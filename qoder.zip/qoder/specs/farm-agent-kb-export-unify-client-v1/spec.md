# farm-agent ChromaDB 导入导出客户端统一 Spec

## Why

`scripts/kb-export.ts` 和 `scripts/kb-import.ts` 使用 LangChain Chroma 客户端，而 `knowledge-indexer.ts` 使用 DirectChromaClient（HTTP API v1 直连）。两个客户端不兼容：

- **kb-export 导出数据不完整**：LangChain 的 `similaritySearchVectorWithScore` 是相似度搜索而非全量导出
- **kb-import 重新 embedding**：浪费 API 费用且嵌入模型可能与原始数据不一致
- **硬编码嵌入模型**：两个脚本硬编码 `text-embedding-3-small`，与统一配置不一致

需要移植 co-agent 的修复方案：统一使用 DirectChromaClient，导出格式升级为 v2（含预计算 embeddings）。

## What Changes

- 创建 `src/lib/chroma-client.ts` 独立共享模块（从 co-agent 移植）
- DirectChromaClient 包含 `get()` 方法（批量导出，含 embeddings）
- `scripts/kb-export.ts`：LangChain Chroma → DirectChromaClient，导出格式 v2（含 embeddings）
- `scripts/kb-import.ts`：LangChain Chroma → DirectChromaClient，直接写入预计算 embeddings
- `knowledge-indexer.ts`：内联类 → 从 `@/lib/chroma-client` 导入

## Impact

- Affected specs: farm-agent-rag-sync-fix-v1（先决条件：pdfjs-dist 迁移已完成）
- Affected code:
  - `src/lib/chroma-client.ts`（新建，从 co-agent 移植）
  - `scripts/kb-export.ts`（重写）
  - `scripts/kb-import.ts`（重写）
  - `src/services/knowledge-indexer.ts`（重构引用）

## Boundaries

- 本次只移植 co-agent 已完成的功能，不做新设计
- 禁止修改 ChromaDB 数据模型和集合结构
- 禁止修改 embedding 配置逻辑

## Requirements

### Requirement: DirectChromaClient 独立共享模块

The system SHALL provide `DirectChromaClient` at `src/lib/chroma-client.ts`.

#### Scenario: 模块独立性
- **WHEN** the module is created
- **THEN** it does NOT import any `@/` prefixed modules
- **AND** it only depends on `fetch` and TypeScript types
- **AND** it can be imported by both Next.js server and tsx scripts

#### Scenario: 方法完整性
- **WHEN** DirectChromaClient is instantiated
- **THEN** methods include: `listCollections`, `getOrCreateCollection`, `add`, `query`, `delete`, `count`, `get`

### Requirement: kb-export 使用 DirectChromaClient

The system SHALL export vectors using DirectChromaClient instead of LangChain Chroma.

#### Scenario: 导出格式 v2
- **WHEN** `kb:export` is executed
- **THEN** export file contains `version: 2`
- **AND** includes `embeddingModel` and `embeddingDim`
- **AND** each vector includes `embedding: number[]`

### Requirement: kb-import 直接写入预计算 embeddings

The system SHALL import vectors by directly writing pre-computed embeddings.

#### Scenario: 直接写入
- **WHEN** `kb:import` processes a v2 export
- **THEN** it calls `client.add()` with pre-computed embeddings
- **AND** it does NOT initialize any embedding model for v2 vectors

#### Scenario: v1 兼容
- **WHEN** processing v1 export without embeddings
- **THEN** it falls back to re-embedding with `getEmbeddings()`

### Requirement: knowledge-indexer 引用共享模块

The system SHALL import `DirectChromaClient` from `@/lib/chroma-client`.
