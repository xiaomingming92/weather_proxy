# Checklist: farm-agent-kb-export-unify-client-v1

## 编译验证
- [ ] `npx tsc --noEmit` 零错误
- [ ] `grep -r "langchain/community/vectorstores/chroma" scripts/` 返回空
- [ ] `grep -r "langchain/openai" scripts/` 返回空
- [ ] `grep -r "langchain/core/documents" scripts/` 返回空

## 共享模块验证
- [ ] `src/lib/chroma-client.ts` 存在且包含 DirectChromaClient 类
- [ ] `DirectChromaClient` 包含 `get()` 方法
- [ ] `chroma-client.ts` 不依赖任何 `@/` 路径别名
- [ ] `knowledge-indexer.ts` 从 `@/lib/chroma-client` 导入 DirectChromaClient
- [ ] `knowledge-indexer.ts` 不包含内联 `class DirectChromaClient`

## 导出验证
- [ ] `npm run kb:export` 导出成功
- [ ] 导出文件格式为 v2（`version: 2`）
- [ ] 导出文件含 `embeddingModel` + `embeddingDim` 字段
- [ ] 导出文件 vectors[0].embedding 长度 > 0
- [ ] 导出文件向量数量 > 0

## 导入验证
- [ ] `npm run kb:import` 导入成功（在干净集合上测试）
- [ ] 导入后 ChromaDB count = 导出文件向量数量
- [ ] v1 导出文件可通过 fallback 重新嵌入导入

## 功能回归
- [ ] `npm run kb:sync` 同步功能正常
- [ ] 文档上传 → 同步 → 检索 端到端通过
