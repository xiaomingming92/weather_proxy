# Tasks: farm-agent-kb-export-unify-client-v1

## Preconditions
- [ ] farm-agent-rag-sync-fix-v1 已完成（pdfjs-dist 迁移、嵌入模型统一）

## Forbidden
- 禁止在新 chroma-client.ts 中引入 `@/` 路径别名依赖
- 禁止 kb-export/kb-import 保留 LangChain 依赖
- 禁止修改 ChromaDB 数据模型

## Tasks

- [ ] Task 1: 创建 chroma-client.ts 共享模块
  **文件**: `src/lib/chroma-client.ts`（新建）
  **依赖**: 无
  - [ ] 从 co-agent 的 `src/lib/chroma-client.ts` 移植完整 DirectChromaClient 类
  - [ ] 包含 `get()` 方法（ChromaDB v1 API）
  - [ ] 确认不依赖 `@/` 路径别名

- [ ] Task 2: 重写 kb-export.ts
  **文件**: `scripts/kb-export.ts`
  **依赖**: Task 1
  - [ ] 移除 LangChain 依赖：`@langchain/community`, `@langchain/openai`, `@langchain/core`
  - [ ] 新增：`import { DirectChromaClient } from "../src/lib/chroma-client"`
  - [ ] 导出格式升级为 v2（embeddingModel + embeddingDim + embeddings）
  - [ ] 使用 `client.get()` 分页拉取全量向量
  - [ ] 使用 `src/config/chroma-config` 获取 CHROMA_URL/COLLECTION/AUTH_TOKEN

- [ ] Task 3: 重写 kb-import.ts
  **文件**: `scripts/kb-import.ts`
  **依赖**: Task 1
  - [ ] 移除 LangChain 依赖
  - [ ] 新增：`import { DirectChromaClient } from "../src/lib/chroma-client"`
  - [ ] v2 路径：`client.add()` 直接写入预计算 embeddings
  - [ ] v1 fallback：动态 import `getEmbeddings` 重新向量化
  - [ ] 使用 `src/config/chroma-config` 获取配置

- [ ] Task 4: 重构 knowledge-indexer.ts
  **文件**: `src/services/knowledge-indexer.ts`
  **依赖**: Task 1
  - [ ] 删除内联 `class DirectChromaClient` 定义
  - [ ] 新增 import: `import { DirectChromaClient } from "@/lib/chroma-client"`
  - [ ] `getChromaCollection()` 和 `resetChromaClient()` 行为不变

- [ ] Task 5: 增强 searchKnowledgeDocuments
  **文件**: `src/services/knowledge-indexer.ts`
  - [ ] 添加 RAG-DEBUG 日志（与 co-agent 对齐）
  - [ ] 添加 agentAudit 审计记录
  - [ ] 添加 `where` 参数支持

- [ ] Task 6: 清理 chroma-direct-client.ts
  **文件**: `src/services/chroma-direct-client.ts`
  - [ ] `grep -r "chroma-direct-client" src/` 确认调用方
  - [ ] 如无调用方 → 删除
  - [ ] 如有调用方 → 迁移到 chroma-client.ts

## Task Dependencies
- Task 2/3 依赖 Task 1（需要 chroma-client.ts）
- Task 4 依赖 Task 1
- Task 5 依赖 Task 4
- Task 6 可独立执行

## Verification
- [ ] `npx tsc --noEmit` 零错误
- [ ] `grep -r "langchain/community/vectorstores/chroma" scripts/` 返回空
- [ ] `grep -r "langchain/openai" scripts/` 返回空
- [ ] `grep -r "langchain/core/documents" scripts/` 返回空
- [ ] `npm run kb:export` 导出成功，含 embeddings 数组
- [ ] `npm run kb:import` 导入成功
