# Tasks: Reasoning 节点结构化数据流

## Preconditions

- [x] `src/agents/prompts/types.ts` 存在且可编辑
- [x] `src/agents/state.ts` 存在且可编辑
- [x] `src/agents/experts/registry.ts` 中 ANALYSIS_EXPERTS 已注册所有专家

## Forbidden

- 禁止改变 LLM 调用次数（保持单次调用）
- 禁止修改 `response.ts`、`verdict.ts`、`intention.ts` 节点逻辑
- 禁止修改 caijuehub 裁决预算
- 禁止修改 agrisynapse 前端代码
- 禁止删除 `buildAnalysisExpertContext()` 函数（标记 @deprecated 保留）

---

- [x] Task 1: 类型层改造
  - [x] 1.1 `prompts/types.ts` 新增 `ExpertReasoningPackage` 接口
  - [x] 1.2 `prompts/types.ts` 新增 `ExpertPromptInput` 接口（query + evidences + toolResults + runtimeInputs）
  - [x] 1.3 `prompts/types.ts` 新增 `ExpertPromptOutput` 接口（结论 + 行动建议 + 风险项）
  - [x] 1.4 `state.ts` 的 `AgentState` 新增 `expertPackages?: ExpertReasoningPackage[]` 字段
  - [x] 1.5 `npx tsc --noEmit` 验证类型无错误

- [x] Task 2: 专家 Prompt 文件创建
  - [x] 2.1 新建 `src/agents/prompts/experts/` 目录
  - [x] 2.2 实现 `src/agents/prompts/experts/index.ts`（注册表 + `loadExpertPrompt()` 函数）
  - [x] 2.3 实现 `crop-compare.ts`（迁移 registry 中 crop_compare.promptTemplate，补充 build/parse/validate）
  - [x] 2.4 实现 `pest-risk.ts`（迁移 pest_risk.promptTemplate）
  - [x] 2.5 实现 `weather-impact.ts`
  - [x] 2.6 实现 `roi-analysis.ts`
  - [x] 2.7 实现 `nutrition-diagnose.ts`
  - [x] 2.8 实现 `growth-report.ts`
  - [x] 2.9 实现 `planting-advice.ts`
  - [x] 2.10 实现 `work-plan.ts`
  - [x] 2.11 实现 `machinery-dispatch.ts`
  - [x] 2.12 实现 `daily-report.ts`（汇总专家，`ExpertPromptInput` 需额外 `coreExpertConclusions?: string`，当前版本用空字符串占位）
  - [x] 2.13 实现 `weekly-report.ts`（汇总专家，同 2.12）
  - [x] 2.14 `npx tsc --noEmit` 验证

- [x] Task 3: registry 与 prompt 解耦
  - [x] 3.1 `registry.ts` 中 `AnalysisExpert` 接口新增 `promptRef: string` 字段
  - [x] 3.2 `promptTemplate` 字段标记 `@deprecated`，暂保留（向后兼容）
  - [x] 3.3 每个专家条目补充 `promptRef` 值（对应 prompts/experts/ 文件名，不含扩展名）
  - [x] 3.4 `npx tsc --noEmit` 验证

- [x] Task 4: retrieval 节点输出 expertPackages
  - [x] 4.1 retrieval 节点在 per-expert 检索完成后，按 expertId 分组构建 `ExpertReasoningPackage[]`
  - [x] 4.2 每个 package 的 `evidences` 填充完整 content（不截断）
  - [x] 4.3 每个 package 的 `runtimeInputs` 从 `analysisContext.runtimeInputs` 读取
  - [x] 4.4 每个 package 的 `promptRef` 从 registry 对应专家的 `promptRef` 读取
  - [x] 4.5 retrieval 节点返回值新增 `expertPackages` 字段
  - [x] 4.6 `npx tsc --noEmit` 验证

- [x] Task 5: reasoning 节点消费结构化包
  - [x] 5.1 检测 `state.expertPackages`，存在时走新路径，否则回退旧路径（@deprecated）
  - [x] 5.2 从 `state.messages` 过滤 `role="tool"` 消息，按 `realtimeToolNames` 归入对应 `package.toolResults`
  - [x] 5.3 无归属的工具结果写入 `globalToolResults`
  - [x] 5.4 对每个 package 调用 `loadExpertPrompt(expertId).build({ query, evidences, toolResults, runtimeInputs })`
  - [x] 5.5 拼接全局 prompt：框架 prompt + 各专家区块 + subIntentContext + 全局工具结果 + 输出格式
  - [x] 5.6 LLM 单次调用，parse/validate 保持不变
  - [x] 5.7 审计标记新增 `REASONING_EXPERT_PACKAGE_CONSUME` 阶段
  - [x] 5.8 `npx tsc --noEmit` 验证

- [x] Task 6: 编译验证 + 回归测试
  - [x] 6.1 `npx tsc --noEmit` 全量零错误
  - [ ] 6.2 启动开发服务器，触发一次包含 pest_risk 分析的对话
  - [ ] 6.3 验证 LLM prompt 中 pest_risk 区块包含完整证据和工具结果
  - [ ] 6.4 验证 expertPackages 未传入时回退到旧路径不崩溃

## Task Dependencies

- Task 2 依赖 Task 1（类型定义）
- Task 3 依赖 Task 1（promptRef 类型）
- Task 4 依赖 Task 1 + Task 3（ExpertReasoningPackage 类型 + registry promptRef 字段）
- Task 5 依赖 Task 2 + Task 3 + Task 4
- Task 6 依赖 Task 5

## Verification

- [x] `npx tsc --noEmit` 零错误
- [ ] `npm run lint` 零错误（或仅已有 warning）
- [ ] 回归：分析对话触发，各专家区块 prompt 结构正确
- [ ] 降级：expertPackages=undefined 时不崩溃
