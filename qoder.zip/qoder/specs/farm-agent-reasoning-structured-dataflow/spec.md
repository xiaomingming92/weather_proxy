# Reasoning 节点结构化数据流 Spec

## Why

reasoning 节点当前采用字符串拼接模式，四个结构性缺陷导致推理质量不可靠：专家 Prompt 无结构化绑定、工具结果无归属且截断 200 字符、RAG 证据二次截断 300 字符、最终 prompt 六段无序拼接。

## What Changes

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/prompts/types.ts` | 修改 | 新增 `ExpertReasoningPackage`、`ExpertPromptInput`、`ExpertPromptOutput` 接口 |
| `src/agents/state.ts` | 修改 | AgentState 新增 `expertPackages` 可选字段 |
| `src/agents/prompts/experts/index.ts` | 新建 | 专家 prompt 注册表 + `loadExpertPrompt()` 函数 |
| `src/agents/prompts/experts/crop-compare.ts` | 新建 | 作物对比专家 PromptTemplate |
| `src/agents/prompts/experts/pest-risk.ts` | 新建 | 病虫害专家 PromptTemplate |
| `src/agents/prompts/experts/weather-impact.ts` | 新建 | 气象分析专家 PromptTemplate |
| `src/agents/prompts/experts/roi-analysis.ts` | 新建 | ROI 分析专家 PromptTemplate |
| `src/agents/prompts/experts/nutrition-diagnose.ts` | 新建 | 营养诊断专家 PromptTemplate |
| `src/agents/prompts/experts/growth-report.ts` | 新建 | 生长报告专家 PromptTemplate |
| `src/agents/prompts/experts/planting-advice.ts` | 新建 | 种植建议专家 PromptTemplate |
| `src/agents/prompts/experts/work-plan.ts` | 新建 | 作业计划专家 PromptTemplate |
| `src/agents/prompts/experts/machinery-dispatch.ts` | 新建 | 农机调度专家 PromptTemplate |
| `src/agents/prompts/experts/daily-report.ts` | 新建 | 日报汇总专家 PromptTemplate |
| `src/agents/prompts/experts/weekly-report.ts` | 新建 | 周报汇总专家 PromptTemplate |
| `src/agents/experts/registry.ts` | 修改 | `promptTemplate` 字段废弃，替换为 `promptRef` |
| `src/agents/nodes/retrieval.ts` | 修改 | 额外构建并返回 `expertPackages`（按 expertId 分组，evidences 不截断） |
| `src/agents/nodes/reasoning.ts` | 修改 | 从 `state.expertPackages` 消费结构化包，工具结果按 `realtimeToolNames` 归集，调用 `expertPrompt.build()` 构建分区 prompt |

## Impact

- Affected specs: 无
- Affected code: `reasoning.ts`、`retrieval.ts`、`registry.ts`、`state.ts`、`prompts/types.ts`
- 父 Plan: `.qoder/plans/farm-agent-reasoning-structured-dataflow-plan-v1.md`
- 依赖: `src/agents/experts/registry.ts`（ANALYSIS_EXPERTS 注册表）
- 后续依赖: 处方生成接口（依赖结构化 verdict 输出）

## Boundaries

**本次只允许实现**：
- 专家 Prompt 结构化文件创建（prompts/experts/）
- retrieval 节点额外输出 expertPackages
- reasoning 节点消费 expertPackages 替代字符串拼接
- 工具结果按 realtimeToolNames 归属到专家包

**本次禁止实现**：
- 禁止改变 LLM 调用次数（保持单次调用）
- 禁止修改 `response.ts` 或 `verdict.ts` 节点逻辑
- 禁止修改 `intention.ts` 节点逻辑
- 禁止修改 caijuehub 裁决预算（`src/caijuehub/strategies/sub-intent.ts` 中的 `TOTAL_RETRIEVAL_POOL` 和 `resolveRetrieveBudget()` 保持不变）
- 禁止修改 agrisynapse 前端代码
- 禁止删除 `buildAnalysisExpertContext()` 函数（向后兼容，标记 @deprecated）

## Requirements

### Requirement: ExpertReasoningPackage 类型定义

系统 SHALL 在 `prompts/types.ts` 中定义 `ExpertReasoningPackage` 接口，包含 `expertId`、`label`、`promptRef`、`evidences[]`、`toolResults[]`、`runtimeInputs` 字段。

#### Scenario: 接口字段完整性

WHEN `ExpertReasoningPackage` 被实例化
THEN 包含 expertId(string)、label(string)、promptRef(string)、evidences(RetrievalEvidence[])、toolResults({toolName:string,content:string}[])、runtimeInputs(Record<string,unknown>)

#### Scenario: evidences 不截断

WHEN retrieval 节点填充 evidences
THEN 每条 evidence 保留完整 content，不做 300 字符截断

#### Scenario: toolResults 初始化

WHEN retrieval 节点构建 expertPackages
THEN 每个 package 的 toolResults 初始化为空数组 []

### Requirement: ExpertPromptInput 类型定义

系统 SHALL 在 `prompts/types.ts` 中定义 `ExpertPromptInput` 接口，作为 `build()` 方法的输入参数。

#### Scenario: Input 字段构成

WHEN `build()` 被调用
THEN Input 包含 query(string)、evidences(RetrievalEvidence[])、toolResults、runtimeInputs

#### Scenario: 汇总专家扩展字段

WHEN 汇总专家（daily/weekly-report）调用 build()
THEN Input 可选包含 `coreExpertConclusions?: string`，当前版本用空字符串占位

### Requirement: ExpertPromptOutput 类型定义

系统 SHALL 在 `prompts/types.ts` 中定义 `ExpertPromptOutput` 接口，仅用于 build 阶段，不参与 parse。

#### Scenario: Output 仅用于 build

WHEN reasoning 节点完成 LLM 调用
THEN 用 `reasoningPrompt.parse()` 统一解析整体输出，不使用 ExpertPromptOutput 的 parse/validate

### Requirement: AgentState 新增 expertPackages

系统 SHALL 在 `state.ts` 的 `AgentState` 中新增 `expertPackages?: ExpertReasoningPackage[]` 字段。

#### Scenario: 字段可选性

WHEN AgentState 被初始化
THEN expertPackages 默认为 undefined，不影响现有节点运行

#### Scenario: 字段赋值

WHEN retrieval 节点完成 expertPackages 构建
THEN 通过 `return { expertPackages: [...] }` 写入 state

### Requirement: 专家 prompt 文件目录结构

系统 SHALL 在 `src/agents/prompts/experts/` 下为每个注册专家创建独立文件。

#### Scenario: 目录创建

WHEN Task 2 完成
THEN 存在 11 个专家 prompt 文件 + 1 个 index.ts

#### Scenario: 文件命名规范

WHEN 专家 ID 为 `pest_risk`
THEN 文件名为 `pest-risk.ts`（kebab-case）

### Requirement: 专家 prompt 文件接口实现

每个专家 prompt 文件 SHALL 实现 `PromptTemplate<ExpertPromptInput, ExpertPromptOutput>` 接口。

#### Scenario: build() 返回完整区块

WHEN `pest-risk.ts` 的 build() 被调用
THEN 返回包含分析要求 + 证据列表 + 工具结果 + 运行时输入的完整 prompt 区块文本

#### Scenario: build() 内聚格式化

WHEN build() 接收到 evidences 和 toolResults
THEN build() 内部负责格式化（不同专家可有不同的展示方式），reasoning 节点不关心格式细节

### Requirement: loadExpertPrompt 加载函数

系统 SHALL 在 `index.ts` 中实现 `loadExpertPrompt(expertId: string)` 函数。

#### Scenario: 正常加载

WHEN `loadExpertPrompt("pest_risk")` 被调用
THEN 返回 pest-risk.ts 导出的 PromptTemplate 实例

#### Scenario: 找不到专家时的降级

WHEN `loadExpertPrompt("nonexistent_expert")` 被调用
THEN 返回默认 prompt 模板（不抛异常，不崩溃）

### Requirement: 专家 prompt 注册表

系统 SHALL 在 `index.ts` 中维护 `Map<string, PromptTemplate>` 注册表。

#### Scenario: 注册表初始化

WHEN index.ts 被加载
THEN 注册表包含所有 11 个专家的映射

### Requirement: registry promptRef 字段

系统 SHALL 将 `AnalysisExpert.promptTemplate` 废弃，替换为 `promptRef: string`。

#### Scenario: promptRef 值

WHEN 读取 `ANALYSIS_EXPERTS.pest_risk.promptRef`
THEN 返回 `"pest-risk"`

#### Scenario: 旧字段移除

WHEN Task 3 完成
THEN 所有 AnalysisExpert 实例不再有 promptTemplate 字段

### Requirement: retrieval 节点构建 expertPackages

系统 SHALL 在 retrieval 节点中额外构建 `expertPackages: ExpertReasoningPackage[]`。

#### Scenario: 按专家分组

WHEN retrieval 完成 per-expert 检索
THEN 每个激活专家产出一个 ExpertReasoningPackage，evidences 包含该专家的完整 RAG 证据

#### Scenario: runtimeInputs 填充

WHEN 构建 expertPackages
THEN runtimeInputs 从 analysisContext.runtimeInputs 读取

#### Scenario: 不破坏现有 evidenceChain

WHEN retrieval 返回结果
THEN 现有 evidenceChain 字段保持不变，expertPackages 为额外追加

### Requirement: toolResults 按 realtimeToolNames 归集

系统 SHALL 在 reasoning 节点中将 tool 消息按 realtimeToolNames 归入对应专家包。

#### Scenario: 工具结果归属

WHEN state.messages 含 name="query_farm_weather" 的工具消息，pest_risk.realtimeToolNames 包含它
THEN 该工具结果写入 pest_risk 包的 toolResults，content 不截断

#### Scenario: 无归属工具结果

WHEN 某工具消息的 name 不在任何专家的 realtimeToolNames 中
THEN 写入全局 globalToolResults，在全局 prompt 区块中展示

#### Scenario: 多专家共享工具

WHEN 两个专家的 realtimeToolNames 都包含同一个工具名
THEN 该工具结果同时写入两个专家的 toolResults

### Requirement: reasoning 节点消费 expertPackages

系统 SHALL 在 reasoning 节点中从 state.expertPackages 读取专家包，构建分区 prompt。

#### Scenario: 多专家分区拼接

WHEN 激活 pest_risk 和 weather_impact 两个专家
THEN 生成包含两个专家区块的 prompt，每区块含完整 prompt + 证据 + 工具结果

#### Scenario: 单次 LLM 调用

WHEN prompt 拼接完成
THEN 仅调用一次 LLM，不增加调用次数

#### Scenario: 专家区块顺序

WHEN 多个专家包同时存在
THEN 按 expertPackages 数组顺序拼接，核心专家在前，汇总专家在后

### Requirement: 审计阶段扩展

系统 SHALL 在 `AgentAuditPhase` 联合类型中新增 3 个审计阶段。

#### Scenario: 新增审计字面量

WHEN Task 5 实施
THEN AgentAuditPhase 包含 REASONING_EXPERT_PACKAGE_CONSUME、REASONING_TOOL_ATTRIBUTION、REASONING_EXPERT_PROMPT_BUILD

### Requirement: 向后兼容

系统 SHALL 保持 `buildAnalysisExpertContext()` 函数存在（标记 @deprecated）。

#### Scenario: expertPackages 缺失时降级

WHEN state.expertPackages 为 undefined
THEN reasoning 节点回退到旧的 buildAnalysisExpertContext() 路径，不崩溃

#### Scenario: 旧函数保留

WHEN Task 5 完成
THEN buildAnalysisExpertContext() 函数仍存在且带有 @deprecated 注释

### Requirement: 编译验证

系统 SHALL 在所有 Task 完成后通过 `npx tsc --noEmit` 零错误。

#### Scenario: 类型安全

WHEN 所有文件修改完成
THEN tsc --noEmit 无错误输出

### Requirement: evidences 复用 RetrievalEvidence 类型

系统 SHALL 复用现有 `RetrievalEvidence` 类型作为 `ExpertReasoningPackage.evidences` 的元素类型，不重复定义。

#### Scenario: 类型复用

WHEN ExpertReasoningPackage.evidences 被类型检查
THEN 元素类型为 RetrievalEvidence，无额外包装

### Requirement: toolResults 内部结构

系统 SHALL 定义 toolResults 元素为 `{ toolName: string, content: string }` 结构。

#### Scenario: 工具结果结构

WHEN reasoning 节点填充 toolResults
THEN 每个元素包含 toolName 和 content，content 为工具消息的原始文本

### Requirement: runtimeInputs 透传

系统 SHALL 将 `analysisContext.runtimeInputs` 透传至每个 ExpertReasoningPackage.runtimeInputs。

#### Scenario: 透传不复制

WHEN retrieval 构建 expertPackages
THEN runtimeInputs 直接引用 analysisContext.runtimeInputs，不做深拷贝

### Requirement: @deprecated 标记

系统 SHALL 在 `buildAnalysisExpertContext()` 函数签名前添加 `/** @deprecated */` JSDoc 注释。

#### Scenario: 标记存在

WHEN 查看 buildAnalysisExpertContext 函数源码
THEN 函数声明前存在 `@deprecated` JSDoc 注释

### Requirement: 回退路径触发条件

系统 SHALL 当 `state.expertPackages === undefined` 时自动回退旧路径。

#### Scenario: undefined 检测

WHEN reasoning 节点执行且 state.expertPackages 为 undefined
THEN 调用 buildAnalysisExpertContext() 走旧路径

### Requirement: 审计日志 REASONING_EXPERT_PACKAGE_CONSUME

系统 SHALL 在 reasoning 节点开始消费 expertPackages 时记录审计日志。

#### Scenario: 审计植入

WHEN reasoning 节点检测到 state.expertPackages 存在
THEN 调用 agentAudit("REASONING_EXPERT_PACKAGE_CONSUME", ...)

### Requirement: 审计日志 REASONING_TOOL_ATTRIBUTION

系统 SHALL 在工具结果归属到各专家包完成时记录审计日志。

#### Scenario: 审计植入

WHEN reasoning 节点完成 toolResults 归集
THEN 调用 agentAudit("REASONING_TOOL_ATTRIBUTION", ...)

### Requirement: 审计日志 REASONING_EXPERT_PROMPT_BUILD

系统 SHALL 在各专家区块 prompt 构建完成时记录审计日志。

#### Scenario: 审计植入

WHEN reasoning 节点完成所有专家区块 prompt 拼接
THEN 调用 agentAudit("REASONING_EXPERT_PROMPT_BUILD", ...)

### Requirement: lint 验证

系统 SHALL 在所有修改文件完成后通过 `npm run lint` 无新增警告或错误。

#### Scenario: lint 通过

WHEN 所有文件修改完成
THEN npm run lint 无新增问题

### Requirement: 回归测试

系统 SHALL 在 Task 6 完成回归测试，确认现有对话链路不受影响。

#### Scenario: 回归测试通过

WHEN 运行 vitest
THEN 所有现有测试用例通过，无新增失败
