# Checklist: Reasoning 节点结构化数据流

## 类型层验证

- [x] C1: `ExpertReasoningPackage` 接口已在 `prompts/types.ts` 定义，含 expertId / label / promptRef / evidences[] / toolResults[] / runtimeInputs
- [x] C2: `ExpertPromptInput` 接口已定义，含 query / evidences / toolResults / runtimeInputs
- [x] C3: `ExpertPromptOutput` 接口已定义，含 conclusion / actions / risks
- [x] C4: `AgentState` 已新增 `expertPackages?: ExpertReasoningPackage[]`

## 专家 Prompt 文件验证

- [x] C5: `src/agents/prompts/experts/index.ts` 存在，含 `loadExpertPrompt()` 函数
- [x] C6: 每个在 ANALYSIS_EXPERTS 注册的专家在 `prompts/experts/` 下有对应文件
- [x] C7: 每个专家 prompt 文件实现 `PromptTemplate<ExpertPromptInput, ExpertPromptOutput>` 接口
- [x] C8: 每个专家 prompt 的 `build()` 输出包含该专家的分析要求 + 证据 + 工具结果

## registry 解耦验证

- [x] C9: `AnalysisExpert` 接口新增 `promptRef: string` 字段
- [x] C10: 每个专家条目的 `promptRef` 值与 `prompts/experts/` 下文件名对应
- [x] C11: `promptTemplate` 字段标记 `@deprecated` 但尚未删除

## retrieval 节点验证

- [x] C12: retrieval 节点返回值包含 `expertPackages` 字段
- [x] C13: 每个 package 的 `evidences` 包含完整 content（不截断）
- [x] C14: 每个 package 的 `runtimeInputs` 来自 `analysisContext.runtimeInputs`
- [x] C15: 每个 package 的 `promptRef` 来自 registry

## reasoning 节点验证

- [x] C16: reasoning 节点优先从 `state.expertPackages` 读取，无值时回退旧路径
- [x] C17: 工具结果按 `realtimeToolNames` 归入对应专家包，content 不截断
- [x] C18: 无归属工具结果写入全局区块
- [x] C19: 每个专家区块由 `expertPrompt.build()` 生成，非字符串拼接
- [x] C20: LLM 调用次数保持单次（不增加）

## 向后兼容验证

- [x] C21: `buildAnalysisExpertContext()` 函数仍存在（@deprecated）
- [x] C22: `state.expertPackages` 为 undefined 时 reasoning 节点不崩溃

## 编译与回归

- [x] C23: `npx tsc --noEmit` 零错误
- [ ] C24: `npm run lint` 无新增错误
- [ ] C25: 回归测试：pest_risk 分析对话，prompt 中 pest_risk 区块完整
- [ ] C26: 审计阶段 `REASONING_EXPERT_PACKAGE_CONSUME` 已在审计日志中出现
