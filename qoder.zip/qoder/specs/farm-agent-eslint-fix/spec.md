# farm-agent ESLint 全量修复 Spec

## Why

`npx eslint src/` 产生 49 个 error + 171 个 warning，降低代码质量基线，阻塞 CI/CD 流水线。
项目中存在 60+ 处 `as unknown as` 双重 cast，其中约 37 处可通过类型改进消除。双重 cast 掩盖类型不安全问题，是 lint 质量的隐性债务。

## What Changes

修改 40+ 个文件，分三个阶段：

| 阶段 | 范围 | 变更概要 |
|------|------|---------|
| Phase 1 | ESLint error 清零 | 35 处 `any` → 具体类型，9 处 `let` → `const`，3 处 React hooks 修复，2 处 import 风格修正 |
| Phase 2 | `as unknown as` 双重 cast 消除 | ~37 处消除（60+ → 23），5 类策略：运行时检查、JSON import、枚举同源、JsonSerializable 边界、DTO/Zod/Prisma 收窄 |
| Phase 3 | unused-vars 清理 | 118 处 warning 消除（161 → 43），eslint 配置添加 `_` 前缀忽略规则 |

消除策略明细（Phase 2）：

| 策略 | 数量 | 说明 |
|------|:--:|------|
| `Array.isArray()` 运行时检查 | 3 | 替代 `as unknown[]` |
| JSON import `.default as` | 5 | 替代 `as unknown as` JSON 类型断言 |
| 枚举同源对齐 | 4 | `InteractionPoint.type` → `InterruptType` 枚举 |
| `JsonSerializable` 类型定义 | 3 | 内聚 cast 到工具函数内部 |
| DTO/Zod/Prisma 类型收窄 | 22 | 补齐字段、单步 cast、`interface` → `type` |

残留 23 处为合法类型边界（LangGraph / fetch proxy / 消息桥接 / LLM response / stream chunk / 第三方库签名差异），本轮不消除。

## Impact

- Affected specs: 无
- Affected code: 40+ 个 src/ 下文件
- 父 Plan: `.qoder/plans/2026-07/02/farm-agent-eslint-fix-plan-v1.md`
- 依赖: 无
- 后续依赖: Zod-DTO 收敛 Plan（串行，已发现 ChatRequest 三份并行类型定义）

## Boundaries

- 本次只修复 ESLint error + 可通过类型改进消除的 `as unknown as` + unused-vars
- 本次禁止修改业务逻辑（运行时行为不变）
- 本次禁止引入新依赖
- 本次禁止全局禁用 ESLint 规则
- 残留 23 处 cast 标记为合法边界，不在本轮处理

---

## Phase 1 Requirements

### Requirement: ESLint Error 清零
系统 SHALL 通过 `npx eslint src/` 无 error 级别问题。

Scenario: 执行 `npx eslint src/` → 0 errors。

### Requirement: 类型安全
系统 SHALL 将所有 `no-explicit-any` 违规替换为具体 TypeScript 类型。

Scenario: 执行 `npx eslint src/` → 0 `no-explicit-any` errors。

### Requirement: 编译通过
系统 SHALL 通过 `npx tsc --noEmit` 零类型错误。

Scenario: 执行 `npx tsc --noEmit` → 退出码 0。

### Requirement: 自动修复
系统 SHALL 通过 `eslint --fix` 自动修复 `prefer-const` 和部分 `no-unused-vars` 违规。

Scenario: 执行 `npx eslint --fix src/` → `prefer-const` error = 0。

### Requirement: React Hooks 合规
系统 SHALL 修复 `react-hooks/set-state-in-effect` 和 `react-hooks/purity` 违规。

Scenario: 执行 `npx eslint src/` → 0 react-hooks errors。

### Requirement: Import 风格统一
系统 SHALL 将 `require()` 替换为 ES module `import`，修正 crypto import 路径为 `globalThis.crypto.randomUUID()`。

Scenario: 执行 `npx eslint src/` → 0 no-require-imports + 0 no-restricted-imports errors。

### Requirement: Warning 收敛
系统 SHALL 修复 P1 级 warning（no-restricted-syntax + react-hooks/exhaustive-deps + jsx-a11y/alt-text）。

Scenario: 执行 `npx eslint src/` → P1 warning 清零。

---

## Phase 2 Requirements

### Requirement: 双重 Cast 数量收敛
系统 SHALL 将 `as unknown as` 总数从 60+ 降至 23。

Scenario: 执行 `grep -rn "as unknown as" src/ --include="*.ts" --include="*.tsx" | wc -l` → 结果 = 23。

### Requirement: 残留分类可审计
系统 SHALL 将 23 处残留按根因分为 6 类，每类有明确的消除路径（归属后续 Plan）。

Scenario: Plan Task 11 的分类表与实际残留一一对应。

### Requirement: 运行时检查替代类型断言
`tool-node-wrapper`、`reasoning`、`response` 中的 `as unknown[]` SHALL 替换为 `Array.isArray()` 运行时检查。

Scenario: 上述文件中不存在 `as unknown[]` 模式。

### Requirement: JSON import 类型安全
`climate-zone-lookup`、`climate-zone-tools`、`city-coords` 中的 JSON import SHALL 使用 `.default as` 模式替代双重 cast。

Scenario: 上述文件中 JSON import 不使用 `as unknown as`。

### Requirement: 枚举类型同源
`InteractionPoint.type` 和 `InteractionPointOutput.type` SHALL 直接使用 `InterruptType` 枚举，消除跨类型断言。

Scenario: `structured-output.ts` 和 `prompts/types.ts` 中 `InteractionPoint` 的 `type` 字段类型为 `InterruptType`。

### Requirement: DTO 字段完整
`ChatRequest` SHALL 补齐 `intent` 字段，`NeuronChatRequestSchema` SHALL 补全全部字段，消除请求体的双重 cast。

Scenario: `[hash]/route.ts` 中 request body 不使用 `as unknown as`。

### Requirement: Prisma 单步 Cast
`prescriptions/[id]`、`tasks/[id]` 中的 Prisma `InputJsonValue` 双重 cast SHALL 降级为单步 cast。

Scenario: 上述文件中 Prisma 相关 cast 不包含 `as unknown as`。

### Requirement: GlobalState 类型定义
`global-state.ts` 中 9 个 `interface` SHALL 改为 `type`，消除 index signature 差异导致的双重 cast。

Scenario: `global-state.ts` 中不使用 `interface` 定义域快照类型。

---

## Phase 3 Requirements

### Requirement: unused-vars 收敛
系统 SHALL 将 `no-unused-vars` warning 从 161 降至 43。

Scenario: 执行 `npx eslint src/` → `no-unused-vars` warning = 43。

### Requirement: ESLint 配置增强
系统 SHALL 在 `eslint.config.mjs` 中添加 `argsIgnorePattern`/`varsIgnorePattern`/`caughtErrorsIgnorePattern` 规则。

Scenario: eslint 配置中包含 `^_` 忽略模式。
