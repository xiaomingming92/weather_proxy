# Tasks: farm-agent ESLint 全量修复

## Preconditions

- [x] Plan 已生成
- [x] ADD Route 已生成
- [x] Review 已生成
- [x] Handoff 已生成

## Forbidden

- 禁止修改业务逻辑（运行时行为不变）
- 禁止引入新依赖
- 禁止全局禁用 ESLint 规则
- 禁止消除 23 处合法类型边界的 cast

---

## Phase 1: ESLint error 清零（49 → 0）

- [x] Task 1: 自动修复 (`eslint --fix`) — 验证: `prefer-const` error = 0
  - [x] 执行 `npx eslint --fix src/`
  - [x] `git diff` 审阅变更
  - [x] 验证无类型破坏

- [x] Task 2: 修复 `no-explicit-any`（35 个，19 文件）— 验证: `no-explicit-any` = 0
  - [x] 逐文件定义具体类型替换 `any`
  - [x] 每批完成后 `tsc --noEmit` 验证

- [x] Task 3: 修复 React hooks（3 个，2 文件）— 验证: react-hooks error = 0
  - [x] `evidence-chain-panel.tsx`：状态提升 → expandedIds Set 受控组件
  - [x] `node-progress-timeline.tsx`：`now` prop + eslint-disable

- [x] Task 4: 修复杂项 error（2 个，2 文件）— 验证: 杂项 error = 0
  - [x] `service-auth-resolver.ts`：`require()` → `import`
  - [x] `append-runtime-finding.ts`：`globalThis.crypto.randomUUID()`

- [x] Task 5: 修复 warning（11 个）— 验证: P1 warning 清零
  - [ ] `no-restricted-syntax`（9 个）：标注为已知存量
  - [ ] `react-hooks/exhaustive-deps`（1 个）：待处理
  - [x] `jsx-a11y/alt-text`（1 个）：添加 alt 属性

- [x] Task 6: 编译 + ESLint 复验 — 验证: tsc 零错误 + eslint 零 error
  - [x] `npx tsc --noEmit` 零错误
  - [x] `npx eslint src/` 零 error

---

## Phase 2: `as unknown as` 双重 cast 消除（~60+ → 23）

### Phase 2.1: 第一轮消除 — 运行时检查 + JSON import + 枚举对齐（10 处）

- [x] Task 7.1: D 类 — `as unknown[]` → `Array.isArray()` 运行时检查
  - [x] `src/agents/tool-node-wrapper.ts`
  - [x] `src/agents/nodes/reasoning.ts`
  - [x] `src/agents/nodes/response.ts`

- [x] Task 7.2: C 类 — JSON import `as unknown as` → `.default as`
  - [x] `src/lib/climate-zone-lookup.ts`（2 处）
  - [x] `src/agents/tools/impl/climate-zone-tools.ts`（2 处）
  - [x] `src/lib/city-coords.ts`（1 处）

- [x] Task 7.3: E 类 — 枚举对齐
  - [x] `src/agents/types/structured-output.ts`
  - [x] `src/agents/prompts/types.ts`
  - [x] `src/agents/nodes/interaction-point-detection.ts`（移除 cast）

### Phase 2.2: JsonSerializable 边界（3 处）

- [x] Task 8.1: 定义 `JsonSerializable` 类型，`sanitizeSnapshot` 内部收敛 cast
  - [x] `src/lib/agent-chain-tracer.ts`

- [x] Task 8.2: Prisma.InputJsonValue 单步 cast
  - [x] `src/services/chat-persistence.ts`

- [x] Task 8.3: validTypes 改用 `InterruptType[]`
  - [x] `src/agents/prompts/interaction-point-detection.ts`

### Phase 2.3: DTO + Zod 联动（8 处）

- [x] Task 9.1: `ChatRequest` 补齐 `intent` 字段
  - [x] `src/dto/agent.dto.ts`

- [x] Task 9.2: `NeuronChatRequestSchema` 补全全部字段 + 5 处 body cast 消除
  - [x] `src/app/api/agent/[hash]/route.ts`
  - [x] `src/app/api/types/hash/schemas.ts`

- [x] Task 9.3: `handleUpdateThreadTitlePOST` 改用 `UpdateThreadTitleRequest` + body.type dispatch
  - [x] `src/app/api/agent/[hash]/route.ts`

### Phase 2.4: Prisma + 域迭代 + 杂项（12 处）

- [x] Task 10.1: Prisma InputJsonValue 双 cast → 单步 cast
  - [x] `src/app/api/h5/nongqing/prescriptions/[id]/route.ts`（2 处）
  - [x] `src/app/api/h5/nongqing/tasks/[id]/route.ts`（2 处）

- [x] Task 10.2: `global-state.ts` 9 个 `interface` → `type`
  - [x] `src/agents/global-state.ts`

- [x] Task 10.3: `chat-store.ts` 参数收窄为 `Partial<StructuredAgentResponse>`
  - [x] `src/stores/chat-store.ts`
  - [x] `src/components/chat/chat-panel.tsx`（调用方适配）

- [x] Task 10.4: `stream/route.ts` body 用 Zod 推导类型
  - [x] `src/app/api/agent/chat/stream/route.ts`

### Phase 2.5: 残留分类（23 处 — 合法类型边界，本轮不消除）

- [x] Task 11.1: 对 23 处残留逐一分类并记录

| 根因 | 数量 | 文件 |
|------|:--:|------|
| LangGraph 边界 | 7 | tool-node-wrapper ×2, agent-runner ×5 |
| fetch proxy | 5 | proxy-fetch ×2, web-search ×3 |
| 消息类型桥接 | 3 | intention ×3 |
| LLM response 解析 | 2 | variety-recommend/route ×2 |
| Stream chunk | 2 | h5/agent/route ×1, [hash]/route ×1 |
| 第三方库 | 4 | prisma ×1, layer2-callback ×1, model-config ×1, ocr-worker ×1 |

---

## Phase 3: unused-vars 清理（161 → 43）

- [x] Task 12.1: ESLint 配置变更 — 添加 `_` 前缀忽略规则
  - [x] `eslint.config.mjs`

- [x] Task 12.2: 批量清理未使用 import / 类型 / 函数（84 处，72 文件）
  - [x] 删除未使用 import
  - [x] 删除未使用类型定义
  - [x] 删除未使用函数/常量
  - [x] `_` 前缀处理接口强制参数（34 处）

- [x] Task 12.3: 编译 + ESLint 复验
  - [x] `npx tsc --noEmit` 零错误
  - [x] `npx eslint src/` 零 error
  - [x] warnings 从 172 降至 54

---

## Task 13: `RunnableConfig` 泛型升级（验收补修 4 error）

- [x] Task 13.1: 定义 `AgentConfigurable` 接口 + `AgentRunnableConfig` 泛型别名
  - [x] `src/agents/agent-runner.ts`
  - [x] `src/agents/index.ts`（导出新类型）

- [x] Task 13.2: 消除 route 层 4 个 `as any`
  - [x] `src/app/api/agent/[hash]/route.ts`：移 globalStateProvider+eventBus 到 config，删 `as any`
  - [x] `src/app/api/agent/chat/route.ts`：删 input `as any` + result 类型推断
  - [x] `src/app/api/agent/stream/route.ts`：删 input `as any` + config `as any`

- [x] Task 13.3: 消除内部 `as` 断言
  - [x] `src/agents/agent-runner.ts`：消除 2 处 `as Record<string, unknown>` / `as GlobalStateProvider`
  - [x] `src/agents/audit-wrapper.ts`：消除 2 处 `as GlobalStateProvider` / `as CognitiveEventBus` + 删 2 个未使用 import

---

## Task Dependencies

- Task 1 → Task 2 → Tasks 3-5（并行）→ Task 6
- Task 6 → Task 7 → Task 8 → Task 9 → Task 10 → Task 11
- Task 11 → Task 12（Phase 3 独立，无 cast 依赖）
- Task 12 → Task 13（验收发现 4 error 补修）

## Verification

- [x] `npx tsc --noEmit` 零错误
- [x] `npx eslint src/` 零 error
- [x] `no-explicit-any` 35 → 0 → 4 → 0（Task 13 补修）
- [x] `prefer-const` 9 → 0
- [x] `as unknown as` ~60+ → 23
- [x] `no-unused-vars` 161 → 43
- [x] warnings 172 → 61
