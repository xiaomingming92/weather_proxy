# farm-agent 架构合流闭包 Spec — Global State Model + Cognitive Event Bus + Policy Loop

## Why

前 7 轮建立了 7 个局部闭包（类型收敛、响应裁决、专家注册、管线消费、语义缓存、演化闭环、三层审计），每轮独立可用。但四套子系统（交互/记忆/认知/执行）并行发展，缺少统一内核：

- **AgentState** 是 LangGraph 管线的局部状态，不表达全局系统状态
- **stream-bus** 是 SSE 流式事件通道，不是认知执行事件中枢
- **path-metrics / cache-ttl-stats / turnHistory** 各自独立运行，不形成统一的 Policy 决策
- 后续 L4 演进（多推理路径仲裁）在无统一 state schema 和 event schema 前无法开始

第 8 轮不做新的业务功能，而是建立统一认知与执行内核，把前 7 轮合流为一个可治理的 Agent OS 内核。

---

## What Changes

### 新增 3 个文件

| 文件 | 职责 |
|------|------|
| `src/agents/global-state.ts` | **GlobalSystemState** 类型定义 + 状态提供器 + snapshot/diff |
| `src/agents/cognitive-event-bus.ts` | **CognitiveEventBus** 类 + 认知事件类型定义 |
| `src/agents/policy-update-loop.ts` | **PolicyUpdateRecord** 类型 + **PolicyUpdateLoop** 决策函数 |

### 修改 8 个文件

| 文件 | 改动 |
|------|------|
| `src/agents/state.ts` | 导出 `agentStateToCognitiveSnapshot()`；`CurrentTask` 新增可选字段 `subIntents?` |
| `src/agents/index.ts` | 管线中注入 CognitiveEventBus + GlobalStateProvider；意图完成后 emit subIntent:detected |
| `src/agents/prompts/intention.ts` | 意图语义定义 + subIntents 输出格式 |
| `src/agents/nodes/intention.ts` | 解析 subIntents，写入 currentTask |
| `src/agents/nodes/retrieval.ts` | subIntents 非空时多域检索并集 |
| `src/agents/nodes/reasoning.ts` | subIntents 非空时 prompt 含多子问题 |
| `src/agents/nodes/response.ts` | subIntents 非空时按子域分段输出 |
| `src/app/api/agent/chat/stream/route.ts` | 初始化 GlobalStateProvider + CognitiveEventBus + PolicyUpdateLoop |

### 不修改的文件（兼容性保证）

- `src/agents/nodes/verdict.ts` — 零改动
- `src/agents/nodes/interaction-point-detection.ts` — 零改动
- `src/agents/stream-bus.ts` — SSE 事件通道不变
- `src/agents/response-strategy.ts` — 策略裁决不变
- `src/agents/edges/conditional.ts` — 条件路由不变
- `src/services/path-metrics.ts` — MetricDescriptor 不变
- `src/services/cache-ttl-stats.ts` — TTL 统计不变
- `src/services/analysis-context.ts` — AnalysisContext CRUD 不变
- `src/lib/layer2-callback.ts` — AuditCallback 不变
- `src/services/semantic-cache.ts` — 缓存不变

---

## Impact

- **AgentState 降级**：从孤立状态孤岛变为 GlobalSystemState 的认知子域视图
- **stream-bus 不变**：SSE 事件通道保持现有 10 种事件类型，新事件总线是独立的内部认知层
- **Policy Loop 统一**：前 6-7 轮分散的 TTL/路径质量/turnHistory 反馈合流为单一 PolicyUpdateLoop
- **所有前 7 轮接口向后兼容**
- **Embedded Path Evolution**：不新增节点和路由，subIntents 可选字段嵌入已有管线

---

## ADDED Requirements

### Requirement 1: GlobalSystemState — 统一七域状态模型

#### 1.1 状态域定义

系统状态被抽象为 7 个域：

```typescript
interface GlobalSystemState {
  chat: ChatStateSnapshot        // 当前对话线程状态
  agent: AgentCognitiveSnapshot  // Agent 认知管线状态（AgentState 的投影）
  memory: MemoryStateSnapshot    // RAG / 缓存 / 知识版本状态
  execution: ExecutionStateSnapshot // Tool 调用 / 当前执行节点状态
  policy: PolicyStateSnapshot    // 当前生效的策略参数快照
  audit: AuditStateSnapshot      // L2 审计状态（traceId、当前事件序列）
  feedback: FeedbackStateSnapshot // 运行中采集的反馈信号
  meta: GlobalStateMeta           // 时间戳、版本号等元数据
}
```

每个子域是当前时刻的**不可变快照**（snapshot），不包含 mutate 方法。

#### 1.2 GlobalStateProvider

```typescript
class GlobalStateProvider {
  private snapshot: GlobalSystemState

  constructor(initial?: Partial<GlobalSystemState>)
  
  // 获取当前快照（只读）
  getSnapshot(): Readonly<GlobalSystemState>
  
  // 原子更新一个子域，返回新快照
  updateDomain<K extends keyof GlobalSystemState>(
    domain: K,
    updater: (prev: GlobalSystemState[K]) => GlobalSystemState[K]
  ): Readonly<GlobalSystemState>
  
  // 生成快照 diff（两个快照之间的差异）
  diff(prev: GlobalSystemState, current: GlobalSystemState): StateDiff

  // 从 AgentState 同步认知子域
  syncFromAgentState(agentState: AgentStateType): void
  
  // 从 AnalysisContext 同步记忆/反馈子域
  syncFromAnalysisContext(ctx: AnalysisContext): void
  
  // 从 PolicyUpdateLoop 同步策略子域
  syncFromPolicyState(policy: PolicyStateSnapshot): void
}
```

#### 1.2.1 性能约束

**问题**：6 节点管线中每个节点结束时 `syncFromAgentState()` 被调用，如果每次同步进行 JSON 序列化/反序列化或深拷贝，会产生不必要的 CPU 开销。

**约束**：

```typescript
// syncFromAgentState() 必须是字段投影映射，禁止序列化操作
// ✅ 正确：字段级浅拷贝
syncFromAgentState(agentState: AgentStateType): void {
  this.snapshot.agent = {
    thinkingLevel: agentState.currentTask?.thinkingLevel ?? null,
    intent: agentState.currentTask?.intent ?? null,
    evidenceCount: agentState.evidenceChain?.length ?? 0,
    verdictConfidence: agentState.verdictResult?.confidence?.final_confidence ?? null,
    strategyDescriptorId: state.currentTask?.entities?.strategyDescriptorId ?? null,
  }
}

// ❌ 禁止：JSON.parse/JSON.stringify、structuredClone、深拷贝
```

- `getSnapshot()` 返回 `Readonly<>` 引用，调用方不可修改
- `diff()` 是惰性计算，仅在 PolicyUpdateLoop.evaluate() 调用时执行，不在管线热路径上
- GlobalStateProvider 是请求级单例，请求结束即释放，不存在并发竞争

#### 1.3 StateDiff

```typescript
interface StateDiff {
  domain: keyof GlobalSystemState
  field: string
  prevValue: unknown
  currentValue: unknown
  timestamp: number
}
```

用于后续 Policy Update Loop 做"系统状态发生了什么变化"的归因分析。

#### Scenario: 一次完整的管线执行中状态域同步

- **WHEN** stream/route.ts 收到 POST 请求
- **THEN** 创建 `GlobalStateProvider`，初始化 `chat` / `memory` / `audit` 子域
- **AND WHEN** `streamAgent` 执行完成后返回 AgentState
- **THEN** `syncFromAgentState()` 将 AgentState 投影到 `agent` 认知子域
- **AND WHEN** `saveAnalysisContext()` 完成后
- **THEN** `syncFromAnalysisContext()` 将 AnalysisContext 投影到 `memory` / `feedback` 子域
- **AND WHEN** PolicyUpdateLoop 产出新策略
- **THEN** `syncFromPolicyState()` 更新 `policy` 子域

#### Scenario: AgentState 是 GlobalSystemState 的认知子域

- **WHEN** 读取 `globalState.getSnapshot().agent`
- **THEN** 获得 `AgentCognitiveSnapshot`，包含 `thinkingLevel`、`intent`、`evidenceCount`、`verdictConfidence`、`strategyDescriptorId` 等认知维度
- **AND** `AgentState` 本身仍然是 LangGraph 管线节点的读写状态（不变）
- **AND** `AgentCognitiveSnapshot` 是 AgentState 的只读投影，不可反向写入

#### Scenario: 禁止 AgentState 继续作为孤立状态孤岛扩张

- **WHEN** 未来需要新增状态字段
- **THEN** 必须先判断该字段属于 GlobalSystemState 的哪个子域
- **AND** 如果是全局性状态（如 policy decision result），写入对应的 GlobalSystemState 子域
- **AND** 只有在仅被 LangGraph 节点消费的局部状态（如 `pendingInteraction`），才继续放在 AgentState 中

---

### Requirement 2: Cognitive Event Bus — 认知执行事件中枢

#### 2.1 认知事件类型

```typescript
type CognitiveEvent =
  // 思维阶段
  | { type: "thought:started"; timestamp: number }
  
  // 意图检测
  | { type: "intent:detected"; intent: string; thinkingLevel: ThinkingLevel; timestamp: number }
  
  // 路由决策
  | { type: "route:decided"; from: string; to: string; reason: string; timestamp: number }
  
  // 证据检索
  | { type: "evidence:retrieved"; count: number; filters?: string[]; timestamp: number }
  
  // 推理路径
  | { type: "reasoning:path_generated"; confidence: number; pathLength: number; timestamp: number }
  
  // 策略裁决
  | { type: "strategy:resolved"; descriptorId: string; adjustments: SignalSummary[]; timestamp: number }
  
  // 行动提案
  | { type: "action:proposed"; type: "response" | "interaction" | "tool_call"; detail: string; timestamp: number }
  
  // 反馈观测
  | { type: "feedback:observed"; source: "cache" | "quality" | "user"; metric: string; value: number; timestamp: number }
  
  // 策略更新
  | { type: "policy:updated"; domain: PolicyDomain; reason: string; rollbackSnapshot: string; timestamp: number }
  
  // 系统事件
  | { type: "system:error"; node: string; message: string; timestamp: number }
  | { type: "system:done"; traceId: string; totalDurationMs: number; timestamp: number }
```

#### 2.2 CognitiveEventBus

```typescript
type CognitiveEventHandler = (event: CognitiveEvent) => void

class CognitiveEventBus {
  private handlers: Map<string, Set<CognitiveEventHandler>>

  // 订阅特定事件类型或全部事件（"*" 表示全部）
  subscribe(eventType: CognitiveEvent["type"] | "*", handler: CognitiveEventHandler): () => void
  
  // 发布事件
  emit(event: CognitiveEvent): void
  
  // 获取事件历史（用于事后分析）
  getHistory(): CognitiveEvent[]
  
  // 获取事件时间线（按 type 过滤）
  getTimeline(eventTypes?: CognitiveEvent["type"][]): CognitiveEvent[]
}
```

返回的 `subscribe()` 是一个 `unsubscribe` 函数。

#### 2.2.1 Handler 依赖声明契约

**问题**：PolicyUpdateLoop 等订阅者可能在 `intent:detected` 事件触发时读取 `GlobalStateProvider.getSnapshot()`，但此时 `agent` 子域尚未同步（syncFromAgentState 在节点结束后才执行），导致读取到不完整状态。

**约束**：每个 handler 在注册时必须声明其依赖的子域：

```typescript
interface CognitiveEventHandlerConfig {
  handler: CognitiveEventHandler
  dependsOn?: (keyof GlobalSystemState)[]  // 声明依赖哪些子域已就绪
}
```

- CognitiveEventBus.emit() 在调用 handler 前检查 `dependsOn` 中声明的子域是否已在 GlobalStateProvider 中同步
- 如果子域未就绪，handler 延迟到该子域的就绪事件后执行
- 未声明 `dependsOn` 的 handler 视为无依赖，立即执行

**目的**：以声明式契约替代运行时锁，避免跨模块认知不一致问题。不引入队列或锁机制，保持事件总线的轻量设计。

#### 2.3 与 stream-bus 的关系

- **CognitiveEventBus 是内部认知层**，服务 PolicyUpdateLoop 和内部组件
- **stream-bus 是外部通信层**，服务 SSE 推送给前端
- 两者独立运行，互不耦合
- 不要求每个 CognitiveEvent 都转化为 StreamEvent
- 可选的 `bridge` 函数将关键认知事件桥接到 SSE（如 `strategy:resolved` → `strategy_adjustment` StreamEvent）

#### Scenario: 管线执行中的认知事件流

- **WHEN** 执行一次完整的 deep 管线
- **THEN** CognitiveEventBus 按顺序 emit：`thought:started` → `intent:detected` → `route:decided` → `evidence:retrieved` → `reasoning:path_generated` → `strategy:resolved` → `action:proposed` → `system:done`
- **AND** 每个事件的 timestamp 单调递增
- **AND** `getTimeline()` 可还原完整认知事件链

#### Scenario: Policy Update Loop 订阅反馈事件

- **WHEN** PolicyUpdateLoop 初始化
- **THEN** 它通过 `eventBus.subscribe("feedback:observed", handler)` 订阅反馈事件
- **AND** 当缓存命中/过期/质量评估完成后，emit `feedback:observed` 事件
- **AND** PolicyUpdateLoop 收集足够的反馈事件后触发 `adaptPolicy()`

#### Scenario: 禁止把 CognitiveEventBus 当日志管道

- **WHEN** 需要记录调试信息
- **THEN** 使用 console / L1 debug-tracer / AuditLog，不得 emit CognitiveEvent
- **AND** CognitiveEvent 只表达"认知层面发生了什么"，不是"系统打了什么日志"

---

### Requirement 3: Policy Update Loop — 可解释策略更新闭环

#### 3.1 PolicyUpdateRecord

```typescript
type PolicyDomain = "cache_ttl" | "response_prompt_hint" | "expert_activation" | "evidence_filter"

interface PolicyUpdateRecord {
  id: string                        // 唯一标识
  domain: PolicyDomain              // 受影响的策略域
  inputMetrics: Record<string, unknown>  // 触发更新的输入指标
  decisionReason: string            // 为什么做这个决策（人类可读）
  affectedPolicy: {                 // 更新内容
    before: Record<string, unknown>
    after: Record<string, unknown>
  }
  rollbackData: {                   // 回滚所需数据
    previousState: Record<string, unknown>
    restorationQuery: string        // 如 "DELETE FROM PolicyState WHERE id=xxx"
  }
  confidence: number                // 决策本身的可信度 (0-100)
  sourceEvents: CogEventRef[]       // 引用的认知事件 ID 列表
  timestamp: number
  applied: boolean                  // 是否已生效
}
```

#### 3.2 PolicyUpdateLoop

```typescript
class PolicyUpdateLoop {
  private eventBus: CognitiveEventBus
  private stateProvider: GlobalStateProvider
  private history: PolicyUpdateRecord[]

  constructor(eventBus: CognitiveEventBus, stateProvider: GlobalStateProvider)
  
  // 消费反馈事件，检查是否需要策略调整
  async evaluate(): Promise<PolicyUpdateRecord | null>
  
  // 应用策略更新
  async apply(record: PolicyUpdateRecord): Promise<void>
  
  // 回滚策略更新
  async rollback(recordId: string): Promise<void>
  
  // 获取策略更新历史
  getHistory(domain?: PolicyDomain): PolicyUpdateRecord[]
  
  // 订阅事件总线（内部调用）
  private subscribeToEvents(): void
}
```

#### 3.3 策略决策函数（四个独立函数）

```typescript
// 决策函数 1: 缓存 TTL 调整
function evaluateCacheTtl(
  ttlStats: TtlStats,
  recentFeedback: CogEventRef[]
): PolicyUpdateRecord | null

// 决策函数 2: Response PromptHint 调整
function evaluatePromptHint(
  pathMetrics: StrategyAdjustment,
  turnHistory: AnalysisTurnRecord[]
): PolicyUpdateRecord | null

// 决策函数 3: 专家激活建议
function evaluateExpertActivation(
  turnHistory: AnalysisTurnRecord[],
  metricBaselines: MetricBaselines
): PolicyUpdateRecord | null

// 决策函数 4: Evidence Filter 松弛
function evaluateEvidenceFilter(
  turnHistory: AnalysisTurnRecord[],
  metricBaselines: MetricBaselines
): PolicyUpdateRecord | null
```

每个决策函数是纯函数：输入数据 → 输出 `PolicyUpdateRecord | null`（null 表示不需调整）。

#### 3.3.1 安全约束（防止自主演化失控）

**问题**：纯函数不保证输出安全——相同的输入产生相同的输出，但输出可能会将系统参数推向恶性循环（如级联放大导致 promptHint 权重失控）。四个决策函数必须有硬性安全边界。

**约束 1 — 变化幅度上限**：每个 PolicyDomain 的单次调整幅度有硬上限：

| PolicyDomain | 最大单次调整幅度 | 允许范围 |
|-------------|:---:|---------|
| `cache_ttl` | ±30% | [1min, 60min] |
| `response_prompt_hint` | ±10%（权重偏移） | 不覆盖原 prompt，只追加 hint |
| `expert_activation` | 只增加不取消 | 累积激活，不自动卸载 |
| `evidence_filter` | 只放宽不收紧 | evidenceFilter 只做 OR 扩展 |

**约束 2 — 冷却期**：同一 PolicyDomain 两次调整之间最少间隔 5 轮（避免连续微调偏离基线）。

**约束 3 — 置信度硬门槛**：`PolicyUpdateRecord.confidence >= 70` 才允许 `apply()`。低于门槛的记录只存档（`applied = false`），供开发者审查后手动应用。

**约束 4 — 自动回滚**：`apply()` 后，PolicyUpdateLoop 持续观测 `sourceEvents` 中的指标类型。如果 N 轮（默认 5 轮）后指标未改善（如置信度未回升），自动执行 `rollback()`。回滚记录写入新 PolicyUpdateRecord（`domain` 同原记录，`decisionReason` 标注"自动回滚：指标未改善"）。

**约束 5 — 决策理由可读性**：`decisionReason` 必须包含"触发阈值 → 当前值 → 调整方向 → 预期效果"四段式描述。不得出现 `"auto-adjust"` 等无信息量理由。

#### Scenario: TTL 自主学习闭环统一

- **WHEN** 同场景 3 次缓存过期后结论相同（±5%）
- **THEN** `evaluateCacheTtl()` 产出 `PolicyUpdateRecord`，`domain=cache_ttl`，TTL 上调 20%
- **AND** `apply()` 将更新后的 TTL 写入 `cache-ttl-stats` 的 `adaptedTtl`
- **AND** `PolicyUpdateRecord` 含完整 `rollbackData` 和 `decisionReason`

#### Scenario: 路径质量下降触发策略调整

- **WHEN** 连续 5 轮置信度线性回归 β < -3
- **THEN** `evaluatePromptHint()` 产出 `PolicyUpdateRecord`，`domain=response_prompt_hint`
- **AND** promptHint 追加"信息可能存在缺口，建议扩大检索范围"
- **AND** `decisionReason` 记录 β 值、样本轮次、触发阈值

#### Scenario: 策略更新可回滚

- **WHEN** `rollback(recordId)` 被调用
- **THEN** 使用 `rollbackData.previousState` 恢复策略参数
- **AND** `rollbackData.restorationQuery` 提供管理员直接 SQL 回滚路径
- **AND** `PolicyUpdateRecord.applied` 设置为 false

#### Scenario: 无足够信号时不强行更新

- **WHEN** `evaluate()` 被调用但所有 decision 函数返回 null
- **THEN** `evaluate()` 返回 null，不做任何策略变更
- **AND** 这不应该视为错误——没有信号就是不需要调整

---

### Requirement 4: Embedded Path Evolution — 嵌入式路径演化

遵循 [嵌入式路径演化策略](file:///home/xmm/ai/farm-agent/docs/哲学理论/4.嵌入式路径演化策略.md) 的方法论：不替换系统、不新增节点、不新增路由，在已有的 `intention → retrieval → reasoning → response` 路径上施加最小结构偏移，使管线能处理跨域多意图问题。

#### 4.1 SubIntent 类型

```typescript
interface SubIntent {
  domain: string     // 子意图域标识，如 "crop_compare" / "pest_risk"
  subQuery: string   // 该域对应的具体问题
}
```

`CurrentTask` 新增可选字段 `subIntents?: SubIntent[]`。单域问题不产出此字段。

#### 4.2 Intention Prompt 重构 — 意图语义定义

当前 intention prompt 将 7 个标签订阅给 LLM，LLM 靠常识推断含义。本轮在 prompt 中补充以下语义定义（三句话格式）：

| 意图 | 含义 | thinkingLevel |
|------|------|:---:|
| `chat` | 日常闲聊、寒暄问候、不涉及农业专业分析的对话 | fast |
| `question` | 事实性问答，有明确答案，不需要深度推理或多因素权衡 | deep |
| `analysis` | 多因素分析、农情研判，需要证据链支撑的综合判断 | deep |
| `planning` | 制定计划、任务排期、资源分配方案 | deep |
| `decision` | 多个方案之间的最优选择，需要权衡利弊 | deep |
| `creation` | 新建实体（任务/项目/文档/配置），不是修改已有的 | deep |
| `modification` | 修改、更新、调整已有实体的属性或状态 | deep |

**跨域判定规则**：当用户问题包含两个或以上意图域的要素时，`intent` 取占比最大的域，其他域拆解为 `subIntents[{ domain, subQuery }]`。

**跨轮指代消解**：intention prompt 必须注入上一轮上下文摘要（来自 `AnalysisContext.turnHistory` 最后一条记录 + `CurrentTask.subIntents`），使 LLM 能正确解析"那"、"它"等指代词：

```
[上一轮上下文]
主要意图：analysis | 活跃专家：crop_compare, roi_analysis
关键实体：某地块(XX省YY县) | 玉米品种(ZZ) | 大豆品种(WW)
子意图产出：
  - crop_compare: 该地块玉米 vs 大豆品种对比结论
  - roi_analysis: 玉米预期收益XXX vs 大豆预期收益YYY

[当前用户消息]
那虫害风险呢
```

**subIntents 粒度边界 — 独立可回答标准**：仅当要素能独立构成一个有意义的回答时，才拆解为 subIntent。判定规则：

| 要素类型 | 示例 | 处理方式 |
|---------|------|---------|
| 独立子问题 | "虫害风险多大" → 可独立回答 | 拆为 subIntent |
| 约束条件 | "预算有限" → 不能独立回答 | 注入对应域 prompt 作为约束 |
| 背景事实 | "去年闹过虫" → 不能独立回答 | 注入对应域 evidenceFilter |

**意图 prompt 中的判定指令**：

```
对于用户消息中的每个域要素，判断：
1. 该要素是否可以独立构成一个有意义的问答？（是 → subIntent）
2. 该要素是否只是影响其他子问题的条件/约束/背景？（是 → 不拆，注入对应域上下文）
```

示例：
```json
// "这片地种玉米还是大豆，虫害风险分别多大"
// → crop_compare 和 pest_risk 都是独立可回答的问题
{
  "intent": "analysis",
  "subIntents": [
    { "domain": "crop_compare", "subQuery": "玉米 vs 大豆品种对比" },
    { "domain": "pest_risk", "subQuery": "虫害风险评估" }
  ]
}

// "种玉米还是大豆，预算有限" 
// → "预算有限"不是独立问题，是 crop_compare 的约束条件 → 单域
{
  "intent": "analysis",
  "constraints": ["预算有限"]
  // 无 subIntents —— 约束条件注入 reasoning prompt，不拆子域
}

// "去年闹过虫，今年种什么好"
// → "去年闹过虫"是背景事实，影响 pest_risk 评估 → 注入 evidenceFilter
// → "今年种什么好"是 crop_compare
{
  "intent": "analysis",
  "subIntents": [
    { "domain": "crop_compare", "subQuery": "今年种什么作物" }
  ],
  "contextHints": [
    { "type": "history", "domain": "pest_risk", "fact": "去年虫害历史" }
  ]
}
```

#### 4.2.1 拆解决策的结构化跨轮传递 (previousSubIntents)

**问题**：当前 intentionNode 每轮独立判断，不知道上一轮自己拆了哪些域、哪些已解答、哪些待跟进。拆解决策本身（subIntents 结构）没有跨轮传递——下一轮 intentionNode 看到的只有对话文本，看不到 Turn 1 的 `{ subIntents: [crop_compare, pest_risk] }` 这个结构化字段。

**方案**：在 `AnalysisContext.turnHistory` 中结构化存储每轮的拆解决策，而非仅依赖 intention prompt 中的自然语言摘要。

```typescript
// AnalysisTurnRecord 新增字段
interface AnalysisTurnRecord {
  // ... 已有字段
  previousSubIntents?: Array<{
    domain: string       // 域标识
    subQuery: string     // 该域的具体问题
    resolved: boolean    // 本轮是否已解答（用于跨轮待跟进判断）
  }>
}
```

**效果**：
- Turn 2 的 intentionNode 能显式看到 Turn 1 拆了 `[crop_compare(resolved), pest_risk(resolved)]`
- 如果 Turn 2 追问"那 ROI 呢"，intentionNode 知道 ROI 未被拆解过 → 新域，非追问
- 如果 Turn 2 追问"虫害有什么具体防治措施"，intentionNode 知道 pest_risk 已解答 → 追加细节，非重新激活
- 自然语言摘要 + 结构化字段**双通道传递**，互相验证

#### 4.2.2 拆解粒度与注册表的语义边界不对齐

**问题**：subIntents 的拆解依据是 `ANALYSIS_EXPERTS` 注册表的 key 集合，但用户的语义边界不按注册表走。例如用户直觉里"收益"是"对比"的一部分，但 `roi_analysis` 是独立 expert。LLM 需要在"用户语义"和"注册表结构"之间做一次翻译。

**约束**：intention prompt 必须明确告知 LLM 可用的 expert domain 列表及其职责范围，使 LLM 在拆解时知道"ROI 是一个独立可激活的能力域"而非"对比的子项"。这是 Expert Grounding 在意图阶段的前置语义锚定。

#### 4.3 管线增强（4 个节点的嵌入式演化）

**retrieval**：当 `subIntents` 非空时，取所有 `subIntents[].subQuery` 的检索结果并集。搜索次数不变（仍是 1 次 `searchKnowledgeDocuments`），但搜索查询覆盖所有子域。

**reasoning**：当 `subIntents` 非空时，prompt 携带多子问题，LLM 在一个推理过程中分别回应。不增加 LLM 调用次数。

**response**：当 `subIntents` 非空时，`structuredResponse` 按子域分段输出，每个子域对应一个 section 块。

**response 跨域共享背景保留约束**：分域输出时，每个子域 section 必须携带被多个域共享的背景数据（如地块位置、当前墒情、气象条件），不得因分段而裁剪。这防止"Rich context loss at sub-domain boundary"——Turn 2 追问某个子域细节时，intentionNode 从 turnHistory 提取的上一轮上下文不残缺。

**interactionPointDetection**：不直接改动，但 turnHistory 通过 GlobalSystemState 获得跨轮多域视角，后续轮次可让交互点检测到"用户在过去 N 轮涉及了多个域"。

#### 4.4 CognitiveEvent 扩展

```typescript
type CognitiveEvent =
  // ... 已有事件类型
  | { type: "subIntent:detected"; subIntents: SubIntent[]; primaryIntent: string; timestamp: number }
  | { type: "subIntent:resolved"; domain: string; sectionCount: number; timestamp: number }
```

PolicyUpdateLoop 后续可根据 `subIntent:detected` 频率调整策略（如多域问题比例超过阈值时调整 promptHint）。

#### Scenario: 跨域问题被正确处理

- **WHEN** 用户问"这片地种玉米还是大豆，虫害风险分别多大"
- **THEN** intention 产出 `{ intent: "analysis", subIntents: [{ domain: "crop_compare", ... }, { domain: "pest_risk", ... }] }`
- **AND** retrieval 检索两个域的并集
- **AND** reasoning 在一个 prompt 中回应两个子问题
- **AND** response 输出包含【作物对比】和【虫害风险】两个分段
- **AND** CognitiveEventBus emit `subIntent:detected`

#### Scenario: 单域问题行为不变

- **WHEN** 用户问"水稻育秧分哪几个步骤"
- **THEN** `subIntents` 为空
- **AND** 管线行为与第 1-7 轮完全一致

#### Scenario: 禁止新增节点和路由

- **WHEN** 尝试为多域问题新增节点（如 fork/join）或条件边（如 routeBySubIntents）
- **THEN** 违反嵌入式路径演化原则——subIntents 只能在已有节点内部增强，不能改变管线拓扑

#### Scenario: 跨轮 subIntents 参考

- **WHEN** Turn 1 产出 `subIntents: [{ domain: "crop_compare", ... }, { domain: "pest_risk", ... }]`，两个域均已解答
- **AND WHEN** Turn 2 用户追问"那 ROI 方面呢"
- **THEN** intentionNode 从 `AnalysisContext.turnHistory[last].previousSubIntents` 读取 Turn 1 已拆解的域列表
- **AND** 判断 ROI 不在 `[crop_compare(resolved), pest_risk(resolved)]` 中 → 新域，非追问
- **AND** 本次产出 `subIntents: [{ domain: "roi_analysis", ... }]`，追加到本轮 `previousSubIntents`
- **AND** 自然语言摘要和结构化字段同时传递，互相验证

#### Scenario: 依赖型 subIntents 不在本轮范围

- **WHEN** 用户问"基于虫害风险来决策种玉米还是大豆"
- **THEN** pest_risk 是 crop_compare 的前置输入 → 依赖型 subIntents
- **AND** 当前管线为单次串行，不支持子问题间的拓扑排序
- **AND** 系统 fallback 为单域处理（intent: analysis，prompt 中说明需同时考虑虫害和品种）
- **AND** 依赖型 subIntents 保留给后续 L4 多路径竞争执行

---

## Non-Requirements (本轮不做)

- ❌ 不新增管线节点和路由（subIntents 是节点内部增强，不改变拓扑）
- ❌ 不引入 WorldLine 权重策略引擎、模型钩子、多路径竞争执行
- ❌ 不修改 Prisma Schema
- ❌ 不修改前端组件
- ❌ 不把 CognitiveEventBus 替换 stream-bus（两者共存）
- ❌ 不把 AgentState 从 LangGraph Annotation 迁移出去（只做投影映射，不做迁移）
- ❌ 不处理依赖型 subIntents（子问题间有拓扑依赖，如"基于虫害风险来决策种什么"中 pest_risk → crop_compare 的依赖链），当前管线为单次串行，不支持子问题间的拓扑排序。依赖型场景保留给后续 L4 多路径竞争执行
