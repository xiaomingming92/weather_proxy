# Checklist — 第8轮 架构合流闭包

## Phase 1: GlobalSystemState — 统一七域状态模型

- [ ] 1.1 `src/agents/global-state.ts` 存在且导出 `GlobalSystemState` 接口
- [ ] 1.2 `GlobalSystemState` 含 7 个子域（chat / agent / memory / execution / policy / audit / feedback）+ meta
- [ ] 1.3 `GlobalStateProvider` 类存在，含 `getSnapshot()` / `updateDomain()` / `diff()` 方法
- [ ] 1.4 `syncFromAgentState(agentState)` 可将 AgentState 投影为 AgentCognitiveSnapshot
- [ ] 1.5 `syncFromAnalysisContext(ctx)` 可将 AnalysisContext 投影为 MemoryStateSnapshot + FeedbackStateSnapshot
- [ ] 1.6 `syncFromPolicyState(policy)` 可更新 PolicyStateSnapshot
- [ ] 1.7 `diff(prev, current)` 返回 `StateDiff[]`（domain + field + prevValue + currentValue + timestamp）
- [ ] 1.8 `src/agents/state.ts` 导出 `agentStateToCognitiveSnapshot(agentState)` 函数
- [ ] 1.9 `src/agents/index.ts` `streamAgent` 入参含可选 `globalStateProvider`，完成后调用 `syncFromAgentState`
- [ ] 1.10 未传入 `globalStateProvider` 时 `streamAgent` 行为不变（向后兼容）
- [ ] 1.11 `npx tsc --noEmit` 零类型错误（global-state.ts + state.ts + index.ts）
- [ ] 1.12 `AgentCognitiveSnapshot` 含 thinkingLevel / intent / evidenceCount / verdictConfidence / strategyDescriptorId 字段

## Phase 2: Cognitive Event Bus — 认知执行事件中枢

- [ ] 2.1 `src/agents/cognitive-event-bus.ts` 存在且导出 `CognitiveEvent` 类型
- [ ] 2.2 `CognitiveEvent` 联合类型含 11 种事件（thought:started / intent:detected / route:decided / evidence:retrieved / reasoning:path_generated / strategy:resolved / action:proposed / feedback:observed / policy:updated / system:error / system:done）
- [ ] 2.3 `CognitiveEventBus` 类存在，含 `subscribe()` / `emit()` / `getHistory()` / `getTimeline()` 方法
- [ ] 2.4 `subscribe("*", handler)` 可订阅全部事件
- [ ] 2.5 `subscribe()` 返回 `unsubscribe` 函数，调用后不再接收事件
- [ ] 2.6 `src/agents/index.ts` `streamAgent` 入参含可选 `eventBus`，管线中在各节点边界 emit 认知事件
- [ ] 2.7 deep 管线执行后 `getTimeline()` 包含按顺序的 thought:started → intent:detected → route:decided → evidence:retrieved → reasoning:path_generated → strategy:resolved → action:proposed → system:done
- [ ] 2.8 fast 管线执行后 `getTimeline()` 包含 thought:started → intent:detected → route:decided → action:proposed → system:done
- [ ] 2.9 未传入 `eventBus` 时 `streamAgent` 行为不变（零开销）
- [ ] 2.10 `src/app/api/agent/chat/stream/route.ts` 中创建 `CognitiveEventBus` 并传入 `streamAgent()`
- [ ] 2.11 管线异常时 `system:error` 事件被 emit
- [ ] 2.12 `CognitiveEventBus` 与 `stream-bus.ts` 无耦合（独立 import，互不引用）
- [ ] 2.13 `npx tsc --noEmit` 零类型错误（cognitive-event-bus.ts + index.ts + stream/route.ts）

## Phase 3: Policy Update Loop — 可解释策略更新闭环

- [ ] 3.1 `src/agents/policy-update-loop.ts` 存在且导出 `PolicyDomain` / `PolicyUpdateRecord` / `PolicyUpdateLoop`
- [ ] 3.2 `PolicyDomain` 含 4 个域（cache_ttl / response_prompt_hint / expert_activation / evidence_filter）
- [ ] 3.3 `PolicyUpdateRecord` 含 id / domain / inputMetrics / decisionReason / affectedPolicy / rollbackData / confidence / sourceEvents / timestamp / applied
- [ ] 3.4 `PolicyUpdateRecord.rollbackData` 含 previousState 和 restorationQuery
- [ ] 3.5 `PolicyUpdateLoop` 类含 `evaluate()` / `apply()` / `rollback()` / `getHistory()` 方法
- [ ] 3.6 `evaluateCacheTtl()` 纯函数存在：输入 TtlStats + 反馈事件 → PolicyUpdateRecord | null
- [ ] 3.7 `evaluatePromptHint()` 纯函数存在：输入 StrategyAdjustment + turnHistory → PolicyUpdateRecord | null
- [ ] 3.8 `evaluateExpertActivation()` 纯函数存在：输入 turnHistory + baselines → PolicyUpdateRecord | null
- [ ] 3.9 `evaluateEvidenceFilter()` 纯函数存在：输入 turnHistory + baselines → PolicyUpdateRecord | null
- [ ] 3.10 `evaluate()` 聚合四个决策函数，任一非 null 时产出 `policy:updated` 事件
- [ ] 3.11 所有决策函数返回 null 时 `evaluate()` 返回 null（不强更新）
- [ ] 3.12 `apply()` 将 PolicyUpdateRecord.applied 置为 true
- [ ] 3.13 `rollback(recordId)` 恢复 `previousState`，将 applied 置为 false
- [ ] 3.14 `src/app/api/agent/chat/stream/route.ts` 中创建 `PolicyUpdateLoop` 并 fire-and-forget `evaluate()`
- [ ] 3.15 PolicyUpdateLoop 不阻塞 chat 响应（fire-and-forget，.catch 兜底）
- [ ] 3.16 `PolicyUpdateRecord` 中 `decisionReason` 为人类可读的中文说明
- [ ] 3.17 `npx tsc --noEmit` 零类型错误（policy-update-loop.ts + stream/route.ts）

## Phase 4: Embedded Path Evolution — 嵌入式路径演化

- [ ] 4.1 `SubIntent` 接口已定义（domain + subQuery）
- [ ] 4.2 `CurrentTask` 含可选字段 `subIntents?: SubIntent[]`
- [ ] 4.3 `src/agents/prompts/intention.ts` 含 7 个意图的语义定义
- [ ] 4.4 `src/agents/prompts/intention.ts` 含跨域判定规则和 subIntents 输出格式
- [ ] 4.5 `intentionNode()` 解析 LLM 输出时提取 `subIntents` 并写入 `currentTask`
- [ ] 4.6 `retrievalNode()` 当 subIntents 非空时多域检索，搜索次数不增加
- [ ] 4.7 `reasoningNode()` 当 subIntents 非空时 prompt 含多子问题，不增加 LLM 调用次数
- [ ] 4.8 `responseNode()` 当 subIntents 非空时按子域分段输出
- [ ] 4.9 subIntents 为空时所有节点行为与第 1-7 轮完全一致（向后兼容）
- [ ] 4.10 CognitiveEventBus 含 `subIntent:detected` 事件类型
- [ ] 4.11 CognitiveEventBus 含 `subIntent:resolved` 事件类型
- [ ] 4.12 没有新增管线节点或条件边（subIntents 不改变管线拓扑）
- [ ] 4.13 `npx tsc --noEmit` 零类型错误

## 全局验证

- [ ] 5.1 `npx tsc --noEmit` 全局零新增类型错误（允许历史基线错误但不增加）
- [ ] 5.2 第1-7轮关键状态均能映射到 GlobalSystemState 子域
- [ ] 5.3 Cognitive Event Bus 可表达 Thought → Decision → Action → Feedback → PolicyUpdate 事件链
- [ ] 5.4 PolicyUpdateRecord 含 input metrics / decision reason / affected policy / rollback data
- [ ] 5.5 修改文件：新增 3 个文件 + 修改 8 个文件，verdict.ts / interactionPointDetection.ts / stream-bus.ts / response-strategy.ts / conditional.ts 零改动
- [ ] 5.6 GlobalStateProvider + CognitiveEventBus + PolicyUpdateLoop 在未传入时全部可选（向后兼容）

## ADD 规则合规检查

- [ ] ADD-0.1 文档先行：spec / tasks / checklist 已完成，架构文档待 Step 0 更新
- [ ] ADD-1 可观测性优先：GlobalStateProvider.diff() + CognitiveEventBus.getHistory() + PolicyUpdateRecord 可追溯
- [ ] ADD-2 阶段标记对称：CognitiveEventBus 按 thought:started → system:done 成对事件
- [ ] ADD-3 最小可观测单元：每条 CognitiveEvent 带 timestamp + type，可独立检索
- [ ] ADD-4 三通道输出：CognitiveEventBus events 通过 L2 AuditCallback 写入 AuditLog 表
- [ ] ADD-5 审计数据即业务数据：PolicyUpdateRecord 含完整 decisionReason + rollbackData
- [ ] ADD-6 失败路径等价审计：`system:error` 事件包含 node + message，与 `system:done` 信息密度等价
- [ ] ADD-7 开发操作审计：每完成一个文件修改调用 `record_dev_operation` + `query_audit_logs` 回查
- [ ] Plan/Spec 一致性：代码实现与 spec.md 中定义一致
- [ ] Plan/Spec 修订记录：如有修订已记录审计日志
