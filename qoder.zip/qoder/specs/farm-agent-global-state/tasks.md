# Tasks — 第8轮 架构合流闭包

## Phase 1: GlobalSystemState — 统一七域状态模型

- [ ] Task 1.1: 创建 `src/agents/global-state.ts`，定义所有子域快照类型和 GlobalSystemState
  - [ ] SubTask 1.1.1: 定义 `ChatStateSnapshot`、`AgentCognitiveSnapshot`、`MemoryStateSnapshot`、`ExecutionStateSnapshot`、`PolicyStateSnapshot`、`AuditStateSnapshot`、`FeedbackStateSnapshot`、`GlobalStateMeta`
  - [ ] SubTask 1.1.2: 定义 `GlobalSystemState` 接口（组合 7 子域 + meta）
  - [ ] SubTask 1.1.3: 定义 `StateDiff` 接口
  - [ ] SubTask 1.1.4: 实现 `GlobalStateProvider` 类（构造器 + `getSnapshot()` + `updateDomain()` + `diff()`）

- [ ] Task 1.2: 实现 GlobalStateProvider 的同步方法
  - [ ] SubTask 1.2.1: 实现 `syncFromAgentState(agentState)` — AgentState → AgentCognitiveSnapshot 投影
  - [ ] SubTask 1.2.2: 实现 `syncFromAnalysisContext(ctx)` — AnalysisContext → MemoryStateSnapshot + FeedbackStateSnapshot 投影
  - [ ] SubTask 1.2.3: 实现 `syncFromPolicyState(policy)` — PolicyStateSnapshot 更新

- [ ] Task 1.3: 修改 `src/agents/state.ts`，导出认知子域投影函数
  - [ ] SubTask 1.3.1: 新增 `agentStateToCognitiveSnapshot(agentState: AgentStateType): AgentCognitiveSnapshot` 函数
  - [ ] SubTask 1.3.2: 导出此函数供 `global-state.ts` 的 `syncFromAgentState` 调用

- [ ] Task 1.4: 修改 `src/agents/index.ts`，管线中接入 GlobalStateProvider
  - [ ] SubTask 1.4.1: `streamAgent` 入参新增 `globalStateProvider?: GlobalStateProvider`
  - [ ] SubTask 1.4.2: 在 `streamAgent` 返回前调用 `syncFromAgentState(finalState)`
  - [ ] SubTask 1.4.3: 保持 `globalStateProvider` 为可选参数，不传时行为不变（向后兼容）

## Phase 2: Cognitive Event Bus — 认知执行事件中枢

- [ ] Task 2.1: 创建 `src/agents/cognitive-event-bus.ts`，定义认知事件类型和事件总线
  - [ ] SubTask 2.1.1: 定义 `CognitiveEvent` 联合类型（11 种事件：thought:started / intent:detected / route:decided / evidence:retrieved / reasoning:path_generated / strategy:resolved / action:proposed / feedback:observed / policy:updated / system:error / system:done）
  - [ ] SubTask 2.1.2: 定义 `SignalSummary` 类型（策略裁决的 adjustment 信号摘要）
  - [ ] SubTask 2.1.3: 实现 `CognitiveEventBus` 类（`subscribe` + `emit` + `getHistory` + `getTimeline`）
  - [ ] SubTask 2.1.4: `subscribe()` 支持 `"*"` 通配符订阅全部事件；返回 `unsubscribe` 函数

- [ ] Task 2.2: 修改 `src/agents/index.ts`，在各节点边界 emit 认知事件
  - [ ] SubTask 2.2.1: `streamAgent` 入参新增 `eventBus?: CognitiveEventBus`
  - [ ] SubTask 2.2.2: 在 intention 节点完成后 emit `intent:detected` + `route:decided`
  - [ ] SubTask 2.2.3: 在 retrieval 节点完成后 emit `evidence:retrieved`
  - [ ] SubTask 2.2.4: 在 reasoning 节点完成后 emit `reasoning:path_generated`
  - [ ] SubTask 2.2.5: 在 response 节点 `resolveResponseStrategy()` 后 emit `strategy:resolved`
  - [ ] SubTask 2.2.6: 在 response 节点完成后 emit `action:proposed`
  - [ ] SubTask 2.2.7: 在管线开始时 emit `thought:started`，完成时 emit `system:done`，异常时 emit `system:error`
  - [ ] SubTask 2.2.8: 保持 `eventBus` 为可选参数，未传入时节点行为不变（零开销）

- [ ] Task 2.3: 修改 `src/app/api/agent/chat/stream/route.ts`，请求级初始化 CognitiveEventBus
  - [ ] SubTask 2.3.1: 在 POST handler 中创建 `CognitiveEventBus` 实例
  - [ ] SubTask 2.3.2: 将 `eventBus` 传入 `streamAgent()` 调用
  - [ ] SubTask 2.3.3: 管线完成后将 CognitiveEventBus 的事件历史记录到 L2 AuditLog（可选：仅记录关键事件类型）
  - [ ] SubTask 2.3.4: 异常路径中 emit `system:error` 到 eventBus

## Phase 3: Policy Update Loop — 可解释策略更新闭环

- [ ] Task 3.1: 创建 `src/agents/policy-update-loop.ts`，定义类型和决策函数
  - [ ] SubTask 3.1.1: 定义 `PolicyDomain` 类型（"cache_ttl" | "response_prompt_hint" | "expert_activation" | "evidence_filter"）
  - [ ] SubTask 3.1.2: 定义 `PolicyUpdateRecord` 接口（id/domain/inputMetrics/decisionReason/affectedPolicy/rollbackData/confidence/sourceEvents/timestamp/applied）
  - [ ] SubTask 3.1.3: 定义 `CogEventRef` 类型（{ eventType, timestamp } 用于追溯）

- [ ] Task 3.2: 实现 PolicyUpdateLoop 类和四个纯决策函数
  - [ ] SubTask 3.2.1: 实现 `evaluateCacheTtl(ttlStats, recentFeedback)` — 输入 TtlStats + 反馈事件 → PolicyUpdateRecord | null
  - [ ] SubTask 3.2.2: 实现 `evaluatePromptHint(pathMetrics, turnHistory)` — 输入 StrategyAdjustment + turnHistory → PolicyUpdateRecord | null
  - [ ] SubTask 3.2.3: 实现 `evaluateExpertActivation(turnHistory, metricBaselines)` — 输入 turnHistory + baselines → PolicyUpdateRecord | null
  - [ ] SubTask 3.2.4: 实现 `evaluateEvidenceFilter(turnHistory, metricBaselines)` — 输入 turnHistory + baselines → PolicyUpdateRecord | null
  - [ ] SubTask 3.2.5: 实现 `PolicyUpdateLoop` 类（构造器 + `evaluate()` + `apply()` + `rollback()` + `getHistory()` + `subscribeToEvents()`）

- [ ] Task 3.3: PolicyUpdateLoop.evaluate() 聚合四个决策函数
  - [ ] SubTask 3.3.1: `evaluate()` 依次调用 4 个 evaluate 函数
  - [ ] SubTask 3.3.2: 只要任一函数返回非 null，生成 `policy:updated` CognitiveEvent
  - [ ] SubTask 3.3.3: 所有函数返回 null → `evaluate()` 返回 null

- [ ] Task 3.4: 修改 `src/app/api/agent/chat/stream/route.ts`，管线结束后触发 PolicyUpdateLoop
  - [ ] SubTask 3.4.1: 在 POST handler 中创建 `PolicyUpdateLoop` 实例（传入 eventBus 和 stateProvider）
  - [ ] SubTask 3.4.2: 在 `responseNode` 完成后、`done` 事件前，fire-and-forget 调用 `policyLoop.evaluate()`
  - [ ] SubTask 3.4.3: 对于返回的 `PolicyUpdateRecord`，调用 `policyLoop.apply(record)` 使其生效
  - [ ] SubTask 3.4.4: apply 后 emit `policy:updated` CognitiveEvent

## Phase 4: Embedded Path Evolution — 嵌入式路径演化

- [ ] Task 4.1: 定义 `SubIntent` 类型并扩展 `CurrentTask`
  - [ ] SubTask 4.1.1: 定义 `SubIntent` 接口（domain + subQuery）
  - [ ] SubTask 4.1.2: `CurrentTask` 接口新增可选字段 `subIntents?: SubIntent[]`
  - [ ] SubTask 4.1.3: `AgentState` 中 `currentTask` 字段自动包含此可选字段

- [ ] Task 4.2: 重构 `src/agents/prompts/intention.ts` — 意图语义定义 + subIntents 输出
  - [ ] SubTask 4.2.1: 在 prompt 中补充 7 个意图的三句话语义定义（chat / question / analysis / planning / decision / creation / modification）
  - [ ] SubTask 4.2.2: 在 prompt 中补充跨域判定规则和 subIntents 输出格式
  - [ ] SubTask 4.2.3: prompt 输出格式新增 `subIntents` 字段（JSON array）
  - [ ] SubTask 4.2.4: 保留原有 prompt 结构，不改变 thinkingLevel 判定逻辑

- [ ] Task 4.3: 修改 `src/agents/nodes/intention.ts` — 解析 subIntents
  - [ ] SubTask 4.3.1: `intentionNode()` 解析 LLM 输出时提取 `subIntents` 字段
  - [ ] SubTask 4.3.2: `subIntents` 写入 `currentTask.subIntents`
  - [ ] SubTask 4.3.3: `subIntents` 为空时行为与原有完全一致

- [ ] Task 4.4: 修改 `src/agents/nodes/retrieval.ts` — 多域检索增强
  - [ ] SubTask 4.4.1: 当 `currentTask.subIntents` 非空时，合并所有 `subQuery` 为搜索查询
  - [ ] SubTask 4.4.2: 调用 `searchKnowledgeDocuments()` 一次，查询覆盖全部子域
  - [ ] SubTask 4.4.3: subIntents 为空时走原有检索逻辑

- [ ] Task 4.5: 修改 `src/agents/nodes/reasoning.ts` — 多子问题推理
  - [ ] SubTask 4.5.1: 当 `currentTask.subIntents` 非空时，prompt 中包含所有子问题
  - [ ] SubTask 4.5.2: 不增加 LLM 调用次数（仍是一次调用，prompt 更丰富）
  - [ ] SubTask 4.5.3: subIntents 为空时走原有 reasoning 逻辑

- [ ] Task 4.6: 修改 `src/agents/nodes/response.ts` — 按子域分段输出
  - [ ] SubTask 4.6.1: 当 `currentTask.subIntents` 非空时，`structuredResponse` 按子域分段
  - [ ] SubTask 4.6.2: 每个子域对应一个 section 块，标记来源子域
  - [ ] SubTask 4.6.3: subIntents 为空时走原有 response 逻辑

- [ ] Task 4.7: 扩展 CognitiveEventBus 事件类型
  - [ ] SubTask 4.7.1: 新增 `subIntent:detected` 事件类型
  - [ ] SubTask 4.7.2: 新增 `subIntent:resolved` 事件类型
  - [ ] SubTask 4.7.3: intention 节点完成后 emit `subIntent:detected`（仅当 subIntents 非空时）
  - [ ] SubTask 4.7.4: response 节点完成后按子域逐个 emit `subIntent:resolved`
