# Tasks: 分页参数 DRY 抽取 + 时间参数补全

## Preconditions

- [x] Plan `farm-agent-pagination-dry-plan-v1.md` 已创建
- [x] Farm-Server API 文档确认 `dataTime` 参数格式

## Forbidden

- 禁止修改 `pageNo`/`pageSize` 的 default 值或约束范围
- 禁止新增工具或修改现有工具的 description
- 禁止修改 expert registry

## Tasks

- [x] Task 1: 提取 BasePageParams
  - [x] `schemas/farm-data-tools.ts` 新增 `export const BasePageParams = { pageNo: ..., pageSize: ... }`
  - [x] `SoilMoisturePageSchema` 的 `pageNo`/`pageSize` 替换为 `...BasePageParams`
  - [x] 验证 zod 类型推断不变

- [x] Task 2: 替换内联分页定义
  - [x] `impl/farm-data-tools.ts` import 追加 `BasePageParams`
  - [x] `InsectDataPageSchema` 的 `pageNo`/`pageSize` → `...BasePageParams`
  - [x] `FarmWeatherPageSchema` 的 `pageNo`/`pageSize` → `...BasePageParams`
  - [x] `MassifPageSchema` 的 `pageNo`/`pageSize` → `...BasePageParams`
  - [x] `InsectTypePageSchema` 的 `pageNo`/`pageSize` → `...BasePageParams`

- [x] Task 3: 补 dataTime + API 透传
  - [x] `InsectDataPageSchema` 新增 `dataTime: z.array(z.string()).optional()`
  - [x] `FarmWeatherPageSchema` 新增 `dataTime: z.array(z.string()).optional()`
  - [x] `queryInsectDataTool` 的 `farmServerPage` 调用追加 `dataTime: params.dataTime`
  - [x] `queryFarmWeatherTool` 的 `farmServerPage` 调用追加 `dataTime: params.dataTime`

- [x] Task 4: 编译验证
  - [x] `npx tsc --noEmit` 零错误

## Task Dependencies

- Task 2 依赖 Task 1（需要先有 `BasePageParams` 导出才能 import）
- Task 3 依赖 Task 2（在同一文件中替换后补字段更安全）
- Task 4 依赖 Task 1-3

## Verification

- [x] `npx tsc --noEmit`
- [x] `npm run lint`
