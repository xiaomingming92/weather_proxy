# 分页参数 DRY 抽取 + 时间参数补全 Spec

## Why

5 处重复定义 `pageNo`/`pageSize` zod schema，修改 default 值需改 5 个地方；虫情/气象工具缺少 `dataTime` 参数，导致周报/日报专家无法按时间窗口过滤数据。

## What Changes

| 文件 | 变更 |
|------|------|
| `src/agents/tools/schemas/farm-data-tools.ts` | 新增 `BasePageParams` 导出，`SoilMoisturePageSchema` 引用它 |
| `src/agents/tools/impl/farm-data-tools.ts` | 4 个内联 schema 替换为 `...BasePageParams`；`InsectDataPageSchema`、`FarmWeatherPageSchema` 补 `dataTime`；工具函数透传 `dataTime` |

## Impact

- Affected specs: 无
- Affected code: `src/agents/tools/schemas/farm-data-tools.ts`, `src/agents/tools/impl/farm-data-tools.ts`
- 父 Plan: `farm-agent-pagination-dry-plan-v1.md`

## Boundaries

- 本次只允许：提取 `BasePageParams` + 替换引用 + 补 `dataTime` 参数
- 本次禁止：修改 default 值、修改 expert registry 时间窗口声明、新增工具

## Requirements

### Requirement: BasePageParams 提取

系统 SHALL 在 `schemas/farm-data-tools.ts` 导出 `BasePageParams` 对象，包含 `pageNo` 和 `pageSize` 的 zod 定义。

#### Scenario: 分页 schema 引用 BasePageParams

- **WHEN** 任意工具定义分页查询 schema
- **THEN** 通过 `{ ...BasePageParams, ...业务字段 }` 引用分页参数，而非内联重复定义

### Requirement: dataTime 参数补全

系统 SHALL 为 `InsectDataPageSchema` 和 `FarmWeatherPageSchema` 增加 `dataTime` 可选字段，类型为 `z.array(z.string()).optional()`，与 `SoilMoisturePageSchema` 保持一致。

#### Scenario: LLM 按时间窗口查询虫情数据

- **WHEN** LLM 调用 `query_insect_data({ massifId: 1, dataTime: ["2026-06-08", "2026-06-15"] })`
- **THEN** 请求透传 `dataTime` 到 Farm-Server `/insect-data/page` 接口，返回该时间范围内的虫情数据

#### Scenario: LLM 按时间窗口查询气象数据

- **WHEN** LLM 调用 `query_farm_weather({ massifId: 1, dataTime: ["2026-06-08", "2026-06-15"] })`
- **THEN** 请求透传 `dataTime` 到 Farm-Server `/weather-data/page` 接口，返回该时间范围内的气象数据
