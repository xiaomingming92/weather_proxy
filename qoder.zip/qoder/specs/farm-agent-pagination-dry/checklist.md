# Checklist: 分页参数 DRY 抽取 + 时间参数补全

## 业务检查

- [x] `BasePageParams` 在 `schemas/farm-data-tools.ts` 中导出
- [x] `SoilMoisturePageSchema` 引用 `...BasePageParams`
- [x] `InsectDataPageSchema` 引用 `...BasePageParams`
- [x] `FarmWeatherPageSchema` 引用 `...BasePageParams`
- [x] `MassifPageSchema` 引用 `...BasePageParams`
- [x] `InsectTypePageSchema` 引用 `...BasePageParams`
- [x] `InsectDataPageSchema` 包含 `dataTime` 字段
- [x] `FarmWeatherPageSchema` 包含 `dataTime` 字段
- [x] `queryInsectDataTool` 透传 `dataTime` 到 `farmServerPage`
- [x] `queryFarmWeatherTool` 透传 `dataTime` 到 `farmServerPage`

## 编译期检查

- [x] `npx tsc --noEmit` 零错误
- [x] `npm run lint` 通过

## ADD 规则合规

- [x] ADD-1 可观测性优先（已有 farmDataAudit 日志，无需新增）
- [x] ADD-2 阶段标记对称（无需新增 AgentAuditPhase）
- [x] ADD-5 审计数据即业务数据（改动后 record_dev_operation）
