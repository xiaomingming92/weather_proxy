# Checklist: AuditLog 绕过治理

## Task 1: writeAuditLog 改造

- [T] `AgentAuditPhase` 联合类型含所有新 phase（STREAM_BUS_EMIT_TOKEN_BATCH 等）
- [T] `writeAuditLog()` 接受 `string` 类型 phase
- [T] `writeAuditLog()` 未设 traceId 时自动生成 `auto_{uuid}`
- [T] `agent-audit-logger.ts` 仍可通过 `setAuditContext` 设置 traceId 覆盖自动生成

## Task 2: stream-bus F1+F2

- [T] `stream-bus.ts` 有 `tokenBuffer: Map<traceId, {tokens[], startTime}>`
- [T] `response_start` 事件初始化 tokenBuffer
- [T] `token` 事件推入 buffer，不写 DB
- [T] `response_end` 事件 flush buffer → 1 条 writeAuditLog
- [T] `done`/`error` 事件兜底清理 tokenBuffer
- [T] `stream-bus-logger.ts` 3 个函数改为 writeAuditLog
- [T] `streamBusAuditBatch()` 函数存在，写入完整原文 + tokenCount + durationMs

## Task 3: 其余绕过模块

- [T] `farm-server-client.ts` → writeAuditLog(action, "FS_CLIENT", ...)
- [T] `credential-store.ts` → writeAuditLog(action, "CREDENTIAL", ...)
- [T] `chat/stream/route.ts` → writeAuditLog(action, "STREAM_TRACE", ...)
- [T] `layer2-callback.ts` → writeAuditLog(...)
- [T] `agent-gateway-audit.ts` → writeAuditLog(action, "AGENT_GATEWAY", ...)

## Task 4: ESLint 强制规则

- [T] ESLint 规则 1：禁止直调 prisma.auditLog.*（除 agent-audit-logger.ts），error 级别
- [T] ESLint 规则 2：禁止 userId 硬编码 "system"/"ai-assistant"，error 级别
- [T] ESLint 规则 3：*-audit.ts / *-logger.ts 新文件警告，warn 级别
- [T] `npx eslint src/` 零新增 error

## Task 5: caijue.toml 注册

- [T] `caijue.toml` 有 `[[caijue]]` id=audit-log-write-contract
- [T] 条目指向 `《裁决层-AuditLog写入契约》.md`

## Task 6: 验证

- [T] `npx tsc --noEmit` 零类型错误
- [T] `grep -rn 'prisma\.auditLog\.create' src/ --include='*.ts' | grep -v agent-audit-logger` 零输出
- [R] 发一条聊天后 AuditLog 无 STREAM_BUS_EMIT_TOKEN 新增行
- [R] 发一条聊天后 AuditLog 有 1 条 STREAM_BUS_EMIT_TOKEN_BATCH（含 tokenCount + durationMs + 完整原文）
- [R] 所有新 AuditLog 行 traceId 非空

## ADD 规则合规检查

- [T] ADD-1 可观测性优先：writeAuditLog 自动兜底 traceId
- [T] ADD-2 阶段标记对称：STREAM_BUS_EMIT_TOKEN_BATCH 与 response_end 成对
- [T] ADD-4 三通道输出：token 仅 file，batch 三通道
- [T] ADD-5 审计数据即业务数据：完整原文 + tokenCount 作为审计字段
- [T] ADD-6 失败路径等价审计：done/error 兜底清理
- [T] Plan/Spec 一致性：tasks.md 与 Plan §4 一致

## 跨项目联调检查

- [T] agent-audit-logger.ts 向后兼容：所有现有调用方传 AgentAuditPhase 子类型仍可编译
- [T] `eslint.config.mjs` 规则不含语法错误
- [R] ESLint 规则在 rfai 生产环境同等生效

## Task 7: 运行时发现队列背压控制

- [T] `append-runtime-finding-light.ts` 存在 L1/L2 两级队列常量（L1_CAP=50, L2_CAP=500）
- [T] `enqueueRuntimeFinding()` L1 有空位→去重→入 L1；L1 满→L2；L2 满→shift 最旧+记 warning
- [T] 去重逻辑：`{ source, errorMsg }` 相同且 60s 内 → 跳过
- [T] `flushRuntimeFindings()` 最多 FLUSH_CONCURRENCY(5) 并发写入
- [T] L1 清空后从 L2 splice(0, L1_CAP) 晋升（再经去重）
- [T] `instrumentation.ts` 仅 import light 模块（eslint 规则已拦截）
- [T] `proxy.ts` 首个请求时 import heavy 模块并 flush
