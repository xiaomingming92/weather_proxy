# AuditLog 绕过治理 Spec

## Why

生产环境 AuditLog 表 30,077 行中 29,622 行 (98.5%) 缺 traceId，其中 27,288 行 (90.7%) 为 STREAM_BUS_EMIT_TOKEN 逐字符垃圾。7 个模块 10 处绕过 writeAuditLog 直调 prisma.auditLog.create。需要将全部 AuditLog 写入收敛到统一入口，从根本上禁止绕过。

## What Changes

### 代码层
- **修改** `src/lib/agent-audit-logger.ts`：`writeAuditLog` phase 类型放宽为 `string`；未设 traceId 时自动生成 `auto_{uuid}`
- **修改** `src/agents/stream-bus.ts`：新增 `tokenBuffer: Map` 内存累积；`response_start` 初始化、`token` 推入 buffer、`response_end` flush 单条 DB、`done`/`error` 兜底清理
- **修改** `src/lib/stream-bus-logger.ts`：3 个直调改为 `writeAuditLog()`；新增 `streamBusAuditBatch()` + `STREAM_BUS_EMIT_TOKEN_BATCH` Phase
- **修改** `src/lib/farm-server-client.ts`：`prisma.auditLog.create` → `writeAuditLog()`
- **修改** `src/lib/auth/credential-store.ts`：同上
- **~~修改~~ 已实施** `src/lib/append-runtime-finding.ts`：已在 hardening-plan 中收口
- **修改** `src/app/api/agent/chat/stream/route.ts`：`auditTraceEvent()` → `writeAuditLog()`
- **修改** `src/lib/layer2-callback.ts`：→ `writeAuditLog()`
- **修改** `src/lib/agent-gateway-audit.ts`：→ `writeAuditLog()`（traceId 已修复，仅收口 L2）
- **修改** `eslint.config.mjs`：新增 3 条 no-restricted-syntax 规则 + instrumentation 链静态导入拦截
- **修改** `src/caijuehub/caijue.toml`：新增 `[[caijue]]` 条目
- **新建** `src/lib/append-runtime-finding-light.ts`：启动期轻量入队（零 I/O），含两级缓存队列 + 背压常量
- **修改** `src/instrumentation.ts`：改为引用 light 模块（enqueueRuntimeFinding）
- **修改** `src/proxy.ts`：首个请求时 import heavy 模块并 flushRuntimeFindings

## Impact

- **Affected specs**: `review-and-evidence-hardening`（append-runtime-finding.ts L2 收口已在此 Plan 实施）
- **Affected code**: 7 个模块 10 处直调
- **父 Plan**: `.qoder/plans/2026-06/25/audit-log-bypass-governance-plan-v1.md`
- **依赖**: hardening-plan（append-runtime-finding.ts 已收口，Task 3 跳过此文件）
- **后续依赖**: 无

## Boundaries

本次允许：
- 修改 writeAuditLog 签名和 traceId 兜底逻辑
- token 事件改为内存累积
- 7 模块 10 处直调改为 writeAuditLog()
- ESLint + caijue.toml 注册
- instrumentation 链分层（light 零 I/O + heavy 动态 import）
- 运行时发现队列两级缓存背压控制

本次禁止：
- 修改 AuditLog 表结构
- 删除历史数据
- 在业务层新增审计逻辑

## ADDED Requirements

### Requirement: 统一写入入口收敛

所有 AuditLog 写入必须通过 `writeAuditLog()` 入口，禁止任何文件直调 `prisma.auditLog.create`。

#### Scenario: 任意模块写入审计日志

- **WHEN** 任何模块需要写入 AuditLog
- **THEN** 必须调用 `writeAuditLog(action, targetType, targetId, extra?, reason?)`，traceId 由入口自动兜底

#### Scenario: 编译时禁止绕过

- **WHEN** 非 `agent-audit-logger.ts` 文件中出现 `prisma.auditLog.create`
- **THEN** ESLint 报 error 阻止编译

### Requirement: Token 内存累积单条落库

流式 token 事件不在每字符落库，而是在内存中累积，response_end 时写一条完整记录。

#### Scenario: LLM 流式回复

- **WHEN** LLM 流式产生 N 个 token 事件
- **THEN** token 内容在内存 buffer 中累积，仅写文件日志
- **WHEN** response_end 事件到达
- **THEN** flush buffer 为 1 条 `STREAM_BUS_EMIT_TOKEN_BATCH` DB 记录，含 tokenCount + durationMs + 完整原文

#### Scenario: SSE 异常断开

- **WHEN** done/error 事件到达但 response_end 未触发
- **THEN** 兜底清理 tokenBuffer 对应 traceId（不残留内存）

### Requirement: 绕过模块全部收口

所有绕过 writeAuditLog 直调 prisma.auditLog.create 的外部模块必须改为统一入口调用。

#### Scenario: 外部模块写入审计日志

- **WHEN** farm-server-client / credential-store / layer2-callback / agent-gateway-audit / stream route 需要写入 AuditLog
- **THEN** 调用 `writeAuditLog(action, targetType, targetId, ...)` 替代 `prisma.auditLog.create(...)`
- **THEN** 不新增审计相关文件（*-audit.ts / *-logger.ts）

### Requirement: ESLint 编译期阻断绕过

`eslint.config.mjs` 中新增 3 条 no-restricted-syntax 规则，在编码时实时阻断非法 AuditLog 写入。

#### Scenario: 开发人员直调 prisma.auditLog.create

- **WHEN** 非 agent-audit-logger.ts 文件中出现 `prisma.auditLog.create` / `prisma.auditLog.findMany` 等调用
- **THEN** ESLint 报 error，编译失败

#### Scenario: 开发人员硬编码 userId

- **WHEN** 代码中出现 `userId: "system"` 或 `userId: "ai-assistant"` 硬编码
- **THEN** ESLint 报 error，编译失败

#### Scenario: 新建审计文件

- **WHEN** 新建文件名为 `*-audit.ts` 或 `*-logger.ts`
- **THEN** ESLint 报 warn，提示走裁决层注册

### Requirement: 裁决层契约注册

在 `src/caijuehub/caijue.toml` 中注册 audit-log-write-contract 条目，形成设计时契约 + 编码时 ESLint + PR 时 CI 三层互锁。

#### Scenario: AI 检索裁决规则

- **WHEN** AI 助手设计审计相关功能
- **THEN** 自动加载 caijue.toml 中的 `audit-log-write-contract` 规则

#### Scenario: CI 流水线扫描绕过

- **WHEN** PR 提交
- **THEN** CI `grep -rn 'prisma\.auditLog\.create' src/ --include='*.ts' | grep -v agent-audit-logger` 有输出即构建失败

### Requirement: 运行时发现队列背压控制

`enqueueRuntimeFinding()` 被 instrumentation.ts 启动期调用，需两级缓存 + 同源去重 + 并发上限防止攻击风暴。

#### Scenario: 正常入队

- **WHEN** 运行时发现数量 ≤ L1_CAP(50)
- **THEN** 经过 source+errorMsg 去重后入 L1 工作区

#### Scenario: L1 溢出

- **WHEN** L1 已满且新发现未命中去重
- **THEN** 转入 L2 等待区（上限 500）

#### Scenario: L2 溢出

- **WHEN** L2 已满
- **THEN** 丢弃最旧发现，记 console.warn

#### Scenario: 同源去重

- **WHEN** `{ source, errorMsg }` 在 L1 或 L2 中已存在且时间 < 60s
- **THEN** 跳过入队，不重复记录

#### Scenario: flush 并发控制

- **WHEN** flushRuntimeFindings 被调用
- **THEN** 最多 FLUSH_CONCURRENCY(5) 个并发写入，逐批处理
- **WHEN** L1 清空
- **THEN** 从 L2 splice(0, L1_CAP) 批量晋升（再经一次去重）

**可配置参数**（`append-runtime-finding-light.ts` 常量区）：
- `L1_CAP = 50`, `L2_CAP = 500`, `DEDUP_WINDOW_MS = 60000`, `FLUSH_CONCURRENCY = 5`

### Requirement: 端到端验证闭环

全部改动完成后执行编译、ESLint、功能验证的完整闭环。

#### Scenario: 编译验证

- **WHEN** 所有 Task 完成
- **THEN** `npx tsc --noEmit` 零类型错误

#### Scenario: AuditLog 数据验证

- **WHEN** 发一条聊天消息
- **THEN** AuditLog 表无新增 STREAM_BUS_EMIT_TOKEN 行
- **THEN** AuditLog 表有 1 条 STREAM_BUS_EMIT_TOKEN_BATCH 记录（含 tokenCount + durationMs + 完整原文）
- **THEN** 所有新 AuditLog 行 traceId 非空
