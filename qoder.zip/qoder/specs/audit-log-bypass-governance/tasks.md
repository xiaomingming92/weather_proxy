# Tasks: AuditLog 绕过治理

## Preconditions

- [x] `append-runtime-finding.ts` L2 收口已完成（hardening-plan 已实施）
- [x] Review 结论已回流至 Plan（P1-1~P1-4）
- [x] 裁决层契约《AuditLog写入契约》已存在

## Forbidden

- 禁止修改 AuditLog 表结构
- 禁止删除历史 AuditLog 数据
- 禁止在业务层新增独立审计逻辑
- 禁止新建 *-audit.ts 或 *-logger.ts 文件

## Task Dependencies

```
Task 1 (writeAuditLog 改造)
  ├──→ Task 2 (stream-bus F1+F2)  ──┐
  │                                  ├── 并行（Task 1 完成后）
  └──→ Task 3 (其余绕过模块)      ──┘
                                    │
                                    ▼
                                Task 4 (ESLint 3规则)
                                    │
                                    ▼
                                Task 5 (caijue.toml 注册)
                                    │
                                    ▼
                                Task 6 (验证)
```

---

- [x] Task 1: writeAuditLog 改造为统一写入入口
  - [ ] 1.1 `phase` 参数类型 `AgentAuditPhase` → `string`
  - [ ] 1.2 未设 `currentTraceId` 时自动生成 `auto_{uuid}`
  - [ ] 1.3 不做其他改动

- [x] Task 2: stream-bus F1（内存累积）+ F2（traceId）
  - [ ] 2.1 `stream-bus.ts`: 新增 `tokenBuffer: Map<traceId, {tokens[], startTime}>`
  - [ ] 2.2 `response_start` 事件：初始化 tokenBuffer
  - [ ] 2.3 `token` 事件：推入 buffer（仅文件日志，不写 DB）
  - [ ] 2.4 `response_end` 事件：flush buffer → `streamBusAuditBatch()` → 1 条 DB
  - [ ] 2.5 `done`/`error` 事件：兜底清理 tokenBuffer
  - [ ] 2.6 `stream-bus-logger.ts`: 3 个函数 prisma.auditLog.create → writeAuditLog()
  - [ ] 2.7 新增 `streamBusAuditBatch(traceId, content, tokenCount, durationMs)`
  - [ ] 2.8 StreamBusAuditPhase 新增 `STREAM_BUS_EMIT_TOKEN_BATCH`

- [x] Task 3: 其余绕过模块改为 writeAuditLog
  - [ ] 3.1 `farm-server-client.ts`: prisma.auditLog.create → writeAuditLog(action, "FS_CLIENT", ...)
  - [ ] 3.2 `credential-store.ts`: → writeAuditLog(action, "CREDENTIAL", ...)
  - [ ] 3.3 `chat/stream/route.ts` `auditTraceEvent()`: → writeAuditLog(action, "STREAM_TRACE", ...)
  - [ ] 3.4 `layer2-callback.ts`: → writeAuditLog(...)
  - [ ] 3.5 `agent-gateway-audit.ts`: → writeAuditLog(action, "AGENT_GATEWAY", ...)

- [x] Task 4: ESLint 3 条强制规则
  - [ ] 4.1 禁止直调 prisma.auditLog.*（error，除 agent-audit-logger.ts）
  - [ ] 4.2 禁止 userId 硬编码 "system"/"ai-assistant"（error）
  - [ ] 4.3 *-audit.ts / *-logger.ts 新文件警告（warn）

- [x] Task 5: caijue.toml 注册裁决层契约
  - [ ] 5.1 新增 `[[caijue]]` id=audit-log-write-contract
  - [ ] 5.2 类型 contract，指向裁决层契约文档

- [x] Task 6: 验证
  - [ ] 6.1 `npx tsc --noEmit` 零类型错误
  - [ ] 6.2 `npx eslint src/` 零新增错误
  - [ ] 6.3 所有 prisma.auditLog.create 仅存在于 agent-audit-logger.ts
  - [ ] 6.4 发一条聊天后 AuditLog 无 STREAM_BUS_EMIT_TOKEN 新增行
  - [ ] 6.5 发一条聊天后 AuditLog 有 1 条 STREAM_BUS_EMIT_TOKEN_BATCH
  
  - [ ] Task 7: 运行时发现队列两级缓存背压控制
    - [ ] 7.1 `append-runtime-finding-light.ts`: 实现 L1/L2 两级队列（`l1Findings:[]`, `l2Findings:[]`）
    - [ ] 7.2 `enqueueRuntimeFinding()`: L1 有空位→去重→入 L1；L1 满→去重→入 L2；L2 满→shift 最旧
    - [ ] 7.3 去重门禁：`{ source, errorMsg }` 相同且在 DEDUP_WINDOW_MS(60s) 内 → 跳过
    - [ ] 7.4 `flushRuntimeFindings()`: 最多 FLUSH_CONCURRENCY(5) 并发，L1 清空后从 L2 晋升
    - [ ] 7.5 溢出记 warning（L2 丢弃时 + L1 晋升失败时）

## Verification

- [ ] `npx tsc --noEmit` 零类型错误
- [ ] `npx eslint src/` 零新增错误
- [ ] `grep -rn 'prisma\.auditLog\.create' src/ --include='*.ts' | grep -v agent-audit-logger` 零输出
- [ ] 验收标准全部通过（Plan §五）
