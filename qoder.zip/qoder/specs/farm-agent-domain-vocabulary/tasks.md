# Tasks: farm-agent Domain Vocabulary

## Preconditions
- [x] Plan v5 已就绪（方案选型 + 架构设计 + 五层管线确认）
- [x] cost-accounting.config.ts 已创建 + 注册（专家数量 13→14 统一）
- [x] SSE 协议文档 v1.2 已更新（param_missing 事件）
- [x] 决策管线架构说明书已更新（领域词汇注入设计约束）

## Forbidden
- 禁止修改 Zod schema 中 optional/required 属性
- 禁止新增 `ExpertPromptInput` 字段（不新增 `toolContext` 字段）
- 禁止修改 Tool Context 注入逻辑

## Tasks

- [x] Task 1: 创建 `src/agents/vocabulary/domain-triggers.ts`
  - [x] 定义 `DomainTriggerMap` 接口（`expertTriggers` + `collectionHints`）
  - [x] 导出 `DOMAIN_TRIGGERS` 常量
  - [x] `tsc --noEmit`

- [x] Task 2: 为 14 个专家填充触发词
  - [x] 全部 14 个专家
  - [x] 每个 ≥ 8 个 expertTriggers
  - [x] collectionHints 从 evidenceFilter 提取

- [x] Task 2.5a: Storage 层 Category 扩展 + 类型去擦除
  - [x] `analysis-context.ts`：`RuntimeInputEntry` 新增 `category: RuntimeInputCategory`（必填）
  - [x] `types.ts`：`Record<string, unknown>` → `Record<string, RuntimeInputEntry>`（2 处）
  - [x] `reasoning.ts`：构建时标注 category
  - [x] `factory.ts`：按 category 分两段渲染
  - [x] `tsc --noEmit`

- [x] Task 2.5b: caijuehub 裁决层
  - [x] `src/caijuehub/strategies/resolve-tool-params.ts` 新建
  - [x] `ToolParamRule` 接口 + `resolveMissingToolParams()` 函数
  - [x] `tsc --noEmit`

- [x] Task 3: intention.ts 注入领域词汇上下文
  - [x] `buildContextBlock()` 追加 triggerKeywords 摘要
  - [x] 不影响原有逻辑

- [x] Task 4: reasoning.ts 注入领域词汇上下文
  - [x] `build()` 追加领域词汇系统上下文

- [x] Task 5: factory.ts 注入 per-expert 词汇
  - [x] systemPrompt 之后追加 triggerKeywords + collectionHints

- [x] Task 6: 编译验证 + 端到端测试
  - [x] `npx tsc --noEmit`

- [x] Task 6.5: SSE param_missing 事件
  - [x] `stream-bus.ts`：新增 `ParamMissingEvent`
  - [x] `agents/index.ts`：ZodError → emit `param_missing`
  - [x] `tsc --noEmit`

## Task Dependencies
- Task 2 依赖 Task 1
- Task 2.5a 依赖 Task 2
- Task 2.5b 依赖 Task 2.5a
- Task 3-5 依赖 Task 2（可并行）
- Task 6 依赖 Task 2.5a + 3-5
- Task 6.5 依赖 Task 2.5b

## Verification
- [ ] `npx tsc --noEmit`
- [ ] 14 个 expert config 不因新增可选字段报错
- [ ] 端到端：领域词汇触发专家匹配
