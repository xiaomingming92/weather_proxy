# farm-agent Domain Vocabulary Spec

## Why
farm-agent 运行时面向用户的 LLM 缺乏领域"语义本能"——用户说"虫害严重"，LLM 不知道应该匹配 pest_risk 专家和 pest_management collection。同时，Tool Context（工具调用上下文）当前类型为 `Record<string, unknown>`，存在类型擦除，LLM 无法有效利用已有上下文参数（projectId/massifIds）填充工具调用入参。

## What Changes
- **新建** `src/agents/vocabulary/domain-triggers.ts` — 14 个专家的领域触发词 + RAG collection 提示
- **修改** `src/services/analysis-context.ts` — `RuntimeInputEntry` 新增 `category: RuntimeInputCategory` 字段
- **修改** `src/agents/prompts/types.ts` — `Record<string, unknown>` → `Record<string, RuntimeInputEntry>`
- **修改** `src/agents/nodes/reasoning.ts` — 构建 runtimeInputs 时标注 category
- **修改** `src/agents/prompts/experts/factory.ts` — 按 category 分区渲染 + 注入 per-expert 触发词
- **修改** `src/agents/prompts/intention.ts` — 注入领域触发词汇表摘要
- **修改** `src/agents/prompts/reasoning.ts` — 注入领域词汇系统上下文
- **新建** `src/caijuehub/strategies/resolve-tool-params.ts` — 动态参数必须性判断裁决层
- **修改** `src/agents/stream-bus.ts` — 新增 `ParamMissingEvent`
- **修改** `src/agents/index.ts` (toolNode) — ZodError → emit `param_missing`
- **修改** `src/agents/experts/configs/cost-accounting.config.ts` — 补建缺失 config
- **修改** `src/agents/experts/registry.ts` — 注册 cost_accounting 专家

## Impact
- Affected specs: 无（新能力，不冲突已有 specs）
- Affected code: `src/agents/vocabulary/`, `src/agents/prompts/`, `src/agents/nodes/`, `src/agents/experts/`, `src/services/`, `src/caijuehub/`, `src/agents/stream-bus.ts`
- 父 Plan: `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-plan-v1.md`
- 依赖: 无上游轮次
- 后续依赖: 无（独立交付）

## Boundaries
本次只允许实现：
- 创建 `domain-triggers.ts` 集中词汇文件 + 填充 14 专家触发词
- `RuntimeInputEntry` 新增 `category` 字段 + Prompt 层分区渲染
- Prompt 层注入领域词汇上下文（intention / reasoning / factory）
- 裁决层 `resolve-tool-params.ts` 动态参数判断
- SSE `param_missing` 事件

本次禁止实现：
- 工具 schema 中修改 optional/required 属性（保持 Zod 层不变）
- 新增 ExpertPromptInput 字段（不新增 `toolContext` 字段）
- 修改 Tool Context 注入逻辑（只做类型修复和分区渲染）
- governance AI 词汇注入（留待后续扩展）

## Requirements

### Requirement: 领域触发词 LLM 注入
系统 SHALL 在 intention / reasoning / factory 三级 prompt 中注入 `DOMAIN_TRIGGERS` 领域触发词汇表。

- Scenario: 用户说"最近虫害严重，帮我分析下风险"
  - WHEN LLM 在 intention 节点解析意图
  - THEN prompt 中包含 "可用的专家分析域: 虫害(pest_risk) 品种(crop_compare)..."
  - THEN LLM 能匹配 pest_risk 专家的触发词 "虫害"

### Requirement: Tool Context 分区渲染
系统 SHALL 按 `RuntimeInputEntry.category` 将 `【运行时参数】` 分裂为 `【运行时参数】`（analysis 类）和 `【工具调用上下文】`（toolContext 类）两段渲染。

- Scenario: expert 上下文包含 `projectId=1001`、`massifId=42`、`cropType=水稻`
  - WHEN factory.ts 调用 build()
  - THEN `【工具调用上下文】` 区块显示 projectId、massifId
  - THEN `【运行时参数】` 区块显示 cropType、其余非 toolContext 字段

### Requirement: 参数缺失 SSE 通知
系统 SHALL 在 toolNode 中检测工具调用 ZodError，emit `param_missing` SSE 事件。

- Scenario: LLM 调用 `query_insect_data({})` 且裁决层判定 massifId 必须
  - WHEN Zod 校验失败
  - THEN SSE 流包含 `{"type":"param_missing","toolName":"query_insect_data","missing":["massifId"],"hint":"..."}`
  - THEN 前端可渲染"需要补充信息"卡片

### Requirement: 类型去擦除
系统 SHALL 将 `ExpertPromptInput.runtimeInputs` 和 `ExpertReasoningPackage.runtimeInputs` 的类型从 `Record<string, unknown>` 改为 `Record<string, RuntimeInputEntry>`。

- Scenario: reasoning.ts 构建 expert package
  - WHEN 传递 runtimeInputs
  - THEN 类型检查通过（非 `unknown`），`factory.ts` 中 `entry.label`/`entry.value` 可直接访问
  - THEN `tsc --noEmit` 零错误

### Requirement: 裁决层动态参数判断
系统 SHALL 在 `src/caijuehub/strategies/resolve-tool-params.ts` 中实现裁决层，根据当前 expert/intent/AgentState 可达性动态判断 optional 参数是否必须。

- Scenario: pest_risk expert 调用 `query_insect_data`，AgentState 中有 `massifId=42`
  - WHEN `resolveMissingToolParams("query_insect_data", {}, state)` 被调用
  - THEN 返回 `{ missing: ["massifId"], hint: "请提供地块ID以查询虫情数据" }`

- Scenario: 用户查询"全农场本周虫害趋势"（无特定地块）
  - WHEN `resolveMissingToolParams` 的 context 显示 intent 为 overview
  - THEN 返回 `null`（massifId 非必须）

### Requirement: 专家配置补全
系统 SHALL 补建 `src/agents/experts/configs/cost-accounting.config.ts` 并在 `ANALYSIS_EXPERTS` 注册表中注册 cost_accounting 专家，使注册表专家数与 DOMAIN_TRIGGERS 一致（14）。

- Scenario: 注册表包含 cost_accounting
  - WHEN `ANALYSIS_EXPERTS["cost_accounting"]` 被访问
  - THEN 返回有效的 AnalysisExpert 对象
  - THEN `experts/configs/` 目录包含 14 个 `.config.ts` 文件

### Requirement: Per-expert 触发词注入
系统 SHALL 在 `factory.ts` 的 `build()` 方法中，为每个专家追加其对应的 `triggerKeywords` 和 `collectionHints`。

- Scenario: pest_risk 专家被激活
  - WHEN factory.ts 调用 build()
  - THEN prompt 中包含 "领域触发词：虫害、害虫、病虫害..." 
  - THEN prompt 中包含 "知识库关联：pest_management, crop_protection"

### Requirement: 编译期类型安全
系统 SHALL 确保全部改动通过 `tsc --noEmit` 编译验证，14 个 ExpertConfig 不因新增可选字段报错。

- Scenario: `npx tsc --noEmit` 执行
  - THEN 零类型错误
  - THEN `src/agents/experts/configs/` 下所有 `.config.ts` 文件无编译错误
