# Checklist: farm-agent Domain Vocabulary

## 编译期检查

- [x] `npx tsc --noEmit` 零错误（全链路）
- [x] `DOMAIN_TRIGGERS` 14 个 expertId 与 `ANALYSIS_EXPERTS` 一致
- [x] `RuntimeInputCategory` 枚举型，`factory.ts` 中 category 过滤无类型错误
- [x] `ParamMissingEvent` 加入 `StreamEvent` union type
- [x] `record_dev_operation` 全部文件已记录（ADD-7）✅ 9 文件已落库

## 业务验收

- [x] Task 1: `domain-triggers.ts` 存在且导出 `DOMAIN_TRIGGERS`
- [x] Task 2: 14 个专家均有 ≥ 8 个 expertTriggers
- [x] Task 2.5a: factory.ts 按 category 分两段渲染
- [x] Task 2.5b: `resolve-tool-params.ts` 存在，裁决层逻辑可用
- [x] Task 3-5: intention / reasoning / factory 三级注入领域词汇
- [x] Task 6.5: `stream-bus.ts` 含 `ParamMissingEvent`

## ADD 规则合规

- [x] ADD-0.1: 文档先行 — Plan + Specs 三元组 + project docs 已更新
- [x] ADD-1: 可观测性 — 新增功能有 agentAudit 调用
- [x] ADD-7: 开发操作审计 — 所有文件改动有 `record_dev_operation` 记录 ✅ 9 文件已落库
- [x] ADD-9: 方案评审 — Plan 已通过 v1→v5 迭代审查
