# Tasks: 气候带查询

## Preconditions

- [ ] Python 3.8+ 已安装（网格数据生成需要）
- [ ] kgcpy Python 包可用（`pip install kgcpy`）

## Forbidden

- 禁止修改 weather-tools 的 API 契约
- 禁止引入任何外部 API 依赖
- 禁止气候带查表走 GCJ-02 转换

## Tasks

### Phase 1: 数据准备

- [ ] Task 1.1: `src/data/climate-zones/climate-zone-metadata.json`
  - [ ] 手工编制 30 种柯本-盖格气候类型的 JSON 元数据
  - [ ] 每种类型包含：code、name、category、avgTempRange、annualPrecip、growingSeason、accumulatedTemp、frostFreeDays、aridityIndex、suitableCrops、farmingSystem、description
  - [ ] 覆盖中国常见气候带 ≥ 15 种（Bwk, Cwa, Cfa, Cwb, Dwa, Dwb, Dwc, ET 等）
  - [ ] 验证: JSON 格式正确，JSON.parse 无报错

- [ ] Task 1.2: `scripts/generate-climate-grid.py`
  - [ ] 编写 Python 脚本，从 kgcpy 内置栅格数据采样导出中国区 ~0.1° 网格
  - [ ] 输出格式：`{ resolution: 0.1, bounds: { minLng, maxLng, minLat, maxLat }, grid: number[] }`
  - [ ] grid 值为柯本分类代码编号 (1-30)，0 = 水域/无效
  - [ ] 验证: 脚本可执行，输出格式正确

### Phase 2: 网格数据生成

- [ ] Task 2.1: 执行脚本生成 `src/data/climate-zones/china-koppen-grid.json`
  - [ ] JSON 文件大小 ≤ 5MB
  - [ ] resolution = 0.1
  - [ ] 抽样验证: 北京(116.4,39.9)→Dwa、广州(113.3,23.1)→Cfa、拉萨(91.1,29.7)→Cwb、乌鲁木齐(87.6,43.8)→Bwk
  - [ ] 验证: grid 数组长度 = (lngRange/0.1) × (latRange/0.1)

### Phase 3: 工具实现

- [ ] Task 3.1: `src/agents/tools/schemas/climate-zone-tools.ts`
  - [ ] 定义 `ClimateZoneSchema`（Zod），location 参数描述复用 weather-tools 的三种格式
  - [ ] 验证: tsc 通过

- [ ] Task 3.2: `src/agents/tools/impl/climate-zone-tools.ts`
  - [ ] 从 weather-tools 提取 `parseTiandituPath`、`calcCentroid`、`detectLocationType` 到 `coordinate-utils.ts`
  - [ ] grep 全项目确认无其他文件引用 weather-tools 中的这三个函数
  - [ ] 实现网格最近邻查找：`(lng - minLng) / resolution` → 列索引，`(lat - minLat) / resolution` → 行索引
  - [ ] 边界检查：坐标超出中国区范围时返回友好错误
  - [ ] 审计日志：同时调用 `agentAudit("CLIMATE_ZONE_LOOKUP")` + `writeAuditLog("TOOL_INVOKED", ...)`
  - [ ] 支持单点、多边形、批量三种坐标格式
  - [ ] 验证: 单测 3 个以上坐标点返回正确气候带

- [ ] Task 3.2a: `src/agents/tools/utils/coordinate-utils.ts`
  - [ ] 提取 `parseTiandituPath`、`calcCentroid`、`detectLocationType`、`wgs84ToGcj02`、`resolveWeatherLocation`
  - [ ] 保持函数签名和实现不变
  - [ ] 验证: weather-tools 使用新 import 路径后功能不变

### Phase 4: 注册与集成

- [ ] Task 4.1: `src/agents/tools/index.ts`
  - [ ] import `queryClimateZoneTool` from `./impl/climate-zone-tools`
  - [ ] 追加到 `agentTools` 数组
  - [ ] 追加到 export 列表
  - [ ] 验证: tsc 通过

### Phase 5: 编译验证

- [ ] Task 5.1: `npx tsc --noEmit` 编译通过
  - [ ] 验证: 零编译错误

- [ ] Task 5.2: weather-tools 回归验证
  - [ ] 确认 `query_weather_realtime` / `query_weather_forecast` 功能正常
  - [ ] 验证: 坐标解析结果与重构前一致

- [ ] Task 5.3: 端到端验证
  - [ ] 通过 Agent 对话触发气候带查询
  - [ ] 验证: tool_call + 返回数据完整

## Task Dependencies

- Task 1.1, 1.2 可并行
- Task 2.1 依赖 Task 1.1, 1.2
- Task 3.1 依赖 Task 1.1（元数据结构定义）
- Task 3.2 依赖 Task 2.1, 3.1
- Task 3.2a 独立于数据任务，可提前执行
- Task 4.1 依赖 Task 3.2
- Task 5.1 依赖 Task 4.1
- Task 5.2 依赖 Task 3.2a
- Task 5.3 依赖 Task 5.1, 5.2

## Verification

- [ ] `npx tsc --noEmit` 零错误
- [ ] weather-tools 功能回归正常
- [ ] 抽样坐标返回正确气候带（北京→Dwa、广州→Cfa、拉萨→Cwb、乌鲁木齐→Bwk）
- [ ] 超出中国区坐标返回友好错误
- [ ] 审计日志记录完整（console + file + AuditLog 表）
