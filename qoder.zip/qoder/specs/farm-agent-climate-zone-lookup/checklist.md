# Checklist: 气候带查询

## Phase 1: 数据准备

- [ ] [T] Task 1.1: `climate-zone-metadata.json` JSON 格式正确，覆盖 ≥ 15 种中国常见气候带
- [ ] [T] Task 1.1: 每种类型包含全部必要字段（code/name/category/avgTempRange/annualPrecip/growingSeason/accumulatedTemp/frostFreeDays/aridityIndex/suitableCrops/farmingSystem/description）
- [ ] [T] Task 1.2: `generate-climate-grid.py` 可执行，输出格式符合规范

## Phase 2: 网格数据

- [ ] [T] Task 2.1: `china-koppen-grid.json` 文件存在且 ≤ 5MB
- [ ] [T] Task 2.1: resolution = 0.1
- [ ] [T] Task 2.1: 北京(116.4,39.9)→Dwa ✓
- [ ] [T] Task 2.1: 广州(113.3,23.1)→Cfa ✓
- [ ] [T] Task 2.1: 拉萨(91.1,29.7)→Cwb ✓
- [ ] [T] Task 2.1: 乌鲁木齐(87.6,43.8)→Bwk ✓

## Phase 3: 工具实现

- [ ] [T] Task 3.1: `ClimateZoneSchema` Zod 定义正确，tsc 通过
- [ ] [T] Task 3.2a: `coordinate-utils.ts` 提取完成，函数签名不变
- [ ] [T] Task 3.2a: grep 确认无其他文件 import weather-tools 的坐标解析函数
- [ ] [T] Task 3.2: weather-tools 使用 coordinate-utils 新路径，功能不变
- [ ] [T] Task 3.2: 单点坐标返回正确气候带
- [ ] [T] Task 3.2: 多边形路径自动计算质心后查表
- [ ] [T] Task 3.2: 批量坐标返回数组结果
- [ ] [T] Task 3.2: 超出中国区坐标返回友好错误（不崩溃）
- [ ] [T] Task 3.2: `agentAudit("CLIMATE_ZONE_LOOKUP")` + `writeAuditLog` 审计已植入

## Phase 4: 注册与集成

- [ ] [T] Task 4.1: `queryClimateZoneTool` 已注册到 agentTools 数组
- [ ] [T] Task 4.1: tsc 零错误

## Phase 5: 编译验证

- [ ] [T] Task 5.1: `npx tsc --noEmit` 零编译错误
- [ ] [T] Task 5.2: weather-tools 回归正常（坐标解析后功能不变）
- [ ] [R] Task 5.3: Agent 对话可自然触发气候带查询
- [ ] [R] Task 5.3: 审计日志记录完整（console + file + AuditLog 表）

## ADD 规则合规检查

- [ ] ADD-0: 文档先行 — Plan + Review + Specs + add-route 全部就绪
- [ ] ADD-1: 可观测性 — `agentAudit` + `writeAuditLog` 双通道审计
- [ ] ADD-2: 阶段标记对称 — `CLIMATE_ZONE_LOOKUP` 在 AgentAuditPhase 已注册
- [ ] ADD-6: 失败路径审计等价 — 越界坐标错误也记录审计
- [ ] ADD-7: 开发操作审计 — 每个文件改动后调用 `record_dev_operation`
