# 气候带查询 Spec

## Why

farm-agent 缺乏气候带层面的宏观认知——Agent 知道"今天 28°C 下雨"，但不知道"这个地块属于亚热带季风气候（Cfa）"。缺乏气候带信息导致专家在品种推荐、种植制度规划、积温带判定时缺少气候背景上下文。需要增加离线气候带查询能力，零外部 API 依赖。

## What Changes

- 新增 `src/data/climate-zones/climate-zone-metadata.json` — 30 种柯本-盖格气候类型 + 中国农业属性
- 新增 `src/data/climate-zones/china-koppen-grid.json` — 中国区 ~10km 分辨率网格数据
- 新增 `scripts/generate-climate-grid.py` — 网格数据生成脚本（Python）
- 新增 `src/agents/tools/schemas/climate-zone-tools.ts` — Zod Schema
- 新增 `src/agents/tools/impl/climate-zone-tools.ts` — 查表引擎 + Agent 工具
- 新增 `src/agents/tools/utils/coordinate-utils.ts` — 从 weather-tools 提取的公共坐标工具函数
- 修改 `src/agents/tools/impl/weather-tools.ts` — import 路径从本地函数改为 coordinate-utils
- 修改 `src/agents/tools/index.ts` — 注册 `query_climate_zone` 工具
- 修改 `src/lib/agent-audit-logger.ts` — 新增 `CLIMATE_ZONE_LOOKUP` + `CLIMATE_ZONE_METADATA` 审计阶段

## Impact

- Affected specs: 无
- Affected code: `weather-tools.ts`（import 路径变更）
- 父 Plan: `farm-agent-climate-zone-lookup-plan-v1.md`
- 依赖: 无上游依赖
- 后续依赖: 无

## Boundaries

本次只允许实现：
- `query_climate_zone` 工具：接受天地图坐标格式，返回柯本气候带代码 + 中国农业属性
- 坐标解析复用 weather-tools 的三种格式（城市名/单点/多边形路径）
- 纯离线查表，不走 GCJ-02 转换
- 坐标超出中国区范围时返回友好错误

本次禁止实现：
- 气候带相关的 UI 组件（纯后端工具）
- 与和风天气 API 的联动
- 实时气候带在线查询
- 品种推荐/种植制度的自动联动（留给专家 prompt 消费工具返回值）

## Requirements

### Requirement: 气候带元数据定义
系统 SHALL 提供 30 种柯本-盖格气候类型的元数据定义，每种包含完整的中国农业属性。

**Scenario: 元数据结构完整性**
- WHEN 加载 `climate-zone-metadata.json`
- THEN 每种气候带包含全部字段：code、name、category、avgTempRange、annualPrecip、growingSeason、accumulatedTemp、frostFreeDays、aridityIndex、suitableCrops、farmingSystem、description
- AND 覆盖中国常见气候带 ≥ 15 种

### Requirement: 气候带网格数据
系统 SHALL 提供中国区 ~10km 分辨率柯本-盖格网格数据，支持按 WGS-84 坐标最近邻查找。

**Scenario: 网格数据格式**
- WHEN 加载 `china-koppen-grid.json`
- THEN resolution = 0.1，grid 为扁平化 number[] 数组
- AND 文件大小 ≤ 5MB

**Scenario: 抽样准确性**
- WHEN 查询北京(116.4,39.9) → THEN 返回 Dwa
- WHEN 查询广州(113.3,23.1) → THEN 返回 Cfa
- WHEN 查询拉萨(91.1,29.7) → THEN 返回 Cwb

### Requirement: Zod Schema 定义
系统 SHALL 定义 `ClimateZoneSchema`，location 参数描述复用 weather-tools 的三种坐标格式。

**Scenario: Schema 类型安全**
- WHEN `npx tsc --noEmit` 编译
- THEN `ClimateZoneSchema` 类型推断正确，零类型错误

### Requirement: 气候带查表
系统 SHALL 根据 WGS-84 坐标查询对应柯本-盖格气候带代码及中国农业属性。

**Scenario: 单点坐标查询**
- WHEN Agent 调用 `query_climate_zone({ location: "116.41,39.92" })`
- THEN 返回 `{ code: "Dwa", name: "冷温带季风气候", category: "D", properties: {...}, wgs84: {...} }`

**Scenario: 多边形路径查询**
- WHEN Agent 调用 `query_climate_zone({ location: "113.2,23.1;113.3,23.1;113.3,23.2;113.2,23.2" })`
- THEN 自动计算多边形质心后查表，返回对应气候带

**Scenario: 批量坐标查询**
- WHEN Agent 调用 `query_climate_zone({ location: "116.41,39.92;113.33,23.17;91.13,29.65" })`
- THEN 返回每个坐标对应的气候带数组

**Scenario: 超出中国区范围**
- WHEN Agent 调用 `query_climate_zone({ location: "139.69,35.69" })`（东京坐标）
- THEN 返回 `{ success: false, error: "坐标 (139.69, 35.69) 超出中国气候带数据覆盖范围" }`

### Requirement: 坐标工具提取
系统 SHALL 将 weather-tools 中的坐标解析函数提取到 `coordinate-utils.ts` 公共模块，不改变原有行为。

**Scenario: 函数签名不变**
- WHEN 提取 `parseTiandituPath`、`calcCentroid`、`detectLocationType`、`wgs84ToGcj02`、`resolveWeatherLocation`
- THEN 所有函数签名和实现保持不变

**Scenario: 天气工具回归**
- WHEN 坐标工具提取后调用 `query_weather_realtime({ location: "116.41,39.92" })`
- THEN 返回结果与提取前完全一致
- AND grep 全项目确认无其他文件直接 import weather-tools 中的这三个函数

### Requirement: 工具注册
系统 SHALL 将 `query_climate_zone` 注册到 `agentTools` 数组和 export 列表。

**Scenario: 工具可见性**
- WHEN Agent 加载工具列表
- THEN `query_climate_zone` 在 `agentTools` 数组中可见
- AND `npx tsc --noEmit` 零错误

### Requirement: 审计日志
系统 SHALL 使用 `agentAudit` + `writeAuditLog` 双通道记录气候带查表过程。

**Scenario: 查表审计**
- WHEN 查表引擎执行网格查找
- THEN 记录 `CLIMATE_ZONE_LOOKUP` 阶段到 console + file + AuditLog 表
- AND 包含坐标、网格索引、结果代码

**Scenario: 失败路径审计**
- WHEN 坐标超出范围或查表失败
- THEN 同样记录审计日志（ADD-6 失败路径等价审计）

### Requirement: AgentAuditPhase 扩展
系统 SHALL 在 `agent-audit-logger.ts` 中新增 `CLIMATE_ZONE_LOOKUP` 和 `CLIMATE_ZONE_METADATA` 阶段字面量。

**Scenario: 阶段类型安全**
- WHEN `agentAudit("CLIMATE_ZONE_LOOKUP", ...)` 调用
- THEN TypeScript 类型检查通过

### Requirement: 编译验证
系统 SHALL 确保所有改动文件通过 TypeScript 编译。

**Scenario: 零编译错误**
- WHEN `npx tsc --noEmit` 执行
- THEN 零编译错误，零类型错误
