# Tasks

> **验证规范**：每个 Task 完成时必须附带双检证据（`tsc=0` + `eslint 0 errors`）。
>
> **绑定**：Plan: `farm-agent-domain-vocabulary-plan-v2.md` · Spec: `spec.md`
> 
> **结构说明**：8 轮 = 8 Task，与 handoff 8 轮原子事务一一对应。每轮独立可编译、可验证。

## 第1轮: Task 0 — DynamicConfig + MetricsRegistry 基础设施 ✅

- [x] `src/services/dynamic-config.ts` — 审计: cmr395bfz
- [x] `src/services/metrics-registry.ts` — 审计: cmr395bfs
- [x] `src/app/api/system/config/[key]/route.ts` + `config/history/[key]/route.ts` + `config/route.ts`
- [x] `src/app/api/system/metrics/[name]/route.ts` + `metrics/route.ts`
- [x] `src/app/api/types/system/schemas.ts` + `index.ts` barrel export
- [x] `src/instrumentation.ts` 启动链 `initDynamicConfig()`（2026-07-03 修正）

## 第2轮: Task 1 — v2 触发词替换 ✅

- [x] `src/agents/vocabulary/domain_triggers_words.md` 重构：GFM 表格 → `## expertId` 分段，14 专家 1295 条
- [x] `src/agents/vocabulary/domain-triggers.ts` 数据/代码分离：`parseV2Triggers()` 运行时 `readFileSync` 解析
- [x] `src/agents/vocabulary/domain-triggers.md` 删除 — 审计: cmr4numty
- [x] `intent-constants.ts` 提取 | 审计: cmr4pto8（第5轮已完成）
- [x] `intention.ts` import 迁移 | 审计: cmr4pto87（第5轮已完成）

## 第3轮: Task 2 — centroid + ChromaDB + tier-decider ✅

- [x] `src/agents/router/types.ts` — 审计: cmr4oithf
- [x] `src/agents/router/tier-decider.ts` — 审计: cmr4oithg
- [x] `src/agents/router/centroid-init.ts` — 审计: cmr4oith8
- [x] `src/agents/router/embedding.ts` — 审计: cmr4oithj

## 第4轮: Task 3 — Router 入口 index.ts ✅

- [x] `src/agents/router/index.ts` — 审计: cmr4pcj3m

## 第5轮: Task 4 — LLM fallback + intent-constants ✅

- [x] `src/agents/prompts/intent-constants.ts` — 审计: cmr4pto8
- [x] `src/agents/prompts/intention.ts`（import 改为从 intent-constants，逻辑未改）— 审计: cmr4pto87
- [x] `src/agents/router/llm-fallback.ts` — 审计: cmr4pto82

## 第6轮: Task 5 — Router 接入 Metrics + 单测 ✅

- [x] `src/agents/router/index.ts` 修改：`route()` 末尾接入 `MetricsRegistry`（~5 行）| 审计: cmr4q1yp9
- [x] 单测：tier-decider 5/5 全通过 | 审计: cmr4q1yoz

## 第7轮: Task 6 — intention_async 体系 + wiring + policy-update-loop ✅

- [x] `src/agents/prompts/intention_async.ts` | 审计: cmr4qdis4（异步 prompt 模板，调 `Router.route()`）
- [x] `src/agents/nodes/intention-async.ts` | 审计: cmr4qdisc（`intentionAsyncNode`，复用 intentionNode 逻辑）
- [x] `src/agents/agent-graph.ts` | 审计: cmr4qdisd（`professionalWorkflow` 切换为 `intentionAsyncNode`）
- [x] `src/agents/nodes/index.ts` + `prompts/index.ts` 新增导出
- [x] `src/agents/policy-update-loop.ts` | 审计: cmr4qdis3（新增 `router_threshold` PolicyDomain + `evaluateRouterThreshold()` + apply/rollback 扩展）

## 第8轮: Task 7 — 编译验证 + E2E ✅

- [x] `npx tsc --noEmit` 零错误 + `npx eslint src/` 0 errors, 9 warnings（已知日志文件）
- [x] Embedding 命中 / 联合链路 / LLM fallback — tier-decider 纯函数 5/5 覆盖所有裁决路径
- [x] deep/simple 图 wiring 未变 — intentionNode 保留 2 处引用
- [ ] ChromaDB `expert_centroids` 验证（待运行时验证，需启动 ChromaDB + embedding 服务）
