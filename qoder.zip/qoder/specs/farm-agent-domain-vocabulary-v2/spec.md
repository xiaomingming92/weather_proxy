# farm-agent-domain-vocabulary-v2 Spec

> **对应 Plan**：`.qoder/plans/2026-07/01/farm-agent-domain-vocabulary-plan-v2.md`
>
> **配套文档**：`tasks.md` · `checklist.md`
>
> **定位**：精确接口定义 + WHEN-THEN 场景。Plan 回答"改什么、为什么改"，Spec 回答"接口长什么样、什么场景返回什么"。

---

## 一、类型定义

### 1.1 路由阈值——DynamicConfig 管理

```typescript
// src/services/dynamic-config.ts — 初始值（启动时从常量注入）
export const DEFAULT_CONFIG: Record<string, unknown> = {
  EMBEDDING_CONFIDENCE_THRESHOLD: 0.5,   // top-1 最低置信度
  EMBEDDING_MARGIN_THRESHOLD: 0.15,       // top-1/2 最小分差
  EMBEDDING_TOPK: 3,                       // ChromaDB 候选数
}

// embedding.ts — 运行时从 DynamicConfig 动态读取，非硬编码
const threshold = dynamicConfig.get("EMBEDDING_CONFIDENCE_THRESHOLD") ?? 0.5
const margin = dynamicConfig.get("EMBEDDING_MARGIN_THRESHOLD") ?? 0.15
const topK = dynamicConfig.get("EMBEDDING_TOPK") ?? 3
```

> **设计理由**：采用行业默认值 0.5（aurelio-labs semantic-router 示例值 + LiteLLM auto-router 官方配置默认值），阈值通过 `DynamicConfig` 运行时热更新，无需重启。配合 `MetricsRegistry` 观察效果后通过 API 或 AI（policy-update-loop）调整。

### 1.2 DynamicConfig 接口

```typescript
// src/services/dynamic-config.ts

interface ConfigChange {
  key: string
  oldValue: unknown
  newValue: unknown
  timestamp: number
  source: "api" | "ai" | "init"
}

interface DynamicConfigStore {
  get<T>(key: string): T | undefined
  set<T>(key: string, value: T, source?: "api" | "ai" | "init"): void
  getAll(): Record<string, unknown>
  delete(key: string): void
  getHistory(key: string): ConfigChange[]
  onChange(key: string, handler: (change: ConfigChange) => void): () => void
}
```

### 1.3 RouterResult

```typescript
// src/agents/router/types.ts

interface Candidate {
  expertId: string        // "pest_risk"
  label: string           // "病虫害风险"
  score: number           // cosine similarity, 0-1
}

interface RouterResult {
  expertIds: string[]     // 候选专家 ID 列表，按置信度降序
  confidence: number      // top-1 的置信度，0-1
  tier: 1 | 2            // 1=Embedding 命中, 2=LLM fallback
  candidates: Candidate[] // 完整候选列表（top-K）
}
```

### 1.4 ExpertCentroid（ChromaDB）

```typescript
// src/agents/router/centroid-init.ts

interface ExpertCentroid {
  expertId: string        // "pest_risk"
  label: string           // "病虫害风险"
  embedding: number[]     // 1024 维 float32 centroid
}
```

ChromaDB collection schema：
- **collection name**：`expert_centroids`
- **维度**：1024（`text-embedding-v4`）
- **metadata**：`{ expertId: string, label: string }`
- **操作**：`upsert`（幂等）

### 1.5 RouteLayer 接口

```typescript
// src/agents/router/index.ts

interface RouteLayer {
  /** 初始化：确保 ChromaDB centroid collection 已就绪 */
  init(): Promise<void>

  /** 路由用户查询到专家 */
  route(query: string): Promise<RouterResult>
}
```

### 1.6 TierDecider 接口

纯函数，不依赖外部状态。`embedding.ts` 返回 `Candidate[]`，`tier-decider.ts` 根据阈值 + margin 输出决策，`index.ts` 按 `action` 分发。

```typescript
// src/agents/router/tier-decider.ts

interface TierDecision {
  tier: 1 | 2
  action: "direct" | "multi-candidate" | "fallback"
  expertIds: string[]
  candidates: Candidate[]
  confidence: number      // top-1 的 score
}

function decide(
  candidates: Candidate[],
  threshold: number,      // dynamicConfig.get("EMBEDDING_CONFIDENCE_THRESHOLD")
  margin: number,          // dynamicConfig.get("EMBEDDING_MARGIN_THRESHOLD")
): TierDecision
```

裁决矩阵（对应 Spec §二 WHEN-THEN 场景 1/2/3）：

| 条件 | action | tier |
|------|--------|:--:|
| top-1 > threshold 且 top-1 − top-2 > margin | `"direct"` | 1 |
| top-1 > threshold 但 top-1 − top-2 < margin | `"multi-candidate"` | 1 |
| top-1 < threshold | `"fallback"` | 2 |

> 场景 4（Embedding 不可用）和场景 5（ChromaDB 缺失）由 `index.ts` 编排层处理，不属于 tier-decider 职责——tier-decider 只做分数裁决。

### 1.7 intention_async PromptTemplate 接口

```typescript
// src/agents/prompts/intention_async.ts

// 复用现有 PromptTemplate<IntentionInput, IntentionOutput> 接口
// 区别：build 为 async，内部调用 Router.route()
export const intentionAsyncPrompt: PromptTemplate<IntentionInput, IntentionOutput> = {
  id: "intention_async",
  build: async (input: IntentionInput): Promise<string> => { ... }
  // parse + validate 同 intention.ts
}
```

### 1.8 MetricsRegistry 接口

```typescript
// src/services/metrics-registry.ts

interface MetricsSnapshot {
  name: string
  counters: Record<string, number>
  gauges: Record<string, number>
  distributions: Record<string, number[]>
  windowSize: number
  lastResetAt: number
}

interface MetricsCollector {
  readonly name: string
  incr(key: string, delta?: number): void
  gauge(key: string, value: number): void
  observe(key: string, value: number): void
  snapshot(): MetricsSnapshot
  reset(): void
}

interface MetricsRegistry {
  register(name: string): MetricsCollector
  unregister(name: string): void
  snapshot(name: string): MetricsSnapshot | null
  snapshotAll(): MetricsSnapshot[]
  getCounter(name: string, key: string): number
}
```

---

## 二、WHEN-THEN 场景

### 场景 1：Embedding 高置信度单候选

**WHEN** 用户输入 `"地里烂根了，打什么药"`

**THEN**
1. `getEmbeddings(query)` → 1024 维 query embedding
2. `ChromaDB.query("expert_centroids", queryEmbedding, topK=EMBEDDING_TOPK)` 返回：
   ```
   pest_risk: 0.92, nutrition_diagnose: 0.58, growth_report: 0.41
   ```
3. `top-1 score(0.92) > EMBEDDING_CONFIDENCE_THRESHOLD(0.5)` ✅ 且 `top-1 - top-2(0.34) > EMBEDDING_MARGIN_THRESHOLD(0.15)` ✅（阈值运行时从 DynamicConfig 读取）
4. 返回 `RouterResult { expertIds: ["pest_risk"], confidence: 0.92, tier: 1 }`
5. `intention_async` 不调 LLM，直接构建 `subIntents: [{ domain: "pest_risk", subQuery: "地里烂根了，打什么药" }]`

### 场景 2：Embedding 高置信度多候选（联合链路）

**WHEN** 用户输入 `"选个高产的品种"`

**THEN**
1. ChromaDB 查询返回：
   ```
   crop_compare: 0.88, variety_recommend: 0.85, planting_advice: 0.52
   ```
2. `top-1(0.88) > EMBEDDING_CONFIDENCE_THRESHOLD(0.5)` ✅ 但 `top-1 - top-2(0.03) < EMBEDDING_MARGIN_THRESHOLD(0.15)` ❌ — 前两者太接近
3. 返回 `RouterResult { expertIds: ["crop_compare", "variety_recommend"], confidence: 0.88, tier: 1 }`
4. `intention_async` 用多候选构建 `subIntents[]`，professional 图 fan-out
5. `routerMetrics` 记录 `tier1Hits`++ 和 `confidenceSamples` 推送

### 场景 3：Embedding 低置信度 → LLM fallback

**WHEN** 用户输入 `"今年种啥能赚钱还不累"`

**THEN**
1. ChromaDB 查询返回：
   ```
   roi_analysis: 0.48, variety_recommend: 0.42, planting_advice: 0.39
   ```
2. `top-1(0.48) < EMBEDDING_CONFIDENCE_THRESHOLD(0.5)` ❌ → 升级 Tier 2
3. 返回 `RouterResult { expertIds: ["roi_analysis", "variety_recommend", "planting_advice"], confidence: 0.48, tier: 2 }`
4. LLM prompt 注入 `INTENT_SEMANTICS` + `CROSS_DOMAIN_RULES` + 三个候选专家的 description
5. LLM 返回最终 `expertPlan[]`

### 场景 4：Embedding 服务不可用

**WHEN** `getEmbeddings()` 抛出异常（网络故障/API key 失效）

**THEN**
1. `embeddingRoute(query)` 捕获异常
2. 直接降级到 Tier 2 LLM（不注入候选专家描述，同 v1 行为）
3. 返回 `RouterResult { tier: 2 }`，由 LLM 全权决策

### 场景 5：ChromaDB centroid collection 不存在

**WHEN** `Router.init()` 检测到 `expert_centroids` collection 缺失

**THEN**
1. `CentroidInit.build()` 自动执行：遍历 `DOMAIN_TRIGGERS.expertTriggers` → `getEmbeddings()` 均值池化 → `upsert` 到 ChromaDB
2. 初始化完成后正常服务

### 场景 6：intention_async 保持与 intention 兼容

**WHEN** deep/simple 图使用 `intention.ts`（同步版本）

**THEN**
- `intention.ts` 未被修改（diff 为空）
- `INTENT_SEMANTICS` 和 `CROSS_DOMAIN_RULES` 从 `intent-constants.ts` 同步 import
- deep/simple 图行为与 v1 完全一致

### 场景 7：AI 自动调参（MetricsRegistry → policy-update-loop）

**WHEN** Router 累计 ≥ 20 次路由后，`PolicyUpdateLoop.evaluate()` 接收 `routerMetrics` 参数

**THEN**
1. `evaluateRouterThreshold(routerSnapshot)` 检查触发条件
2. 若 `tier1Rate < 0.6` → 自动降低 `EMBEDDING_CONFIDENCE_THRESHOLD` 0.05（下限 0.3）
3. 若 `tier1Rate > 0.85` 且 expert 集中度 > 60% → 自动提高阈值 0.05（上限 0.8）
4. 生成的 `PolicyUpdateRecord` 走 cooldown + confidenceThreshold 检查
5. `apply()` 调用 `dynamicConfig.set("EMBEDDING_CONFIDENCE_THRESHOLD", newValue, "ai")` 落实
6. `agentAudit("POLICY_APPLIED", ...)` 记录，`source: "ai"` 可审计
7. 不满足条件 → 返回 null，不做任何调整

---

## 三、文件与接口清单

### 3.1 新建文件

| 文件 | 职责 | 主要导出 |
|------|------|---------|
| `src/services/dynamic-config.ts` | 动态参数 CRUD + 变更历史 + onChange 订阅 | `dynamicConfig`, `DEFAULT_CONFIG` |
| `src/services/metrics-registry.ts` | 模块化指标收集（incr/gauge/observe/snapshot） | `metricsRegistry` |
| `src/api/system/config/route.ts` | 人类查看/修改参数的 REST API | `GET/PUT /api/system/config/:key` |
| `src/api/system/metrics/route.ts` | 人类查看指标快照的 REST API | `GET /api/system/metrics/:name` |
| `src/agents/router/types.ts` | `RouterResult`, `Candidate` 类型 | `RouterResult`, `Candidate` |
| `src/agents/router/centroid-init.ts` | 构建 centroid → 写入 ChromaDB | `CentroidInit.build()` |
| `src/agents/router/embedding.ts` | ChromaDB 查询 + 阈值判定（阈值从 DynamicConfig 动态读取） | `embeddingRoute(query): Promise<RouterResult \| null>` |
| `src/agents/router/tier-decider.ts` | 纯函数裁决：candidates + threshold + margin → TierDecision | `decide(candidates, threshold, margin): TierDecision` |
| `src/agents/router/llm-fallback.ts` | LLM 意图解析 fallback | `llmFallbackRoute(query, candidates): Promise<RouterResult>` |
| `src/agents/router/index.ts` | RouteLayer 入口 | `Router.init()`, `Router.route(query)` |
| `src/agents/prompts/intent-constants.ts` | INTENT_SEMANTICS + CROSS_DOMAIN_RULES 共享常量 | `INTENT_SEMANTICS`, `CROSS_DOMAIN_RULES` |
| `src/agents/prompts/intention_async.ts` | 异步 intention prompt（professional 图专用） | `intentionAsyncPrompt` |
| `src/agents/nodes/intention-async.ts` | 异步 LangGraph 节点，替代 `intentionNode` 在 professional 图中 | `intentionAsyncNode` |

### 3.2 修改文件

| 文件 | 改动 | 说明 |
|------|------|------|
| `src/agents/vocabulary/domain-triggers.ts` | 替换触发词 | v1 词 → v2 词（`domain-triggersv2.md`） |
| `src/agents/prompts/intention.ts` | 提取常量 | import 改为从 `intent-constants.ts`；`intentionNode` 函数逻辑不改 |
| `src/agents/agent-graph.ts` | wiring | `professionalWorkflow` 的 intention 节点从 `intentionNode` 切换为 `intentionAsyncNode` |
| `src/agents/nodes/index.ts` | 导出 | 新增 `intentionAsyncNode` 导出 |
| `src/agents/prompts/index.ts` | 导出 | 新增 `intentionAsyncPrompt` 导出 |
| `src/agents/policy-update-loop.ts` | 修改 | 新增 `router_threshold` PolicyDomain + `evaluateRouterThreshold()` 决策函数 + `apply/rollback` 扩展 `DynamicConfig.set()` + `evaluate()` 新增 `routerMetrics` 参数 |

### 3.3 删除文件

| 文件 | 原因 |
|------|------|
| `src/agents/vocabulary/domain-triggers.md` | TypeScript 代码的 .md 副本，无消费者 |

---

## 四、Requirement ↔ Plan Task 映射

| # | Requirement | Plan Task |
|---|-------------|-----------|
| R1 | `domain-triggers.ts` 触发词替换为 v2 词库 | Task 1 |
| R2 | `CentroidInit.build()` 可用，ChromaDB collection 写入 | Task 2 |
| R3 | `embeddingRoute()` 阈值判定正确 | Task 2 |
| R4 | `Router.init()` 启动初始化 + `Router.route()` 串联流程 | Task 3 |
| R5 | `llmFallbackRoute()` prompt 含完整上下文 | Task 4 |
| R6 | Router 接入 MetricsRegistry（tier1Hits/tier2Fallbacks/latency/confidence） | Task 5 |
| R7 | `intention_async.ts` 异步 prompt 新建 | Task 6 |
| R8 | `intention-async.ts` 异步节点函数新建 | Task 6 |
| R9 | `agent-graph.ts` professional 图 wiring 切换为 `intentionAsyncNode` | Task 6 |
| R10 | `intent-constants.ts` 常量提取 | Task 6 |
| R11 | `intention.ts` 的 `intentionNode` 函数逻辑未修改 | Task 6（验证） |
| R12 | `tsc --noEmit` 零错误 | Task 7 |
| R13 | deep/simple 图不受影响（`agent` wiring 未改） | Task 7（回归） |
| R14 | `evaluateRouterThreshold` 自动调参：触发条件 + apply/rollback 闭环 | Task 6（子任务） |
