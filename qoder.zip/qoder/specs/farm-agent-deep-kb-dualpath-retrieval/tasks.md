# Tasks: KB 双路径检索与矛盾裁决

## Preconditions

- [ ] Expert Grounding RAG 适配已完成（groundingStatus 字段可用）
- [ ] LlmTopHeader.vue 已维护 selectedProjectId 状态
- [ ] Plan Review 全量回流完成

## Forbidden

- 禁止在 retrieval 节点内做路由决策（必须调用 caijuehub）
- 禁止跳过 record_dev_operation（每个 Task 完成后记录 ADD-7）
- 禁止第 1 轮提前实现 interrupt() 调用

---

## 第 1 轮：双路检索上线

### Phase 1.1: 裁决策略层

- [ ] Task 1.1.1: RetrievalRoutingPlan + resolveRetrievalRouting() → `src/caijuehub/strategies/retrieval-routing.ts`
- [ ] Task 1.1.2: RetrievalConfidenceHint + resolveRetrievalConfidence() → `src/caijuehub/strategies/retrieval-confidence.ts`
- [ ] Task 1.1.3: retrieval-stats.ts 统计收集器（静默） → `src/services/retrieval-stats.ts`
- [ ] Task 1.1.4: agentAuditRetrieval 扩展 expertId + distances[] → `src/lib/agent-audit-logger.ts`

### Phase 1.2: projectId 全链路

- [ ] Task 1.2.1: Prisma schema Document.projectId String? → Int? → `prisma/schema.prisma`
- [ ] Task 1.2.2: ChromaDB metadata 写入 projectId → `src/services/knowledge-indexer.ts`
- [ ] Task 1.2.3: upload route FormData projectId parseInt → `src/app/api/knowledge/upload/route.ts`
- [~] Task 1.2.4: 存量 chunk projectId 回填 → `scripts/backfill-projectId.ts`（暂不执行：[P1#8] 单项目存量小，手动重传即可覆盖；脚本已就绪）

### Phase 1.3: State 与类型扩展

- [ ] Task 1.3.1: evidence 向量信号字段类型扩展 → `src/agents/state.ts`
- [ ] Task 1.3.2: KBDisagreementPayload 类型定义 → `src/agents/state.ts`

### Phase 1.4: retrieval 节点改造

- [ ] Task 1.4.1: 调用 resolveRetrievalRouting() 替代三元判断 → `src/agents/nodes/retrieval.ts`
- [ ] Task 1.4.2: 按 plan.searches 并行检索 + 向量信号暴露 → `src/agents/nodes/retrieval.ts`

### Phase 1.5: Graph 集成（第 1 轮）

- [ ] Task 1.5.1: 移除 kbClaimExtractor/kbConflictResolver 节点引用 → `src/agents/index.ts`
- [ ] Task 1.5.2: reasoning 节点消费 promptHint（不调 interrupt） → `src/agents/nodes/reasoning.ts`

### Phase 1.6: 前端 projectId 管理

- [ ] Task 1.6.1: customization 文档列表 projectId 过滤 → `../agrisynapse/src/views/llm/customization/index.vue`
- [ ] Task 1.6.2: grounding API 支持 projectId 参数 → `../agrisynapse/src/api/knowledge/grounding.ts`

### Phase 1.7: 编译验证

- [ ] Task 1.7.1: `npx tsc --noEmit`（farm-agent）
- [ ] Task 1.7.2: `cd ../agrisynapse && npx vue-tsc --noEmit`

---

## 第 2 轮：矛盾裁决交互

> **前置**：第 1 轮 evidence 向量信号已可用。

### Phase 2.1: reasoning interrupt 触发

- [x] Task 2.1.1: reasoning 双路检测(distagap > 0.3) → interrupt() → `src/agents/nodes/reasoning.ts`
- [x] Task 2.1.2: interrupt 前调用 agentAuditKBDisagreement()（KB_DISAGREEMENT 事件） → 同上
- [x] Task 2.1.3: resume 后注入 userChoice + userNote 继续推理 → 同上
- [x] Task 2.1.4: AgentAuditPhase 新增 KB_DISAGREEMENT → `src/lib/agent-audit-logger.ts`

### Phase 2.2: SSE interrupt 协议与 API

- [x] Task 2.2.1: stream/route.ts 检测 __interrupt__ chunk → SSE event → `src/app/api/agent/stream/route.ts`
- [x] Task 2.2.2: /api/agent/resume 端点 → `src/app/api/agent/resume/route.ts`

### Phase 2.3: 前端交互点卡片

- [x] Task 2.3.1: SSE interrupt 事件 → 渲染交互卡片（选项 + 补充说明） → `../agrisynapse/src/views/llm/components/LlmChatView.vue`
- [x] Task 2.3.2: 用户提交 → POST resume → 卡片消失 → 流继续 → `../agrisynapse/src/store/modules/agentChat.ts` + `../agrisynapse/src/api/llm/agent/index.ts`

### Phase 2.4: 集成验证

- [x] Task 2.4.1: `npx tsc --noEmit`（farm-agent）
- [x] Task 2.4.2: `cd ../agrisynapse && npx vue-tsc --noEmit`
- [ ] Task 2.4.3: 端到端：模拟矛盾 → interrupt → 卡片 → resume → 输出（原因：需运行时环境）

## Task Dependencies

第 1 轮:
  Phase 1.1, 1.2, 1.3 → 1.4 → 1.5.2
  Phase 1.2 → 1.6
  Phase 1.2 完成后 → 1.2.4（回填脚本）

第 2 轮（依赖第 1 轮 Phase 1.4 evidence 信号）:
  Phase 2.1 → 2.2 → 2.3 → 2.4

## Verification

- [x] 第 1 轮 `tsc --noEmit` 通过
- [x] 第 2 轮 `tsc --noEmit` 通过
- [x] 双仓库 vue-tsc 通过
- [x] ADD-7 审计记录覆盖全部 Phase（8 条）
- [ ] 端到端运行时验证（需联调环境）

## Spec 偏差记录

| Spec 项 | Spec 描述 | 实际实现 | 原因 |
|---------|----------|---------|------|
| R2.1 Scenario 1 | LLM 判定结论相反 → interrupt() | 双路 kbSources 检测 + distagap > 0.3 → interrupt() | 开发中简化：向量距离差比 LLM 结论比较更稳定，且 handoff 要求"距离差仅展示参考"需要先有距离差数据才能展示 |
