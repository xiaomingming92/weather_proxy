# KB 双路径检索与矛盾裁决 Spec

## Why

当前 retrieval 节点 `groundingReady ? expertCollection : globalFallback` 三元判断缺少项目知识库裁剪路径和双路矛盾裁决能力。

## What Changes

- retrieval 节点从三元判断升级为 caijuehub 裁决层策略驱动
- ChromaDB metadata 新增 projectId，evidence 新增向量信号字段
- reasoning 消费向量信号，第 2 轮叠加 interrupt() 暂停等用户裁决
- SSE interrupt 协议 + resume 端点 + 前端交互卡片
- 审计日志 KB_DISAGREEMENT（severity: HIGH）

**分 2 轮交付**：第 1 轮双路检索上线（项目+全局并行），第 2 轮矛盾裁决交互（interrupt→卡片→resume）。

## Impact

- Affected specs: 无
- Affected code: 16 文件（跨 farm-agent + agrisynapse）
- 父 Plan: `farm-agent-deep-kb-dualpath-retrieval-plan-v1.md`

## Boundaries

禁止：KBClaim / kbConflictResolver / 方案 B 基线 / 自动裁决 / ACA 多专家冲突

---

## 第 1 轮 Requirements：双路检索上线

### R1.1 projectId 全链路打通

#### Scenario: Document.projectId 类型统一为 Int

- **WHEN** `prisma/schema.prisma` 执行 `Int?` 类型变更 + migration
- **THEN** 链路中不再需要 String→Int 边界转换（仅上传路由做一次 FormData→Int）

#### Scenario: 上传时 projectId 写入

- **WHEN** POST /api/knowledge/upload 收到 FormData 含 projectId 字段（字符串）
- **THEN** `parseInt(projectId)` 转为 number 写入 `Document.projectId`

#### Scenario: 存量 chunk 回填 projectId

> ⚠️ **[P1#8] 暂不执行**：脚本 `scripts/backfill-projectId.ts` 已就绪，当前仅一个项目接入，存量小，手动重新上传即可覆盖。多项目接入后再执行。

- **WHEN** 执行 `scripts/backfill-projectId.ts`
- **THEN** 读 Prisma Document.projectId → 按 documentId 匹配 ChromaDB chunk → batch update metadata
- **AND** 回填后 ChromaDB `farm_agent` collection 的所有 chunk metadata 含 projectId（number）

### R1.2 知识索引 projectId 写入

#### Scenario: 新文档索引

- **WHEN** knowledge-indexer 索引新文档
- **THEN** 从 Document.projectId 读取 → 写入每条 chunk 的 ChromaDB metadata.projectId

### R1.3 检索路由策略裁决

#### Scenario: 有 projectId

- **WHEN** AgentState 含 projectId
- **THEN** `resolveRetrievalRouting()` 产出 plan 含两类 search：`projectId` 过滤的 farm_agent 搜索 + 无过滤的 farm_agent 全局搜索
- **AND** 每条 evidence 标记 kbSources（"project_kb" / "global_kb"）

#### Scenario: 无 projectId

- **WHEN** AgentState 无 projectId
- **THEN** `resolveRetrievalRouting()` 产出单路全局搜索 plan
- **AND** retrieval 不触发双路流程

#### Scenario: grounding 就绪时的检索路径

- **WHEN** groundingStatus 为 GROUNDED 且 expert 有对应 collection
- **THEN** plan.searches 增加 expert collection 搜索
- **AND** 所有 search 并行执行（Promise.all），不串行

### R1.4 retrieval 节点消费策略

#### Scenario: 策略驱动检索

- **WHEN** retrieval 节点执行
- **THEN** 移除 `groundingReady ? collectionSearch : fallbackSearch` 三元判断
- **AND** 改为 `const plan = resolveRetrievalRouting(state)`
- **AND** 按 `plan.searches` 并行检索

### R1.5 向量信号暴露

#### Scenario: ChromaDB 结果附加信号

- **WHEN** retrieval 从 ChromaDB 获取 top-k chunk
- **THEN** 每条 evidence 附带：
  - `vectorDistance` — ChromaDB 返回的 distance 值
  - `chunkMethod` — 从 metadata 提取的切块方案（"smart" / "fixed" / "unknown"）
  - `kbSources` — 根据 search 路径标记的来源集合
- **AND** 信号字段为只读，不改写原始 content

### R1.6 置信度提示注入

#### Scenario: reasoning 消费 promptHint

- **WHEN** reasoning 节点获取 evidence（含向量信号）
- **THEN** 调用 `resolveRetrievalConfidence(evidence)` 生成 promptHint
- **AND** promptHint 注入 reasoning system message：指导 LLM 比较同批次 evidence 的 vectorDistance

### R1.7 审计日志扩展

#### Scenario: RETRIEVAL_RESULT 附加向量信号

- **WHEN** `agentAuditRetrieval()` 被调用
- **THEN** metadata 新增 `expertId` + `distances[]`（每条含 chunkId / distance / chunkMethod / kbSources）

### R1.8 Graph 集成（第 1 轮）

#### Scenario: 移除废弃节点

- **WHEN** `index.ts` 编译
- **THEN** kbClaimExtractor / kbConflictResolver 节点引用已删除
- **AND** retrieval → reasoning 边正常

#### Scenario: reasoning 消费向量信号（仅在 system message 层面，不调用 interrupt）

- **WHEN** reasoning 节点运行
- **THEN** system message 含 promptHint
- **AND** LLM 基于向量信号自主融合证据，不触发 interrupt

### R1.9 前端 projectId 管理

#### Scenario: customization 按项目过滤文档

- **WHEN** agrisynapse customization 页面加载
- **THEN** 文档列表可按 `selectedProjectId` 过滤
- **AND** 上传文档自动携带当前 projectId

#### Scenario: grounding API 支持 projectId

- **WHEN** 调用 `getDocuments()` / `getGroundingStats()`
- **THEN** 支持 projectId 参数过滤

---

## 第 2 轮 Requirements：矛盾裁决交互

> **前置条件**：第 1 轮已交付 evidence 向量信号字段（vectorDistance / chunkMethod / kbSources）。

### R2.1 KB 矛盾检测与 interrupt

#### Scenario: LLM 判定双方结论相反

- **WHEN** reasoning LLM 收到项目 KB 和全局 KB 的证据（均带向量信号）
- **AND** LLM 判定结论相反
- **THEN** 调用 `interrupt({ type: "kb_disagreement", projectEvidence, globalEvidence, options, notePlaceholder })`
- **AND** 调用 `agentAuditKBDisagreement()` 记录审计事件（severity: HIGH）
- **AND** 图暂停

#### Scenario: LLM 判定无矛盾或互补

- **WHEN** reasoning LLM 判定双方结论一致或互补
- **THEN** 正常融合输出，不触发 interrupt

### R2.2 SSE interrupt 协议

#### Scenario: stream 检测 interrupt chunk

- **WHEN** LangGraph stream 输出 `__interrupt__` chunk
- **THEN** `stream/route.ts` 检测后发送 SSE event：`{ type: "interrupt", payload: { type: "kb_disagreement", ... } }`
- **AND** 前端接收后渲染交互点卡片

#### Scenario: resume 端点接收用户选择

- **WHEN** POST /api/agent/resume 收到 `Command({ resume: { choice: "采纳项目建议", note: "地块偏沙性" } })`
- **THEN** 调用 `streamAgent(Command(resume=...), config)` 从中断点继续 SSE 流
- **AND** reasoning 节点上下文注入 userChoice + userNote，基于用户裁决重新推理

### R2.3 前端交互点卡片

#### Scenario: 卡片渲染

- **WHEN** 前端收到 SSE interrupt 事件
- **THEN** 在 LlmChatView 中渲染交互点卡片：展示矛盾双方摘要 + 选项按钮 + 补充说明输入框

#### Scenario: 用户提交裁决

- **WHEN** 用户选择选项并可选填写补充说明，点击提交
- **THEN** 前端 POST /api/agent/resume 携带 `{ choice, note }`
- **AND** 卡片消失，流式响应继续

### R2.4 KB_DISAGREEMENT 审计日志

#### Scenario: 矛盾检测时记录（interrupt 前）

- **WHEN** reasoning 判定结论相反 → 调用 interrupt 前
- **THEN** `agentAudit("KB_DISAGREEMENT", ...)` 记录：
  - projectEvidence: { chunkId, distance, content }
  - globalEvidence: { chunkId, distance, content }
  - distanceGap: 双方距离差
  - severity: "HIGH"

#### Scenario: 用户裁决后补充记录

- **WHEN** resume 端点收到用户选择
- **THEN** 同一 KB_DISAGREEMENT 事件补充 userChoice + userNote
