# Checklist: KB 双路径检索与矛盾裁决

## 第 1 轮：双路检索上线

### Phase 1.1: 裁决策略层

- [ ] 1.1.1 retrieval-routing.ts resolveRetrievalRouting() 输入 projectId+expertIds+groundingStatus → 输出 plan.searches
- [ ] 1.1.2 retrieval-confidence.ts promptHint 生成（方案 A），reasoning 可注入 system message
- [ ] 1.1.3 retrieval-stats.ts 查询 AuditLog 按 expertId 分组计算分位数（静默运行）
- [ ] 1.1.4 agentAuditRetrieval metadata 含 expertId + distances[]

### Phase 1.2: projectId 全链路

- [ ] 1.2.1 Prisma Document.projectId 类型为 Int?，migrate 无报错
- [ ] 1.2.2 knowledge-indexer.ts metadata 写入 projectId（number），ChromaDB chunk 可查到
- [ ] 1.2.3 upload route FormData projectId parseInt → number，写入 Document.projectId
- [~] 1.2.4 backfill-projectId.ts 暂不执行（[P1#8] 单项目存量小，手动重传即可；脚本已就绪）

### Phase 1.3: State 类型扩展

- [ ] 1.3.1 evidence 类型含 vectorDistance/chunkMethod/kbSources 字段
- [ ] 1.3.2 KBDisagreementPayload 类型编译通过

### Phase 1.4: retrieval 节点改造

- [ ] 1.4.1 retrieval.ts 内无 `groundingReady ? x : y` 三元判断
- [ ] 1.4.2 evidence 含 vectorDistance / chunkMethod / kbSources

### Phase 1.5: Graph 集成

- [ ] 1.5.1 kbClaimExtractor/kbConflictResolver 节点引用已从 index.ts 移除
- [ ] 1.5.2 reasoning system message 含 promptHint（不调用 interrupt）

### Phase 1.6: 前端 projectId

- [ ] 1.6.1 customization 文档列表可按 projectId 过滤
- [ ] 1.6.2 grounding API 支持 projectId 参数

### Phase 1.7: 编译验证

- [ ] 1.7.1 farm-agent `npx tsc --noEmit` 通过
- [ ] 1.7.2 agrisynapse `vue-tsc --noEmit` 通过

---

## 第 2 轮：矛盾裁决交互

> 前置：第 1 轮全部 [x]，evidence 向量信号可用

### Phase 2.1: reasoning interrupt

- [x] 2.1.1 双路 evidence 检测(distagap > 0.3) → interrupt() 触发 [reasoning.ts:271-342]
- [x] 2.1.2 interrupt 前 agentAuditKBDisagreement() 已调用 [reasoning.ts:310-322]
- [x] 2.1.3 resume 后 userChoice + userNote 注入上下文，继续推理 [reasoning.ts:345-365]
- [x] 2.1.4 AgentAuditPhase 含 KB_DISAGREEMENT，agentAuditKBDisagreement() 可调用 [agent-audit-logger.ts:71,274]

### Phase 2.2: SSE interrupt 协议

- [x] 2.2.1 stream/route.ts 检测 __interrupt__ chunk → SSE event: interrupt [stream/route.ts:35-43]
- [x] 2.2.2 POST /api/agent/resume 接收 Command({ resume: { choice, note } }) → 恢复 SSE 流 [resume/route.ts:44-46]

### Phase 2.3: 交互点卡片

- [x] 2.3.1 收到 SSE interrupt → 渲染卡片（选项 + 补充说明输入框） [LlmChatView.vue:189-261]
- [x] 2.3.2 用户选择+提交 → POST resume → 卡片消失 → 流继续 [LlmChatView.vue:770-782, agentChat.ts:381-408]

### Phase 2.4: 集成验证

- [x] 2.4.1 farm-agent `npx tsc --noEmit` 通过
- [x] 2.4.2 agrisynapse `vue-tsc --noEmit` 通过（仅预存错误）
- [ ] 2.4.3 端到端：模拟矛盾 → interrupt → 卡片 → resume → 输出（原因：需运行时联调环境）

## ADD 规则合规检查

- [ ] ADD-1 可观测性优先：每个 Task 有独立 agentAudit 调用
- [ ] ADD-2 阶段标记对称：KB_DISAGREEMENT 命名与 Plan 一致
- [ ] ADD-4 三通道输出：console + file + AuditLog
- [ ] ADD-5 审计数据即业务数据：KB_DISAGREEMENT severity: HIGH
- [ ] Plan/Spec 一致性：Spec Requirements 分轮结构与 Plan §4 一致

## 跨项目联调检查

### 格式契约
- [T] interrupt SSE event: `{ type: "interrupt", payload: { type: "kb_disagreement", ... } }`
- [T] resume Command: `{ resume: { choice: string, note?: string } }`

### 数据模型
- [T] ChromaDB metadata.projectId 类型 number ≡ Document.projectId Int?
- [T] agentAuditRetrieval 扩展 expertId + distances

### API 选择
- [T] /api/agent/stream 现有 SSE 协议，新增 interrupt chunk
- [T] /api/agent/resume 独立端点，内部调用 streamAgent(Command)

> **[T]** 项全部通过后，生成 review-implementation.md。**[R]** 项流转到 review-runtime.md。
