# Tasks: farm-agent-project-context-activation

## Phase 1: 上下文扩展

- [ ] Task 1: 扩展 farm-project-context — 验证: tsc=0
  - [ ] 新增 projectIds[] + getter/setter
  - [ ] 新增 activedProjectId + getter/setter
  - [ ] getFarmProjectId() 改为返回 activedProjectId
  - [ ] setFarmProjectId() 同时设置 activedProjectId

- [ ] Task 2: 同步 DTO + Zod — 验证: tsc=0
  - [ ] `src/dto/agent.dto.ts` 补充 projectId + activedProjectId
  - [ ] `src/app/api/types/` Zod schema 补充字段

## Phase 2: 端点实现

- [ ] Task 3: handshake 保存 — 验证: curl handshake
  - [ ] handleHandshakePOST 中保存 projectId 到 context

- [ ] Task 4: activate-project POST — 验证: curl POST
- [ ] Task 5: activate-project GET — 验证: curl GET
