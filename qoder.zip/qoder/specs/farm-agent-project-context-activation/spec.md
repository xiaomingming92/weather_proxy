# farm-agent-project-context-activation Spec

## Why

神经元前端透传 projectId 数组和 activedProjectId 后，agent 侧需要保存并暴露给 LLM 推理/工具调用。

## What Changes

- `farm-project-context.ts`：新增 `projectIds[]`、`activedProjectId`、getter/setter
- `agent/[hash]/route.ts`：handshake 保存 + activate-project 端点

## Impact

- Affected code: 4 files
- 依赖: 无
- 后续依赖: 16 专家/tool 调用可消费 activedProjectId

## ADDED Requirements

### Requirement: handshake 透传 projectId
- **WHEN** handshake 携带 `userVO.projectId` 和 `userVO.activedProjectId`
- **THEN** `setFarmProjectIds()` 和 `setActivedProjectId()` 被调用

### Requirement: activate-project 端点
- **WHEN** `POST { type: "activate-project", projectId: N }` 或 `GET ?action=activateProject&projectId=N`
- **THEN** `setActivedProjectId(N)` 被调用，返回 `{ activedProjectId: N }`

### Requirement: 向后兼容
- **WHEN** 旧调用方调用 `setFarmProjectId(N)`
- **THEN** `activedProjectId` 也被设为 N，`getFarmProjectId()` 返回 N
