# Tasks: 瑞丰耘H5 API v2（阶段1：API 脚手架）

## Preconditions
- [ ] Plan v1 全部端点已上线运行
- [ ] 数据库可连接，Prisma migrate 可用
- [ ] 小程序后台已确认 API Key 方案

## Forbidden
- 禁止修改 Farm-Server API 调用逻辑
- 禁止删除 H5Session 表（保留兼容）
- 禁止实现 generate 端点的 LLM 聚合逻辑（阶段2）

---

## Phase 1: 基础设施

- [ ] Task 1: Prisma ServiceAccount 模型
  - [ ] 在 schema.prisma 新增 ServiceAccount 模型
  - [ ] 执行 migrate dev
  - [ ] 添加种子脚本或手动插入测试记录
  - [ ] 验证：prisma.serviceAccount.findFirst() 可查

- [ ] Task 2: h5-auth-gateway 双模式扩展
  - [ ] H5AuthMode 加 "service"
  - [ ] H5AuthGatewayDecision 加 serviceAccountId
  - [ ] resolveH5AuthGateway 签名为 (apiKey, sessionId)
  - [ ] 优先查 ServiceAccount 表 → service 模式
  - [ ] 降级查 H5Session 表 → session 模式
  - [ ] agent-audit-logger.ts 新增 SERVICE_AUTH 阶段
  - [ ] 验证：curl 无 Key → 401；有 Key → 200

- [ ] Task 3: 路径迁移（3个端点）
  - [ ] 目录名重命名 land-analysis → production-plan/land-analysis
  - [ ] 目录名重命名 variety-recommend → production-plan/variety-recommend
  - [ ] 目录名重命名 cost-accounting → production-plan/cost-accounting
  - [ ] 三路由认证方式 X-Session-Id → X-Api-Key
  - [ ] 提取 resolveServiceAuth 辅助函数
  - [ ] Farm-Server token 改为 ensureValidToken(0, "service")
  - [ ] 验证：新路径可访问，旧路径 404

## Phase 2: 新增 + 改造端点

- [ ] Task 4: 新增 generate 端点（假数据）
  - [ ] 新建 production-plan/generate/route.ts
  - [ ] POST 端点，X-Api-Key 认证
  - [ ] 返回硬编码 JSON（coreMetrics/plots/growthSchedule/materials/risks）
  - [ ] agent-audit-logger.ts 新增 H5_PLAN_GENERATE 阶段
  - [ ] traceId: h5_gen_<uuid>
  - [ ] 验证：curl 返回假数据 JSON

- [ ] Task 5: 改造 agent 端点
  - [ ] 移除 type: "handshake" 处理分支
  - [ ] 认证切换：X-Api-Key → service 模式
  - [ ] 从 body.userId 直建 ChatThread（source="h5"）
  - [ ] 移除 h5-handshake-thread.ts import
  - [ ] FarmServerCredential source 改为 "service"
  - [ ] 验证：curl 聊天正常 SSE 流式推送

- [ ] Task 6: 废弃 handshake 端点
  - [ ] 删除 src/app/api/h5/handshake/route.ts
  - [ ] h5-handshake-thread.ts 标记 deprecated 注释
  - [ ] H5Session 模型标记 deprecated（不下线）
  - [ ] 验证：旧 handshake 路径 404

## Phase 3: 验证

- [ ] Task 7: 编译 + curl 端到端验证
  - [ ] npx tsc --noEmit 零错误
  - [ ] curl land-analysis 新路径
  - [ ] curl variety-recommend 新路径
  - [ ] curl cost-accounting 新路径
  - [ ] curl generate 新路径
  - [ ] curl agent 聊天 SSE
  - [ ] curl 旧路径 → 404

## Task Dependencies
- Task 2 依赖 Task 1（ServiceAccount 表存在才能校验 API Key）
- Task 3/4/5 可并行（均依赖 Task 2 的 auth-gateway）
- Task 6 可并行（删除独立路由）
- Task 7 依赖 Task 1-6 全部完成

## Verification
- [ ] npx tsc --noEmit
- [ ] npm run lint（无新增问题）
- [ ] 全部 curl 验证通过
