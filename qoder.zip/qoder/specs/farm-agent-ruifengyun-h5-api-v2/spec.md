# 瑞丰耘H5 API v2 Spec

## Why

小程序对接方式从「前端直连」改为「后台中转」，认证模型从 per-user 握手改为服务账户 API Key。同时按 demo 页面的「生产计划」业务域重新组织 API 路径，并补全缺失的 Step 5 计划生成端点。

## What Changes

### 新增文件
- `src/app/api/h5/production-plan/generate/route.ts` — 计划生成端点（阶段1：假数据）

### 修改文件
- `prisma/schema.prisma` — 新增 ServiceAccount 模型
- `src/caijuehub/strategies/h5-auth-gateway.ts` — 双模式裁决（service + session）
- `src/app/api/h5/agent/route.ts` — 移除 handshake type，加 body.userId
- `src/lib/agent-audit-logger.ts` — 新增 SERVICE_AUTH + H5_PLAN_GENERATE 阶段

### 路径迁移
- `src/app/api/h5/land-analysis/route.ts` → `src/app/api/h5/production-plan/land-analysis/route.ts`
- `src/app/api/h5/variety-recommend/route.ts` → `src/app/api/h5/production-plan/variety-recommend/route.ts`
- `src/app/api/h5/cost-accounting/route.ts` → `src/app/api/h5/production-plan/cost-accounting/route.ts`

### 删除文件
- `src/app/api/h5/handshake/route.ts` — 废弃 per-user 握手

## Impact

- **Affected specs**: `farm-agent-ruifengyun-h5-api`（v1）
- **Affected code**: h5-auth-gateway.ts, agent/route.ts, agent-audit-logger.ts, schema.prisma
- **父 Plan**: `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v2.md`
- **依赖**: 上游 v1 端点已全部上线；下游：小程序后台消费新路径

## Boundaries

**本次实现（阶段1）**：
- ServiceAccount 模型 + API Key 认证通道
- 3 个业务端点路径迁移 + 认证切换
- 新增 generate 端点（假数据）
- agent 端点去 handshake + body.userId 线程隔离
- 废弃 handshake 端点

**本次禁止**：
- 不实现 generate 端点的 LLM 聚合逻辑（阶段2）
- 不删除 H5Session 表（保留兼容过渡期）
- 不修改 Farm-Server API 调用方式

## ADDED Requirements

### Requirement: 服务账户 API Key 认证

#### Scenario: 合法 API Key 访问业务端点
- **WHEN** 小程序后台 POST `/api/h5/production-plan/*` 并在 Header 携带 `X-Api-Key: svc_xxx`
- **THEN** h5-auth-gateway 查 ServiceAccount 表 → 匹配成功 → service 模式 → 使用服务账户 token 调 Farm-Server → 正常返回

#### Scenario: 无效或缺失 API Key
- **WHEN** 请求无 `X-Api-Key` Header 或 Key 不匹配
- **THEN** 返回 `{ code: 401, message: "认证失败" }`

### Requirement: 生产计划路径迁移

#### Scenario: 新路径可访问
- **WHEN** POST `/api/h5/production-plan/land-analysis` 带合法 API Key
- **THEN** 正常执行业务逻辑并返回结果

#### Scenario: 旧路径不可访问
- **WHEN** POST `/api/h5/land-analysis`（旧路径）
- **THEN** 返回 404

### Requirement: 计划生成端点

#### Scenario: 汇总前三步产出
- **WHEN** POST `/api/h5/production-plan/generate` 带 planName + selectedPlots + landAnalysis + selectedVariety + costEstimate + projectId
- **THEN** 阶段1：返回硬编码假数据 JSON（结构含 coreMetrics/plots/growthSchedule/materials/risks）
- **THEN** 阶段2（后续）：LLM 聚合前三步产出，返回完整生产计划

### Requirement: Agent 聊天端点改造

#### Scenario: 通过 body.userId 隔离对话线程
- **WHEN** POST `/api/h5/agent` 带 `X-Api-Key` + body `{ userId: 10001, type: "chat", messages: [...] }`
- **THEN** 用 userId 查/建 ChatThread（source="h5"），与同 userId 的历史对话关联

#### Scenario: handshake type 不再支持
- **WHEN** POST `/api/h5/agent` 带 `type: "handshake"`
- **THEN** 返回 400 或忽略（handshake 逻辑已移除）

### Requirement: DTO 类型定义与 Zod 校验

#### Scenario: 响应结构通过 Zod 校验
- **WHEN** API 端点返回数据
- **THEN** Zod Schema 校验响应结构 → 通过则返回 Zod 类型，失败则记录 audit + 降级为原始 JSON
