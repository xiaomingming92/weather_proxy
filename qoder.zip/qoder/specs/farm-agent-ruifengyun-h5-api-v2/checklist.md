# Checklist: 瑞丰耘H5 API v2

## 编译期验证 [T]

- [ ] Task 1: ServiceAccount 模型存在且 migrate 成功
- [ ] Task 2: auth-gateway 双模式编译通过
- [ ] Task 3: 新路径三端点可访问，旧路径 404
- [ ] Task 4: generate 端点返回正确结构 JSON
- [ ] Task 5: agent 端点 SSE 流式推送正常
- [ ] Task 6: handshake 端点 404
- [ ] Task 7: `npx tsc --noEmit` 零错误

## 运行时验证 [R]

- [ ] curl `/api/h5/production-plan/land-analysis` 正常返回
- [ ] curl `/api/h5/production-plan/variety-recommend` 正常返回
- [ ] curl `/api/h5/production-plan/cost-accounting` 正常返回
- [ ] curl `/api/h5/production-plan/generate` 返回假数据
- [ ] curl `/api/h5/agent` SSE 聊天正常
- [ ] curl 无 X-Api-Key → 401
- [ ] curl `/api/h5/land-analysis`（旧路径）→ 404
- [ ] curl `/api/h5/handshake` → 404

## ADD 规则合规检查

- [ ] ADD-1: 审计日志可查询（SERVICE_AUTH + H5_PLAN_GENERATE）
- [ ] ADD-2: 阶段标记对称（每个 route 入口 agentAudit 起点 出口终点）
- [ ] ADD-3: 最小可观测单元（每个端点有独立 traceId）
- [ ] ADD-4: 三通道输出（console + file + AuditLog）
- [ ] ADD-5: 审计数据即业务数据
- [ ] ADD-6: 失败路径等价审计（401/400/500 均有审计记录）
- [ ] ADD-7: record_dev_operation 全量落库
