# Project Massif Resolution Spec

## Why

全农场语义的 SkillCard（如"周报分析"）点击后，LLM 调用 `query_insect_data` 等工具时缺 massifId → 必触发 `param_missing` SSE 事件。但"全农场"本意是"对项目下所有地块分析"，不应弹出地块选择器。当前 `activedProjectId` 已在 handshake 时注入上下文，但没有代码自动解析 `projectId → massifIds[]`。

## What Changes

- `src/lib/farm-api/massif.ts`：getPage 支持 projectId 参数；新增 `getAllByProjectId(projectId)`
- `src/lib/farm-project-context.ts`：新增 `resolveProjectMassifIds()` 函数
- `src/agents/state.ts`：新增 `prebuiltMassifIds` Annotation
- `src/agents/agent-runner.ts`：`StreamAgentInput` 新增 `prebuiltMassifIds`
- `src/app/api/agent/chat/stream/route.ts`：chat 请求透传前自动调用 resolveProjectMassifIds
- `src/agents/nodes/intention.ts`：explicitIntent 路径消费 prebuiltMassifIds
- `src/caijuehub/strategies/resolve-tool-params.ts`：available() 检查新增 prebuiltMassifIds

## Impact

- Affected specs: 无（全新功能）
- Affected code: 7 个源文件（见 What Changes）
- 父 Plan: `.qoder/plans/2026-07/06/farm-agent-project-massif-resolution-plan-v1.md`
- 依赖: `farm-agent-thinking-level-runtime-fix-plan-v1`（SkillCard massifIds 字段 + prebuiltThinkingLevel 机制）
- 后续依赖: 无

## ADDED Requirements

### Requirement: Farm-Server 按项目查询全部地块

#### Scenario: 正常解析

- **WHEN** `activedProjectId = 1001` 且 Farm-Server 返回 9 个地块
- **THEN** `resolveProjectMassifIds()` 返回 `[1, 2, 3, 4, 5, 7, 8, 9, 10]`

#### Scenario: 无项目上下文

- **WHEN** `activedProjectId` 为 null
- **THEN** `resolveProjectMassifIds()` 返回 null

#### Scenario: Farm-Server 不可达

- **WHEN** 网络错误或超时
- **THEN** `resolveProjectMassifIds()` 返回 null

### Requirement: 全农场卡片不触发 param_missing

#### Scenario: 全农场卡片 + activedProjectId 有效

- **WHEN** 用户点击"周报分析"卡片（无 massifIds）、activedProjectId=1001、项目下有 9 个地块
- **THEN** intentionNode 自动填充 prebuiltMassifIds=[1,2,3,4,5,7,8,9,10]，工具调用不缺参，不触发 param_missing

#### Scenario: 指定地块卡片不变

- **WHEN** 用户点击"地块虫害分析"卡片（massifIds=[1,2]）
- **THEN** 跳过 projectId 解析，行为与修复前一致

### Requirement: param_missing 作为回退

#### Scenario: activedProjectId 不存在

- **WHEN** 用户未完成 handshake 或 activedProjectId=null
- **THEN** 回退到 param_missing，弹出地块选择器

#### Scenario: 项目下无地块

- **WHEN** resolveProjectMassifIds 返回空数组 `[]`
- **THEN** 回退到 param_missing
