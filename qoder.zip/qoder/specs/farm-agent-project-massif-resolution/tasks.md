# Tasks: Project Massif Resolution

> **验证规范**：每个 Task 完成时必须附带双检证据（`tsc=0` + `eslint 0 errors`）。

## Preconditions

- [x] Plan 已生成
- [x] Spec 已就绪

## Forbidden

- ✅ 禁止修改 Handshake 协议 — 未修改
- ✅ 禁止修改 SkillCard 数据结构 — 未修改
- ✅ 禁止修改 deep/professional 图内部逻辑 — 仅扩展 state/agent-runner 类型
- ✅ 禁止引入新 dependency — 0 新依赖
- ~~禁止修改 LLM 自由对话路径~~ → 已扩大为全路径覆盖

## Round 1 Tasks: farm-api 层 + context 层

- [x] Task 1.1: `src/lib/farm-api/massif.ts` — 新增 `getAllByProjectId(projectId)` + getPage 支持 projectId
  - [x] `getPage()` 签名新增 `projectId?: number` 可选参数，透传至 query params
  - [x] 新增 `getAllByProjectId(projectId: number): Promise<FarmApiResponse<MassifDTO[]>>`，调 `/farm/massif/options?projectId={projectId}`
  - ✅ 验证: `tsc=0` + eslint 零 error

- [x] Task 1.2: `src/lib/farm-project-context.ts` — 新增 `resolveProjectMassifIds()`
  - [x] 读取 `activedProjectId`，null 则返回 null
  - [x] 调用 `createMassifApi(tokenGetter).getAllByProjectId(projectId)` 获取地块列表
  - [x] 成功返回 `data.map(m => m.id)`，失败返回 null
  - [x] `agentAudit("PROJECT_MASSIF_RESOLVE", ...)` 记录成功/失败
  - [x] phase.ts 新增 `ProjectMassifPhase` 子类型
  - ✅ 验证: `tsc=0` + eslint 零 error

## Round 2 Tasks: state + route + intention 消费端串联

- [x] Task 2.1: `src/agents/state.ts` — 新增 `prebuiltMassifIds` Annotation
  - [x] `prebuiltMassifIds: Annotation<number[] | null>()` (L134)
  - ✅ 验证: `tsc=0`

- [x] Task 2.2: `src/agents/agent-runner.ts` — `StreamAgentInput` 新增 `prebuiltMassifIds`
  - [x] `prebuiltMassifIds?: number[] | null` (L46)
  - ✅ 验证: `tsc=0`

- [x] Task 2.3: `src/app/api/agent/chat/stream/route.ts` — 调用 `resolveProjectMassifIds`
  - [x] `streamAgent` 前无条件 try/catch 调用 `resolveProjectMassifIds()` (L264-272)
  - [x] 注入 `prebuiltMassifIds` 至 `StreamAgentInput` (L283)
  - ✅ 验证: `tsc=0` + eslint 零 error

- [x] Task 2.4: `src/agents/nodes/intention.ts` — explicitIntent 路径消费 prebuiltMassifIds
  - [x] prebuiltMassifIds 有值时 `agentAudit("PROJECT_MASSIF_PREFILL", ...)` (L173-177)
  - ✅ 验证: `tsc=0` + eslint 零 error

## Round 3 Tasks: resolve-tool-params 补位 + 全量验证

- [x] Task 3.1: `src/caijuehub/strategies/resolve-tool-params.ts` — available() 扩展
  - [x] 3 个规则的 `available()` 新增 `(s.prebuiltMassifIds?.length ?? 0) > 0` (L36/43/50)
  - ✅ 验证: `tsc=0`

- [x] Task 3.2: 全量验证
  - [x] `npx tsc --noEmit` 零错误
  - [x] `npx eslint src/` 零 error

## Task Dependencies

- Task 2.x 全部依赖 Task 1.x
- Task 3.1 依赖 Task 2.1 (prebuiltMassifIds Annotation 类型)
- Task 3.2 依赖全部 Task

## Verification

- [x] `npx tsc --noEmit` 零错误
- [x] `npx eslint src/` 零 error
# Tasks: Project Massif Resolution

> **验证规范**：每个 Task 完成时必须附带双检证据（`tsc=0` + `eslint 0 errors`）。

## Preconditions

- [x] Plan 已生成
- [x] Spec 已就绪

## Forbidden

- 禁止修改 Handshake 协议
- 禁止修改 SkillCard 数据结构
- 禁止修改 deep/professional 图内部逻辑
- 禁止引入新 dependency
- 禁止修改 LLM 自由对话路径（本 Plan 仅覆盖 explicitIntent 路径）

## Round 1 Tasks: farm-api 层 + context 层

- [ ] Task 1.1: `src/lib/farm-api/massif.ts` — 新增 `getAllByProjectId(projectId)` + getPage 支持 projectId
  - [ ] `getPage()` 签名新增 `projectId?: number` 可选参数，透传至 query params
  - [ ] 新增 `getAllByProjectId(projectId: number): Promise<FarmApiResponse<MassifDTO[]>>`，调 `/farm/massif/options?projectId={projectId}`
  - 验证: `tsc=0` + eslint 零 error

- [ ] Task 1.2: `src/lib/farm-project-context.ts` — 新增 `resolveProjectMassifIds()`
  - [ ] 读取 `activedProjectId`，null 则返回 null
  - [ ] 调用 `createMassifApi(tokenGetter).getAllByProjectId(projectId)` 获取地块列表
  - [ ] 成功返回 `data.map(m => m.id)`，失败返回 null
  - [ ] `agentAudit("PROJECT_MASSIF_RESOLVE", ...)` 记录成功/失败
  - 验证: `tsc=0` + eslint 零 error + resolveProjectMassifIds 函数可导出

## Round 2 Tasks: state + route + intention 消费端串联

- [ ] Task 2.1: `src/agents/state.ts` — 新增 `prebuiltMassifIds` Annotation
  - [ ] `prebuiltMassifIds: Annotation<number[] | null>()`
  - 验证: `tsc=0`

- [ ] Task 2.2: `src/agents/agent-runner.ts` — `StreamAgentInput` 新增 `prebuiltMassifIds`
  - [ ] `prebuiltMassifIds?: number[] | null`
  - 验证: `tsc=0`

- [ ] Task 2.3: `src/app/api/agent/chat/stream/route.ts` — 调用 `resolveProjectMassifIds`
  - [ ] 在 `streamAgent` 调用前，若 `expertIds` 有值且 `massifId`/`subIntents.massifIds` 均无
  - [ ] 调用 `resolveProjectMassifIds()`，注入 `prebuiltMassifIds` 至 `StreamAgentInput`
  - 验证: `tsc=0` + eslint 零 error

- [ ] Task 2.4: `src/agents/nodes/intention.ts` — explicitIntent 路径消费 prebuiltMassifIds
  - [ ] L151 explicitIntent 分支：检查 `state.prebuiltMassifIds`，有值则跳过解析
  - [ ] L158 构建 `builtSubIntents`：若有 prebuiltMassifIds，在 subQuery 中注入地块上下文
  - [ ] `agentAudit("PROJECT_MASSIF_PREFILL", ...)` 记录填充
  - 验证: `tsc=0` + eslint 零 error

## Round 3 Tasks: resolve-tool-params 补位 + 全量验证

- [ ] Task 3.1: `src/caijuehub/strategies/resolve-tool-params.ts` — available() 扩展
  - [ ] 3 个规则的 `available()` 新增 `(s.prebuiltMassifIds?.length ?? 0) > 0`
  - 验证: `tsc=0`

- [ ] Task 3.2: 全量验证
  - [ ] `npx tsc --noEmit` 零错误
  - [ ] `npx eslint src/` 零 error

## Task Dependencies

- Task 2.x 全部依赖 Task 1.x
- Task 3.1 依赖 Task 2.1 (prebuiltMassifIds Annotation 类型)
- Task 3.2 依赖全部 Task

## Verification

- [ ] `npx tsc --noEmit` 零错误（Round 3 完成时）
- [ ] `npx eslint src/` 零 error（Round 3 完成时）
