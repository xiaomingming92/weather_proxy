# Checklist: Project Massif Resolution

> **证据规范**：每项 [x] 必须附带可验证证据。`[T]` = 编译期验证，`[R]` = 运行时验证。

## 一、编译与 Lint 门禁

- [x] [T] tsc 零错误 — 证据: `npx tsc --noEmit 2>&1 | wc -l` → 0
- [x] [T] ESLint 零 error — 证据: `npx eslint src/ 2>&1` → 0 errors, 9 warnings (均非本次改动文件)
- [x] [T] massif.ts getAllByProjectId 函数存在 — 证据: `grep -n "getAllByProjectId" src/lib/farm-api/massif.ts` → L74
- [x] [T] farm-project-context.ts resolveProjectMassifIds 函数存在 — 证据: `grep -n "resolveProjectMassifIds" src/lib/farm-project-context.ts` → L72
- [x] [T] state.ts prebuiltMassifIds Annotation 存在 — 证据: `grep -n "prebuiltMassifIds" src/agents/state.ts` → L134
- [x] [T] agent-runner.ts StreamAgentInput 含 prebuiltMassifIds — 证据: `grep -n "prebuiltMassifIds" src/agents/agent-runner.ts` → L46
- [x] [T] resolve-tool-params.ts available() 检查 prebuiltMassifIds — 证据: `grep -n "prebuiltMassifIds" src/caijuehub/strategies/resolve-tool-params.ts` → L36,43,50

## 二、业务验收

- [ ] [R] activedProjectId=1001 → resolveProjectMassifIds 返回地块列表（非 null）— 需启动服务 + Farm-Server 网络可达
- [ ] [R] 点击"周报分析"卡片 → query_insect_data 不缺参 → 不触发 param_missing
- [ ] [R] 点击"地块虫害分析"卡片（massifIds=[1,2]）→ 跳过 projectId 解析 → 行为不变
- [ ] [R] activedProjectId=null → 不自动解析 → 触发 param_missing
- [x] [R] Farm-Server 不可达 → 不自动解析 → 触发 param_missing — 证据: route.ts L268-271 try/catch + farm-project-context.ts L107-110 catch 返回 null
- [x] [R] 项目下无地块（空数组）→ 触发 param_missing — 证据: farm-project-context.ts L97-99

## ADD 规则合规检查

- [x] [E] ADD-1 可观测性优先 — 证据: `grep -c "PROJECT_MASSIF" src/lib/farm-project-context.ts src/agents/nodes/intention.ts` → farm-project-context.ts:6, intention.ts:1（共 7 处审计点）
- [ ] [E] ADD-7 审计操作记录 — 证据: `record_dev_operation` 按文件逐条记录（待记录）
# Checklist: Project Massif Resolution

> **证据规范**：每项 [x] 必须附带可验证证据。`[T]` = 编译期验证，`[R]` = 运行时验证。

## 一、编译与 Lint 门禁

- [ ] [T] tsc 零错误 — 证据: `npx tsc --noEmit 2>&1 | wc -l` 输出 0
- [ ] [T] ESLint 零 error — 证据: `npx eslint src/ 2>&1` 无 error 行
- [ ] [T] massif.ts getAllByProjectId 函数存在 — 证据: `grep -n "getAllByProjectId" src/lib/farm-api/massif.ts`
- [ ] [T] farm-project-context.ts resolveProjectMassifIds 函数存在 — 证据: `grep -n "resolveProjectMassifIds" src/lib/farm-project-context.ts`
- [ ] [T] state.ts prebuiltMassifIds Annotation 存在 — 证据: `grep -n "prebuiltMassifIds" src/agents/state.ts`
- [ ] [T] agent-runner.ts StreamAgentInput 含 prebuiltMassifIds — 证据: `grep -n "prebuiltMassifIds" src/agents/agent-runner.ts`
- [ ] [T] resolve-tool-params.ts available() 检查 prebuiltMassifIds — 证据: `grep -n "prebuiltMassifIds" src/caijuehub/strategies/resolve-tool-params.ts`

## 二、业务验收

- [ ] [R] activedProjectId=1001 → resolveProjectMassifIds 返回地块列表（非 null）
- [ ] [R] 点击"周报分析"卡片 → query_insect_data 不缺参 → 不触发 param_missing
- [ ] [R] 点击"地块虫害分析"卡片（massifIds=[1,2]）→ 跳过 projectId 解析 → 行为不变
- [ ] [R] activedProjectId=null → 不自动解析 → 触发 param_missing
- [ ] [R] Farm-Server 不可达 → 不自动解析 → 触发 param_missing
- [ ] [R] 项目下无地块（空数组）→ 触发 param_missing

## ADD 规则合规检查

- [ ] [E] ADD-1 可观测性优先 — 证据: `grep -c "PROJECT_MASSIF" src/lib/farm-project-context.ts src/agents/nodes/intention.ts`
- [ ] [E] ADD-7 审计操作记录 — 证据: `record_dev_operation` 按文件逐条记录
