# Tasks: agrisynapse rehydration 数据结构一致性修复

## Preconditions

- [ ] agrisynapse 项目可正常编译（`npx tsc --noEmit`）
- [ ] farm-agent 项目可正常编译（`npx tsc --noEmit`）
- [ ] 已阅读 Plan 和 Spec 中的三个联动历史 Plan

## Forbidden

- 禁止修改 SSE 流式路径的 `_consumeSSE` / `_dispatchEvent` 方法
- 禁止修改 `response.ts` 的 `structuredResponse` 构建逻辑
- 禁止修改 DB schema
- 禁止引入新的 npm 依赖

---

- [ ] Task 1: agrisynapse rehydration — verdict 字段名归一化
  - [ ] 在 `loadThread` 的 `messages.map` 中增加 verdict.confidence 字段转换函数（camelCase → snake_case）
  - [ ] 与 SSE handler lines 381-392 保持字段转换逻辑一致
  - [ ] 验证：刷新页面后置信度面板数值非 0%

- [ ] Task 2: agrisynapse rehydration — evidenceChain/reasoningPath 嵌套提取
  - [ ] evidenceChain：提取 `metaObj.evidenceChain?.evidences` 数组（回退 `Array.isArray` 兼容已提取的数组）
  - [ ] reasoningPath：提取 `metaObj.reasoningPath?.steps` 数组（回退 `Array.isArray` 兼容已提取的数组）
  - [ ] 验证：刷新页面后证据链面板按证据项逐条渲染，推理路径面板按步骤逐条渲染

- [ ] Task 3: farm-agent tool evidence content 结构化
  - [ ] 将 F2 工具证据 content 从 `tm.content.slice(0,500)` 改为摘要描述
  - [ ] 从 `state.toolResults`（优先）或解析 `tm.content` JSON（降级）获取 `list` 和 `columns`，填充 `data` 字段
  - [ ] 验证：新建对话 → 工具调用后，证据链中 tool_result 的 content 为可读摘要

- [ ] Task 4: agrisynapse tool evidence 回退渲染
  - [ ] 在 `LlmChatView.vue` 证据链 tool 源展开区，当无 `data` 字段时渲染 content 文本摘要
  - [ ] 验证：加载旧线程（无 data 的 tool evidence），展开后不报错、不空白

- [ ] Task 5: 编译验证 + 回归测试
  - [ ] agrisynapse `npx tsc --noEmit` 零错误
  - [ ] farm-agent `npx tsc --noEmit` 零错误
  - [ ] 手动测试：新对话 → SSE 流式正常 → 刷新页面 → 全部结构化数据保持
  - [ ] 手动测试：发送第二条消息 → 上一轮数据不被损坏

## Task Dependencies

- Task 1 和 Task 2 可并行（同一文件 agentChat.ts，同一段代码）
- Task 3 独立于 Task 1/2（farm-agent 侧，无前端依赖）
- Task 4 依赖 Task 3（需要 data 字段存在时走表格渲染，不存在时走回退渲染）
- Task 5 依赖 Task 1-4 全部完成

## Verification

- [ ] `npx tsc --noEmit`（agrisynapse）
- [ ] `npx tsc --noEmit`（farm-agent）
- [ ] 页面刷新后置信度数值正确
- [ ] 页面刷新后证据链列表正确
- [ ] 页面刷新后推理路径列表正确
- [ ] 工具证据 content 为可读摘要
- [ ] 工具证据有 data 时表格正常渲染
- [ ] 工具证据无 data 时回退渲染不报错
