# Checklist: agrisynapse rehydration 数据结构一致性修复

## Phase 1: agrisynapse rehydration 归一化（Task 1 + 2）

- [T] `loadThread` 中 verdict.confidence 字段从 camelCase 转换为 snake_case（baseConfidence→base_confidence 等）
- [T] `loadThread` 中 evidenceChain 从 `{ evidences: [...] }` 提取为 `[...]` 数组
- [T] `loadThread` 中 reasoningPath 从 `{ steps: [...] }` 提取为 `[...]` 数组
- [T] 转换函数与 SSE handler 逻辑一致（可复用时抽取为共享函数）
- [R] 刷新页面后置信度面板数值非 0%
- [R] 刷新页面后证据链面板按证据项逐条渲染
- [R] 刷新页面后推理路径面板按步骤逐条渲染

## Phase 2: farm-agent 工具证据结构化（Task 3）

- [T] F2 工具证据 content 改为摘要描述格式（如 `"[toolName] 查询成功，返回 N 条记录"`）
- [T] 从 state.toolResults（优先）或 tm.content JSON 解析（降级）获取 list + columns，填充 data 字段
- [T] evidenceChain 中 tool_result evidence 的 data 字段存在且类型正确
- [R] 新对话工具调用后 evidence 的 content 为可读摘要

## Phase 3: 前端回退渲染（Task 4）

- [T] tool 源证据展开区：有 data 时走表格渲染，无 data 时渲染 content 文本
- [R] 旧线程（无 data 的 tool evidence）展开后不报错

## Phase 4: 编译验证（Task 5）

- [T] agrisynapse `npx tsc --noEmit` 零错误
- [T] farm-agent `npx tsc --noEmit` 零错误
- [R] 新对话 SSE 流式全部结构化数据正常
- [R] 刷新页面后全部结构化数据保留
- [R] 发送第二条消息后上一轮数据不被损坏

## ADD 规则合规检查

- [T] ADD-2 阶段标记对称（SSE 路径与 rehydration 路径产出字段形状对称）
- [T] Plan/Spec 一致性（代码实现与文档定义一致）

## 跨项目联调检查

- [T] 所有跨系统 API：SSE 事件格式不变、metadata JSON 结构不变（仅消费端归一化）
- [T] 确认两项目 package.json 主版本号，无 breaking changes
- [T] 环境变量无变更
