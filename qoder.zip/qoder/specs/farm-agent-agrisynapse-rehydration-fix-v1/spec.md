# farm-agent-agrisynapse-rehydration-fix-v1 Spec

## Why

agrisynapse 前端页面刷新后，从 DB 加载的 ASSISTANT 消息结构性数据（置信度、证据链、推理路径）与 SSE 流式路径产出的字段形状不一致，导致三个 P0 渲染缺陷：置信度数值丢失、证据链/推理路径遍历对象 key 而非数组元素、工具证据渲染原始 HTTP 响应。

## What Changes

| 文件 | 操作 | 内容 |
|------|------|------|
| agrisynapse `src/store/modules/agentChat.ts` | MODIFY | `loadThread` 方法中 verdict/evidenceChain/reasoningPath 的 rehydration 逻辑增加形状归一化 |
| farm-agent `src/agents/nodes/reasoning.ts` | MODIFY | F2 工具证据回填 content 从原始 HTTP 响应改为摘要描述，增加 data 字段 |
| agrisynapse `src/views/llm/components/LlmChatView.vue` | MODIFY | tool 源证据无 data 时的回退渲染 |

## Impact

- **Affected specs**: 无（纯 bug fix，不涉及新功能 spec）
- **Affected code**:
  - agrisynapse: `agentChat.ts` (loadThread), `LlmChatView.vue` (tool evidence render)
  - farm-agent: `reasoning.ts` (F2 tool evidence backfill)
- **父 Plan**: `.qoder/plans/2026-06/24/farm-agent-structured-data-agrisynapse-rehydration-fix-plan-v1.md`
- **前序关联**: `fix-streaming-structured-data-plan-v1` (05-18), `intermediate-streaming-ui-fix-plan-v1` (06-17), `reasoning-structured-dataflow-plan-v1` (06-15)
- **依赖**: 无外部服务依赖，纯前端 store + 后端 node 逻辑修复
- **后续依赖**: 无

## Boundaries

- 本次只允许修改上述 3 个文件的 rehydration 归一化逻辑、工具证据 content 构建逻辑、tool evidence 回退渲染
- 本次禁止修改 SSE 流式路径的现有转换代码（`_consumeSSE` / `_dispatchEvent`）
- 本次禁止修改 `response.ts` 的 `structuredResponse` 构建逻辑（维持 camelCase + 嵌套结构）
- 本次禁止修改 DB schema 或 Prisma 模型
- 本次禁止引入新的 npm 依赖

## Requirements

### Requirement: verdict 置信度字段 rehydration 归一化

系统 SHALL 在 agrisynapse `loadThread` 中，将 metadata.verdict.confidence 的 camelCase 字段名转换为 snake_case，使 rehydration 路径与 SSE 路径产出的字段名一致。

#### Scenario: 页面刷新后判决面板置信度正确渲染

- **WHEN** 用户刷新页面，前端调用 `loadThread` 从 DB 加载历史消息
- **THEN** ASSISTANT 消息的 `verdict.confidence.final_confidence` 字段值为有效数值（与 SSE 流式时的 `finalConfidence` 值对应），且判决面板渲染正确的百分比

### Requirement: 证据链 rehydration 扁平化

系统 SHALL 在 agrisynapse `loadThread` 中，将 metadata.evidenceChain（嵌套对象 `{ evidences: [...], totalScore, sourceBreakdown }`）提取为 `evidences` 数组，使 rehydration 路径与 SSE 路径产出的类型一致。

#### Scenario: 页面刷新后证据链列表正确渲染

- **WHEN** 用户刷新页面，前端从 DB 加载含证据链的历史消息
- **THEN** ASSISTANT 消息的 `evidenceChain` 为数组（`[{id, source, content, ...}, ...]`），证据链面板按证据项逐条渲染（非对象 key 遍历）

### Requirement: 推理路径 rehydration 扁平化

系统 SHALL 在 agrisynapse `loadThread` 中，将 metadata.reasoningPath（嵌套对象 `{ steps: [...], traces: [...] }`）提取为 `steps` 数组。

#### Scenario: 页面刷新后推理路径列表正确渲染

- **WHEN** 用户刷新页面，前端从 DB 加载含推理路径的历史消息
- **THEN** ASSISTANT 消息的 `reasoningPath` 为数组（`[{step, action, description, ...}, ...]`），推理路径面板按步骤逐条渲染

### Requirement: 工具证据 content 结构化

系统 SHALL 在 farm-agent `reasoning.ts` F2 工具证据回填中，将 content 从原始 HTTP 响应截断改为结构化摘要描述，并从 state.toolResults 填充 data 字段。

#### Scenario: 证据链中 tool_result 类型内容可读且支持表格渲染

- **WHEN** Agent 管线中使用工具获取实时数据后，reasoning 节点将工具结果回填至 evidenceChain
- **THEN** evidenceChain 中 tool_result 类型证据的 `content` 为人类可读的摘要描述（如 `"[query_farm_weather] 查询成功，返回 12 条记录"`），`data` 字段包含 `{ list, columns }` 用于前端表格渲染

### Requirement: 工具证据无 data 时的回退渲染

系统 SHALL 在 agrisynapse `LlmChatView.vue` 中，当工具源证据无 `data` 字段时，显示 content 文本摘要作为回退，不展示空白表格。

#### Scenario: 旧版 tool evidence（无 data 字段）仍可渲染

- **WHEN** DB 中存有旧版 tool evidence（content 为原始 HTTP 响应截断，无 data 字段）
- **THEN** 证据链展开后显示 content 文本内容，无表格区域（不报错、不空白）
