# Checklist: Professional Fan-out

> **证据规范**：每项 [x] 必须附带可验证证据。`[T]` = 编译期验证，`[R]` = 运行时验证。

## 一、编译与 Lint 门禁

- [x] [T] tsc 零错误 — `npx tsc --noEmit` 输出空
- [x] [T] ESLint 零 error — 0 errors, 9 warnings（非本次改动）
- [x] [T] professionalGraph 编译无异常 — agent-graph.ts 编译通过
- [x] [T] deep 图不受影响（回归）— reasoning.ts 未修改
- [x] [T] state.ts expertClaims 有 reducer — `grep -n "reducer" src/agents/state.ts` → L164

## 二、业务验收

- [x] [T] routeByExpertPlan：3 expert → 3 Send；0 expert → 直通 — send-api.ts L33-48
- [ ] [R] 2 expert mock fan-out → ExpertClaim[] → kbConflictAggregator 全链路（需启动服务）
- [ ] [R] expertClaims 汇聚正确（需运行时验证）
- [ ] [R] deep 图单专家推理不受影响（需运行时验证）

## ADD 规则合规检查

- [x] [E] ADD-1 可观测性优先 — `agentAudit("PROFESSIONAL_FAN_OUT")` 在 send-api.ts L35/46 共 2 处
- [ ] [E] ADD-7 审计操作记录 — `record_dev_operation` 按文件逐条记录（待记录）# Checklist: Professional Fan-out

> **证据规范**：每项 [x] 必须附带可验证证据。`[T]` = 编译期验证，`[R]` = 运行时验证。

## 一、编译与 Lint 门禁

- [ ] [T] tsc 零错误
- [ ] [T] ESLint 零 error
- [ ] [T] professionalGraph 编译无异常
- [ ] [T] deep 图不受影响（回归）
- [ ] [T] state.ts expertClaims 有 reducer — `grep -n "reducer" src/agents/state.ts`

## 二、业务验收

- [ ] [T] routeByExpertPlan：3 expert → 3 Send；0 expert → 直通
- [ ] [R] 2 expert mock fan-out → ExpertClaim[] → kbConflictAggregator → conflictResolver 全链路
- [ ] [R] expertClaims 汇聚正确（2 分支完成 → length === 2）
- [ ] [R] deep 图单专家推理不受影响

## ADD 规则合规检查

- [ ] [E] ADD-1 可观测性优先 — `agentAudit("PROFESSIONAL_FAN_OUT", ...)` 至少 1 处
- [ ] [E] ADD-7 审计操作记录 — `record_dev_operation` 按文件逐条记录
