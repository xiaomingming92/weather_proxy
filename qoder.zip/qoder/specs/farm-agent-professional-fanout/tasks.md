# Tasks: Professional Fan-out

> **验证规范**：每个 Task 完成时必须附带双检证据（`tsc=0` + `eslint 0 errors`）。

## Preconditions

- [x] Plan 已生成
- [x] Spec 已就绪
- [x] LangGraph Send API 可用（v1.4.7）

## Forbidden

- ✅ 禁止修改 deep/fast 图拓扑 — 未修改
- ✅ 禁止修改 kbConflictAggregator / conflictResolver / aggregation / coordinationDialogue 节点 — 未修改
- ✅ 禁止修改 intention 图节点 — 仅路由由 thinking-level Plan 负责

## Round 1 Tasks: Send API 基础设施

- [x] Task 1.1: `src/agents/state.ts` — expertClaims 加 reducer + fanoutExpertId
  - [x] expertClaims 改为带 `reducer: concat` 的 Annotation
  - [x] 新增 `fanoutExpertId: Annotation<string | null>()`
  - ✅ 验证: `tsc=0` + deep 图不受影响

- [x] Task 1.2: `src/lib/langgraph/send-api.ts` — 新建 Send API 封装
  - [x] 导出 `routeByExpertPlan(state)` → `Send[] | string`
  - [x] agentAudit("PROFESSIONAL_FAN_OUT", ...)
  - ✅ 验证: `tsc=0`

## Round 2 Tasks: 节点适配

- [x] Task 2.1: `src/agents/nodes/per-expert-retrieval.ts` — 新建 per-expert 检索
  - [x] 接收 `state.fanoutExpertId`，查 `ANALYSIS_EXPERTS[fanoutExpertId].evidenceFilter`
  - [x] 调 RAG → 构建单 expert 的 expertPackage
  - ✅ 验证: `tsc=0`

- [x] Task 2.2: `src/agents/nodes/per-expert-reasoning.ts` — 新建 per-expert 推理
  - [x] 读 `fanoutExpertId` + `expertPackages[0]`
  - [x] 过滤本 expert 的 toolMessages（按 realtimeToolNames）
  - [x] loadExpertPrompt.build() → LLM invoke → reasoningPrompt.parse() → verdictResult
  - ✅ 验证: `tsc=0`

- [x] Task 2.3: `src/agents/nodes/structured-output.ts` — fan-out 上下文
  - [x] `state.fanoutExpertId` 存在时从 `verdictResult.conclusion.content` 取 reasoning
  - ✅ 验证: `tsc=0`

## Round 3 Tasks: 图组装 + 集成验证

- [x] Task 3.1: `src/agents/edges/conditional.ts` — 导出 hasToolCalls
  - [x] 导出 `hasToolCalls` 供 agent-graph.ts 使用
  - ✅ 验证: `tsc=0`

- [x] Task 3.2: `src/agents/agent-graph.ts` — professionalWorkflow 重建
  - [x] 替换现有串行链为 Send API fan-out 拓扑
  - [x] 添加 perExpertRetrieval / perExpertReasoning / perExpertStructuredOutput 节点
  - [x] 添加 perExpertReasoning → toolNode → perExpertReasoning 循环
  - [x] fan-in 边：`.addEdge("perExpertStructuredOutput", "kbConflictAggregator")`
  - ✅ 验证: 图编译无异常

## Verification

- [x] `npx tsc --noEmit` 零错误
- [x] `npx eslint src/` 零 error（9 warnings，均为非本次改动文件）
- [x] professionalGraph 编译无异常# Tasks: Professional Fan-out

> **验证规范**：每个 Task 完成时必须附带双检证据（`tsc=0` + `eslint 0 errors`）。

## Preconditions

- [x] Plan 已生成
- [x] Spec 已就绪
- [x] LangGraph Send API 可用（node_modules/@langchain/langgraph 确认 `new Send(node, args)`）

## Forbidden

- 禁止修改 deep/fast 图拓扑
- 禁止修改 kbConflictAggregator / conflictResolver / aggregation / coordinationDialogue 节点
- 禁止修改 intention 图节点（仅路由可达由 thinking-level Plan 负责）

## Round 1 Tasks: Send API 基础设施

- [ ] Task 1.1: `src/agents/state.ts` — expertClaims 加 reducer
  - [ ] 从 `Annotation<ExpertClaim[] | null>()` 改为带 `reducer: concat` 的 Annotation
  - ✅ 验证: `tsc=0` + deep 图不受影响

- [ ] Task 1.2: `src/lib/langgraph/send-api.ts` — 新建 Send API 封装
  - [ ] 导出 `routeByExpertPlan(state)` → `Send[] | string`
  - [ ] 导入 `Send` from `@langchain/langgraph`
  - ✅ 验证: `tsc=0`

## Round 2 Tasks: 节点适配

- [ ] Task 2.1: `src/agents/nodes/per-expert-retrieval.ts` — 新建 per-expert 检索
  - [ ] 接收 `state.expertId`，查 `ANALYSIS_EXPERTS[expertId].knowledgeBaseIds`
  - [ ] 调 RAG → 构建单 expert 的 expertPackage
  - ✅ 验证: `tsc=0`

- [ ] Task 2.2: `src/agents/nodes/reasoning.ts` — 单 expert 模式
  - [ ] `state.expertId` 存在 → 单 expert 推理路径
  - [ ] `state.expertId` 不存在 → 回退现有串行逻辑
  - ✅ 验证: `tsc=0` + deep 图回归

- [ ] Task 2.3: `src/agents/nodes/structured-output.ts` — 单 expert 模式
  - [ ] `state.expertPackages.length === 1` → 单 expert 调用
  - [ ] 否则回退现有遍历逻辑
  - ✅ 验证: `tsc=0`

## Round 3 Tasks: 图组装 + 集成验证

- [ ] Task 3.1: `src/agents/edges/conditional.ts` — 新增 routeByExpertPlan
  - [ ] 读 `state.expertPlan`，返回 `Send[]` 或直通字符串
  - ✅ 验证: `tsc=0`

- [ ] Task 3.2: `src/agents/agent-graph.ts` — professionalWorkflow 重建
  - [ ] 替换现有串行链为 Send API fan-out 拓扑
  - [ ] 添加 perExpertRetrieval / perExpertReasoning / perExpertStructuredOutput 节点
  - ✅ 验证: 图编译无异常

- [ ] Task 3.3: `tests/professional-fanout.test.ts` — 集成测试
  - [ ] 2 expert mock → fan-out → ExpertClaim[] 全链路
  - ✅ 验证: 测试通过

## Verification

- [ ] `npx tsc --noEmit` 零错误
- [ ] `npx eslint src/` 零 error
- [ ] professionalGraph 编译无异常
