# Professional Fan-out Spec

## Why

`professionalWorkflow` 当前全串行 `.addEdge` 链（零 Send API fan-out），所有 expert 共享一个 retrieval 节点 + reasoning 节点。ACA v3 Plan 要求 per-expert 并行推理（retrieval → reasoning → structuredOutput），仅冲突汇聚层保持串行。

## What Changes

- `src/lib/langgraph/send-api.ts`：新建 LangGraph Send API 封装
- `src/agents/agent-graph.ts`：professionalWorkflow 从串行改为 Send API fan-out 拓扑
- `src/agents/edges/conditional.ts`：新增 `routeByExpertPlan` conditional edge
- `src/agents/nodes/per-expert-retrieval.ts`：新建 per-expert 检索节点
- `src/agents/nodes/reasoning.ts`：适配单 expert 模式（`state.expertId` 存在时走单 expert 路径）
- `src/agents/nodes/structured-output.ts`：适配单 expert 模式
- `src/agents/state.ts`：`expertClaims` 改为带 reducer 的 Annotation
- `tests/professional-fanout.test.ts`：集成测试

## Impact

- Affected specs: 无（全新功能）
- Affected code: 8 个文件
- 父 Plan: `.qoder/plans/2026-07/06/farm-agent-professional-fanout-plan-v1.md`
- 依赖: `farm-agent-three-tier-reasoning-graph-plan-v3.md`（轮次 1-3 节点代码）、`farm-agent-thinking-level-runtime-fix-plan-v1.md`（路由可达）

## ADDED Requirements

### Requirement: Send API fan-out 拓扑

#### Scenario: 3 expert fan-out

- **WHEN** intention 产出 expertPlan = [{ pest_risk }, { weather_impact }, { roi_analysis }]
- **THEN** `routeByExpertPlan` 返回 3 个 `Send("perExpertRetrieval", { expertId })`，3 个分支并行执行

#### Scenario: 空 expertPlan

- **WHEN** expertPlan 为空或 null
- **THEN** `routeByExpertPlan` 返回 `"kbConflictAggregator"` 直通

### Requirement: expertClaims reducer 汇聚

#### Scenario: 2 expert 各产出 1 个 Claim

- **WHEN** pest_risk 产出 ExpertClaim A，weather_impact 产出 ExpertClaim B
- **THEN** `state.expertClaims` = [A, B]（reducer concat 自动汇聚）

### Requirement: 单 expert 模式（deep 图回归）

### Requirement: per-expert 推理（隔离方案）

> 与 ACA v3 的差异：ACA v3 设计为复用现有 `reasoningNode`，但会导致节点职责混杂。本 Plan 采用隔离方案——新建 `perExpertReasoning`，职责单一。

#### Scenario: 单 expert 推理 + 工具结果归集

- **WHEN** `state.fanoutExpertId = "pest_risk"` 且 `expertPackages = [{ pest_risk, ... }]`
- **THEN** `perExpertReasoning` 加载 `loadExpertPrompt("pest_risk").build()`，从 `state.messages` 筛选本 expert 的 `toolMessages`（按 `ANALYSIS_EXPERTS[pest_risk].realtimeToolNames` 过滤），注入 `toolResults`，单 LLM invoke，解析产出 `verdictResult`

#### Scenario: 工具结果归集只取本 expert

- **WHEN** pest_risk 的 `realtimeToolNames = ["query_insect_data"]`，weather_impact 的 `realtimeToolNames = ["query_farm_weather"]`
- **THEN** pest_risk 分支的 `perExpertReasoning` 只取 `query_insect_data` 的工具结果，不取 `query_farm_weather`

### Requirement: per-expert 检索

#### Scenario: 单 expert RAG 检索

- **WHEN** `state.fanoutExpertId = "pest_risk"`
- **THEN** `perExpertRetrieval` 查 `ANALYSIS_EXPERTS[pest_risk].evidenceFilter`，调用 `searchKnowledgeDocuments`，构建单 expert 的 `expertPackage`，写入 `state.expertPackages`
