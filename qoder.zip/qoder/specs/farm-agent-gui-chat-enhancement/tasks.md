# Tasks: farm-agent GUI Chat Enhancement

## Preconditions
- [ ] farm-agent 可运行
- [ ] agrisynapse 可访问 farm-agent API

## Forbidden
- 禁止修改 farm-agent ChatPanel/ChatContainer
- 禁止修改 SSE 协议
- 禁止修改 Prisma schema

## Tasks

- [ ] Task 1: updateThreadTitle PATCH 落库
  - [ ] `chat-store.ts`: updateThreadTitle 增加 fetch PATCH 调用 + 乐观更新

- [ ] Task 2: [hash] route 新增 threads 列表
  - [ ] `[hash]/route.ts`: GET 新增 action=threads → chatPersistence.getThreadsByUser

- [ ] Task 3: handleThreadGET 返回 metadata
  - [ ] `[hash]/route.ts`: handleThreadGET messages 包含 metadata

- [ ] Task 4: agrisynapse store + API
  - [ ] `agentChat.ts`: StreamingMessage 新增 interactionPoint? 字段
  - [ ] `agentChat.ts`: _dispatchEvent 新增 interactionPoint 处理
  - [ ] `agentChat.ts`: 新增 threads/fetchThreads/switchThread
  - [ ] `api/agent/index.ts`: 新增 getThreads(userId) → GET ?action=threads
  - [ ] `api/agent/index.ts`: getThread 解析 metadata 字段

- [ ] Task 5: agrisynapse GUI 渲染
  - [ ] `LlmSidebar.vue`: 新增 historyThreads prop + 渲染
  - [ ] `LlmChatView.vue`: 新增交互点 section 模板（选项按钮 + 点击处理）
  - [ ] `index.vue`: navSections 历史对话改为 computed（从 store）

- [ ] Task 6: tsc 编译验证
  - [ ] farm-agent: npx tsc --noEmit
  - [ ] agrisynapse: build 验证

## Task Dependencies
- Task 1/2/3 无依赖（可并行）
- Task 4 依赖 Task 2/3（API 就绪）
- Task 5 依赖 Task 4
- Task 6 依赖 Task 1-5
