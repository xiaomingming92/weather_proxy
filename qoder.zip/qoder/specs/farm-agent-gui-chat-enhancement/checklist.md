# Checklist: farm-agent GUI Chat Enhancement

## 业务验收

- [ ] T1: 编辑标题 → 刷新 → 标题保持
- [ ] T2: GET ?action=threads&userId=... 返回线程列表
- [ ] T3: GET ?action=thread&id=... 返回 messages 含 metadata
- [ ] T4: agrisynapse 侧边栏显示用户全部历史对话（非硬编码 3 条）
- [ ] T5: 点击历史对话项 → 切换并加载消息
- [ ] T6: 流式输出时 interactionPoint 渲染选项按钮
- [ ] T7: 交互点 options 字段缺失时降级显示

## 编译检查

- [ ] [T] farm-agent `npx tsc --noEmit` 零错误
- [ ] [T] agrisynapse build 验证

## ADD 规则合规

- [ ] ADD-1 可观测性：标题编辑、历史加载、交互点渲染均通过 UI 可观测
- [ ] ADD-7 记录：每个文件修改有 record_dev_operation
