# farm-agent GUI Chat Enhancement Spec

## Why
修复 agrisynapse 神经元 GUI 的四缺陷：历史对话硬编码、标题不落库、交互点不渲染、历史消息 metadata 丢失。

## What Changes
- farm-agent `chat-store.ts`: updateThreadTitle 增加 PATCH 调用
- farm-agent `[hash]/route.ts`: GET 新增 action=threads，handleThreadGET 返回 metadata
- agrisynapse `agentChat.ts`: 新增 threads/fetchThreads/switchThread + interactionPoint dispatch
- agrisynapse `LlmSidebar.vue`: historyThreads prop 动态渲染
- agrisynapse `LlmChatView.vue`: 新增交互点 section 模板
- agrisynapse `index.vue`: navSections 动态 computed
- agrisynapse `api/agent/index.ts`: 新增 getThreads(userId)

## Impact
- Affected specs: 无
- Affected code: 8 个文件（farm-agent 2 + agrisynapse 6）
- 父 Plan: `farm-agent-gui-chat-enhancement-plan-v1.md`

## Boundaries
本次允许：标题 PATCH、threads API、metadata 返回、agrisynapse 历史+交互点渲染
本次禁止：修改 farm-agent ChatPanel/ChatContainer、修改 SSE 协议、修改 Prisma schema

## Requirements

### Requirement: 标题编辑落库
系统 SHALL 在 updateThreadTitle 时调用 PATCH /api/agent/chat/threads 持久化。

Scenario: PATCH 失败 → 本地 state 仍更新（乐观更新），console.warn

### Requirement: 线程列表 API
系统 SHALL 在 GET /api/agent/{hash}?action=threads&userId=... 返回用户全部线程列表。

Scenario: GET threads → 返回 { success: true, data: [{id, title, messageCount, createdAt, updatedAt}] }

### Requirement: 线程详情返回 metadata
系统 SHALL 在 handleThreadGET 返回 messages 时包含 metadata 字段。

Scenario: GET thread?id=xxx → messages 含 metadata（可为 null）

### Requirement: agrisynapse 历史对话动态加载
系统 SHALL 在 LlmSidebar 动态渲染用户全部对话线程。

Scenario: onMounted → fetchThreads → LlmSidebar 渲染

Scenario: 点击历史项 → switchThread → loadThread → 切换到该对话

### Requirement: 交互点流式渲染
系统 SHALL 在 structured_update 包含 interactionPoint 时渲染交互点选项。

Scenario: structured_update { interactionPoint: { options: [...] } } → msg.interactionPoint 赋值 → LlmChatView 渲染按钮

Scenario: 用户点击选项 → handleInteractionSelect → store.sendMessage(optionLabel)

Scenario: options 字段缺失 → 降级显示（label ?? "选项N"）
