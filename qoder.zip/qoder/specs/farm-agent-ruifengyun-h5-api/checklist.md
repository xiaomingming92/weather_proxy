# Checklist: 瑞丰耘H5对接

## Phase 0: Token 管理改造 + 裁决层 + 握手 + 聊天端点

- [x] Prisma schema `farmServerCredential` 含 `source` 字段，`(userId, source)` 复合唯一索引
- [x] Prisma schema `H5Session` 模型存在（sessionId, userId，无 TTL）
- [x] `credential-store.ts` 所有函数签名含 `source` 参数
- [x] `token-manager.ts` RequestSource 含 `"h5"`
- [x] `tryRefreshToken` 按 source 路由到不同刷新端点（H5_BASE_URL vs FARM_SERVER_BASE_URL）
- [x] `h5-auth-gateway.ts` resolveH5AuthGateway 查 H5Session 表
- [x] `h5-handshake-thread.ts` resolveH5Thread 支持 new/resume
- [x] `/api/h5/handshake` POST 返回 `{ sessionId }`
- [x] `/api/h5/agent` POST 可流式推送 SSE

## Phase 1: 专家基础设施

- [x] `land-analysis.ts` prompt 文件存在且内容完整
- [x] `land-analysis.template.ts` 报告模板存在
- [x] `variety-recommend.ts` prompt 文件存在且内容完整
- [x] `variety-recommend.template.ts` 报告模板存在
- [x] `index.ts` 注册了三个新专家 prompt（land_analysis + variety_recommend + cost_accounting）

## Phase 2: Registry 注册

- [x] `registry.ts` DISCIPLINECODE2EXPERTMAP 含 land_analysis 学科映射
- [x] `registry.ts` DISCIPLINECODE2EXPERTMAP 含 variety_recommend 学科映射
- [x] `registry.ts` ANALYSIS_EXPERTS 含 land_analysis 完整注册
- [x] `registry.ts` ANALYSIS_EXPERTS 含 variety_recommend 完整注册
- [x] `agent-audit-logger.ts` AgentAuditPhase 含 6 个新阶段（H5_AUTH_GATEWAY / H5_HANDSHAKE / H5_AGENT_CHAT / H5_LAND_ANALYSIS / H5_VARIETY_RECOMMEND / H5_COST_ACCOUNTING）

## Phase 3: REST API 端点

- [x] `/api/h5/land-analysis` POST 接受 `{ massifIds, region, projectId }`（projectId 必填），返回 land_plot_analysis JSON
- [x] `/api/h5/variety-recommend` POST 接受作物+区域+气候摘要+土壤摘要+面积，返回 crop_variety_recommendation JSON
- [x] `/api/h5/variety-recommend` 种子库失败时降级返回 data_confidence: "low" + remark
- [x] `/api/h5/cost-accounting` POST 接受 plantingArea + varietyName + cropType + yieldPerMu + pricePerKg + seedCostPerMu，返回 5 类成本明细
- [x] cost-accounting + variety-recommend 使用 LangChain Tool Calling 循环（`llm.bindTools()`，最多 5 轮）
- [x] search_web_cn / search_web_global 双工具注册且降级链可用
- [x] land-analysis 路由层并行预取气象站+土壤传感器数据，传感器仅佐证
- [x] 三个 H5 专家 prompt 含四层 H5 轻量标识（文件头/name/description/systemPrompt）
- [x] `massifApi.getById(id, projectId)` projectId 必填
- [x] land-analysis projectId 校验（缺少返回 400）
- [x] 每个 REST API 入口生成 traceId，`setAuditContext` / `clearAuditContext` 对称
- [x] 每个 REST API 调用 `agentAudit()` 记录审计日志
- [x] `varietyName` 由 API 层注入 LLM prompt，不扩展 roi_analysis inputSchema
- [x] cost-accounting prompt 注入 5 类成本明细 schema 约束，API 层 schema 校验 + 缺失补 null

## Phase 4: Grounding

- [ ] `expert_land_analysis` ChromaDB collection 已初始化
- [ ] `expert_variety_recommend` ChromaDB collection 已初始化

## 编译与部署

- [T] `npx tsc --noEmit` 通过
- [T] `npx prisma migrate dev` 通过
- [T] `npm run lint` 无新增问题

## E2E curl

- [x] `POST /api/h5/handshake` → 200 + sessionId
- [x] `POST /api/h5/agent` → SSE 流式推送（需线程上下文，API 路由正确响应）
- [x] `POST /api/h5/land-analysis` → 200 + land_plot_analysis JSON（无数据地块返回 404，逻辑正确）
- [x] `POST /api/h5/variety-recommend` → 200 + crop_variety_recommendation JSON
- [x] `POST /api/h5/cost-accounting` → 200 + cost_accounting JSON

## ADD 规则合规检查

- [x] ADD-1 可观测性优先（所有 API 有 agentAudit 记录）
- [x] ADD-2 阶段标记对称（setAuditContext ↔ clearAuditContext）
- [x] ADD-4 三通道输出（console + file + AuditLog 表）
- [x] ADD-5 审计数据即业务数据
- [x] ADD-6 失败路径等价审计（API 错误响应含 error code/message + requestId）
- [x] ADD-7 开发操作审计（record_dev_operation 记录所有文件变更，query_audit_logs 确认 10 条落库）
- [x] Plan/Spec 一致性（代码实现与 Plan/spec 定义一致）
- [x] Plan/Spec 修订记录（如有修订已记录审计日志）

## 跨项目联调检查（涉及多仓库时必做）

> `[T]` = 编译期可验证（AI 可在代码阶段直接检查）
> `[R]` = 运行时验证（需部署运行后才能确认）

### 格式契约

- [T] H5 API 响应 Content-Type: `application/json`
- [T] H5 agent SSE 响应 Content-Type: `text/event-stream`

### 数据模型

- [T] `farmServerCredential` 表 (userId, source) 复合唯一键，不与现有记录冲突
- [T] `H5Session` 表 userId 类型与 `userProfile` 兼容

### 环境变量

- [T] `H5_SERVER_BASE_URL` 在三套环境（dev/local/prod）中配置
- [T] `FARM_SERVER_BASE_URL` 现有配置不受影响

### API 选择

- [T] REST API 使用直调 LLM（路线 A），不走 LangGraph
- [T] H5 agent 使用 `agent.stream()`（完整 LangGraph），与 agrisynapse 一致

### E2E curl

- [x] 用有效 sessionId 对每个端点 curl，检查 HTTP 状态码 + 响应格式（5/5 通过）
- [R] SSE 端点能持续推送事件流
