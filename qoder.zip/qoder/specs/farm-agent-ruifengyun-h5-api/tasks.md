# Tasks: 瑞丰耘H5对接

## Preconditions

- [x] Plan Review 已完成且全部 P0/P1/P2 问题已回流
- [x] Plan 文档就绪：`.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v1.md`
- [x] PostgreSQL 可用，Prisma schema 可迁移

## Forbidden

- 禁止修改 agrisynapse 已有的 handshake 逻辑（agrisynapse-handshake.ts、auth-gateway.ts）
- 禁止引入新的外部依赖（Redis、消息队列等）
- 禁止实现 Step 5"计划生成"API

## Phase 0: Token 管理改造 + 裁决层 + 握手 + 聊天端点

- [x] Task 0: 改造 credential-store.ts（source 参数）
  - [x] SubTask 0.1: `farmServerCredential` 表 Prisma schema 加 `source` 字段（`"agrisynapse" | "h5"`，`(userId, source)` 复合唯一）
  - [x] SubTask 0.2: `saveToken(userId, accessToken, refreshToken, expiresAt, source)` 签名扩展
  - [x] SubTask 0.3: `getValidToken(userId, source)` 签名扩展
  - [x] SubTask 0.4: `updateRefreshedToken(userId, newAccessToken, newRefreshToken, newExpiresAt, source)` 签名扩展
  - [x] SubTask 0.5: `deleteToken(userId, source)` 签名扩展
  - [x] SubTask 0.6: 新增环境变量 `H5_SERVER_BASE_URL`
  - [x] 验证: `npx prisma migrate dev` 无错误

- [x] Task 0.1: 改造 token-manager.ts（source 路由刷新）
  - [x] SubTask 0.1.1: `RequestSource` 类型加 `"h5"`
  - [x] SubTask 0.1.2: `tryRefreshToken(userId, source)` 按 source 路由：`"h5"` → `H5_SERVER_BASE_URL/auth/refresh`，`"agrisynapse"` → `FARM_SERVER_BASE_URL/system/auth/refresh-token`
  - [x] SubTask 0.1.3: `ensureValidToken(userId, source)` 传递 source
  - [x] SubTask 0.1.4: `handleHandshakeToken(params)` 加 `source` 参数
  - [x] 验证: 现有 agrisynapse 调用方传 `source: "agrisynapse"` 后仍工作

- [x] Task 0.2: 新建 h5-auth-gateway.ts（sessionId 裁决）
  - [x] `resolveH5AuthGateway(sessionId)` → 查 H5Session 表 → 返回 `{ userId }` 或 `null`
  - [x] 验证: `tsc --noEmit` 通过

- [x] Task 0.3: 新建 h5-handshake-thread.ts（线程裁决）
  - [x] `resolveH5Thread({ action, userId })` → new 建 chatThread / resume 查最近线程
  - [x] 验证: `tsc --noEmit` 通过

- [x] Task 0.4: 新建 `/api/h5/handshake/route.ts`
  - [x] POST 端点，接收 `{ userVO, accessToken?, refreshToken?, expiresTime? }`
  - [x] 调用 `handleHandshakeToken({..., source: "h5"})`
  - [x] `prisma.userProfile.upsert(...)`
  - [x] `prisma.h5Session.create({sessionId, userId})`
  - [x] 返回 `{ sessionId }`
  - [x] 验证: `tsc --noEmit` 通过

- [x] Task 0.5: 新建 `/api/h5/agent/route.ts`（SSE 流式聊天）
  - [x] POST 端点，接收 chat message + sessionId
  - [x] `resolveH5AuthGateway(sessionId)` → userId
  - [x] `resolveH5Thread({ action, userId })` → threadId
  - [x] `agent.stream()` → SSE 推送
  - [x] 验证: `tsc --noEmit` 通过

## Phase 1: 专家基础设施（可并行）

- [x] Task 1: 新建 `land-analysis.ts` prompt
  - [x] 聚焦区域气候推理 + 多地块土壤综合判定
- [x] Task 2: 新建 `land-analysis.template.ts` 报告模板
  - [x] 基础信息 + 土壤信息 + 气候环境 + 地块明细
- [x] Task 3: 新建 `variety-recommend.ts` prompt
  - [x] 聚焦基于种子库的品种推荐
- [x] Task 4: 新建 `variety-recommend.template.ts` 报告模板
  - [x] 推荐品种列表 + 收益测算 + 风险提示
- [x] Task 5: 更新 `index.ts` 注册两个新 prompt

## Phase 2: Registry 注册

- [x] Task 6: 更新 registry.ts
  - [x] DISCIPLINECODE2EXPERTMAP 新增 land_analysis + variety_recommend
  - [x] ANALYSIS_EXPERTS 新增两个专家完整注册
- [x] Task 7: 更新 agent-audit-logger.ts
  - [x] AgentAuditPhase 新增 `H5_AUTH_GATEWAY` / `H5_HANDSHAKE` / `H5_LAND_ANALYSIS` / `H5_VARIETY_RECOMMEND` / `H5_COST_ACCOUNTING` / `H5_AGENT_CHAT`

## Phase 3: REST API 端点（可并行）

- [x] Task 8: 新建 `/api/h5/land-analysis/route.ts`
  - [x] 接收 `{ massifIds, region, projectId }`（projectId 必填）→ 查 Farm-Server（massif.get + weather-data.page + moisture-data.page 并行预取）→ 直调 LLM → 返回 land_plot_analysis JSON
  - [x] 传感器数据仅作佐证参考，气候带推断为主依据
  - [x] traceId 生成 + setAuditContext/clearAuditContext
- [x] Task 9: 新建 `/api/h5/variety-recommend/route.ts`
  - [x] 接收作物类型+区域+气候摘要+土壤摘要+面积 → Prisma 直查 seedCatalog → LangChain Tool Calling（llm.bindTools([searchWebCnTool])，最多 5 轮）→ 返回 crop_variety_recommendation JSON
  - [x] 种子库降级：失败时 LLM 基于 KB 推理，输出 data_confidence: "low"
  - [x] traceId 生成 + setAuditContext/clearAuditContext
- [x] Task 10: 新建 `/api/h5/cost-accounting/route.ts`
  - [x] 接收 plantingArea + varietyName + cropType + yieldPerMu + pricePerKg + seedCostPerMu
  - [x] LangChain Tool Calling（llm.bindTools([searchWebCnTool, searchWebGlobalTool])，最多 5 轮）
  - [x] prompt 注入 5 类成本明细 schema 约束，API 层 schema 校验 + 缺失补 null
  - [x] traceId 生成 + setAuditContext/clearAuditContext

## Phase 4: Grounding collection 初始化

- [N/A] Task 11: 初始化 `expert_land_analysis` ChromaDB collection（Route A 不需要 Grounding）
- [N/A] Task 12: 初始化 `expert_variety_recommend` ChromaDB collection（Route A 不需要 Grounding）

## Phase 5: 验证

- [x] Task 13: `npx tsc --noEmit` 编译通过
- [R] Task 14: curl 端到端验证（handshake → 聊天 SSE → 3 个 REST API）

## Task Dependencies

- Task 0.1 依赖 Task 0（credential-store 改造完成后方可改造 token-manager）
- Task 0.2/0.3/0.4 可并行（均依赖 Task 0 完成）
- Task 0.5 依赖 Task 0.2 + Task 0.3（需要裁决层就绪）
- Task 5 依赖 Task 1/2/3/4
- Task 8/9/10 可并行（均依赖 Phase 0 + Phase 2 完成）
- Task 13 依赖 Phase 0~3 全部完成
- Task 14 依赖 Task 13

## Verification

- [x] `npx tsc --noEmit` 无错误
- [T] `npx prisma migrate dev` 无错误
- [T] `npm run lint` 无新增问题
- [x] curl `/api/h5/handshake` → 返回 sessionId
- [x] curl `/api/h5/agent` → SSE 流式（需线程上下文）
- [x] curl `/api/h5/land-analysis` → 逻辑正确（无数据含 404）
- [x] curl `/api/h5/variety-recommend` → 返回 crop_variety_recommendation JSON
- [x] curl `/api/h5/cost-accounting` → 返回 cost_accounting JSON
