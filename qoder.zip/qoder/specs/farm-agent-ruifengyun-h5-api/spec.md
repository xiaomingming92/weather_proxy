# 瑞丰耘H5对接 Spec

## Why

瑞丰耘H5前端"智慧农业助手"聊天功能和"新增生产计划"5步向导的 Step 2~4（地块分析、品种选择、成本核算）需要后端 AI 能力支撑。当前 farm-agent 所有能力通过 SSE 流式 agent 链路暴露，不适合 H5 直接消费。需要新增独立的 REST API 端点 + SSE 流式聊天端点，并新增 2 个专家（land_analysis、variety_recommend）。

## What Changes

### 新增文件
- `src/agents/prompts/experts/land-analysis.ts` — land_analysis 专家 prompt
- `src/agents/prompts/experts/variety-recommend.ts` — variety_recommend 专家 prompt
- `src/agents/reports/land-analysis.template.ts` — land_analysis 报告模板
- `src/agents/reports/variety-recommend.template.ts` — variety_recommend 报告模板
- `src/app/api/h5/handshake/route.ts` — H5 握手端点
- `src/app/api/h5/agent/route.ts` — H5 智慧农业助手 SSE 流式聊天端点
- `src/app/api/h5/land-analysis/route.ts` — 地块分析 REST API
- `src/app/api/h5/variety-recommend/route.ts` — 品种推荐 REST API
- `src/app/api/h5/cost-accounting/route.ts` — 成本核算 REST API
- `src/caijuehub/strategies/h5-auth-gateway.ts` — H5 sessionId 认证裁决
- `src/caijuehub/strategies/h5-handshake-thread.ts` — H5 线程 new/resume 裁决

### 修改文件
- `src/agents/experts/registry.ts` — 新增 land_analysis + variety_recommend 注册 + 学科映射
- `src/agents/prompts/experts/index.ts` — 注册两个新 prompt
- `src/lib/agent-audit-logger.ts` — AgentAuditPhase 新增 H5 相关阶段
- `src/lib/auth/credential-store.ts` — 所有函数加 source 参数，(userId,source) 复合唯一
- `src/lib/auth/token-manager.ts` — RequestSource 加 "h5"，tryRefreshToken 按 source 路由
- `prisma/schema.prisma` — 新增 H5Session 模型，farmServerCredential 加 source 字段

## Impact

- **Affected specs**: 无（全新功能）
- **Affected code**: registry.ts, index.ts, agent-audit-logger.ts, credential-store.ts, token-manager.ts, schema.prisma
- **父 Plan**: `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v1.md`
- **依赖**: 上游无依赖（全新端点）；下游：H5 前端消费这些 API
- **后续依赖**: 品种推荐依赖种子库 `query_seed_catalog` 工具 + `search_web_cn` 搜索工具；地块分析依赖 Farm-Server massif/weather-data/moisture-data 接口；成本核算依赖 `search_web_cn` + `search_web_global` 搜索工具

## Boundaries

**本次实现**：
- H5 握手端点 + sessionId 管理（Prisma H5Session 表，无 TTL）
- H5 智慧农业助手 SSE 流式聊天端点（复用 LangGraph agent.stream）
- 3 个 REST API 端点（land-analysis / variety-recommend / cost-accounting）
- 2 个新专家（land_analysis / variety_recommend）+ 2 个裁决策略（h5-auth-gateway / h5-handshake-thread）
- token 管理改造为 source-aware（支持 H5 和 agrisynapse 多端 token 隔离）
- cost-accounting 复用现有 roi_analysis 专家
- 路线 A（轻量）：REST API 绕过 LangGraph，API Route 内直调 LLM + 手动工具调用

**本次禁止**：
- 不实现 Step 5"计划生成"API（H5 端本地聚合）
- 不引入新的外部依赖（Redis、消息队列等）
- 不修改 agrisynapse 已有的 handshake 逻辑

## ADDED Requirements

### Requirement: H5 握手与 sessionId 管理

#### Scenario: H5 应用启动时握手
- **WHEN** H5 端 POST `/api/h5/handshake` 带 userVO + token 三元组
- **THEN** farm-agent 存储 token（source="h5"）到 credential-store，upsert userProfile，生成 sessionId 写入 H5Session 表，返回 `{ sessionId }`

#### Scenario: 后续 API 调用携带 sessionId
- **WHEN** H5 端调用 `/api/h5/*` 并在 Header 中携带 `X-Session-Id`
- **THEN** farm-agent 校验 sessionId 存在，提取 userId，执行业务逻辑

### Requirement: 地块分析 REST API

#### Scenario: 多地块区域分析
- **WHEN** H5 端 POST `/api/h5/land-analysis` 带 `{ massifIds, region, projectId }`（三个字段必填，projectId 用于项目级数据隔离）
- **THEN** farm-agent 查 Farm-Server 获取 Massif DTO + 并行预取气象站/土壤传感器瞬时快照，调用 LLM 推理区域气候带特征（主依据）+ 土壤综合判定，传感器数据仅作佐证参考，返回 land_plot_analysis JSON（含地块明细）

### Requirement: 品种推荐 REST API

#### Scenario: 基于种子库的品种匹配
- **WHEN** H5 端 POST `/api/h5/variety-recommend` 带作物类型+区域+气候摘要+土壤摘要+面积
- **THEN** farm-agent 查种子库（Prisma seedCatalog）→ LLM 通过 `search_web_cn` 自主搜索品种实测数据（Tool Calling 循环，最多 5 轮）→ 匹配排序后返回 crop_variety_recommendation JSON

#### Scenario: 种子库无数据时的降级
- **WHEN** query_seed_catalog 返回空或失败
- **THEN** LLM 基于 knowledge base 纯知识推理，输出标记 `data_confidence: "low"` + 降级 remark

### Requirement: 成本核算 REST API

#### Scenario: ROI 成本计算
- **WHEN** H5 端 POST `/api/h5/cost-accounting` 带 plantingArea + varietyName + cropType + yieldPerMu + pricePerKg + seedCostPerMu
- **THEN** farm-agent LLM 通过 `search_web_cn` / `search_web_global` 自主搜索实时农资价格（Tool Calling 循环，最多 5 轮），计算 5 类成本明细（种子/肥料/病虫害/人工/其他），返回 cost_accounting JSON

### Requirement: 智慧农业助手 SSE 流式聊天

#### Scenario: 自由对话请求
- **WHEN** H5 端 POST `/api/h5/agent` 带用户消息 + sessionId
- **THEN** h5-auth-gateway 验证 sessionId → h5-handshake-thread 裁决线程 → LangGraph agent.stream() 推送 SSE

### Requirement: Token 管理多端隔离

#### Scenario: H5 与 agrisynapse token 隔离
- **WHEN** H5 userId=123 和 agrisynapse userId=123 分别握手
- **THEN** credential-store 以 (userId, source) 复合键存储，互不覆盖；token 刷新各走各的端点
