# farm-agent-log-audit-unify Spec

## Why

`code-review-combined-report.md` #6-#9 发现：8 个 logger 内联相同文件 I/O 代码、Gateway 审计两个文件行为不一致且仅覆盖 agent/[hash]、`audit-log.ts` 内存存储是死代码、`agents/index.ts` 563 行单体文件。需要统一日志基础设施 + 推广 Gateway 审计 + 删除死代码 + 拆分单体文件。

## What Changes

- 新建 `LogFileWriter` / `LazyLogFileWriter`，消除 8 处文件 I/O 重复
- 新建 `auditGatewayRequest()` 纯函数，替代 `agent-gateway-dev-logger.ts` + `agent-gateway-audit.ts`
- 删除 `src/services/audit-log.ts`，`audit/route.ts` 直查 Prisma
- `agents/index.ts` 拆分为 6 个模块 + re-export

## Impact

- Affected specs: 无（新建）
- Affected code: 30 个文件（8 新增 + 19 修改 + 3 删除）
- 父 Plan: `farm-agent-log-audit-unify-plan-v3.md`
- 依赖: `writeAuditLog()`（已有）、`getLogUserId()`（已有）
- 后续依赖: 无

## Boundaries

**本次允许**:
- 新建 `src/lib/log/file-writer.ts`、`src/lib/log/gateway-audit.ts`
- 修改 8 个 logger、`audit.ts`、`agent/[hash]/route.ts`、13 条 h5 路由、`audit/route.ts`、`services/index.ts`、`agents/index.ts`
- 新建 `src/agents/{tracer-store,tracer,tool-node-wrapper,audit-wrapper,graph,agent-runner}.ts`
- 删除 `agent-gateway-dev-logger.ts`、`agent-gateway-audit.ts`、`audit-log.ts`
- 更新 `src/lib/log/index.ts` 导出

**本次禁止**:
- 修改 Prisma schema
- 修改 `writeAuditLog()` 函数签名
- 修改 `appendRuntimeFinding` 或 `instrumentation.ts`（hardening plan 领地）
- 新增 DB 表或索引
- 引入新的 npm 依赖

## Requirements

### Requirement: LogFileWriter 统一文件日志基础设施

#### Scenario: 纯服务端 logger 使用 LogFileWriter

- **WHEN** `audit-logger.ts` 需要写文件日志
- **THEN** 通过 `new LogFileWriter({prefix, logDir, logFile, enableFileLog})` 实例的 `log()` / `logPhaseStart()` / `logPhaseEnd()` 方法写入，不再内联 `ensureLogDir/writeToFile/formatMessage`

#### Scenario: 同构模块使用 LazyLogFileWriter

- **WHEN** `chat-stats-logger.ts`（Next.js 同构）需要写文件日志
- **THEN** 通过 `new LazyLogFileWriter({...})` 实例写入，内部使用动态 `import("fs/promises")` + `isServer` 守卫，浏览器端不触发

#### Scenario: File 日志包含 userId

- **WHEN** `LogFileWriter` 写入 JSONL 日志行
- **THEN** 每行包含 `userId` 字段，值由 `getLogUserId()` 自动注入

### Requirement: Gateway 审计纯函数替代 agent 专属文件

#### Scenario: agent/[hash] 成功请求审计

- **WHEN** `agent/[hash]/route.ts` 处理 dashboard/chat/thread 等请求成功
- **THEN** 调用 `auditGatewayRequest({phase:"GATEWAY_REQUEST", source:"agent", action, entityId, durationMs})`，输出 console + `writeAuditLog`

#### Scenario: h5 路由新增 gateway 审计

- **WHEN** `h5/nongqing/daily-report/route.ts` 处理农情日报请求
- **THEN** 在请求入口和出口调用 `auditGatewayRequest({phase:"GATEWAY_REQUEST", source:"h5", action:"daily_report", entityId:projectId, durationMs})`

#### Scenario: Gateway 报错不触发 appendRuntimeFinding

- **WHEN** gateway 请求失败，调用 `auditGatewayRequest({phase:"GATEWAY_ERROR", ...})`
- **THEN** 仅写 console + `writeAuditLog`，**不**调用 `appendRuntimeFinding`（由 hardening plan 的 instrumentation.ts 边界捕获）

### Requirement: 删除 audit-log.ts 死代码

#### Scenario: audit/route.ts 直查 Prisma

- **WHEN** 管理员访问 `GET /api/audit`
- **THEN** 直接调用 `prisma.auditLog.findMany()` 查询，不再经过 `getAuditLogs()` from `audit-log.ts`

#### Scenario: audit-log.ts 文件已删除

- **WHEN** 编译通过
- **THEN** `src/services/audit-log.ts` 不存在于文件系统，`src/services/index.ts` 无相关导出

### Requirement: agents/index.ts 拆分

#### Scenario: 外部 import 不受影响

- **WHEN** 其他模块 `import { streamAgent } from "@/agents"`
- **THEN** 仍正常导入，`index.ts` 从 `agent-runner.ts` re-export
