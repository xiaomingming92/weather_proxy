# Tasks: farm-agent-log-audit-unify

> **验证规范**：每个 Task 完成时必须附带验证证据。

## Phase 1: Atom 1 — LogFileWriter 基础设施

- [ ] Task 1.1: 创建 `src/lib/log/file-writer.ts` — 验证: `tsc --noEmit` 无类型错误
  - [ ] 定义 `LogFileWriterOptions`、`LogEntry` 接口
  - [ ] 实现 `LogFileWriter` 类（ensureLogDir, writeToFile, writeJSONLEntry, formatMessage, toJSONLEntry, rotate, cleanup, log, logPhaseStart, logPhaseEnd, readLogs, clearLogs, getLogPath）
  - [ ] 实现 `LazyLogFileWriter` 子类（动态 import("fs/promises") + isServer 守卫）
  - [ ] 集成 `getLogUserId()` 注入 userId 到 JSONL

- [ ] Task 1.2: 迁移 `src/lib/audit-logger.ts` — 验证: 日志输出格式不变
  - [ ] 创建 `LogFileWriter` 实例，替换内联 `ensureLogDir/writeToFile/formatMessage`
  - [ ] 保留所有 `audit*` 公共函数、`AuditPhase` 类型

- [ ] Task 1.3: 迁移 `src/lib/chat-persistence-logger.ts` — 验证: 同上
- [ ] Task 1.4: 迁移 `src/lib/stream-bus-logger.ts` — 验证: 同上 + DB 双写逻辑不变
- [ ] Task 1.5: 迁移 `src/lib/stream-chat-logger.ts` — 验证: 同上
- [ ] Task 1.6: 迁移 `src/lib/agent-gateway-dev-logger.ts` — 验证: 同上（Atom 2 会删除）
- [ ] Task 1.7: 迁移 `src/lib/chat-stats-logger.ts` — 验证: `LazyLogFileWriter`，浏览器端不报错
- [ ] Task 1.8: 迁移 `src/lib/model-config-logger.ts` — 验证: 同上
- [ ] Task 1.9: 迁移 `src/lib/log/audit.ts` — 验证: `writeAuditLog` + 失败计数器不受影响

## Phase 2: Atom 2 — Gateway 审计纯函数 + h5 接入

- [ ] Task 2.1: 创建 `src/lib/log/gateway-audit.ts` — 验证: `tsc --noEmit` 无类型错误
  - [ ] 实现 `auditGatewayRequest()` 纯函数（console + writeAuditLog）
  - [ ] 不集成 `appendRuntimeFinding`（保持边界）

- [ ] Task 2.2: 更新 `src/lib/log/index.ts` — 验证: 导出 `auditGatewayRequest`
- [ ] Task 2.3: 重写 `src/app/api/agent/[hash]/route.ts` — 验证: 8 个 action 全部使用新函数
  - [ ] 删除 `agent-gateway-dev-logger` + `agent-gateway-audit` import
  - [ ] 替换 `agentGatewayAudit/PhaseStart/End/recordAgentGatewayAudit/Error` → `auditGatewayRequest`
  - [ ] 保留 3 处 `appendRuntimeFinding` 手动调用不变

- [ ] Task 2.4: 删除旧 gateway 文件 — 验证: `grep` 无残留引用
  - [ ] 删除 `src/lib/agent-gateway-dev-logger.ts`
  - [ ] 删除 `src/lib/agent-gateway-audit.ts`

- [ ] Task 2.5: h5 P0 路由接入（7 条）— 验证: 每条有 `auditGatewayRequest({source:"h5"})` 调用
  - [ ] `h5/agent/route.ts`
  - [ ] `h5/nongqing/daily-report/route.ts`
  - [ ] `h5/nongqing/overview/route.ts`
  - [ ] `h5/nongqing/prescriptions/route.ts`
  - [ ] `h5/nongqing/tasks/route.ts`
  - [ ] `h5/production-plan/variety-recommend/route.ts`
  - [ ] `h5/production-plan/land-analysis/route.ts`

- [ ] Task 2.6: h5 P1 路由接入（6 条）— 验证: 同上
  - [ ] `h5/nongqing/prescriptions/[id]/route.ts`
  - [ ] `h5/nongqing/tasks/[id]/route.ts`
  - [ ] `h5/production-plan/plans/[id]/route.ts`
  - [ ] `h5/production-plan/cost-accounting/route.ts`
  - [ ] `h5/production-plan/generate/route.ts`
  - [ ] `h5/upload/image/route.ts`

## Phase 3: Atom 3 — 删除 audit-log.ts

- [ ] Task 3.1: 重写 `src/app/api/audit/route.ts` — 验证: `GET /api/audit` 正常返回
  - [ ] 替换 `getAuditLogs()` → `prisma.auditLog.findMany()`
  - [ ] 保留 `AuditAction` 枚举内联定义

- [ ] Task 3.2: 删除 `src/services/audit-log.ts` — 验证: 文件不存在
- [ ] Task 3.3: 更新 `src/services/index.ts` — 验证: 无 audit-log 相关导出

## Phase 4: Atom 4 — agents/index.ts 拆分

- [ ] Task 4.1: 创建 `src/agents/tracer-store.ts` — 验证: `tsc --noEmit`
  - [ ] 提取 L302-L323: `activeTracers` Map + `tracerCreateTimes` Map + `cleanupExpiredTracers`

- [ ] Task 4.2: 创建 `src/agents/tracer.ts` — 验证: 同上
  - [ ] 提取 L413-L435: `getActiveTracer` + `startChainTrace` + `endChainTrace`

- [ ] Task 4.3: 创建 `src/agents/tool-node-wrapper.ts` — 验证: 同上
  - [ ] 提取 L34-L187: `createToolNodeWrapper`

- [ ] Task 4.4: 创建 `src/agents/audit-wrapper.ts` — 验证: 同上
  - [ ] 提取 L325-L411: `wrapNodeWithAudit`

- [ ] Task 4.5: 创建 `src/agents/graph.ts` — 验证: `agent` + `professionalGraph` 可导入
  - [ ] 提取 L189-L300: `workflow` + `professionalWorkflow` + `agent` + `professionalGraph`

- [ ] Task 4.6: 创建 `src/agents/agent-runner.ts` — 验证: `runAgent` / `streamAgent` 可导入
  - [ ] 提取 L437-L561: `runAgent` + `streamAgent` + `StreamAgentInput` + `buildPartialState`

- [ ] Task 4.7: 精简 `src/agents/index.ts` — 验证: 25+ 处外部 import 无变化
  - [ ] 保留 import（节点、边、工具、审计）
  - [ ] 保留 `setAgentTools(agentTools)` (L31)
  - [ ] 从 6 个新模块 re-export
  - [ ] 保留 `export { agentTools }`

## Task Dependencies

- Task 1.2-1.9 依赖 Task 1.1（LogFileWriter）
- Task 1.2-1.9 可并行
- Task 2.1 依赖 Task 1.1
- Task 2.3 依赖 Task 2.1
- Task 2.4 依赖 Task 2.3
- Task 2.5-2.6 依赖 Task 2.1
- Task 3.1-3.3 独立
- Task 4.2 依赖 Task 4.1
- Task 4.4 依赖 Task 1.1, 4.1
- Task 4.5 依赖 Task 4.3, 4.4
- Task 4.6 依赖 Task 4.5
- Task 4.7 依赖 Task 4.1-4.6

## Verification

- [ ] `npx tsc --noEmit` — 零类型错误
- [ ] `npm run lint` — 无新增 lint 问题
- [ ] `grep -r "agent-gateway-dev-logger\|agent-gateway-audit" src/` — 仅 agent/[hash]/route.ts 中的 import 语句已删除
- [ ] `grep -r "from.*services/audit-log" src/` — 无结果
- [ ] `grep -r "createAuditLog\|getAuditLogs\|getAuditLogsByTarget" src/` — 仅 audit/route.ts 中内联定义
