# Checklist: add-qoder-integration

## Task 1: L1 词汇映射表

- [ ] [T] project_rules.md 六类词汇表完整（A文档类型 / B阶段 / C门禁 / D MCP工具 / E Skills / F核心概念）
- [ ] [T] 每类含独立表格，有优先级列（P0/P1/P2）
- [ ] [T] P0 词汇 ≥ 15 条（用户高频本能响应）
- [ ] [T] P1 词汇 ≥ 20 条（开发流程频繁涉及）
- [ ] [T] devlog 条目含双触发说明（用户说 + Step 8 自动）
- [ ] [T] Step 8 条目含三步序列（devlog→handoff→架构回看）
- [ ] [T] 表格 Markdown 语法正确
- [ ] [T] `record_dev_operation` 已调用

## Task 2: L1 词汇速查表

- [ ] [T] AGENTS.md 存在"ADD 词汇速查"章节
- [ ] [T] 速查表含 ≥ 10 个 P0 高频词
- [ ] [T] 表格 Markdown 语法正确
- [ ] [T] `record_dev_operation` 已调用

## Task 3: L2 session-init 增强

- [ ] [T] Step 2.4: 读取 `.qoder/plans/index.md` 子步骤已添加
- [ ] [T] Step 2.5: 调用 `get_project_context({ scope: "add-state" })` 子步骤已添加
- [ ] [T] Step 3: 交叉 index.md + ADD 状态推断逻辑已添加
- [ ] [T] Step 4: 上下文摘要含 Plan 清单 + 待办项
- [ ] [T] 新增步骤编号不与原有 Steps 冲突
- [ ] [T] YAML frontmatter 格式正确
- [ ] [T] `record_dev_operation` 已调用

## Task 4: L3 add-orchestrator

- [ ] [T] `.qoder/agents/add-orchestrator.md` 文件存在
- [ ] [T] YAML frontmatter 含正确的 tools 和 mcpServers 声明
- [ ] [T] 阶段 0 状态感知逻辑完整（index.md + get_project_context + add-route）
- [ ] [T] 阶段 1 入口门禁调度逻辑完整（委托 Guardian）
- [ ] [T] 阶段 2 出口门禁调度逻辑完整（委托 Guardian）
- [ ] [T] 阶段 3 上下文衔接逻辑完整（门禁报告反馈主 Agent）
- [ ] [T] 不重复 add-flow-guardian 的检查逻辑
- [ ] [T] `record_dev_operation` 已调用

## 跨轮验证

- [ ] [T] 四文件全部完成，tasks.md 全部 `[x]`
- [ ] [T] `query_audit_logs` 回查确认全部 ADD-7 记录落库
- [ ] [R] 新会话中 LLM 对 devlog/handoff/DPS 等 P0 词汇产生本能响应
- [ ] [R] session-init 执行后上下文中含 index.md 摘要
- [ ] [R] "看依赖"类问题优先匹配 index.md，无匹配才全局搜索
- [ ] [R] Step 8 收敛后 LLM 自动写 devlog日志(走mcp)（无需用户提醒）
