# Tasks: add-qoder-integration

## Preconditions

- [ ] Plan: `add-qoder-integration-plan-v1.md` 已就绪
- [ ] Review: `add-qoder-integration-review-v1.md` 已生成 + P0/P1 已回流
- [ ] add-route: `add-qoder-integration-add-route-v1.md` 已生成
- [ ] farm-agent-dev-tools MCP Server 已连接

## Forbidden

- 禁止修改 `src/` 下任何代码
- 禁止修改 `add-paradigm` SKILL 的 Step 流程
- 禁止修改 `add-flow-guardian` 的检查逻辑
- 禁止引入外部依赖

---

- [ ] Task 1: L1 词汇映射表写入 project_rules.md
  - [ ] 1.1 在 `project_rules.md` 中新增"ADD 词汇→操作映射"章节（放在"理论→实践映射"表之前）
  - [ ] 1.2 按六类分类（A-F），每类独立表格，含 P0/P1/P2 优先级列
  - [ ] 1.3 P0 词汇 ≥ 15 条，P1 词汇 ≥ 20 条
  - [ ] 1.4 验证：表格语法正确，优先级列无遗漏
  - [ ] 1.5 调用 `record_dev_operation`（targetType: "RULE"，action: "RULE_MODIFIED"）

- [ ] Task 2: L1 词汇速查表写入 AGENTS.md
  - [ ] 2.1 在 AGENTS.md ADD 工作流入口之前新增"ADD 词汇速查"章节
  - [ ] 2.2 精选 P0 高频词（devlog, handoff, add-route, 看依赖, DPS, RAHS, Guardian, 验收, 收敛, 回流）
  - [ ] 2.3 验证：表格语法正确
  - [ ] 2.4 调用 `record_dev_operation`（targetType: "RULE"，action: "RULE_MODIFIED"）

- [ ] Task 3: L2 session-init 增强
  - [ ] 3.1 Step 2 新增 2.4 子步骤：读取 `.qoder/plans/index.md`
  - [ ] 3.2 Step 2 新增 2.5 子步骤：调用 `get_project_context({ scope: "add-state" })`
  - [ ] 3.3 Step 3 增强：交叉 index.md + ADD 状态推断 Plan 拓扑
  - [ ] 3.4 Step 4 增强：上下文摘要含 Plan 清单 + 待办项
  - [ ] 3.5 验证：SKILL.md YAML frontmatter + Markdown 格式正确
  - [ ] 3.6 调用 `record_dev_operation`（targetType: "SKILL"，action: "SKILL_MODIFIED"）

- [ ] Task 4: L3 add-orchestrator Subagent 创建
  - [ ] 4.1 创建 `.qoder/agents/add-orchestrator.md`
  - [ ] 4.2 实现阶段 0：状态感知（读 index.md + 调 get_project_context + 读 add-route）
  - [ ] 4.3 实现阶段 1：入口门禁调度（Step 边界自动调 Guardian）
  - [ ] 4.4 实现阶段 2：出口门禁调度（Step 完成自动调 Guardian）
  - [ ] 4.5 实现阶段 3：上下文衔接（门禁报告反馈主 Agent）
  - [ ] 4.6 验证：YAML frontmatter 含 tools + mcpServers 声明
  - [ ] 4.7 验证：不重复 guardian 检查逻辑，只做调度
  - [ ] 4.8 调用 `record_dev_operation`（targetType: "AGENT"，action: "AGENT_CREATED"）

## Task Dependencies

- Task 2 依赖 Task 1（AGENTS.md 速查表引用 project_rules.md 的完整词汇）
- Task 3 依赖 Task 1,2（session-init 增强需要词汇表已就位）
- Task 4 依赖 Task 1,2,3（编排需要词汇+惯性作为底座）

## Verification

- [ ] 四个文件全部创建/修改完成
- [ ] 每个文件调用 `record_dev_operation` 记录
- [ ] `query_audit_logs` 回查确认全部记录落库
- [ ] project_rules.md 词汇表六类完整（A-F 全覆盖）
- [ ] session-init SKILL 新步骤编号不冲突
- [ ] add-orchestrator.md 不重复 add-flow-guardian 逻辑
