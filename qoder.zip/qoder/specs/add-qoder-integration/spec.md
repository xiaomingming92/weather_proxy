# add-qoder-integration Spec

## Why

ADD 范式的词汇表（devlog、handoff、add-route、DPS、RAHS…）和操作惯例（看 index.md 找 plan、Step 边界调 Guardian…）散落在 skill 文件、MCP 工具描述、plan 文档中，LLM 需要"主动去翻"才知道。必须将这些知识预埋到 Qoder 的 always-on 上下文中，使 LLM 对 ADD 术语产生本能响应。

## What Changes

| 文件 | 操作 | 内容 |
|------|------|------|
| `.qoder/rules/project_rules.md` | MODIFY | 新增"ADD 词汇→操作映射"六类分类表（约45条，含P0/P1/P2优先级） |
| `AGENTS.md` | MODIFY | 新增"ADD 词汇速查"章节（P0高频词精选） |
| `.qoder/skills/session-init/SKILL.md` | MODIFY | Step 2 新增 index.md 加载 + get_project_context 调用；Step 3 新增 Plan 拓扑注入 |
| `.qoder/agents/add-orchestrator.md` | CREATE | ADD 编排 Subagent：阶段感知 + 门禁调度 + 上下文衔接 |

## Impact

- Affected specs: 无（首次）
- Affected code: 仅 Qoder 配置文件，不涉及 `src/`
- 父 Plan: `add-qoder-integration-plan-v1.md`
- 依赖: 无
- 后续依赖: 无

## Boundaries

本次只允许实现：
- `.qoder/` 下的 Rules、Skills、Agents 文件修改/创建
- 纯 Markdown/YAML 格式，无代码逻辑

本次禁止实现：
- 修改 `src/` 下任何代码
- 修改 add-paradigm SKILL 的 Step 流程
- 修改 add-flow-guardian 的检查逻辑
- 引入外部依赖（npm 包、Qoder SDK 等）

## Requirements

### Requirement: 词汇映射表完整性
系统 SHALL 在 `project_rules.md` 中提供六类 ADD 词汇→操作映射表，覆盖文档类型、ADD阶段、门禁、MCP工具、Skills/Subagents、核心概念共6类。

Scenario: 用户说"devlog 记录下"
- WHEN 用户说"devlog 记录下"
- THEN LLM 本能知道写 devlog日志(走mcp) 到 `.qoder/plans/{YYYY-MM}/{DD}/`

Scenario: 用户说"看下这个功能依赖哪个plan"
- WHEN 用户说"看依赖"类问题
- THEN LLM 优先读 `.qoder/plans/index.md` 匹配，无匹配才全局搜索

Scenario: Step 8 收敛通过
- WHEN Step 8 收敛判断通过
- THEN LLM 自动执行 devlog 写入（无需用户提醒）

### Requirement: session-init 自动注入上下文
系统 SHALL 在 session-init 执行时自动加载 index.md 并调用 get_project_context。

Scenario: 新对话启动
- WHEN 新对话启动并执行 session-init
- THEN LLM 上下文中包含 index.md 摘要 + ADD 状态快照 + 活跃 Plan 清单

### Requirement: 门禁自动编排
系统 SHALL 通过 add-orchestrator Subagent 在 Step 边界自动触发门禁检查。

Scenario: 主 Agent 完成 Step 3 代码编写
- WHEN 主 Agent 完成 Step 3
- THEN add-orchestrator 自动调 add-flow-guardian（出口模式）做门禁检查

Scenario: 门禁 BLOCKED
- WHEN Guardian 返回 BLOCKED
- THEN add-orchestrator 明确告知主 Agent 回退到哪个 Step、执行什么操作
