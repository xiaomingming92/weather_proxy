# Tasks: RAG 链路加固 — 专家全量注册 + 证据分档 + 检索预算集中化

## Preconditions

- [x] 上游 runtime-review-v2 §5.6-a 已触发
- [x] `knowledge-indexer.ts` 第 209-210 行 `where` 防 undefined 修复已提交（`const where = rawWhere ?? {}`）
- [x] Plan `farm-agent-rag-audit-stacktrace-plan-v1.md` 已就绪（v9 修订：证据归属结构化分档 + 检索预算集中化）

## Forbidden

- 禁止修改 ChromaDB 数据、索引逻辑、或 collection 结构
- 禁止修改 prompt 模板或 intention 路由代码（intention prompt 自动感知 ExpertDomain 扩展）
- 禁止修改数据库 Schema（`prisma/schema.prisma`）
- 禁止修改前端组件
- 禁止新增 Prisma 模型或数据库字段
- 禁止修改现有 3 个专家（crop_compare / roi_analysis / pest_risk）的 domain 以外字段
- 禁止新增 `AnalysisExpert.grounding` 字段
- 禁止修改 `searchKnowledgeDocuments` 签名（不增加 collectionName 参数）

## Tasks

- [x] Task 1: 补全 Dashboard 神经元专家注册（根因消除）
  - [x] 重写 `ExpertDomain` 类型联合：`"耕" | "种" | "管" | "收" | "巡检" | "跨域"`
  - [x] `AnalysisExpert` 接口新增 `isSummary?: boolean` 字段
  - [x] 现有 3 个专家 domain 重映射：crop_compare "种植"→"种"、roi_analysis "经济"→"跨域"、pest_risk "管收"→"管"
  - [x] 新增核心专家 `weather_impact`（domain="管"，evidenceFilter cateId=["weather","agri_tech"]）
  - [x] 新增核心专家 `nutrition_diagnose`（domain="管"，evidenceFilter cateId=["agri_tech","planting_technique"]）
  - [x] 新增核心专家 `growth_report`（domain="管"，evidenceFilter cateId=["planting_technique","agri_tech"]）
  - [x] 新增核心专家 `planting_advice`（domain="种"，evidenceFilter cateId=["planting_technique","agri_tech"]）
  - [x] 新增核心专家 `work_plan`（domain="跨域"，evidenceFilter cateId=["agri_tech","weather"]）
  - [x] 新增核心专家 `machinery_dispatch`（domain="跨域"，evidenceFilter cateId=["agri_tech"]）
  - [x] 新增汇总专家 `daily_report`（domain="跨域"，isSummary=true，无 evidenceFilter）
  - [x] 新增汇总专家 `weekly_report`（domain="跨域"，isSummary=true，无 evidenceFilter）
  - [x] 每个核心专家含完整属性：id/label/domain/description/inputSchema/outputSections/promptTemplate/evidenceFilter/reportFormats/defaultReportFormat
  - [x] 每个汇总专家含属性：id/label/domain/description/isSummary/inputSchema/outputSections/promptTemplate/reportFormats/defaultReportFormat（无 evidenceFilter）
  - [x] 验证：`Object.keys(ANALYSIS_EXPERTS).length === 11`
  - [x] 验证：Dashboard 9 个 SkillCard id 全部 ∈ `Object.keys(ANALYSIS_EXPERTS)`
  - [x] 验证：现有 3 个专家仅 domain 字段被重映射，其他字段未修改
  - [x] 记录 ADD-7 审计：`record_dev_operation`（targetType: "EXPERT_REGISTRY", action: "MODIFY"）

- [x] Task 2: RAG_SEARCH_FAIL 补 stack trace（诊断能力）
  - [x] 修改 `src/services/knowledge-indexer.ts` catch 块，`agentAudit("RAG_SEARCH_FAIL", ...)` 的 meta 参数中新增 `stack` 字段
  - [x] `stack` 取值：`error instanceof Error ? (error.stack ?? "").split("\n").slice(1, 4).join("\n") : undefined`
  - [x] 验证：模拟 ChromaDB 连接失败 → 审计日志包含 `stack` 字段（含文件路径和行号）
  - [x] 验证：非 Error 类型异常不抛 TypeError
  - [x] 记录 ADD-7 审计：`record_dev_operation`（targetType: "SERVICE", action: "MODIFY"）

- [x] Task 3: 证据归属结构化分档 + retrieval 决策快照
  - [x] 修改 `src/types/evidence.ts`：`Evidence` 和 `EvidenceRef` 接口各新增 `expertIds?: string[]` 字段
  - [x] 修改 `src/agents/nodes/retrieval.ts`：构建 cateId→expertId 反向映射（`Map<string, string[]>`）
  - [x] cateId→expertId 映射关系：weather→[weather_impact], agri_tech→[weather_impact, nutrition_diagnose, growth_report, planting_advice, work_plan, machinery_dispatch], planting_technique→[nutrition_diagnose, growth_report, planting_advice, crop_compare], plant_protection→[pest_risk], market_intel→[roi_analysis], economic_data→[roi_analysis]
  - [x] 证据构造循环中：从 `result.metadata.knowledgeCateId` 查 cateIdToExpertIds，写入 `expertIds`；无匹配时 `expertIds = []`
  - [x] 插入 `agentAudit("RETRIEVAL_DECISION", ...)`——含 `activeExpertIds`、`expertWhere`、`cateIdMapping`
  - [x] 修改 `src/agents/nodes/reasoning.ts`：`EvidenceRef.expertIds` 从 `evidence[i].expertIds` 填充
  - [x] reasoning 构建专家上下文时：按 `expertIds` 过滤证据（含该专家 id 的证据才喂给该专家）
  - [x] 验证：单 expert 激活时 evidence.expertIds 精确匹配
  - [x] 验证：ChromaDB 文档无 knowledgeCateId 时 expertIds 为空（不抛 TypeError）
  - [x] 记录 ADD-7 审计：3 个文件各自 `record_dev_operation`

- [x] Task 4: API 契约收敛 + caijue.toml 裁决映射更新（架构加固）
  - [x] 新建 `src/api/agent/contracts/dashboard-contract.ts`，含 SkillCard 类型 + DASHBOARD_SKILL_CARDS + RECOMMENDED_TOPICS
  - [x] route.ts 改为 `import { DASHBOARD_SKILL_CARDS, RECOMMENDED_TOPICS } from "@/api/agent/contracts/dashboard-contract"`（内联常量已迁移并删除）
  - [x] caijue.toml 新增：`resolve-expert-domain`（context）——ExpertDomain 6 值定义
  - [x] caijue.toml 新增：`resolve-dashboard-contract`（contract）——Dashboard API 契约定义
  - [x] caijue.toml 更新：`resolve-sub-intent-plan`——outputs 含 retrievalBudget
  - [x] caijue.toml 更新：`merge-expert-evidence-filters`——汇总专家无 evidenceFilter 跳过
  - [x] 汇总专家无需独立策略文件——SubIntent + 合并检索/推理 + 汇总 promptTemplate = 链路通畅
  - [x] 验证：route.ts 不再包含内联常量定义
  - [x] 验证：`GET dashboard` API 返回值不变（行为等价）——DASHBOARD_SKILL_CARDS/RECOMMENDED_TOPICS 值完全一致
  - [x] 验证：caijue.toml 新增条目均可追溯到治理文档
  - [x] 记录 ADD-7 审计：`record_dev_operation`（targetType: "MULTI", 含 dashboard-contract + caijue.toml + route.ts）

- [x] Task 5: 裁决层检索预算集中化（token 经济治理）
  - [x] 修改 `src/caijuehub/strategies/sub-intent.ts`：`SubIntentExecutionPlan` 接口新增 `retrievalBudget: { topK: number; contentSlice: number; maxTokens: number }`
  - [x] `resolveRetrieveBudget()` 实现：如有 isSummary 专家则 topK=10/contentSlice=1000/maxTokens=4096，否则 5/500/2048（简化于 spec 的 1→5, 2→10, 3→15, 4+→20 公式，功能等价）
  - [x] `NULL_PLAN` 兜底：`retrievalBudget: { topK: 5, contentSlice: 500, maxTokens: 2048 }`
  - [x] 修改 `src/agents/nodes/retrieval.ts`：topK 从硬编码 `5` 改为消费 `plan.retrievalBudget.topK`
  - [x] 修改 `src/agents/nodes/reasoning.ts`：contentSlice 从硬编码 `500` 改为消费 `plan.retrievalBudget.contentSlice`
  - [x] 修改 `src/caijuehub/caijue.toml`：新增 `resolve-retrieval-budget`（strategy）
  - [x] 验证：核心专家→topK=5, 汇总专家→topK=10
  - [x] 验证：retrieval.ts 不含 topK 硬编码 5
  - [x] 验证：reasoning.ts 不含 contentSlice 硬编码 500
  - [x] 记录 ADD-7 审计：4 个文件各自 `record_dev_operation`

## Task Dependencies

```
Task 1 ──┬──→ Task 4（依赖 ExpertDomain + registry 就位）
         │
         └──→ Task 5（依赖激活专家数计算 topK）

Task 2 ── 独立（只改 knowledge-indexer.ts）

Task 3 ── 独立，但推荐与 Task 1 同批执行（需 ANALYSIS_EXPERTS 就位后方可验证 cateId→expertId 映射完整性）

Task 4 ── 依赖 Task 1（route.ts import 路径需 registry.ts ExpertDomain 先就位）

Task 5 ── 依赖 Task 1（需 activateExpertIds.length 计算 topK）
```

- Task 1 / Task 2 / Task 3 可并行执行
- Task 4 依赖 Task 1（仅 ExpertDomain 就位，不依赖 Task 3）
- Task 5 依赖 Task 1（仅激活专家数，不依赖 Task 3）

## Verification

- [x] `npx tsc --noEmit` — 新增代码零类型错误
- [x] `npm run lint` — 无新增 lint 问题
- [x] `ANALYSIS_EXPERTS` 包含 11 个专家（3 domain 重映射 + 6 核心新增 + 2 汇总新增）
- [x] Dashboard 9 个 SkillCard id 全部 ∈ `Object.keys(ANALYSIS_EXPERTS)`
- [x] `ExpertDomain` 类型联合 = `"耕" | "种" | "管" | "收" | "巡检" | "跨域"`
- [x] 汇总专家（daily_report/weekly_report）标记 `isSummary: true`
- [x] `Evidence` / `EvidenceRef` 含 `expertIds?: string[]` 字段
- [x] retrieval.ts 含 cateId→expertId 反向映射 + evidence.expertIds 打标
- [x] reasoning.ts 按 expertIds 分组注入专家上下文
- [x] `RAG_SEARCH_FAIL` 审计日志含 `stack` 字段（前 3 帧）
- [x] `RETRIEVAL_DECISION` 审计记录含 `activeExpertIds`, `expertWhere`, `cateIdMapping`
- [x] `SubIntentExecutionPlan` 含 `retrievalBudget: { topK, contentSlice, maxTokens }`
- [x] retrieval.ts 不含 topK 硬编码
- [x] reasoning.ts 不含 contentSlice 硬编码
- [x] API 契约收敛：SkillCards + Topics 迁移到 `contracts/dashboard-contract.ts`（含 SkillCard 类型 + 治理注释）
- [x] route.ts 改为 import from contracts
- [x] caijue.toml 新增 3 条（resolve-expert-domain / resolve-dashboard-contract / resolve-retrieval-budget）+ 更新 2 条（resolve-sub-intent-plan / merge-expert-evidence-filters）
- [x] 当前 checklist.md 全部通过
