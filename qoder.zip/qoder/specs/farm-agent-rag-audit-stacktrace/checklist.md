# Checklist: RAG 链路加固 — 专家全量注册 + 证据分档 + 检索预算集中化

## Task 1: Dashboard 神经元专家全量补全（三层架构）

- [x] `ExpertDomain` 类型联合 = 6 值：`"耕" | "种" | "管" | "收" | "巡检" | "跨域"`
- [x] `AnalysisExpert` 接口含 `isSummary?: boolean` 字段
- [x] `ANALYSIS_EXPERTS` 含 11 个专家（3 domain 重映射 + 6 核心新增 + 2 汇总新增）
- [x] 现有专家 domain 重映射：`crop_compare` "种植"→"种"、`roi_analysis` "经济"→"跨域"、`pest_risk` "管收"→"管"
- [x] 新增核心专家 `weather_impact`：domain="管"，evidenceFilter cateId=["weather","agri_tech"]
- [x] 新增核心专家 `nutrition_diagnose`：domain="管"，evidenceFilter cateId=["agri_tech","planting_technique"]
- [x] 新增核心专家 `growth_report`：domain="管"，evidenceFilter cateId=["planting_technique","agri_tech"]
- [x] 新增核心专家 `planting_advice`：domain="种"，evidenceFilter cateId=["planting_technique","agri_tech"]
- [x] 新增核心专家 `work_plan`：domain="跨域"，evidenceFilter cateId=["agri_tech","weather"]
- [x] 新增核心专家 `machinery_dispatch`：domain="跨域"，evidenceFilter cateId=["agri_tech"]
- [x] 新增汇总专家 `daily_report`：domain="跨域"，`isSummary: true`，无 evidenceFilter
- [x] 新增汇总专家 `weekly_report`：domain="跨域"，`isSummary: true`，无 evidenceFilter
- [x] 每个核心专家含完整属性：id/label/domain/description/inputSchema/outputSections/promptTemplate/evidenceFilter/reportFormats/defaultReportFormat
- [x] 每个汇总专家含属性：id/label/domain/description/isSummary/inputSchema/outputSections/promptTemplate/reportFormats/defaultReportFormat（无 evidenceFilter）
- [x] Dashboard 9 个 SkillCard id 全部 ∈ `Object.keys(ANALYSIS_EXPERTS)`
- [x] 现有 3 个专家仅 domain 字段被重映射，其他字段未修改
- [x] 所有专家的 `outputSections` 使用 `ResponseSectionType` 联合类型成员
- [x] 注册表只增不减

## Task 2: RAG_SEARCH_FAIL 补 stack trace

- [x] `src/services/knowledge-indexer.ts` catch 块 `agentAudit("RAG_SEARCH_FAIL", ...)` 的 meta 参数含 `stack` 字段
- [x] `stack` 取值逻辑：`error instanceof Error` 时取 `error.stack` 前 3 帧（split+slice+join）
- [x] 非 Error 类型异常时 `stack` 为 `undefined`，不抛 TypeError
- [x] 现有 `error` 字段行为不变（仍为 `error.message` 或 `String(error)`）

## Task 3: 证据归属结构化分档 + retrieval 决策快照

- [x] `src/types/evidence.ts`：`Evidence` 接口含 `expertIds?: string[]`
- [x] `src/types/evidence.ts`：`EvidenceRef` 接口含 `expertIds?: string[]`
- [x] `src/agents/nodes/retrieval.ts`：构建 cateId→expertId 反向映射（`Map<string, string[]>`）
- [x] cateId→expertId 映射精确：weather→[weather_impact], agri_tech→[...], planting_technique→[...], plant_protection→[pest_risk], market_intel→[roi_analysis], economic_data→[roi_analysis]
- [x] 证据构造循环中从 `result.metadata.knowledgeCateId` 查映射，写入 `expertIds`；无匹配时 `expertIds = []`（不抛 TypeError）
- [x] `agentAudit("RETRIEVAL_DECISION", ...)` 记录含 `activeExpertIds`、`expertWhere`、`cateIdMapping`
- [x] `src/agents/nodes/reasoning.ts`：`EvidenceRef.expertIds` 从 `evidence[i].expertIds` 填充
- [x] reasoning 构建专家上下文时按 `expertIds` 过滤证据（含该专家 id 的证据才喂给该专家）
- [x] 使用业务审计通道（`agentAudit`），不混入 L2 基础设施日志

## Task 4: API 契约收敛 + caijue.toml 裁决映射更新

- [x] `src/api/agent/contracts/dashboard-contract.ts` 新建，含 SkillCard 类型 + DASHBOARD_SKILL_CARDS + RECOMMENDED_TOPICS
- [x] 契约文件含治理注释（指向 00-需求/《Dashboard 仪表盘交互规范》）
- [x] route.ts 改为 `import from "@/api/agent/contracts/dashboard-contract"`，删除内联常量
- [x] `GET dashboard` API 返回值不变（行为等价）
- [x] caijue.toml 新增 `resolve-expert-domain`（context，ExpertDomain 6 值）
- [x] caijue.toml 新增 `resolve-dashboard-contract`（contract，API 契约定义）
- [x] caijue.toml 更新 `resolve-sub-intent-plan`——outputs 含 retrievalBudget
- [x] caijue.toml 更新 `merge-expert-evidence-filters`——汇总专家跳过
- [x] caijue.toml 头部类型注释新增 `contract` 裁决类型

## Task 5: 裁决层检索预算集中化

- [x] `SubIntentExecutionPlan` 含 `retrievalBudget: { topK: number; contentSlice: number; maxTokens: number }`
- [x] `resolveRetrieveBudget()` 按 isSummary 动态计算：核心专家 5/500/2048，汇总专家 10/1000/4096（简化于 spec 的 1→5/2→10/3→15/4+→20 公式）
- [x] `NULL_PLAN` 含 `retrievalBudget: { topK: 5, contentSlice: 500, maxTokens: 2048 }`
- [x] `retrieval.ts` topK 改为消费 `plan.retrievalBudget.topK`（不含硬编码 5）
- [x] `reasoning.ts` contentSlice 改为消费 `plan.retrievalBudget.contentSlice`（不含硬编码 500）
- [x] caijue.toml 新增 `resolve-retrieval-budget`（strategy）

## 编译与类型检查

- [x] `npx tsc --noEmit` 零新增类型错误
- [x] `npm run lint` 无新增 lint 问题

## ADD 规则合规检查

- [x] ADD-1 可观测性优先 — 全部 5 个 Task 均有审计记录
- [x] ADD-2 阶段标记对称 — 无新增阶段，无需检查
- [x] ADD-4 三通道输出 — 使用现有 `agentAudit`，自动满足
- [x] ADD-5 审计数据即业务数据 — 决策快照走业务审计通道
- [x] ADD-6 失败路径等价审计 — stack trace 确保失败路径信息密度 ≥ 成功路径
- [x] Plan/Spec 一致性（代码实现与文档定义一致）—— tasks.md + checklist.md 已同步更新
- [x] ADD-7 审计记录 — 7 个源文件均有 `record_dev_operation` 记录（新增 check_spec_sync 等 3 个工具文件额外记录）

## 运行时验证（`[R]` 项）

- [R] Dashboard 加载 → `availableExpertDomains` 含全部 9 个神经元对应 expertId
- [R] 用户点"天气影响"神经元 → intention 匹配 weather_impact → activeExpertIds 非空
- [R] 用户点"营养诊断"神经元 → intention 匹配 nutrition_diagnose → activeExpertIds 非空
- [R] 用户点"种植建议"神经元 → intention 匹配 planting_advice → activeExpertIds 非空
- [R] 模拟 ChromaDB 连接失败 → 审计日志包含 `stack` 字段（前 3 帧可定位到文件:行号）
- [R] 无专家激活时 → 审计日志可见 `RETRIEVAL_DECISION` 记录含 `activeExpertIds=(none), expertWhere=undefined`
- [R] 有 weather_impact 激活时 → 审计日志可见 `activeExpertIds=weather_impact, expertWhere=defined, cateIdMapping`
- [R] 单专家激活 → evidence.expertIds 精确匹配对应 expertId
- [R] 文档无 knowledgeCateId → evidence.expertIds 为空，系统不抛异常
