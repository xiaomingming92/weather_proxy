# RAG 链路加固 — 专家全量注册 + 证据分档 + 检索预算集中化 Spec

## Why

agrisynapse Dashboard 定义了 9 个神经元（Skill Cards），但 `ANALYSIS_EXPERTS` 仅有 3 个专家，8 个神经元缺专家。用户提问"最近天气对玉米生长有什么影响？"时，intention 无法匹配 weather_impact → activeExpertIds 为空 → `mergeExpertEvidenceFilters([])` 返回 `undefined` → `knowledge-indexer.ts` 中 `JSON.stringify(undefined)` 抛出 TypeError → catch 吞异常返回空数组 → LLM 零证据凭空回答。

更隐蔽的问题：合并查询返回扁平结果，`reasoning.ts` 把同一份证据列表发给所有专家，LLM 自己猜哪个证据属于哪个专家——证据归属缺失。

这不是孤立问题——任意 Dashboard 神经元未被 ANALYSIS_EXPERTS 覆盖，都会触发同类崩溃链路。需要在五个环节加固：根因消除（补全 Dashboard 全部神经元专家）、诊断能力补全（stack trace）、证据归属结构化分档（cateId→expertId）、决策可见性（业务审计快照）、检索预算集中化（token 经济治理）。

> **架构依据**：Plan §2.4 三层能力模型（业务域→能力专家→能力卡片），严格对齐《规划说明书》四·农业作业规划 + 五·经济要素联动

## What Changes

- 修改 `src/agents/experts/registry.ts`：重写 `ExpertDomain` 类型（对齐规划说明书 6 值）、现有 3 个专家 domain 重映射、新增 6 个核心专家 + 2 个汇总专家
- 修改 `src/services/knowledge-indexer.ts`：`RAG_SEARCH_FAIL` 审计日志补 `error.stack` 前 3 帧
- 修改 `src/types/evidence.ts`：`Evidence` + `EvidenceRef` 接口各新增 `expertIds?: string[]`
- 修改 `src/agents/nodes/retrieval.ts`：cateId→expertId 反向映射 + evidence.expertIds 打标 + `RETRIEVAL_DECISION` 审计 + topK 改为消费 `plan.retrievalBudget.topK`
- 修改 `src/agents/nodes/reasoning.ts`：`EvidenceRef.expertIds` 填充 + 按 expertIds 分组上下文注入 prompt + contentSlice 改为消费 `plan.retrievalBudget.contentSlice`
- 修改 `src/caijuehub/strategies/sub-intent.ts`：`SubIntentExecutionPlan` 新增 `retrievalBudget` 字段 + `resolveSubIntentPlan()` 动态计算
- 新建 `src/api/agent/contracts/dashboard-contract.ts`：从 route.ts 收敛 SkillCards + Topics
- 修改 `src/app/api/agent/[hash]/route.ts`：改为 import from contracts
- 修改 `src/caijuehub/caijue.toml`：新增 3 条 + 更新 2 条裁决条目

## Impact

- Affected specs: `co-agent-expert-registry`（大幅扩展专家注册表）
- Affected code: `src/agents/experts/registry.ts`、`src/services/knowledge-indexer.ts`、`src/types/evidence.ts`、`src/agents/nodes/retrieval.ts`、`src/agents/nodes/reasoning.ts`、`src/caijuehub/strategies/sub-intent.ts`、`src/api/agent/contracts/dashboard-contract.ts`、`src/app/api/agent/[hash]/route.ts`、`src/caijuehub/caijue.toml`（共 9 文件）
- 父 Plan: [farm-agent-rag-audit-stacktrace-plan-v1.md](../../plans/farm-agent-rag-audit-stacktrace-plan-v1.md)
- 关联 Plan: [Expert Grounding RAG 适配 Plan](../../plans/farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md)（§3.3 降级路径与本 Plan 降级路径加固的协作接口）
- 依赖: Task 1 独立，Task 3/5 推荐与 Task 1 同批验证
- 后续依赖: Expert Grounding Plan（本 Plan 产出的 `evidence[i].expertIds` → Grounding Plan 平滑升级为 `evidence[i].grounding`）

## Boundaries

本次只允许实现：
- 重写 `ExpertDomain` 为 6 值：`"耕" | "种" | "管" | "收" | "巡检" | "跨域"`
- 现有 3 个专家 domain 重映射（crop_compare: "种植"→"种"，roi_analysis: "经济"→"跨域"，pest_risk: "管收"→"管"）
- 新增 6 个核心专家：weather_impact / nutrition_diagnose / growth_report / planting_advice / work_plan / machinery_dispatch
- 新增 2 个汇总专家（isSummary: true，无独立 evidenceFilter）：daily_report / weekly_report
- `AnalysisExpert` 接口新增 `isSummary?: boolean` 字段
- RAG_SEARCH_FAIL 日志补 stack 前 3 帧
- `Evidence` / `EvidenceRef` 接口各新增 `expertIds?: string[]`
- retrieval 节点 cateId→expertId 反向映射 + evidence.expertIds 打标 + RETRIEVAL_DECISION 审计（含 cateIdMapping）
- reasoning 节点 EvidenceRef.expertIds 填充 + 按 expertIds 分组上下文注入 prompt
- `SubIntentExecutionPlan` 新增 `retrievalBudget`（topK + contentSlice）
- retrieval.ts topK / reasoning.ts contentSlice 改为消费 plan.retrievalBudget
- API 契约收敛：DASHBOARD_SKILL_CARDS + RECOMMENDED_TOPICS 迁移到 contracts/
- caijue.toml 新增 3 条（resolve-expert-domain / resolve-dashboard-contract / resolve-retrieval-budget）+ 更新 2 条

本次禁止实现：
- 新增超过上述 8 个的专家
- 修改现有 3 个专家的 domain 以外字段
- 修改 ChromaDB 数据、索引逻辑、或 collection 结构（ChromaDB per-collection 创建属于 Expert Grounding Plan）
- 修改 prompt 模板或路由代码（intention prompt 自动感知 ExpertDomain 扩展）
- 新增数据库表或字段（走现有 agentAudit 通道）
- `AnalysisExpert.grounding` 字段（属于 Expert Grounding Plan Phase 2）
- `searchKnowledgeDocuments(collectionName)` 签名扩展（属于 Expert Grounding Plan Phase 3）
- `grounding.ready()` 健康检查逻辑（属于 Expert Grounding Plan Phase 2）

## Requirements

### Requirement: Dashboard 神经元专家全量补全（三层架构）

系统 SHALL 按 Plan §2.4 三层能力模型，在 `ANALYSIS_EXPERTS` 注册表中补全所有 agrisynapse Dashboard 神经元对应的专家。

**ExpertDomain 定义**（对齐《规划说明书》）：
```typescript
export type ExpertDomain = "耕" | "种" | "管" | "收" | "巡检" | "跨域"
```

**现有 3 个专家 domain 重映射**：

| 专家 ID | 旧 domain | 新 domain | 依据 |
|---------|----------|----------|------|
| `crop_compare` | "种植" | **种** | 三·3.1 候选作物对比 |
| `roi_analysis` | "经济" | **跨域** | 五·经济要素联动 |
| `pest_risk` | "管收" | **管** | 四·4.3 管理规划 |

**核心专家**（isSummary: false 显式声明，有独立 RAG 管线）：

| Dashboard 神经元 | 专家 ID | domain | evidenceFilter cateId |
|-----------------|---------|--------|----------------------|
| 生长报告 | `growth_report` | 管 | `["planting_technique","agri_tech"]` |
| 病虫害识别 | `pest_risk` ✅ 已有 | 管 | `["plant_protection","agri_tech"]` |
| 营养诊断 | `nutrition_diagnose` | 管 | `["agri_tech","planting_technique"]` |
| 天气影响 | `weather_impact` | 管 | `["weather","agri_tech"]` |
| 种植建议 | `planting_advice` | 种 | `["planting_technique","agri_tech"]` |
| 作物对比 | `crop_compare` ✅ 已有 | 种 | `["planting_technique"]` |
| ROI 分析 | `roi_analysis` ✅ 已有 | 跨域 | `["market_intel","economic_data"]` |
| 作业规划 | `work_plan` | 跨域 | `["agri_tech","weather"]` |
| 农机调度 | `machinery_dispatch` | 跨域 | `["agri_tech"]` |

**汇总专家**（isSummary: true，无独立 evidenceFilter，promptTemplate 为汇总模板）：

| Dashboard 神经元 | 专家 ID | domain | 汇总哪些核心专家的章节 |
|-----------------|---------|--------|------------------|
| 农情日报 | `daily_report` | 跨域 | weather_impact + growth_report + pest_risk + machinery_dispatch 等 |
| 周报分析 | `weekly_report` | 跨域 | 同上 + roi_analysis |

汇总专家无 evidenceFilter，不运行独立 RAG 检索，其 promptTemplate 指示 LLM 按章节汇总各核心专家的独立报告。

#### Scenario: 注册表含 11 专家

- **WHEN** 运行时读取 `ANALYSIS_EXPERTS`
- **THEN** `Object.keys(ANALYSIS_EXPERTS).length === 11`
- **THEN** Dashboard 9 个 SkillCard id 全部 ∈ `Object.keys(ANALYSIS_EXPERTS)`
- **THEN** 汇总专家（daily_report/weekly_report）的 `isSummary === true`
- **THEN** 核心专家 `isSummary: false`（显式声明）

#### Scenario: Dashboard 神经元全匹配

- **WHEN** 用户点击 Dashboard 任意神经元（如"天气影响"）
- **THEN** intention prompt 的 `availableExpertDomains` 包含对应 expertId
- **THEN** intention 可匹配 → activeExpertIds 非空 → `mergeExpertEvidenceFilters` 返回非 undefined

#### Scenario: 现有专家仅 domain 重映射

- **WHEN** 用户提问"对比水稻和玉米"
- **THEN** crop_compare 专家除 domain 字段外行为与变更前完全一致

### Requirement: RAG_SEARCH_FAIL 补 stack trace

系统 SHALL 在 `knowledge-indexer.ts` 的 `RAG_SEARCH_FAIL` 审计日志中补充 `error.stack` 前 3 帧，使单条日志即可定位崩溃位置。

#### Scenario: 异常时日志含 stack

- **WHEN** `searchKnowledgeDocuments` 执行中抛出异常
- **THEN** `RAG_SEARCH_FAIL` 审计日志 meta 含 `stack` 字段（前 3 帧）
- **THEN** stack 帧可定位到具体文件和行号

#### Scenario: 非 Error 类型异常兼容

- **WHEN** catch 块捕获的不是 Error 实例（如 `throw "string"`）
- **THEN** `stack` 字段为 `undefined`，不抛 TypeError

### Requirement: 证据归属结构化分档（cateId→expertId）+ retrieval 决策快照

系统 SHALL 在 retrieval 节点合并查询后，构建 cateId→expertId 反向映射，为每条 evidence 打标 `expertIds`。reasoning 节点 SHALL 按 expertIds 分组将证据注入对应专家的分析上下文。同时 SHALL 记录 RETRIEVAL_DECISION 审计快照。

**cateId → expertId 映射关系**（确定性，无需反查）：

| cateId | 对应专家 |
|--------|---------|
| `weather` | weather_impact |
| `agri_tech` | weather_impact, nutrition_diagnose, growth_report, planting_advice, work_plan, machinery_dispatch |
| `planting_technique` | nutrition_diagnose, growth_report, planting_advice, crop_compare |
| `plant_protection` | pest_risk |
| `market_intel` | roi_analysis |
| `economic_data` | roi_analysis |

#### Scenario: 单专家激活时证据打标

- **WHEN** 仅 weather_impact 激活，ChromaDB 返回 weather 类型文档
- **THEN** `evidence.expertIds = ["weather_impact"]`
- **THEN** reasoning 将文档只喂给 weather_impact 专家

#### Scenario: 多专家激活时证据共享

- **WHEN** weather_impact + nutrition_diagnose 同时激活，ChromaDB 返回 agri_tech 类型文档
- **THEN** `evidence.expertIds = ["weather_impact", "nutrition_diagnose"]`
- **THEN** reasoning 将文档同时喂给两个专家

#### Scenario: ChromaDB 文档无 knowledgeCateId

- **WHEN** 文档 metadata 缺少 `knowledgeCateId` 或为未知值
- **THEN** `evidence.expertIds = []` → 不打标（行为等价于当前：证据归全体专家）

#### Scenario: RETRIEVAL_DECISION 审计

- **WHEN** retrieval 节点执行检索
- **THEN** 审计日志含 `activeExpertIds`、`expertWhere`、`cateIdMapping`
- **THEN** 无专家激活时 `activeExpertIds=(none), expertWhere=undefined`

### Requirement: 裁决层检索预算集中化（token 经济治理）

系统 SHALL 将 topK / contentSlice 从节点硬编码上升为裁决层策略决策。`SubIntentExecutionPlan` 新增 `retrievalBudget` 字段，`resolveSubIntentPlan()` 按激活专家数动态计算。retrieval.ts 和 reasoning.ts 消费 plan 而非硬编码。

#### Scenario: 检索预算动态计算

- **WHEN** 1 个专家激活
- **THEN** `plan.retrievalBudget.topK === 5`, `contentSlice === 500`
- **WHEN** 2 个专家激活
- **THEN** `plan.retrievalBudget.topK === 10`, `contentSlice === 500`
- **WHEN** 4+ 个专家激活
- **THEN** `plan.retrievalBudget.topK === 20`（封顶）, `contentSlice === 300`

#### Scenario: NULL_PLAN 兜底

- **WHEN** 无 subIntents（返回 NULL_PLAN）
- **THEN** `plan.retrievalBudget = { topK: 5, contentSlice: 500 }`

#### Scenario: 节点不再硬编码

- **WHEN** 阅读 retrieval.ts / reasoning.ts
- **THEN** 源码不含 `5` 或 `500` 的硬编码 topK / contentSlice 值

### Requirement: API 契约层收敛 + caijue.toml 裁决映射更新

系统 SHALL 将散落在 route.ts 内联的 DASHBOARD_SKILL_CARDS + RECOMMENDED_TOPICS 收敛到独立的 API 契约层（`src/api/agent/contracts/dashboard-contract.ts`），每个对接方有独立契约文件，route.ts 改为 import。同时更新 caijue.toml 裁决映射，使全部决策可追溯。

#### Scenario: API 契约收敛

- **WHEN** 运行时加载 `GET dashboard` API
- **THEN** 返回值来源为 `src/api/agent/contracts/dashboard-contract.ts`
- **THEN** API 返回值与收敛前完全一致（行为等价）
- **THEN** route.ts 不再包含 DASHBOARD_SKILL_CARDS / RECOMMENDED_TOPICS 内联定义

#### Scenario: caijue.toml 裁决映射完整

- **WHEN** 查阅 `src/caijuehub/caijue.toml`
- **THEN** 包含 `resolve-expert-domain`（context）——ExpertDomain 6 值定义
- **THEN** 包含 `resolve-dashboard-contract`（contract）——Dashboard API 契约定义
- **THEN** 包含 `resolve-retrieval-budget`（strategy）——检索预算裁决
- **THEN** `resolve-sub-intent-plan` 已标注 isSummary 感知
- **THEN** `merge-expert-evidence-filters` 已标注汇总专家跳过
- **THEN** 所有条目均可追溯到 00-需求文档

## MODIFIED Requirements

无（纯增强现有逻辑 + 架构收敛 + 证据归属新增 + 检索预算新增）

## REMOVED Requirements

无
