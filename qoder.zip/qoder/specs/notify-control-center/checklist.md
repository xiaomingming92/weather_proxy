# Checklist: Notify Control Center

## Phase 1: 核心架构

- [x] types.ts 定义 NotifyAlert + NotifyChannel 接口
- [x] wecom channel 实现 NotifyChannel，行为与原 wecom-notify.ts 一致
- [x] dingtalk channel 骨架（enabled=false）
- [x] feishu channel 骨架（enabled=false）

## Phase 2: 控制中心

- [x] control.ts sendAlert() fan-out 到所有 enabled channel
- [x] index.ts 统一 re-export

## Phase 3: 迁移

- [x] wecom-notify.ts 改为兼容层，已有 import 仍有效
- [x] agent-audit-logger.ts 改用 sendAlert()

## Phase 4: 环境变量

- [x] .env.example 含 DINGTALK_WEBHOOK_URL / FEISHU_WEBHOOK_URL
- [x] .env.development 含 DINGTALK_WEBHOOK_URL / FEISHU_WEBHOOK_URL

## 编译验证

- [T] `npx tsc --noEmit`
