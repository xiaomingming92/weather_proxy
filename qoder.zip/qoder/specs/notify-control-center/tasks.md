# Tasks: Notify Control Center

## Preconditions

- [x] 设计已确认：fan-out 控制中心 + channel 可插拔
- [x] 现有 wecom-notify.ts 逻辑完整可迁移

## Forbidden

- 禁止修改 agent-audit-logger.ts 中除 import 和 sendWecomAlert 调用外的任何逻辑
- 禁止改变企微 webhook 调用行为
- 禁止删除 wecom-notify.ts（改为兼容层）

---

## Phase 1: 核心架构

- [ ] **Task 1.1**: 创建 `src/lib/notify/types.ts` — NotifyAlert / NotifyChannel 接口
  - [ ] 验证: 接口定义完整，无需依赖任何项目模块

- [ ] **Task 1.2**: 创建 `src/lib/notify/channels/wecom.ts`
  - [ ] 从 wecom-notify.ts 迁移 webhook 调用逻辑
  - [ ] 实现 NotifyChannel 接口
  - [ ] 独立失败计数器
  - [ ] 验证: 行为与原 wecom-notify.ts 完全一致

- [ ] **Task 1.3**: 创建 `src/lib/notify/channels/dingtalk.ts`
  - [ ] 骨架：实现 NotifyChannel，enabled 返回 false
  - [ ] 占位 send() 含 console.warn "not implemented"
  - [ ] 验证: `npx tsc --noEmit` 通过

- [ ] **Task 1.4**: 创建 `src/lib/notify/channels/feishu.ts`
  - [ ] 骨架：实现 NotifyChannel，enabled 返回 false
  - [ ] 占位 send() 含 console.warn "not implemented"
  - [ ] 验证: `npx tsc --noEmit` 通过

## Phase 2: 控制中心 + 统一出口

- [ ] **Task 2.1**: 创建 `src/lib/notify/control.ts`
  - [ ] NotifyControl 类：channel 注册 + sendAlert fan-out
  - [ ] 导出便捷函数 `sendAlert()`
  - [ ] 验证: `npx tsc --noEmit` 通过

- [ ] **Task 2.2**: 创建 `src/lib/notify/index.ts`
  - [ ] re-export: sendAlert, NotifyAlert, NotifyChannel, getWecomSendFailCount
  - [ ] 验证: import 路径正确

## Phase 3: 迁移调用点 + 兼容层

- [ ] **Task 3.1**: 修改 `src/lib/wecom-notify.ts` 为兼容层
  - [ ] re-export sendAlert / getWecomSendFailCount
  - [ ] 保留 WecomAlertOptions 类型别名
  - [ ] 验证: 已有 import 无需改动

- [ ] **Task 3.2**: 修改 `src/lib/agent-audit-logger.ts`
  - [ ] import sendAlert 替代 sendWecomAlert
  - [ ] sendWecomAlert({...}) → sendAlert({...})
  - [ ] 验证: `npx tsc --noEmit` 通过

## Phase 4: 环境变量

- [ ] **Task 4.1**: 更新 `.env.example` + `.env.development`
  - [ ] 添加 DINGTALK_WEBHOOK_URL（注释状态）
  - [ ] 添加 FEISHU_WEBHOOK_URL（注释状态）
  - [ ] 验证: 格式正确

## Task Dependencies

- Task 1.2 依赖 Task 1.1
- Task 2.1 依赖 Task 1.1 + 1.2
- Task 3.1 依赖 Task 2.1 + 2.2
- Task 3.2 依赖 Task 3.1

## Verification

- [ ] `npx tsc --noEmit` 零新增错误
- [ ] 企微通知测试脚本仍正常工作
- [ ] wecom-notify.ts 导入兼容（已有代码无需改动）
