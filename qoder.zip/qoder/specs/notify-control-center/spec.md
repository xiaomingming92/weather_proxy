# Notify Control Center Spec

## Why

当前 `agent-audit-logger.ts` 硬编码 `sendWecomAlert()`，无法扩展钉钉/飞书等多渠道。需抽象通知控制中心，实现 channel 可插拔。

## What Changes

| 文件 | 操作 | 内容 |
|------|------|------|
| src/lib/notify/types.ts | 新建 | NotifyAlert / NotifyChannel 接口 |
| src/lib/notify/control.ts | 新建 | NotifyControl 控制中心（fan-out） |
| src/lib/notify/channels/wecom.ts | 新建 | 企微 channel（从 wecom-notify.ts 迁移核心逻辑） |
| src/lib/notify/channels/dingtalk.ts | 新建 | 钉钉骨架（占位，后续填充） |
| src/lib/notify/channels/feishu.ts | 新建 | 飞书骨架（占位，后续填充） |
| src/lib/notify/index.ts | 新建 | 统一 re-export |
| src/lib/wecom-notify.ts | 修改 | 改为兼容层，re-export 新接口 |
| src/lib/agent-audit-logger.ts | 修改 | sendWecomAlert() → sendAlert() |
| .env.example | 修改 | 添加 DINGTALK_WEBHOOK_URL / FEISHU_WEBHOOK_URL |
| .env.development | 修改 | 同上 |

## Impact

- Affected specs: code-review-fixes（#12 告警链路升级）
- Affected code: agent-audit-logger.ts, wecom-notify.ts
- 父 Plan: `.qoder/plans/2026-06/30/farm-agent-notify-control-center-plan-v1.md`
- 依赖: 无
- 后续依赖: 后续可启用钉钉/飞书 channel

## Boundaries

本次只允许实现：
- 通知控制中心架构（types + control + channels）
- 企微 channel 完整实现
- 钉钉/飞书 channel 骨架（类型定义 + 占位 send）
- agent-audit-logger.ts 调用点迁移
- wecom-notify.ts 改为兼容层

本次禁止实现：
- 钉钉/飞书 webhook 完整逻辑
- 其他业务模块的通知接入

## Requirements

### Requirement: 通知控制中心 fan-out

系统 SHALL 通过 `sendAlert()` 将告警 fan-out 到所有已启用的 channel，单个 channel 失败不影响其他 channel。

#### Scenario: 多 channel 并行发送

- **WHEN** 调用 `sendAlert({ title, content, level })`
- **THEN** 所有 `enabled === true` 的 channel 并行收到告警
- **AND** 单个 channel 失败以 `console.error` 记录，不抛出异常

### Requirement: Channel 接口可插拔

新增通知渠道 SHALL 仅需实现 `NotifyChannel` 接口并注册到 `notifyChannels` 数组，无需修改调用方代码。

#### Scenario: 新增钉钉 channel

- **WHEN** 开发者在 `channels/dingtalk.ts` 实现 `NotifyChannel`
- **AND** 在 `control.ts` 中 `notifyChannels.push(dingtalkChannel)`
- **THEN** `sendAlert()` 自动 fan-out 到钉钉

### Requirement: 企微 channel 行为不变

企微 channel SHALL 保持与 `wecom-notify.ts` 完全相同的 webhook 调用逻辑和失败计数。

### Requirement: wecom-notify.ts 向后兼容

`wecom-notify.ts` SHALL 作为兼容层 re-export `sendAlert` / `getWecomSendFailCount`，已有 import 无需修改即可工作。
