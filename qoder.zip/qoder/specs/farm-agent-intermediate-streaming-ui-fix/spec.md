# 流式中间态 UI 修复 Spec

## Why

用户点击"分析一周农场数据趋势"后，深度思考容器在 0~24s 流式中间态缺少两个关键视觉反馈：工具调用状态不可见（3 个实时工具执行了但 UI 无反馈）；证据条走通用 RAG 而非专家来源（`weekly_report` isSummary expert 无 grounding 回退到默认 Collection）。

## What Changes

| 文件 | 改动 |
|------|------|
| `src/agents/stream-bus.ts` | 新增 `ToolCallEvent` / `ToolResultEvent` 类型，加入 union + audit |
| `src/agents/node-stream-controller.ts` | 新增 `toolCall(toolName, args)` / `toolResult(toolName, result)` + `_traceToolCalls` 静态 Map + `collectStreamingTraces()` 返回 toolCalls |
| `src/agents/nodes/retrieval.ts` | isSummary expert 跳过 RAG 检索（不推送通用 knowledge 证据条） |
| `src/app/api/agent/chat/stream/route.ts` + `[hash]/route.ts` | 删除 route 层补丁 `toolCallsLog`，持久化统一走 streamingTraces 路径 |
| agrisynapse `LlmChatView.vue` | evidence-bar 按 source 区分 expert/knowledge 样式 |
| agrisynapse `src/store/modules/agentChat.ts` | loadThread 从 `streamingTraces.toolCalls` 读取（与 evidence/ragResult 一致） |

## Impact

- Affected specs: 无
- Affected code: `stream-bus.ts`, `node-stream-controller.ts`, `retrieval.ts`, agrisynapse `LlmChatView.vue`
- 父 Plan: `farm-agent-intermediate-streaming-ui-fix-plan-v1.md`
- 依赖: 无上游依赖
- 后续依赖: 无

## Boundaries

本次只允许实现：
- 补齐 tool_call/tool_result SSE 事件链路
- retrieval.ts 中 isSummary expert 跳过 RAG
- 前端 evidence-bar source 区分
- toolCalls 持久化路径统一到 NodeStreamController 静态缓存模式（架构级）

本次禁止实现：
- Expert Grounding Collection 向量数据初始化（那是另一个 Plan 的 Task 9）
- verdict 置信度 0% 显示修复（那是另一个 Plan 的范围）
- UI 重构或新增组件

## Requirements

### Requirement: tool_call SSE 事件推送

系统 SHALL 在 toolNode 执行每个工具前推送 `{type: "tool_call", toolName, args}`，完成后推送 `{type: "tool_result", toolName, result}`。

#### Scenario: 单工具执行

- **WHEN** toolNode 调用 `query_farm_weather`
- **THEN** 前端 `_dispatchEvent` 收到 `tool_call` 事件并 push 到 `msg.toolCalls`

#### Scenario: 多工具执行 + 持久化恢复

- **WHEN** 工具调用完成后页面刷新
- **THEN** 前端 loadThread 从 `streamingTraces.toolCalls` 恢复工具调用状态，含每项 `{toolName, args, result, status}`
- **THEN** 前端 `LlmChatView.vue` 深度思考容器中重新渲染工具调用项

### Requirement: toolCalls 持久化经 NodeStreamController 统一收集

系统 SHALL 通过 `NodeStreamController._traceToolCalls` 静态 Map 跨节点收集工具调用数据，经 `collectStreamingTraces()` 汇入 `streamingTraces.toolCalls`，最终持久化到 ChatMessage metadata。

#### Scenario: 正常流式过程中触发工具调用

- **WHEN** toolNode 多次调用 toolCall/toolResult
- **THEN** `_traceToolCalls` 按 traceId 收集所有调用，含 status 从 "calling" 更新为 "done"
- **THEN** `collectStreamingTraces()` 返回 `{evidence, ragResult, toolCalls}` 并清理缓存
- **THEN** toolCalls 出现在 `structuredResponse.streamingTraces.toolCalls` 中

#### Scenario: route 层无补丁代码

- **WHEN** route.ts registerStreamBus 被调用
- **THEN** 回调中不含任何 toolCallsLog 相关的收集逻辑，仅为纯 SSE 转发

### Requirement: isSummary expert 跳过 RAG

系统 SHALL 在 retrieval.ts per-expert 并行检索循环中跳过 `expert.isSummary === true` 的 expert。

#### Scenario: weekly_report 激活时

- **WHEN** analysisContext.activeExperts 含 weekly_report（isSummary: true）
- **THEN** retrieval 节点跳过 weekly_report 的 RAG 检索，不产生 source="knowledge" 的证据条
- **THEN** 审计日志记录 `EXPERT_SKIPPED` phase 说明跳过原因
