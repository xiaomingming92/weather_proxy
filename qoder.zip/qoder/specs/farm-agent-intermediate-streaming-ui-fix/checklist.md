# Checklist: 流式中间态 UI 修复

## Phase 1: SSE 事件链路

- [x] `ToolCallEvent` / `ToolResultEvent` 类型定义完整，加入 `StreamEvent` union
- [x] `resolveAuditPhase` 正确处理 `tool_call` / `tool_result`
- [x] `NodeStreamController.toolCall()` 正确 emit `{type: "tool_call", toolName, args}`
- [x] `NodeStreamController.toolResult()` 正确 emit `{type: "tool_result", toolName, result}`

## Phase 2: RAG 路由修复

- [x] isSummary expert（weekly_report / daily_report）在 retrieval 中跳过 RAG
- [x] 审计日志记录 `EXPERT_SKIPPED` phase
- [x] 非 isSummary expert（crop_compare / pest_risk 等）RAG 行为不变

## Phase 3: 前端渲染

- [ ] evidence-bar 按 source 区分样式（expert=绿色，knowledge=灰色）
- [x] toolCalls 渲染项在深度思考容器中可见
- [x] 工具结果数据表格渲染（getToolResultRows 解析分页响应 + 工具结果展开/折叠）
- [ ] 无数据时不 dump 原始 JSON，显示 "暂无数据" 友好提示
- [ ] 工具结果表格使用 el-table（非原生 table）

## Phase 3.5: 持久化（补丁方案，已被 Phase 4.5 重构取代）

- [x] route.ts SSE 闭包收集 toolCallsLog → metadata.toolCalls 写入 ChatMessage
- [x] agentChat.ts loadThread 从 metadata.toolCalls 恢复（替代 undefined）
- [x] 刷新页面后工具调用 DOM 不丢失

## Phase 4: 编译验证

- [x] `npx tsc --noEmit` 零错误（farm-agent）
- [x] `npx vue-tsc --noEmit` 无新增错误（agrisynapse）

## Phase 4.5: 架构重构 — 持久化从补丁到统一路径

- [x] `NodeStreamController._traceToolCalls` 静态 Map（与 _traceEvidence/_traceRagResult 同模式）
- [x] `toolCall()` push 到静态缓存 + emit
- [x] `toolResult()` 逆序匹配更新静态缓存 + emit
- [x] `collectStreamingTraces()` 返回 `{ evidence, ragResult, toolCalls }`
- [x] stream/route.ts 删除 `toolCallsLog` 补丁数组
- [x] [hash]/route.ts 删除 `toolCallsLog` 补丁数组
- [x] agrisynapse agentChat.ts 读取路径: `metaObj.toolCalls` → `st?.toolCalls`
- [x] metadata 持久化不单独合并 toolCallsLog，toolCalls 自然流经 structuredResponse.streamingTraces

## ADD 规则合规检查

- [ ] ADD-1 可观测性优先（tool_call/tool_result 审计日志已植入）
- [ ] ADD-2 阶段标记对称（stream-bus audit phase 有 tool_call/tool_result 映射）
- [ ] ADD-4 三通道输出（stream-bus 事件 → console + file + AuditLog）
- [ ] ADD-5 审计数据即业务数据（tool 执行审计通过 stream-bus 自动采样）
- [ ] Plan/Spec 一致性

## 跨项目联调检查

### 格式契约

- [T] SSE 事件 `type: "tool_call"` / `"tool_result"` 字段与前端 `_dispatchEvent` 解析一致
- [T] `msg.toolCalls.push({ toolName, args, status: "calling" })` 接收格式匹配

### E2E curl

- [R] 对 `/api/agent/[hash]` 发起对话，确认 SSE 流中含 `"type":"tool_call"` 事件
- [R] 对 `/api/agent/chat/stream` 发起对话，确认 SSE 流中含 `"type":"tool_result"` 事件
