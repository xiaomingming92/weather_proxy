# Tasks: 流式中间态 UI 修复

## Preconditions

- [x] Plan `farm-agent-intermediate-streaming-ui-fix-plan-v1.md` 已完成
- [x] 诊断已通过截图确认（缺口A：tool_call SSE 缺失，缺口B：isSummary expert 走通用 RAG）

## Forbidden

- 禁止修改 Expert Grounding Collection 向量数据初始化逻辑
- 禁止修改 verdict 置信度计算逻辑
- 禁止引入新的 npm 依赖

---

- [x] Task 1: stream-bus.ts 新增 ToolCallEvent / ToolResultEvent
  - [x] 新增 `ToolCallEvent` 接口（type: "tool_call", toolName, args）
  - [x] 新增 `ToolResultEvent` 接口（type: "tool_result", toolName, result）
  - [x] 加入 `StreamEvent` union type
  - [x] `resolveAuditPhase` 新增 `tool_call` / `tool_result` 分支
  - [x] `buildAuditDetail` 新增对应分支

- [x] Task 2: NodeStreamController 新增 toolCall/toolResult
  - [x] 新增 `toolCall(toolName: string, args: Record<string, unknown>)` 方法
  - [x] 新增 `toolResult(toolName: string, result: unknown)` 方法
  - [x] 每个方法内部 `this.emit({ type: ... })`

- [x] Task 3: retrieval.ts isSummary expert 跳过 RAG
  - [x] 在 per-expert 并行检索循环中，`expert.isSummary === true` 时 `agentAudit("EXPERT_SKIPPED", ...)` + `return []`
  - [x] 保留 `realtimeToolNames` 不受影响（工具调用不走 retrieval）

- [ ] Task 4: 前端 evidence-bar 区分 source
  - [ ] evidence-bar 渲染时判断 `ev.source`
  - [ ] `source === "expert"` → 绿色标签 + collectionName
  - [ ] `source === "knowledge"` → 灰色标签 + "通用知识库"

- [x] Task 5: tsc 编译验证
  - [x] `npx tsc --noEmit`（farm-agent）零错误
  - [x] `npx vue-tsc --noEmit`（agrisynapse）无新增错误

- [x] Task tc-b1: route.ts 工具调用持久化（补丁式，已被重构取代）
  - [x] → Task tc-r1~tc-r7 重构为 NodeStreamController 统一路径

- [x] Task tc-b2: agentChat.ts loadThread 恢复 toolCalls（已重构）
  - [x] → 改为从 `streamingTraces.toolCalls` 读取（与 evidence/ragResult 一致）

- [x] Task tc-r1: NodeStreamController 新增 `_traceToolCalls` 静态 Map
  - [x] 与 `_traceEvidence` / `_traceRagResult` 同模式，按 traceId 跨节点共享

- [x] Task tc-r2: toolCall() / toolResult() 加静态缓存收集
  - [x] `toolCall()` push 到 `_traceToolCalls` + emit
  - [x] `toolResult()` 逆序匹配更新同名工具调用 status + emit

- [x] Task tc-r3: collectStreamingTraces() 返回 toolCalls
  - [x] 从 `_traceToolCalls` 收集 + 清理
  - [x] 返回 `{ evidence, ragResult, toolCalls }`

- [x] Task tc-r4: stream/route.ts 删除补丁
  - [x] 删除 `toolCallsLog` 数组声明
  - [x] `registerStreamBus` 回调恢复为纯 SSE 转发
  - [x] metadata 不再单独合并 toolCallsLog

- [x] Task tc-r5: [hash]/route.ts 删除补丁
  - [x] 同 stream/route.ts

- [x] Task tc-r6: agrisynapse agentChat.ts 读取路径修正
  - [x] `metaObj.toolCalls` → `st?.toolCalls`

- [x] Task tc-r7: tsc 编译验证
  - [x] `npx tsc --noEmit`（farm-agent）零错误

- [x] Task a2: 前端工具渲染辅助函数
  - [x] toolDisplayName / toolResultSummary / getToolResultRows / getToolResultCols / formatToolResult
  - [x] 工具结果展开/折叠 toggleToolResult / isToolResultExpanded

- [ ] Task a4: reasoning.ts 修复 isSummary expert 的 isRagEmpty 误判
  - [ ] isSummary expert 在工具数据可用时跳过 "本轮RAG检索返回 0 条结果" 降级提示

- [x] Task a6: 工具结果表格升级
  - [x] (a) 无数据时显示 "暂无数据" 友好提示，不再 dump 原始 JSON
  - [x] (b) 有数据时替换原生 `<table>` 为 `<el-table>`
  - [x] (c) 证据链处工具数据表格同步替换为 el-table

- [x] Task a7: 工具返回列定义标准化
  - [x] (a) 后端 5 个工具各自声明 `columns: [{prop, label}]` 常量（`ToolColumn` 接口）
  - [x] (b) 后端新增 `unwrapPageResponse(raw)` 拍扁 farm-server 嵌套为 `{total, list}`
  - [x] (c) 工具返回格式标准化为 `{success, total, list, columns}`
  - [x] (d) 前端新增 `getTableColumns(result)` 直接读 `result.columns`（旧版兼容 Object.keys 降级）
  - [x] (e) 前端新增 `getDataRows(data)` 统一提取表格行数据
  - [x] (f) 前端模板 `:prop="col.prop"` / `:label="col.label"` 支持中文列名
  - [x] (g) 移除前端 `TOOL_FALLBACK_COLS` 常量

- [ ] Task a5: 浏览器截图验收

## Task Dependencies

- Task 1, Task 2, Task 3 可并行
- Task 4 无代码依赖

## Verification

- [ ] `npx tsc --noEmit` 零错误
- [ ] stream-bus 日志中出现 tool_call / tool_result 事件
- [ ] 浏览器截图确认工具调用状态在深度思考容器中可见
- [ ] 浏览器截图确认 evidence-bar 区分 expert/knowledge source
