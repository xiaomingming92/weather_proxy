# Agrisynapse API 文档通知体系 Spec

## Why
Agrisynapse 与 H5 共享 SSE 事件类型但缺乏独立的文档通知通道，版本变更无法自动推送到对接团队。

## What Changes
- 新增 `scripts/notify-agrisynapse-api-version.sh`：Agrisynapse 主文档版本变更通知
- 重构 `scripts/notify-h5-api-version.sh`：H5 主文档版本变更通知（重命名+重构）
- 新增 `scripts/_notify_lib.sh`：多平台 IM 推送共享库
- 新增 `src/app/api/agent/docs/[doc]/route.ts`：Agrisynapse 文档公网端点
- 更新 `.env.production` /.env.example`：分通道环境变量
- 更新 `.gitlab-ci.yml`：拆分 H5/Agrisynapse notify job
- 删除 `scripts/notify-doc-update.sh`：旧脚本

## Impact
- Affected specs: 无（新 spec）
- Affected code: `scripts/`, `src/app/api/agent/docs/`, `.gitlab-ci.yml`, `.env.*`
- 父 Plan: `farm-agent-agrisynapse-api-doc-notify-plan-v1.md`
- 依赖: `farm-agent-wecom-doc-notify-plan-v1.md`（参考旧实现）
- 后续依赖: 无

## Boundaries
本次只允许:
- 创建/重构通知脚本和共享推送库
- 新增 Agrisynapse 文档端点
- 更新 CI 和环境变量配置

本次禁止:
- 修改 H5 端点现有行为
- 引入新的第三方 IM SDK
- 在生产环境自动触发通知（仅 CI push 时触发）

## Requirements

### Requirement: Agrisynapse 文档变更自动通知
系统 SHALL 在 Git Push 到 main 且 `神经元GUI-API对接文档.md` 版本变更时，自动推送 IM 通知到 Agrisynapse 对接群。
- Scenario: Agrisynapse 主文档 v1.0 → v1.1，CI 检测到版本变更，推送到企业微信/钉钉
- Scenario: SSE 子文档变更但主文档未升版，CI 输出黄色警告

### Requirement: H5 文档变更自动通知
系统 SHALL 在 H5 主文档版本变更时，自动推送到 H5 对接群。
- Scenario: H5 主文档 v5.1 → v5.2，推送含版本号+变更说明+多格式链接的通知

### Requirement: Agrisynapse 文档公网端点
系统 SHALL 提供 `/api/agent/docs/agrisynapse` 和 `/api/agent/docs/agrisynapse-sse` 端点。
- Scenario: GET `/api/agent/docs/agrisynapse` → 返回 markdown
- Scenario: GET `/api/agent/docs/agrisynapse-sse?format=json` → 返回 JSON 分段

### Requirement: 多平台推送
系统 SHALL 支持企业微信 markdown、钉钉 markdown+HMAC-SHA256 加签、飞书 text 三种平台。
- Scenario: NOTIFY_WEBHOOK_URLS 包含企业微信 URL → 推送 markdown
- Scenario: DINGTALK_*_SECRET 已设置 → 自动加签

### Requirement: 钉钉加签变量正名
系统 SHALL 使用 `DINGTALK_*_SECRET` 命名钉钉加签变量，而非 `WECOM_*_KEY`。
