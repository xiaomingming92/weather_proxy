# Tasks: Agrisynapse API 文档通知体系

## Preconditions
- [x] `farm-agent-wecom-doc-notify-plan-v1.md` 参考实现就绪
- [x] `.env.production` 有 IM 群 Webhook URL

## Forbidden
- 禁止复用 H5 的 `/api/h5/docs` 路径给 Agrisynapse
- 禁止在通知消息中硬编码文档路径

- [x] Task 1: 创建共享推送库 `scripts/_notify_lib.sh`
  - [x] 实现 escape_json 转义函数
  - [x] 实现 detect_platform 平台识别
  - [x] 实现 push_all：企业微信/钉钉加签/飞书三平台推送
  - [x] 按 CHANNEL_NAME 构建文档链接
  - [x] 验证: bash 语法检查通过

- [x] Task 2: 重构 H5 通知脚本 `scripts/notify-h5-api-version.sh`
  - [x] 重命名：`notify-h5-sse-sync.sh` → `notify-h5-api-version.sh`
  - [x] 改检测逻辑：SSE 基线比对 → 主文档版本 git diff
  - [x] 调用 `_notify_lib.sh` push_all
  - [x] 验证: `bash notify-h5-api-version.sh HEAD~1 HEAD` 正常退出

- [x] Task 3: 创建 Agrisynapse 通知脚本 `scripts/notify-agrisynapse-api-version.sh`
  - [x] 检测 `神经元GUI-API对接文档.md` 版本变更
  - [x] SSE 子文档变更但主文档未升版 → 警告
  - [x] 调用 `_notify_lib.sh` push_all
  - [x] 验证: `bash notify-agrisynapse-api-version.sh HEAD~1 HEAD` 正常退出

- [x] Task 4: 创建 Agrisynapse 文档端点 `src/app/api/agent/docs/[doc]/route.ts`
  - [x] 注册 `agrisynapse` + `agrisynapse-sse` 文档路径
  - [x] 支持 markdown/json 格式
  - [x] 验证: curl 可访问

- [x] Task 5: 环境变量对齐
  - [x] `.env.production` 分通道块（H5 + Agrisynapse）
  - [x] `.env.example` 移除通用通道，仅保留分通道
  - [x] 钉钉加签变量正名: `WECOM_*_KEY/SECRET` → `DINGTALK_*_SECRET`
  - [x] 删除 `DINGTALK_*_KEY`（钉钉只需要 SECRET）

- [x] Task 6: CI 配置 `.gitlab-ci.yml`
  - [x] 拆分 `notify` job 为 `notify-h5` + `notify-agrisynapse`
  - [x] 传入 `$CI_COMMIT_BEFORE_SHA $CI_COMMIT_SHA`
  - [x] 统一 source `.env.production`
  - [x] 验证: CI Lint 通过

- [x] Task 7: 清理
  - [x] 删除 `scripts/notify-doc-update.sh`

## Task Dependencies
- Task 2,3 依赖 Task 1（共享库）
- Task 5 依赖 Task 2,3（脚本就绪后才能对齐变量）
- Task 6 依赖 Task 5（环境变量就绪后配置 CI）
- Task 1,4,7 无前置依赖

## Verification
- [x] `bash -n scripts/_notify_lib.sh` 语法无误
- [x] `bash -n scripts/notify-h5-api-version.sh` 语法无误
- [x] `bash -n scripts/notify-agrisynapse-api-version.sh` 语法无误
- [x] `bash scripts/notify-h5-api-version.sh HEAD~1 HEAD` 退出码 0
- [x] `bash scripts/notify-agrisynapse-api-version.sh HEAD~1 HEAD` 退出码 0
- [ ] CI 实际推送验证（需要部署后触发）
