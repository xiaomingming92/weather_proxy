# Checklist: Agrisynapse API 文档通知体系

## [T] 编译期验证

- [x] T01: `bash -n scripts/_notify_lib.sh` 无语法错误
- [x] T02: `bash -n scripts/notify-h5-api-version.sh` 无语法错误
- [x] T03: `bash -n scripts/notify-agrisynapse-api-version.sh` 无语法错误
- [x] T04: 旧 `scripts/notify-doc-update.sh` 已删除
- [x] T05: `.env.example` 无 `NOTIFY_WEBHOOK_URLS` / `DINGTALK_SECRET` 通用通道
- [x] T06: `.env.production` 分通道块变量名正确（`DINGTALK_*_SECRET`，非 `WECOM_*_KEY`）
- [x] T07: `.gitlab-ci.yml` notify 阶段仅含 `notify-h5` + `notify-agrisynapse` 两个 job
- [x] T08: `notify-h5-api-version.sh` 不引用 `NOTIFY_WEBHOOK_URLS` fallback
- [x] T09: `_notify_lib.sh` 钉钉加签仅检查 `DINGTALK_SECRET_VAR`

## [R] 运行时验证

- [ ] R01: `scripts/notify-h5-api-version.sh HEAD~1 HEAD`（H5 主文档变更后）
- [ ] R02: `scripts/notify-agrisynapse-api-version.sh HEAD~1 HEAD`（Agrisynapse 主文档变更后）
- [ ] R03: `curl http://localhost:3000/api/agent/docs/agrisynapse` 返回 200
- [ ] R04: SSE 子文档变更但主文档未升版 → 输出黄色警告
- [ ] R05: CI deploy 后 git push 触发 notify jobs
