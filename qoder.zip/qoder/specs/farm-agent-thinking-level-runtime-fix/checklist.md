# Checklist: farm-agent-thinking-level-runtime-fix

> **证据规范**：每项 `[x]` 必须附带可验证证据。未执行项诚实保留 `[ ]`。

---

## 第 1 轮：SubIntent 双字段 + C 增强

### 类型与 Prompt
- [x] SubIntent 双字段（expertId+domain:ExpertDomain） — `sub-intent.ts` L15-17
- [x] LLM JSON 输出 `"expertId"` + `"thinkingLevel"` — `schemas/intention.ts` L22
- [x] parse 从 ANALYSIS_EXPERTS 推导 domain — `intention.ts` L132
- [x] parse 提取 thinkingLevel — `intention.ts` L139
- [x] buildSubIntentsFromRouter 适配 — `intention_async.ts` L124-129
- [x] schemas/intention.ts 集中管理 + validateIntentionFields — 新建 124 行

### rename + retry
- [x] 全部 si.domain→si.expertId rename — tsc=0 确认
- [x] intention.ts retry 回路 — L16 import + L194-238
- [x] intention-async.ts retry 回路 — L25 import + L119-158

### SkillCard
- [x] SkillCard 扩展 4 字段 — `dashboard-contract.ts` L21-27
- [x] 8 张旧卡适配 + crop_decision — L38-L126

---

## 第 2 轮：thinking-level.ts

- [x] getDomains 纯函数 — `thinking-level.ts` L24-29
- [x] resolveThinkingLevel A+C — L39-53
- [x] THINKING_LEVEL_RESOLVED 字面量 — `phase.ts` L198
- [x] INTENTION_RETRY 字面量 — `phase.ts` L199

---

## 第 3 轮：intention.ts 调用方结构性修复

### State + API 契约
- [x] explicitExpertIds: string[] — `state.ts` L119
- [x] prebuiltThinkingLevel + prebuiltSubIntents + prebuiltExpertPlan — L123-127
- [x] StreamAgentInput 接口 — `agent-runner.ts` L38-44
- [x] route.ts API 契约 expertIds[] — L119
- [x] Zod schema 新增 3 字段 — `schemas.ts` L21-27

### intention.ts scope fix
- [x] explicitExpertIds 解构 — L41
- [x] prebuilt 优先 — L153-155
- [x] thinkingLevel 外部 let — L261
- [x] try 块传 subIntents+llmSuggestedLevel — L272
- [x] 删除 L301 覆写行 ✅

---

## 第 4 轮：intention-async.ts 调用方结构性修复

- [x] explicitExpertIds 解构 — L36
- [x] Embedding 命中传 subIntents — L83
- [x] thinkingLevel 外部 let — L161
- [x] try 块传 subIntents+llmSuggestedLevel — L170
- [x] 删除 L191 覆写行 ✅
- [x] reasoning.ts explicitExpertIds?.[0] ×3 — L78/131/500
- [x] conditional.ts explicitExpertIds?.[0] ×2 — L75/79

---

## 第 5 轮：全量验证

### 编译 + Lint
- [x] `npx tsc --noEmit` 零错误
- [x] `npx eslint src/` 零 error（9 warnings 预存量）

### 单测
- [x] getDomains 同域去重 — vitest ✅
- [x] getDomains 跨域 — vitest ✅
- [x] getDomains 排除 isSummary — vitest ✅
- [x] getDomains 无效 expertId 防御 — vitest ✅
- [x] resolveThinkingLevel chat→fast — vitest ✅
- [x] resolveThinkingLevel 单 expert→deep — vitest ✅
- [x] resolveThinkingLevel 同域→deep — vitest ✅
- [x] resolveThinkingLevel 跨域→professional — vitest ✅
- [x] resolveThinkingLevel 含汇总→deep — vitest ✅
- [x] resolveThinkingLevel 不传 subIntents→deep — vitest ✅
- [x] resolveThinkingLevel C 升权 — vitest ✅

### API 文档
- [x] SSE 协议文档：expertId→expertIds
- [x] GUI API 对接文档：expertId→expertIds

### 未执行
- [ ] 端到端运行时验证（需启动服务 + GUI 点击技能卡片）
