# farm-agent-thinking-level-runtime-fix Spec

## Why

`resolveThinkingLevel` 当前仅返回 `"fast"` | `"deep"`，从未返回 `"professional"`。跨域多专家场景全部走 deep 图，professional 图（intentionAsyncNode / Router）全线未触发。

## What Changes

- `SubIntent` 类型：双字段（`expertId` + `domain: ExpertDomain`），消除语义歧义
- LLM JSON 输出契约：`"domain"` → `"expertId"`，新增 `"thinkingLevel"` 字段
- `resolveThinkingLevel`：新增 A 规则（跨域 ≥2 → professional）+ C 升权（LLM 语义裁决）
- `intention.ts` / `intention-async.ts`：thinkingLevel 外部作用域 + 传 subIntents + 删除覆写行
- State：`explicitExpertId: string|null` → `explicitExpertIds: string[]` + 3 个 prebuilt 字段
- Route API 契约：`expertId` → `expertIds: string[]` + 收 `subIntents` + `thinkingLevel`
- SkillCard 预计算决策表：`dashboard-contract.ts` 扩展 `thinkingLevel` + `subIntents` + `expertPlan`
- API 文档：SSE 协议 + API 对接文档同步更新
- 10 个文件，28 处改动

## Impact

- Affected specs: `farm-agent-three-tier-reasoning-graph`（professional 图路由入口）
- Affected code: `src/agents/types/`, `src/agents/prompts/`, `src/agents/nodes/`, `src/caijuehub/strategies/`, `src/app/api/agent/chat/stream/route.ts`, `src/api/agent/contracts/dashboard-contract.ts`, `src/agents/state.ts`
- Affected docs: `神经元GUI-SSE流式聊天协议文档.md`, `神经元GUI-API对接文档.md`
- 父 Plan: `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md`
- 依赖: 无（入口修复）
- 后续依赖: ACA v3 Plan 轮次 4（Send API fan-out 图重建）

## Boundaries

本次只允许：
- 修改 `resolveThinkingLevel` 签名 + 调用方传递 subIntents + SubIntent 类型修正 + C 增强 LLM prompt
- State 扩展 explicitExpertIds + prebuilt 字段
- Route API 契约适配
- SkillCard 预计算决策表扩展
- API 文档更新

本次禁止：
- 重构 professionalWorkflow 图拓扑（ACA v3 Plan 职责）
- 修改 `routeByIntent` 以外的路由逻辑
- 新增外部依赖

## Requirements

### Requirement: A 规则跨域裁决

系统 SHALL 在 `subIntents` 跨 ExpertDomain ≥2 时返回 `"professional"`，排除 `isSummary` 汇总专家。

#### Scenario: 跨域 2 专家触发 professional

- **WHEN** subIntents 含 pest_risk（管域）+ variety_recommend（种域）
- **THEN** `resolveThinkingLevel` 返回 `"professional"`

#### Scenario: 同域 2 专家保持 deep

- **WHEN** subIntents 含 crop_compare（种域）+ variety_recommend（种域）
- **THEN** `resolveThinkingLevel` 返回 `"deep"`

### Requirement: C 升权 LLM 语义裁决（仅自由对话路径）

系统 SHALL 在 A 规则未触发 `"professional"` 时，采纳 LLM 产出的 `thinkingLevel` 字段。

#### Scenario: LLM 升权覆盖 A 的 deep

- **WHEN** subIntents 含两个同"种"域 expert，但 LLM 判断语义冲突
- **THEN** `resolveThinkingLevel` 返回 `"professional"`（C 升权）

### Requirement: SkillCard 预计算决策表

系统 SHALL 在 GUI 点击技能卡片时，直接使用 `SkillCard` 预计算的 `thinkingLevel` + `subIntents` + `expertPlan`，跳过 `resolveThinkingLevel` 和所有运行时组装。

#### Scenario: 单专家卡片走 deep

- **WHEN** GUI 点击单专家卡片（如 `weekly_report`），API 收到 `{ expertIds: ["weekly_report"], thinkingLevel: "deep", subIntents: [...] }`
- **THEN** state 直接设 `thinkingLevel = "deep"`，路由到 deep 图

#### Scenario: 多专家卡片走 professional

- **WHEN** GUI 点击多专家卡片（如 `crop_decision`），API 收到 `{ expertIds: ["variety_recommend", "pest_risk", "roi_analysis"], thinkingLevel: "professional", subIntents: [...], expertPlan: [...] }`
- **THEN** state 直接设 `thinkingLevel = "professional"`，路由到 professional 图
