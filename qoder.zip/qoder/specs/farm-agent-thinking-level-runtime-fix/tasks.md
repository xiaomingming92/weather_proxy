# Tasks: farm-agent-thinking-level-runtime-fix

> **验证规范**：每个 Task 完成时必须附带验证证据（如 `tsc=0` / `vitest` / `grep确认`）。

## Preconditions

- [ ] Plan 已生成: `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md`
- [ ] Review 已回流: `.qoder/reviews/farm-agent-thinking-level-runtime-fix-review-v1.md`
- [ ] Spec 已就绪: `.qoder/specs/farm-agent-thinking-level-runtime-fix/spec.md`

## Forbidden

- 禁止修改 professionalWorkflow 图拓扑（ACA v3 Plan 职责）
- 禁止修改 `routeByIntent` 以外的路由逻辑
- 禁止新增外部依赖

## Tasks

### 第1轮：SubIntent 双字段 + C 增强 + thinking-level.ts

- [x] Task 1.1: SubIntent 类型双字段 + LLM 模板 + dashboard-contract 预计算决策表 — 验证: 代码 grep 确认
  - [x] 修改 `src/agents/types/sub-intent.ts`
  - [x] 修改 `src/agents/prompts/intent-constants.ts`
  - [x] 修改 `src/agents/prompts/intention.ts`（模板 + parse）
  - [x] 修改 `src/agents/prompts/intention_async.ts`（模板 + parse + buildSubIntentsFromRouter）
  - [x] 修改 `src/agents/nodes/intention.ts`（si.domain → si.expertId + retry回路）
  - [x] 修改 `src/agents/nodes/intention-async.ts`（si.domain → si.expertId + retry回路）
  - [x] 修改 `src/caijuehub/strategies/sub-intent.ts`（si.domain → si.expertId）
  - [x] 修改 `src/app/api/agent/chat/stream/route.ts`（si.domain → si.expertId）
  - [x] 修改 `src/api/agent/contracts/dashboard-contract.ts`（预计算决策表：expertIds + thinkingLevel + subIntents + expertPlan，8 张旧卡适配，新增多专家卡片）
  - [x] 新建 `src/agents/prompts/schemas/intention.ts`（JSON schema 集中管理 + validateIntentionFields + buildRetryHint）
- [x] Task 1.2: thinking-level.ts 新逻辑 — 验证: grep 确认
  - [x] 新增 `getDomains` 纯函数
  - [x] 扩展 `resolveThinkingLevel` 签名（subIntents + llmSuggestedLevel）
  - [x] 实现 A 规则 + C 升权

### 第2轮：State + API 契约变更 + intention.ts 消费者适配

- [x] Task 2.1: state.ts + route.ts API 契约 — 验证: `tsc=0`
  - [x] `src/agents/state.ts`: explicitExpertId → explicitExpertIds + prebuiltThinkingLevel + prebuiltSubIntents + prebuiltExpertPlan
  - [x] `src/app/api/agent/chat/stream/route.ts` L119: expertId → expertIds: string[] + subIntents + thinkingLevel
  - [x] route.ts L270: 设 state prebuilt 字段
  - [x] `src/app/api/types/farm-agent/schemas.ts`: BaseChatSchema 新增 expertIds + subIntents + thinkingLevel
  - [x] `src/agents/agent-runner.ts`: StreamAgentInput 接口适配
- [x] Task 2.2: intention.ts 消费者适配 + 结构性修复 — 验证: `tsc=0`
  - [x] L40 解构改为 explicitExpertIds
  - [x] L82-93 工具注入：for of explicitExpertIds（预激活所有 expert）
  - [x] L97-143 tool_calls 注入：取 explicitExpertIds[0]
  - [x] L147 explicitIntent：优先 prebuiltThinkingLevel，跳过 resolveThinkingLevel；或从 explicitExpertIds 构建 subIntents
  - [x] L184 prompt input：explicitExpertIds?.[0]
  - [x] L213 新增外部声明 let thinkingLevel: ThinkingLevel = "deep"
  - [x] L223 try 块：赋值 thinkingLevel + 传 result.subIntents + result.thinkingLevel
  - [x] L267 catch 块：赋值 thinkingLevel = resolveThinkingLevel(parsed.intent)
  - [x] 删除 L301 覆写行
- [x] Task 2.3: intention-async.ts + reasoning.ts + conditional.ts 消费者适配 — 验证: `tsc=0`
  - [x] intention-async.ts L35 解构改为 explicitExpertIds
  - [x] L75-77 预激活：for of explicitExpertIds
  - [x] L82 传 subIntents → resolveThinkingLevel("analysis", subIntents)
  - [x] L111 prompt input：explicitExpertIds?.[0]
  - [x] L133 新增外部声明 let thinkingLevel: ThinkingLevel = "deep"
  - [x] L137 try 块：赋值 thinkingLevel + 传 result.subIntents + result.thinkingLevel
  - [x] 删除 L191 覆写行
  - [x] reasoning.ts L78/131/500：explicitExpertIds?.[0]（含 isSummary 防御 guard）
  - [x] conditional.ts L75/79：explicitExpertIds?.[0]
- [x] Task 2.4: API 文档更新 — 验证: grep 确认
  - [x] `神经元GUI-SSE流式聊天协议文档.md`：expertId → expertIds + 表格新增 subIntents/thinkingLevel
  - [x] `神经元GUI-API对接文档.md`：expertId → expertIds（含 SkillCard 预计算说明）

### 第3轮：全量验证

- [x] Task 3.1: tsc + eslint — 验证: `tsc=0` + eslint 零 error
- [x] Task 3.2: getDomains 单测 — 验证: `vitest` 12/12

## Task Dependencies

- Task 1.2 依赖 Task 1.1（类型定义 + LLM 模板）
- Task 2.1 依赖 Task 1.2（resolveThinkingLevel 新签名）
- Task 2.2/2.3 依赖 Task 2.1（state + route 契约）
- Task 2.4 依赖 Task 2.1（API 契约已确定）
- Task 3.1/3.2 依赖全部前置 Task

## Verification

- [ ] `npx tsc --noEmit` 通过
- [ ] `npx eslint src/` 零 error
- [ ] `vitest` getDomains 单测 4/4
- [ ] API 文档已更新（grep 确认 expertIds）
- [ ] `resolveKeywordExperts()` 不受影响（grep 确认）
