# agrisynapse ↔ farm-agent 前端对接 Spec

## Why
farm-agent 后端管线（单端点路由、23工具、toolNode 回环）已全部就绪并通过编译验证，但 agrisynapse 前端的 LLM 模块（聊天界面、技能中心、农场信息）目前是纯静态 UI 壳，没有任何一行代码调用 farm-agent。需要建立 agrisynapse 到 farm-agent 的完整对接层，使前端 AI 助手真正可用。

## What Changes
- **agrisynapse 侧**：
  - 新建 API 客户端层 `src/api/agent/`：封装 farm-agent 哈希路径握手 + 聊天 + 仪表盘 + 报告 API
  - 改造聊天界面 `LlmChatView/LlmChatWelcome/LlmChatInput`：从静态占位变为真实流式对话
  - 对接技能中心 `skill-center`：从 farm-agent 获取 9 个技能卡片和推荐话题
  - 农场信息页对接真实数据
  - 聊天状态管理：消息列表、流式响应、工具调用展示、裁决结果展示
  - 握手机制改为惰性触发（首次 sendMessage 时），而非仪表盘 onMounted 时 → 修订 [2026-06-08: review2 发现 eager handshake 在仪表盘加载时产生孤儿线程，改为惰性]
  - handshake 请求新增 `action` 字段（`new` / `resume`）区分新建 vs 恢复会话 → 修订 [2026-06-08: review2 发现 handshake 始终新建 thread 无法恢复历史会话]
  - 移除 Authorization header 注入和 Farm-Server token 透传 → 修订 [2026-06-08: review2 简化为 hash-only 认证 + farm-agent 自主登录 Farm-Server]
- **farm-agent 侧**：
  - 新建 `caijuehub/strategies/agrisynapse-handshake.ts`：握手 thread 路由裁决层 → 修订 [2026-06-08: review2 决策裁决层独立，参照 thinking-level.ts/sub-intent.ts/response.ts]
  - 新建 `caijuehub/strategies/auth-gateway.ts`：多身份源认证网关裁决层 → 修订 [2026-06-08: review2 发现 proxy.ts 硬编码 requireRole 不支持外部 GUI]
  - 新建 `lib/credential/`：farm-agent 自有 service 账户登录 Farm-Server 的 token 管理（LLM 不可达） → 修订 [2026-06-08: review2 决策 Farm-Server token 不出 farm-agent，一个 service 账户服务所有用户]
  - 修改 `proxy.ts`：移除 JWT requireRole 校验，改为调 auth-gateway 裁决层 → 修订 [2026-06-08: review2 发现 agrisynapse JWT 与 farm-agent JWT_SECRET 不通，hash-path 已证明调用方身份]
  - 修改 `route.ts`：handshake 调裁决层替代硬编码 createThread；userId 来源改为根据 auth mode 判定 → 修订 [2026-06-08: review2 决策裁决与执行分离]
  - 跨域 CORS 配置验证

## Impact
- Affected specs: 无（全新对接）
- Affected code (agrisynapse):
  - 新建: `src/api/agent/index.ts` — farm-agent API 客户端
  - 新建: `src/api/agent/types.ts` — 对接类型定义
  - 新建: `src/store/modules/agentChat.ts` — 聊天状态管理
  - 修改: `src/views/llm/dashboard/index.vue` — 移除硬编码，从 API 获取
  - 修改: `src/views/llm/components/LlmChatView.vue` — 接入真实聊天
  - 修改: `src/views/llm/components/LlmChatWelcome.vue` — 动态技能卡片
  - 修改: `src/views/llm/components/LlmChatInput.vue` — 接入发送逻辑
  - 新建: `src/views/llm/components/StreamingEvidenceBar.vue` — 检索证据流式展示
  - 新建: `src/views/llm/components/LlmToolCallDisplay.vue` — 工具调用展示
  - 新建: `src/views/llm/components/LlmVerdictDisplay.vue` — 裁决结果展示
  - handshake 签名加 `action` 参数，移除 Authorization header 注入 → 修订 [2026-06-08: review2 决策 hash-only 认证 + 惰性握手]
  - Store 去掉 `initialized` 锁，handshake 改为惰性触发于 sendMessage → 修订 [2026-06-08: review2 发现 initialized 锁阻止 farm-agent 重启后重连]
  - dashboard 移除 eager handshake，仅 GET dashboard 获取技能卡片 → 修订 [2026-06-08: review2 发现仪表盘加载时不该建 thread]
- Affected code (farm-agent):
  - 可能: `src/app/api/agent/[hash]/route.ts` — CORS 头确认
  - 可能: `src/proxy.ts` — 跨域 OPTIONS 处理
  - 新建: `src/caijuehub/strategies/agrisynapse-handshake.ts` — 握手 thread 路由裁决层 → 修订 [2026-06-08: review2 决策裁决层独立]
  - 新建: `src/caijuehub/strategies/auth-gateway.ts` — 多身份源认证网关裁决层 → 修订 [2026-06-08: review2 决策 proxy.ts 不再内含认证判断]
  - 修改: `src/app/api/agent/[hash]/route.ts` — handshake 加 action + 调裁决层替代硬编码 createThread → 修订 [2026-06-08: review2 发现 L354 对所有场景一律新建线程]
  - 修改: `src/proxy.ts` — 移除 requireRole，改为调 auth-gateway 裁决层 → 修订 [2026-06-08: review2 发现 agrisynapse JWT 与 farm-agent JWT_SECRET 不互通]
  - 新建: `src/lib/credential/` — farm-agent 自有 service 账户 Farm-Server token 管理 → 修订 [2026-06-08: review2 决策 Farm-Server token 不出 farm-agent，agents/tools 禁止 import]
- 父 Plan: agrisynapse-farm-agent-integration-plan-v1
- 依赖: farm-agent tools-calling-pipeline 已收敛
- 后续依赖: 端到端联调测试

## Boundaries
- 本次只实现 agrisynapse → farm-agent 的前端对接层
- 本次只对接 farm-agent 单端点 `/api/agent/{hash}`
- 本次禁止修改 agrisynapse 的 Axios 拦截器核心逻辑（不破坏现有 Java 后端对接）
- 本次禁止修改 farm-agent 的单端点路由签名
- 本次不实现语音/图片多模态输入（后续轮次）

## Requirements

### Requirement: 惰性握手 + action 区分意图
系统 SHALL 在用户首次发送消息时惰性触发握手（而非仪表盘 onMounted 时）。handshake 请求 SHALL 携带 `action` 字段：`"new"`（仪表盘输入框首发消息、点击新建对话）→ 无条件建线程；`"resume"`（页面刷新后恢复、farm-agent 重启后重连）→ 查找最近活跃线程，有则复用，无则返回 null → GUI 回仪表盘。resume 永远不建线程。 → 修订 [2026-06-08: review2 发现 eager handshake 在仪表盘加载时产生孤儿线程，且 handshake 始终 createThread 无法恢复历史会话；改为惰性 + action 区分意图]

Scenario: 用户从仪表盘输入框发送第一条消息 → sendMessage 发现 !threadId → 触发 handshake({ action: "new" }) → farm-agent 创建新线程 → 返回 threadId。 → 修订 [2026-06-08: 原 scenario 为 onMounted 时 eager handshake]
Scenario: 用户刷新页面后继续对话 → sendMessage 发现 !threadId → 触发 handshake({ action: "resume" }) → farm-agent 查到最近线程 → 复用返回。 → 新增 [2026-06-08]
Scenario: resume 查无历史线程 → farm-agent 返回 { threadId: null } → agrisynapse 路由到仪表盘页面。 → 新增 [2026-06-08]

### Requirement: 握手裁决层
系统 SHALL 将 thread 路由决策（新建/复用）从 route.ts 中抽离为独立的裁决策略文件 `caijuehub/strategies/agrisynapse-handshake.ts`，遵循项目「裁决与执行分离」原则。裁决层输出 `{ thread, isNew, auditAction }`，执行层只负责调裁决层 + 组装 HTTP 响应。

### Requirement: 多身份源认证网关
系统 SHALL 支持两种认证模式：`jwt` 模式（farm-agent 自有 GUI，Authorization Bearer token）和 `hash-only` 模式（agrisynapse 等外部 GUI，hash-path 证明调用方身份，用户身份从 body userVO 取）。认证模式裁决集中在 `caijuehub/strategies/auth-gateway.ts`，proxy.ts 不再内含认证判断。agrisynapse 不传 JWT，走 hash-only 模式。

### Requirement: Farm-Server 自主登录
系统 SHALL 由 farm-agent 使用自有 service 账户登录 Farm-Server（部署时预配），一个 service token 服务所有用户，按 massifId 过滤数据。agrisynapse 不持有、不传递 Farm-Server token。凭证管理代码位于 `lib/credential/` 独立目录，`agents/tools/` 禁止 import，LLM 不可达。

### Requirement: 技能卡片动态加载
系统 SHALL 从 farm-agent GET dashboard 接口获取技能卡片列表和推荐话题，替代当前的硬编码数据。

### Requirement: 流式聊天对话
系统 SHALL 支持 SSE/stream 方式的实时聊天，在 LlmChatView 中展示 AI 的流式回复（逐字输出），并支持展示工具调用过程（toolNode 执行进度）和裁决结果。

### Requirement: 历史对话管理
系统 SHALL 支持查看历史对话线程列表和加载特定线程的消息记录。

### Requirement: 聊天状态管理
系统 SHALL 使用 Pinia store 管理聊天状态，包括：当前 threadId、消息列表、流式状态、nextHash（用于后续请求）、连接状态。
