# Checklist: agrisynapse ↔ farm-agent 前端对接

> 每条验证项均可追溯到 tasks.md 的具体 Task。未执行的勾选框保持 `[ ]` 状态。

## Task 1: API 客户端层
- [x] `src/api/agent/types.ts` 类型定义涵盖 ChatRequest/ChatResponse/DashboardData/HandshakeRequest/HandshakeResponse
- [x] `src/api/agent/index.ts` 实现 5 个 API 函数，每个函数正确处理 hash path 拼接
- [x] handshake 请求传递 userVO + action（new/resume），不传 Farm-Server 凭据 → 修订 [2026-06-08: 原为"传递 userVO"，加 action 字段]
- [x] chat 请求传递 userId 字段（替代原 Authorization header 身份提取） → 新增 [2026-06-08]
- [x] dashboard 请求正确解析 skillCards + recommendedTopics + nextHash
- [x] chat 请求正确传递 messages + threadId + modelConfig + intent + userId
- [x] agrisynapse 所有请求不携带 Authorization header → 新增 [2026-06-08]

## Task 2: 聊天状态管理
- [x] `src/stores/agent-chat-store.ts` 使用 Pinia `defineStore`
- [x] threadId 在惰性 handshake 后写入 store，后续请求复用 → 修订 [2026-06-08: 原为"handshake 后写入"，改为惰性]
- [x] nextHash 在每次 API 响应后更新
- [x] messages 支持追加（用户消息 + AI 流式消息）
- [x] sendMessage 惰性触发 handshake：!threadId → initSession("resume") → 失败 → 回仪表盘 → 新增 [2026-06-08]
- [x] startNewChat() 触发 handshake({ action: "new" }) → 新增 [2026-06-08]
- [x] 去掉 initialized 锁，initSession 可重复调用 → 新增 [2026-06-08]

## Task 3: 仪表盘对接
- [x] LlmDashboard 移除硬编码的 quickQuestionCards/quickQuestionChips
- [x] LlmChatWelcome 通过 props 或 store 接收动态 skillCards
- [x] 点击技能卡片触发 sendMessage({ message, intent: card.id })

## Task 4: 聊天消息组件 → 修订 [2026-06-08: 功能 inline 于 LlmChatView.vue，未创建独立组件文件]
- [x] LlmChatMessage 区分 user/assistant 气泡样式 → 修订 [2026-06-08: inline 于 LlmChatView.vue 第 16-21 行]
- [x] StreamingEvidenceBar 支持检索证据逐条出现动画 → 修订 [2026-06-08: inline 于 LlmChatView.vue 第 27-36 行]
- [x] LlmToolCallDisplay 展示 tool name + args + result（折叠/展开） → 修订 [2026-06-08: inline 于 LlmChatView.vue 第 38-49 行，展示 name + status]
- [x] LlmVerdictDisplay 展示 conclusion + confidence + reasoning_path → 修订 [2026-06-08: inline 于 LlmChatView.vue 第 56-65 行]

## Task 5: 流式聊天
- [x] 发送消息后 LlmChatView 进入流式渲染模式
- [x] AI 回复逐 token/tag 追加显示
- [x] 流式完成后触发 structuredResponse/verdict 解析
- [x] 网络错误时显示错误提示 + 重试按钮

## Task 6: 跨域与认证
- [x] farm-agent CORS 头配置允许 agrisynapse 源
- [x] farm-agent proxy：OPTIONS 预检放行 → 修订 [2026-06-08: Next.js 16 middleware→proxy]
- [x] agrisynapse 请求不携带 `Authorization` 头 → 修订 [2026-06-08: review2 决策 hash-only 认证，移除 JWT]
- [x] handshake 传递 userVO + action 建立会话（Farm-Server 凭据由 farm-agent 自主管理） → 修订 [2026-06-08: review2 决策 Farm-Server token 不出 farm-agent]
- [x] agrisynapse 无 JWT 请求 farm-agent 不返回 401 → 新增 [2026-06-08]

## Task 7: 编译验证
- [x] `cd /home/xmm/ai/agrisynapse && pnpm build` 通过
- [x] `cd /home/xmm/ai/farm-agent && npm run build` 通过
- [x] LSP 无新增报错

## Task 8: farm-agent 裁决层实现 → 新增 [2026-06-08]
- [x] `agrisynapse-handshake.ts` 实现 `resolveHandshakeThread({ action, userId })`
- [x] `action: "new"` → 无条件 `createThread(userId)`，返回 `{ thread, isNew: true }`
- [x] `action: "resume"` → `findRecentActiveThread(userId)`，有则复用，无则返回 `null`
- [x] `auth-gateway.ts` 实现 `resolveAuthGateway(request)` → `{ mode: "jwt"|"hash-only", user: JWTPayload|null }`
- [x] 有 Authorization header → 验证 JWT → mode: "jwt"
- [x] 无 Authorization header → mode: "hash-only" → user: null
- [x] proxy.ts 调用 resolveAuthGateway 替代 requireRole
- [x] route.ts handleHandshakePOST 调用 resolveHandshakeThread 替代硬编码 createThread
- [x] route.ts handleChatPOST userId = auth mode === "jwt" ? authUser.userId : body.userId

## Task 9: farm-agent lib/credential/ 凭证隔离 → 新增 [2026-06-08]
- [x] `src/lib/credential/` 独立目录存在，不与其他模块耦合
- [x] farm-agent 部署时预配的 service 账户（环境变量）可成功登录 Farm-Server
- [x] service token 缓存/刷新逻辑不涉及用户 ID
- [x] Farm-Server 数据按 massifId（来自 userVO）过滤，一个 token 多用户复用
- [x] `grep -r "lib/credential" src/agents/` 无匹配 → agents/tools 不 import
- [x] LLM prompt、chat message、日志中不含 Farm-Server token 原文
