# Tasks: agrisynapse ↔ farm-agent 前端对接

## Preconditions
- [x] farm-agent tools-calling-pipeline 已收敛（tsc + build pass）
- [x] farm-agent 单端点 `/api/agent/[hash]` 已注册为动态路由
- [ ] farm-agent 开发服务器可被 agrisynapse 访问（CORS / 同域 / 代理）

## Forbidden
- 禁止修改 agrisynapse 现有 Axios 拦截器 `service.ts` 的核心逻辑
- 禁止修改 farm-agent 单端点路由的请求/响应签名
- 禁止删除 agrisynapse 现有 Java 后端 API 调用
- 禁止引入新的第三方聊天 UI 库（使用 Element Plus + 自定义组件）

## Tasks

- [x] Task 0: 文档先行（ADD 0.1）
  - [x] 更新 `docs/大田精准耕播智能决策系统/.../技术架构说明书.md`
  - [x] 新增 7.7.8 节：agrisynapse 前端对接
  - [x] 子章节：对接拓扑、API 端点、双层认证、SSE 事件→组件映射、Token 生命周期、跨域策略
  - [x] 验证标准: 新增章节与 plan 2.3-2.7 设计一致

- [x] Task 1: farm-agent API 客户端层
  - [x] 新建 `src/api/agent/types.ts`：farm-agent 请求/响应类型定义
  - [x] 新建 `src/api/agent/index.ts`：封装 hash-path 握手 + chat/dashboard/thread/report API
  - [x] 实现 `getDashboard()` → GET `/api/agent/{hash}?action=dashboard`
  - [x] 实现 `handshake(userVO, action?)` → POST `/api/agent/{hash}` type=handshake（仅传用户基本信息，不传 Farm-Server 凭据；加 `action` 字段区分 new/resume） → 修订 [2026-06-08: 原为 handshake(accessToken, refreshToken)，改为 handshake(userVO, action)]
  - [x] 实现 `sendChat(messages, threadId, modelConfig, userId)` → POST `/api/agent/{hash}` type=chat（加 userId 字段，替代原 Authorization header） → 修订 [2026-06-08: review2 决策 hash-only 认证，userId 从 body 传]
  - [x] 实现 `getThread(threadId)` → GET `/api/agent/{hash}?action=thread&id=xxx`
  - [x] 实现 `getReport(reportId)` → GET `/api/agent/{hash}?action=report&id=xxx`
  - [ ] 验证标准: 在浏览器 console 中手动调用 API 函数，确认能拿到响应

- [x] Task 2: 聊天状态管理 Pinia Store
  - [x] 新建 `src/store/modules/agentChat.ts`
  - [x] 状态字段: threadId, messages[], nextHash, isStreaming, error
  - [x] Actions: initSession(action?), sendMessage, loadThread, clearChat, startNewChat → 修订 [2026-06-08: initSession 加 action 参数；新增 startNewChat；去掉 initialized 锁]
  - [x] sendMessage 惰性触发 handshake：发现 !threadId → initSession("resume") → 失败 → initSession("new") → 修订 [2026-06-08: review2 决策惰性握手]
  - [x] 流式消息追加逻辑
  - [ ] 验证标准: Vue DevTools 中可查看 store 状态变化

- [x] Task 3: 仪表盘页面对接
  - [x] 修改 `src/views/llm/dashboard/index.vue`：从 agentChatStore 获取技能卡片
  - [x] 修改 `LlmChatWelcome.vue`：动态渲染 skillCards + recommendedTopics
  - [x] 点击技能卡片 → 触发 sendMessage(对应 intent)
  - [x] 点击推荐话题 → 触发 sendMessage(话题文本)
  - [ ] 验证标准: 页面加载后显示从 farm-agent 返回的真实技能卡片

- [x] Task 4: 聊天消息组件 → 修订 [2026-06-08: 功能 inline 于 LlmChatView.vue，未创建独立组件文件]
  - [x] 新建 `LlmChatMessage.vue`：用户消息气泡 + AI 消息气泡 → 修订 [2026-06-08: inline 于 LlmChatView.vue 第 16-21 行]
  - [x] 新建 `StreamingEvidenceBar.vue`：检索证据流式展示（逐条出现动画） → 修订 [2026-06-08: inline 于 LlmChatView.vue 第 27-36 行]
  - [x] 新建 `LlmToolCallDisplay.vue`：工具调用过程展示（tool name + args + result） → 修订 [2026-06-08: inline 于 LlmChatView.vue 第 38-49 行]
  - [x] 新建 `LlmVerdictDisplay.vue`：裁决结论 + 置信度 + 推理路径 → 修订 [2026-06-08: inline 于 LlmChatView.vue 第 56-65 行]
  - [x] 修改 `LlmChatView.vue`：从 store 渲染消息列表 + 输入框发送
  - [x] 修改 `LlmChatInput.vue`：发送按钮绑定 sendMessage action → 修订 [2026-06-08: 输入框 inline 于 LlmChatView.vue，原 LlmChatInput.vue 不再使用]
  - [ ] 验证标准: 发送消息后能看到用户消息气泡 + AI 流式回复

- [x] Task 5: 流式聊天对接
  - [x] 实现 SSE 流式解析（或使用 farm-agent 的 stream 端点）
  - [x] 流式过程中更新消息内容（逐 token 追加）
  - [x] 流式完成后解析 structuredResponse/verdict/toolCalls
  - [x] 错误处理和断线重连
  - [ ] 验证标准: 发送"今天天气怎么样"后能看到 AI 逐字输出 + 可能的工具调用展示

- [x] Task 6: 跨域与认证桥接
  - [x] farm-agent `next.config.ts` `headers()`：`/api/agent/:hash` 路由添加 CORS 响应头
  - [x] farm-agent proxy：OPTIONS 请求跳过 hash 校验直接放行 → 修订 [2026-06-08: Next.js 16 middleware→proxy 迁移]
  - [x] agrisynapse 不再注入 Authorization header → 修订 [2026-06-08: review2 决策 hash-only 认证，移除 JWT]
  - [x] handshake 仅传递 `userVO` + `action`；不传 Farm-Server 凭据 → 修订 [2026-06-08: review2 决策 Farm-Server token 不出 farm-agent]
  - [x] chat 请求加 `userId` 字段（替代原 Authorization header 的身份提取） → 新增 [2026-06-08]
  - [ ] 验证标准: agrisynapse 开发环境跨域请求 farm-agent 成功，无 401

- [x] Task 7: 编译验证
  - [x] agrisynapse `npm run build` 或 `pnpm build` 通过
  - [x] farm-agent 侧无回归（现有 build 保持通过）
  - [x] LSP 无报错

- [x] Task 8: farm-agent 裁决层实现 → 新增 [2026-06-08: review2 决策]
  - [x] 新建 `src/caijuehub/strategies/agrisynapse-handshake.ts`：`resolveHandshakeThread({ action, userId }) → { thread, isNew, auditAction }`
  - [x] 新建 `src/caijuehub/strategies/auth-gateway.ts`：`resolveAuthGateway(request) → { mode, user }`
  - [x] 修改 `src/proxy.ts`：移除 `requireRole` 调用，改为调 `resolveAuthGateway()`
  - [x] 修改 `src/app/api/agent/[hash]/route.ts`：`handleHandshakePOST` 调 `resolveHandshakeThread` 替代硬编码 `createThread`
  - [x] 修改 `src/app/api/agent/[hash]/route.ts`：`handleChatPOST` userId 来源改为根据 auth mode 判定（jwt → authUser.userId；hash-only → body.userId）
  - [x] 验证标准: farm-agent `npx tsc --noEmit` 通过；agrisynapse 无 JWT 请求 farm-agent 不返回 401

- [x] Task 9: farm-agent lib/credential/ 凭证隔离 → 新增 [2026-06-08: review2 决策]
  - [x] 新建 `src/lib/credential/` 独立目录
  - [x] 实现 farm-agent 自有 service 账户登录 Farm-Server（部署时预配环境变量）
  - [x] 一个 service token 服务所有用户，按 massifId 过滤数据
  - [x] 确保 `src/agents/tools/` 不 import `lib/credential/`（LLM 不可达）
  - [x] 验证标准: LLM tool 调用 Farm-Server 数据正常返回；token 不出现在任何 LLM prompt 或日志中

## Task Dependencies
- Task 2 依赖 Task 1（store 调用 API 客户端）
- Task 3 依赖 Task 1, Task 2
- Task 4 依赖 Task 2
- Task 5 依赖 Task 2, Task 4
- Task 6 可与 Task 1-5 并行
- Task 7 依赖 Task 1-6 全部完成
- Task 8 依赖 Task 6（认证方案确定后实施裁决层） → 新增 [2026-06-08]
- Task 9 可与 Task 8 并行 → 新增 [2026-06-08]

## Verification
- [x] `cd agrisynapse && pnpm build` 通过
- [x] `cd farm-agent && npx tsc --noEmit` 通过
- [ ] 浏览器中打开 agrisynapse → /llm/dashboard → 看到真实技能卡片（不触发 handshake，不创建 thread）
- [ ] 从仪表盘输入框发送第一条消息 → 惰性触发 handshake({ action: "new" }) → thread 创建成功
- [ ] 刷新页面后发送消息 → handshake({ action: "resume" }) → 复用最近 thread
- [ ] 发送消息 → 收到 AI 流式回复
- [ ] 发送"查一下地块A的土壤湿度" → 看到工具调用过程
- [x] agrisynapse 不传 JWT 请求 farm-agent → 不返回 401 → 新增 [2026-06-08]
- [x] farm-agent 自有 service 账户调 Farm-Server 成功，LLM 输出不含 token → 新增 [2026-06-08]
