# Tasks: farm-agent-unpdf-migration

## Phase 3: 解析与索引分离（本次待实施）

- [ ] Task 3.1: 抽出 `indexContent()` 纯索引函数
  - [ ] 从 `indexKnowledgeDocumentWithProgress` 中提取 L113-281 的索引逻辑
  - [ ] 函数签名: `indexContent(documentId, fileName, content, parsedType, onProgress, disciplineCodes?)`
  - [ ] 保留 projectId 查询、smartChunk、embed、ChromaDB 主写、Prisma update、双写、kbGeneration bump
  - [ ] 将 `parsed.metadata.type` 引用替换为参数 `parsedType`
  - [ ] 将 `parsed.content` 引用替换为参数 `content`
  - [ ] 从 "PARSING: 文档解析完成，正在分块..." 开始进度（跳过文件解析阶段）

- [ ] Task 3.2: 重构 `indexKnowledgeDocumentWithProgress` 为薄封装
  - [ ] 内部: `parseDocumentFromBuffer(buffer, fileName)` → `indexContent(documentId, fileName, content, metadata.type, onProgress)`
  - [ ] 签名不变，外部所有调用方零改动

- [ ] Task 3.3: 修改 OCR 完成回调调 `indexContent`
  - [ ] 文件: `src/app/api/knowledge/documents/[id]/progress/route.ts` L100-105
  - [ ] `onComplete` 中: `indexKnowledgeDocumentWithProgress(id, Buffer.from(ocrText), ...)` → `indexContent(id, doc.name, ocrText, "pdf", onProgress)`
  - [ ] 移除 `Buffer.from(ocrText)` 的无效包装

- [ ] Task 3.4: 同步调用方检查
  - [ ] `knowledge-sync.ts` 中所有 `indexKnowledgeDocumentWithProgress` 调用 — 不走 OCR 路径，签名不变，无需改动
  - [ ] 其他调用方 (tests/scripts) — 确认 `indexKnowledgeDocumentWithProgress` 行为不变

## Phase 1-2: PDF 引擎替换 + OCR 降级（✅ 已完成）

- [x] Task 1.1: 安装 unpdf，移除 pdfjs-dist/pdf-parse
- [x] Task 1.2: 重写 parsePdf 为 unpdf.extractText
- [x] Task 1.3: 清理 DOMMatrix polyfill + 构建验证
- [x] Task 2.1: 安装 @napi-rs/canvas
- [x] Task 2.2: 实现 OCR 降级逻辑（extractText → ocrDeferred）
- [x] Task 2.3: OCR 验证（扫描件实测）

## Phase 3a: OCR 子进程 + 索引管理器（✅ 已完成）

- [x] Task 3a.1: 创建 OCR 子进程 Worker（fork→spawn，临时文件传 PDF）
- [x] Task 3a.2: 创建 IndexJobManager（ChildProcess 生命周期 + 进度轮询）
- [x] Task 3a.3: 创建通用取消 API
- [x] Task 3a.4: SSE Progress 端点两阶段架构（Phase A 解析检测 + Phase B OCR）

## Phase 4-6: SSE 结构化 + 取消 + 单文档同步 + 删除（✅ 已完成）

- [x] Task 4.1: SyncProgressEvent 结构化接口
- [x] Task 4.2: agrisynapse 前端同步面板升级
- [x] Task 5.1: 同步批次取消（后端 + 前端）
- [x] Task 6.1: 单文档同步按钮（前端）
- [x] Task 6.2: 文档行级删除按钮（前端）

## Task Dependencies

- Task 3.1 → Task 3.2 → Task 3.3（严格串行）
- Task 3.4 在 Task 3.3 后执行

## Verification

- [ ] `npx tsc --noEmit` 零错误
- [ ] `indexKnowledgeDocumentWithProgress` 外部调用方零改动
- [ ] OCR 路径 SSL 流中不再出现 `Invalid PDF structure`
- [ ] 非扫描件 PDF 索引行为与重构前完全一致
