# farm-agent-unpdf-migration Spec

## Why

PDF 解析管线使用 `pdfjs-dist` 导致 VPS 运行时找不到 worker 静默失败，且对扫描型 PDF（无文本层）无法提取内容。需要用 `unpdf` 替换并扩展 OCR 降级管线，使扫描件也能被 RAG 系统索引。

## What Changes

### Phase 1-2: 替换 PDF 解析引擎（✅ 已完成）
- `package.json`: unpdf 替换 pdfjs-dist + pdf-parse
- `src/services/document-parser.ts`: parsePdf 改用 unpdf.extractText + OCR 降级
- `src/tests/setup.ts`: 移除 DOMMatrix polyfill

### Phase 3: OCR 异步化 + 取消 + 进度（部分完成）
- `src/workers/ocr-worker.ts`: **新建** — OCR 子进程入口（child_process.spawn，临时文件传 PDF）
- `src/services/index-job-manager.ts`: **新建** — 统一索引任务管理器（ChildProcess 生命周期 + 进度轮询）
- `src/app/api/knowledge/documents/[id]/index/cancel/route.ts`: **新建** — 通用取消接口
- `src/services/knowledge-indexer.ts`: **修改（待实施）** — 抽出 `indexContent()` 纯索引函数，解析与索引分离
- `src/app/api/knowledge/documents/[id]/progress/route.ts`: **修改（待实施）** — OCR 路径直接调 `indexContent(ocrText)` 替代 `parseDocumentFromBuffer`

### Phase 4-6: SSE 进度结构化 + 取消 + 单文档同步（✅ 已完成）
- `src/services/knowledge-sync.ts`: SyncProgressEvent 结构化接口
- `src/app/api/knowledge/sync/route.ts`: 透传结构化事件 + heartbeat
- `src/app/api/knowledge/sync/cancel/route.ts`: **新建** — 同步批次取消
- `src/api/llm/knowledge/grounding.ts` (agrisynapse): cancelSync + syncSingleDocument
- `src/views/llm/knowledgeBase/index.vue` + `customization/index.vue` (agrisynapse): 取消/单文档同步/删除按钮

## Impact

- Affected specs: 无（首个 spec）
- Affected code:
  - farm-agent: `knowledge-indexer.ts`, `progress/route.ts`（本次待实施）
  - farm-agent: `document-parser.ts`, `ocr-worker.ts`, `index-job-manager.ts`（✅ 已完成）
  - agrisynapse: `grounding.ts`, `index.vue` × 2（✅ 已完成）
- 父 Plan: `.qoder/plans/farm-agent-unpdf-migration-plan-v1.md`
- Runtime Review: `.qoder/reviews/farm-agent-unpdf-migration-runtime-review-v1.md`
- 依赖: 无上游
- 后续依赖: 无

## Boundaries

本次只允许实现：`knowledge-indexer.ts` 抽出 `indexContent()` + `progress/route.ts` OCR 路径调 `indexContent()`。

本次禁止实现：新增文件、修改已有调用的函数签名、引入新依赖。

## Requirements

### Requirement: 解析与索引分离 + OCR 文本索引（待实施）

`indexKnowledgeDocumentWithProgress` 中解析逻辑（`parseDocumentFromBuffer`）与索引逻辑（chunk→embed→ChromaDB→双写）必须解耦为独立函数。OCR 文本直接进入 `indexContent` 绕过文件解析。

#### Scenario: 非扫描件 PDF 进入索引

- **WHEN** 调用 `indexKnowledgeDocumentWithProgress(buffer, fileName, onProgress)`
- **THEN** 内部先 `parseDocumentFromBuffer(buffer, fileName)` 获取 content 和 parsedType
- **AND** 调 `indexContent(documentId, fileName, content, parsedType, onProgress, disciplineCodes)` 完成索引

#### Scenario: OCR 文本进入索引

- **WHEN** OCR 子进程返回纯文本 `ocrText` 且 `parsedType = "pdf"`
- **THEN** 直接调 `indexContent(documentId, fileName, ocrText, "pdf", onProgress)` 完成索引
- **AND** 不经过 `parseDocumentFromBuffer` 二次解析
- **AND** 不再抛出 `Invalid PDF structure` 错误

### Requirement: indexContent 纯索引函数签名

`indexContent` 必须接受 `content: string` + `parsedType: string`（非 `buffer: Buffer`），不调用 `parseDocumentFromBuffer`。

#### Scenario: OCR 路径调用

- **WHEN** OCR 子进程返回纯文本
- **THEN** 直接调用 `indexContent(id, name, text, "pdf", onProgress)`
- **AND** ChromaDB metadata 中 `parsedType` 字段使用参数值而非 `parsed.metadata.type`

### Requirement: SSE Progress 路由 OCR 回调修复

`progress/route.ts` 中 OCR `onComplete` 回调必须移除 `Buffer.from(ocrText)` 包装，改为直接调用 `indexContent`。

#### Scenario: 扫描件 PDF SSE 流

- **WHEN** OCR 子进程成功返回纯文本
- **THEN** SSE 流中 `Indexing` 阶段后接 `INDEXED` 状态
- **AND** 不再出现 `ERROR: Invalid PDF structure`

### Requirement: tsc 零错误 + 外部签名不变

重构后 `npx tsc --noEmit` 零错误，`indexKnowledgeDocumentWithProgress` 签名不变，现有调用方（kb-sync.ts / tests）零改动。

#### Scenario: 回归测试

- **WHEN** 非扫描件 PDF 通过 `indexKnowledgeDocumentWithProgress` 索引
- **THEN** 行为与重构前完全一致

### Requirement: PDF 引擎替换为 unpdf（Phase 1 ✅ 已完成）

系统 SHALL 使用 `unpdf.extractText` 替换 `pdfjs-dist` 做 PDF 文本提取，消除 worker/polyfill 依赖。

#### Scenario: 文本型 PDF 提取

- **WHEN** 调用 `parseDocumentFromBuffer(pdfBuffer, "doc.pdf")` 且 PDF 包含文本层
- **THEN** `unpdf.extractText` 返回非空文本
- **AND** `parsePdf` 函数签名不变

### Requirement: 扫描件 OCR 降级识别（Phase 2 ✅ 已完成）

系统 SHALL 在 PDF 文本层为空时标记 `ocrDeferred: true`，将 OCR 延迟到异步管线执行。

#### Scenario: 扫描型 PDF 检测

- **WHEN** 调用 `parseDocumentFromBuffer(pdfBuffer, "scan.pdf")` 且 PDF 无文本层
- **THEN** 返回 `{ content: "", metadata: { ocrDeferred: true, pageCount: N, type: "pdf" } }`
- **AND** 不阻塞当前请求线程

### Requirement: OCR 子进程隔离（Phase 3a ✅ 已完成）

系统 SHALL 使用 `child_process.spawn`（非 `worker_threads`）启动 OCR 子进程，PDF buffer 通过临时文件传递。

#### Scenario: OCR 子进程启动

- **WHEN** `indexJobManager.startOcrWorker(docId, pdfBuffer, totalPages, onComplete, onError)` 被调用
- **THEN** PDF buffer 写入临时文件 `/tmp/ocr-{docId}.pdf`
- **AND** 子进程通过 `spawn("tsx", ["dist/cli.mjs", ocr-worker.ts, tmpFile])` 启动
- **AND** 子进程完成后临时文件被清理

### Requirement: SSE 进度结构化（Phase 4 ✅ 已完成）

系统 SHALL 通过 SSE 推送包含 `phase`/`currentDoc`/`docIndex`/`totalDocs` 的结构化 `SyncProgressEvent`。

#### Scenario: 批量同步进度推送

- **WHEN** `POST /api/knowledge/sync` 批量索引 15 个文档
- **THEN** 前端收到 `{ phase: "parsing", currentDoc: "file1.pdf", docIndex: 3, totalDocs: 15 }`

### Requirement: 同步取消 + 前端交互（Phase 5-6 ✅ 已完成）

系统 SHALL 支持取消整个同步批次（`POST /api/knowledge/sync/cancel`），并支持文档行级删除和单文档同步按钮。

#### Scenario: 同步批次取消

- **WHEN** 同步进行中调用 `POST /api/knowledge/sync/cancel`
- **THEN** 当前文档子进程被 kill，ChromaDB chunks 被清理
- **AND** 剩余文档状态回退为 `PENDING_INDEX`
- **AND** SSE 推送 `{ type: "cancelled" }`
