# Checklist: farm-agent-unpdf-migration

## Phase 3: 解析与索引分离

- [ ] [T] Task 3.1: `indexContent()` 函数已从 `indexKnowledgeDocumentWithProgress` 抽出
- [ ] [T] Task 3.1: `indexContent` 签名含 `content: string` + `parsedType: string`，不含 `buffer: Buffer`
- [ ] [T] Task 3.1: ChromaDB metadata 中 `parsedType` 使用参数值（非 `parsed.metadata.type`）
- [ ] [T] Task 3.2: `indexKnowledgeDocumentWithProgress` 退化为 `parseDocumentFromBuffer` → `indexContent`
- [ ] [T] Task 3.2: 外部调用方零改动（签名不变）
- [ ] [T] Task 3.3: `progress/route.ts` OCR `onComplete` 调 `indexContent(id, doc.name, ocrText, "pdf", onProgress)`
- [ ] [T] Task 3.3: 不再出现 `Buffer.from(ocrText)` 包装
- [ ] [T] Task 3.4: `knowledge-sync.ts` / tests / scripts 中现有调用行为不变
- [ ] [T] `npx tsc --noEmit` 零错误
- [ ] [R] OCR 路径 SSE 流返回 "INDEXED" 而非 "Invalid PDF structure"
- [ ] [R] 非扫描件 PDF 索引行为与重构前完全一致（回归测试）

## Phase 1-2: PDF 引擎替换

- [x] [T] `package.json` 无 pdfjs-dist/pdf-parse 依赖
- [x] [T] `parsePdf` 使用 `unpdf.extractText`
- [x] [T] `src/tests/setup.ts` 无 DOMMatrix polyfill
- [x] [R] `@napi-rs/canvas` 已安装，`renderPageAsImage` 可用
- [x] [R] 扫描型 PDF 经 OCR 降级路径返回有效文本

## Phase 3a: OCR 子进程 + 索引管理

- [x] [T] `ocr-worker.ts` 使用 `process.send`（非 `parentPort`）
- [x] [T] `index-job-manager.ts` 管理 `ChildProcess`（非 `worker_threads`）
- [x] [T] PDF buffer 通过临时文件传递（非 env var/stdin）
- [x] [T] `POST /api/.../index/cancel` 可取消任意类型文档
- [x] [T] SSE 两阶段架构（Phase A 解析检测 + Phase B OCR poll）

## Phase 4-6: 结构化 + 取消 + 单文档

- [x] [T] `SyncProgressEvent` 含 phase/currentDoc/docIndex/totalDocs
- [x] [T] `POST /api/knowledge/sync/cancel` 取消整个批次
- [x] [T] agrisynapse 同步面板含取消/同步/删除按钮
- [x] [R] SSE 心跳 8s 保活

## ADD 规则合规检查

- [ ] ADD-1 可观测性优先：indexContent 内 auditDoc/agentAudit 调用保持
- [ ] ADD-2 阶段标记对称：indexContent 的 audit 阶段与 `indexKnowledgeDocumentWithProgress` 一致
- [ ] ADD-4 三通道输出：Console + File + DB 的 audit 调用未破坏
- [ ] ADD-5 审计数据即业务数据：ChromaDB metadata 中 parsedType 正确传递
- [ ] Plan/Spec 一致性：实现与 spec.md Requirements 的 WHEN-THEN 场景一致
- [ ] Plan/Spec 修订记录：本次 spec 创建已记录
