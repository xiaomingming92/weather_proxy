# Checklist

> **证据规范**：每项 [x] 必须附带可验证证据。不得空勾选、不得推测通过。

## Phase 1: 模板与入口

- [ ] [E] report-handoff-template.md 已新建 — 证据: `grep -c "关闭格式" .qoder/templates/report-handoff-template.md` = 1
- [ ] [E] AGENTS.md 已更新 10 阶段 + Step 9 词汇 — 证据: `grep -c "10 阶段" AGENTS.md` = 1

## Phase 2: 核心 Skill + 词汇

- [ ] [E] add-paradigm SKILL.md 已新增 Step 9 章节 — 证据: `grep -c "Step 9" .qoder/skills/add-paradigm/SKILL.md` ≥ 1
- [ ] [E] add-governance-vocabulary.md 已新增 report 词汇 — 证据: `grep -c "Step 9" .qoder/vocabulary/add-governance-vocabulary.md` ≥ 1

## Phase 3: 模板同步

- [ ] [E] add-route-template.md 已新增 Step 9 行 — 证据: `grep -c "Step 9" .qoder/templates/add-route-template.md` ≥ 1
- [ ] [E] add-route-template-heavyweight.md 已新增 Step 9 行 — 证据: `grep -c "Step 9" .qoder/templates/add-route-template-heavyweight.md` ≥ 1

## Phase 4: 规则与映射

- [ ] [E] project_rules.md 已更新 10 阶段 + ADD-15 — 证据: `grep -c "10 个阶段" .qoder/rules/project_rules.md` = 1
- [ ] [E] theory-practice-map.toml 已新增 Step 9 — 证据: `grep -c "Step 9" .qoder/rules/theory-practice-map.toml` ≥ 1

## Phase 5: Agent 同步

- [ ] [E] add-flow-guardian.md 已新增 Step 9 入口/出口 — 证据: `grep -c "Step 9" .qoder/agents/add-flow-guardian.md` ≥ 2
- [ ] [E] add-orchestrator.md 已新增 Step 9 — 证据: `grep -c "Step 9" .qoder/agents/add-orchestrator.md` ≥ 1

## Phase 6: 报告格式修正

- [ ] [E] REPORT-WORKFLOW.md 格式已对齐 `- [x]` — 证据: `grep -c "\- \[x\] Triage 结果" .qoder/reports/REPORT-WORKFLOW.md` ≥ 1
- [ ] [R] gateway.md 31 条发现均已 `- [x]` + check-boundary-report 通过 — 证据: `npx tsx scripts/check-boundary-report.ts`