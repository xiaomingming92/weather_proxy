# Report Closure 集成 Spec

## Why

gateway.md 运行时发现关闭流程未接入 ADD 工作流：handoff 无 Report Closure 模板、REPORT-WORKFLOW.md 格式与 check-boundary-report.ts 解析逻辑不一致、ADD 没有强制步骤关闭运行时发现。

## What Changes

- 新建独立 `report-handoff-template.md`
- 新增 ADD Step 9（Report Closure）条件性步骤
- 同步 10 个治理文件从 Step 0-8 → Step 0-9
- 修正 REPORT-WORKFLOW.md 格式对齐 `- [x]`
- 修复 gateway.md 31 条发现

## Impact

- Affected specs: 无
- Affected code: 无（纯治理文档变更）
- 父 Plan: `.qoder/plans/2026-07/01/farm-agent-report-closure-integration-plan-v1.md`

## Boundaries

- 本次只修改 `.qoder/` 和 `AGENTS.md` 下的治理文件
- 禁止修改 `src/` 下任何代码
- 禁止修改 `prisma/` 下任何 Schema

## ADDED Requirements

### Requirement: 独立 report-handoff 模板

#### Scenario: runtime-fix plan 的 handoff 需要 Report Closure 章节

- **WHEN** runtime-fix plan 完成 Step 8 收敛，需关闭 gateway.md 发现
- **THEN** 按 `report-handoff-template.md` 在 handoff 中追加 Report Closure 章节，按模板格式列出关闭的发现 + 验证命令

### Requirement: ADD Step 9 Report Closure

#### Scenario: runtime-fix plan 进入收敛流程

- **WHEN** Step 8 收敛条件满足 + plan 涉及 gateway.md 发现修复
- **THEN** 进入 Step 9：按模板在 gateway.md 追加 `- [x]` 标记 + 运行 check-boundary-report 验证

#### Scenario: 非 runtime plan 跳过 Step 9

- **WHEN** plan 不涉及 gateway.md 运行时发现
- **THEN** 直接跳过 Step 9，进入架构文档回看

### Requirement: 治理文件 Step 编号升级

#### Scenario: 新增 Step 后所有引用点同步

- **WHEN** ADD 范式从 9 阶段升级到 10 阶段
- **THEN** AGENTS.md / add-paradigm SKILL.md / 词汇表 / add-route 模板 / project_rules.md / theory-practice-map.toml / Guardian / Orchestrator 中所有 "Step 0-8" / "9 阶段" 引用更新为 "Step 0-9" / "10 阶段"

### Requirement: REPORT-WORKFLOW.md 格式对齐

#### Scenario: gateway.md 发现被 triage 后关闭

- **WHEN** 修复完成需标记发现为已关闭
- **THEN** 在 gateway.md 对应发现条目内追加 `- [x] Triage 结果: ✅ 已修复 — commit {hash}（{原因}）`，使 check-boundary-report.ts L58-60 可正确识别为关闭状态
