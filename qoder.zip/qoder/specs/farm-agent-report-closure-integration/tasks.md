# Tasks

> **验证规范**：每个 Task 完成时必须附带验证证据。

## Phase 1: 模板与入口

- [ ] Task 1.1: 新建 report-handoff-template.md — 验证: 文件存在 + 含 "关闭格式" / "check-boundary-report" 关键词
- [ ] Task 1.2: 更新 AGENTS.md — 验证: grep "10 阶段" / "Step 9" 各命中 1 次

## Phase 2: 核心 Skill + 词汇

- [ ] Task 2.1: 更新 add-paradigm SKILL.md — 验证: grep "10 phases" / "Step 9" 各命中
- [ ] Task 2.2: 更新 add-governance-vocabulary.md — 验证: grep "Step 9" / "report-handoff" / "gateway.md" / "boundary-report" 各命中

## Phase 3: 模板同步

- [ ] Task 3.1: 更新 add-route-template.md（轻量）— 验证: grep "Step 9" 命中
- [ ] Task 3.2: 更新 add-route-template-heavyweight.md — 验证: grep "Step 9" 命中

## Phase 4: 规则与映射

- [ ] Task 4.1: 更新 project_rules.md — 验证: grep "10 个阶段" / "ADD-15" 各命中
- [ ] Task 4.2: 更新 theory-practice-map.toml — 验证: grep "Step 9" 命中

## Phase 5: Agent 同步

- [ ] Task 5.1: 更新 add-flow-guardian.md — 验证: grep "Step 9" 命中 2 次（入口+出口）
- [ ] Task 5.2: 更新 add-orchestrator.md — 验证: grep "Step 9" 命中

## Phase 6: 报告格式修正

- [ ] Task 6.1: 修正 REPORT-WORKFLOW.md 格式对齐 `- [x]` — 验证: grep "\- \[x\] Triage 结果" 命中
- [ ] Task 6.2: gateway.md 31 条发现追 `- [x]` + 删除 §2/§4 — 验证: npx tsx scripts/check-boundary-report.ts 全部已关闭