# Tasks

## Phase 1: 数据层 Schema 迁移

- [ ] Task 1.1: prisma/schema.prisma 新增 farm_server_credential 表
  - [ ] SubTask 1.1.1: 定义字段：id, user_id(@unique), access_token, refresh_token, expires_at, created_at, updated_at
  - [ ] SubTask 1.1.2: access_token 和 refresh_token 使用加密存储
- [ ] Task 1.2: prisma/schema.prisma 新增 user_profile 表
  - [ ] SubTask 1.2.1: 定义字段：id, user_id(@unique), nickname, dept_id, dept_name, email, mobile, preferences(Json), tags(Json), responsible_massif_ids(Json), created_at, updated_at
- [ ] Task 1.3: User.Role 枚举新增 SERVICE
- [ ] Task 1.4: 执行 `npx prisma migrate dev` 迁移
- [ ] Task 1.5: 验证：三张表可正常 CRUD

## Phase 2: 基础设施层

- [ ] Task 2.1: 创建 `src/lib/auth/credential-store.ts`
  - [ ] SubTask 2.1.1: saveToken(userId, accessToken, refreshToken, expiresAt) → prisma.farmServerCredential.upsert
  - [ ] SubTask 2.1.2: getValidToken(userId) → 检查过期，过期则调 refresh
  - [ ] SubTask 2.1.3: refreshUserToken(userId) → POST /system/auth/refresh-token?refreshToken=xxx，更新 credential 表
  - [ ] SubTask 2.1.4: 验证：项目全局仅 `src/lib/auth/` 目录 import prisma.farmServerCredential（grep 检查）
- [ ] Task 2.2: 创建 `src/lib/auth/token-manager.ts`
  - [ ] SubTask 2.2.1: 区分请求来源（agrisynapse vs 自有 UI）
  - [ ] SubTask 2.2.2: refresh 失败处理：神经元来源 → TOKEN_EXPIRED 事件，自有 UI → 302 /login
  - [ ] SubTask 2.2.3: 验证：token 写入 → 读取 → 模拟过期 → refresh → 更新全流程通过
- [ ] Task 2.3: 创建 `src/lib/hash-path.ts`
  - [ ] SubTask 2.3.1: `.env` 新增 `HASH_SEED_TEXT`（需求文档关键段落，不硬编码到代码）
  - [ ] SubTask 2.3.2: generateHash() → SHA-256(process.env.HASH_SEED_TEXT + Math.floor(Date.now() / 600000)).slice(0, 12)
  - [ ] SubTask 2.3.3: validateHash(hash) → 验证当前窗口 ±1 窗口容差
  - [ ] SubTask 2.3.4: 验证：同窗口 hash 一致，跨窗口 hash 不同，±1 容差正常
- [ ] Task 2.4: 创建 `src/lib/farm-server-client.ts`
  - [ ] SubTask 2.4.1: createClient({ baseUrl, auth, getToken? }) → { request(method, path, params) }
  - [ ] SubTask 2.4.2: bearer auth 模式：getToken → credential-store.getValidToken
  - [ ] SubTask 2.4.3: qweather auth 模式：JWT EdDSA 签名，凭据从 .env
  - [ ] SubTask 2.4.4: 创建 `src/lib/farm-server-client-dev-logger.ts`（Layer1 审计，console + file + DB metadata）
  - [ ] SubTask 2.4.5: 创建 `src/lib/farm-server-client-audit.ts`（Layer2 审计，AuditLog 表）
  - [ ] SubTask 2.4.6: 验证：bearer 和 qweather 双通道均可正常请求

## Phase 3: 业务层

- [ ] Task 3.1: 创建 `src/app/api/agent/[hash]/route.ts`
  - [ ] SubTask 3.1.1: GET handler → `?action=thread&id=xxx` 查询对话历史和进度
  - [ ] SubTask 3.1.2: GET handler → `?action=report&id=xxx&format=md` 导出分析报告
  - [ ] SubTask 3.1.3: GET handler → `?action=dashboard` 返回技能卡片 + 推荐话题
  - [ ] SubTask 3.1.4: POST handler → `body.type: "handshake"` 存 token + upsert user_profile + 异步预载 3 个热加载专家
  - [ ] SubTask 3.1.5: POST handler → `body.type: "chat"` LangGraph agent + SSE stream 响应
  - [ ] SubTask 3.1.6: 验证：6 个操作全线通过
- [ ] Task 3.2: 天气/时间工具迁移（8 文件）
  - [ ] SubTask 3.2.1: 从 co-agent 复制 `weather-tools.ts` → `src/agents/tools/impl/`
  - [ ] SubTask 3.2.2: 从 co-agent 复制 `time-tools.ts` → `src/agents/tools/impl/`
  - [ ] SubTask 3.2.3: 从 co-agent 复制 schemas/weather-tools.ts + schemas/time-tools.ts
  - [ ] SubTask 3.2.4: 从 co-agent 复制 weather-dev-logger.ts + weather-audit.ts → `src/lib/`
  - [ ] SubTask 3.2.5: 从 co-agent 复制 time-tool-dev-logger.ts + time-tool-audit.ts → `src/lib/`
  - [ ] SubTask 3.2.6: 修改 weather-tools.ts：用 farm-server-client(qweather) 替代内部 HTTP + JWT 逻辑
  - [ ] SubTask 3.2.7: 验证：4 个天气工具 + 1 个时间工具编译通过
- [ ] Task 3.3: Farm-Server 数据工具（5 个工具 × 3 文件 = 15 文件）
  - [ ] SubTask 3.3.1: soil-moisture-tool.ts + schema + 审计日志器（接口：GET /moisture-data/get, /moisture-data/page）
  - [ ] SubTask 3.3.2: insect-data-tool.ts + schema + 审计日志器（接口：GET /insect-data/get, /insect-data/page）
  - [ ] SubTask 3.3.3: insect-type-tool.ts + schema + 审计日志器（接口：GET /insect-type/get, /insect-type/page）
  - [ ] SubTask 3.3.4: farm-weather-tool.ts + schema + 审计日志器（接口：GET /weather-data/get, /weather-data/page）
  - [ ] SubTask 3.3.5: massif-tool.ts + schema + 审计日志器（接口：GET /massif/get, /massif/page）
  - [ ] SubTask 3.3.6: 每个工具支持 GET/get（id 精确查）和 GET/page（pageNo + pageSize ≤ 200）
  - [ ] SubTask 3.3.7: 验证：5 个工具编译通过，所有接口按 6 份 API 文档的 code: 200 规范

## Phase 4: 集成与验证

- [ ] Task 4.1: 管线集成 ToolNode
  - [ ] SubTask 4.1.1: `src/agents/tools/index.ts` 注册全部工具（现有 14 + 天气 5 + 时间 1 + FS 5 = ~25）
  - [ ] SubTask 4.1.2: `src/agents/index.ts` 导入 ToolNode from @langchain/langgraph/prebuilt
  - [ ] SubTask 4.1.3: `src/agents/index.ts` 添加 `.addNode("toolNode", new ToolNode(agentTools))`
  - [ ] SubTask 4.1.4: `src/agents/index.ts` 条件路由：routeAfterIntention → tool_calls? toolNode : 现有管线
  - [ ] SubTask 4.1.5: 验证：tool_calls → toolNode → intention 环正常
- [ ] Task 4.2: Middleware + 神经元账号
  - [ ] SubTask 4.2.1: 创建 `src/middleware.ts`
  - [ ] SubTask 4.2.2: hash 验证逻辑 → 不匹配返回 404（无响应体）
  - [ ] SubTask 4.2.3: session 校验逻辑 → 无效返回 401
  - [ ] SubTask 4.2.4: 种子脚本：创建 agrisynapse 的 SERVICE role User 账号（用户名/密码来自 .env 环境变量）
  - [ ] SubTask 4.2.5: 验证：未登录 → 401, hash 错 → 404, 正常请求 → 200
- [ ] Task 4.3: 编译验证 + 端到端
  - [ ] SubTask 4.3.1: `npx tsc --noEmit` 零错误
  - [ ] SubTask 4.3.2: `npm run build` 成功
  - [ ] SubTask 4.3.3: 端到端：agrisynapse login → handshake → POST chat SSE stream 全线通过
  - [ ] SubTask 4.3.4: 端到端：GUI 关闭 → agent 继续执行 → 重连后 GET ?action=thread 恢复
  - [ ] SubTask 4.3.5: 端到端：agent 重启 → credential 恢复 → pending 任务从 checkpoint 继续
  - [ ] SubTask 4.3.6: 端到端：hash 跨 10 分钟窗口自动滚动，SSE 对话不中断

## Phase 5: ToolNode→Response 数据契约修复（Runtime Review v2 F7-F9 回流）

- [ ] Task 5.1: State 新增 `toolResults` 结构化字段
  - [ ] SubTask 5.1.1: `src/agents/state.ts` 新增 `toolResults` Annotation
    ```typescript
    toolResults: Annotation<Array<{
      toolName: string
      success: boolean
      recordCount: number
      list: unknown[]
      columns?: { prop: string; label: string }[]
      error?: string
    }>>()
    ```
  - [ ] SubTask 5.1.2: 验证：`npx tsc --noEmit` 无新增类型错误
- [ ] Task 5.2: ToolNode 写入 `toolResults`
  - [ ] SubTask 5.2.1: `src/agents/index.ts` `createToolNodeWrapper` return 中同时写入 `messages` 和 `toolResults`
  - [ ] SubTask 5.2.2: 工具执行成功路径：从 `result` 对象提取 `toolName`、`success`、`list.length`、`columns`
  - [ ] SubTask 5.2.3: 工具执行失败路径：写入 `error` 字段，`recordCount=0`
  - [ ] SubTask 5.2.4: 验证：toolNode 执行后 `state.toolResults` 非空且字段正确
- [ ] Task 5.3: Response 节点消费 `toolResults` + 降级兼容
  - [ ] SubTask 5.3.1: `src/agents/nodes/response.ts` `buildToolExecutionSummary` 改为从 `state.toolResults` 读取（优先）
  - [ ] SubTask 5.3.2: 降级路径：`toolResults` 为空时回退到 ToolMessage JSON 解析，增加 `parsed.list` 兜底
  - [ ] SubTask 5.3.3: 验证：mock 工具返回 20 条记录，LLM prompt 摘要显示 "返回 20 条记录"
- [ ] Task 5.4: ADD 审计
  - [ ] SubTask 5.4.1: `toolResults` 写入/消费处添加 `agentAudit` 调用
  - [ ] SubTask 5.4.2: 调用 `record_dev_operation` 记录所有文件变更
  - [ ] SubTask 5.4.3: 验证：`query_audit_logs({ keyword: "toolResults" })` 可回溯
