# tools-calling-pipeline Spec

## Why

farm-agent 的 LangGraph 管线缺少工具调用节点，无法调用 Farm-Server 和 QWeather 外部 API。同时缺少完整的认证体系（神经元→farm-agent、farm-agent→Farm-Server）和端点安全防护。agrisynapse 的 9 个技能卡片（农情日报、病虫害识别等）需要真实农场数据支撑，目前完全没有对接。

## What Changes

### 新建文件（~29 个）

- `prisma/schema.prisma`：新增 farm_server_credential 表 + user_profile 表，User.Role 新增 SERVICE 枚举
- `src/lib/auth/credential-store.ts`：auth 层 token CRUD（项目唯一引用 prisma.farmServerCredential 的模块）
- `src/lib/auth/token-manager.ts`：refresh 逻辑 + 请求来源区分（神经元 vs 自有 UI）
- `src/lib/hash-path.ts`：动态 hash 路径生成，`process.env.HASH_SEED_TEXT` + 10分钟时间窗口 → SHA-256
- `src/lib/farm-server-client.ts`：通用 HTTP 客户端，支持 bearer/qweather 双 auth
- `src/lib/farm-server-client-dev-logger.ts` + `farm-server-client-audit.ts`：Layer1/Layer2 审计
- `src/app/api/agent/[hash]/route.ts`：单端点 Route Handler，GET 只读 + POST 写操作
- `src/middleware.ts`：hash 验证 + session 校验
- 天气工具迁移 8 文件（weather-tools / time-tools / schemas / 审计日志器）
- Farm-Server 工具 15 文件（5 个工具 × 3 文件：实现 + schema + 审计）

### 修改文件

- `src/agents/tools/index.ts`：注册 ~11 个新工具
- `src/agents/index.ts`：添加 ToolNode + 条件路由边
- `src/agents/state.ts`：新增 `toolResults` 结构化字段（Runtime Review v2 F7 回流）
- `src/agents/nodes/response.ts`：`buildToolExecutionSummary` 优先消费 `state.toolResults`，降级兼容 ToolMessage JSON 解析（Runtime Review v2 F7 回流）

## Impact

- Affected specs: 无（本项目首个工具管线 spec）
- Affected code: `src/lib/auth/`, `src/app/api/agent/[hash]/`, `src/agents/tools/`, `src/agents/state.ts`, `src/agents/nodes/response.ts`, `src/agents/index.ts`, `prisma/`, `src/middleware.ts`
- 父 Plan: `.qoder/plans/farm-agent-tools-pipeline-plan-v1.md`
- 依赖: co-agent 天气/时间工具源码（commit dae1c76），Farm-Server 6 份 API 文档
- 后续依赖: agrisynapse 侧 `src/utils/farm-agent-hash.ts` + `.env` HASH_SEED_TEXT

## ADDED Requirements

### Requirement: 三层认证栈

系统 SHALL 实现三层认证隔离，确保 credential 表 LLM tool 不可达。

#### Scenario: agrisynapse 请求 farm-agent

- **WHEN** agrisynapse 携带 session cookie（SERVICE role User 登录态）请求 farm-agent
- **THEN** middleware 验证通过，放行到 API Route

#### Scenario: farm-agent 请求 Farm-Server

- **WHEN** Agent 执行时需要 Farm-Server 数据
- **THEN** auth 层从 credential-store 获取 per-user 有效 token（过期则自动 refresh）

#### Scenario: LLM 调用 tool

- **WHEN** LLM 决定调用 Farm-Server 数据工具
- **THEN** tool 通过 farm-server-client 的 getToken 回调获取 token，LLM 永远不知道 credential 表存在

#### Scenario: credential 表隔离

- **WHEN** 任意 tool 文件尝试 import credential-store 或 prisma.farmServerCredential
- **THEN** 编译/构建阶段通过 grep 检查拦截（0 个 tool 文件引用）

### Requirement: 动态 hash 端点安全

系统 SHALL 使用动态 hash 路径防止端点被枚举爆破，种子文字不硬编码。

#### Scenario: hash 匹配

- **WHEN** 请求路径为 `/api/agent/{hash}` 且 hash = SHA-256(process.env.HASH_SEED_TEXT + Math.floor(Date.now() / 600000)).slice(0, 12)
- **THEN** middleware 放行请求

#### Scenario: hash 不匹配

- **WHEN** hash 不在当前窗口 ±1 窗口容差内
- **THEN** middleware 返回 404，无任何响应体

#### Scenario: hash 跨窗口滚动

- **WHEN** 10 分钟窗口切换（临界时刻前后窗口不同）
- **THEN** ±1 窗口容差（验证当前、前一个、后一个窗口的 hash）确保临界时刻请求不中断

#### Scenario: 种子文字安全

- **WHEN** 攻击者反编译服务端构建产物
- **THEN** 代码中只有 `process.env.HASH_SEED_TEXT` 变量名，实际种子文字仅在 `.env` 中，无法计算 hash

#### Scenario: 端点无语义

- **WHEN** 攻击者抓包观察到请求 URL
- **THEN** 仅看到一个随机 hex 端点，无法推断服务类型、操作类型、参数格式（HTTPS 加密 query params 和 body）

### Requirement: Token 持久化与恢复

系统 SHALL 支持 GUI 断开和 agent 重启后的任务恢复。

#### Scenario: GUI 关闭

- **WHEN** 用户关闭浏览器（GUI 断开）
- **THEN** agent 的 LangGraph session 继续在服务端执行，credential 表持久化不丢失

#### Scenario: agent 重启

- **WHEN** farm-agent 进程意外退出后重新启动
- **THEN** auth 层从 credential 表恢复 per-user token，pending 任务从 LangGraph checkpoint 继续

#### Scenario: token 自动 refresh

- **WHEN** agent 调 Farm-Server 返回 401
- **THEN** auth 层自动用 refresh_token 调 `/system/auth/refresh-token` 刷新，更新 credential 表后重试原请求

#### Scenario: refresh 失败区分来源

- **WHEN** refresh_token 也过期
- **THEN** 区分请求来源：agrisynapse 来源返回 `TOKEN_EXPIRED` 事件，自有 UI 来源 → 302 重定向 /login

### Requirement: 用户分表管理

系统 SHALL 维护 user_profile 分表，存储基础信息 + 偏好 + 地块关联，与 credential 表物理分离。

#### Scenario: 握手更新

- **WHEN** agrisynapse 调用 handshake 传入 UserVO
- **THEN** farm-agent 对比传入的 UserVO 与 user_profile，有变更（昵称/部门/邮箱/手机）则 UPDATE，无变更跳过

#### Scenario: LLM 读取用户信息

- **WHEN** LLM 需要用户信息（昵称、负责地块 ID）
- **THEN** 从 user_profile 表读取，不额外调 Farm-Server API

### Requirement: 专家能力加载

系统 SHALL 支持热加载和惰性加载两种专家预载策略。

#### Scenario: 热加载（握手时异步预载）

- **WHEN** 用户完成 handshake
- **THEN** farm-agent 异步预载农情日报、天气影响、作业规划 3 个专家的 Farm-Server 数据（per-user token + massifId 精确查）

#### Scenario: 惰性加载（技能卡片触发）

- **WHEN** 用户点击周报分析/生长报告/病虫害识别/营养诊断/种植建议/农机调度 6 个技能卡片之一
- **THEN** farm-agent 按需调 Farm-Server 获取对应数据

### Requirement: 工具数据查询

系统 SHALL 通过 per-user token + massifId 精确查询 Farm-Server 数据，禁止全量拉取。

#### Scenario: 用户地块过滤

- **WHEN** Agent 调 Farm-Server 数据接口（土墒/虫情/气象站/地块）
- **THEN** 请求携带 massifId 参数，Farm-Server 返回该用户负责地块的数据

#### Scenario: 分页查询

- **WHEN** 数据量可能较大
- **THEN** 支持 GET/page 分页（pageNo + pageSize ≤ 200）

#### Scenario: 单条查询

- **WHEN** 需要获取单条详情
- **THEN** 支持 GET/get（id 精确查询）

### Requirement: 安全边界

系统 SHALL 强制安全边界，禁止危险 tool 和危险操作。

#### Scenario: 禁止通用 tool

- **WHEN** 开发尝试新建 tool 文件
- **THEN** 禁止文件系统读取 tool、通用 HTTP（curl/fetch 任意 URL）tool、代码执行 tool

#### Scenario: 禁止数据写操作

- **WHEN** Agent 需要与 Farm-Server 交互
- **THEN** 仅允许 GET 接口（get/page），禁止 create/update/delete 接口工具

#### Scenario: 禁止定时任务

- **WHEN** 考虑数据同步策略
- **THEN** 禁止 cron/定时任务，禁止 service account 全量拉取 Farm-Server 数据，所有查询均为 per-user + massifId 精确过滤

#### Scenario: 禁止新建 service_account 表

- **WHEN** 管理神经元认证
- **THEN** 复用 User 表 + SERVICE role，不新建 service_account 表

### Requirement: Tool 结果结构化通道（Runtime Review v2 F7 回流）

系统 SHALL 在 LangGraph State 中提供 `toolResults` 结构化字段作为 ToolNode 与 Response 节点之间的数据契约，消除 JSON Stringify → Parse → 字段探测的不确定链。

#### Scenario: ToolNode 写入结构化结果

- **WHEN** ToolNode 包装器执行工具并获取返回值 `{ success, total, list, columns }`
- **THEN** 同时写入 `messages`（保留给 LLM 上下文）和 `state.toolResults`（给下游节点消费），`toolResults` 中每条记录包含 `toolName`、`success`、`recordCount`、`list`、`columns`

#### Scenario: Response 节点优先消费 toolResults

- **WHEN** Response 节点的 `buildToolExecutionSummary` 构建工具调用摘要
- **THEN** 优先从 `state.toolResults` 读取结构化记录数（`recordCount`、`toolName`、`success`），不再从 ToolMessage JSON 反向解析

#### Scenario: 降级兼容 ToolMessage JSON

- **WHEN** `state.toolResults` 为空（旧线程恢复或迁移期）
- **THEN** 降级到 ToolMessage JSON 解析，按三级优先级探测：`parsed.data.data.list` → `parsed.data.list` → `parsed.list`

#### Scenario: recordCount 正确反映实际记录数

- **WHEN** 工具 `query_farm_weather` 返回 20 条记录
- **THEN** LLM prompt 中的工具摘要显示 "查询成功，返回 20 条记录"（而非 "返回 0 条记录"）
