# Checklist

## Phase 1: 数据层

- [ ] farm_server_credential 表字段完整（id, user_id, access_token, refresh_token, expires_at, created_at, updated_at）
- [ ] user_profile 表字段完整（id, user_id, nickname, dept_id, dept_name, email, mobile, preferences, tags, responsible_massif_ids, created_at, updated_at）
- [ ] User.Role 枚举含 SERVICE
- [ ] `npx prisma migrate dev` 执行成功
- [ ] 三张表可正常 CRUD

## Phase 2: 基础设施层

- [ ] credential-store 三个方法均可正常调用（saveToken / getValidToken / refreshUserToken）
- [ ] 项目全局仅 `src/lib/auth/` 目录 import prisma.farmServerCredential（grep 确认 0 个 tool 文件引用）
- [ ] token 写入 → 读取 → 模拟过期 → refresh → 更新全流程通过
- [ ] refresh 失败区分来源：神经元返回 TOKEN_EXPIRED，自有 UI → 302
- [ ] hash 同窗口一致，跨窗口不同，±1 窗口容差正常
- [ ] HASH_SEED_TEXT 在 .env 中而非代码中（grep 确认无硬编码）
- [ ] farm-server-client bearer auth 可正常请求 Farm-Server
- [ ] farm-server-client qweather auth 可正常请求 QWeather API
- [ ] farm-server-client-dev-logger.ts（Layer1）输出到 console + file + DB metadata
- [ ] farm-server-client-audit.ts（Layer2）写入 AuditLog 表

## Phase 3: 业务层

- [ ] GET `/api/agent/{hash}?action=thread&id=xxx` 查询对话成功
- [ ] GET `/api/agent/{hash}?action=report&id=xxx&format=md` 报告导出成功
- [ ] GET `/api/agent/{hash}?action=dashboard` 返回技能卡片 + 推荐话题
- [ ] POST handshake → token 存储 + user_profile upsert + 3 个热加载专家异步预载
- [ ] POST chat → SSE stream 输出正常
- [ ] chat SSE 中 tool_call 阶段可调 Farm-Server
- [ ] 4 个天气工具编译通过，qweather auth 正常
- [ ] 1 个时间工具编译通过
- [ ] soil-moisture-tool 编译通过，支持 GET/get + GET/page
- [ ] insect-data-tool 编译通过，支持 GET/get + GET/page
- [ ] insect-type-tool 编译通过，支持 GET/get + GET/page
- [ ] farm-weather-tool 编译通过，支持 GET/get + GET/page
- [ ] massif-tool 编译通过，支持 GET/get + GET/page
- [ ] 所有 Farm-Server 工具按 code: 200 规范（非 code: 0）
- [ ] 每个 Farm-Server 工具含 3 文件：实现 + schema + 审计日志器

## Phase 4: 集成与验证

- [ ] tools/index.ts 注册全部工具（~25 个）
- [ ] agents/index.ts 含 ToolNode 节点 + 条件路由边
- [ ] tool_calls → toolNode → intention 环正常
- [ ] middleware：hash 不匹配 → 404（无响应体）
- [ ] middleware：session 无效 → 401
- [ ] agrisynapse SERVICE 账号可登录 farm-agent
- [ ] `npx tsc --noEmit` 零错误
- [ ] `npm run build` 成功
- [ ] 端到端：agrisynapse login → handshake → POST chat SSE 全线通过
- [ ] 端到端：GUI 关闭 → agent 继续 → 重连恢复
- [ ] 端到端：agent 重启 → credential 恢复 → 任务继续
- [ ] 端到端：hash 跨 10 分钟窗口自动滚动，对话不中断
- [ ] agrisynapse 侧 `farm-agent-hash.ts` 本地 hash 计算与 farm-agent 一致

## Phase 5: ToolNode→Response 数据契约修复

- [ ] `src/agents/state.ts` 含 `toolResults` Annotation，类型为 `Array<{toolName, success, recordCount, list, columns?, error?}>`
- [ ] ToolNode 成功路径写入 `toolResults`（含 `toolName`、`success=true`、`recordCount`、`list`、`columns`）
- [ ] ToolNode 失败路径写入 `toolResults`（含 `error`、`success=false`、`recordCount=0`）
- [ ] `buildToolExecutionSummary` 优先从 `state.toolResults` 读取（`toolResults` 非空时跳过 ToolMessage JSON 解析）
- [ ] 降级路径：`toolResults` 为空时回退 ToolMessage JSON 解析，含 `parsed.list` 兜底
- [ ] 工具返回 20 条记录时，LLM prompt 摘要显示 "返回 20 条记录"（非 "返回 0 条记录"）
- [ ] `toolResults` 写入/消费处有 `agentAudit` 调用
- [ ] `record_dev_operation` 已记录所有文件变更
- [ ] `query_audit_logs({ keyword: "toolResults" })` 可回溯

## ADD 规则合规检查

- [ ] ADD-1 可观测性优先：所有新增模块含 Layer1（dev-logger）+ Layer2（audit）审计
- [ ] ADD-2 阶段标记对称：所有异步函数内 auditPhaseStart/End 配对
- [ ] ADD-4 三通道输出：审计日志输出到 console + file + AuditLog 表
- [ ] ADD-5 审计数据即业务数据：Layer2 审计写入 AuditLog 表，`query_audit_logs` 可回查
- [ ] ADD-6 失败路径等价审计：catch 块 extra 字段数 ≥ try 块
- [ ] ADD-7 开发操作审计：所有文件改动已记录 `record_dev_operation`
- [ ] Plan/Spec 一致性：代码实现与 `.qoder/specs/tools-calling-pipeline/spec.md` 定义一致
- [ ] 不存在文件系统/通用 HTTP/代码执行 tool
- [ ] 不存在 Farm-Server create/update/delete 接口工具
- [ ] 不存在 service_account 表（复用 User + SERVICE role）
- [ ] 不存在定时任务/cron
