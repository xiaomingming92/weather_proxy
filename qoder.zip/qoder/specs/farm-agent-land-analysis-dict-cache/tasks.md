# Tasks: Land Analysis DictCache

## Preconditions

- [ ] Task 0: 调用 `/system/dict-data/type` 确认 moistureType dictType
- [ ] 确认 Farm-Server token 可用（`ensureValidToken(0, "service")`）

## Forbidden

- 禁止修改 variety-recommend / cost-accounting 等非 land-analysis 端点的枚举映射
- 禁止引入新的持久化依赖（数据库表、ChromaDB collection）
- 禁止在 DictCache 中硬编码业务特定的枚举值（业务枚举通过 registerStatic 外部注入）

## Phase 1: 前置确认 + 肥力应急修复

- [ ] Task 0: 前置确认 moistureType dictType
  - [ ] 调用 `/system/dict-data/type` 搜索 moisture/soil 相关 dictType
  - [ ] 如存在 → 记录确切 dictType 名称
  - [ ] 如不存在 → 准备 `registerStatic` 静态映射数据

- [ ] Task 1: 修复 route.ts 肥力计算
  - [ ] `fertilityLevel` 取值兼容 `number | string | null`
  - [ ] 映射表扩展为 `{'0':'低','1':'中','2':'高','低':'低','中':'中','高':'高'}`
  - [ ] 保留面积加权逻辑
  - [ ] `MassifDTO.fertilityLevel` 类型改为 `number | string | null`
  - [ ] 新增 `AgentAuditPhase: LAND_FERTILITY_CALC`
  - [ ] [T] `tsc --noEmit` 通过

## Phase 2: DictCache 模块

- [ ] Task 2: 创建 DictCache 模块
  - [ ] 新建 `src/lib/farm-api/dict-cache.ts`
  - [ ] 实现 `preload(dictTypes, getToken)` — 通过 farmClient 调 dict API
  - [ ] 实现 `getLabel(dictType, value, fallback?)` 
  - [ ] 实现 `getMap(dictType)`
  - [ ] 实现 `registerStatic(dictType, mapping)` — 静态映射兜底
  - [ ] 实现 lazy-init：首次 getLabel 触发 preload，加 Promise 锁
  - [ ] 实现 TTL 惰性刷新：缓存过期后下次查询自动刷新
  - [ ] 新增 `AgentAuditPhase: DICT_CACHE_PRELOAD` + `DICT_CACHE_REFRESH`
  - [ ] [T] 独立导入 DictCache 可编译

## Phase 3: 接入 + soilTypeSummary

- [ ] Task 3: route.ts 接入 DictCache + 新增 soilTypeSummary
  - [ ] fertility 映射改为 `DictCache.getMap("farm_massif_fertility_level")`
  - [ ] 删除硬编码 `FERTILITY_LABELS`
  - [ ] 新增 soilTypeSummary 计算：moistureType 分组 → DictCache.getLabel → 面积加权 → `"类型A x%  类型B x%"` 格式
  - [ ] 新增 `AgentAuditPhase: LAND_SOILTYPE_CALC` + `DICT_CACHE_FALLBACK`
  - [ ] [T] `tsc --noEmit` 通过

## Phase 4: Prompt + 后处理

- [ ] Task 4: LLM prompt 更新 + 后处理强制覆盖
  - [ ] land-analysis.ts prompt 字段名 `soilType` → `soilTypeSummary`
  - [ ] prompt 明确指示 `fertilitySummary` 和 `soilTypeSummary` 直接使用输入值，无需推理
  - [ ] route.ts 后处理：`result.soilInfo.fertility = fertilitySummary`，`result.soilInfo.soilTypeSummary = soilTypeSummary`
  - [ ] [T] Zod schema 校验通过（`landAnalysisSchema.safeParse` 返回 success）

## Phase 5: 文档 + 验证

- [ ] Task 5: .md 文档差异记录
  - [ ] 地块基本信息管理接口文档新增"枚举值映射"章节
  - [ ] 新增"与 OpenAPI 差异记录"章节

- [ ] Task 6: 编译验证 + E2E
  - [ ] [T] `npx tsc --noEmit` 零错误
  - [ ] [T] `npm run lint` 无新增问题
  - [ ] [R] `curl /api/h5/production-plan/land-analysis` 验证 fertility 和 soilTypeSummary 输出格式

## Task Dependencies

- Task 1, 2 依赖 Task 0
- Task 3 依赖 Task 1, 2
- Task 4 依赖 Task 3
- Task 5, 6 依赖 Task 4

## Verification

- [ ] `npx tsc --noEmit`
- [ ] `npm run lint`
- [ ] `check_phase_symmetry` 通过
- [ ] `check_failure_path` 通过
- [ ] `check_spec_sync` 通过
- [ ] RAHS ≥ 90
