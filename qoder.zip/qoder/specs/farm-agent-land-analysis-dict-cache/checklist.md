# Checklist: Land Analysis DictCache

## Phase 1: 前置确认 + 肥力应急修复

- [ ] Task 0: moistureType dictType 已确认或静态映射已准备
- [ ] Task 1: fertilityLevel 兼容 number/string/null，测试数据不出现"未知"
- [ ] Task 1: MassifDTO.fertilityLevel 类型已改为 `number | string | null`
- [ ] Task 1: `AgentAuditPhase` 已新增 `LAND_FERTILITY_CALC`

## Phase 2: DictCache 模块

- [ ] Task 2: `dict-cache.ts` 可独立 import
- [ ] Task 2: lazy-init + Promise 锁防并发
- [ ] Task 2: TTL 惰性刷新或 setInterval 定时刷新
- [ ] Task 2: `registerStatic` 兜底方法可用
- [ ] Task 2: `AgentAuditPhase` 已新增 `DICT_CACHE_PRELOAD` + `DICT_CACHE_REFRESH`

## Phase 3: 接入 + soilTypeSummary

- [ ] Task 3: fertility 映射改为 DictCache，硬编码已删除
- [ ] Task 3: soilTypeSummary 输出 `"粘壤土 60%  壤土 40%"` 格式
- [ ] Task 3: `AgentAuditPhase` 已新增 `LAND_SOILTYPE_CALC` + `DICT_CACHE_FALLBACK`

## Phase 4: Prompt + 后处理

- [ ] Task 4: prompt 字段名 `soilType` → `soilTypeSummary`
- [ ] Task 4: 后处理强制覆盖 fertility + soilTypeSummary
- [ ] Task 4: Zod schema 校验通过

## Phase 5: 文档 + 验证

- [ ] Task 5: 接口文档新增枚举映射 + OpenAPI 差异记录
- [ ] Task 6: `tsc --noEmit` 通过
- [ ] Task 6: `npm run lint` 通过
- [ ] Task 6: [R] curl E2E 验证 fertility + soilTypeSummary 输出

## ADD 规则合规检查

- [ ] ADD-1 可观测性优先：5 个新增 Phase 覆盖全链路
- [ ] ADD-2 阶段标记对称：preload/refresh/fallback/fertility/soiltype 成对
- [ ] ADD-4 三通道输出：agentAudit 自动支持
- [ ] ADD-5 审计数据即业务数据：getLabel 失败走 fallback 记录 audit
- [ ] Plan/Spec 一致性：实现与 spec.md Requirements 一致
- [ ] Plan/Spec 修订记录：review 回流已记录

## 跨项目联调检查

- [T] DictCache 调用 Farm-Server `/system/dict-data/type` 接口格式正确
- [T] `ensureValidToken(0, "service")` 可获取有效 token
- [R] OPTIONS 预检 CORS 头包含 `X-Api-Key`
- [R] E2E curl 验证 land-analysis 响应格式
