# Land Analysis DictCache Spec

## Why

`land-analysis/route.ts` 中 fertility 计算因 `fertilityLevel` 类型不兼容（`number?` vs 实际返回 `null/中文文本`）导致输出 `"未知 100%"`；soilTypeSummary 完全缺失。枚举映射散落在各 route 硬编码，无统一数据源。

## What Changes

- **新建** `src/lib/farm-api/dict-cache.ts`：in-memory 字典缓存层，lazy-init + TTL 惰性刷新
- **修改** `src/app/api/h5/production-plan/land-analysis/route.ts`：fertility 兼容 number/string/null + 新增 soilTypeSummary 面积加权计算 + LLM 后处理强制覆盖
- **修改** `src/lib/farm-api/massif.ts`：`MassifDTO.fertilityLevel` 类型放宽为 `number | string | null`
- **修改** `src/agents/prompts/experts/land-analysis.ts`：字段名 `soilType` → `soilTypeSummary`
- **修改** `docs/.../地块基本信息管理接口文档.v2.md`：新增枚举值映射 + 与 OpenAPI 差异记录

## Impact

- Affected specs: 无
- Affected code: `land-analysis/route.ts`, `dict-cache.ts`(new), `massif.ts`, `land-analysis.ts`
- 父 Plan: `.qoder/plans/2026-06/24/farm-agent-land-analysis-dict-cache-plan-v1.md`
- 前置 Plan: `.qoder/plans/2026-06/23/farm-agent-ruifengyun-h5-api-plan-v2.md`
- 依赖: 无
- 后续依赖: 无

## Boundaries

- ✅ 创建 DictCache 模块（lazy-init + TTL 刷新 + registerStatic 兜底）
- ✅ 修复 fertility + 新增 soilTypeSummary（面积加权 + DictCache 查 label）
- ✅ LLM 后处理强制覆盖 soilInfo（不依赖 LLM 精度）
- ❌ 不迁移其他 route 的枚举映射（variety-recommend、cost-accounting 等）
- ❌ 不实现 OpenAPI 自动同步机制

## ADDED Requirements

### Requirement: 肥力输出修复

#### Scenario: fertilityLevel 为 null 时正常输出

- **WHEN** Farm-Server 返回部分地块 `fertilityLevel=null`
- **THEN** fertility 输出中该地块不计入百分比，不出现 `"未知"`

#### Scenario: fertilityLevel 为中文文本时正常解析

- **WHEN** Farm-Server 返回 `fertilityLevel="中"`
- **THEN** 直接从映射表匹配到 "中"，正确计算面积加权百分比

### Requirement: 土壤类型输出（新增）

#### Scenario: 多地块不同 moistureType

- **WHEN** 查询地块列表包含 `moistureType: "粘壤土"` 和 `moistureType: "壤土"`
- **THEN** soilTypeSummary 输出 `"粘壤土 60%  壤土 40%"` 格式（两空格分隔，面积加权）

### Requirement: DictCache 字典缓存层

#### Scenario: 首次调用时懒加载

- **WHEN** 首次 `DictCache.getLabel()` 调用
- **THEN** 自动触发 `preload()`，加 Promise 锁防并发

#### Scenario: Farm-Server 无目标 dictType

- **WHEN** `/system/dict-data/type?type=farm_massif_moisture_type` 返回空
- **THEN** 走 `registerStatic` 注册的静态映射兜底，不抛异常
