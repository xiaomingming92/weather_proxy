# Tasks: 交互点 Resume 修复

## Preconditions

- [x] `MemorySaver` checkpointer 已编译到 agent 图中
- [x] `resumeAgent` API 已存在（KB 矛盾在用）
- [x] `store.resumeWithChoice` 方法已存在

## Forbidden

- 禁止修改 `retrieval` / `reasoning` / `verdict` / `response` 节点
- 禁止修改 `routeByIntent` 路由逻辑
- 禁止引入新 npm 依赖
- 禁止修改 `MemorySaver` 为 `PostgresSaver`

## Phase 1: 后端 interrupt 改造

- [ ] Task 1.1: interactionPointDetection 节点增加 interrupt() 调用
  - [ ] 在返回 `pendingInteraction` 前插入 `interrupt({ interactionPoint })`
  - [ ] 图暂停后 /api/h5/agent/resume 端点收到 `Command(resume)` 从断点继续
  - [ ] 验证: `npx tsc --noEmit` farm-agent 通过

- [ ] Task 1.2: agents/index.ts 图编译适配
  - [ ] `routeByInteractionPoint` 路由函数识别 `pendingInteraction != null` → 调用 `interrupt()`
  - [ ] 保持不变：`pendingInteraction == null` → `verdict` 或 `response`
  - [ ] 验证: `npx tsc --noEmit` 通过

## Phase 2: 前端 resume 改造

- [ ] Task 2.1: agentChat.ts 交互点分支改为 resumeAgent
  - [ ] `sendMessage` 调用中交互点分支复用 `resumeWithChoice` 逻辑
  - [ ] 前端保持 `_streamingMsgId` + `_pausedForInterrupt` flag
  - [ ] 验证: `vue-tsc --noEmit` agrisynapse 通过

- [ ] Task 2.2: LlmChatView.vue 确认按钮绑定
  - [ ] `handleInteractionSelect` → `store.resumeWithChoice(label)` 
  - [ ] 验证: 前端兼容性检查通过

## Phase 3: 集成验证

- [ ] Task 3.1: tsc 全量编译
  - [ ] farm-agent `npx tsc --noEmit` 零错误
  - [ ] agrisynapse `vue-tsc --noEmit` 零错误

- [ ] Task 3.2: 端到端回归
  - [R] 交互点确认后 evidenceChain 不丢失
  - [R] KB 矛盾裁决流程不变
  - [R] session 重启后交互卡片不残留

## Task Dependencies

- Task 1.2 依赖 Task 1.1
- Task 2.2 依赖 Task 2.1
- Task 3 依赖 Task 1 + Task 2

## Verification

- [ ] `npx tsc --noEmit` farm-agent 零错误
- [ ] `vue-tsc --noEmit` agrisynapse 零错误
- [R] 用户选择交互点选项后，新回复包含上一轮 evidenceChain
