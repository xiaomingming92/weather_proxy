# Checklist: 交互点 Resume 修复

## Phase 1: 后端 interrupt 改造

- [x] interactionPointDetection 检测到交互点时调用 `interrupt()`
- [x] `routeByInteractionPoint` 识别 `pendingInteraction != null` → interrupt
- [x] `pendingInteraction == null` → verdict/response 路径不变
- [x] farm-agent `npx tsc --noEmit` 通过

## Phase 2: 前端 resume 改造

- [x] agentChat.ts 交互点分支复用 `resumeWithChoice`
- [x] `handleInteractionSelect` → `store.resumeWithChoice(label)`
- [x] `_pausedForInterrupt` flag 正确设置/清除
- [x] agrisynapse `vue-tsc --noEmit` 无新增错误（预存10个无关）

## Phase 3: 集成验证

- [T] farm-agent `npx tsc --noEmit` 零错误 ✅
- [T] agrisynapse `vue-tsc --noEmit` 无新增错误 ✅

## ADD 规则合规检查

- [x] ADD-1 可观测性优先（interrupt/resume 均有 agentAudit）
- [x] ADD-2 阶段标记对称（INTERACTION_INTERRUPT + INTERACTION_RESUME 成对）
- [x] ADD-4 三通道输出（复用 agentAudit 现有三通道）
- [x] Plan/Spec 一致性

## 回归检查

- [R] KB 矛盾裁决流程不受影响
- [R] 交互点确认后 evidenceChain 不丢失
- [R] session 重启后交互卡片不残留
