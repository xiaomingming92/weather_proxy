# 交互点 Resume 修复 Spec

## Why

普通交互点确认后走 `sendMessage`（新消息 → 新图 run），丢失上一轮 State（evidenceChain/reasoningPath），不符合 LangGraph `interrupt()` + `Command(resume)` 行业标准。

## What Changes

1. `agents/index.ts` — 图编译：新增 `routeByInteractionPoint` 条件边支持 `interrupt()` 暂停
2. `agents/nodes/interaction-point-detection.ts` — 检测到交互点时调用 LangGraph `interrupt()` 暂停图
3. `agrisynapse/store/modules/agentChat.ts` — 交互点确认改为 `resumeAgent` 而非 `sendMessage`
4. `agrisynapse/views/llm/components/LlmChatView.vue` — 确认按钮绑定 `resumeWithChoice`

## Impact

- Affected specs: 无
- Affected code: `agents/index.ts` / `agents/nodes/interaction-point-detection.ts` / `agentChat.ts` / `LlmChatView.vue`
- 父 Plan: `.qoder/plans/farm-agent-interaction-resume-fix-plan-v1.md`
- 依赖: `MemorySaver` checkpointer 已存在，`resumeAgent` API 已存在（KB 矛盾在用）
- 后续依赖: ACA 框架多专家交互点复用同一机制

## Boundaries

本次只允许实现：
- 后端 `interactionPointDetection` → `interrupt()` + `Command(resume)` 
- 前端交互点确认走 `resumeAgent` 通道
- KB 矛盾裁决不受影响（已走 `resumeAgent`）

本次禁止实现：
- `interrupt()` 的 `MemorySaver` 换 `PostgresSaver`（超出范围）
- 修改 KB 矛盾裁决流程

## ADDED Requirements

### Requirement: 交互点检测调用 interrupt

#### Scenario: 检测到交互点

- **WHEN** `interactionPointDetection` 返回 `pendingInteraction != null`
- **THEN** 图调用 `interrupt({ interactionPoint })` 暂停，State 保留在 `MemorySaver`

#### Scenario: 未检测到交互点

- **WHEN** `pendingInteraction == null`
- **THEN** 图正常进入 `verdict` → `response` → `__end__`

### Requirement: 交互点确认走 resumeAgent

#### Scenario: 用户选择交互点选项

- **WHEN** 用户点击交互卡片选项
- **THEN** 前端调用 `store.resumeWithChoice(label)` → `resumeAgent(threadId, label)`，后端收到 `Command(resume=label)` 从 interrupt 点继续

### Requirement: KB 矛盾不受影响

#### Scenario: KB 矛盾裁决流程

- **WHEN** KB 矛盾触发
- **THEN** 走原有 `resumeWithChoice` 流程不变
