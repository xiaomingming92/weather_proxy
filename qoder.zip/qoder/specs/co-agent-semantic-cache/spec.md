# 语义缓存 Spec

## Why

相同问题重复发送给 Agent 时每次都走完整 6 节点管线，浪费 LLM token 和响应延迟。需要一层语义级缓存：相同意图 + 相似问题 → 直接返回缓存结果。知识库文档变更后，旧缓存应自动失效（Generation-based 淘汰）。

## What Changes

- 新建 `src/services/semantic-cache.ts`：SimpleSemanticCache 类（LRU + 按意图 TTL + kbGeneration 版本淘汰）+ buildCacheKey() + bumpKbGeneration()
- stream/route.ts 集成缓存查询/存储 + 命中时模拟流式输出
- knowledge-indexer.ts 索引完成后调用 bumpKbGeneration()

## Impact

- Affected specs: 无
- Affected code: `src/services/semantic-cache.ts`（新建）, `src/app/api/agent/chat/stream/route.ts`（修改）, `src/services/knowledge-indexer.ts`（修改）
- 父 Plan: [co-agent-simplified-v1.md](../../documents/co-agent-simplified-v1.md)
- 依赖: 第4轮(领域集成) — 需要 stream/route.ts 中已有的管线架构
- 后续依赖: 第6轮(演化闭环)

~~## ADDED Requirements~~ → **[2026-06-03 修订: review 后拆分为 ADDED + Boundaries 两节，新增 6 个 Requirement，修正 2 个已有 Requirement]**

## Boundaries

**[2026-06-03 新增]**

本次只允许实现：基本缓存机制（get/set + 三层淘汰 + 模拟流式输出 + kbGeneration bump）。
本次禁止实现：TTL 自适应（第6轮）、cateId 级精细淘汰（第6轮）、turnHistory 记录（第6轮）、策略参数自适应（第6轮）。

## ADDED Requirements

### Requirement: 缓存键构建

~~缓存键 SHALL 由四元组组成~~ → **[2026-06-03 修订]** 缓存键 SHALL 由三元组组成：

- `normalizedQueryHash`：用户消息标准化后（去标点+去空格+小写化）的 SHA256 前 16 位
  → **[2026-06-03 修订: 原 `normalizedQuery` 字段改为 `normalizedQueryHash`，新增独立 `normalizeQuery` 函数]**
- `intentHash`：意图类型的 hash 前 8 位
- `activeExpertsHash`：排序后的激活专家 ID 列表（逗号连接）的 hash 前 8 位
- `compositeKey`：`${normalizedQueryHash}:${intentHash}:${activeExpertsHash}`

~~- `kbGeneration`：当前全局 kbGeneration 版本号（知识库变更后自动淘汰）~~
~~- `compositeKey`：`${normalizedQuery}:${intentHash}:${activeExperts}:${kbGeneration}`~~ → **[2026-06-03 修订] `kbGeneration` 不进 key，作为 `CacheEntry` 出生版本号字段，在 `get()` 中通过 entry 字段比对执行惰性淘汰。** 理由：若 kbGeneration 在 key 中，版本号 bump 后旧 key 直接查询不到（key miss），与 TTL 过期混为一谈。移入 entry 字段后，Layer 1（Generation 淘汰）和 Layer 2（TTL 淘汰）的职责边界清晰。

#### Scenario: 不同专家激活不生误命中

**[2026-06-03 新增]**

- **WHEN** 用户激活 `crop_compare` 发送问题 X
- **AND** 后续恢复 `pest_risk` 发送相同问题 X
- **THEN** compositeKey 不同 → 不会命中前面的缓存 → 走完整管线生成对应专家的结果

### Requirement: 查询文本标准化

**[2026-06-03 新增]**

`normalizeQuery(text: string): string` SHALL 执行以下标准化流程：
1. 去除标点符号（中文标点 + 英文标点，含 `，。！？、；：""''（）《》` 和 `,.;:!?"'()`）
2. 去除多余空白（`\s+` → 单空格）
3. `.trim()` 首尾空白
4. `.toLowerCase()`

标准化后对结果做 SHA256，取前 16 位作为 `normalizedQueryHash`。

### Requirement: CacheEntry 数据结构

**[2026-06-03 新增]**

每条缓存条目 SHALL 包含以下字段：

```typescript
interface CacheEntry {
  responseContent: string           // 完整回复文本（用于模拟流式输出）
  displayContent: Record<string, unknown>  // structured_output 数据
  createdAt: number                 // Date.now() 时间戳
  ttl: number                       // TTL 秒数（按意图分档）
  hitCount: number                  // 命中次数（初始化 0，每次 get() 命中 +1）
  sourceTraceId: string             // 原始请求 traceId（用于 traceability）
  kbGeneration: number              // 出生版本号 — get() 与全局 getKbGeneration() 比对
  intent: string                    // 意图类型
}
```

### Requirement: 三层淘汰策略

缓存 SHALL 使用三层淘汰：

**Layer 1 — Generation-based**：每个 CacheEntry 写入时记录 `kbGeneration`（出生版本）。全局 `kbGeneration` 在知识库索引完成后递增。`get()` 时若 `entry.kbGeneration < kbGeneration`，惰性淘汰，O(1) 操作。

#### Scenario: 知识库变更后缓存失效

- **WHEN** 上传新文档后 kbGeneration 从 3 变为 4
- **AND** 用户发送与之前相同的问题
- **THEN** 旧缓存条目 kbGeneration=3 < current=4 → 淘汰 → 走完整管线

**Layer 2 — TTL-based**：每个 CacheEntry 记录 `createdAt` 和 `ttl`（秒）。`get()` 时若 `Date.now() - createdAt > ttl * 1000`，过期淘汰。

TTL 按意图类型区分：
| intent | TTL（秒） |
|--------|----------|
| chat | 3600 |
| question | 1800 |
| analysis | 300 |
| planning | 600 |
| decision | 600 |
| creation | 300 |
| modification | 300 |
| default | 300 |

#### Scenario: TTL 过期

- **WHEN** analysis 意图缓存已超过 300 秒
- **THEN** 下次 get() 返回 null → 重新走完整管线

**Layer 3 — LRU**：缓存容量上限 MAX_CACHE_SIZE=200。超出时删除 `createdAt` 最旧的条目。

#### Scenario: LRU 淘汰

- **WHEN** 缓存条目数超过 200
- **THEN** 最旧的条目被逐出

### Requirement: 缓存插入点与查询时序

**[2026-06-03 新增]**

~~管线启动前查询缓存（MODIFIED Requirements 所述）不可行：intent 由 intention 节点产出，管线启动前未知。~~ → 缓存查询 SHALL 在 `intention` 节点完成之后、`retrieval` 节点之前执行。

具体规则：
- `intention` → `thinkingLevel === "fast"` → 直接走 response（跳过缓存，fast 通道不涉及 RAG）
- `intention` → `thinkingLevel === "deep"` → 构建 cacheKey → 查询缓存
  - HIT → 模拟流式输出 → 直接跳到 response 节点（跳过 retrieval + reasoning + interactionPoint + verdict）
  - MISS → 正常进入 retrieval 节点
- 管线完成后 → 如果 MISS（走了完整管线）→ `semanticCache.set(cacheKey, entry)`（fire-and-forget）

#### Scenario: deep 通道缓存命中

- **WHEN** intention 判定 thinkingLevel=deep
- **AND** 构建 cacheKey 后 semanticCache.get() 命中
- **THEN** SSE 首事件为 `cache_hit`
- **AND** token 事件以 ~3 字符/片的速度推送
- **AND** 总耗时 ~1.5s
- **AND** 跳过 retrieval、reasoning、interactionPointDetection、verdict 节点

#### Scenario: fast 通道不查缓存

- **WHEN** intention 判定 thinkingLevel=fast
- **THEN** 不构建 cacheKey → 不查缓存 → 直通 response

### Requirement: 缓存命中模拟流式输出

缓存命中时 SHALL 不直接返回完整结果，而是模拟正常的 SSE token 流式输出：
- 首先推送 `cache_hit` 事件（含 sourceTraceId + cachedAt，前端可展示 ⚡ 缓存响应）
- 按 chunkSize=3 分片推送 token 事件
- 目标总耗时约 1.5s（自适应延迟）
- 每个分片间隔 ≥ 5ms
- 最后推送 ~~`structured_output` 事件（与正常流程一致）~~ → **[2026-06-03 修订]** `done` 事件（含 displayContent 数据，与正常流程的 done 事件结构一致）

#### Scenario: 缓存命中用户体验

- **WHEN** 发送与第1次相同的问题
- **THEN** SSE 首事件为 `cache_hit`
- **AND** token 事件以 ~3 字符/片的速度推送
- **AND** 总耗时在 0.5-1.5s 之间
- **AND** 最终推送 done 事件（与正常流程一致）

### Requirement: 缓存不阻塞管线

缓存写入 `semanticCache.set()` SHALL 不阻塞 Agent 响应返回。写入失败 SHALL 不影响响应正常发送。

→ **[2026-06-03 修订]** 实现方式：管线完成后 `set()` 通过 `Promise.resolve().then()` 或独立微任务执行，try-catch 包裹。

### Requirement: 全局 kbGeneration 管理

`bumpKbGeneration()` 在 knowledge-indexer 索引完成后调用，全局版本号 +1。`getKbGeneration()` 返回当前全局版本号。~~（初始值未定义）~~ → **[2026-06-03 修订]** 初始值为 1。

### Requirement: 缓存淘汰管理

**[2026-06-03 新增]**

`invalidate(pattern: RegExp): number` SHALL 按正则匹配 compositeKey 批量淘汰缓存条目，返回淘汰数量。用于管理操作（如按特定 intent 清空缓存）。

### Requirement: 缓存统计

**[2026-06-03 新增]**

`getStats(): CacheStats` SHALL 返回当前缓存状态：

```typescript
interface CacheStats {
  size: number           // 当前条目数
  maxSize: number        // 容量上限
  hitCount: number       // 累计命中次数
  missCount: number      // 累计未命中次数
  evictedByGeneration: number  // kbGeneration 淘汰数
  evictedByTTL: number   // TTL 淘汰数
  evictedByLRU: number   // LRU 淘汰数
}
```

每次 `get()` 更新 `hitCount`（命中）或 `missCount`（未命中），每次淘汰更新对应计数器。

## MODIFIED Requirements

### Requirement: stream/route.ts 集成缓存

~~stream/route.ts SHALL 在管线启动前查询语义缓存：~~
~~1. 构建 cacheKey = buildCacheKey(userMessage, intent, projectId, threadId)~~
~~2. cacheEntry = semanticCache.get(cacheKey)~~
~~3. HIT → 模拟流式输出 → return（跳过 Agent 管线）~~
~~4. MISS → 继续执行 Agent 管线~~
~~5. 管线完成后 → semanticCache.set(cacheKey, entry)（fire-and-forget）~~

→ **[2026-06-03 修订: 缓存插入点改为管线内]**

stream/route.ts SHALL 在管线中集成语义缓存（不在管线启动前，而在 intention 之后）：

1. Agent 管线正常启动（intention → 获取 intent + activeExperts）
2. routeByIntent 分流后，deep 通道在进入 retrieval 之前：
   - 构建 cacheKey = ~~buildCacheKey(userMessage, intent, projectId, threadId)~~ → `buildCacheKey(query, intent, activeExpertIds)`
   - cacheEntry = semanticCache.get(cacheKey)
   - HIT → 模拟流式输出（cache_hit + token 分片 + done）→ return（跳过后续节点）
   - MISS → 继续执行 retrieval 节点
3. MISS 时管线完成后 → `semanticCache.set(cacheKey, entry)`（fire-and-forget）

## REMOVED Requirements

无
