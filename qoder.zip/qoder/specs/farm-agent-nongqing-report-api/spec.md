# 农情报告 API（总体态势概览 + 日常巡检报告）Spec

## Why

IoT 物联感知页面（`/wrnc/06/iot`）的"农情态势概览"模块和"日常巡检报告"模块目前数据硬编码在前端 demo 中，无后端 API。需要新建 2 个 REST API 端点，为小程序端提供结构化数据支撑，明天对接真实业务流程。

## What Changes

1. 新增 `POST /api/h5/nongqing/overview` — 返回总体态势概览完整数据（种植计划头部 + 生育进度 + 总体生产评价 + 关键发现 + 四情趋势分析 + 风险复盘）
2. 新增 `POST /api/h5/nongqing/daily-report` — 返回日常巡检报告（normal/warning 双状态模板，含当前情况 + 今日建议/风险预警 + 处置方案 + 判断依据）
3. 在 `src/app/api/h5/types/dto.ts` 追加 OverviewData + DailyReportData 类型定义
4. 在 `src/app/api/h5/types/schemas.ts` 追加 overviewSchema + dailyReportSchema Zod 校验
5. 在 `src/lib/agent-audit-logger.ts` 的 AgentAuditPhase 新增 `H5_NONGQING_OVERVIEW` + `H5_NONGQING_DAILY_REPORT`

## Impact

- Affected specs: 无
- Affected code:
  - `src/app/api/h5/nongqing/overview/route.ts` (CREATED)
  - `src/app/api/h5/nongqing/daily-report/route.ts` (CREATED)
  - `src/app/api/h5/types/dto.ts` (MODIFIED)
  - `src/app/api/h5/types/schemas.ts` (MODIFIED)
  - `src/lib/agent-audit-logger.ts` (MODIFIED)
- 父 Plan: `.qoder/plans/farm-agent-nongqing-report-api-plan-v1.md`
- 依赖: H5 API v2 认证基础设施（`h5-auth-gateway` + `ServiceAccount`）
- 后续依赖: 阶段2 LLM 智能分析、阶段3 Farm-Server 真实数据

## Boundaries

本次只允许实现：
- 2 个 API 端点（overview + daily-report）
- Demo 假数据（与 80retros.com demo 页面 1:1 对齐）
- DTO 类型 + Zod 校验
- 审计阶段注册 + 审计植入

本次禁止实现：
- LLM 智能分析逻辑（阶段2）
- Farm-Server 传感器数据聚合（阶段3）
- 前端页面渲染
- 数据库模型变更

## ADDED Requirements

### Requirement: 总体态势概览端点

#### Scenario: 正常请求返回完整概览数据

- **WHEN** 客户端 POST `/api/h5/nongqing/overview` 携带有效 X-Api-Key 和 projectId
- **THEN** 返回 `{ code: 200, data: OverviewData, meta: { traceId, durationMs, projectId } }`

#### Scenario: 缺少 projectId

- **WHEN** 客户端 POST 请求未传 projectId
- **THEN** 返回 `{ code: 400, message: "缺少 projectId" }`

#### Scenario: 无认证凭证

- **WHEN** 客户端未携带 X-Api-Key 和 X-Session-Id
- **THEN** 返回 `{ code: 401, message: "..." }`

### Requirement: 日常巡检报告端点

#### Scenario: 正常请求返回巡检报告（normal 状态）

- **WHEN** 客户端 POST `/api/h5/nongqing/daily-report` 携带有效认证和 projectId
- **THEN** 返回 `{ code: 200, data: DailyReportData(status="normal"), meta }`，包含 currentStatus + todayAdvice + analysisBasis

#### Scenario: 缺少 projectId

- **WHEN** 客户端 POST 请求未传 projectId
- **THEN** 返回 `{ code: 400 }`

#### Scenario: 无认证凭证

- **WHEN** 客户端未携带认证凭证
- **THEN** 返回 `{ code: 401 }`

### Requirement: DTO 集中管理

#### Scenario: 类型定义位置正确

- **WHEN** 新增 OverviewData 或 DailyReportData 类型
- **THEN** 类型必须定义在 `src/app/api/h5/types/dto.ts`，Zod Schema 必须在 `src/app/api/h5/types/schemas.ts`

### Requirement: 审计植入

#### Scenario: 审计日志可查

- **WHEN** overview 或 daily-report 端点被调用
- **THEN** agent-audit-logger 输出含 `H5_NONGQING_OVERVIEW` 或 `H5_NONGQING_DAILY_REPORT` phase 的日志
