# Checklist: 农情报告 API（总体态势概览 + 日常巡检报告）

## Phase 1: 审计阶段定义 + DTO/Schema

- [ ] AgentAuditPhase 已新增 `H5_NONGQING_OVERVIEW` 和 `H5_NONGQING_DAILY_REPORT`
- [ ] `dto.ts` 包含 OverviewData 接口（planHeader + growthProgress + productionEvaluation + keyFindings + trendAnalysis + riskReview）
- [ ] `dto.ts` 包含 DailyReportData 接口（status + currentStatus + todayAdvice? + riskWarning? + solutionPrescription? + analysisBasis）
- [ ] `schemas.ts` 包含 overviewSchema（Zod object）
- [ ] `schemas.ts` 包含 dailyReportSchema（Zod object/union）

## Phase 2: API 端点实现

- [ ] `overview/route.ts` 存在且实现 POST 方法
- [ ] overview 端点认证裁决调用 `resolveH5AuthGateway`
- [ ] overview 端点校验 projectId 必填
- [ ] overview 端点假数据与 demo 页面对齐
- [ ] overview 端点 Zod safeParse 校验
- [ ] overview 端点审计植入 `agentAudit("H5_NONGQING_OVERVIEW", ...)`
- [ ] `daily-report/route.ts` 存在且实现 POST 方法
- [ ] daily-report 端点认证裁决调用 `resolveH5AuthGateway`
- [ ] daily-report 端点校验 projectId 必填
- [ ] daily-report 端点假数据与需求文档 normal 模板对齐
- [ ] daily-report 端点 Zod safeParse 校验
- [ ] daily-report 端点审计植入 `agentAudit("H5_NONGQING_DAILY_REPORT", ...)`

## Phase 3: 编译验证

- [T] `npx tsc --noEmit` 零错误
- [T] `npm run lint` 无新增问题

## ADD 规则合规检查

- [ ] ADD-1 可观测性优先（审计植入点齐全）
- [ ] ADD-2 阶段标记对称（try/catch/finally 均有审计）
- [ ] ADD-4 三通道输出（复用 agentAudit 三通道）
- [ ] ADD-5 审计数据即业务数据（traceId + durationMs 记录）
- [ ] Plan/Spec 一致性（代码实现与文档定义一致）
- [ ] Plan/Spec 修订记录（如有修订已记录审计日志）

## 跨项目联调检查

### E2E curl

- [R] curl `POST /api/h5/nongqing/overview` 有效凭证返回 200 + 完整 OverviewData JSON
- [R] curl `POST /api/h5/nongqing/daily-report` 有效凭证返回 200 + 完整 DailyReportData JSON
- [R] curl 无 X-Api-Key 两个端点返回 401
- [R] curl 缺少 projectId 两个端点返回 400
- [R] OPTIONS 预检 CORS 头正确
