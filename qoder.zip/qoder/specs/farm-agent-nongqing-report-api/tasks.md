# Tasks: 农情报告 API（总体态势概览 + 日常巡检报告）

## Preconditions

- [ ] H5 API v2 认证基础设施可用（`h5-auth-gateway` + `ServiceAccount` 表）
- [ ] `src/app/api/h5/types/dto.ts` 和 `schemas.ts` 存在且可编辑
- [ ] `src/lib/agent-audit-logger.ts` 存在且 `AgentAuditPhase` 可扩展

## Forbidden

- 禁止修改 `src/caijuehub/strategies/h5-auth-gateway.ts`
- 禁止修改 Prisma schema
- 禁止新建独立的 DTO 文件（必须追加到现有 types/dto.ts 和 types/schemas.ts）
- 禁止引入新的 npm 依赖
- 禁止实现 LLM 分析逻辑或 Farm-Server 数据聚合

## Phase 1: 审计阶段定义 + DTO/Schema

- [ ] Task 1.1: 扩展 AgentAuditPhase 联合类型
  - [ ] 在 `src/lib/agent-audit-logger.ts` 的 `AgentAuditPhase` 末尾新增 `"H5_NONGQING_OVERVIEW"` 和 `"H5_NONGQING_DAILY_REPORT"`
  - [ ] 验证: `tsc --noEmit` 无新增错误

- [ ] Task 1.2: DTO 类型追加
  - [ ] 在 `src/app/api/h5/types/dto.ts` 末尾追加 `// ──── 农情态势 ────` 分区
  - [ ] 新增 `OverviewData` 接口（含 planHeader, growthProgress, productionEvaluation, keyFindings, trendAnalysis, riskReview）
  - [ ] 新增 `DailyReportData` 接口（含 status, reportDate, crop, growthStage, currentStatus, todayAdvice?, riskWarning?, solutionPrescription?, analysisBasis）
  - [ ] 验证: `tsc --noEmit` 通过

- [ ] Task 1.3: Zod Schema 追加
  - [ ] 在 `src/app/api/h5/types/schemas.ts` 末尾追加 `// ──── 农情态势 ────` 分区
  - [ ] 新增 `overviewSchema`（与 OverviewData 结构对齐）
  - [ ] 新增 `dailyReportSchema`（与 DailyReportData 结构对齐，使用 z.discriminatedUnion 或 z.union 处理 normal/warning 双状态）
  - [ ] 验证: `tsc --noEmit` 通过

## Phase 2: API 端点实现

- [ ] Task 2.1: 总体态势概览端点
  - [ ] 新建 `src/app/api/h5/nongqing/overview/route.ts`
  - [ ] 实现 POST 方法：认证裁决 → 解析 body(projectId) → 构建假数据 → Zod safeParse → 返回 H5ApiResponse
  - [ ] PREFIX: `[H5-NONGQING-OVERVIEW]`，traceId: `h5_nq_overview_<uuid>`
  - [ ] 审计植入: `agentAudit("H5_NONGQING_OVERVIEW", ...)`
  - [ ] 假数据内容与 demo `80retros.com/wrnc/06/overall` 页面 1:1 对齐
  - [ ] 验证: `tsc --noEmit` 通过

- [ ] Task 2.2: 日常巡检报告端点
  - [ ] 新建 `src/app/api/h5/nongqing/daily-report/route.ts`
  - [ ] 实现 POST 方法：认证裁决 → 解析 body(projectId) → 构建 normal 状态假数据 → Zod safeParse → 返回 H5ApiResponse
  - [ ] PREFIX: `[H5-NONGQING-DAILY-REPORT]`，traceId: `h5_nq_report_<uuid>`
  - [ ] 审计植入: `agentAudit("H5_NONGQING_DAILY_REPORT", ...)`
  - [ ] 假数据内容与需求文档 §1.2 正常情况 JSON 示例对齐
  - [ ] 验证: `tsc --noEmit` 通过

## Phase 3: 编译验证

- [ ] Task 3.1: 全局编译检查
  - [ ] `npx tsc --noEmit` 零错误
  - [ ] 确认无 lint 问题

## Task Dependencies

- Task 1.2 和 1.3 可并行
- Task 2.1 依赖 Task 1.1 + Task 1.2 + Task 1.3
- Task 2.2 依赖 Task 1.1 + Task 1.2 + Task 1.3
- Task 3.1 依赖 Task 2.1 + Task 2.2

## Verification

- [ ] `npx tsc --noEmit` 零错误
- [ ] `npm run lint` 无新增问题
- [R] curl overview 端点返回正确 JSON
- [R] curl daily-report 端点返回正确 JSON
- [R] 无 X-Api-Key 返回 401
- [R] 缺少 projectId 返回 400
