# Checkpointer PostgreSQL 迁移 Spec

## Why

PM2 重启 / 部署更新导致 `MemorySaver` 中所有中断 thread 的 checkpoint 状态丢失，调用方 resume 时报 `"u is not async iterable"` 错误。需将 checkpointer 从进程内存迁移至 PostgreSQL 持久化存储。

## What Changes

| 文件 | 操作 | 内容 |
|------|------|------|
| `package.json` | MODIFY | 新增依赖 `@langchain/langgraph-checkpoint-postgres@^1.0.4` |
| `src/lib/checkpointer.ts` | CREATE | checkpointer 工厂模块：PostgresSaver 连接池 + MemorySaver fallback |
| `src/agents/index.ts` | MODIFY | 替换 `new MemorySaver()` 为工厂函数调用 |

## Impact

- **Affected specs**: 无
- **Affected code**: `src/agents/index.ts:231`, `src/lib/checkpointer.ts`（新建）
- **父 Plan**: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-plan.md`
- **依赖**: 无上游依赖
- **后续依赖**: 无——checkpointer 替换对 LangGraph API 透明

## Boundaries

**本次只允许实现**：
- 安装 `@langchain/langgraph-checkpoint-postgres`
- 新建 `src/lib/checkpointer.ts`，封装 `PostgresSaver` 连接池和 `MemorySaver` fallback
- 修改 `src/agents/index.ts:231`，替换 checkpointer 实例化方式
- 确保 PostgreSQL 不可用时自动降级到 MemorySaver + 日志告警

**本次禁止实现**：
- 修改 agent 节点的 `interrupt()` / `resume` 逻辑
- 修改 `streamAgent()` / `runAgent()` 调用方式
- 修改 Prisma schema（LangGraph 自动建表）
- checkpoint 过期清理策略（P2，后续独立 Plan）
- 修改 SSE 流式协议或 H5 API 合约
- 使用非 ESM 模块加载方式（如 `require()`）引入 `src/lib/checkpointer.ts`——该模块依赖顶层 await

## Requirements

### Requirement: PostgreSQL checkpointer 持久化

系统 SHALL 使用 PostgreSQL 作为 LangGraph checkpointer 后端，替代 `MemorySaver`。

#### Scenario: 正常启动
- **WHEN** farm-agent 启动且 PostgreSQL 可用
- **THEN** checkpointer 使用 `PostgresSaver`，checkpoint 数据写入 PostgreSQL `langgraph_checkpoints` 表

#### Scenario: PostgreSQL 不可用降级
- **WHEN** farm-agent 启动但 PostgreSQL 连接失败
- **THEN** checkpointer 自动降级为 `MemorySaver`，并输出 `[CHECKPOINTER]` 前缀的日志告警

#### Scenario: 部署重启后 resume
- **WHEN** 对话在 `interrupt()` 处暂停，PM2 restart 后调用 resume 端点
- **THEN** checkpoint 从 PostgreSQL 恢复，SSE 流正常继续，不报 `"u is not async iterable"`

#### Scenario: 新对话无影响
- **WHEN** 发起全新对话（无 checkpoint 依赖）
- **THEN** 行为与 MemorySaver 时完全一致
