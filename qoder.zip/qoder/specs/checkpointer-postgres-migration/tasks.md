# Tasks: Checkpointer PostgreSQL 迁移

## Preconditions

- [ ] PostgreSQL 服务运行中（`npm run db:status`）
- [ ] `DATABASE_URL` 在 `.env.production` 中已配置
- [ ] `@langchain/langgraph-checkpoint@^1.0.2` 已安装

## Forbidden

- 禁止修改 `src/agents/index.ts` 中 `interrupt()` / `resume` 相关逻辑
- 禁止修改 `streamAgent()` / `runAgent()` 函数签名
- 禁止修改 Prisma schema 文件
- 禁止引入新的数据库连接库（复用已有 `pg` 包）

---

- [ ] Task 1: 安装 `@langchain/langgraph-checkpoint-postgres` 依赖
  - [ ] `npm install @langchain/langgraph-checkpoint-postgres@^1.0.4`
  - [ ] 验证 `package.json` 中依赖已添加
  - [ ] 验证 `node_modules/@langchain/langgraph-checkpoint-postgres` 存在

- [ ] Task 2: 新建 `src/lib/checkpointer.ts` checkpointer 工厂模块
  - [ ] 从 `DATABASE_URL` 环境变量构造 PostgreSQL 连接配置
  - [ ] 创建 `PostgresSaver` 实例（含连接池）
  - [ ] 实现 `MemorySaver` fallback 路径（try-catch + 日志告警）
  - [ ] 导出 `createCheckpointer()` 工厂函数
  - [ ] 验证 `npx tsc --noEmit` 通过

- [ ] Task 3: 修改 `src/agents/index.ts` 替换 checkpointer
  - [ ] 移除 `import { StateGraph, MemorySaver }` 中的 `MemorySaver`（如不再直接使用）
  - [ ] 新增 `import { createCheckpointer } from "@/lib/checkpointer"`
  - [ ] 第 231 行 `const checkpointer = new MemorySaver()` 替换为 `const checkpointer = await createCheckpointer()`
  - [ ] 注意：`workflow.compile({ checkpointer })` 调用点不变
  - [ ] 验证 `npx tsc --noEmit` 通过

- [ ] Task 4: 端到端验证
  - [ ] 启动 farm-agent → 发起对话 → 产生 `interrupt()` → 检查 PostgreSQL `langgraph_checkpoints` 表有记录
  - [ ] `pm2 restart farm-agent` → 调用 resume 端点 → SSE 流正常恢复
  - [ ] 模拟 PostgreSQL 不可用 → 验证 MemorySaver 降级 + 日志告警

## Task Dependencies

```
Task 1 ──→ Task 2 ──→ Task 3 ──→ Task 4
```

- Task 2 依赖 Task 1（需要 postgres 包）
- Task 3 依赖 Task 2（需要工厂函数）
- Task 4 依赖 Task 3（需要完整实现）

## Verification

- [ ] `npx tsc --noEmit`
- [ ] `npm run lint`
- [ ] PostgreSQL `langgraph_checkpoints` 表自动创建
- [ ] 重启后 resume 正常（不再报 `"u is not async iterable"`）
