# Checklist: Checkpointer PostgreSQL 迁移

## Task 1: 安装依赖

- [ ] `@langchain/langgraph-checkpoint-postgres@^1.0.4` 已添加到 `package.json` dependencies
- [ ] `node_modules/@langchain/langgraph-checkpoint-postgres/dist/` 存在

## Task 2: checkpointer 工厂模块

- [ ] `src/lib/checkpointer.ts` 文件已创建
- [T] 从 `process.env.DATABASE_URL` 解析 PostgreSQL 连接参数
- [T] `PostgresSaver` 实例化使用连接池（非单连接）
- [T] PostgreSQL 连接失败时 catch 异常，降级为 `new MemorySaver()`
- [T] 降级时输出 `console.warn("[CHECKPOINTER] PostgreSQL 不可用，降级为 MemorySaver")`
- [T] 导出 `createCheckpointer(): Promise<PostgresSaver | MemorySaver>`

## Task 3: agents/index.ts 替换

- [T] 移除 `MemorySaver` 的顶部 import（如无其他使用）
- [T] 新增 `import { createCheckpointer } from "@/lib/checkpointer"`
- [T] 第 231 行替换为 `const checkpointer = await createCheckpointer()`
- [T] `workflow.compile({ checkpointer })` 调用不变

## Task 4: 端到端验证

- [R] PostgreSQL `langgraph_checkpoints` 表在首次对话后自动创建
- [R] `pm2 restart farm-agent` 后 resume 端点正常恢复 SSE 流
- [R] 模拟 PostgreSQL 不可用时 MemorySaver 降级生效

## ADD 规则合规检查

- [ ] ADD-1 可观测性优先：PostgreSQL 连接状态有日志输出（成功/降级）
- [ ] ADD-2 阶段标记对称：无新增审计阶段（纯基础设施改造）
- [ ] ADD-4 三通道输出：console 日志 + 文件日志 + AuditLog 表（降级事件记录）
- [ ] ADD-5 审计数据即业务数据：checkpoint 本身即为业务关键数据
- [ ] Plan/Spec 一致性：代码实现与文档定义一致
- [ ] Plan/Spec 修订记录：如有修订已记录审计日志

## 跨项目联调检查

> 本变更不涉及跨项目联调（纯后端基础设施，LangGraph API 透明）。

### 格式契约

- [T] checkpointer 替换对 `agent.stream()` / `agent.invoke()` 的输入输出类型无影响

### 环境变量

- [T] `DATABASE_URL` 在 `.env.production` 中已配置（`postgresql://farm_admin:farm_secure_pass_2024@localhost:5433/farm_agent?schema=public`）
- [T] `pg` 包已在 `package.json` dependencies 中（v8.20.0）

### API 选择

- [T] 使用 `@langchain/langgraph-checkpoint-postgres` 的 `PostgresSaver`（官方适配器）
- [T] LangGraph `compile({ checkpointer })` 接口不变
