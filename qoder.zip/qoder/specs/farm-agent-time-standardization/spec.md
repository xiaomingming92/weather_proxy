# 时间规范化治理 Spec

## Why

`src/lib/time.ts` 已定义 `now()`（UTC）和 `reportNow()`（本地+8）两个统一时间函数，但全局 80+ 处绕过该模块直接调用 `new Date().toISOString()` 或 `new Date()`。导致：(1) 日志/DB 时间失去统一管理入口；(2) Report 使用 UTC 而非北京时间；(3) DB→前端时区转换缺失，用户看到的时间错误。

## What Changes

- **扩展** `src/lib/time.ts`：新增 `nowDate()`（返回 Date 对象供 Prisma DateTime）、`fromUTC()`/`toLocalISO()`/`fromUTCToDate()`（UTC→本地时区转换）
- **替换** ~25 个 Logger/lib 文件中 `new Date().toISOString()` → `now()`
- **替换** ~10 个 Service 文件中 JSON metadata `new Date().toISOString()` → `now()`
- **替换** ~6 个 Service/Route 文件中 `new Date()` → `nowDate()`（Prisma DateTime 字段）
- **替换** ~3 个 Report/通知文件中时间戳 → `reportNow()`
- **替换** ~5 个 Agent 节点文件中 `new Date().toISOString()` → `now()`
- **替换** ~13 个 API Route 文件中 `new Date().toISOString()` / `new Date()` → `now()` / `nowDate()`
- **替换** ~3 个 Frontend Store 文件中 `new Date().toISOString()` → `now()`
- **接入** 4 个 UI 组件的 DB→前端时区转换（`fromUTC()`）
- **总计** ~55 个文件，~85 处修改

## Impact

- Affected specs: 无
- Affected code: 55 个文件（详见 Plan §4 及 ADD-7 审计策略表）
- 父 Plan: `.qoder/plans/2026-07/01/farm-agent-time-standardization-plan-v1.md`
- 依赖: 无（独立规范改动）
- 后续依赖: 无

## Boundaries

本次只允许实现：
- `src/lib/time.ts` 函数扩展
- 所有 `new Date().toISOString()` → `now()` 或 `reportNow()` 替换
- 所有 Prisma DateTime `new Date()` → `nowDate()` 替换
- DB→前端时区转换接入

本次禁止实现：
- ESLint 规则配置（后续单独 Plan）
- 其他时间库（dayjs/moment/date-fns）的引入
- 时区配置系统化（当前仅支持 +8，多时区后续扩展）

## ADDED Requirements

### Requirement: 时间生成统一入口

所有时间戳生成必须通过 `src/lib/time.ts` 的函数，禁止裸 `new Date().toISOString()` 或 `new Date()`。

#### Scenario: 日志时间戳生成

- **WHEN** 任何 Logger 的 `formatMessage` 函数需要时间戳
- **THEN** 使用 `import { now } from "@/lib/time"` 代替 `new Date().toISOString()`

#### Scenario: DB JSON metadata 时间写入

- **WHEN** Service 层向 DB JSON 字段写入时间（如 `lastSync`、`classifiedAt`）
- **THEN** 使用 `now()` 代替 `new Date().toISOString()`

#### Scenario: Prisma DateTime 字段赋值

- **WHEN** Prisma `create`/`update` 的 `data` 对象中需要当前时间
- **THEN** 使用 `nowDate()` 代替 `new Date()`

#### Scenario: Report 人类可读时间

- **WHEN** 生成面向中国用户的 Report 文档或通知消息
- **THEN** 使用 `reportNow()` 代替 `new Date().toISOString()`

### Requirement: Report/通知人类可读时间统一

面向中国用户的所有输出必须使用本地时区（+8）。

#### Scenario: 报告生成时间

- **WHEN** `report-generator.ts` 生成 MD/PDF/DOCX/XLSX 报告
- **THEN** 所有"生成时间"字段使用 `reportNow()` 代替 `new Date().toISOString()`

#### Scenario: 企业微信通知

- **WHEN** `wecom.ts` 发送告警通知
- **THEN** 时间戳使用 `reportNow()`（含中文格式化）

#### Scenario: 农情日报

- **WHEN** `daily-report/route.ts` 设置 `reportDate`
- **THEN** 使用 `reportNow()` 代替 `new Date().toLocaleDateString("zh-CN")`

### Requirement: Service 层 DB 写入时间统一

11 个 Service 文件中 JSON metadata 和 Prisma DateTime 字段必须使用统一时间入口。

#### Scenario: Knowledge sync metadata 时间戳

- **WHEN** `knowledge-sync.ts` 写入 `lastSync`/`classifiedAt`/`excludedAt` 等 JSON metadata
- **THEN** 使用 `import { now } from "@/lib/time"` 代替 `new Date().toISOString()`

#### Scenario: Prisma DateTime 字段（Service 层）

- **WHEN** `chat-persistence.ts` 写入 `deletedAt` 字段
- **THEN** 使用 `import { nowDate } from "@/lib/time"` 代替 `new Date()`

### Requirement: 日志/审计层时间统一

15 个 Logger/lib 文件的 `formatMessage` 函数必须使用统一时间入口。

#### Scenario: Logger 时间戳生成

- **WHEN** `audit-logger.ts` 的 `formatMessage` 生成日志行
- **THEN** `new Date().toISOString()` 替换为 `import { now } from "@/lib/time"` 的 `now()`
- **AND** 15 个 Logger 文件全部替换后，`grep -rn 'new Date().toISOString()' src/lib/ | grep -v time.ts | grep -v append-runtime` 返回空

### Requirement: Agent 节点时间统一

5 个 Agent 节点/工具文件中生成的时间戳必须统一使用 `now()`。

#### Scenario: Reasoning step 时间戳

- **WHEN** `reasoning.ts` / `retrieval.ts` / `aggregation.ts` / `intention.ts` 生成 step 时间戳
- **THEN** 使用 `import { now } from "@/lib/time"` 代替 `new Date().toISOString()`

### Requirement: API Route 时间统一

13 个 API Route 文件中 `new Date().toISOString()` 和 Prisma DateTime `new Date()` 必须统一替换。

#### Scenario: API 响应构建中的时间戳

- **WHEN** `project/route.ts` 等 Route 构建响应 JSON 时写入 `createdAt`/`updatedAt`
- **THEN** 使用 `now()` 代替 `new Date().toISOString()`

#### Scenario: Prisma DateTime 字段赋值

- **WHEN** `h5/nongqing/prescriptions/` 等 Route 对 Prisma `data` 对象赋值 `completedAt`
- **THEN** 使用 `nowDate()` 代替 `new Date()`

### Requirement: 前端 Store 时间统一

3 个 Zustand Store + 1 个 UI 组件中 `new Date().toISOString()` 必须统一使用 `now()`。

#### Scenario: chat-store 生成线程/消息时间戳

- **WHEN** `chat-store.ts` 的 `createThread` / `addMessage` 等方法需要时间戳
- **THEN** 使用 `import { now } from "@/lib/time"` 代替 `new Date().toISOString()`

### Requirement: DB→前端时区转换

DB 存储 UTC 时间，前端展示前必须转换为本地时区。

#### Scenario: 聊天线程列表时间展示

- **WHEN** 前端从 API 获取线程的 `createdAt`/`updatedAt`（UTC）
- **THEN** 调用 `fromUTC(utcString)` 转换为本地时间后再展示

#### Scenario: UI 组件时间展示

- **WHEN** `chat-message.tsx` 等组件显示从 DB 读取的时间
- **THEN** 使用 `fromUTC()` 代替 `new Date(timestamp).toLocaleXxx()`

### Requirement: 验证闭环

所有替换完成后必须通过编译和 grep 验证。

#### Scenario: 编译验证

- **WHEN** 全部 Task 完成
- **THEN** `npm run build` 通过（tsc=0）

#### Scenario: 裸调用清零验证

- **WHEN** 全部 Task 完成
- **THEN** `grep -rn 'new Date().toISOString()' src/ | grep -v time.ts | grep -v test` 返回空
- **AND** `grep -rn 'new Date()' src/ --include='*.ts' --include='*.tsx' | grep -v time.ts | grep -v 'Date.now' | grep -v 'new Date(' | grep -v test` 返回空
