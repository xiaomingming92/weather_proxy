# Tasks: 时间规范化治理

> **验证规范**：每个 Task 完成时必须附带验证证据。

## Preconditions

- [ ] Plan 已评审通过（DPS ≥ 85）
- [ ] `npm run build` 当前无错误

## Phase 1: 基础设施（Task 1）

- [ ] Task 1.1: 扩展 `src/lib/time.ts` — 验证: `tsc --noEmit src/lib/time.ts` 通过
  - [ ] SubTask 1.1.1: 新增 `nowDate()` 函数
  - [ ] SubTask 1.1.2: 新增 `fromUTC(utcString)` 函数
  - [ ] SubTask 1.1.3: 新增 `fromUTCToDate(utcString)` 函数
  - [ ] SubTask 1.1.4: 新增 `toLocalISO(utcString)` 函数
  - [ ] SubTask 1.1.5: 添加单元测试 `src/tests/time.test.ts`

## Phase 2: 日志/审计层（Task 2，15 文件，可并行）

- [ ] Task 2.1: 替换 `src/lib/log/audit.ts` L137 — 验证: `grep -c "now()"` ≥ 1
- [ ] Task 2.2: 替换 `src/lib/audit-logger.ts` L67 — 验证: 同上
- [ ] Task 2.3: 替换 `src/lib/chat-persistence-logger.ts` L48
- [ ] Task 2.4: 替换 `src/lib/chat-stats-logger.ts` L43
- [ ] Task 2.5: 替换 `src/lib/stream-chat-logger.ts` L37
- [ ] Task 2.6: 替换 `src/lib/stream-bus-logger.ts` L48
- [ ] Task 2.7: 替换 `src/lib/model-config-logger.ts` L58
- [ ] Task 2.8: 替换 `src/lib/agent-gateway-dev-logger.ts` L43
- [ ] Task 2.9: 替换 `src/lib/agent-gateway-audit.ts` L22
- [ ] Task 2.10: 替换 `src/lib/farm-server-client.ts` L32
- [ ] Task 2.11: 替换 `src/lib/credential/service-token.ts` L34
- [ ] Task 2.12: 替换 `src/lib/auth/token-manager.ts` L28
- [ ] Task 2.13: 替换 `src/lib/auth/credential-store.ts` L15
- [ ] Task 2.14: 替换 `src/lib/hash-path.ts` L12, L57, L112
- [ ] Task 2.15: 确认 `src/lib/append-runtime-finding.ts` 已使用 `now()`/`reportNow()` ✅

## Phase 3: Service 层（Task 3+4，~11 文件，可并行）

- [ ] Task 3.1: 替换 `src/services/knowledge-sync.ts` — 8 处 `now()` + 验证
- [ ] Task 3.2: 替换 `src/services/knowledge-indexer.ts` — 4 处 `now()` + 验证
- [ ] Task 3.3: 替换 `src/services/analysis-context.ts` — 6 处 `now()` + 验证
- [ ] Task 3.4: 替换 `src/services/audit-log.ts` L40 — 1 处 `now()` + 验证
- [ ] Task 3.5: 替换 `src/services/retrieval-stats.ts` L78 — 1 处 `now()` + 验证
- [ ] Task 3.6: 替换 `src/services/cache-ttl-stats.ts` L128, L138 — 2 处 `now()` + 验证
- [ ] Task 3.7: 替换 `src/services/chat-persistence.ts` L251 — `deletedAt: nowDate()` + 验证
- [ ] Task 4.1: 替换 `src/services/report-generator.ts` — 8 处 → `reportNow()` + 验证
- [ ] Task 4.2: 替换 `src/lib/log/notify/channels/wecom.ts` L35 → `reportNow()` + 验证
- [ ] Task 4.3: 替换 `src/app/api/h5/nongqing/daily-report/route.ts` L125 → `reportNow()` + 验证
- [ ] Task 4.4: 替换 `src/services/reasoning-engine.ts` — 4 处 → `now()` + 验证

## Phase 4: Agent 节点 + API Route（Task 5+6，~18 文件，可并行）

- [ ] Task 5.1: 替换 `src/agents/nodes/reasoning.ts` L488 — 1 处 `now()`
- [ ] Task 5.2: 替换 `src/agents/nodes/retrieval.ts` L151, L346, L377, L435, L454 — 5 处 `now()`
- [ ] Task 5.3: 替换 `src/agents/nodes/aggregation.ts` L20, L61 — 2 处 `now()`
- [ ] Task 5.4: 替换 `src/agents/nodes/intention.ts` L25 — 1 处 `now()`
- [ ] Task 5.5: 替换 `src/agents/tools/impl/index-documents.ts` L20 — 1 处 `now()`
- [ ] Task 6.1: 替换 `src/app/api/agent/[hash]/route.ts` L693 — `now()`
- [ ] Task 6.2: 替换 `src/app/api/agent/chat/route.ts` L132 — `now()`
- [ ] Task 6.3: 替换 `src/app/api/agent/chat/stream/route.ts` L427, L537, L575 — 3 处 `now()`
- [ ] Task 6.4: 替换 `src/app/api/project/route.ts` L31-32 + `[id]/route.ts` L39 — `now()`
- [ ] Task 6.5: 替换 `src/app/api/task/route.ts` L46-47 + `[id]/route.ts` L40 + `[id]/status/route.ts` L36
- [ ] Task 6.6: 替换 `src/app/api/document/route.ts` L36-37 — `now()`
- [ ] Task 6.7: 替换 `src/app/api/knowledge/upload/route.ts` L140 — `now()`
- [ ] Task 6.8: 替换 `src/app/api/knowledge/documents/[id]/progress/route.ts` L184 — `now()`
- [ ] Task 6.9: 替换 `src/app/api/h5/nongqing/prescriptions/[id]/route.ts` L131 `abandonedAt` + L170 `completedAt` → `now()` + `nowDate()`
- [ ] Task 6.10: 替换 `src/app/api/h5/nongqing/tasks/[id]/route.ts` L173 + L222 → `now()` + `nowDate()`
- [ ] Task 6.11: 替换 `src/app/api/h5/production-plan/plans/[id]/route.ts` L122 → `nowDate()`
- [ ] Task 6.12: 替换 `src/app/api/admin/service-accounts/route.ts` L106 → `nowDate()`
- [ ] Task 6.13: 替换 `src/app/api/seed-catalog/price/route.ts` L43 fallback → `nowDate()`

## Phase 5: 前端 Store + UI 转换（Task 7+8，~7 文件）

- [ ] Task 7.1: 替换 `src/stores/chat-store.ts` — 9 处 `new Date().toISOString()` → `now()`
- [ ] Task 7.2: 替换 `src/stores/task-store.ts` — 2 处 → `now()`
- [ ] Task 7.3: 替换 `src/stores/project-store.ts` — 2 处 → `now()`
- [ ] Task 7.4: 替换 `src/components/chat/chat-panel.tsx` — 4 处 → `now()`
- [ ] Task 8.1: 接入 `fromUTC()` 到 `chat-message.tsx` L55, L87
- [ ] Task 8.2: 接入 `fromUTC()` 到 `knowledge-base-panel.tsx` L472
- [ ] Task 8.3: 接入 `fromUTC()` 到 `document-list.tsx` L146

## Phase 6: 验证（Task 9）

- [ ] Task 9.1: `npm run build` 通过
- [ ] Task 9.2: `grep` 验证零裸 `new Date().toISOString()` + 零裸 Prisma `new Date()`
- [ ] Task 9.3: 运行现有测试 `npm test`

## Task Dependencies

- Task 2~8 全部依赖 Task 1
- Task 7.1 依赖 Task 8.1~8.3（`fromUTC()` 函数）
- Task 9 依赖 Task 1~8 全部完成

## Verification

- [ ] `npx tsc --noEmit` 通过
- [ ] `grep -rn 'new Date().toISOString()' src/ --include='*.ts' --include='*.tsx' | grep -v time.ts | grep -v test` 返回空
- [ ] `grep -rn 'new Date()' src/ --include='*.ts' --include='*.tsx' | grep -v time.ts | grep -v 'Date.now' | grep -v 'new Date(' | grep -v test` 返回空（仅 time.ts 内允许）
