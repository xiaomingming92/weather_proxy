# Checklist: 时间规范化治理

> **证据规范**：每项 [x] 必须附带可验证证据。不得空勾选、不得推测通过。

## Phase 1: 基础设施

- [ ] [T] Task 1.1: time.ts 函数扩展（nowDate + fromUTC + fromUTCToDate + toLocalISO） — 证据: `tsc --noEmit src/lib/time.ts` 通过|审计: (待初验)
- [ ] [T] Task 1.1.5: 单元测试通过 — 证据: `vitest run src/tests/time.test.ts` 全部通过|审计: (待初验)

## Phase 2: 日志/审计层

- [ ] [E] Task 2.1~2.15: 15 个 Logger 文件全部替换 — 证据: `grep -l 'import.*now.*time' src/lib/log/audit.ts src/lib/audit-logger.ts ... | wc -l` = 15|审计: (待初验)
- [ ] [E] 确认无遗漏 Logger — 证据: `grep -rn 'new Date().toISOString()' src/lib/ | grep -v time.ts | grep -v append-runtime` 返回空|审计: (待初验)

## Phase 3: Service 层

- [ ] [E] Task 3.1~3.7: Service metadata JSON 全部替换 — 证据: `grep -rn 'new Date().toISOString()' src/services/` 返回空|审计: (待初验)
- [ ] [E] Task 4.1~4.4: Report/通知时间全部替换 — 证据: `grep -l 'reportNow' src/services/report-generator.ts src/lib/log/notify/channels/wecom.ts` 均有 import|审计: (待初验)

## Phase 4: Agent + API Route

- [ ] [E] Task 5.1~5.5: Agent 节点全部替换 — 证据: `grep -rn 'new Date().toISOString()' src/agents/` 返回空|审计: (待初验)
- [ ] [E] Task 6.1~6.13: API Route 全部替换 — 证据: `grep -rn 'new Date().toISOString()' src/app/api/` 返回空|审计: (待初验)
- [ ] [E] Prisma DateTime `new Date()` 全部替换为 `nowDate()` — 证据: `grep -rn 'new Date()' src/ --include='*.ts' | grep -v time.ts | grep -v 'Date.now' | grep -v 'new Date('` 返回空|审计: (待初验)

## Phase 5: 前端 Store + UI

- [ ] [E] Task 7.1~7.4: 前端 Store 全部替换 — 证据: `grep -rn 'new Date().toISOString()' src/stores/ src/components/chat/chat-panel.tsx` 返回空|审计: (待初验)
- [ ] [E] Task 8.1~8.3: UI 组件接入 fromUTC() — 证据: `grep -l 'fromUTC' src/components/chat/chat-message.tsx src/components/knowledge/knowledge-base-panel.tsx src/components/document/document-list.tsx` 均有 import|审计: (待初验)

## Phase 6: 全量验证

- [ ] [T] `npm run build` 通过 — 证据: `tsc=0`|审计: (待初验)
- [ ] [E] 全量裸调用清零 — 证据: `grep -rn 'new Date().toISOString()' src/ | grep -v time.ts | grep -v test` 返回空|审计: (待初验)
- [ ] [E] 全量裸 `new Date()` 清零 — 证据: `grep -rn 'new Date()\b' src/ --include='*.ts' --include='*.tsx' | grep -v time.ts | grep -v 'Date.now' | grep -v 'new Date(' | grep -v test` 返回空|审计: (待初验)

## ADD 规则合规检查

- [ ] [E] ADD-1 可观测性优先 — 证据: 时间生成统一入口本身就是可观测性提升
- [ ] [E] ADD-4 三通道输出 — 证据: `now()` 同时写入 console/file/DB
- [ ] [E] Plan/Spec 一致性 — 证据: check_spec_sync 结果|审计: (待初验)
