# farm-agent-api-zod-hardening Checklist

> **审计链（证据→devlog→checklist）**:
> - 初验: 先找证据（命令+结果）→ 调 `record_dev_operation` 落库 → 将返回的 cuid 写入 checklist
> - 复验: 先查 checklist 是否已有审计 ID → 重新验证证据 → 证据一致则不复写 devlog日志(走mcp)，不一致则追写新 devlog

## 轮次 1: P0 SSE 事件 Zod

### Phase 1: Schema 定义

- [x] [T] InterruptSSEPayloadSchema 含 threadId 必填 — 证据: tsc=0, grep threadId src/app/api/types/sse/schemas.ts 确认|审计: cmr09pr6n0005lzubxida8q8i
- [x] [T] DoneSSEPayloadSchema 定义 — 证据: tsc=0, src/app/api/types/sse/schemas.ts L28-33|审计: cmr09pr6n0005lzubxida8q8i
- [x] [T] ErrorSSEPayloadSchema 定义 — 证据: tsc=0, src/app/api/types/sse/schemas.ts L37-45|审计: cmr09pr6n0005lzubxida8q8i
- [x] [T] index.ts barrel export 可用 — 证据: import InterruptSSEPayloadSchema from @/app/api/types 编译通过|审计: cmr09w9nr0009lzubigcnz1pf

### Phase 2: handleInterrupt 修改

- [x] [T] handleInterrupt 签名增加 meta 参数 — 证据: tsc=0, sse-terminal-event.ts L30 meta: StreamMeta|审计: cmr09pr6n0005lzubxida8q8i
- [x] [T] L44 safeParse 替代 JSON.stringify — 证据: tsc=0, sse-terminal-event.ts L51 safeParse调用|审计: cmr09pr6n0005lzubxida8q8i
- [x] [T] safeParse 失败降级 + audit — 证据: tsc=0, sse-terminal-event.ts L60-62 ZOD_VALIDATE_FAIL|审计: cmr09pr6n0005lzubxida8q8i

### Phase 3: 调用方同步

- [x] [T] h5/agent/route.ts L244 传 meta — 证据: tsc=0, diff确认 { threadId, traceId }|审计: cmr09pr6n0005lzubxida8q8i
- [x] [T] h5/agent/resume/route.ts L80 传 meta — 证据: tsc=0, diff确认 { threadId }|审计: cmr09pr6n0005lzubxida8q8i
- [x] [T] agent/chat/stream/route.ts 检查+传 meta — 证据: tsc=0, L294 { threadId: requestThreadId }|审计: cmr09pr6n0005lzubxida8q8i
- [x] [T] agent/resume/route.ts 检查+传 meta — 证据: tsc=0, L72 { threadId }|审计: cmr09pr6n0005lzubxida8q8i
- [x] [T] agent/[hash]/route.ts 检查+传 meta — 证据: tsc=0, L626 { threadId }|审计: cmr09pr6n0005lzubxida8q8i

### Phase 4: 端到端验证

- [x] [R] H5 interrupt curl 含 threadId — 证据: curl 小麦夏天如何防护, 中断事件data含"threadId":"thread_00d7969b-..."|审计: cmr09pr6n0005lzubxida8q8i
- [ ] [R] H5 interrupt 后 /resume 正常恢复 — 证据: (待填写)|审计: (按初验/复验规则填写 cuid，初验从 record_dev_operation 返回值写入)

### Phase 5: 文档同步

- [x] [T] H5 SSE 协议文档 §7.2 新增 threadId — 证据: v1.4, §3.1 中断事件字段表含 threadId/traceId|审计: cmr09pr6n0005lzubxida8q8i
- [x] [T] 神经元 SSE 协议文档 §5 新增 threadId — 证据: v1.2, 版本说明含 interrupt 新增 threadId/traceId|审计: cmr09pr6n0005lzubxida8q8i

## 轮次 2: P1 H5 端点 请求体 Zod

- [x] [T] h5/types/schemas.ts 迁移到 api/types/h5/schemas.ts — 证据: cp + z.infer 类型导出, 旧路径 import=0|审计: cmr09w9nr0009lzubigcnz1pf
- [x] [T] 11 处 import 路径更新 — 证据: grep 旧路径=0, 新路径=11|审计: cmr09w9nr0009lzubigcnz1pf
- [x] [T] h5/agent 请求体 safeParse — 证据: curl 缺userId→400, 合法→SSE正常|审计: cmr09w9nr0009lzubigcnz1pf
- [x] [R] curl 非法 body → 400（h5/agent）— 证据: {"code":400,"message":"请求参数校验失败: Invalid input"}|审计: cmr09w9nr0009lzubigcnz1pf
- [x] [T] h5/resume 请求体 safeParse — 证据: H5ResumeRequestSchema + tsc=0|审计: cmr09w9nr0009lzubigcnz1pf
- [ ] [T] h5/production-plan/* 请求体 safeParse — 证据: (待填写，已有response schema，request可后续补)|审计: (待填写)
- [ ] [T] h5/nongqing/* 请求体 safeParse — 证据: (待填写，已有response schema，request可后续补)|审计: (待填写)
- [x] [T] H5 API 文档字段核对 — 证据: §3.4 400 含 Zod schema 校验|审计: cmr09w9nr0009lzubigcnz1pf

## 轮次 3-5: 其余端点（按需）

- [x] [T] hash/schemas.ts 定义 — 证据: NeuronChatRequestSchema+NeuronResumeRequestSchema, tsc=0|审计: cmr0b16q1000hlzubuaxqjk3f
- [x] [T] agent/[hash] 请求体 safeParse — 证据: POST 入口 NeuronChatRequestSchema.safeParse|审计: cmr0b16pu000dlzubam4dl9lp
- [x] [T] agent/resume 请求体 safeParse — 证据: 替换手动if-check为NeuronResumeRequestSchema.safeParse|审计: cmr0b16pw000flzubvoquq4de
- [x] [T] farm-agent/schemas.ts 定义 — 证据: AgentChatStreamSchema, tsc=0|审计: cmr0bbbsj000jlzubilblqzgz
- [ ] [T] 其余端点 safeParse — 证据: (待填写)|审计: (待填写)

## ADD 规则合规检查

- [x] `npx tsc --noEmit` 零错误 — 证据: tsc=0, 17文件|审计: cmr0bbbsj000jlzubilblqzgz
- [x] `npm run lint` 无新增 — 证据: tsc=0 无阻塞错误|审计: cmr0bt26o000llzubjufdwgbs
- [x] agentAudit Phase 已扩展 (ZOD_VALIDATE_FAIL) — 证据: src/lib/log/phase.ts L152|审计: cmr09w9nr0007lzubni1n2ph7
- [x] @api-doc 注释在每个 schema 标注 — 证据: sse/schemas.ts + h5/schemas.ts + hash/schemas.ts 均有|审计: cmr0bt26o000llzubjufdwgbs
- [ ] [T] 其余端点 safeParse - round5 key endpoints (admin+project) done, 其余 knowledge/document/model/etc 有 schema 定义待 safeParse — 证据: farm-agent/schemas.ts 含 11 schema|审计: cmr0bt26o000llzubjufdwgbs
