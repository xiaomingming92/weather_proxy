# farm-agent-api-zod-hardening Spec

## Why

生产事故（June 29 16:30）：H5 中断流 `event: interrupt` 缺失 `threadId`，调用方无法调 `/resume`。根因是 SSE 事件全凭约定发送，无 Zod 类型约束。同时 Code Review 指出 `src/app/api/` 下 40+ 路由文件全部裸 `request.json()` 无运行时校验。

## What Changes

| 轮次 | 改动 | 文件数 |
|:--:|------|:--:|
| 1 | 新建 SSE 事件 Zod schema + handleInterrupt safeParse + 调用方 meta 参数 | ~8 |
| 2 | H5 端点请求体 Zod (迁移 h5/types/schemas.ts) | ~12 |
| 3 | hash 神经元端点请求体 Zod | ~4 |
| 4 | farm-agent 自有端点请求体 Zod | ~3 |
| 5 | 其余端点请求体 Zod (admin/auth/knowledge) | ~26 |

## Impact

- **Affected specs**: 无（独立基础设施改造）
- **Affected code**: `src/app/api/**/*.ts`、`src/caijuehub/strategies/sse-terminal-event.ts`
- **父 Plan**: 无
- **依赖**: 无上游依赖
- **后续依赖**: 所有后续 API 开发均需遵守 Zod schema 约定

## Boundaries

**本次允许**:
- 新建 `src/app/api/types/` 目录下 SSE/H5/hash/farm-agent 四个域的 schema 文件
- 修改 `handleInterrupt` / `resolveStreamEnd` 签名以传递 `meta`
- 每个端点 `request.json()` 后添加 `safeParse(schema)` 校验
- 迁移 `h5/types/schemas.ts` → `api/types/h5/schemas.ts`

**本次禁止**:
- 修改 API 业务逻辑（校验失败只返回 400，不影响正常流程）
- 修改 Zod schema 字段语义（只加字段不删不改）
- 修改前端对接方的解析逻辑

## Requirements

### Requirement: Interrupt SSE 事件携带 threadId

系统 SHALL 在 `event: interrupt` 的 data 中包含 `threadId` 和 `traceId` 字段。

**Scenario**: H5 用户触发交互点
- WHEN Agent 调用 `interrupt(payload)` 暂停图
- THEN SSE 流发送 `event: interrupt\ndata: { type, description, options, threadId, traceId }`
- AND 调用方可以从 data.threadId 获取线程 ID 用于 resume

### Requirement: Zod schema 校验 API 请求体

系统 SHALL 在每个 API 端点的 `request.json()` 后调用 `safeParse(schema)` 校验请求体。

**Scenario**: 非法格式请求体
- WHEN 请求体缺少必填字段或字段类型不匹配
- THEN 返回 HTTP 400 及错误描述
- AND 记录 `ZOD_VALIDATE_FAIL` 审计日志

### Requirement: Zod 与 DTO 协调

系统 SHALL 以 Zod schema 为单一真源，DTO 类型通过 `z.infer` 推导。

**Scenario**: 新增 API 字段
- WHEN 在 Zod schema 中新增字段
- THEN DTO 类型自动包含新字段（通过 `z.infer`）
- AND 不再需要在 `dto.ts` 中手写重复 interface
