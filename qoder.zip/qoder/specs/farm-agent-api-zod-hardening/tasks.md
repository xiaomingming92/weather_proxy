# Tasks: farm-agent-api-zod-hardening

## Preconditions

- [ ] DPS ≥ 85（Specs 三元组就绪后重跑）
- [ ] Plan Review 3 P0 已回流

## Forbidden

- 禁止修改 API 业务逻辑
- 禁止修改 Zod schema 字段语义（只加不删不改）
- 禁止在 `dto.ts` 和 `schemas.ts` 中手写重复结构

## 轮次 1: P0 SSE 事件 Zod

- [x] Task 1.1: 新建 `src/app/api/types/sse/schemas.ts`
  - [x] 定义 `InterruptSSEPayloadSchema`（`threadId: z.string()` 必填）— 证据: tsc=0, grep threadId 确认
  - [x] 定义 `DoneSSEPayloadSchema`
  - [x] 定义 `ErrorSSEPayloadSchema`
  - [x] `@api-doc` 注释标注来源
  - [x] 验证: `z.object` 定义编译通过

- [x] Task 1.2: 新建 `src/app/api/types/index.ts`
  - [x] barrel export: `export * from "./sse/schemas"`
  - [x] 验证: `import { InterruptSSEPayloadSchema } from "@/app/api/types"` 可编译

- [x] Task 1.3: 修改 `src/caijuehub/strategies/sse-terminal-event.ts`
  - [x] `handleInterrupt` 增加 `meta: { threadId: string; traceId: string }` 参数
  - [x] L44 替换为 `InterruptSSEPayloadSchema.safeParse(payload)`
  - [x] 验证: tsc=0

- [x] Task 1.4: H5 agent 调用方传 meta
  - [x] `h5/agent/route.ts` L244 → `{ threadId, traceId }`

- [x] Task 1.5: H5 resume 调用方传 meta
  - [x] `h5/agent/[threadId]/resume/route.ts` L80 → `{ threadId }`

- [x] Task 1.6: agent/chat/stream 调用方
  - [x] L294 → `{ threadId: requestThreadId }`

- [x] Task 1.7: agent/resume 调用方
  - [x] L72 → `{ threadId }`

- [x] Task 1.8: SSE 协议文档同步
  - [x] H5 SSE → v1.4, §3.1 中断事件字段表含 threadId/traceId
  - [x] 神经元 SSE → v1.2, 版本说明含 interrupt 新增字段

## 轮次 2: P1 H5 端点 请求体 Zod

- [x] Task 2.1: 迁移 schema → `src/app/api/types/h5/schemas.ts`
  - [x] 复制 `h5/types/schemas.ts` 全部 schema — 证据: cp + 文件存在
  - [x] 每个 schema 加 `export type X = z.infer<typeof XSchema>` — 证据: 16 个 z.infer 类型导出
  - [x] 验证: tsc=0

- [x] Task 2.2: h5/agent 请求体 safeParse
  - [x] `H5AgentRequestSchema` 定义 + `safeParse` → 失败返回 400
  - [x] 验证: curl 缺userId→400, 合法→SSE正常

- [x] Task 2.3: h5/resume 请求体 safeParse
  - [x] `H5ResumeRequestSchema` 定义 + `safeParse` → 失败返回 400
  - [x] 验证: tsc=0

- [x] Task 2.10: 更新 import 路径
  - [x] 11 处 `@/app/api/h5/types/` → `@/app/api/types/h5/`
  - [x] 验证: grep 旧路径确认零残留

- [ ] Task 2.4-2.9: production-plan/nongqing 请求体 Zod（已有 response schema，request 可后续轮次补）

- [x] Task 2.11: H5 API 文档同步
  - [x] §3.4 400 错误码标注 Zod schema 校验

## 轮次 3-5: 其余端点

- [x] Task 3.1: 新建 `src/app/api/types/hash/schemas.ts` — 证据: tsc=0 + NeuronChatRequestSchema/NeuronResumeRequestSchema
- [x] Task 3.2: agent/[hash] safeParse — 证据: POST 入口 safeParse + tsc=0
- [x] Task 3.3: agent/resume safeParse — 证据: 替换手动if-check + tsc=0
- [x] Task 4.1: farm-agent schema — 证据: AgentChatStreamSchema + tsc=0
- [x] Task 4.2: agent/chat/stream safeParse — 证据: safeParse + tsc=0
- [x] Task 4.3: agent/resume — 已由轮次3完成
- [ ] Task 5.1: admin/auth/knowledge 等 26 端点 schema（分批）

## Task Dependencies

- Task 1.3 依赖 1.1（schema 定义）
- Task 1.4~1.7 依赖 1.3（handleInterrupt 签名变更）
- Task 2.1 依赖 1.2（index.ts barrel）
- 轮次 2 独立于轮次 1（互不依赖）
- 轮次 3-5 各自独立

## Verification

- [ ] `npx tsc --noEmit` 零错误
- [ ] `npm run lint` 通过
- [ ] curl H5 interrupt 流包含 threadId
- [ ] curl H5 非法请求体返回 400
