# Tasks: hash route SSE 流式修复

## Preconditions

- [ ] dev server 正在运行（`npm run dev`）
- [ ] `chat/stream/route.ts` 的 SSE 流式模式可正常参考
- [ ] `npx tsc --noEmit` 当前无错误

## Forbidden

- 禁止修改 `handleHandshakePOST`、`handleDashboardGET` 等其他 handler
- 禁止修改 Agent 管线节点（intention/retrieval/reasoning/response 等）
- 禁止修改 `src/agents/stream-bus.ts` 的事件发送逻辑
- 禁止修改 proxy.ts

## Tasks

### Phase 1: 函数替换

- [ ] Task 1.1: `handleChatPOST` 引入 SSE 依赖
  - [ ] 从 `@/agents/stream-bus` 引入 `registerStreamBus` / `unregisterStreamBus` / `StreamEvent`
  - [ ] 从 `@/agents/cognitive-event-bus` 引入 `CognitiveEventBus`
  - [ ] 从 `@/agents` 引入 `streamAgent`（替代 `runAgent`）
  - [ ] 验证：`npx tsc --noEmit` 无 import 错误

- [ ] Task 1.2: 替换 Agent 调用方式
  - [ ] `runAgent(...)` → `streamAgent(...)`（参数增加 `globalStateProvider` + `eventBus`）
  - [ ] 验证：函数签名对齐 `chat/stream/route.ts` 的 `streamAgent` 调用

### Phase 2: SSE 流式输出

- [ ] Task 2.1: 创建 ReadableStream 包装 SSE 输出
  - [ ] 使用 `ReadableStream` + `TextEncoder` 创建 SSE 流
  - [ ] `registerStreamBus(traceId, callback)` 将事件序列化为 `data: {JSON}\n\n`
  - [ ] Agent 完成后发送 `data: {"done":true,...}\n\n`
  - [ ] `finally` 块调用 `unregisterStreamBus(traceId)`

- [ ] Task 2.2: 返回 SSE Response
  - [ ] 返回 `new Response(stream, { headers: { "Content-Type": "text/event-stream", ... } })`
  - [ ] 注意：不再调用 `NextResponse.json()`

### Phase 3: 验证

- [ ] Task 3.1: 编译验证
  - [ ] `npx tsc --noEmit` 零错误

- [ ] Task 3.2: curl 验证
  - [ ] `curl -X POST /api/agent/{hash} -d '{"type":"chat","messages":[...]}'` → `Content-Type: text/event-stream`
  - [ ] 输出逐条 `data:` 行

- [ ] Task 3.3: 日志验证
  - [ ] `stream-bus.log` 中该 traceId 有 `STREAM_BUS_REGISTER` 记录
  - [ ] 不再出现 `STREAM_BUS_EMIT_ERROR: 未注册`

## Task Dependencies

- Task 1.2 依赖 Task 1.1
- Phase 2 依赖 Phase 1
- Phase 3 依赖 Phase 2

## Verification

- [ ] `npx tsc --noEmit` 通过
- [ ] agrisynapse 神经元点击"农情日报" → 流式显示回复
