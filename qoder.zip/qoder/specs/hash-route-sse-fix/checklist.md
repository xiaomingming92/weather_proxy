# Checklist: hash route SSE 流式修复

> 执行日期: 2026-06-09
> 状态: 代码实现完成，[T] 项已验证，[R] 项待两端联调

## Phase 1: 函数替换

- [x] `handleChatPOST` 正确引入 `registerStreamBus` / `unregisterStreamBus` / `StreamEvent` / `CognitiveEventBus` / `streamAgent`
- [x] `streamAgent` 调用签名与 `chat/stream/route.ts` 一致（含 `globalStateProvider` + `eventBus`）
- [x] `npx tsc --noEmit` 编译通过

## Phase 2: SSE 流式输出

- [x] `ReadableStream` + `TextEncoder` 正确创建 SSE 流
- [x] `registerStreamBus` 回调正确输出 `data: {JSON}\n\n` 格式
- [x] Agent 完成后发送 `data: {"done":true,...}\n\n`
- [x] 返回 `Content-Type: text/event-stream`
- [x] `finally` 块调用 `unregisterStreamBus(traceId)`

## Phase 3: 验证

- [x] `curl` 返回 `Content-Type: text/event-stream` (2026-06-09T06:54 验证通过)
- [x] `curl` 输出逐条 `data:` 行（token + structured_update + streaming_node 均正常）
- [R] agrisynapse 神经元点击"农情日报" → 流式显示回复（需两端都启动验证）
- [x] `stream-bus.log` 有 `STREAM_BUS_REGISTER` 记录（traceId=935c9de5-...）
- [x] `stream-bus.log` 无 `STREAM_BUS_EMIT_ERROR: 未注册`

## ADD 规则合规

- [x] ADD-2 阶段标记对称（register/unregister 配对，finally 保证 always unregister）
- [x] ADD-4 三通道输出（console + file + AuditLog 均不受影响）
- [x] handleHandshakePOST / handleDashboardGET 逻辑未被修改
