# hash route SSE 流式修复 Spec

## Why

`[hash]/route.ts` 的 `handleChatPOST()` 使用 `runAgent()` 返回 JSON，与 agrisynapse 客户端期望的 SSE 流式协议不匹配，导致：
- 前端 GUI 永远卡在"等待响应"
- 2393 条 `STREAM_BUS_EMIT_ERROR` 写满日志和 AuditLog
- Agent 管线完整执行但数据全部丢弃

## What Changes

修改 `src/app/api/agent/[hash]/route.ts` 的 `handleChatPOST()`：
- `runAgent()` → `streamAgent()`
- 返回 `Content-Type: text/event-stream` 替代 `NextResponse.json()`
- 接入 `registerStreamBus` / `unregisterStreamBus` + `CognitiveEventBus`

## Impact

- Affected specs: 无
- Affected code: `src/app/api/agent/[hash]/route.ts`（仅 `handleChatPOST` 函数）
- 父 Plan: `farm-agent-hash-route-sse-fix-plan-v1.md`
- 上游: review2 §5.1
- 下游: review-runtime.md（运行时验证）

## Boundaries

本次只允许修改 `handleChatPOST` 的响应格式（JSON → SSE 流式）。
本次禁止修改：
- 认证网关裁决逻辑
- 握手/线程创建逻辑
- Farm-Server token provider
- Agent 管线节点逻辑

## ADDED Requirements

### Requirement: Chat 消息返回 SSE 流式响应

#### Scenario: agrisynapse 发送 chat 请求

- **WHEN** agrisynapse 客户端 POST `{"type":"chat","messages":[...]}` 到 `/api/agent/{hash}`
- **THEN** 响应 Content-Type 为 `text/event-stream`
- **THEN** 响应体逐条输出 `data: {"type":"token","content":"..."}` 格式的 SSE 事件
- **THEN** `stream-bus.log` 不再出现 `STREAM_BUS_EMIT_ERROR: 未注册`

#### Scenario: Agent 管线节点事件正确桥接

- **WHEN** Agent 节点（intention/retrieval/reasoning/response 等）调用 `emitStreamEvent()`
- **THEN** 事件通过 `registerStreamBus` 注册的回调写入 SSE 输出流
- **THEN** 所有 SSE 事件类型（token/structured_update/streaming_node 等）均被正确序列化

#### Scenario: 非 chat 类型请求不受影响

- **WHEN** POST `{"type":"handshake",...}` 到 `/api/agent/{hash}`
- **THEN** 行为不变，按原有逻辑处理
- **WHEN** GET 请求到 `/api/agent/{hash}?action=dashboard`
- **THEN** 行为不变，返回 JSON
