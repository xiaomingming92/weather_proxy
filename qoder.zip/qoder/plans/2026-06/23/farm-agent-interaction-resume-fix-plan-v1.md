# farm-agent-interaction-resume-fix-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到 Review 能判断方向对错即可。

## PLAN 元信息

- **Plan 名称**: farm-agent-interaction-resume-fix-v1
- **启动时间**: 2026-06-22
- **主导 AI**: Qoder
- **关联文档**:
  - SSE 协议文档: `docs/.../瑞丰耘H5小程序SSE流式聊天协议文档.md`（§7.2-7.3 标注了当前偏差）
  - 父 Plan: `.qoder/plans/farm-agent-three-tier-reasoning-graph-plan-v1.md`（Phase 1 已交付，Phase 2-4 待实施）
- **ADD-7 审计策略**: 见 §六

---

## 一、问题根因

普通交互点 resume 走 `store.sendMessage(choice, { selectedOption })` — **新消息**启动**新图 run**，导致上一轮 State 全部丢失：

```
当前方案（❌）:
  graph run#1 → reasoning → interactionPointDetection → structured_update → graph __end__
  user clicks option
  graph run#2 (NEW) → intention → ...   ← 上一轮 evidenceChain/reasoningPath 全部没了

行业标准（✅）:
  graph run#1 → reasoning → interactionPointDetection → interrupt() ← 图暂停
  user clicks option → Command(resume=choice)
  graph run#1 续推 → verdict → response → __end__  ← State 完整保留
```

KB 矛盾裁决已经做对了（`resumeAgent(threadId, choice, note)` → 后端 `Command(resume)`），普通交互点没做。

## 二、修复范围

| 层 | 文件 | 改动 |
|:--|------|------|
| 后端 | `src/agents/index.ts` | `interactionPointDetection` 节点检测到交互点时调用 `interrupt()` 而非 `__end__` |
| 后端 | `src/agents/nodes/interaction-point-detection.ts` | 返回 `{ interactionPoint, __interrupt__: true }` 让图暂停 |
| 前端 | `agrisynapse/src/store/modules/agentChat.ts` | `handleInteractionSelect` 改为 `resumeAgent(threadId, choice)` 而非 `sendMessage()` |
| 前端 | `agrisynapse/src/views/llm/components/LlmChatView.vue` | 交互点确认按钮绑定 `resumeAgent` 而非 `sendMessage` |

## 三、改动详情

### 3.1 后端：interactionPointDetection → interrupt()

当前流程：
```
reasoning → interactionPointDetection → routeByInteractionPoint → verdict/response
```

修复后：
```
reasoning → interactionPointDetection
  └─ hasInteractionPoint? → interrupt({ interactionPoint })  ← 新增
  └─ noInteractionPoint  → verdict → response               ← 不变
```

关键：`interrupt()` 后 State 保留在 `MemorySaver`，`Command(resume=choice)` 从同一行继续。

前端调用：
```
resumeAgent(threadId, choice, note?) → POST /api/h5/agent/resume
  → agent.invoke(Command(resume = { choice, note }), config)
  → 图从 interrupt() 下一行继续
```

不再使用 `sendMessage`。

### 3.2 前端：resumeAgent 通道

KB 矛盾裁决已经在用 `resumeAgent`（`agentChat.ts L411-439`）。交互点复用同一个函数：

```typescript
// LlmChatView.vue L811-813 改前
function handleInteractionSelect(label: string) {
  store.sendMessage(label, undefined, undefined, undefined, undefined, { selectedOption: label })
}

// 改后
function handleInteractionSelect(label: string) {
  store.resumeWithChoice(label)
  // resumeWithChoice 内部调用 resumeAgent(threadId, label)
}
```

### 3.3 图状态标记

`interrupt()` 后需要区分"流暂停等交互"vs"流正常结束"：

- 前端保持 `_streamingMsgId` 不释放
- `_pausedForInterrupt` flag 复用（KB 矛盾已实现）

## 四、实施步骤

```
Task 1: interactionPointDetection 节点改造（interrupt 替代 end）
Task 2: agentChat.ts 交互点分支改为 resumeAgent
Task 3: LlmChatView.vue 确认按钮绑定修改
Task 4: tsc --noEmit + 端到端测试（问一个触发交互点的问题 → 确认 → 验证 State 未丢失）
```

## 五、验收标准

- [ ] 触发交互点的对话，用户选择后 evidenceChain 不丢失
- [ ] `npx tsc --noEmit` 零错误
- [ ] KB 矛盾裁决不受影响（走同一个 resumeAgent）
- [ ] session 重启后交互卡片不残留
- [ ] 与行业标准对齐：`interrupt()` + `Command(resume)`

## 六、ADD-7 审计策略

| 文件 | targetType | action | beforeState | afterState |
|-----|-----------|--------|------------|-----------|
| `src/agents/nodes/interaction-point-detection.ts` | NODE | NODE_MODIFIED | 返回 interactionPoint → 图自然结束 | 返回 interactionPoint + interrupt() 暂停图 |
| `src/agents/index.ts` | GRAPH | GRAPH_MODIFIED | interactionPointDetection 后无条件边到 verdict | 新增条件边：hasInteraction → interrupt / 无 → verdict |
| `agrisynapse/.../agentChat.ts` | STORE | STORE_MODIFIED | 交互点走 sendMessage 新消息 | 交互点走 resumeWithChoice/resumeAgent 恢复流 |
| `agrisynapse/.../LlmChatView.vue` | COMPONENT | COMPONENT_MODIFIED | handleInteractionSelect → sendMessage | handleInteractionSelect → resumeWithChoice |

## 七、关联文档

| 文档 | 路径 |
|------|------|
| 本 Plan | `.qoder/plans/farm-agent-interaction-resume-fix-plan-v1.md` |
| add-route | `.qoder/plans/farm-agent-interaction-resume-add-route-v1.md` |
| Handoff | `.qoder/plans/farm-agent-interaction-resume-fix-handoff-v1.md` |
| Spec | `.qoder/specs/farm-agent-interaction-resume-fix/spec.md` |
| Tasks | `.qoder/specs/farm-agent-interaction-resume-fix/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-interaction-resume-fix/checklist.md` |
| SSE 协议文档 | `docs/.../瑞丰耘H5小程序SSE流式聊天协议文档.md`（标注了当前偏差） |
| ACA 框架 Plan | `.qoder/plans/farm-agent-three-tier-reasoning-graph-plan-v1.md` |
