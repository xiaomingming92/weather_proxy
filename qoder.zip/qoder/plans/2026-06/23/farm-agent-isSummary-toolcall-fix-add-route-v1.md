# farm-agent-isSummary-toolcall-fix-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节。
> **模式**：重型 — 每步产出检查强制执行"验证并更新项目状态"。
> **绑定**：Plan: `farm-agent-isSummary-toolcall-fix-plan-v1.md` · Spec: `farm-agent-isSummary-toolcall-fix/spec.md` · Tasks: `farm-agent-isSummary-toolcall-fix/tasks.md` · Handoff: `farm-agent-isSummary-toolcall-fix-handoff-v1.md`

---

## Step 0：文档先行

**动作**：
1. 确认 Specs 三元组就绪（spec.md + tasks.md + checklist.md）
2. 调用 `find_related_docs` 检索受影响文档
3. 更新项目文档或声明无需更新
4. 确认 Handoff 就绪

**产出**：
- [ ] Specs 三元组路径确认：`.qoder/specs/farm-agent-isSummary-toolcall-fix/`
- [ ] 项目文档更新：本次为修复型子 Plan，不新增业务能力，无需更新 `docs/` 下架构/需求文档（理由：F1-F4 均为节点内代码逻辑修复，不改变外部 API 合约）
- [ ] Handoff 就绪：待生成

### §0.8 DPS 闸门

调用 `check_dps({ planKeyword: "isSummary-toolcall-fix" })`。

- [ ] DPS ≥ 85，可进入 Step 1

---

## Step 1：审计阶段定义

| Phase | 使用场景 | Task |
|-------|---------|------|
| `INTENTION_TOOL_INJECT` | intention 节点强制注入 tool_calls（F1 修复） | Task 1 |
| `INTENTION_TOOL_SKIP` | 本轮已有 ToolMessages，跳过注入（F4 收窄后） | Task 1 |
| `REASONING_EVIDENCE_BACKFILL` | reasoning 节点工具结果回写 evidenceChain（F2 修复） | Task 3 |
| `REASONING_PACKAGE_SELF_BUILD` | reasoning 节点自构建 expertPackages（F3 修复） | Task 3 |
| `ISUMMARY_VERIFY` | isSummary 全链路验证 | Task 5 |

**产出**：
- [ ] AgentAuditPhase 联合类型已扩展（新增上述 5 个 phase 字面量）
- [ ] 本次审计阶段清单已同步到 tasks.md

---

## Step 2：审计基础设施确认

**动作**：
1. 确认 `agentAudit()` 接受新增 phase 字面量
2. 确认三通道输出正常

**产出**：
- [ ] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现

### §3.0 前置守卫

调用 `check_add_route_status` 确认本文件有效存在。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | intention.ts F1+F4 | `src/agents/nodes/intention.ts` | L158 注入点: `INTENTION_TOOL_INJECT`; 跳过点: `INTENTION_TOOL_SKIP` | 2 | 无 | ⬜ |
| 2 | EvidenceSource 扩展 | `src/types/evidence.ts` | 无（类型变更） | — | 无 | ⬜ |
| 3 | reasoning.ts F2+F3 | `src/agents/nodes/reasoning.ts` | 回写点: `REASONING_EVIDENCE_BACKFILL`; 构建点: `REASONING_PACKAGE_SELF_BUILD` | 2 | Task 2 | ⬜ |
| 4 | caijue.toml | `src/caijuehub/caijue.toml` | 无（配置变更） | — | Task 1,3 | ⬜ |
| 5 | 全链路验证 | — | `ISUMMARY_VERIFY` | 1 | Task 1-4 | ⬜ |

### 依赖拓扑

```
Task 1 (intention.ts) ──┐
                          │ 可并行
Task 2 (evidence type) ──┘
                          │
                          ▼
Task 3 (reasoning.ts) ──── 依赖 Task 2
                          │
                          ▼
Task 4 (caijue.toml) ──── 依赖 Task 1,3
                          │
                          ▼
Task 5 (验证)
```

**产出**：
- [ ] 全部 Task `[T]` 项通过
- [ ] tasks.md 已完成项已逐项勾选
- [ ] `record_dev_operation` 逐文件记录
- [ ] `check_spec_sync` 通过

---

## Step 3.5：实现审查

**产出**：
- [ ] checklist.md 全部 `[T]` 项已通过并勾选
- [ ] review-implementation.md 已生成
- [ ] review-runtime.md 已生成

---

## Step 4：审计数据验证

**动作**：
1. `npx tsc --noEmit`
2. `npm run lint`
3. `check_phase_symmetry`
4. `check_failure_path`

**产出**：
- [ ] tsc 通过
- [ ] lint 通过
- [ ] 阶段对称性通过
- [ ] 失败路径审计通过

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "isSummary-toolcall-fix" })`。

- [ ] RAHS ≥ 90

---

## Step 5：AI 自动合规检查

调用 `check_add_compliance` 逐文件。

**产出**：
- [ ] 合规报告已生成

---

## Step 8：收敛判断 + Handoff + Step 0 第二阶段

**产出**：
- [ ] 收敛判定通过
- [ ] tasks.md + checklist.md 全部完成
- [ ] `check_spec_sync` 四者一致
- [ ] Handoff 已更新
- [ ] 架构文档已校准
- [ ] ADD-7 审计已落库

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/agents/nodes/intention.ts` | MODIFY | 1 | COMPONENT | ⬜ |
| `src/types/evidence.ts` | MODIFY | 2 | TYPE | ⬜ |
| `src/agents/nodes/reasoning.ts` | MODIFY | 3 | COMPONENT | ⬜ |
| `src/caijuehub/caijue.toml` | MODIFY | 4 | DECISION_REGISTRY | ⬜ |
| `src/lib/agent-audit-logger.ts` | MODIFY | 1 | LIB | ⬜ |
