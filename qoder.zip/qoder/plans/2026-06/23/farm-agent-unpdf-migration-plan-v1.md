# farm-agent-unpdf-migration-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。精确函数签名属于 Spec。

## PLAN 元信息

- **Plan 名称**: farm-agent-unpdf-migration-v1
- **启动时间**: 2026-06-23T10:00:00+08:00
- **主导 AI**: Qoder
- **最近更新**: 2026-06-23 — DPS 门禁纯化：已完成项归档至附录，正文仅保留待实施 Task 12-13
- **关联文档**:
  - Handoff: `.qoder/plans/farm-agent-unpdf-migration-handoff-v1.md`
  - add-route: `.qoder/plans/farm-agent-unpdf-migration-add-route-v1.md`
  - Runtime Review: `.qoder/reviews/farm-agent-unpdf-migration-runtime-review-v1.md`
  - Specs: `.qoder/specs/farm-agent-unpdf-migration/`
- **ADD-7 审计策略（仅待实施项）**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/services/knowledge-indexer.ts | COMPONENT | COMPONENT_MODIFIED | 解析与索引耦合在 indexKnowledgeDocumentWithProgress | 抽出 indexContent() 纯索引函数，解析与索引分离 | 待实施 |
| src/app/api/knowledge/documents/[id]/progress/route.ts | API_ROUTE | ROUTE_MODIFIED | OCR 回调经 parseDocumentFromBuffer 二次解析致 Invalid PDF structure | OCR 路径直接调 indexContent(ocrText)，绕过文件解析 | 待实施 |

---

## 一、背景与目标

OCR 异步管线已就位（ocr-worker + IndexJobManager + cancel API 已完成），但存在一个设计级缺口——OCR 子进程返回的纯文本被包成 `Buffer` 传入 `indexKnowledgeDocumentWithProgress`，后者内部无条件调 `parseDocumentFromBuffer` 将文本当 PDF 解析，unpdf 抛出 `Invalid PDF structure`。

**目标**：抽出 `indexContent()` 纯索引函数，使 OCR 路径绕过 `parseDocumentFromBuffer` 直接进入 Chunk→Embed→ChromaDB 管线。

---

## 二、方案选型

**OCR→索引桥接协议**（runtime review P0#1，唯一待实施方案）：

- `knowledge-indexer.ts` 抽出 `indexContent(content, fileName, parsedType, onProgress)` 纯索引函数
- `indexKnowledgeDocumentWithProgress` 退化为薄封装：`parseDocumentFromBuffer` → `indexContent`
- OCR 路径：Worker 返回 `done { text }` → 直接调 `indexContent(ocrText, fileName, "pdf", onProgress)`
- 绕过 `parseDocumentFromBuffer` 二次解析，不再出现 `Invalid PDF structure`

| 调用方 | 当前行为 | 修复后行为 |
|-------|---------|----------|
| `indexKnowledgeDocumentWithProgress(buffer, name)` | parseDocumentFromBuffer → chunk → embed | parseDocumentFromBuffer → indexContent |
| OCR `onComplete(ocrText)` | `Buffer.from(ocrText)` → parseDocumentFromBuffer（崩） | `indexContent(id, name, ocrText, "pdf", onProgress)` |

---

## 三、架构设计

**改动范围**：仅 `knowledge-indexer.ts`（抽出函数）+ `progress/route.ts`（调用替换），零新增文件，零新依赖。

```
Before（有 Bug）:
  OCR Worker done(text)
    → Buffer.from(text)                       // 纯文本伪装成 PDF buffer
    → indexKnowledgeDocumentWithProgress()    // 内部调 parseDocumentFromBuffer
    → unpdf.extractText(Buffer)               // 报错 Invalid PDF structure ❌

After（修复后）:
  OCR Worker done(text)
    → indexContent(id, name, text, "pdf")     // 直接进入索引管线 ✅

  非OCR路径不变:
  indexKnowledgeDocumentWithProgress(buffer)
    → parseDocumentFromBuffer(buffer)         // 解析
    → indexContent(id, name, content, type)   // 索引（与OCR路径共享）
```

外部消费者无感知：
- `document-indexer.ts` → `parseDocumentFromBuffer()` → 不变
- `knowledge-sync.ts` → `parseDocument()` + `parseDocumentFromBuffer()` → 不变

---

## 四、实施步骤

```
Task 1 (安装) ──┐
                 │ 串行
                 ▼
Task 2 (重写) ──┐
                 │ 串行
                 ▼
Task 3 (清理) ──┐
                 │ 串行
                 ▼
Task 4 (构建验证)
```

> **注意**：Task 1-11、14-15 已在前期完成，详见 [附录：已完成归档](#附录已完成归档)。本节仅列出待实施的 Task 12-13。

**Task 12:** 解析与索引分离（`knowledge-indexer.ts`）
- 从 `indexKnowledgeDocumentWithProgress` 中抽取 L113-281 的索引逻辑，形成 `indexContent(documentId, fileName, content, parsedType, onProgress, disciplineCodes?)` 纯索引函数
- `indexKnowledgeDocumentWithProgress` 退化为薄封装：`parseDocumentFromBuffer` → `indexContent`
- 签名不变，外部调用方零改动

**Task 13:** 改造 SSE Progress 端点（`progress/route.ts`）
- OCR 完成回调 `onComplete` 中：`Buffer.from(ocrText)` + `indexKnowledgeDocumentWithProgress` → `indexContent(id, doc.name, ocrText, "pdf", onProgress)`
- 移除 `Buffer.from(ocrText)` 的无效包装
- 不再出现 `Invalid PDF structure` 错误

---

## 五、验收标准

- [ ] `npx tsc --noEmit` 零错误
- [ ] `indexContent()` 从 `indexKnowledgeDocumentWithProgress` 中抽出，签名含 `content: string` + `parsedType: string`
- [ ] `indexKnowledgeDocumentWithProgress` 退化为 `parseDocumentFromBuffer` → `indexContent`，外部调用方零改动
- [ ] OCR 路径 SSE 流返回 `INDEXED` 而非 `Invalid PDF structure`
- [ ] 非扫描件 PDF 索引行为与重构前完全一致（回归测试）

---

## 六、各阶段独立验收标准

- **1. unpdf 引擎替换**：无 pdfjs-dist/pdf-parse 依赖，tsc 零错误，签名不变。✅ 已完成
- **2. 扫描件 OCR 降级**：@napi-rs/canvas 可用，扫描件返回有效文本。✅ 已完成
- **3. 解析索引分离（待实施）**：indexContent() 抽出，OCR 直接调 indexContent(ocrText) 不经过 parseDocumentFromBuffer。OCR 路径 SSE 流返回 INDEXED 而非 Invalid PDF structure。⬜
- **3a. OCR 子进程**：spawn + 临时文件，SSE 推送进度，cancel 可用。✅ 已完成
- **4. SSE 结构化**：phase/currentDoc/docIndex/totalDocs，agrisynapse 同步面板升级。✅ 已完成
- **5-6. 取消 + 单文档**：sync/cancel 可用，ChromaDB 清理正常，agrisynapse 行级按钮。✅ 已完成

**Review 回流确认**（runtime review P0/P1）：
- P0#1 OCR→索引桥接协议 → Plan §二 方案选型 + §三 架构设计 ✅ 已回流
- P0#2 Plan 未经过 ADD review → Plan 元信息关联文档 ✅ 已回流
- P1#3 Plan 文档漂移 → Plan 全文 child_process.spawn 规范 ✅ 已回流

---

## 七、关联文档

| 文档 | 路径 |
|------|------|
| Handoff | `.qoder/plans/farm-agent-unpdf-migration-handoff-v1.md` |
| add-route | `.qoder/plans/farm-agent-unpdf-migration-add-route-v1.md` |
| Runtime Review | `.qoder/reviews/farm-agent-unpdf-migration-runtime-review-v1.md` |
| Specs | `.qoder/specs/farm-agent-unpdf-migration/` |

---

## 附录：已完成归档

> 以下各项已在前期完成实施，本文档仅保留概要以供追溯。详细架构、Task 细节、验收标准见 git 历史 `2026-06-23`。

### 1. unpdf 引擎替换 (✅)

替换 `pdfjs-dist@5.7` + 死依赖 `pdf-parse@1.1` 为 `unpdf@1.6`，消除 worker/polyfill 问题。

| 文件 | 改动 | 状态 |
|------|------|:---:|
| `package.json` | unpdf 替换 pdfjs-dist + pdf-parse | ✅ |
| `src/services/document-parser.ts` | parsePdf 改用 unpdf.extractText | ✅ |
| `src/tests/setup.ts` | 移除 DOMMatrix polyfill | ✅ |
| `next.config.ts` | 新增 @napi-rs/canvas 到 serverExternalPackages | ✅ |

验收：tsc 零错误，PDF 解析函数签名不变，无 pdfjs-dist/pdf-parse 依赖。

### 2. 扫描件 OCR 降级 (✅)

`parsePdf` 扩展为混合解析：优先 `extractText`，文本为空时标记 `ocrDeferred: true`（不阻塞主线程）。

| 依赖 | 版本 | 用途 | 状态 |
|------|------|------|:---:|
| `@napi-rs/canvas` | ^0.1.69 | unpdf renderPageAsImage 必需 | ✅ |
| `tesseract.js` | ^7.0.0 | 纯 JS OCR | ✅ |
| `sharp` | latest | 图片预处理 | ⬜ |

验收：扫描型 PDF 可返回有效文本，文本型 PDF 行为不变。

### 3a. OCR 子进程 + IndexJobManager (✅)

OCR 异步化：`child_process.spawn` 子进程 + 临时文件传递 PDF + `process.send` 进度上报。

| 文件 | 操作 | 状态 |
|------|------|:---:|
| `src/workers/ocr-worker.ts` | 新建 — OCR 子进程入口 | ✅ |
| `src/services/index-job-manager.ts` | 新建 — 单例索引任务管理器 | ✅ |
| `src/app/api/knowledge/documents/[id]/index/cancel/route.ts` | 新建 — 通用取消 API | ✅ |

验收：扫描件不阻塞主线程，SSE 推送索引进度，cancel 可用。

### 4. SSE 进度结构化 (✅)

| 文件 | 改动 | 状态 |
|------|------|:---:|
| `src/services/knowledge-sync.ts` | SyncProgressEvent { phase, currentDoc, docIndex, totalDocs } | ✅ |
| `src/app/api/knowledge/sync/route.ts` | 透传结构化事件 + 8s heartbeat | ✅ |
| `agrisynapse: grounding.ts` | SyncProgressDetail + triggerSyncStream 类型化 | ✅ |
| `agrisynapse: index.vue(x2)` | 同步面板展示文档名+计数器+阶段标签 | ✅ |

### 5-6. 同步取消 + 单文档操作 (✅)

| 文件 | 改动 | 状态 |
|------|------|:---:|
| `src/app/api/knowledge/sync/cancel/route.ts` | 同步批次取消 | ✅ |
| `agrisynapse: grounding.ts` | cancelSync + syncSingleDocument + deleteDocument | ✅ |
| `agrisynapse: index.vue(x2)` | 取消/同步/删除按钮 | ✅ |

验收：POST /api/knowledge/sync/cancel 可用，ChromaDB 清理正常，agrisynapse 行级按钮可用。
