# farm-agent-ruifengyun-h5-api-plan-v2

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。不要写完整 TS 类型定义——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-ruifengyun-h5-api-v2
- **启动时间**: 2026-06-22T00:00:00Z
- **修订时间**: 2026-06-22（Review v1 回流：P1-1+P1-2）
- **修订时间**: 2026-06-22（启动自动登录 farmagentservice + Token 链路修复）
- **修订时间**: 2026-06-22（API Key 轮换：宽限期 + 管理 API + 脚本）
- **修订时间**: 2026-06-22（Phase 2 回流：DTO + Zod 校验层）
- **修订时间**: 2026-06-23（CORS 修复：全端点 X-Api-Key 白名单 + 网关错误信息优化）
- **修订时间**: 2026-06-24（跨 Plan 联动：下游 dict-cache plan 引用本 Plan 为前置依赖）
- **修订时间**: 2026-06-26（Runtime 纠正 §7：SSE Stream Bus 优雅结束）
- **修订时间**: 2026-06-26（Runtime 纠正 §8：H5 Agent 路由 interrupt 暂停修复）
- **修订时间**: 2026-06-26（新增子 Plan：h5-agent-route-code-quality-v1 — 审计函数替换 + SSE 流状态机）
- **主导 AI**: Qoder
- **父 Plan**: `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v1.md`（已实施完成）
- **关联文档**:
  - ADD Route: `.qoder/plans/farm-agent-ruifengyun-h5-api-add-route-v2.md`
  - Handoff: `.qoder/plans/farm-agent-ruifengyun-h5-api-handoff-v2.md`
  - Review: `.qoder/reviews/farm-agent-ruifengyun-h5-api-plan-v2-review-v1.md`
  - API 对接文档: `docs/大田精准耕播智能决策系统/knowledge/02-规范/瑞丰耘H5小程序API对接文档.md`
  - 需求文档: `docs/大田精准耕播智能决策系统/knowledge/00-需求/对接瑞丰耘AI智能体小程序-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| prisma/schema.prisma | COMPONENT | COMPONENT_UPDATED | 无 ServiceAccount 模型 | 新增 ServiceAccount 模型（id/name/apiKey/status/permissions） | 待实施 |
| src/caijuehub/strategies/h5-auth-gateway.ts | COMPONENT | COMPONENT_UPDATED | 仅 sessionId 模式 | 双模式裁决：service(API Key) + session（保留兼容） | 待实施 |
| src/app/api/h5/production-plan/land-analysis/route.ts | COMPONENT | COMPONENT_UPDATED | 路径 /api/h5/land-analysis，sessionId 认证 | 路径 /api/h5/production-plan/land-analysis，API Key 认证 | 待实施 |
| src/app/api/h5/production-plan/variety-recommend/route.ts | COMPONENT | COMPONENT_UPDATED | 路径 /api/h5/variety-recommend，sessionId 认证 | 路径 /api/h5/production-plan/variety-recommend，API Key 认证 | 待实施 |
| src/app/api/h5/production-plan/cost-accounting/route.ts | COMPONENT | COMPONENT_UPDATED | 路径 /api/h5/cost-accounting，sessionId 认证 | 路径 /api/h5/production-plan/cost-accounting，API Key 认证 | 待实施 |
| src/app/api/h5/production-plan/generate/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 计划生成端点（阶段1：假数据；阶段2：LLM 聚合） | 待实施 |
| src/app/api/h5/agent/route.ts | COMPONENT | COMPONENT_UPDATED | 双 type(handshake+chat)，sessionId 认证 | 仅 chat，API Key 认证 + body.userId 线程隔离 | 待实施 |
| src/lib/agent-audit-logger.ts | COMPONENT | COMPONENT_UPDATED | AgentAuditPhase 含 H5_HANDSHAKE 等 | 新增 SERVICE_AUTH + H5_PLAN_GENERATE 阶段 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

Plan v1 已于 2026-06-18 实施完成，5 个 API 端点均已上线运行。当前架构存在三个问题：

1. **认证模型不适配新需求**：v1 采用 per-user 握手（`handshake → H5Session → sessionId`），用户 token 加密存储于 `FarmServerCredential` 表。新的对接方是**小程序后台而非前端**——后台自身管理小程序用户认证，不希望将 per-user token 透传给 farm-agent。

2. **路径未按业务域划分**：三个业务端点（land-analysis / variety-recommend / cost-accounting）在 demo 页面（`https://80retros.com/wrnc/06/plan/new`）中属于「生产计划」5 步向导的 Step 2~4，但 API 路径平铺在 `/api/h5/` 下，未体现业务域归属。

3. **缺少 Step 5 计划生成 API**：demo 页面第 5 步「计划生成」聚合前三步产出，输出核心指标 + 生育周期 + 物资准备 + 风险提示。v1 Spec 将该步骤划为"禁止实现"（H5 端本地聚合），现在需要由 farm-agent 提供后端支持。

### 1.2 目标

1. **认证服务化**：新增 `ServiceAccount` 模型 + `X-Api-Key` 认证通道，替代 per-user 握手
2. **路径业务化**：三个业务端点迁移至 `/api/h5/production-plan/*`
3. **补全计划生成端点**：`POST /api/h5/production-plan/generate`
4. **聊天端点适配**：`/api/h5/agent` 保持原路径，认证切换为 API Key + body.userId 线程隔离
5. **分两阶段交付**：阶段1 假数据跑通链路 → 阶段2 真实逻辑

---

## 二、方案选型

### 2.1 认证方案对比

| 方案 | 实现成本 | 安全级别 | 运维复杂度 | 结论 |
|------|---------|---------|----------|------|
| A: API Key (Header) | 低 | 中 | 低 | **采纳** |
| B: JWT 服务账户 | 中 | 高 | 中（密钥管理） | 过度设计 |
| C: mTLS | 高 | 最高 | 高（证书轮换） | 过度设计 |

### 2.2 选型理由

- **API Key 方案**：与现有 `X-Session-Id` 模式并列，认证网关加一条 `service` 通道即可，不破坏现有裁决架构
- **不采用 JWT**：小程序后台是唯一调用方，无多租户签发需求，JWT 增加无效复杂度
- **不采用 mTLS**：开发/测试环境无证书基础设施

### 2.3 认证网关双通道设计

```
h5-auth-gateway.ts 裁决流程:
  ├─ X-Api-Key 存在且 ServiceAccount 表有效 → "service" 模式
  │   → 服务账户 token 调 Farm-Server（单条 FarmServerCredential，source="service"）
  ├─ X-Session-Id 存在且 H5Session 表有效  → "session" 模式（保留兼容旧客户端）
  └─ 两者都不存在 → "unauthenticated"
```

### 2.4 路径重构方案

直接迁移路由文件到新路径，Next.js App Router 下即目录重命名：

```
src/app/api/h5/land-analysis/route.ts    → src/app/api/h5/production-plan/land-analysis/route.ts
src/app/api/h5/variety-recommend/route.ts → src/app/api/h5/production-plan/variety-recommend/route.ts
src/app/api/h5/cost-accounting/route.ts   → src/app/api/h5/production-plan/cost-accounting/route.ts
```

旧路径保留重定向或直接删除（小程序后台未对接过旧路径，无兼容负担）。

### 2.5 计划生成方案

阶段1（本次交付）：API Route 内直接返回假数据 JSON（与 demo 页面结构一致），验证链路通畅。

阶段2（后续交付）：新增 `plan_generate` 轻量专家，LLM 聚合前三步产出。不走 LangGraph，API Route 内直调 LLM（与 v1 路线 A 一致）。

---

## 三、架构设计

### 3.1 新增 ServiceAccount 模型

```prisma
model ServiceAccount {
  id          String   @id @default(cuid())
  name        String   @unique            // 服务账户标识（如 "ruifengyun-h5-backend"），JWT 模式下对应 sub
  apiKey          String?
  previousApiKey  String?
  keyRotatedAt    DateTime?  @unique            // API Key SHA-256 哈希（apikey 模式必填，jwt 模式可为 null）
  description String?
  status      String   @default("active") // active | disabled
  permissions Json?                        // ["production-plan:*", "agent:chat"]
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}
```

API Key 生成与分发：
- 生成：`svc_` + randomUUID，存储时 SHA-256 哈希
- 分发：提供种子脚本 `scripts/seed-service-account.ts`，执行时输出明文 API Key（仅创建时可见），复制给小程序后台即完成分发
- 轮换：更新 ServiceAccount 表 `apiKey` 字段即可，同时通知小程序后台更新

### 3.1.1 API Key 生命周期管理



**轮换机制**：

- 轮换时旧 Key 写入 `previousApiKey`，记录 `keyRotatedAt`

- `ApiKeyResolver` 优先匹配 `apiKey`，其次匹配宽限期内的 `previousApiKey`（5 分钟）

- 5 分钟后旧 Key 自动失效



**管理方式**：

| 操作 | 管理 API | 脚本 |

|:--|:--|:--|

| 创建账户 | `POST /api/admin/service-accounts` | `manage-service-account.ts` |

| 轮换 Key | `PUT /api/admin/service-accounts?name=xxx` | `manage-service-account.ts rotate` |

| 查询账户 | `GET /api/admin/service-accounts?name=xxx` | `npm run service-account:create` |

| 禁用账户 | `DELETE /api/admin/service-accounts?name=xxx` | — |



### 3.2 认证网关扩展（可切换策略）

认证网关采用**策略模式**，支持 API Key 和 JWT 两种服务认证方式，通过环境变量 `H5_SERVICE_AUTH_MODE` 一键切换。

```
                 ┌─────────────────────────┐
X-Api-Key /     │   resolveServiceAuth()   │
Authorization ─→│                          │──→ H5AuthGatewayDecision
                 │  ┌───────────────────┐  │
                 │  │ H5_SERVICE_AUTH_  │  │
                 │  │ MODE=apikey ───→ ApiKeyResolver   │
                 │  │ MODE=jwt    ───→ JwtResolver      │
                 │  └───────────────────┘  │
                 └─────────────────────────┘
```

**环境变量**：

| 变量 | 默认值 | 说明 |
|:--|:--|:--|
| `H5_SERVICE_AUTH_MODE` | `apikey` | `apikey` \| `jwt` |
| `H5_JWT_SECRET` | — | JWT 模式下的签名密钥（HMAC-SHA256） |

**策略接口**：

```typescript
interface ServiceAuthResolver {
  resolve(credential: string): Promise<{
    serviceAccountId: string
    name: string
  } | null>
}
```

**ApiKeyResolver**（默认）：
- 从 Header `X-Api-Key` 取 credential
- 查 `ServiceAccount` 表 → SHA-256 比对 `apiKey` 字段
- 不关心过期时间

**JwtResolver**（`H5_SERVICE_AUTH_MODE=jwt`）：
- 从 Header `Authorization: Bearer <token>` 取 credential
- 用 `H5_JWT_SECRET` 验证签名 + `exp` 过期检查
- 从 payload `sub` 字段匹配 `ServiceAccount.name`
- 小程序后台需先向 farm-agent 申请 JWT（后续可提供签发端点）

**切换方式**：修改环境变量 → 重启服务 → 生效。两种模式共用 `ServiceAccount` 表的 `name` + `permissions` 字段，仅认证凭证不同。

**ServiceAccount 模型适配**：`apiKey` 字段改为可选（JWT 模式下不使用）：

```prisma
model ServiceAccount {
  id          String   @id @default(cuid())
  name        String   @unique            // 服务账户标识，JWT 模式下对应 sub
  apiKey          String?
  previousApiKey  String?
  keyRotatedAt    DateTime?  @unique            // API Key 哈希（apikey 模式必填，jwt 模式 null）
  description String?
  status      String   @default("active")
  permissions Json?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}
```

### 3.3 Farm-Server Token 管理

服务账户的 Farm-Server token 存储方式：
- 新增一条 `FarmServerCredential` 记录，`userId=0, source="service"`
- **Token 来源**：farm-agent 自身持有独立 Farm-Server 凭证（当前可复用已有管理员 token），存储于 `FarmServerCredential(userId=0, source="service")`。注意这是 farm-agent→Farm-Server 的内部调用凭证，与小程序后台→farm-agent 的 X-Api-Key 是两个独立认证层
- 若 Farm-Server 支持服务账户独立注册，后续可切换为专用 token（不阻塞当前实施）
- 服务账户的 token 由管理员手动维护（长期有效），不经过 per-user refresh 循环
- 业务端点通过 `ensureValidToken(0, "service")` 获取
- **前置确认**：实施前验证 Farm-Server 对 userId=0 的 API 调用权限（massif 查询、气象/土壤数据查询）

### 3.3.1 H5 服务账户自动登录（startup-farm-service-login.ts）



farm-agent 启动时自动以 `farmagentservice` 账户登录 Farm-Server：



```

npm run dev → predev → startup-farm-service-login.ts

  ├─ getValidToken(0, "service") → 有效则跳过

  ├─ POST {FARM_SERVER_BASE_URL}/system/auth/login

  └─ saveToken(0, accessToken, refreshToken, expiresAt, "service")

```



⚠️ **仅用于 H5 / 小程序后台对接场景**。agrisynapse 有独立 handshake 接口。



**Token 使用链路**：

```

H5 API Route → ensureValidToken(0, "service")

  → FarmServerCredential(userId=0, source="service")

  → 解密 accessToken → createFarmClient(token)

  → Farm-Server API (massif/weather/moisture)

```

|

### 3.4 端点变更总览

| 变更类型 | 旧 | 新 |
|:--|:--|:--|
| **路径迁移** | `/api/h5/land-analysis` | `/api/h5/production-plan/land-analysis` |
| **路径迁移** | `/api/h5/variety-recommend` | `/api/h5/production-plan/variety-recommend` |
| **路径迁移** | `/api/h5/cost-accounting` | `/api/h5/production-plan/cost-accounting` |
| **新增** | — | `/api/h5/production-plan/generate` |
| **修改** | `/api/h5/agent`（handshake+chat） | `/api/h5/agent`（仅 chat，body.userId） |
| **废弃** | `/api/h5/handshake` | 删除路由文件 |

### 3.4.5 CORS 预检白名单修复（2026-06-23）

**问题**：多个 H5 端点的 OPTIONS 预检响应中 `Access-Control-Allow-Headers` 缺少 `X-Api-Key`，导致遵守 CORS 的客户端（浏览器、部分 API 工具、代理层）在预检后丢弃该 Header，服务端收到请求时确实无 `X-Api-Key`，返回误导性 "缺少 X-Api-Key" 错误。

**修复范围**：

| 端点 | 修复内容 |
|------|---------|
| `/api/h5/agent` | CORS +`X-Api-Key` |
| `/api/h5/production-plan/land-analysis` | CORS +`X-Api-Key` |
| `/api/h5/production-plan/variety-recommend` | CORS +`X-Api-Key` |
| `/api/h5/production-plan/cost-accounting` | CORS +`X-Api-Key` |
| `/api/h5/production-plan/generate` | 补充完整 OPTIONS 处理器（原缺失） |
| nongqing/* 全部 6 个端点 | 已有 `X-Api-Key`，无需修改 |

**同时修复**：`h5-auth-gateway.ts` 中 `resolveH5AuthGateway` 的错误消息逻辑——原逻辑在 API Key 存在但数据库匹配失败时，静默降级到 sessionId，最终返回 "缺少 X-Api-Key" 的误导信息。修复后：提供 Key 但无效 → 返回 `"X-Api-Key 无效，未找到匹配的服务账户"`；Key 缺失 → 返回 `"缺少 X-Api-Key / X-Session-Id 认证凭证"`。

**ADD-7 审计**：

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/caijuehub/strategies/h5-auth-gateway.ts | COMPONENT | COMPONENT_UPDATED | 认证失败时返回误导性 "缺少凭证" 错误 | 区分 Key 缺失 vs Key 无效，返回不同错误消息 | ✅ 已实施 |
| src/app/api/h5/agent/route.ts | COMPONENT | COMPONENT_UPDATED | CORS 缺少 X-Api-Key | 补充 X-Api-Key 到 Access-Control-Allow-Headers | ✅ 已实施 |
| src/app/api/h5/production-plan/land-analysis/route.ts | COMPONENT | COMPONENT_UPDATED | CORS 缺少 X-Api-Key | 补充 X-Api-Key 白名单 | ✅ 已实施 |
| src/app/api/h5/production-plan/variety-recommend/route.ts | COMPONENT | COMPONENT_UPDATED | CORS 缺少 X-Api-Key | 补充 X-Api-Key 白名单 | ✅ 已实施 |
| src/app/api/h5/production-plan/cost-accounting/route.ts | COMPONENT | COMPONENT_UPDATED | CORS 缺少 X-Api-Key | 补充 X-Api-Key 白名单 | ✅ 已实施 |
| src/app/api/h5/production-plan/generate/route.ts | COMPONENT | COMPONENT_UPDATED | 缺少 OPTIONS 处理器 | 补充 OPTIONS + X-Api-Key CORS 白名单 | ✅ 已实施 |

### 3.4.6 DTO 与 Zod 校验层



所有端点响应均通过 Zod Schema 校验，类型定义就近存放在 `src/app/api/h5/types/`：



| 文件 | 职责 |

|:--|:--|

| `types/dto.ts` | TypeScript 接口定义（LandAnalysisData, VarietyRecommendItem, PlanGenerateData 等） |

| `types/schemas.ts` | Zod 校验 Schema（landAnalysisSchema, planGenerateSchema 等） |



**校验策略**：

- `generate` 端点：`planGenerateSchema.safeParse()` — 校验通过返回 Zod 类型，失败记录 audit + 降级为原始输出

- 3 个 LLM 端点：`xxxSchema.safeParse()` — 同上软校验策略

- Agent SSE：已有 `StreamEvent` 类型，无需额外 Zod



### 3.5 Agent 聊天端点改造

移除 `type: "handshake"` 逻辑，统一为 `type: "chat"`：

```
之前: X-Session-Id → h5-auth-gateway → userId → h5-handshake-thread → agent.stream()
现在: X-Api-Key → h5-auth-gateway(service) → 从 body.userId 建线程 → agent.stream()
```

- 不再查 `H5Session` 表
- 不再需 `h5-handshake-thread.ts` 裁决（线程由 body.userId 直通 `ChatThread` 表）
- `ChatThread` 表结构不变：`(userId, source="h5")` 隔离

---

## 四、实施步骤 + 依赖图

```
阶段1: API 脚手架（假数据，跑通链路）

  Task 1: Prisma ServiceAccount 模型 ──┐
  Task 2: h5-auth-gateway 双模式扩展 ──┤ 可并行
  Task 3: 路径迁移（3个端点重命名）  ──┤
                                       │
                                       ▼
  Task 4: 新增 /api/h5/production-plan/generate（假数据）
  Task 5: 改造 /api/h5/agent（去 handshake，加 body.userId）
  Task 6: 废弃 /api/h5/handshake（删除路由）
                                       │
                                       ▼
  Task 7: tsc --noEmit + curl 验证

────────────────────────────────────────────

阶段2: 真实逻辑（后续 Plan）

  Task 8: plan_generate 专家 prompt
  Task 9: plan_generate registry 注册
  Task 10: generate 端点接入 LLM 聚合逻辑
  Task 11: 端到端验证
```

### 阶段1 详细 Task

#### Task 1: Prisma ServiceAccount 模型
- 在 `prisma/schema.prisma` 新增 `ServiceAccount` 模型
- 执行 `npx prisma migrate dev --name add_service_account`
- 新建 `scripts/seed-service-account.ts`：创建 ServiceAccount 记录 + 输出明文 API Key
- **验证**: `npx tsx scripts/seed-service-account.ts` 输出有效 Key，`prisma.serviceAccount.findFirst()` 可查

#### Task 2: h5-auth-gateway 双模式扩展
- `H5AuthMode` 加 `"service"`
- `H5AuthGatewayDecision` 加 `serviceAccountId: string | null`
- `resolveH5AuthGateway` 签名改为 `(apiKey: string | null, sessionId: string | null)`
- 优先检查 `apiKey` → 查 `ServiceAccount` 表 → service 模式
- 降级检查 `sessionId` → 查 `H5Session` 表 → session 模式
- 新增审计阶段 `SERVICE_AUTH` 到 `agent-audit-logger.ts`
- **验证**: 单元级逻辑审查（无独立测试文件，以 curl 为准）

#### Task 3: 路径迁移（3个端点）
- 目录重命名：`src/app/api/h5/{land-analysis,variety-recommend,cost-accounting}` → `src/app/api/h5/production-plan/{land-analysis,variety-recommend,cost-accounting}`
- 三个 route.ts 内部认证方式切换：`X-Session-Id` → `X-Api-Key`
- 三路由共有的认证模式代码提取为辅助函数 `resolveServiceAuth(apiKey)` 避免重复
- Farm-Server token 获取改为 `ensureValidToken(0, "service")`
- traceId 前缀继承不变（`h5_land_` / `h5_var_` / `h5_cost_`）
- **验证**: `tsc --noEmit` 通过

#### Task 4: 新增 generate 端点（假数据）
- 新建 `src/app/api/h5/production-plan/generate/route.ts`
- POST 端点，`X-Api-Key` 认证
- 阶段1：直接返回硬编码 JSON（与 demo 页面结构一致：coreMetrics + plots + growthSchedule + materials + risks）
- 阶段2（本次不实施）：LLM 聚合
- 新增审计阶段 `H5_PLAN_GENERATE`
- traceId: `h5_gen_<uuid>`
- **验证**: curl 返回假数据 JSON

#### Task 5: 改造 agent 端点
- 移除 `type: "handshake"` 处理逻辑
- 认证切换：`X-Api-Key` → service 模式
- 线程裁决：从 body 取 `userId` → 直接查/建 `ChatThread`（不再经 h5-handshake-thread.ts）
- 移除 `h5-handshake-thread.ts` 的 import（文件保留不动，仅解耦）
- `FarmServerCredential` source="h5" 改为 source="service"
- **验证**: curl 聊天正常 SSE 流式推送

#### Task 6: 废弃 handshake 端点
- 删除 `src/app/api/h5/handshake/route.ts`
- 可选清理：`H5Session` 模型标记 deprecated（不下线，旧 session 仍可查询用于过渡期）
- `h5-handshake-thread.ts` 标记 deprecated 注释
- **验证**: `tsc --noEmit` 通过

#### Task 7: 编译 + curl 验证
- `npx tsc --noEmit` 零错误
- curl 逐个端点验证：land-analysis → variety-recommend → cost-accounting → generate → agent
- 确认 `X-Api-Key` 认证生效（无 Key 返回 401）
- 确认旧路径 `/api/h5/land-analysis` 返回 404

---

## 五、验收标准

- [ ] ServiceAccount 模型已建表，种子数据可查
- [ ] `X-Api-Key` 认证通过后 3 个业务端点正常响应
- [ ] 无 `X-Api-Key` 返回 401
- [ ] `/api/h5/production-plan/land-analysis` 路径可访问
- [ ] `/api/h5/production-plan/variety-recommend` 路径可访问
- [ ] `/api/h5/production-plan/cost-accounting` 路径可访问
- [ ] 旧路径 `/api/h5/land-analysis` 返回 404
- [ ] `/api/h5/production-plan/generate` 返回假数据 JSON（结构与 demo 一致）
- [ ] `/api/h5/agent` 不再支持 handshake type，仅 chat
- [ ] `/api/h5/agent` 通过 body.userId 正确隔离 thread
- [ ] `/api/h5/handshake` 返回 404
- [ ] `npx tsc --noEmit` 编译通过
- [ ] 审计日志可查询（SERVICE_AUTH + H5_PLAN_GENERATE 阶段）
- [ ] API 对接文档 v2.0 与实现一致

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| 父 Plan | `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v1.md` | ✅ 已实施 |
| 需求来源 | `docs/大田精准耕播智能决策系统/knowledge/00-需求/对接瑞丰耘AI智能体小程序-v1.md` | ✅ 已存在 |
| API 对接文档 | `docs/大田精准耕播智能决策系统/knowledge/02-规范/瑞丰耘H5小程序API对接文档.md` | ✅ 已更新为 v2.0 |
| ADD Route | `.qoder/plans/farm-agent-ruifengyun-h5-api-add-route-v2.md` | ⬜ 待生成 |
| Handoff | `.qoder/plans/farm-agent-ruifengyun-h5-api-handoff-v2.md` | ⬜ 待生成 |
| Review | `.qoder/reviews/farm-agent-ruifengyun-h5-api-plan-v2-review-v1.md` | ⬜ 待生成 |
| Spec | `.qoder/specs/farm-agent-ruifengyun-h5-api-v2/spec.md` | ⬜ 待生成 |
| Tasks | `.qoder/specs/farm-agent-ruifengyun-h5-api-v2/tasks.md` | ⬜ 待生成 |
| Checklist | `.qoder/specs/farm-agent-ruifengyun-h5-api-v2/checklist.md` | ⬜ 待生成 |
| 下游 Plan | `.qoder/plans/2026-06/24/farm-agent-land-analysis-dict-cache-plan-v1.md` | 📋 已规划 |
| Runtime Review | `.qoder/reviews/farm-agent-ruifengyun-h5-api-v2-runtime-review-v1.md` | ✅ 已生成 (2026-06-25: P0x3 + P1x2 + P2x1) |
| Runtime 纠正 §7 | 本文档 §7 | 📋 2026-06-26: SSE Stream Bus 优雅结束 |

---

## 七、Runtime 纠正 §7 — SSE Stream Bus 优雅结束（2026-06-26）

> **定位**：父 Plan 体不动，仅追加引用。完整 Runtime 纠正方案由 stream-bus 起源 Plan 主责：[`streaming-event-bus-plan-v1.md` §6](../../2026-05/18/streaming-event-bus-plan-v1.md)。
>
> 本 Plan 涉及的关联变更：
> - `src/app/api/h5/agent/route.ts`：回调增加 `streamClosed` + try/catch 防护
>
> 其余 `stream-bus.ts` / `chat/stream/route.ts` / `agent/[hash]/route.ts` 的变更归属 `streaming-event-bus-plan-v1.md`。
>
> 验收：部署后 `pm2-out.log` 不再出现 `STREAM_BUS_EMIT_ERROR ... 未注册`。

## 八、Runtime 纠正 §8 — H5 Agent 路由 interrupt 暂停修复（2026-06-26）

> **定位**：§7 部署后测试发现 H5 Agent SSE 流在 `interrupt()` 后仍然发送 `done` 事件，导致 checkpoint 未正确保留、resume 端点无法工作。本次修复属于 §7 的配套完善。

### 8.1 触发来源

VPS 部署 §7 后测试 H5 resume 端点，发现 `INTERACTION_INTERRUPT` 已记录但 resume 仍失败。

### 8.2 根因

`src/app/api/h5/agent/route.ts` 中 `__interrupt__` 处理使用 `continue` 而非 `break`，导致循环继续、代码走到 `done` 发送逻辑。图虽被 `interrupt()` 暂停，但路由层未区分中断与完成，仍发送 `done` 并关闭 SSE 连接。

### 8.3 变更

| 文件 | 改动 | 原因 |
|------|------|------|
| `src/app/api/h5/agent/route.ts` | `__interrupt__` 处理：`continue` → `break`；中断后 `return` 早退不发送 `done` | 中断后图已暂停，不发 done 才能让客户端通过 resume 恢复 |

### 8.4 架构文档同步

`docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` §4.4 管线行为描述已从"下一轮对话重新进入"更新为 LangGraph `interrupt()` + resume 端点三段式流程。

### 8.5 验收

- `INTERACTION_INTERRUPT` 后 resume 端点可正常恢复 SSE 流（不报 `u is not async iterable`）
- 中断后的 SSE 连接不发送 `done` 事件

## 九、子 Plan — h5-agent-route-code-quality-v1（2026-06-26）

> **定位**：父 Plan 体不动，追加引用。完整方案由子 Plan 主责：[`h5-agent-route-code-quality-plan-v1.md`](../../2026-06/26/h5-agent-route-code-quality-plan-v1.md)。

本 Plan 关联：
- `src/lib/agent-audit-logger.ts`：新增 5 个 `H5_CHAT_*` 审计阶段（枚举扩展）
- `src/agents/sse-stream-state.ts`：新建 `StreamState` 类型 + `transition()` + 判断函数（路由层状态机）
- `src/app/api/h5/agent/route.ts`：6 处 `console.*` → `agentAudit()`；`interrupted` 布尔 → `streamState` 状态机
