# farm-agent-unpdf-migration-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **绑定**：Plan: `.qoder/plans/farm-agent-unpdf-migration-plan-v1.md` · Runtime Review: `.qoder/reviews/farm-agent-unpdf-migration-runtime-review-v1.md` · Handoff: `.qoder/plans/farm-agent-unpdf-migration-handoff-v1.md`
>
> **最近更新**: 2026-06-23 — runtime review 回流 (P0#1 解析索引分离, P1#3 纠正实现细节)

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Handoff 就绪，项目文档反映即将实现的变更。

**输入**：
- Plan v1 文档（已存在，待增量更新）
- Handoff v1 文档（已存在，待同步更新）
- 项目文档 `docs/大田精准耕播智能决策系统/`

**动作**：
1. Plan 增量更新：在已有 unpdf 迁移基础上，新增"扫描件 OCR 降级"方案
2. 调用 `find_related_docs` 检索受影响的架构文档
3. Handoff 同步更新：追加 OCR 降级相关改动清单、风险点、回滚方案
4. 确认 README.md 文档解析技术栈描述是否需同步更新

**产出**：
- [x] Plan v1 增量更新完成（新增 §3.2 扫描件 OCR 降级方案 + Task 5-8）
- [x] Handoff v1 同步更新完成
- [x] 项目文档更新（小改动，无需更新架构文档——OCR 降级对上层 RAG 透明）
- [x] Handoff 就绪

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的所有审计阶段，扩展 `AgentAuditPhase`。

**输入**：
- Plan § 的 Task 列表
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase` 联合类型

**动作**：
1. 列出本次变更涉及的业务阶段：`pdf_parse_ocr_fallback`（PDF OCR 降级解析）
2. 无需新增 AgentAuditPhase——复用现有 `DOCUMENT_PARSE` phase + 现有 `auditDocParseStart/Done/Error` 函数

**产出**：
- [x] 审计阶段清单（使用现有 phase，无需新增）

| Phase | 使用场景 | Task |
|-------|---------|------|
| `DOCUMENT_PARSE` (复用) | PDF 文本提取 + OCR 降级 | Task 5-6 |

---

## Step 2：审计基础设施确认

**目的**：确认 `auditDocParseStart/Done/Error` 通道可用。

**输入**：
- `src/lib/audit-logger.ts` 的 `auditDocParseStart/Done/Error` 导出

**动作**：
1. 确认三函数签名接受 `fileName`、`docType`、额外 metadata
2. 确认三通道输出正常（console + file + AuditLog 表）

**产出**：
- [x] 审计通道确认可用（与 Step 0 原始迁移使用同一套审计函数）

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan 依赖拓扑逐 Task 实施代码 + 嵌入审计点。

**输入**：
- Plan §3 修复方案
- Plan §4 实施步骤（Task 依赖拓扑）
- Handoff 的 ADD-7 审计策略表

**动作**：

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | 安装 unpdf，移除旧包 | `package.json` | `record_dev_operation` | — | 无 | ✅ 已完成 |
| 2 | 重写 parsePdf | `src/services/document-parser.ts` | `auditDocParseStart/Done/Error` | `DOCUMENT_PARSE` | Task 1 | ✅ 已完成 |
| 3 | 清理 polyfill | `src/tests/setup.ts` | `record_dev_operation` | — | Task 2 | ✅ 已完成 |
| 4 | 构建验证 | — | `tsc --noEmit` | — | Task 3 | ✅ 已完成 |
| 5 | 安装 @napi-rs/canvas | `package.json` | `record_dev_operation` | — | Task 4 | ✅ 已完成 |
| 6 | 实现 OCR 降级逻辑 | `src/services/document-parser.ts` | `auditDocParseStart/Done/Error` (追加 OCR 相关 metadata) | `DOCUMENT_PARSE` | Task 5 | ✅ 已完成 |
| 7 | （可选）安装 sharp 预处理 | `package.json` | `record_dev_operation` | — | Task 5 | ❌ 跳过 |
| 8 | OCR 验证 | — | `tsc --noEmit` + 扫描件实测 | — | Task 6 | ✅ 已完成 |
| 9 | 创建 OCR 子进程 Worker | `src/workers/ocr-worker.ts` | `record_dev_operation` | — | Task 8 | ✅ 已完成（fork→spawn，临时文件传 PDF） |
| 10 | 创建统一 IndexJobManager | `src/services/index-job-manager.ts` | `record_dev_operation` | — | Task 9 | ✅ 已完成（ChildProcess 生命周期+进度轮询） |
| 11 | 创建通用取消 API | `src/app/api/knowledge/documents/[id]/index/cancel/route.ts` | `record_dev_operation` | — | Task 10 | ✅ 已完成 |
| 12 | 解析与索引分离 | `src/services/knowledge-indexer.ts` | `auditDocParseStart/Done/Error` | `DOCUMENT_PARSE` | Task 9,10 | ⬜ **待实施**（抽出 indexContent） |
| 13 | 改造 SSE Progress 端点 | `src/app/api/knowledge/documents/[id]/progress/route.ts` | 现有审计点 | `DOC_PROGRESS` | Task 10,12 | ⬜ **待实施**（OCR 路径调 indexContent 替代 parseDocumentFromBuffer） |
| 14 | 丰富 SSE Progress 数据结构 | `src/services/knowledge-sync.ts`, `src/app/api/knowledge/sync/route.ts` | `record_dev_operation` | — | — | ✅ |
| 15 | agrisynapse 前端同步面板升级 | `grounding.ts`, `knowledgeBase/index.vue`, `customization/index.vue` | — | — | Task 14 | ✅ |
| 16 | 后端同步取消能力 | `index-job-manager.ts`, `knowledge-sync.ts`, `sync/route.ts`, `sync/cancel/route.ts` | `record_dev_operation` | — | — | ✅ |
| 17 | agrisynapse 前端取消按钮 | `grounding.ts`, `knowledgeBase/index.vue`, `customization/index.vue` | — | — | Task 16 | ✅ |

### 依赖拓扑

```
Task 1 ──→ Task 2 ──→ Task 3 ──→ Task 4（Phase 1 已完成）
                                      │
                                      ▼
                               Task 5（安装 Canvas）✅
                                      │
                              ┌───────┴───────┐
                              ▼               ▼
                         Task 6（OCR 降级）✅  Task 7（sharp）❌
                              │
                              ▼
                         Task 8（验证）✅
                              │
                              ▼
                    ┌──── Task 9（OCR 子进程 ✅）
                    │         │
                    │         ▼
                    │    Task 10（IndexJobManager ✅）
                    │         │
                    │    ┌────┴────┐
                    │    ▼         ▼
                    │ Task 11    Task 12
                    │ (Cancel ✅) (解析索引分离 ⬜)
                    │              │
                    │              ▼
                    │         Task 13
                    │         (SSE改造 ⬜)
                    │
                    ▼
              Task 14 → Task 15
              (SSE结构) (前端UI) ✅
```

**产出**：
- [x] 已完成 Task (1-11, 14-15) 的 `[T]` 项全部通过
- [ ] Task 12/13 的 `[T]` 项待实施（解析索引分离 + SSE 改造）
- [x] 每个文件有 `record_dev_operation` 记录（3 条审计：add-route 创建/Plan 更新/Handoff 更新 + 2 条：component-parser.ts 修改/canvas 确认）

---

## Step 3.5：实现审查

**目的**：代码完成后，验证意图与实现无语义鸿沟。

**动作**：
1. 确认 parsePdf 函数签名不变，外部调用方无感知
2. 确认 OCR 降级仅当 extractText 返回空时触发
3. 确认 @napi-rs/canvas 在 Next.js build 中无问题

**产出**：
- [x] `tsc --noEmit` 零错误（多次验证通过）
- [x] OCR 降级逻辑审查通过（Phase 2 已完成，扫描件实测通过）
- [ ] Task 12/13 实现审查（待代码修改后执行）

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**动作**：
1. `npx tsc --noEmit` —— 零类型错误 ✅
2. 调用 `check_phase_symmetry` 验证阶段标记完整性
3. 调用 `check_failure_path` 验证失败路径审计等价

**产出**：
- [x] `tsc --noEmit` 通过
- [ ] 阶段对称性验证通过（已完成代码需调 check_phase_symmetry）
- [ ] 失败路径审计等价验证通过（已完成代码需调 check_failure_path）
- [ ] Task 12/13 审计验证（待代码修改后执行）

---

## Step 5：AI 自动合规检查

**目的**：扫描全部修改文件的 ADD-1~ADD-7 合规性。

**动作**：
1. 对修改文件调用 `check_add_compliance`

**产出**：
- [ ] 合规报告已生成（已完成文件需调 check_add_compliance）

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**目的**：功能收敛判定，更新 Handoff，架构文档校准。

**动作**：
1. 收敛判断：全部 Task 通过 → 功能收敛
2. Handoff 更新：同步 OCR 降级相关改动
3. Step 0 第二阶段：验证 `docs/` 架构文档反映变更
4. ADD-7 回查：`query_audit_logs` 确认记录落库

**产出**：
- [ ] 收敛判定结果（Task 12/13 完成后执行）
- [x] Handoff 已更新（OCR 降级相关改动已同步）
- [x] 架构文档已校准（OCR 降级对上层 RAG 透明，无需变更）

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `package.json` | MODIFY | 1, 5, 7 | CONFIG | ✅ |
| `src/services/document-parser.ts` | MODIFY | 2, 6, 12 | COMPONENT | ✅/⬜ |
| `src/tests/setup.ts` | MODIFY | 3 | CONFIG | ✅ |
| `src/workers/ocr-worker.ts` | CREATE | 9 | COMPONENT | ✅ |
| `src/services/index-job-manager.ts` | CREATE | 10 | COMPONENT | ✅ |
| `src/app/api/knowledge/documents/[id]/index/cancel/route.ts` | CREATE | 11 | API | ✅ |
| `src/services/knowledge-indexer.ts` | MODIFY | 12 | COMPONENT | ⬜ 待实施 |
| `src/services/knowledge-sync.ts` | MODIFY | 12 | COMPONENT | ✅ |
| `src/app/api/knowledge/documents/[id]/progress/route.ts` | MODIFY | 13 | API | ⬜ 待实施 |
| `src/services/knowledge-sync.ts` | MODIFY | 14 | COMPONENT | ✅ |
| `src/app/api/knowledge/sync/route.ts` | MODIFY | 14 | API | ✅ |
| `src/components/knowledge/knowledge-base-panel.tsx` | MODIFY | 14 | COMPONENT | ✅ |
| `agrisynapse: grounding.ts, index.vue(x2)` | MODIFY | 15 | FRONTEND | ✅ |
| `src/services/index-job-manager.ts` | MODIFY | 16 | COMPONENT | ✅ |
| `src/services/knowledge-sync.ts` | MODIFY | 16 | COMPONENT | ✅ |
| `src/app/api/knowledge/sync/route.ts` | MODIFY | 16 | API | ✅ |
| `src/app/api/knowledge/sync/cancel/route.ts` | CREATE | 16 | API | ✅ |
| `agrisynapse: grounding.ts, index.vue(x2)` | MODIFY | 17 | FRONTEND | ✅ |
