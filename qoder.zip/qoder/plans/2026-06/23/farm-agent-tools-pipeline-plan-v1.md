# farm-agent-tools-pipeline-plan-v1

## PLAN 元信息

- **Plan 名称**: farm-agent-tools-pipeline-v1
- **启动时间**: 2026-06-06
- **主导 AI**: Qoder
- **关联文档**:
  - Spec: `.qoder/specs/tools-calling-pipeline/spec.md`
  - Tasks: `.qoder/specs/tools-calling-pipeline/tasks.md`
  - Checklist: `.qoder/specs/tools-calling-pipeline/checklist.md`
  - Handoff: `.qoder/plans/farm-agent-tools-pipeline-handoff-v2.md`
  - Review: `.qoder/reviews/farm-agent-tools-pipeline-review-v1.md`
  - Review (runtime v1): `.qoder/reviews/farm-agent-tools-pipeline-review-runtime-v1.md`
  - Review (runtime v2): `.qoder/reviews/farm-agent-tools-pipeline-review-runtime-v2.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| prisma/schema.prisma | SCHEMA | SCHEMA_MODIFIED | 现有 User/Task/Project 等表 | 新增 farm_server_credential/user_profile 表，User 新增 SERVICE role | ✅ 已实施 |
| src/lib/auth/credential-store.ts | COMPONENT | COMPONENT_CREATED | 无 | auth 层 token 持久化模块（唯一引用 prisma.farmServerCredential） | ✅ 已实施 |
| src/lib/farm-server-client.ts | COMPONENT | COMPONENT_CREATED | 无 | 通用 HTTP 模块，支持 bearer/qweather 双 auth，bearer token 从 credential-store 获取 | ✅ 已实施 |
| src/app/api/agent/[hash]/route.ts | API_ROUTE | API_ROUTE_CREATED | 无 | 单一入口端点：GET 只读（thread/dashboard/report），POST 写操作（handshake/chat SSE），语义零泄露 | ✅ 已实施 |
| src/agents/tools/impl/weather-tools.ts | COMPONENT | COMPONENT_CREATED | 无（co-agent有） | 从 co-agent 迁移，改用 farm-server-client | ✅ 已实施 |
| src/agents/tools/impl/time-tools.ts | COMPONENT | COMPONENT_CREATED | 无（co-agent有） | 从 co-agent 迁移 | ✅ 已实施 |
| src/agents/tools/impl/soil-moisture-tool.ts | COMPONENT | COMPONENT_CREATED | 无 | ~~土墒数据查询工具~~ → 统一合并为 farm-data-tools.ts | ⚠️ 已合并 |
| src/agents/tools/impl/insect-data-tool.ts | COMPONENT | COMPONENT_CREATED | 无 | ~~虫情数据查询工具~~ → 统一合并为 farm-data-tools.ts | ⚠️ 已合并 |
| src/agents/tools/impl/insect-type-tool.ts | COMPONENT | COMPONENT_CREATED | 无 | ~~虫害类别查询工具~~ → 统一合并为 farm-data-tools.ts | ⚠️ 已合并 |
| src/agents/tools/impl/farm-weather-tool.ts | COMPONENT | COMPONENT_CREATED | 无 | ~~Farm-Server 气象站数据工具~~ → 统一合并为 farm-data-tools.ts | ⚠️ 已合并 |
| src/agents/tools/impl/massif-tool.ts | COMPONENT | COMPONENT_CREATED | 无 | ~~地块查询工具~~ → 统一合并为 farm-data-tools.ts | ⚠️ 已合并 |
| src/agents/tools/schemas/weather-tools.ts | SCHEMA | SCHEMA_CREATED | 无 | Zod 校验 schema | ✅ 已实施 |
| src/agents/tools/schemas/time-tools.ts | SCHEMA | SCHEMA_CREATED | 无 | Zod 校验 schema | ✅ 已实施 |
| src/agents/tools/schemas/farm-data-tools.ts | SCHEMA | SCHEMA_CREATED | 无 | Zod 校验 schema（BasePageParams + 各工具 schema） | ✅ 已实施 |
| src/agents/tools/index.ts | COMPONENT | COMPONENT_MODIFIED | 已注册14个工具（无天气/时间/Farm-Server） | 新增 farm-data/weather/time 工具注册 | ✅ 已实施 |
| src/agents/index.ts | COMPONENT | COMPONENT_MODIFIED | 无 toolNode | 添加 ToolNode + 条件路由边 | ✅ 已实施 |
| src/lib/hash-path.ts | COMPONENT | COMPONENT_CREATED | 无 | 动态 hash 路径生成模块：`process.env.HASH_SEED_TEXT` + 10分钟时间窗口 seed → SHA-256，种子文字不硬编码 | ✅ 已实施 |
| src/middleware.ts | COMPONENT | COMPONENT_CREATED | 无 | session 校验 + hash 路径验证中间件，hash 不匹配直接 404 | ✅ 已实施 |
| docs/.../决策管线架构说明书.md | DOC | DOC_UPDATED | 零工具调用内容 | 补充 toolNode 章节 | ✅ 已实施 |
| ~~src/lib/weather-dev-logger.ts~~ | ~~COMPONENT~~ | ~~COMPONENT_CREATED~~ | ~~无~~ | ~~天气工具 Layer1 审计~~ | ❌ 已取消 — 经 runtime review 裁决，per-tool L1/L2 文件为过度设计，改为工具内直接 import agentAudit/writeAuditLog |
| ~~src/lib/weather-audit.ts~~ | ~~COMPONENT~~ | ~~COMPONENT_CREATED~~ | ~~无~~ | ~~天气工具 Layer2 审计~~ | ❌ 已取消 |
| ~~src/lib/time-tool-dev-logger.ts~~ | ~~COMPONENT~~ | ~~COMPONENT_CREATED~~ | ~~无~~ | ~~时间工具 Layer1 审计~~ | ❌ 已取消 |
| ~~src/lib/time-tool-audit.ts~~ | ~~COMPONENT~~ | ~~COMPONENT_CREATED~~ | ~~无~~ | ~~时间工具 Layer2 审计~~ | ❌ 已取消 |
| ~~src/lib/farm-server-client-dev-logger.ts~~ | ~~COMPONENT~~ | ~~COMPONENT_CREATED~~ | ~~无~~ | ~~farm-server-client Layer1 审计~~ | ❌ 已取消 |
| ~~src/lib/farm-server-client-audit.ts~~ | ~~COMPONENT~~ | ~~COMPONENT_CREATED~~ | ~~无~~ | ~~farm-server-client Layer2 审计~~ | ❌ 已取消 |
| **src/agents/tools/impl/*.ts** | **COMPONENT** | **COMPONENT_MODIFIED** | **自造 farmDataAudit/weatherToolAudit console.log，6 文件零日志** | **工具层统一接入 agentAudit(L1)+writeAuditLog(L2)，业务/技术分层** | **🔄 待实施 — 见 runtime review v1 F1-F4** |
| src/agents/nodes/response.ts | COMPONENT | COMPONENT_MODIFIED | buildToolExecutionSummary 硬编码 parsed.data.data.list 三级嵌套路径提取工具结果记录数 | 新增 State.toolResults 结构化字段，消除跨节点 JSON 解析歧义；同时 buildToolExecutionSummary 增加结构探测降级逻辑 | 🔄 待实施 — 见 runtime review v2 F7-F9 |

---

## 一、背景与目标

### 1.1 问题现状

1. **管线缺 toolNode**：farm-agent 的 LangGraph 管线只有 6 个节点（intention → retrieval → reasoning → interactionPointDetection → verdict → response），没有工具调用节点。LLM 无法自主调用外部 API 获取数据。
2. **天气/时间工具丢失**：co-agent 在 5月20日实现了完整的天气和时间 LangChain Tool，但 farm-agent 从 co-agent 复制时主动排除了这些文件（当时 farm-agent 同步给 codein2027 开源，不宜暴露含 API 凭据的工具）。
3. **Farm-Server 数据未接入**：agrisynapse 的 9 个技能卡片（农情日报、病虫害识别等）需要 Farm-Server 的土墒、虫情、气象站、地块等真实农场数据，目前完全没有对接。
4. **认证体系缺失**：farm-agent 作为独立服务，需要自己的认证层，同时需要管理 per-user 的 Farm-Server token 以支持 agent 意外重启后的任务恢复。
5. **架构文档缺失**：决策管线架构说明书 1615 行中仅 1 处提及"工具"，toolNode 的设计和拓扑完全没有文档化。

### 1.2 目标

- 补齐工具调用架构文档
- 建立三层认证体系（神经元→farm-agent、farm-agent→Farm-Server、LLM tool 隔离）
- 建立通用 HTTP 客户端（farm-server-client.ts）
- 迁移天气/时间工具
- 新增 Farm-Server 数据工具
- 管线集成 toolNode，使 LLM 能自主调用工具
- 提供 agrisynapse 对接的 HTTP API（handshake、chat SSE、thread 查询、报告导出）
- 支持 GUI 断开/agent 重启后的任务恢复

---

## 二、方案选型

### 2.1 认证架构选型

#### 神经元→farm-agent 认证

| 方案 | 描述 | 结论 |
|------|------|------|
| A: 单独 service_account 表 | 新建神经元专用认证表 | ❌ 过度设计 |
| B: 复用 User 表 + SERVICE role | 神经元作为一个 User，新增 `SERVICE` role 枚举值 | ✅ 采用 |

#### farm-agent→Farm-Server 认证

| 方案 | 描述 | 结论 |
|------|------|------|
| A: agrisynapse 每次请求传 token | 不持久化，GUI 关闭或 agent 重启任务丢失 | ❌ 脆断 |
| B: farm_server_credential 持久化 per-user token | auth 层管理，支持 refresh，重启可恢复 | ✅ 采用 |
| C: service account 全量拉取 | 定时 cron 拉全量 Farm-Server 数据到缓存 | ❌ agent 不做定时任务 |

#### LLM 安全隔离

| 方案 | 描述 | 结论 |
|------|------|------|
| 代码模块隔离 | `prisma.farmServerCredential` 仅在 `src/lib/auth/` 下 import，LLM tool 文件零引用 | ✅ 采用 |

#### 端点路径安全（动态 hash 路径）

| 方案 | 描述 | 结论 |
|------|------|------|
| 静态路径 `/api/agent/chat` | 攻击者可枚举爆破 | ❌ |
| 随机取产品文档段 SHA-256 | 安全但心智负担高（需记住取了哪段） | ❌ |
| 固定需求文字 + 变动算法（日期 seed） | 同一段需求描述，seed 按时间窗口滚动，双方各自纯函数计算，零同步开销 | ✅ 采用 |

**hash 生成规则：**
```
hash = SHA-256(REQUIREMENT_TEXT + TIME_WINDOW).slice(0, 12)
TIME_WINDOW = Math.floor(Date.now() / 600000) // 每 10 分钟一个窗口
```

9 段需求描述来自 `docs/.../00-需求/` 目录下产品文档关键段落，一次定义不再变动。
攻击者搞到文档算不出 hash（不知道 seed 是时间窗口），抓到今天的 hash 10 分钟后 404。

### 2.2 HTTP 客户端选型

| 方案 | 职责边界 | 代码复用 | 审计粒度 | 结论 |
|------|---------|---------|---------|------|
| A: 所有 Farm-Server 接口耦合在一个 HTTP 模块 | 模糊 | 无 | 粗 | ❌ |
| B: farm-server-client 只做通用 HTTP + 可插拔 auth，每个工具独立实现 | 清晰 | 高 | 细 | ✅ 采用 |

### 2.3 专家能力加载策略

与 agrisynapse 9 个技能卡片(报告分析: 农情日报/周报分析/生长报告; 诊断分析: 病虫害识别/营养诊断/天气影响; 规划建议: 作业规划/种植建议/农机调度)对应的专家加载策略：

| 分类 | 数量 | 专家 | 加载策略 |
|------|------|------|---------|
| 热加载（握手时异步预载） | 3 | 农情日报、天气影响、作业规划 | 用户连接即预取 Farm-Server 数据(用 massifId 精确查)，早于仪表盘推荐问题或技能卡片点击 |
| 惰性加载（技能卡片触发） | 6 | 周报分析、生长报告、病虫害识别、营养诊断、种植建议、农机调度 | 用户点击对应技能卡片时按需调 Farm-Server |

### 2.4 数据过滤策略

| 方案 | 描述 | 结论 |
|------|------|------|
| A: service account 拉全量 + farm-agent 内存过滤 responsible_massif_ids | 浪费 Farm-Server 和 agent 算力 | ❌ |
| B: 用用户 token + massifId 精确查 Farm-Server | Farm-Server API 原生支持 massifId 过滤参数，直接筛选 | ✅ 采用 |

---

## 三、架构设计

### 3.1 三层认证栈

```
┌─ 层 1: agrisynapse → farm-agent ───────────────────────┐
│  agrisynapse 以 SERVICE role User 登录，session cookie  │
│  middleware 校验 session，未登录 → 401                  │
├─ 层 2: farm-agent → Farm-Server ────────────────────────┤
│  farm_server_credential 表存储 per-user token           │
│  auth 层管理 refresh 生命周期，LLM tool 不可达          │
├─ 层 3: LLM tool 数据隔离 ───────────────────────────────│
│  tool 只调 Farm-Server 固定接口 + ChromaDB 知识库       │
│  禁止文件系统/通用 HTTP/代码执行 tool                  │
└─────────────────────────────────────────────────────────┘
```

### 3.2 数据库 Schema 新增

```
farm_server_credential (auth 层专用，Agent tool 零访问)
├── id
├── user_id          (Farm-Server 用户 ID)
├── access_token     (encrypted)
├── refresh_token    (encrypted)
├── expires_at
├── created_at
└── updated_at

user_profile (Agent tool 可读，非敏感)
├── id
├── user_id          (Farm-Server 用户 ID，与 credential 关联)
├── nickname
├── dept_id
├── dept_name
├── email
├── mobile
├── preferences       (JSON，偏好设置)
├── tags              (JSON，用户标签)
├── responsible_massif_ids (JSON，负责地块 ID 列表)
├── created_at
└── updated_at

User 表扩展
├── role 新增枚举值: ROOT | STAFF | SERVICE
```

### 3.3 HTTP API（对 agrisynapse 暴露，语义零泄露单端点）

所有操作通过单一端点 `/api/agent/{hash}` 完成，hash 10 分钟滚动。GET/POST 本身即区分读写语义，query params 和 body 在 HTTPS 下不可见。

```
GET  /api/agent/{hash}?action=thread&id=xxx    → 查询对话历史和进度
GET  /api/agent/{hash}?action=report&id=xxx&format=md → 导出分析报告
GET  /api/agent/{hash}?action=dashboard        → 技能卡片 + 推荐话题

POST /api/agent/{hash}
  body.type: "handshake"  → 握手：接收 token+UserVO，存 credential+upsert user_profile，预载热加载专家
  body.type: "chat"       → 对话：SSE stream
```

攻击者视角：仅看到一个随机 hex 端点，不知道服务类型、不知道操作能力、不知道参数格式。

### 3.3.1 agrisynapse → farm-agent API 合约（实施时 ADD-01 展开为代码）

> 以下为 agrisynapse GUI 需要对接的全部接口。所有请求须携带 session cookie（SERVICE role User 登录态）。实施时由 ADD-01 展开为 Next.js Route Handler 代码。

#### 前置：hash 计算（两端纯函数，零同步）

```typescript
// agrisynapse/src/utils/farm-agent-hash.ts
const HASH_SEED = process.env.HASH_SEED_TEXT!;  // .env 注入，不硬编码

export function getFarmAgentHash(): string {
  const window = Math.floor(Date.now() / 600_000);  // 10 分钟窗口
  return crypto.createHash('sha256')
    .update(HASH_SEED + window)
    .digest('hex')
    .slice(0, 12);
}
```

所有请求 URL = `${farmAgentBase}/api/agent/${getFarmAgentHash()}`。

#### ① 登录

```
POST /api/auth/login  { username, password }
→ session cookie (SERVICE role)
→ 失败 401
```

凭据来自 agrisynapse `.env`（`AGENT_SERVICE_USERNAME` / `AGENT_SERVICE_PASSWORD`），farm-agent 种子脚本创建同名账号。

#### ② 仪表盘

```
GET /api/agent/{hash}?action=dashboard
→ { cards: [...9个技能卡片], topics: [...推荐话题], nextHash }
→ hash 不对 404
→ 未登录 401
```

#### ③ 握手

```
POST /api/agent/{hash}
body: { type: "handshake", token, refreshToken, user: { id, username, nickname, deptId, deptName, email, mobile } }
→ { threadId, nextHash }
→ token 无效 { error: "TOKEN_EXPIRED" }
```

#### ④ 对话（SSE stream）

```
POST /api/agent/{hash}
body: { type: "chat", threadId, message }
→ SSE stream: thinking | tool_call | tool_result | token | done | error
```

#### ⑤ 查询历史

```
GET /api/agent/{hash}?action=thread&id=xxx
→ { threadId, status, messages: [...] }
```

#### ⑥ 导出报告

```
GET /api/agent/{hash}?action=report&id=xxx&format=md
→ { content, format }
```

#### 错误码

| HTTP | 含义 | agrisynapse 动作 |
|------|------|-----------------|
| 401 | session 过期 | 重新 login |
| 404 | hash 过期（10min） | 重新算 hash 重试 |
| 200 + TOKEN_EXPIRED | Farm-Server token 不可恢复 | 重新登录 Farm-Server → handshake |
| SSE event:error | 对话异常 | 显示错误，保留 threadId |

#### nextHash 机制（窗口切换零中断）

hash 10 分钟滚动，两端时钟可能有微小偏差。farm-agent 在每个响应中附带 `nextHash`（下一窗口的 hash），agrisynapse 缓存后用于窗口切换时的无缝过渡。

**farm-agent 生成**（`hash-path.ts`）：
```typescript
export function getNextHash(): string {
  const nextWindow = Math.floor(Date.now() / 600_000) + 1;
  return sha256(HASH_SEED_TEXT + nextWindow).slice(0, 12);
}
```
所有非 SSE 响应和 SSE `done` 事件均附带 `nextHash`。

**agrisynapse 消费**（`farm-agent-hash.ts`）：
1. 每次收到响应 → `updateHashFromResponse(resp)` 缓存 `nextHash`
2. 每次发请求 → `getRequestHash()`：本地 hash ≠ 上次 activeHash 且有 nextHash → 用 nextHash
3. 收到 404 → `getFallbackHash()` 本地算 ±1 窗口重试
4. 全部 404 → 重新 login + handshake

详细实现见 `.qoder/plans/farm-agent-tools-pipeline-handoff-v2.md` §2.1.9。

### 3.4 握手时序

```
agrisynapse                              farm-agent
    │                                        │
    │── login(username, password) ──────────→│ session cookie
    │←── { ok, session } ────────────────────│
    │                                        │
    │── handshake(token, UserVO) ───────────→│
    │                                        │── 存 token → farm_server_credential
    │                                        │── upsert → user_profile (对比更新)
    │                                        │── 异步预载 3 个热加载专家 (massifId 精确查)
    │←── { threadId, ok } ──────────────────│
    │                                        │
    │── chat(threadId, msg) ────────────────→│
    │←── SSE stream ────────────────────────│
    │                                        │
    (用户关 GUI)                             │
    │                                        │── agent 继续执行 pending 任务
    │                                        │── token 过期 → refresh → 更新 credential
    │                                        │
    (用户重开 GUI)                            │
    │── login ──────────────────────────────→│
    │── handshake(token, UserVO) ───────────→│ 新 token 覆盖
    │── GET /thread/{threadId} ─────────────→│
    │←── { status, messages } ──────────────│ 任务结果不丢失
    │                                        │
    (agent 意外重启)                          │
    │                                        │── 重启后从 credential 恢复 token
    │                                        │── 继续 pending 任务
```

### 3.5 Agent 代码模块架构

```
src/lib/auth/                    ← auth 层（唯一引用 credential 表）
├── credential-store.ts          → prisma.farmServerCredential CRUD
└── token-manager.ts             → refresh 逻辑 + 过期判断 + 来源区分

src/lib/hash-path.ts             ← 动态 hash 路径模块
  → generateHash(): SHA-256(process.env.HASH_SEED_TEXT + 10分钟窗口) → 12位 hex
  → validateHash(hash): 验证 ±1 窗口容差
  → HASH_SEED_TEXT 在 .env 中，不硬编码

src/lib/farm-server-client.ts    ← 通用 HTTP（可插拔 auth）
  ├── createClient({ auth: "bearer", getToken })
  │   → Farm-Server 工具用，token 来自 credential-store
  └── createClient({ auth: "qweather" })
      → 天气工具用，JWT EdDSA

src/app/api/agent/[hash]/        ← 单一 Route Handler（含动态 hash 路径）
  └── route.ts                   → GET(thread/dashboard/report) + POST(handshake/chat SSE)

src/agents/tools/impl/           ← LLM 可调用的 tool
├── weather-tools.ts             ← 只 import farm-server-client(qweather)，不碰 credential
├── time-tools.ts
├── soil-moisture-tool.ts
├── insect-data-tool.ts
├── insect-type-tool.ts
├── farm-weather-tool.ts
└── massif-tool.ts
```

### 3.5.1 Tool 结果序列化格式规范（Runtime Review v2 回流 — 2026-06-23）

> **背景**: Runtime Review v2 F7 发现 ToolNode 序列化格式与 Response 节点解析路径存在契约缺失，导致 LLM prompt 中工具结果摘要 `recordCount` 永远为 0。

#### 工具返回值契约（Producer: ToolNode）

所有 Farm-Server 数据工具（`farm-data-tools.ts`）返回统一平铺格式：

```typescript
// 工具返回值 — 由 ToolNode 包装器 JSON.stringify 后存入 ToolMessage.content
{
  success: boolean          // 执行是否成功
  total: number             // 总记录数
  list: Record<string, unknown>[]  // 数据列表
  columns: { prop: string; label: string }[]  // 列定义
  // 失败时：
  error?: string            // 错误信息，success=false 时存在
}
```

#### 工具结果消费契约（Consumer: Response 节点）

Response 节点的 `buildToolExecutionSummary` 通过以下优先级提取记录数：

1. `State.toolResults`（推荐 — 结构化字段，消除 JSON 解析歧义）
2. `ToolMessage JSON → parsed.list`（降级 — 兼容平铺格式）
3. `ToolMessage JSON → parsed.data.data.list`（降级 — 兼容嵌套格式）

#### LangGraph State 扩展

在 `AgentState` 中新增 `toolResults` 字段作为跨节点的结构化数据通道：

```typescript
// src/agents/state.ts
toolResults: Annotation<Array<{
  toolName: string
  success: boolean
  recordCount: number
  list: unknown[]
  columns?: { prop: string; label: string }[]
  error?: string
}>>
```

- **写入方**: ToolNode 包装器（`src/agents/index.ts`），工具执行后同时写入 `messages` 和 `toolResults`
- **消费方**: Response 节点（`buildToolExecutionSummary`）、Reasoning 节点（`toolResultsBlock`）
- **设计原则**: 消除 "JSON Stringify → Parse → 字段探测" 的不确定链，用 TypeScript 类型系统强制契约一致性

---

## 四、实施步骤 + 依赖图

```
Task 0 (Schema 迁移) ──────────────────────────┐
Task 1 (credential-store + auth 层) ────────────┤ 可并行
Task 2 (hash-path 模块) ────────────────────────┤ 可并行
Task 3 (farm-server-client) ────────────────────┘
                    │
                    ▼
Task 4 (单端点 Route: GET+POST) ─────────────────┐
                    │
                    ▼
Task 5 (天气/时间工具迁移) ──┐
Task 6 (Farm-Server 数据工具) ─┤ 可并行
                    │
                    ▼
Task 7 (管线集成 toolNode)
                    │
                    ▼
Task 8 (middleware + 神经元 User 账号)
                    │
                    ▼
Task 9 (编译验证 + 端到端)
```

### Task 0: Schema 迁移

1. Prisma schema 新增 `farm_server_credential` 表
2. Prisma schema 新增 `user_profile` 表
3. User 表 Role 枚举新增 `SERVICE`
4. `npx prisma migrate dev`

### Task 1: Auth 层 + credential-store

- 创建 `src/lib/auth/credential-store.ts`
  - `saveToken(userId, accessToken, refreshToken, expiresAt)`
  - `getValidToken(userId)` → 检查过期，过期则尝试 refresh
  - `refreshUserToken(userId)` → POST /system/auth/refresh-token
  - 全局唯一引用 `prisma.farmServerCredential` 的模块
- 创建 `src/lib/auth/token-manager.ts`
  - 区分请求来源（神经元 vs 自有 UI）
  - refresh 失败时：神经元返回 `TOKEN_EXPIRED`，自有 UI → 302 /login

### Task 2: hash-path 动态路径模块

- 创建 `src/lib/hash-path.ts`
- `.env` 新增 `HASH_SEED_TEXT` 环境变量（需求文档关键段落，不硬编码到代码）
- agrisynapse 侧同样配置同值 `HASH_SEED_TEXT`
- `generateHash()` → `SHA-256(process.env.HASH_SEED_TEXT + Math.floor(Date.now() / 600000)).slice(0, 12)`
- `validateHash(hash)` → 验证当前窗口 ±1 窗口容差

### Task 3: farm-server-client.ts 通用 HTTP 模块

- 创建 `src/lib/farm-server-client.ts`
- ~~创建 `src/lib/farm-server-client-dev-logger.ts`（Layer1）~~ — 已取消（runtime review 裁决：工具内直接 import agentAudit）
- ~~创建 `src/lib/farm-server-client-audit.ts`（Layer2）~~ — 已取消
- 实现 `createClient({ baseUrl, auth, getToken? })`
  - `auth: "bearer"` → `getToken` 从 credential-store 获取有效 token
  - `auth: "qweather"` → 内聚 JWT EdDSA 签名逻辑，凭据在 `.env`
- 统一 `request(method, path, params)` 入口

### Task 4: API Route（单一入口端点，语义零泄露）

- 创建 `src/app/api/agent/[hash]/route.ts`
- **GET 处理**（只读）：
  - `?action=thread&id=xxx` → 查询对话历史和进度
  - `?action=report&id=xxx&format=md` → 导出分析报告
  - `?action=dashboard` → 返回技能卡片 + 推荐话题
- **POST 处理**（写操作）：
  - `body.type: "handshake"` → 接收 token+UserVO，存 credential + upsert user_profile，异步预载 3 个热加载专家
  - `body.type: "chat"` → LangGraph agent 执行，SSE stream 响应
- 攻击者视角：仅看到一个随机 hex URL，不知道 GET/POST 背后的操作类型和参数格式

### Task 5: 天气和时间工具迁移

- 从 co-agent 复制核心文件，修改 weather-tools.ts：用 `farm-server-client`（qweather auth）替代内部 HTTP + JWT 逻辑
- ~~4 个独立审计日志文件~~ — 已取消

### Task 6: Farm-Server 数据工具（统一合并为 farm-data-tools.ts）

以 6 份详细 API 文档为准（旧的 Farm-Server 汇总文档作废，`code: 0` → `code: 200`）：
- `docs/.../02-规范/土墒数据管理接口文档.md`
- `docs/.../02-规范/气象数据管理接口文档.md`
- `docs/.../02-规范/虫情数据管理接口文档.md`
- `docs/.../02-规范/虫害类别管理接口文档.md`
- `docs/.../02-规范/地块基本信息管理接口文档.md`
- `docs/.../02-规范/管理后台 - 用户管理接口文档.md`（握手时调 `/system/user/get` 获取用户详情）

API 规范要点：`code: 200`（非 0）、分页参数必填、pageSize 最大 200。
**没有 `tenant-id` 通用 Header**。

数据查询全部使用 per-user token + massifId 精确过滤，不拉全量。

| 工具 | 工具名 | 接口 | 参考文档 |
|------|--------|------|---------|
| soil-moisture-tool.ts | `query_soil_moisture` | `/moisture-data/get`, `/moisture-data/page` | 土墒数据管理接口文档 |
| insect-data-tool.ts | `query_insect_data` | `/insect-data/get`, `/insect-data/page` | 虫情数据管理接口文档 |
| insect-type-tool.ts | `query_insect_type` | `/insect-type/get`, `/insect-type/page` | 虫害类别管理接口文档 |
| farm-weather-tool.ts | `query_farm_weather` | `/weather-data/get`, `/weather-data/page` | 气象数据管理接口文档 |
| massif-tool.ts | `query_massif` | `/massif/get`, `/massif/page` | 地块基本信息管理接口文档 |

### Task 7: 管线集成 toolNode

- 修改 `src/agents/tools/index.ts`：注册天气/时间/Farm-Server 工具
- 修改 `src/agents/index.ts`：添加 ToolNode + 条件路由边
- **🆕（Runtime Review v2 回流）**: 定义 ToolNode→Response 数据契约
  - State 新增 `toolResults` 结构化字段（`src/agents/state.ts`）
  - ToolNode 写入 `toolResults`（`src/agents/index.ts`）
  - Response 节点 `buildToolExecutionSummary` 优先消费 `state.toolResults`，降级兼容 ToolMessage JSON 解析（`src/agents/nodes/response.ts`）

### Task 8: Middleware + 神经元账号

- 创建 `src/middleware.ts`：session 校验 + hash 路径验证（hash 不匹配 → 404，session 无效 → 401）
- 创建种子脚本：生成 agrisynapse 的 SERVICE role User 账号（用户名/密码来自环境变量）

### Task 9: 编译验证

- `npx tsc --noEmit`
- `npm run build`
- 端到端：agrisynapse 登录 → handshake → chat → 验证 SSE 流

---

## 五、验收标准

- [ ] Prisma schema 新增 credential/user_profile 表，User 新增 SERVICE role，migrate 成功
- [ ] credential-store 隔离：仅 `src/lib/auth/` import，0 个 tool 文件引用
- [ ] agrisynapse SERVICE 账号可登录 farm-agent
- [ ] middleware：hash 不匹配 → 404（无任何响应体），session 无效 → 401
- [ ] hash 每 10 分钟自动滚动，±1 窗口容差正常
- [ ] 单端点 `/api/agent/{hash}`：GET(thread/dashboard/report) + POST(handshake/chat SSE) 全部正常
- [ ] handshake：存 token、upsert user_profile、预载热加载专家
- [ ] chat API：SSE stream 正常输出，tool_call 阶段可调 Farm-Server
- [ ] token 过期自动 refresh，失败时区分来源返回
- [ ] GUI 关闭后 agent 任务不中断
- [ ] agent 重启后从 credential 恢复 token，pending 任务继续
- [ ] Farm-Server 5个工具 + 天气/时间工具编译通过
- [ ] tools/index.ts 注册所有工具
- [ ] 管线添加 toolNode 节点 + 条件路由边
- [ ] `npm run build` 成功
- [ ] ADD-2 阶段标记对称
- [ ] ADD-4 三通道输出（console + file + DB）— 🔄 工具层 L1/L2 接入待实施
- [ ] ADD-5 审计数据回写 DB — 🔄 工具层 writeAuditLog 接入待实施

### Review 回流记录（2026-06-15 Runtime Review v1）

| Review 发现 | 优先级 | Plan 修正 | 状态 |
|------------|--------|----------|------|
| F1 工具日志未接入 agentAudit/writeAuditLog | P0 | ADD-7 审计策略表：取消 per-tool L1/L2 文件，新增集中式改造任务 | 🔄 |
| F2 业务/技术日志混在同一函数 | P1 | Task 3/5/6：移除 per-tool L1/L2 文件承诺 | ✅ 已回流 |
| F3 6 个工具文件零日志 | P1 | ADD-7 审计策略表：新增 8 文件接入任务 | 🔄 |
| F4 Plan 承诺的 6 个 L1/L2 文件未创建 | P2 | 标记为已取消（取消原因记录在审计策略表） | ✅ 已回流 |

### Review 回流记录（2026-06-23 Runtime Review v2）

| Review 发现 | 优先级 | Plan 修正 | 状态 |
|------------|--------|----------|------|
| F7 ToolNode 序列化格式与 Response 解析路径契约缺失 → LLM 永远收到 recordCount=0 | P0 | §3.5.1 新增 Tool 结果序列化格式规范；§4 Task 7 追加数据合约子任务；ADD-7 审计策略表追加 response.ts 修复项；§6 新增架构决策记录 | ✅ 已回流 |
| F8 unwrapPageResponse 拍扁格式未同步上层解析路径 | P1 | §3.5.1 工具返回值契约明确定义平铺格式；State.toolResults 消除中介拍扁影响 | ✅ 已回流 |
| F9 数据提取路径单一无结构探测降级 | P2 | §3.5.1 消费契约定义三级提取优先级（State.toolResults → parsed.list → parsed.data.data.list） | ✅ 已回流 |

---

## 六、架构决策记录

| 决策 | 内容 |
|------|------|
| 神经元认证 | 复用 User 表 + SERVICE role，不新建 service_account 表 |
| Token 持久化 | `farm_server_credential` 表存 per-user token/refresh_token |
| 安全隔离 | credential 表仅 auth 层 import，LLM tool 零引用；不建文件/HTTP/代码执行 tool |
| 端点安全 | 动态 hash 单端点：需求文字+10分钟窗口→SHA-256，`/api/agent/{hash}` 无语义，GET/POST 内置分发，hash 不匹配 → 404 |
| agrisynapse 适配 | 1 个新文件 `getFarmAgentHash()`（~15行），同段需求文字+时间窗口纯函数计算，URL 拼接方式修改 |
| 专家加载 | 3 热加载（握手预载）+ 6 惰性（技能卡片触发） |
| 数据查询 | per-user token + massifId 精确查 Farm-Server，不全量拉取 |
| 任务恢复 | token 持久化支撑 GUI 断开 + agent 重启恢复 |
| Token 过期 | refresh 失败时区分来源：神经元返回 TOKEN_EXPIRED，自有 UI 重定向 /login |
| 用户分表 | `user_profile` 存基础信息+偏好+地块，握手时对比更新，允许迟滞 |
| **🆕 ToolNode→Response 数据契约** | State 新增 `toolResults` 结构化字段作为跨节点数据通道，消除 JSON Stringify → Parse → 字段探测的不确定链；ToolNode 写入、Response/Reasoning 消费，TypeScript 类型系统强制一致性（见 §3.5.1） |

---

## 七、关联文档

| 文档 | 路径 |
|------|------|
| Spec | `.qoder/specs/tools-calling-pipeline/spec.md` |
| Tasks | `.qoder/specs/tools-calling-pipeline/tasks.md` |
| Checklist | `.qoder/specs/tools-calling-pipeline/checklist.md` |
| Handoff | `.qoder/plans/farm-agent-tools-pipeline-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-tools-pipeline-review-v1.md` |
| Review (runtime v1) | `.qoder/reviews/farm-agent-tools-pipeline-review-runtime-v1.md` |
| Review (runtime v2) | `.qoder/reviews/farm-agent-tools-pipeline-review-runtime-v2.md` |
| 土墒数据 API | `docs/.../02-规范/土墒数据管理接口文档.md` |
| 气象数据 API | `docs/.../02-规范/气象数据管理接口文档.md` |
| 虫情数据 API | `docs/.../02-规范/虫情数据管理接口文档.md` |
| 虫害类别 API | `docs/.../02-规范/虫害类别管理接口文档.md` |
| 地块管理 API | `docs/.../02-规范/地块基本信息管理接口文档.md` |
| 用户管理 API | `docs/.../02-规范/管理后台 - 用户管理接口文档.md` |
| 旧汇总文档（已作废） | `docs/.../02-规范/Farm-Server Web API 接口文档.md` |
