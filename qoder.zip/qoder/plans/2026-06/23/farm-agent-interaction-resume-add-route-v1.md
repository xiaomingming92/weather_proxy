# farm-agent-interaction-resume-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。
>
> **绑定**：Plan: `farm-agent-interaction-resume-fix-plan-v1.md` · Spec: `specs/farm-agent-interaction-resume-fix/spec.md` · Tasks: `specs/farm-agent-interaction-resume-fix/tasks.md` · Handoff: `farm-agent-interaction-resume-fix-handoff-v1.md`

---

## Step 0：文档先行

**状态**: ✅ 完成

**产出**:
- [x] Specs 三元组: `specs/farm-agent-interaction-resume-fix/{spec,tasks,checklist}.md`
- [x] 项目文档: 无需更新（纯 bug fix，不改变外部 API 契约）
- [x] Handoff: ✅ 已生成

### 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: 交互点确认后，图 State 完整保留（evidenceChain/reasoningPath 不丢失）

Task Groups:
  Phase 1 (后端interrupt): 不能用 — 没有前端适配，用户无法确认交互点
  Phase 2 (前端resume):  不能用 — 没有后端interrupt，resumeAgent 没有断点可恢复
  Phase 3 (验证):        不能用 — 验证不产生业务功能

判定结论: 需要 1 轮（1 个原子闭包）

第1轮: Phase 1 + Phase 2 + Phase 3 — 业务功能: 交互点确认后 State 完整保留
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## Step 1：审计阶段定义

**状态**: ✅ 完成

| Phase | 使用场景 | Task |
|-------|---------|------|
| `INTERACTION_INTERRUPT` | 图暂停等交互 | Task 1.1 ✓ |
| `INTERACTION_RESUME` | 用户确认后恢复流 | Task 2.1-2.2 ✓ |

---

## Step 2：审计基础设施确认

**状态**: ✅ 完成

`agent-audit-logger.ts` 已新增 `INTERACTION_INTERRUPT` + `INTERACTION_RESUME` 字面量。`agentAudit()` 三通道正常。

---

## Step 3：代码实现

### Task 映射表

| # | Task | 文件 | 审计点 | 依赖 | 状态 |
|---|------|------|--------|------|------|
| 1.1 | interactionPointDetection interrupt | `agents/nodes/interaction-point-detection.ts` | `agentAudit("INTERACTION_INTERRUPT", ...)` | 无 | ✅ |
| 1.2 | 图编译适配 | `agents/index.ts` | routing 不变（`interrupt()` 内置） | 1.1 | ✅ |
| 2.1 | agentChat.ts resume | `agentChat.ts` (agrisynapse) | 无（store 层） | 无 | ✅ |
| 2.2 | LlmChatView.vue 绑定 | `LlmChatView.vue` (agrisynapse) | 无（组件层） | 2.1 | ✅ |
| 3.1 | tsc 全量编译 | — | — | 1.1+1.2+2.1+2.2 | ✅ |

---

## Step 4：审计验证

**状态**: ✅ 完成

- `npx tsc --noEmit` farm-agent 零错误
- `vue-tsc --noEmit` agrisynapse 无新增错误
- RAHS = 100 🟢 HEALTHY

---

## Step 5：AI 自动合规检查

**状态**: ✅ 完成

checklist 全部 [T] 项已通过，ADD-1~ADD-4 合规。

---

## Step 6/7：条件执行

无需——Step 4/5 无异常。

---

## Step 8：收敛判断

**状态**: ✅ 完成

- 全部 [T] 项通过
- [R] 项待运行时验证（KB矛盾回归/evidenceChain保留/session残留）
- Handoff 已生成

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | 状态 |
|------|------|------|-----------|------|
| `src/agents/nodes/interaction-point-detection.ts` | MODIFY | 1.1 | NODE | ✅ |
| `src/agents/index.ts` | 不变 | 1.2 | GRAPH | ✅ |
| `agrisynapse/src/store/modules/agentChat.ts` | MODIFY | 2.1 | STORE | ✅ |
| `agrisynapse/src/views/llm/components/LlmChatView.vue` | MODIFY | 2.2 | COMPONENT | ✅ |
| `src/lib/agent-audit-logger.ts` | MODIFY | 1.1 | INFRA | ✅ |
# farm-agent-interaction-resume-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。
>
> **绑定**：Plan: `farm-agent-interaction-resume-fix-plan-v1.md` · Spec: `specs/farm-agent-interaction-resume-fix/spec.md` · Tasks: `specs/farm-agent-interaction-resume-fix/tasks.md` · Handoff: `farm-agent-interaction-resume-fix-handoff-v1.md`

---

## Step 0：文档先行

**状态**: ✅ 完成

**产出**:
- [x] Specs 三元组: `specs/farm-agent-interaction-resume-fix/{spec,tasks,checklist}.md`
- [x] 项目文档: 无需更新（纯 bug fix，不改变外部 API 契约）
- [x] Handoff: 待 Step 8 生成

### 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: 交互点确认后，图 State 完整保留（evidenceChain/reasoningPath 不丢失）

Task Groups:
  Phase 1 (后端interrupt): 不能用 — 没有前端适配，用户无法确认交互点
  Phase 2 (前端resume):  不能用 — 没有后端interrupt，resumeAgent 没有断点可恢复
  Phase 3 (验证):        不能用 — 验证不产生业务功能

判定结论: 需要 1 轮（1 个原子闭包）

第1轮: Phase 1 + Phase 2 + Phase 3 — 业务功能: 交互点确认后 State 完整保留
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## Step 1：审计阶段定义

**状态**: ⬜ 待执行

| Phase | 使用场景 | Task |
|-------|---------|------|
| `INTERACTION_INTERRUPT` | 图暂停等交互 | Task 1.1-1.2 |
| `INTERACTION_RESUME` | 用户确认后恢复流 | Task 2.1-2.2 |

---

## Step 2：审计基础设施确认

**状态**: ⬜ 待执行

复用中央 `agent-audit-logger.ts`，新增 `INTERACTION_INTERRUPT` + `INTERACTION_RESUME` 字面量。

---

## Step 3：代码实现

### Task 映射表

| # | Task | 文件 | 审计点 | 依赖 | 状态 |
|---|------|------|--------|------|------|
| 1.1 | interactionPointDetection interrupt | `agents/nodes/interaction-point-detection.ts` | `agentAudit("INTERACTION_INTERRUPT", ...)` | 无 | ⬜ |
| 1.2 | 图编译适配 | `agents/index.ts` | routing 不变 | 1.1 | ⬜ |
| 2.1 | agentChat.ts resume | `agentChat.ts` (agrisynapse) | 无（store 层） | 无 | ⬜ |
| 2.2 | LlmChatView.vue 绑定 | `LlmChatView.vue` (agrisynapse) | 无（组件层） | 2.1 | ⬜ |
| 3.1 | tsc 全量编译 | — | — | 1.1+1.2+2.1+2.2 | ⬜ |

---

## Step 4~8：留白待执行

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | 状态 |
|------|------|------|-----------|------|
| `src/agents/nodes/interaction-point-detection.ts` | MODIFY | 1.1 | NODE | ⬜ |
| `src/agents/index.ts` | MODIFY | 1.2 | GRAPH | ⬜ |
| `agrisynapse/src/store/modules/agentChat.ts` | MODIFY | 2.1 | STORE | ⬜ |
| `agrisynapse/src/views/llm/components/LlmChatView.vue` | MODIFY | 2.2 | COMPONENT | ⬜ |
| `src/lib/agent-audit-logger.ts` | MODIFY | 1.1 | INFRA | ⬜ |
