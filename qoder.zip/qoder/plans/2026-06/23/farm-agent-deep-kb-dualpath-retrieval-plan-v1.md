# farm-agent-deep-kb-dualpath-retrieval-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度（文件路径 + Phase 验收标准 + 架构维度全覆盖）。**不要**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-deep-kb-dualpath-retrieval-v1
- **启动时间**: 2026-06-17T12:00:00+08:00
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/farm-agent-deep-kb-dualpath-retrieval-add-route-v1.md`（待生成）
  - Handoff: `.qoder/plans/farm-agent-deep-kb-dualpath-retrieval-handoff-v1.md`（2 轮，已生成）
  - Review: `.qoder/reviews/farm-agent-deep-kb-dualpath-retrieval-review-v1.md`（✅ 已生成）
  - Runtime Review: `.qoder/reviews/farm-agent-deep-kb-dualpath-retrieval-review-runtime-v1.md`（🆕 2026-06-23，F1-F3: isSummary 专家工具调用阻断→证据链/推理链双空）
  - Spec: `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/spec.md`（✅ 已生成，R1.1~R2.4 共 13 条 Scenario）
  - Tasks: `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/tasks.md`（✅ 已生成，Phase 1.1~2.4）
  - Checklist: `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/checklist.md`（✅ 已生成）
- **关联 Plan**: `farm-agent-three-tier-reasoning-graph-plan-v1.md`（ACA 框架 Plan，本 Plan 为其 deep 管线改造部分的前置工程）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/caijuehub/strategies/retrieval-routing.ts | STRATEGY | STRATEGY_CREATED | 不存在；retrieval 节点内部做 grounding/fallback/双路 三元判断 | 集中裁决：输入 projectId+expertIds+groundingStatus，输出 RetrievalRoutingPlan（每个 Expert 的 searches[] 列表），节点只执行 plan 不做判断 | 待实施 |
| src/agents/nodes/retrieval.ts | COMPONENT | COMPONENT_MODIFIED | 节点内做三元路由（grounding? collection: fallback + evidenceFilter）；无 projectId 过滤；无 KB 冲突检测 | 移除三元判断，改为消费 RetrievalRoutingPlan；执行 plan.searches 并行检索；标记来源（project_kb/global_kb） | 待实施 |
| src/agents/nodes/kb-claim-extractor.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 检索 chunk → mini-LLM → KBClaim 结构体（claim + preconditions + constraints + confidence） | ~~待实施~~ ❌ P1#3 已决议移除（轻量 fan-in 替代） |
| src/agents/nodes/kb-conflict-resolver.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 确定性冲突检测（前提互斥/约束矛盾/置信度差），不可解时调用 interrupt() 暂停管线 | ~~待实施~~ ❌ P1#3 已决议移除（轻量 fan-in 替代） |
| src/agents/state.ts | COMPONENT | COMPONENT_MODIFIED | 无 kbConflictResult / kbClaims | 新增 kbConflictResult / kbClaims / kbConflictResolution | 待实施 → P0#1 需更新（kbSources + vectorDistance 相关字段替代） |
| src/agents/index.ts | COMPONENT | COMPONENT_MODIFIED | retrieval → reasoning 直连 | retrieval → kbConflictResolver → reasoning；kbConflictResolver 支持 interrupt() 暂停 | 待实施 → P0#1+P1#3 需更新（无新中间节点，仍直连） |
| src/agents/edges/conditional.ts | COMPONENT | COMPONENT_MODIFIED | 无 routeByKBConflict | 新增 routeByKBConflict（当 interrupt() 未触发时标准路由） | ~~待实施~~ ❌ P1#3+P1#6 已决议移除（无 kbConflictResolver 则无需 conditional edge） |
| src/agents/nodes/intention.ts | COMPONENT | COMPONENT_MODIFIED | explicitIntent 提前 return 使实时工具注入成为死代码（L78 阻断 L158-186） | 强制 tool_calls 注入提前到 explicitIntent 之前；isSummary 专家在所有入口路径下均产出 tool_calls | 🔴 Runtime Review F1，待实施 |
| src/agents/nodes/reasoning.ts | COMPONENT | COMPONENT_MODIFIED | isSummary 专家 toolMessages 不写回 evidenceChain；expertPackages 不自行构建 | 工具结果回写 evidenceChain + 内聚构建 expertPackages（isSummary 跳过 retrieval 时） | 🔴 Runtime Review F2/F3，待实施 |
| src/services/knowledge-indexer.ts | SERVICE | SERVICE_MODIFIED | ChromaDB metadata 无 projectId 字段 | 索引时写入 projectId（number）到 chunk metadata | 待实施 |
| prisma/schema.prisma | SCHEMA | SCHEMA_MODIFIED | Document.projectId: String? | Document.projectId: Int?（与 farm-server 和 AgentState 统一为 number） | 待实施 |
| src/app/api/knowledge/upload/route.ts | API_ROUTE | API_ROUTE_MODIFIED | FormData 仅提取 file | 额外提取 projectId（number），写入 Document.projectId | 待实施 |
| src/app/api/agent/stream/route.ts | API_ROUTE | API_ROUTE_MODIFIED | 不支持 interrupt() 和 Command(resume=...) | 检测 stream 中的 __interrupt__ chunk，支持 /api/agent/resume 端点接收 Command | 待实施 |
| src/caijuehub/strategies/retrieval-confidence.ts | STRATEGY | STRATEGY_CREATED | 不存在；reasoning 节点无证据向量信号解读指引 | 生成 promptHint 注入 reasoning system message，指导 LLM 基于 vectorDistance 比较证据可信度。方案 B（统计基线裁决）延后独立 Plan | 待实施 |
| src/services/retrieval-stats.ts | SERVICE | SERVICE_CREATED | 不存在；无法按 expert 统计检索距离分布 | 查询 AuditLog 表（RETRIEVAL_RESULT），按 expertId 分组计算 p25/p50/p75，5 分钟缓存。提供 getRetrievalBaseline(expertId) 接口 | 待实施 |
| src/lib/agent-audit-logger.ts | LIB | LIB_MODIFIED | agentAuditRetrieval 仅记录 query/resultCount/evidenceCount；无 KB 矛盾事件类型 | 新增 expertId + distances[] 到 RETRIEVAL_RESULT；新增 KB_DISAGREEMENT 事件类型 + agentAuditKBDisagreement()，severity: HIGH | 待实施 |
| scripts/backfill-projectId.ts | SCRIPT | SCRIPT_CREATED | 不存在；存量 ChromaDB chunk 元数据无 projectId | 读 Prisma Document.projectId → 按 documentId 匹配 ChromaDB chunk → update metadata 写入 projectId | 待实施 |
| ../agrisynapse/src/views/llm/customization/index.vue | VIEW | VIEW_MODIFIED | 文档列表无项目过滤，上传无 projectId | 按 projectId 过滤文档列表，上传时自动携带 projectId | ✅ 已完成 |
| ../agrisynapse/src/api/llm/knowledge/grounding.ts | API_CLIENT | API_CLIENT_MODIFIED | uploadDocument(file) 无 projectId | uploadDocument(file, projectId)；getDocuments/getGroundingStats 支持 projectId 参数 | ✅ 已完成 |
| src/app/api/knowledge/documents/route.ts | API_ROUTE | API_ROUTE_MODIFIED | 忽略前端传递的 projectId 参数，whereClause 无 projectId 条件，查询全量文档 | 新增 projectId query param 读取，加入 whereClause 过滤条件，按项目隔离文档列表 | ✅ 已完成 |
| src/app/api/knowledge/grounding/stats/route.ts | API_ROUTE | API_ROUTE_MODIFIED | _request 未使用，findMany 无 where 条件，统计查全量文档 | 新增 projectId query param 读取，findMany 加 where 过滤，统计数据按项目隔离 | ✅ 已完成 |

---

## 一、背景与目标

### 1.1 问题现状

| 问题 | 现象 | 根因 |
|------|------|------|
| **推理时知识全局混用** | 用户选项目 A 提问，RAG 检索返回项目 B 的文档，导致推理结论偏离 | retrieval.ts 从未使用 AgentState.projectId 做检索过滤 |
| **UI 展示与推理不一致** | customization 页面将来可按项目过滤展示，但推理管线不做过滤，形成"视觉隔离"假象 | projectId 已全链路透传到 AgentState，但 retrieval 节点未消费 |
| **KB 冲突无检测** | 项目知识库（如"该地块适合玉米"）与全局知识库（如"该条件应种大豆"）可能存在矛盾，当前无任何检测机制 | 检索结果直接注入 evidenceChain，不同来源数据被无差别接受 |
| **交互点机制未落地 interrupt()** | plan-v1 已设计 interrupt() 暂停 + Command(resume) 恢复，但代码中从未实现；当前交互点是"消息往返→新轮次"的伪暂停 | interactionPointDetection 只设置 pendingInteraction 属性，图继续执行到 response |

### 1.2 目标

1. **双路并行检索**：根据 `state.projectId` 决定是否执行项目KB+全局KB 双路检索
2. **KB Claim 结构化提取**：检索 chunk → mini-LLM → 结构化 KBClaim（复用 ACA 框架的 Argumentation 模式）
   > 🔴 **P1#3 已决议移除**：KBClaim 提取从自由文本 chunk 事后提取召回率不可靠，改为轻量方案——不做结构化 Claim，改为在 evidence 上暴露 vectorDistance + chunkMethod + kbSources 原始信号
3. **确定性冲突检测**：复用 fan-in ConflictResolver 模式，对项目KB和全局KB的 Claim 做前提互斥/约束矛盾/置信度差检测
   > 🔴 **P1#3 已决议移除**：kbConflictResolver 节点砍掉；置信度不做人工微调，reasoning LLM 基于原始向量信号自行裁决矛盾
4. **interrupt() 暂停机制落地**：不可解 KB 冲突时调用 LangGraph 原生 `interrupt()`，图真暂停、State 全保留，用户选择后 `Command(resume=...)` 继续
   > 🔴 **P1#3 已决议修订**：interrupt() 不依赖 KBClaim。reasoning LLM 发现矛盾后直接基于 evidence 原始信号调用 interrupt()，前端渲染交互点卡片（选项 + 补充说明），用户选择后 Command(resume) 继续推理。
5. **ChromaDB + 上传链路打通**：索引时写 projectId 到 metadata，上传时从 FormData 提取 projectId 写入 Document

### 1.3 P0/P1 决议增量摘要

> **P0#1（组合语义）**：双路检索不嵌入 Per-Expert 循环内做三元判断。在裁决层新增 `caijuehub/strategies/retrieval-routing.ts`，输出 `RetrievalRoutingPlan`，retrieval 节点只执行 plan 不做判断。见 Task 0。
>
> **P0#2（类型统一）**：`Document.projectId` 改为 `Int?`，全链路 number，无需边界 `String()` 转换。见 Task 1.2。
>
> **P1#3（KBClaim vs 轻量）**：砍掉 kbClaimExtractor + kbConflictResolver 两个节点。KB 双路改为轻量 fan-in：retrieval 节点内来源标记 + vectorDistance/chunkMethod/kbSources 暴露 + reasoning LLM 自主裁决。置信度不做人工微调（+0.1/-0.05 不可迁移）。
>
> **P1#8（存量回填）**：必须回填。新建 `scripts/backfill-projectId.ts`，读 Prisma Document.projectId → 按 documentId 匹配 ChromaDB chunk → update metadata 写入 projectId。泰州种业项目已接入，旧 chunk 无 projectId 导致过滤后丢数据。
>
> **P1#7（FormData → Int）**：FormData.get("projectId") 返回 string，route 层 `parseInt()` 后写入。
>
> **P2#9（KBClaim LLM 预算）**：随 P1#3 KBClaim 移除标记为废弃。
>
> **P2#10（interrupt SSE 协议）**：随 P1#4 复活。SSE 事件类型 `interrupt`，payload `{ type: "kb_disagreement", projectEvidence, globalEvidence, options: string[], notePlaceholder }`。
>
> **P2#11（customization projectId 来源）**：已具备。LlmTopHeader.vue L26 维护 `selectedProjectId`，customization 页面复用同一状态即可。
>
> **P2#12（展开对比选项实现路径）**：随 P1#4 复活。交互点卡片渲染矛盾双方证据 + 单选 + 补充说明输入框，提交后作为 resume context 注入。
>
> **P2#13（自动裁决边界规则）**：不自动裁决。结论相反一律 interrupt，不论距离差。距离信息在卡片中展示供用户参考，系统不代用户决策。
>
> 🔴 **P2#14 已决议修订**：R2.1 触发机制从"LLM 语义判定结论相反"改为"向量距离差阈值检测（distagap > 0.3）"。理由：(1) LLM 判定边界模糊不可靠（农业结论很少非黑即白），(2) 向量距离差确定性更高、零额外 token 成本，(3) 阈值仅控制"何时问用户"不替代"替用户选什么"——最终决策权永远在用户。详见 `tasks.md` Spec 偏差记录表。

---

## 二、方案选型

### 2.1 候选方案对比

| 维度 | A: 简单 metadata 过滤 | B: 双路检索 + 交叉比对 + interrupt()（选用） |
|------|----------------------|------------------------------------------|
| 实现复杂度 | 低（检索时加 `where: { projectId }`） | 中（新增 2 个节点 + interrupt 机制 + Claim 提取） |
| 冲突检测 | 无——项目KB和全局KB各自独立检索，无交叉比对 | 有——确定性冲突检测 + 不可解时暂停 |
| 架构一致性 | 与 Expert fan-in 模式无关 | 与 ACA 框架的 Argumentation + Adjudication 同构 |
| 人工裁决 | 不支持 | 支持——interrupt() 暂停、结构化选项、Command(resume) 恢复 |
| 可审计性 | 弱——不知道是否有冲突被忽略 | 强——每条冲突都有 ConflictReport + 审计日志 |
| 对 ACA Graph 的贡献 | 无 | **深图中验证的 KB Claim 提取 + ConflictResolver + interrupt()，可直接复用到 ACA Graph 的 per-expert 层** |

### 2.2 选型理由

**选用方案 B（双路检索 + 交叉比对 + interrupt()）**。理由：

- 产品需求明确要求"项目知识库与全局知识库交叉比对"，不是简单过滤
- ACA 框架（plan-v1）已设计 Argumentation + ConflictResolver + Adjudication 模式，本 Plan 在深图中先验证该模式，为 ACA Graph 铺路
- `interrupt()` 是 LangGraph 原生能力，可替代当前"消息往返→新轮次"的伪交互点，降低延迟、保持 State
- 方案 A 无法处理知识冲突，产品需求不满足

> 🔴 **P1#3 已决议修订**：方案 B 由"双路检索 + 交叉比对 + interrupt()"修订为"轻量双路检索 + 来源标记 + 向量信号暴露"。核心变化：(1) 砍掉 kbClaimExtractor + kbConflictResolver 两个新节点；(2) 检索路径决策收敛到裁决层策略；(3) 冲突处理降级为来源标记 + 向量信号暴露，让 reasoning LLM 自主裁决。industry 实践不支持从 chunk 文本事后提取 structured claim。

### 2.3 数据模型选型：单 Collection + metadata 过滤 vs 独立 Collection

| 维度 | A: 单 Collection + metadata 过滤（选用） | B: 独立 Collection per-project |
|------|---------------------------------------|-------------------------------|
| 检索隔离度 | 逻辑隔离，`where: { projectId }` 过滤 | 物理隔离，不同 collection |
| 向量空间一致性 | ✅ 同一空间，项目KB和全局KB的相似度距离可直接比较，交叉比对有意义 | ❌ 不同空间，跨 collection 距离语义不可比，冲突检测失基准 |
| 管理复杂度 | 低——一个 collection，多一层 where | 高——每项目一个 collection，生命周期管理 |
| Expert Grounding 一致性 | 与现有双写模式同构——同一份 chunk 共享 embedding，仅 metadata 不同 | 与现有模式矛盾——每个 collection 独立 embedding |
| 冲突检测可行性 | ✅ 同一 query 在统一向量空间检索两个子集，距离可比 | ❌ 需额外协调两个独立向量空间 |

**选用方案 A（单 collection + metadata 过滤）**。理由：

- **交叉比对依赖同一向量空间**：项目KB和全局KB的 chunks 在同一 embedding 空间中，它们与 query 的余弦距离才有可比性。分两个 collection 意味着两套独立的向量空间，`distance=0.3` 在不同空间中含义不同，冲突检测失去了统一的距离基准
- **与现有 Expert Grounding 双写模式一致**：Expert Grounding 使用 per-expert collection（领域语义域划分），主知识库使用单一 `farm_agent` collection（项目归属只是 metadata 标记）。两者是正交的两套体系——本 Plan 只涉及主知识库体系，不改 Expert collection 模型。同一份 chunk 在两种体系中的关系：写一次 embedding → 主 collection（farm_agent）+ 双写到 per-expert collection
- **ChromaDB `where` 过滤是原生支持的**，不引入性能问题
- **项目KB 不是独立的知识孤岛**：它与全局KB 共享同一个 `farm_agent` 向量空间，`projectId` 标记的语义是"该知识来自/适用于某项目"，而非"该知识属于一个独立的向量库"

> **关键定义**：`projectId` 不是"标记归属"，而是"划分检索域"。
> - 全局检索域 = `where: {}` 或无 `projectId` 条件的查询
> - 项目检索域 = `where: { projectId: "<currentProjectId>" }`

---

## 三、架构设计

### 3.1 改造后 deep 管线拓扑

```
                       intention
                           │
                           ▼
                       retrieval (改造)
                           │
             ┌─────────────┼─────────────┐
             │ 项目KB检索     │ 全局KB检索     │
             │ where:        │ (无 projectId  │
             │ {projectId}   │  过滤)         │
             └──────┬────────┴──────┬────────┘
                    │               │
                    └───────┬───────┘
                            │
                    来源标记 + 向量信号填充
                    (vectorDistance, chunkMethod,
                     kbSources)
                            │
                            ▼
                    ┌──────────────┐
                    │  reasoning   │
                    │  基于向量信号  │
                    │  裁决矛盾      │
                    └──────┬───────┘
                           │
                  ┌────────┴────────┐
                  │ 双路 distanceGap│         │ 其他情况
                  │ > 0.3          │         │ (≤ 0.3 / 单路)
                  ▼                 ▼
          ┌──────────────┐  ┌──────────────┐
          │ interrupt()  │  │ 继续推理      │
          │ 交互点卡片    │  │ → response   │
          │ 选项+补充说明  │  └──────────────┘
          └──────┬───────┘
                 │
          ┌──────┴───────┐
          │ 用户选择后     │
          │ Command(resume)│
          │ 图继续执行     │
          └──────┬───────┘
                 │
                 ▼
          ┌──────────────┐
          │  reasoning    │
          │ (继续，含用户  │
          │  选择+补充说明) │
          └──────┬───────┘
                 │
            interactionPoint
            → verdict → response
```

> 🔴 **P1#3 已决议修订**：kbClaimExtractor、kbConflictResolver 移除。retrieval 节点内来源标记 + 向量信号填充，直连 reasoning。reasoning 在判定矛盾时直接调用 interrupt()——无需 Claim 提取，基于 evidence 原始信号即可。

### 3.1a 向量信号暴露规范（P1#3 决议新增）

KB 双路不做结构化 Claim 提取和人工置信度微调，改为在 evidence 上暴露三类原始向量信号，让 reasoning LLM 自主裁决可信度：

| 字段 | 类型 | 来源 | 语义 |
|------|------|------|------|
| `vectorDistance` | `number` | ChromaDB query result 原始余弦距离 | 越小越相似；对同一 query 在同一向量空间（farm_agent collection）内，项目KB chunk 和全局KB chunk 的 distance 可直接比较 |
| `chunkMethod` | `"smart" \| "fixed" \| "unknown"` | ChromaDB chunk metadata（knowledge-indexer 写入） | `smart`=SmartChunker 语义分块（语义完整性高），`fixed`=固定长度切分（可能截断语义），`unknown`=存量无标记 |
| `kbSources` | `string[]` | retrieval 节点根据 search 路径标记 | `["project_kb"]` 仅项目KB命中，`["global_kb"]` 仅全局KB命中，`["project_kb", "global_kb"]` 双路同时命中 |

**与现有 evidence 字段的关系：**

```
现有: content / source / relevance / reliability(=0.85 硬编码) / metadata / grounding / expertIds
新增: vectorDistance / chunkMethod / kbSources
移除: reliability(0.85) — reasoning 基于 vectorDistance + chunkMethod + kbSources 自行判断
保留: relevance(= 1 - distance) — 二次加工值，方便 LLM 快速排序，但不替代原始 distance
```

**reasoning 使用范式（推理节点 prompt 追加）：**

```
对于每条检索证据，综合评估：
1. vectorDistance < 0.3 ? 高可信 : (vectorDistance < 0.5 ? 中可信 : 低可信)
2. chunkMethod = "smart" ? 语义完整性高 : ("fixed" → 可能有截断风险 / "unknown" → 保守评估)
3. kbSources 包含 both ? 双源交叉验证增强 : 单源需交叉比对其他证据
4. 项目KB 和全局KB 给出矛盾结论时 → 优先 distance 更小的一方，标注矛盾供用户复查
```

> **置信度不做人工微调**：不叠加 +0.1/-0.05 等魔法偏移。行业标准是用原始向量距离作为可信度参考，不对模型输出叠加主观判断。不同 embedding 模型下数值语义不同，手调不可迁移。

> ⚠️ **前提：用户能读懂证据**。当前 evidence 渲染仅显示截断的 chunk 片段，无「查看原文」入口，用户无法理解片段上下文和矛盾原因。矛盾标注依赖 evidence 完整展示能力——需在 evidence 展开区显示完整 chunk 内容 + 「查看原文」按钮跳转文档详情页。

### 3.1b 置信度消费者链路

三个消费者按同一数据源协作：

```
retrieval 节点
    │  构建 evidence { vectorDistance, chunkMethod, kbSources }
    │  调用 agentAuditRetrieval({ distances })
    │
    ├─→ 消费者① reasoning LLM (主消费)
    │       caijuehub/retrieval-confidence.ts → 生成 promptHint
    │       prompt 追加: "每条证据标注了向量距离。距离越小越匹配。
    │                     比较同批次证据的距离，更低的更可信。
    │                     切块方案为语义分块的信息更完整。"
    │
    ├─→ 消费者② 前端 GUI (透明展示)
    │       白盒行: 向量值 | chunkId | 距离 0.23 | 切块方案 | 语义分块 | 来源 项目知识库
    │
    └─→ 消费者③ ADD-4 审计日志 (统计数据源)
            agentAuditRetrieval extended:
              { distances: [{ chunkId, distance, chunkMethod, kbSources }] }
                ↓ 落 AuditLog 表
            retrieval-stats.ts 读 AuditLog:
              按 expertId 分组 → p25/p50/p75 → 缓存 5min
              （静默收集，供后续 Plan 的方案 B 基线裁决复用）
```

> **方案 B 统计基线延后为独立 Plan**（违反原子闭包：基线需 50+ 真实查询后计算，无法在 PR 时验证）。`retrieval-stats.ts` 静默收集数据，供后续 Plan 复用。

### 3.1c 存量 ChromaDB chunk 的 projectId 回填（P1#8）

> 🔴 P1#8 已决议：必须回填。泰州种业项目已接入，旧 chunk 无 projectId 会导致检索过滤后丢数据。

**回填方案**：`scripts/backfill-projectId.ts`

1. 查询 Prisma：`SELECT id, projectId FROM Document WHERE projectId IS NOT NULL`
2. 按 `documentId` 分组
3. 对每组，查 ChromaDB：`collection.get({ where: { documentId: doc.id } })`
4. 对命中的 chunk，`collection.update({ ids: [...], metadatas: [{ ...old_meta, projectId: doc.projectId }] })`
5. 批量处理（每批 100），输出进度日志

回填后新增索引写入路径也携带 projectId，防止未来回退。

### 3.1d KB 矛盾交互点卡片（P2#12 + P2#13）

reasoning LLM 裁决边界规则（注入 prompt）：

```
根据检索证据判断 KB 矛盾时：
1. 项目 KB 0 条结果 → 直接声明"未找到项目相关数据"，不触发 interrupt
2. 双方结论一致/互补 → 正常融合输出，不触发 interrupt
3. 双方结论相反 → 调用 interrupt() 暂停，等用户裁决
   （向量距离在卡片中展示供用户参考，但不代用户做决策）
```

> 🔴 **P2#14 修订**：实际实现不依赖 LLM 语义判定"结论相反"。改为在 reasoning 节点内做确定性检测：
> 1. 从 evidence 中按 `kbSources` 分离 projectEvidences 和 globalEvidences
> 2. 取各源 best evidence（min vectorDistance）
> 3. 计算 `distanceGap = |projDist - globalDist|`
> 4. `distanceGap > 0.3` → interrupt()；≤ 0.3 → 不触发（避免误报）
>
> **interrupt() 触发条件**（实际）：双路 evidence 均存在 **且** 向量距离差 > 0.3。

**前端交互点卡片**（最终态面板渲染）：

```
┌─────────────────────────────────────────────────┐
│ ⚠️ 与通用建议不一致                              │
│                                                 │
│ 项目KB：播种深度 3-5cm（距离 0.23）              │
│ 全局KB：播种深度 5-8cm（距离 0.31）              │
│                                                 │
│ ○ 采纳项目建议    ○ 采纳通用建议    ○ 暂不处理    │
│                                                 │
│ ┌─────────────────────────────────────────────┐ │
│ │ 补充说明（选填）:                            │ │
│ │ ___________________________________________ │ │
│ └─────────────────────────────────────────────┘ │
│                                    [提交]        │
└─────────────────────────────────────────────────┘
```

提交后 `Command({ resume: { choice: "项目建议", note: "我们地块偏沙性" } })`，
reasoning 节点恢复时上下文包含用户选择 + 补充说明。

**审计日志加强**（矛盾事件高等级记录）：

新增 `AgentAuditPhase = "KB_DISAGREEMENT"` 事件类型 + `agentAuditKBDisagreement()` 函数：

```typescript
// agent-audit-logger.ts
type AgentAuditPhase = ... | "KB_DISAGREEMENT"

export function agentAuditKBDisagreement(params: {
  projectEvidence: { chunkId, distance, content }
  globalEvidence: { chunkId, distance, content }
  distanceGap: number
  userChoice?: string        // resume 后补填
  userNote?: string          // resume 后补填
}) {
  agentAudit("KB_DISAGREEMENT", `KB 矛盾检测`, {
    projectChunkId: params.projectEvidence.chunkId,
    projectDistance: params.projectEvidence.distance,
    globalChunkId: params.globalEvidence.chunkId,
    globalDistance: params.globalEvidence.distance,
    distanceGap: params.distanceGap,
    userChoice: params.userChoice,
    userNote: params.userNote,
    severity: "HIGH",       // 最高审计等级
  })
}
```

矛盾检测时写入（reasoning 节点调用 interrupt 前），用户裁决后
`resume` 端点二次写入补充 `userChoice` + `userNote`。

### 3.2 无 projectId 时的降级路径

```
提问 → projectId == null? → 全局检索 → 直接构建 evidenceChain → reasoning
                                  ↑ 不进入双路流程，不回退到旧管线
```

### 3.3 interrupt() 暂停机制

reasoning 节点判定 KB 结论相反后直接触发：

```
reasoning 节点
    │  收到 evidence { vectorDistance, kbSources }
    │  分离 projectEvidences / globalEvidences
    │  计算 distanceGap = |projDist - globalDist|
    │  ↑ P2#14: distanceGap > 0.3 时调用 interrupt()
    │
    ▼
interrupt({
  type: "kb_disagreement",
  projectEvidence: { chunkId, distance, content },
  globalEvidence: { chunkId, distance, content },
  options: ["采纳项目建议", "采纳通用建议", "暂不处理"],
  notePlaceholder: "补充说明（选填）",
})
    │
    ▼ 图暂停 ── 前端渲染交互点卡片（§3.1d）── 用户选择 + 补充说明
    │
    ▼
Command({ resume: { choice: "采纳项目建议", note: "地块偏沙性" } })
    │
    ▼ 图继续
reasoning 节点
    │  上下文注入: { userChoice, userNote }
    │  基于用户裁决重新推理 → 输出最终答案
    │
    ▼
interactionPoint → verdict → response
```

stream/route.ts 支持两种调用模式：
1. **普通 invoke**：`POST /api/agent/stream` → `streamAgent(input, config)` → SSE 流
2. **恢复 invoke**：`POST /api/agent/resume` → `streamAgent(Command(resume=...), config)` → 从中断点继续 SSE 流

> ⚠️ **MemorySaver 持久化评估**：MemorySaver 是内存级 checkpointer，进程重启后 interrupt 状态丢失。考虑到 interrupt 发生在同一 HTTP 请求的 SSE 流中（用户看到卡片 → 点击选择 → resume），此过程在进程生命周期内完成，MemorySaver 足够。**若用户长时间不操作导致进程回收，重新发起对话即可**——这是一个可接受的 trade-off，无需持久化 checkpointer。

### 3.4 与 ACA Graph 的关系

```
本 Plan 验证的核心能力              ACA Graph 复用方式
─────────────────────────          ──────────────────
裁决层策略模式                      ACA Graph 的 per-expert 检索路由
(retrieval-routing.ts)             → 同走 caijuehub 集中的 resolve*() 裁决

向量信号暴露规范                    ACA Graph 的 evidenceChain
(vectorDistance/chunkMethod/       → 专家 Claim 可附加相同向量信号字段
 kbSources + reasoning 消费)

reasoning 内 interrupt() 调用      ACA 的 Adjudication 层
→ 判定矛盾后直接暂停图              → 图暂停模式完全一致，选项格式统一
→ 交互点卡片（选项 + 补充说明）      → 卡片模式可复用（增加多专家维度）
→ Command(resume) 注入用户选择

审计日志 KB_DISAGREEMENT 事件       ACA Graph 的 per-expert 矛盾审计
→ 高等级记录冲突 + 用户裁决         → 扩展为多专家间冲突的记录模式
```

> 🔴 **P1#3 已决议修订**：不验证 KBClaim 提取（该能力不适合从 chunk 事后提取），但验证了裁决层策略模式、向量信号暴露、reasoning 内 interrupt() 调用——这三项能力可直接复用到 ACA Graph。

---
---

## 四、实施步骤 + 依赖图

### 轮次拆分（原子闭包判定）

> **判定原则**（ADD 规范第 88 行）：以"可独立交付业务价值"为原点，不以代码依赖为边界。

| | 第 1 轮：双路检索上线 | 第 2 轮：矛盾裁决交互 |
|---|---|---|
| **覆盖 Task** | 0+1+2+5+6(条件边)+8 | 6(interrupt)+7+8(交互卡片) |
| **业务功能** | 项目 KB + 全局 KB 并行检索，evidence 带向量信号，前端支持 projectId 过滤 | KB 结论相反时暂停 → 交互卡片 → 用户选择 → 恢复推理 |
| **用户感知** | 提问自动检索项目专属知识，证据行显示向量距离 | 矛盾时弹出选择卡片，用户裁定后系统按裁定方向继续 |
| **交付物** | ~10 文件（策略层 + projectId 链路 + retrieval 改造 + Graph 条件边 + customization 过滤） | ~5 文件（reasoning interrupt + stream/resume 端点 + 交互卡片渲染） |
| **可独立验证** | `tsc --noEmit` + 有/无 projectId 双场景 | 模拟矛盾 → 检测 __interrupt__ chunk → resume |
| **可独立审计** | RETRIEVAL_RESULT 扩展 distances | KB_DISAGREEMENT 事件（severity: HIGH） |

> ⚠️ **第 1 轮不包含 reasoning interrupt**：双路检索上线后，reasoning LLM 消费向量信号自主融合（不调用 interrupt）。第 2 轮在 evidence 向量信号基础上叠加 interrupt 裁决。第 2 轮依赖第 1 轮的 evidence 信号字段，但第 1 轮不依赖第 2 轮的任何产出。

### 依赖图

```
                         ══════════ 第 1 轮 ══════════
Task 0: 裁决层检索路由策略 ──┐
                              │
Task 1: ChromaDB metadata + upload route ──┤ 可并行
                                            │
                                            ├─→ backfill-projectId.ts（存量 chunk 回填）
                                            │
Task 2: 向量信号类型定义 + State 扩展 ──────┘
                                            │
Task 3: ~~kbClaimExtractor~~ ❌ 废弃
Task 4: ~~kbConflictResolver~~ ❌ 废弃
                                            │
                                            ▼
Task 5: retrieval.ts 改造（消费策略计划）
                            │
              ┌─────────────┼─────────────┐
              │             │             │
              ▼             ▼             ▼
    retrieval-confidence.ts   retrieval-stats.ts   agent-audit-logger 扩展
    (置信度策略)               (距离统计)           (KB_DISAGREEMENT + distances)
                            │
                            ▼
Task 6: Graph 集成 (index.ts 条件边清理 + reasoning 向量信号消费，不含 interrupt)
                            │
              ┌─────────────┴─────────────┐
              │                           │
              ▼                           ▼
Task 8: customization 前端              Task 9: 编译验证
  (projectId 过滤 + 上传)                (第 1 轮交付物验证)
                            │
                         ═══▼═══ 第 1 轮收敛 ══════
                            │
                         ═══▼═══ 第 2 轮 ═══════════
Task 6: reasoning 节点内 interrupt() 触发
                            │
                            ▼
Task 7: stream/route.ts interrupt 支持 + /api/agent/resume 端点
                            │
                            ▼
Task 8: 交互点卡片前端渲染
                            │
                            ▼
Task 9: 编译验证 + 集成测试
```

### Task 0: 裁决层检索路由策略（新增，前置依赖）

| # | 任务 | 文件 | 说明 |
|---|------|------|------|
| 0.1 | RetrievalRoutingPlan 接口定义 | 新建 `caijuehub/strategies/retrieval-routing.ts` | 输出 plan 包含 `perExpert: [{ expertId, searches: [{ collection, where }] }]` |
| 0.2 | resolveRetrievalRouting() 裁决函数 | 同上 | 输入 projectId + expertIds + groundingStatus，裁决每个 Expert 的检索路径（grounding 就绪走 expert collection；降级走 farm_agent 双路：projectId 过滤 + 无过滤） |
| 0.3 | RetrievalConfidenceHint 接口 + resolveRetrievalConfidence() | 新建 `caijuehub/strategies/retrieval-confidence.ts` | 方案 A（唯一活跃模式）：LLM 自行比较距离。reasoning 节点消费 promptHint 拼入 system message |
| 0.4 | retrieval-stats.ts 统计收集器（静默运行） | 新建 `src/services/retrieval-stats.ts` | 查 AuditLog WHERE type="RETRIEVAL_RESULT"，按 expertId 分组算 p25/p50/p75，5min 缓存。仅收集，不接入基线裁决。方案 B 基线上线延后为独立 Plan |
| 0.5 | agentAuditRetrieval 扩展 expertId + distances 字段 | agent-audit-logger.ts | metadata 新增 expertId + distances[]={ chunkId, distance, chunkMethod, kbSources } |
| 0.6 | 编译验证 | tsconfig | `npx tsc --noEmit` |

**验收**：给定 projectId + expertIds，输出正确的 searches 列表；无 projectId 时降级为单路全局检索。

### Task 1: ChromaDB metadata + upload route 打通 projectId 链路

| # | 任务 | 文件 | 说明 |
|---|------|------|------|
| 1.1 | ChromaDB metadata 写入 projectId | knowledge-indexer.ts | 从 Document.projectId 读取（number），写入 chunk metadata（number） |
| 1.2 | Document.projectId 类型改为 Int | schema.prisma | `String?` → `Int?`，生成并执行 migration；无需边界 String() 转换 |
| 1.3 | upload route 提取 projectId | upload/route.ts | 从 FormData 提取 projectId（number），写入 Document.projectId |

> 🔴 **P1#7 已决议**：FormData.get("projectId") 返回 string，需 `parseInt()` 转换为 number 再写入 `Document.projectId: Int`。空值/null → 不写入（保持 null）。
| 1.4 | 编译验证 | tsconfig | `npx tsc --noEmit` |

**验收**：上传文件后 Document.projectId 非空；ChromaDB chunk metadata 包含 projectId。

> 🔴 **P1#8 已决议：暂不执行**。回填脚本 `scripts/backfill-projectId.ts` 已就绪（105 行），但当前仅泰州种业一个项目接入，存量数据量小，手动重新上传即可覆盖，回填无实际收益。后续多项目接入时若有必要再执行。
>
> ~~**回填脚本**：~~
> ~~1. 查询 Prisma `Document` 表，获取所有 `projectId` 非空的 `(id, projectId)` 对~~
> ~~2. 连接 ChromaDB，获取 `farm_agent` collection~~
> ~~3. 按 documentId 分组，`collection.get({ where: { documentId } })` 获取旧 chunk~~
> ~~4. 对每组 chunk，`collection.update({ ids, metadatas: [{ ...oldMeta, projectId }] })`~~
> ~~5. 批量处理（每批 100），输出进度日志~~

### Task 2: 向量信号类型定义 + AgentState 扩展（修订）

> 🔴 **P1#3 已决议修订**：原 Task 2（KBClaim 类型）废弃，改为轻量 fan-in 对应的向量信号类型定义。

| # | 任务 | 文件 | 说明 |
|---|------|------|------|
| 2.1 | evidence 向量信号字段类型扩展 | agents/state.ts 或 types/ | evidence 类型新增 `vectorDistance?: number`、`chunkMethod?: "smart" \| "fixed" \| "unknown"`、`kbSources?: string[]` |
| 2.2 | interrupt payload 类型定义 | 同上 | `KBDisagreementPayload: { projectEvidence, globalEvidence, options, notePlaceholder }` |
| 2.3 | 编译验证 | tsconfig | `npx tsc --noEmit` |

**验收**：evidence 类型包含向量信号字段；interrupt payload 类型编译通过。

### Task 3: ~~kbClaimExtractor 节点~~ ❌ 废弃

> 🔴 **P1#3 已决议移除**：整个 Task 废弃。KB 双路不做结构化 Claim 提取，改为在 evidence 上暴露 vectorDistance/chunkMethod/kbSources 原始信号。

### Task 4: ~~kbConflictResolver 节点~~ ❌ 废弃

> 🔴 **P1#3 已决议移除**：整个 Task 废弃。KB 双路不做确定性冲突检测，改为 reasoning LLM 基于向量信号自主裁决 + interrupt() 暂停等用户决策。

### Task 5: retrieval.ts 改造（消费策略计划）

| # | 任务 | 文件 | 说明 |
|---|------|------|------|
| 5.1 | 调用 resolveRetrievalRouting() 替代三元判断 | retrieval.ts | 移除 `groundingReady ? collectionSearch : fallbackSearch` 三元；改为 `const plan = resolveRetrievalRouting(...)` |
| 5.2 | 按 plan.searches 并行执行检索 | 同上 | `Promise.all(plan.perExpert.flatMap(e => e.searches.map(s => search(s))))`，标记来源（project_kb / global_kb / expert_collection） |
| 5.3 | 编译验证 | tsconfig | `npx tsc --noEmit` |

**验收**：retrieval 节点内无三元判断；检索路径由裁决层策略决定；有 projectId 时自动双路。

> 🟢 **P0#1 已决议**：retrieval 节点不再做 grounding?collection:fallback 三元判断。改为调用 `resolveRetrievalRouting(state)` 获取 `RetrievalRoutingPlan`，按 `plan.searches` 并行执行。节点完全不做路由决策。此外，补充向量信号暴露：从 ChromaDB result 提取 distance → vectorDistance；从 metadata 提取 chunkMethod；根据 search 路径标记 kbSources。
>
> ⚠️ **证据完整性**：当前 evidence `content` 是 ChromaDB chunk 内容（非截断），但 `detailUrl` 目前只有 `metadata.sourceUrl` 可能为空。需确保每条 knowledge 来源的 evidence 携带有效的 `detailUrl`（指向文档详情页），供前端「查看原文」按钮使用。

### Task 6: Graph 集成（分轮）

#### 第 1 轮：条件边清理 + reasoning 向量信号消费

| # | 任务 | 文件 | 说明 |
|---|------|------|------|
| 6.1 | 移除 kbClaimExtractor/kbConflictResolver 节点引用 | index.ts | 删除 `.addNode("kbClaimExtractor", ...)` 和 `.addNode("kbConflictResolver", ...)` |
| 6.2 | reasoning 节点消费 promptHint | reasoning.ts | 调用 `resolveRetrievalConfidence(evidence)`，将 promptHint 注入 system message |
| 6.3 | 编译验证 | tsconfig | `npx tsc --noEmit` |

**验收**：graph 编译通过；retrieval → reasoning 边正常；reasoning system message 含置信度提示。

#### 第 2 轮：reasoning 节点内 interrupt() 触发

| # | 任务 | 文件 | 说明 |
|---|------|------|------|
| 6.4 | reasoning 调用 interrupt() | reasoning.ts | 双路 kbSources 检测 + distanceGap > 0.3 → `interrupt({ type: "kb_disagreement", ... })`；调用前写入 agentAuditKBDisagreement() |
| 6.5 | resume 后上下文恢复 | 同上 | Command(resume) 返回后，注入 userChoice + userNote 继续推理 |
| 6.6 | 编译验证 | tsconfig | `npx tsc --noEmit` |

**验收**：模拟矛盾 → interrupt() 触发 → stream 输出 __interrupt__ chunk。

> 🔴 **P1#3 已决议修订**：无 kbConflictResolver 节点，reasoning 节点在判定矛盾后直接调用 interrupt()。graph 拓扑为 `retrieval → reasoning（含 interrupt 分支）`。

### Task 7: stream/route.ts interrupt 支持

| # | 任务 | 文件 | 说明 |
|---|------|------|------|
| 7.1 | 检测 `__interrupt__` chunk | stream/route.ts | `for await (const chunk of stream)` 中识别 interrupt chunk，发送结构化中断信息给前端 |
| 7.2 | 新增 `/api/agent/resume` 端点 | 新建或 route.ts 内条件分支 | 接收 `{ threadId, resume: { choice } }` → `Command({ resume: choice })` → 继续 stream |
| 7.3 | 编译验证 | tsconfig | `npx tsc --noEmit` |

**验收**：中断时前端收到结构化冲突选项；resume 后图从中断点继续。

> 🔴 **P1#4 已决议复活**：stream/route.ts 和 `/api/agent/resume` 端点纳入本 Plan。interrupt 在 reasoning 节点内触发，前端解析 SSE `interrupt` 事件渲染交互点卡片。

### Task 6.5: isSummary 专家工具调用链路修复（Runtime Review F1-F3）

> 🔴 **2026-06-23 Runtime Review 新增**：isSummary 路由（intention → reasoning 跳过 retrieval）存在四处断裂（F1-F4）。**已拆分为独立子 Plan** → `farm-agent-isSummary-toolcall-fix-plan-v1.md`。本 Plan 不再维护 isSummary 修复的详细任务。
>
> 详见 `.qoder/reviews/farm-agent-deep-kb-dualpath-retrieval-review-runtime-v1.md`

| # | 任务 | 说明 |
|---|------|------|
| 6.5 | isSummary 专家工具调用链路修复 | 🔗 委托至子 Plan `farm-agent-isSummary-toolcall-fix-plan-v1.md` |

### Task 8: customization 前端 + grounding API + 后端过滤

| # | 任务 | 文件 | 说明 | 状态 |
|---|------|------|------|------|
| 8.1 | grounding API 客户端扩展 projectId | agrisynapse grounding.ts | uploadDocument(file, projectId)；getDocuments/getGroundingStats 支持 projectId 参数 | ✅ 已完成 |
| 8.2 | customization 页面项目绑定 | agrisynapse customization/index.vue | 引入 agentChatStore.projectId，上传自动携带，列表按 projectId 过滤 | ✅ 已完成 |
| 8.3 | 后端文档列表接口 projectId 过滤 | src/app/api/knowledge/documents/route.ts | 读取 projectId query param，加入 whereClause 过滤条件 | ✅ 已完成 |
| 8.4 | 后端统计接口 projectId 过滤 | src/app/api/knowledge/grounding/stats/route.ts | 读取 projectId query param，findMany 加 where 过滤 | ✅ 已完成 |

**验收**：上传文件后 Document.projectId = 当前选中项目；列表仅显示当前项目文档；统计数据按项目隔离。

> ⚠️ **8.3/8.4 修复记录**：前端已正确传递 projectId，但后端 documents/route.ts 和 grounding/stats/route.ts 均未读取该参数，导致查询返回全量数据。修复后 whereClause 包含 projectId 条件，数据按项目正确隔离。

> ⚠️ **证据可读性改造**（本 Task 追加）：LlmChatView.vue 证据链区域需三项改动：
> 1. **完整内容展示**：evidence 展开区显示完整 chunk 内容（当前 `{{ content }}` 已为全文，确认无截断）
> 2. **「查看原文」按钮**：在证据链条目 header 或 body 底部添加，使用 evidence 的 `detailUrl`（`metadata.sourceUrl`）跳转文档详情页
> 3. **矛盾标注 badge**：在证据链条目 header 的 grounding badge 旁，当 reasoning 标记矛盾时显示 `⚠️ 与通用建议不一致` / `⚠️ 与项目记录不符` 可点击 badge。badge 颜色：橙底白字（`#f59e0b`），点击展开矛盾说明弹窗或跳转到相关证据
> 4. **白盒数据行**：evidence 展开区底部以标签-值格式展示向量层原始信号，用户可自行判断证据质量。格式：`向量值 | {chunkId} | 距离 {vectorDistance} | 切块方案 | {chunkMethod中文} | 来源 {kbSources中文}`。其中 chunkMethod 中文映射：smart→"语义分块"、fixed→"固定长度分块"、unknown→"未知分块"；kbSources 中文映射：project_kb→"项目知识库"、global_kb→"通用知识库"。不再显示硬编码的 reliability(0.85)

### Task 9: 编译验证 + 集成测试

| # | 任务 | 文件 | 说明 |
|---|------|------|------|
| 9.1 | farm-agent 编译验证 | tsconfig | `npx tsc --noEmit` |
| 9.2 | agrisynapse 编译验证 | - | 确认前端改动无编译错误 |
| 9.3 | 集成场景验证 | - | 三种场景：无 projectId（降级全局检索）、有 projectId 无冲突、有 projectId 有冲突 + interrupt |

---

## 五、验收标准

- [ ] 无 projectId 时：降级为全局检索 → reasoning，与当前行为一致（零回归）
- [ ] 有 projectId 时：双路并行检索执行，项目KB + 全局KB 检索分别执行
- [ ] ~~KB Claim 提取~~ → P1#3 移除
- [ ] ~~确定性冲突检测~~ → P1#3 移除
- [ ] ~~无冲突/有冲突可自动裁决/不可自动裁决~~ → P1#3 移除
- [ ] ~~interrupt() / Command(resume)~~ → P1#3 延后到 ACA Graph
- [ ] **证据向量信号暴露**：evidence 包含 vectorDistance（原始 cosine distance）、chunkMethod（smart/fixed/unknown）、kbSources（project_kb/global_kb）
- [ ] **裁决层路由策略**：`resolveRetrievalRouting()` 正确输出 plan.searches，retrieval 节点无三元判断
- [ ] ChromaDB chunk metadata 包含 projectId；上传文件后 Document.projectId 非空（Int）
- [x] customization 页面按 projectId 过滤文档列表（前端 8.1/8.2 + 后端 8.3/8.4 全链路完成）
- [ ] `npx tsc --noEmit` 零错误
- [ ] 审计日志覆盖检索路由决策（plan 生成）、双路来源分布（kbSources 统计）

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| ADD Route | `.qoder/plans/farm-agent-deep-kb-dualpath-retrieval-add-route-v1.md` | 待生成 |
| Handoff | `.qoder/plans/farm-agent-deep-kb-dualpath-retrieval-handoff-v1.md` | 已生成（2 轮，含恢复审计查询 + 高风险误区） |
| Review | `.qoder/reviews/farm-agent-deep-kb-dualpath-retrieval-review-v1.md` | ✅ 已生成（2 P0 + 6 P1 + 5 P2） |
| Spec | `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/spec.md` | 已生成（2 轮 Requirements R1.1~R2.4） |
| Tasks | `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/tasks.md` | 已生成（Phase 1.1~2.4，按轮组织） |
| Checklist | `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/checklist.md` | 已生成（分轮验证项 + ADD 合规） |
| ACA 框架 Plan | `.qoder/plans/farm-agent-three-tier-reasoning-graph-plan-v1.md` | 已有 |
| 决策管线架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` | 现有 |
