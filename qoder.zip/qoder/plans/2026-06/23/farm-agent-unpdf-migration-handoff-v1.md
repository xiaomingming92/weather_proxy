# farm-agent — unpdf 迁移 PDF 解析 交接手册

> **适用场景**：四阶段变更。(1) pdfjs-dist → unpdf。(2) 混合解析管线——文本层 + OCR 降级。(3) OCR 线程隔离 + 取消接口 + SSE 状态推送。(4) 解析与索引分离——indexContent 纯索引函数。</br>**最后更新**: 2026-06-23 — Task 12-13 实施完成，handoff 同步

---

## 1. 交接前状态

- `document-parser.ts` 使用 `pdfjs-dist@5.7.284` 的 legacy build 做 PDF 文本提取
- `pdfjs-dist` 的 `pdf.worker.mjs` 未被打包进 `.next/server/chunks/`，VPS 运行时找不到 worker
- `@napi-rs/canvas` 未安装，`DOMMatrix`/`Path2D`/`ImageData` 浏览器 API 在 Node.js 中缺失
- `pdf-parse@1.1.1` 为死依赖（源码中未使用）
- `src/tests/setup.ts` 有 DOMMatrix polyfill 仅供 pdf-parse 测试用

## 2. 交接后状态（目标）

- `document-parser.ts` 使用 `unpdf@1.6.2`（零依赖，内置 serverless PDF.js build）
- `parsePdf` 两处调用从 15 行/处简化为 6 行/处，函数签名不变
- `pdfjs-dist` 和 `pdf-parse` 已从 `package.json` 移除
- DOMMatrix polyfill 已从测试 setup 移除
- `tsc --noEmit` 零错误
- **增量 Phase 2**：`parsePdf` 扩展混合解析——文本层优先，空文本自动降级 OCR（`renderPageAsImage` + `tesseract.js`）
- **增量 Phase 2**：`@napi-rs/canvas` 已安装，提供 Node.js Canvas 渲染能力
- **增量 Phase 2**：`tesseract.js`（已安装但此前未使用）激活为 OCR 引擎
- **Phase 3 已完成**：OCR 运行在独立 child_process.spawn 子进程，不阻塞主请求线程
- **Phase 3 已完成**：`POST /api/.../index/cancel` 可随时终止任意类型文档索引，抛弃中间数据
- **Phase 3 已完成**：SSE 通道实时推送索引进度（含 OCR page/totalPages）
- **Phase 3 已完成**：解析与索引分离——`indexContent(content, parsedType)` 纯索引函数，OCR 路径绕过 `parseDocumentFromBuffer`

## 3. 改动清单

| # | 文件 | 操作 | 内容 | 状态 |
|---|------|------|------|------|
| 1 | `package.json` | 修改 | 移除 `pdfjs-dist`、`pdf-parse`，新增 `unpdf@^1.6.2` | ✅ |
| 2 | `src/services/document-parser.ts` | 修改 | 导入换为 `unpdf`，`parsePdf()` 和 `parseDocumentFromBuffer` 的 pdf case 简化 | ✅ |
| 3 | `src/tests/setup.ts` | 修改 | 移除 DOMMatrix polyfill（8 行） | ✅ |
| 4 | `package.json` | 修改 | 新增 `@napi-rs/canvas@^0.1.69`（unpdf renderPageAsImage 必需） | ✅ |
| 5 | `src/services/document-parser.ts` | 修改 | `parsePdf` 扩展 OCR 降级：extractPdfContent 辅助函数 + 两处调用点 | ✅ |
| 6 | `package.json` | 修改 | （可选）新增 `sharp` 图片预处理 | ❌ |
| 7 | `src/workers/ocr-worker.ts` | 新建 | child_process.spawn 子进程：逐页 renderPageAsImage + tesseract OCR，process.send 上报进度，临时文件传递 PDF | ✅ |
| 8 | `src/services/index-job-manager.ts` | 新建 | 统一索引任务管理器：所有文档类型平等，AbortController + ChildProcess 生命周期管理 | ✅ |
| 9 | `src/app/api/knowledge/documents/[id]/index/cancel/route.ts` | 新建 | POST 通用取消接口 → indexJobManager.cancelJob(docId) | ✅ |
| 10 | `src/services/document-parser.ts` + `knowledge-indexer.ts` + `knowledge-sync.ts` | 修改 | extractPdfContent 返回 ocrDeferred，indexer/sync 接入 indexJobManager | ✅ |
| 11 | `src/app/api/knowledge/documents/[id]/progress/route.ts` | 修改 | Phase B: Worker OCR 完成后 poll 进度 + indexContent 直接索引 + SSE 推送 | ✅ |
| 12 | `src/services/knowledge-sync.ts` + `sync/route.ts` + `farm-agent GUI` | 修改 | SyncProgressEvent 结构化 + 逐文档上报 phase/docIndex/totalDocs | ✅ |
| 13 | `agrisynapse: grounding.ts + knowledgeBase/index.vue + customization/index.vue` | 修改 | 同步面板展示当前文档名 + 计数器 + 阶段标签 | ✅ |
| 14 | `src/services/knowledge-indexer.ts` | 重构 | 抽出 `indexContent(content, parsedType)` 纯索引函数，`indexKnowledgeDocumentWithProgress` 退化为薄封装 | ✅ |
| 15 | `src/app/api/knowledge/documents/[id]/progress/route.ts` | 修复 | OCR onComplete 从 `Buffer.from(ocrText)` 改为 `indexContent(id, name, ocrText, "pdf")` | ✅ |

## 4. 回滚方案

### Phase 1 回滚（unpdf 迁移）

```bash
git checkout package.json
git checkout src/services/document-parser.ts
git checkout src/tests/setup.ts
npm install
```

### Phase 1 依赖回滚

```bash
npm install pdfjs-dist@5.7.284 pdf-parse@1.1.1 --legacy-peer-deps
```

### Phase 2 回滚（OCR 降级）

```bash
git checkout src/services/document-parser.ts
```

### Phase 3 回滚（Worker Thread + Cancel API）

```bash
rm src/workers/ocr-worker.ts
rm src/services/index-job-manager.ts
rm -r src/app/api/knowledge/documents/\[id\]/index/
git checkout src/services/document-parser.ts src/services/knowledge-indexer.ts src/services/knowledge-sync.ts src/app/api/knowledge/documents/\[id\]/progress/route.ts
```

## 5. 执行前置检查

- [x] `npx tsc --noEmit` 零错误
- [x] 源码中无 `pdfjs-dist` / `pdf-parse` 残留引用
- [x] `package.json` 中仅有 `unpdf`，无旧依赖
- [x] `@napi-rs/canvas` 已安装（v0.1.100，transitive dep 自动就位）
- [x] OCR 降级路径已实现：扫描型 PDF 可通过 renderPageAsImage + tesseract.js 返回文本
- [x] OCR 降级路径：文本型 PDF 不受影响（快速路径阈值 >=50 字符）
- [x] **Phase 4**：SSE progress 事件结构化——含 phase/currentDoc/docIndex/totalDocs
- [x] **Phase 4**：agrisynapse 同步面板展示当前文档名 + 计数器

## 6. 执行步骤摘要

```text
Phase 1 (已完成):
Task 1 (安装 unpdf) ──┐
                       │
                       ▼
Task 2 (重写 parsePdf) ──┐
                          │
                          ▼
Task 3 (清理 polyfill) ──┐
                          │
                          ▼
Task 4 (tsc 验证) ✅ 通过

Phase 2 (增量):
Task 5 (安装 @napi-rs/canvas)
         │
    ┌────┴────┐
    ▼         ▼
Task 6     Task 7 (sharp 可选)
(OCR降级)
    │
    ▼
Task 8 (OCR 验证)
```

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| unpdf 内置 pdfjs v4.0 vs 原 v5.7 版本差异 | 极端 PDF 格式解析可能不同 | 提取文本 API 兼容；如遇到可换 `configureUnPDF` 使用官方 build |
| `text as string` 类型断言 | TS 重载推断失败 | `mergePages: true` 保证返回 string，断言安全 |
| pm2 运行时需 `npm install` 后重启 | 新依赖未安装 | 部署前执行 `npm install --legacy-peer-deps && pm2 restart farm-agent` |
| **新增**：tesseract.js OCR 速度慢 | 扫描件多页解析耗时长（5-30s/页） | 仅扫描件走 OCR 路径；可限制最大 OCR 页数（如 50 页）；用 `sharp` 预处理加速 |
| **新增**：@napi-rs/canvas 原生编译 | 不同平台/Node 版本需重新编译 | 在 `next.config.ts` 的 `serverExternalPackages` 中追加 `@napi-rs/canvas` |
| **新增 Phase 3**：Worker Thread 创建/销毁开销 | 每个扫描件 PDF 创建新 Worker，频繁操作有开销 | Worker 复用池（后续优化）；当前按需创建 |
| **新增 Phase 3**：Worker 内 prisma 不可用 | Worker Thread 独立上下文，不能直接访问 Prisma | 通过 postMessage 将结果回传主线程，由 manager 写 DB |
| **新增 Phase 3**：worker.terminate() 不保证立即停止 | tesseract.js 内部 wasm 操作可能处于不可中断状态 | AbortController 信号在页间检查，最坏情况等当前页完成（< 30s） |

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用，直接复制粘贴调用即可。共 3 条审计记录可恢复完整开发上下文。

### 总体一键恢复

```text
query_audit_logs({ keyword: "unpdf-migration" })
```
→ 预期返回 3 条记录

### 逐文件审计查询

```text
query_audit_logs({ targetId: "src/services/document-parser.ts" })
→ 预期返回 COMPONENT_MODIFIED: parsePdf 从 pdfjs-dist 迁移到 unpdf

query_audit_logs({ targetId: "package.json" })
→ 预期返回 CONFIG_MODIFIED: 移除 pdfjs-dist/pdf-parse，新增 unpdf

query_audit_logs({ targetId: "src/tests/setup.ts" })
→ 预期返回 CONFIG_MODIFIED: 移除 DOMMatrix polyfill
```

### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE action = 'COMPONENT_MODIFIED' OR action = 'CONFIG_MODIFIED'
ORDER BY "createdAt" DESC
LIMIT 5;
```

### 恢复判定标准

- action 命中数 ≥ 3
- grep 验证命令：

```bash
grep -R "unpdf" src/services/
grep -R "pdfjs-dist\|pdf-parse" src/   # 应无结果
```

---

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过
- [x] 所有文件改动已记录 ADD-7 审计（5 条 record_dev_operation，`query_audit_logs` 可回查）
- [x] 源码中 pdfjs-dist / pdf-parse 残留引用：零
- [x] package.json 依赖干净：仅 unpdf
- [x] `@napi-rs/canvas` 已安装（v0.1.100）
- [x] 扫描型 PDF OCR 路径已实现（`extractPdfContent` 辅助函数）
- [x] 文本型 PDF 快速路径不受影响（阈值门控）
- [x] `parseDocumentFromBuffer` 同步支持 OCR 降级
- [x] OCR 子进程隔离：child_process.spawn + 临时文件传递 PDF
- [x] IndexJobManager 管理 ChildProcess 生命周期 + 通用 cancel API
- [x] 解析与索引分离：`indexContent(content, parsedType)` 纯索引函数
- [x] OCR 路径直接调 `indexContent(ocrText, "pdf")`，不经过 `parseDocumentFromBuffer`
- [x] DPS 门禁通过（88 分 🟢）
