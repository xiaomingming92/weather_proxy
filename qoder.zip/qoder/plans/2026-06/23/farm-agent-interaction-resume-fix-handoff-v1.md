# farm-agent — 交互点 Resume 标准化修复 交接手册

> **适用场景**：单轮变更，修复普通交互点 resume 通道。

---

## 1. 交接前状态

- 普通交互点确认走 `store.sendMessage(choice, { selectedOption })` → 新消息启动新图 run
- 上一轮 State（evidenceChain/reasoningPath）丢失
- KB 矛盾裁决已使用 `resumeAgent` 通道（符合标准）

## 2. 交接后状态（目标）

- 普通交互点统一走 `resumeAgent` 通道
- 后端 `interactionPointDetection` 检测到交互点时调用 `interrupt()` 暂停图
- State 保留在 `MemorySaver`，用户确认后 `Command(resume)` 从断点继续
- KB 矛盾裁决不受影响

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/agents/nodes/interaction-point-detection.ts` | 修改 | +`interrupt()` 调用，暂停图保留 State |
| 2 | `src/lib/agent-audit-logger.ts` | 修改 | 新增 `INTERACTION_INTERRUPT` + `INTERACTION_RESUME` 审计阶段 |
| 3 | `agrisynapse/src/store/modules/agentChat.ts` | 修改 | `resumeWithChoice` 兼容交互点 + KB 矛盾共用 |
| 4 | `agrisynapse/src/views/llm/components/LlmChatView.vue` | 修改 | `handleInteractionSelect` → `resumeWithChoice` |

## 4. 恢复上下文审计查询（新 AI Session 首次启动必读）

> 共 6 条审计记录可恢复完整开发上下文。

### 总体一键恢复

```text
query_audit_logs({ keyword: "interaction-resume" })
```
→ 预期返回 3+ 条（PLAN + COMPONENT）

### 逐文件/逐阶段审计查询

```text
// 代码改动
query_audit_logs({ targetId: "interaction-point-detection.ts+agentChat.ts+LlmChatView.vue" })
→ 预期返回 COMPONENT_MODIFIED: interactionPoint确认改为interrupt()+Command(resume)

// 文档生成
query_audit_logs({ targetId: "farm-agent-interaction-resume-add-route-v1" })
→ 预期返回 DOC_CREATED: specs三元组+add-route

// 审计阶段
query_audit_logs({ keyword: "INTERACTION_INTERRUPT" })
→ 预期返回 1 条: interactionPointDetection.agentAudit("INTERACTION_INTERRUPT", ...)

query_audit_logs({ keyword: "INTERACTION_RESUME" })
→ 预期返回 1 条: interactionPointDetection.agentAudit("INTERACTION_RESUME", ...)
```

### 恢复判定标准

- action 命中数 ≥ 3
- grep 验证命令：

```bash
grep -R "interrupt\|INTERACTION_INTERRUPT\|INTERACTION_RESUME" src/agents/nodes/interaction-point-detection.ts
grep -R "resumeWithChoice" agrisynapse/src/store/modules/agentChat.ts agrisynapse/src/views/llm/components/LlmChatView.vue
```

## 5. 后置确认

- [x] farm-agent `npx tsc --noEmit` 零错误
- [x] agrisynapse `vue-tsc --noEmit` 无新增错误
- [x] ADD-7 审计记录已落库（6 条）
- [x] RAHS = 100
- [R] 交互点确认后 evidenceChain 不丢失（运行时验证）

## 6. 关联文档

| 文档 | 路径 |
|------|------|
| Plan | `.qoder/plans/farm-agent-interaction-resume-fix-plan-v1.md` |
| add-route | `.qoder/plans/farm-agent-interaction-resume-add-route-v1.md` |
| Spec | `.qoder/specs/farm-agent-interaction-resume-fix/spec.md` |
| Tasks | `.qoder/specs/farm-agent-interaction-resume-fix/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-interaction-resume-fix/checklist.md` |
| SSE 协议文档 | `docs/.../瑞丰耘H5小程序SSE流式聊天协议文档.md`（§7.2-7.3 已标注修正） |
