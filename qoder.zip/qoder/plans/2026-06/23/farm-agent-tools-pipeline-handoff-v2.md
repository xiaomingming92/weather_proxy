# farm-agent — 工具调用管线 交接手册

> **适用场景**：单轮变更，新增工具调用管线、三层认证栈、语义零泄露端点安全。

---

## 1. 交接前状态

- farm-agent 的 LangGraph 管线只有 6 个节点（intention → retrieval → reasoning → interactionPointDetection → verdict → response），无工具调用节点
- LLM 无法自主调用外部 API 获取 Farm-Server 数据
- 天气/时间工具从 co-agent 迁移时被主动排除
- 无认证体系：无 credential 表、无 user_profile 表、无 neuron 认证
- 端点路径为静态 `/api/agent/...`，可被枚举爆破
- 决策管线架构说明书 1615 行中仅 1 处提及"工具"

---

## 2. 交接后状态（目标）

- 管线新增 ToolNode 节点 + 条件路由边，LLM 可自主调用 ~25 个工具
- 三层认证栈就绪：neuron→agent（session）、agent→Farm-Server（credential 持久化）、LLM tool 隔离（代码边界）
- 单端点 `/api/agent/{hash}` 语义零泄露，hash 10 分钟滚动，种子文字在 `.env` 不硬编码
- 9 个技能卡片数据通路打通：3 热加载（握手预载）+ 6 惰性（点击触发）
- 支持 GUI 断开/agent 重启后的任务恢复（credential 持久化 + LangGraph checkpoint）
- Farm-Server 5 个数据工具 + 天气 4 个工具 + 时间 1 个工具全部可用
- agrisynapse 侧新增 `src/utils/farm-agent-hash.ts`（~15 行）+ `.env` HASH_SEED_TEXT

### 2.1 agrisynapse → farm-agent API 合约

> 以下为 agrisynapse GUI 需要调用的全部接口。所有请求须携带 session cookie（SERVICE role User 登录态）。

#### 2.1.1 前置：计算 hash

```typescript
// agrisynapse/src/utils/farm-agent-hash.ts
const HASH_SEED = process.env.HASH_SEED_TEXT!;  // 与 farm-agent 同值

export function getFarmAgentHash(): string {
  const window = Math.floor(Date.now() / 600_000);  // 10 分钟窗口
  return crypto.createHash('sha256')
    .update(HASH_SEED + window)
    .digest('hex')
    .slice(0, 12);
}
```

所有请求 URL = `${farmAgentBase}/api/agent/${getFarmAgentHash()}`。

#### 2.1.2 登录（SERVICE role）

```
POST /api/auth/login
Content-Type: application/json

{
  "username": "${AGENT_SERVICE_USERNAME}",
  "password": "${AGENT_SERVICE_PASSWORD}"
}

→ Response { sessionCookie, user: { id, role: "SERVICE" } }
→ 失败 401
```

凭据来自 agrisynapse `.env`（`AGENT_SERVICE_USERNAME` / `AGENT_SERVICE_PASSWORD`），与 farm-agent 种子脚本创建的账号一致。

#### 2.1.3 仪表盘（技能卡片 + 推荐话题）

```
GET /api/agent/{hash}?action=dashboard
Cookie: session=...

→ Response {
  cards: [
    { id, label, domain, description }  // 9 个技能卡片
  ],
  topics: [
    { text, intent }
  ],
  nextHash: "a3b9c1d2e4f5"  // 下一窗口 hash，GUI 预存
}
→ hash 不对 404
→ 未登录 401
```

#### 2.1.4 握手（传 token + 用户信息）

```
POST /api/agent/{hash}
Cookie: session=...
Content-Type: application/json

{
  "type": "handshake",
  "token": "${farmServerAccessToken}",
  "refreshToken": "${farmServerRefreshToken}",
  "user": {
    "id": 42,
    "username": "zhangsan",
    "nickname": "张三",
    "deptId": 3,
    "deptName": "生产部",
    "email": "zhangsan@farm.com",
    "mobile": "13800138000"
  }
}

→ Response {
  threadId: "thread_abc123",
  nextHash: "b4c2d3e5f6a7"
}
→ 401 token 无效时返回 { error: "TOKEN_EXPIRED" }，agrisynapse 需重新登录 Farm-Server
```

#### 2.1.5 对话（SSE stream）

```
POST /api/agent/{hash}
Cookie: session=...
Content-Type: application/json

{
  "type": "chat",
  "threadId": "thread_abc123",
  "message": "今天的农场情况怎么样？"
}

→ SSE stream（text/event-stream）

事件类型:
  data: {"event":"thinking","content":"正在分析..."}
  data: {"event":"tool_call","tool":"query_soil_moisture","args":{...}}
  data: {"event":"tool_result","tool":"query_soil_moisture","result":{...}}
  data: {"event":"token","content":"根据"}
  data: {"event":"token","content":"最新"}
  ...
  data: {"event":"done","threadId":"thread_abc123"}
  data: {"event":"error","message":"..."}
```

agrisynapse 按 `event` 字段分发 UI 渲染：`thinking` → 加载动画，`tool_call/tool_result` → 工具调用卡片，`token` → 流式文字，`done` → 结束，`error` → 错误提示。

#### 2.1.6 查询对话历史

```
GET /api/agent/{hash}?action=thread&id=thread_abc123
Cookie: session=...

→ Response {
  threadId: "thread_abc123",
  status: "active" | "completed" | "error",
  messages: [
    { role: "user" | "assistant" | "tool", content, timestamp }
  ]
}
```

用途：GUI 关闭后重连恢复对话。

#### 2.1.7 导出报告

```
GET /api/agent/{hash}?action=report&id=thread_abc123&format=md
Cookie: session=...

→ Response { content: "# 农情日报\n...", format: "md" }
```

#### 2.1.8 错误码汇总

| HTTP 状态 | 含义 | agrisynapse 处理 |
|-----------|------|-----------------|
| 200 | 正常 | — |
| 401 | 未登录或 session 过期 | 重新 POST /api/auth/login |
| 404 | hash 不匹配（10 分钟窗口已过） | 重新计算 hash 重试 |
| 200 + body `{error:"TOKEN_EXPIRED"}` | Farm-Server token 过期且 refresh 失败 | 重新登录 Farm-Server → 再次 handshake |
| SSE `event:"error"` | 对话执行异常 | 显示错误信息，保留 threadId 供重试 |

#### 2.1.9 nextHash 机制（窗口切换零中断）

##### 为什么需要 nextHash

hash 每 10 分钟滚动一次。如果 agrisynapse 只用本地 `getFarmAgentHash()` 计算，窗口切换瞬间可能出现：

```
agrisynapse 本地窗口 = N，算得 hash_A
farm-agent 窗口刚好切到 N+1，期望 hash_B
→ 请求 hash_A → 404
```

getFarmAgentHash 内置 ±1 窗口容差可以缓解，但依赖两端时钟严格同步。`nextHash` 让 farm-agent **主动告知**下一窗口的正确 hash，消除时钟漂移风险。

##### farm-agent 侧：生成 nextHash

```typescript
// src/lib/hash-path.ts
export function getNextHash(): string {
  const nextWindow = Math.floor(Date.now() / 600_000) + 1;  // 窗口 +1
  return crypto.createHash('sha256')
    .update(process.env.HASH_SEED_TEXT! + nextWindow)
    .digest('hex')
    .slice(0, 12);
}
```

每个非 SSE 响应（dashboard、handshake、thread、report）都在 JSON body 中附带 `nextHash` 字段。SSE 的 `done` 事件同样附带 `nextHash`。

##### agrisynapse 侧：使用 nextHash

```typescript
// agrisynapse/src/utils/farm-agent-hash.ts

let activeHash: string | null = null;   // 当前正在使用的 hash
let nextHash: string | null = null;     // farm-agent 告知的下一窗口 hash

/** 每次收到 farm-agent 响应后调用 */
export function updateHashFromResponse(resp: { nextHash?: string }) {
  if (resp.nextHash) {
    activeHash = resp.nextHash;  // 服务器告知的当前窗口 hash
    nextHash = resp.nextHash;     // 同时也是下一次要用的
  }
}

/** 发起请求前调用，决定用哪个 hash */
export function getRequestHash(): string {
  // 1. 先本地算当前窗口 hash
  const localHash = computeLocalHash();

  // 2. 如果本地 hash 和上次用的 activeHash 不同 → 窗口已切换
  //    优先用 nextHash（来自 farm-agent，零漂移风险）
  if (activeHash && localHash !== activeHash && nextHash) {
    return nextHash;
  }

  // 3. 正常情况：本地算的就对
  return localHash;
}

/** 收到 404 后的回退：本地算 ±1 窗口 */
export function getFallbackHash(): string[] {
  const now = Math.floor(Date.now() / 600_000);
  return [now - 1, now, now + 1].map(w =>
    crypto.createHash('sha256')
      .update(process.env.HASH_SEED_TEXT! + w)
      .digest('hex')
      .slice(0, 12)
  );
}
```

##### agrisynapse 请求流程

```
发起请求
  │
  ├─ getRequestHash() → 拼 URL
  │   ├─ 有 nextHash 且窗口已切换 → 用 nextHash
  │   └─ 否则 → 本地计算
  │
  ├─ 发送请求
  │   ├─ 200 → 调 updateHashFromResponse(resp) 更新 activeHash/nextHash
  │   └─ 404 → getFallbackHash() 重试 3 次（3 个窗口）
  │       ├─ 成功 → updateHashFromResponse
  │       └─ 全部 404 → 重新 login + handshake
```

##### 关键边界

| 场景 | agrisynapse 行为 |
|------|-----------------|
| 正常使用，窗口内 | 本地 hash = activeHash，直接发请求 |
| 窗口刚切换，上一响应带了 nextHash | 本地 hash ≠ activeHash，切到 nextHash，无缝 |
| 断连 > 10 分钟，nextHash 已过期 | 本地计算 + fallback 重试 3 窗口，命中后恢复 |
| 首次启动（无 activeHash/nextHash） | 纯本地计算，依赖 ±1 容差 |
| farm-agent 时钟比 agrisynapse 快 > 10 分钟 | fallback 也覆盖不了 → 重新 login + handshake 重置 |

### 2.2 环境变量（两端共享）

| 变量 | farm-agent | agrisynapse | 说明 |
|------|-----------|-------------|------|
| `HASH_SEED_TEXT` | `.env` | `.env` | **两端必须同值**，需求文档关键段落 |
| `AGENT_SERVICE_USERNAME` | `.env` | — | SERVICE 账号用户名 |
| `AGENT_SERVICE_PASSWORD` | `.env` | — | SERVICE 账号密码 |
| `AGENT_SERVICE_USERNAME` | — | `.env` | 同上，agrisynapse 用于登录 |
| `AGENT_SERVICE_PASSWORD` | — | `.env` | 同上 |

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `prisma/schema.prisma` | 修改 | 新增 farm_server_credential 表、user_profile 表，User.Role 新增 SERVICE 枚举 |
| 2 | `src/lib/auth/credential-store.ts` | 新建 | auth 层 token CRUD，项目唯一引用 prisma.farmServerCredential |
| 3 | `src/lib/auth/token-manager.ts` | 新建 | refresh 逻辑 + 请求来源区分 |
| 4 | `src/lib/hash-path.ts` | 新建 | 动态 hash 路径生成（process.env.HASH_SEED_TEXT + 10分钟窗口 → SHA-256） |
| 5 | `src/lib/farm-server-client.ts` | 新建 | 通用 HTTP 客户端，bearer/qweather 双 auth |
| 6 | `src/lib/farm-server-client-dev-logger.ts` | 新建 | Layer1 审计（console + file + DB metadata） |
| 7 | `src/lib/farm-server-client-audit.ts` | 新建 | Layer2 审计（AuditLog 表） |
| 8 | `src/app/api/agent/[hash]/route.ts` | 新建 | 单端点 GET（thread/dashboard/report）+ POST（handshake/chat SSE） |
| 9 | `src/middleware.ts` | 新建 | hash 验证（404）+ session 校验（401） |
| 10 | `src/agents/tools/impl/weather-tools.ts` | 新建 | 从 co-agent 迁移，改用 farm-server-client(qweather) |
| 11 | `src/agents/tools/impl/time-tools.ts` | 新建 | 从 co-agent 迁移 |
| 12 | `src/agents/tools/schemas/weather-tools.ts` | 新建 | Zod schema |
| 13 | `src/agents/tools/schemas/time-tools.ts` | 新建 | Zod schema |
| 14 | `src/lib/weather-dev-logger.ts` | 新建 | 天气工具 Layer1 审计 |
| 15 | `src/lib/weather-audit.ts` | 新建 | 天气工具 Layer2 审计 |
| 16 | `src/lib/time-tool-dev-logger.ts` | 新建 | 时间工具 Layer1 审计 |
| 17 | `src/lib/time-tool-audit.ts` | 新建 | 时间工具 Layer2 审计 |
| 18 | `src/agents/tools/impl/soil-moisture-tool.ts` + schema + audit | 新建 | 土墒数据查询工具（3 文件） |
| 19 | `src/agents/tools/impl/insect-data-tool.ts` + schema + audit | 新建 | 虫情数据查询工具（3 文件） |
| 20 | `src/agents/tools/impl/insect-type-tool.ts` + schema + audit | 新建 | 虫害类别查询工具（3 文件） |
| 21 | `src/agents/tools/impl/farm-weather-tool.ts` + schema + audit | 新建 | 气象站数据查询工具（3 文件） |
| 22 | `src/agents/tools/impl/massif-tool.ts` + schema + audit | 新建 | 地块查询工具（3 文件） |
| 23 | `src/agents/tools/index.ts` | 修改 | 注册 ~25 个工具 |
| 24 | `src/agents/index.ts` | 修改 | 添加 ToolNode + 条件路由边 |
| 24a | `src/agents/nodes/response.ts` | 修改 | `buildToolExecutionSummary` 修复：优先消费 `state.toolResults`，降级兼容 ToolMessage JSON 解析；State 新增 `toolResults` 结构化字段（见 Runtime Review v2 F7-F9） |
| 24b | `src/agents/state.ts` | 修改 | 新增 `toolResults` 字段：`Array<{toolName, success, recordCount, list, columns?, error?}>` |
| 25 | `src/agents/experts/registry.ts` | 修改 | 扩展至 9 个专家：3 热加载 + 6 惰性 |
| 26 | `.env.development` / `.env.production` | 修改 | 新增 HASH_SEED_TEXT、神经元账号凭据 |
| 27 | `docs/.../决策管线架构说明书.md` | 修改 | 补充 toolNode 章节 |

### agrisynapse 侧

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 28 | `src/utils/farm-agent-hash.ts` | 新建 | 本地 hash 计算（~15 行，process.env.HASH_SEED_TEXT + 时间窗口） |
| 29 | `.env` | 修改 | 新增 HASH_SEED_TEXT（与 farm-agent 同值） |
| 30 | axios interceptor / 请求层 | 修改 | URL 拼接方式从静态路径 → `/${getFarmAgentHash()}` |

---

## 4. 回滚方案

### 代码回滚

```bash
git revert <commit>
# 或
git reset --hard <previous-commit>
```

### 数据库回滚

```bash
npx prisma migrate reset  # 回滚到迁移前状态
# 或手动:
DROP TABLE IF EXISTS "farm_server_credential";
DROP TABLE IF EXISTS "user_profile";
-- 移除 User.Role 中的 SERVICE 枚举值需重建 enum
```

### agrisynapse 侧回滚

- 删除 `src/utils/farm-agent-hash.ts`
- 移除 `.env` 中的 HASH_SEED_TEXT
- 恢复 axios URL 为静态路径

---

## 5. 执行前置检查

- [ ] PostgreSQL 可连接，Prisma migrate 可用
- [ ] co-agent 天气/时间工具源码可访问（commit dae1c76）
- [ ] Farm-Server 6 份 API 文档已就位（docs/.../02-规范/ 下）
- [ ] `.env.development` 已配置 HASH_SEED_TEXT（需求文档关键段落，与 agrisynapse 同值）
- [ ] `.env.development` 已配置和风天气 API 凭据
- [ ] `.env.development` 已配置 agrisynapse SERVICE role 账号（用户名/密码）
- [ ] `npx tsc --noEmit` 当前无错误（或已知错误与本变更无关）
- [ ] agrisynapse NTP 时间同步正常（hash 滚动依赖时间对齐）

---

## 6. 执行步骤摘要

```text
Phase 1 ── 数据层
  Schema 新增 credential + user_profile + SERVICE role
  npx prisma migrate dev
            │
            ▼
Phase 2 ── 基础设施
  credential-store + token-manager (auth 层)
            ├──────────────┐
            ▼              ▼
       hash-path.ts    farm-server-client.ts
            │              │
            └──────┬───────┘
                   ▼
Phase 3 ── 业务层
  /api/agent/[hash]/route.ts (单端点)
            │
    ┌───────┼───────────┐
    ▼       ▼           ▼
  天气迁移  FS工具   handshake + dashboard
  (8文件)  (15文件)
    │       │           │
    └───────┼───────────┘
            ▼
Phase 4 ── 集成
  tools/index.ts 注册 + agents/index.ts ToolNode
            │
            ▼
  middleware.ts (hash + session)
            │
            ▼
  npx tsc --noEmit → npm run build → E2E
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| HASH_SEED_TEXT 泄露或两端不一致 | hash 计算不一致导致 agrisynapse 无法访问 farm-agent | 两端 .env 配置后立即调用 GET ?action=dashboard 验证 |
| 服务器 NTP 时间偏差 > 10分钟 | hash 窗口跨度过大，±1 容差无法覆盖 | 标准 NTP 运维，偏差通常 < 1 秒 |
| credential-store 被 LLM tool 意外引用 | 安全隔离失效，LLM 可获取 token | 编译后 grep 检查：0 个 tool 文件 import credential-store |
| Farm-Server API code 字段从 0 改为 200 | 旧文档误导，code: 0 判定逻辑错误 | 以 6 份最新 API 文档为准，统一 code: 200 |
| pageSize 上限 200 被忽略 | 分页查询性能下降 | 工具 schema 中 Zod 校验 pageSize ≤ 200 |
| 天气工具 JWT 凭据在迁移时泄露 | co-agent → farm-agent 复制携带真实凭据 | 迁移时用 .env 变量替换硬编码值 |
| agrisynapse SaaS 多租户场景 | 多个 agrisynapse 实例共享同一 farm-agent | 当前单租户部署，多租户需后续扩展 session 隔离 |

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用，AI 助手在自己的对话中**直接复制粘贴这些参数调用工具即可**，不需要写 SQL。共 30 条审计记录可恢复完整开发上下文。

### 总体一键恢复

```text
query_audit_logs({ keyword: "tools-calling-pipeline" })
```
→ 预期返回 30+ 条记录

### 逐模块审计查询

```text
query_audit_logs({ targetId: "prisma/schema.prisma" })
→ 预期返回 SCHEMA_MODIFIED: 新增 credential/user_profile 表 + SERVICE role

query_audit_logs({ targetId: "src/lib/auth/credential-store.ts" })
→ 预期返回 COMPONENT_CREATED: auth 层 token 持久化模块

query_audit_logs({ targetId: "src/lib/hash-path.ts" })
→ 预期返回 COMPONENT_CREATED: 动态 hash 路径生成模块

query_audit_logs({ targetId: "src/lib/farm-server-client.ts" })
→ 预期返回 COMPONENT_CREATED: 通用 HTTP 客户端

query_audit_logs({ targetId: "src/app/api/agent/[hash]/route.ts" })
→ 预期返回 API_ROUTE_CREATED: 单端点 Route Handler

query_audit_logs({ targetId: "src/middleware.ts" })
→ 预期返回 COMPONENT_CREATED: hash 验证 + session 校验

query_audit_logs({ targetType: "COMPONENT", keyword: "weather" })
→ 预期返回 4 条: weather-tools 相关文件

query_audit_logs({ targetType: "COMPONENT", keyword: "time-tool" })
→ 预期返回 2 条: time-tools 相关文件

query_audit_logs({ keyword: "soil-moisture" })
→ 预期返回 3 条: soil-moisture-tool + schema + audit

query_audit_logs({ keyword: "insect-data" })
→ 预期返回 3 条: insect-data-tool + schema + audit

query_audit_logs({ keyword: "insect-type" })
→ 预期返回 3 条: insect-type-tool + schema + audit

query_audit_logs({ keyword: "farm-weather" })
→ 预期返回 3 条: farm-weather-tool + schema + audit

query_audit_logs({ keyword: "massif-tool" })
→ 预期返回 3 条: massif-tool + schema + audit

query_audit_logs({ targetId: "src/agents/tools/index.ts" })
→ 预期返回 COMPONENT_MODIFIED: 工具注册

query_audit_logs({ targetId: "src/agents/index.ts" })
→ 预期返回 COMPONENT_MODIFIED: ToolNode + 条件路由
```

### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE "targetId" IN (
  'prisma/schema.prisma',
  'src/lib/auth/credential-store.ts',
  'src/lib/hash-path.ts',
  'src/lib/farm-server-client.ts',
  'src/app/api/agent/[hash]/route.ts',
  'src/middleware.ts',
  'src/agents/tools/index.ts',
  'src/agents/index.ts'
)
ORDER BY "createdAt" DESC;
```

### 恢复判定标准

- action 命中数 ≥ 30
- grep 验证命令：

```bash
grep -R "farm_server_credential\|user_profile\|hash-path\|farm-server-client" .qoder/specs/ .qoder/plans/
```

---

## 9. 后置确认

- [ ] `npx tsc --noEmit` 通过
- [ ] `npm run build` 成功
- [ ] credential-store 隔离验证：grep 确认 0 个 tool 文件引用 prisma.farmServerCredential
- [ ] HASH_SEED_TEXT 安全验证：grep 确认种子文字不在代码中
- [ ] 禁止 tool 验证：grep 确认不存在文件系统/通用 HTTP/代码执行 tool
- [ ] GET ?action=dashboard 正常返回技能卡片
- [ ] POST handshake → credential 存储 + user_profile upsert
- [ ] POST chat → SSE stream 正常，tool_call 阶段可调 Farm-Server
- [ ] agrisynapse hash 计算与 farm-agent 一致（同时间窗口 GET dashboard 成功）
- [ ] hash 跨 10 分钟窗口自动滚动，对话不中断
- [ ] GUI 关闭 → agent 继续 → 重连恢复
- [ ] agent 重启 → credential 恢复 → pending 任务继续
- [ ] 所有文件改动已记录 ADD-7 审计（`query_audit_logs` 可回查）

---

### 脱敏要求

Handoff 文档中 **禁止出现** 以下类型的硬编码值：
- 数据库密码（`POSTGRES_PASSWORD`）
- 和风天气 API Key（`QWEATHER_API_KEY`）
- JWT 密钥（`JWT_SECRET`）
- HASH_SEED_TEXT 种子文字原文

所有凭据值应通过 `${ENV_VAR}` 引用，并标注"值见 `.env.development` / `.env.production`"。
