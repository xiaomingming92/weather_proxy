# farm-agent-toolresults-contract-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"，包含 `check_spec_sync` 文档-代码交叉校验。
>
> **绑定**：Plan: `.qoder/plans/farm-agent-tools-pipeline-plan-v1.md` · Spec: `.qoder/specs/tools-calling-pipeline/spec.md` · Tasks: `.qoder/specs/tools-calling-pipeline/tasks.md` · Handoff: `.qoder/plans/farm-agent-tools-pipeline-handoff-v2.md`

---

## STEP 0 状态

- [x] Plan 已就绪（`.qoder/plans/farm-agent-tools-pipeline-plan-v1.md`，§3.5.1 + §4 Task 7 + ADD-7 审计策略表已回流）
- [x] Specs 三元组已更新（`spec.md` 新增 Requirement "Tool 结果结构化通道"，`tasks.md` 新增 Phase 5，`checklist.md` 新增 Phase 5 验证项）
- [x] Handoff 已更新（`handoff-v2.md` §3 新增 24a/24b 改动项）
- [x] Runtime Review v2 已生成并回流至 Plan（F7/F8/F9 → ✅ 已回流）
- [ ] DPS 闸门待通过

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全。

**输入**：
- Runtime Review v2（触发来源）
- Plan 文档（`farm-agent-tools-pipeline-plan-v1.md` §3.5.1 / §4 Task 7）
- Specs 三元组（`tools-calling-pipeline/spec.md` + `tasks.md` + `checklist.md`）
- Handoff v2（`farm-agent-tools-pipeline-handoff-v2.md` §3）

**动作**：
1. 确认 Specs 三元组就绪：`spec.md`（含 Tool 结果结构化通道 Requirement）+ `tasks.md`（Phase 5）+ `checklist.md`（Phase 5 验证项）
2. `find_related_docs` 无需调用——本次修复限定在 `src/agents/state.ts` + `src/agents/index.ts` + `src/agents/nodes/response.ts` 三个文件，不涉及 `docs/` 项目知识库文档
3. 项目文档无需更新——本次修复是内部数据契约补齐，不改变外部 API 合约和业务语义
4. Handoff v2 已更新 §3 改动清单（新增 24a response.ts + 24b state.ts）

**产出**：
- [x] 验证并更新项目状态：Specs 三元组路径确认
- [x] 验证并更新项目状态：项目文档无需更新声明已记录（内部契约补齐，不影响外部合约）
- [x] 验证并更新项目状态：Handoff v2 就绪

### §0.7 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: 修复 ToolNode→Response 数据契约，使 LLM 工具结果摘要 recordCount 正确反映实际记录数

Task Groups: T5.1(state.ts) / T5.2(index.ts) / T5.3(response.ts) / T5.4(audit)

逐组业务价值判定:
  T5.1 (state.ts 类型定义): 不能用 — 仅类型定义，无用户可感知功能
  T5.2 (ToolNode 写入): 不能用 — 写入数据但无人消费，LLM prompt 无变化
  T5.3 (Response 消费): 不能用 — 读取 toolResults 但从未被写入，回退到旧路径
  T5.4 (审计): 不能用 — 仅审计记录，无功能行为

判定结论: 需要 1 轮（1 个原子闭包）

第1轮（原子闭包1）: Task Groups {5.1, 5.2, 5.3, 5.4}
  业务功能: LLM prompt 中工具结果摘要 recordCount 从永久 0 变为正确反映实际记录数
  可独立提交✅ — 用户能看到 LLM 回复中工具摘要从"返回 0 条"变成"返回 20 条"
  可独立验证✅ — tsc --noEmit + checklist Phase 5 全部 [T] 项
  可独立审计✅ — 有 TOOL_RESULTS_WRITE / TOOL_RESULTS_CONSUME phase + agentAudit 调用
  可独立恢复✅ — query_audit_logs({ keyword: "toolResults" }) 可回溯
```

### §0.8 DPS 闸门

调用 `check_dps({ planKeyword: "toolResults" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |
| 70–84 | 🟡 | 回退补齐短板 |
| < 70 | 🔴 | 回退细化 Plan |

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的审计阶段。

**输入**：
- Plan §3.5.1 数据契约规范
- `tasks.md` Phase 5 的 4 个 Task
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase`

**动作**：
1. 列出本次变更涉及的业务阶段：ToolNode 写入 toolResults（`TOOL_RESULTS_WRITE`）、Response 消费 toolResults（`TOOL_RESULTS_CONSUME`）
2. 在 `AgentAuditPhase` 联合类型中新增 `TOOL_RESULTS_WRITE`、`TOOL_RESULTS_CONSUME`

**产出**：
- [ ] 验证并更新项目状态：审计阶段清单已同步到 tasks.md Step 1 区域

| Phase | 使用场景 | Task |
|-------|---------|------|
| `TOOL_RESULTS_WRITE` | ToolNode 包装器写 `state.toolResults` | Task 5.2 |
| `TOOL_RESULTS_CONSUME` | Response 节点 `buildToolExecutionSummary` 读 `state.toolResults` | Task 5.3 |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用。

**输入**：
- `src/lib/agent-audit-logger.ts`
- Step 1 新增的 `AgentAuditPhase` 字面量

**动作**：
1. 确认 `agentAudit(phase, detail, extra?)` 接受 `TOOL_RESULTS_WRITE` / `TOOL_RESULTS_CONSUME`
2. 确认三通道输出正常
3. 无需新建 logger 文件

**产出**：
- [ ] 验证并更新项目状态：`agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan 的 Task 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

**输入**：
- Plan §3.5.1 Tool 结果序列化格式规范
- `tasks.md` Phase 5 的 Task 5.1~5.4
- Handoff v2 ADD-7 审计策略表

**动作**：

### §3.0 前置守卫

调用 `check_add_route_status` 确认 add-route 文件有效存在。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 5.1 | State 新增 toolResults 字段 | `src/agents/state.ts` | 无（类型定义） | — | 无 | ⬜ |
| 5.2 | ToolNode 写入 toolResults | `src/agents/index.ts` | `agentAudit("TOOL_RESULTS_WRITE", ...)` | `TOOL_RESULTS_WRITE` | Task 5.1 | ⬜ |
| 5.3 | Response 消费 toolResults | `src/agents/nodes/response.ts` | `agentAudit("TOOL_RESULTS_CONSUME", ...)` | `TOOL_RESULTS_CONSUME` | Task 5.2 | ⬜ |
| 5.4 | ADD 审计 | 以上 3 文件 | `record_dev_operation` | — | Task 5.3 | ⬜ |

### 依赖拓扑

```
Task 5.1 (state.ts 类型定义) ──→ Task 5.2 (index.ts ToolNode 写入)
                                          │
                                          ▼
                                   Task 5.3 (response.ts 消费)
                                          │
                                          ▼
                                   Task 5.4 (审计记录)
```

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计
3. **验证并更新项目状态**：将该 Task 在 `tasks.md` 中逐子项勾选为 `[x]`

**产出**：
- [ ] 验证并更新项目状态：全部 Task 的 `[T]` 项通过
- [ ] 验证并更新项目状态：每个文件有 `record_dev_operation` 记录
- [ ] 验证并更新项目状态：`check_spec_sync` 通过

---

## Step 3.5：实现审查

**目的**：代码完成后，验证意图与实现无语义鸿沟。

**输入**：
- `checklist.md` Phase 5 验证项
- `review-implementation-template.md`

**动作**：
1. 逐项执行 `checklist.md` Phase 5 全部验证项
2. 生成 `review-implementation.md`
3. 生成 `review-runtime.md`（含 `[R]` 待验证清单）
4. 调用 `check_spec_sync` 确认勾选状态

**产出**：
- [ ] 验证并更新项目状态：`checklist.md` Phase 5 全部项已通过并勾选
- [ ] 验证并更新项目状态：`review-implementation.md` 已生成
- [ ] 验证并更新项目状态：`review-runtime.md` 已生成
- [ ] 验证并更新项目状态：`check_spec_sync` 通过

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**动作**：
1. `npx tsc --noEmit`
2. 调用 `check_phase_symmetry`
3. 调用 `check_failure_path`
4. 调用 `check_spec_sync`

**产出**：
- [ ] `tsc --noEmit` 通过
- [ ] 阶段对称性验证通过
- [ ] 失败路径审计等价验证通过
- [ ] `check_spec_sync` 通过

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "toolResults" })`。

| RAHS | 判定 | 动作 |
|------|:--:|------|
| ≥ 90 | 🟢 | 进入 Step 5 |
| 70–89 | 🟡 | 自检 |
| < 70 | 🔴 | 返工 |

- [ ] RAHS 已通过（≥ 90）

---

## Step 5：AI 自动合规检查

**目的**：扫描修改文件的 ADD-1~ADD-7 合规性。

**动作**：
1. 对 `state.ts` / `index.ts` / `response.ts` 调用 `check_add_compliance`
2. 汇总合规报告

**产出**：
- [ ] 合规报告已生成
- [ ] `checklist.md` ADD 规则合规检查项已同步勾选

---

## Step 8：收敛判断 + Handoff 更新

**目的**：功能收敛判定，更新 Handoff。

**动作**：
1. 收敛判断：全部 `[T]` 项通过 + RAHS ≥ 90 → 功能收敛
2. 更新 Handoff v2 的 §8（恢复上下文审计查询）、§9（后置确认）
3. Step 0 第二阶段：架构文档无需更新（内部契约补齐）
4. `query_audit_logs` 确认全部审计记录已落库

**产出**：
- [ ] 收敛判定结果
- [ ] `tasks.md` + `checklist.md` 全部完成项已勾选
- [ ] `check_spec_sync` 四者一致确认
- [ ] Handoff 已更新
- [ ] ADD-7 审计记录已落库确认

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/agents/state.ts` | MODIFY | 5.1 | COMPONENT | ⬜ |
| `src/agents/index.ts` | MODIFY | 5.2 | COMPONENT | ⬜ |
| `src/agents/nodes/response.ts` | MODIFY | 5.3 | COMPONENT | ⬜ |
| `src/lib/agent-audit-logger.ts` | MODIFY | 1 | COMPONENT | ⬜ |
