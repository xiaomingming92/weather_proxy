# farm-agent-isSummary-toolcall-fix-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。**不要**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-isSummary-toolcall-fix-v1
- **启动时间**: 2026-06-23T18:00:00+08:00
- **主导 AI**: Qoder
- **Plan 类型**: 子 Plan（修复型）
- **父 Plan**: `farm-agent-deep-kb-dualpath-retrieval-plan-v1.md` §Task 6.5
- **触发来源**: `.qoder/reviews/farm-agent-deep-kb-dualpath-retrieval-review-runtime-v1.md`（F1-F3）
- **关联文档**:
  - Runtime Review: `.qoder/reviews/farm-agent-deep-kb-dualpath-retrieval-review-runtime-v1.md`（🆕 2026-06-23）
  - 父 Plan Review: `.qoder/reviews/farm-agent-deep-kb-dualpath-retrieval-review-v1.md`
  - 历史 Review: `.qoder/reviews/farm-agent-tool-calls-blocked-runtime-review-v1.md`（F3 同类修复）
  - ADD Route: `.qoder/plans/farm-agent-isSummary-toolcall-fix-add-route-v1.md`（待生成）
  - Handoff: `.qoder/plans/farm-agent-isSummary-toolcall-fix-handoff-v1.md`（待生成）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/agents/nodes/intention.ts | COMPONENT | COMPONENT_MODIFIED | L158-186 强制注入在 L78 explicitIntent 之后，Dashboard 点击时不可达；hasToolResult 判定跨轮次污染 | 强制注入移到 L78 之前；hasToolResult 收窄到本轮（最后 user message 之后） | 🔴 待实施 |
| src/types/evidence.ts | TYPE | TYPE_MODIFIED | EvidenceSource 联合 12 值，无 "tool_result" | 新增 "tool_result" 字面量 | 🔴 待实施 |
| src/agents/nodes/reasoning.ts | COMPONENT | COMPONENT_MODIFIED | isSummary 跳过 retrieval 后 evidenceChain 为 null/[]，工具结果不写回；expertPackages 不自行构建，旧路径不可达 | 工具结果回写 evidenceChain；expertPackages 为 undefined 时自行构建 | 🔴 待实施 |
| src/caijuehub/caijue.toml | DECISION_REGISTRY | REGISTRY_UPDATED | resolve-evidence-source 无跨轮次约束 | 补充 F1 跨轮次污染约束 + isSummary 工具调用闭环约束 | ✅ 已完成 |
| src/app/api/agent/chat/stream/route.ts | API_ROUTE | API_ROUTE_MODIFIED | token provider 注入仅读 authUser?.userId 和 user?.id，漏读 body.userId（agrisynapse 发送的顶层字段） | 三源兜底: authUser?.userId → body.userId → user?.id | 🆕 运行时发现，已修复 |
| src/agents/stream-bus.ts | COMPONENT | COMPONENT_MODIFIED | controller 关闭后仍推送事件 → STREAM_BUS_EMIT_ERROR | registerStreamBus 回调加 try-catch 守卫 + streamClosed 标志 | 🆕 运行时发现，已修复 |

---

## 一、背景与目标

### 1.1 问题现状

父 Plan `farm-agent-deep-kb-dualpath-retrieval-plan-v1` 实现了 isSummary 专家的快捷路由：`intention → reasoning`（跳过 retrieval），设计意图是 isSummary 专家以工具实时数据为证据源，不需要 RAG 检索。

但 Runtime Review 发现三处断裂：

| # | 问题 | 现象 | 所在文件 |
|---|------|------|---------|
| F1 | explicitIntent 提前 return 使强制 tool_calls 注入成为死代码 | Dashboard 点击 weekly_report → 无工具调用 → 无实时数据 | intention.ts L78 vs L158 |
| F2 | isSummary 跳过 retrieval 后 evidenceChain 无替代填充来源 | response 节点拿到空 evidenceChain → 前端不渲染证据链 | reasoning.ts |
| F3 | expertPackages 不自行构建，isSummary 专用 prompt 路径不可达 | reasoning 始终走旧路径（扁平 evidenceList），工具结果仅补充在末尾 | reasoning.ts |
| F4 | hasToolResult 检查全量历史消息，跨轮次污染 | 先点 pest_risk 再点 weekly_report → 读到上轮 ToolMessages → 跳过注入 | intention.ts L161 |

> F4 为 Runtime Review 追加审查时发现的边界 bug。

### 1.2 目标

1. 修复 intention.ts 的工具调用生成逻辑：isSummary 专家在所有入口路径下均产出 tool_calls
2. 修复 reasoning.ts：工具结果回写 evidenceChain，使 response 节点可渲染证据链
3. 修复 reasoning.ts：expertPackages 自构建，使 isSummary 专用 prompt 模板生效
4. 修复跨轮次 ToolMessages 污染：hasToolResult 收窄到本轮
5. 扩展 EvidenceSource 类型，编译通过

---

## 二、方案选型

### 2.1 候选方案对比

| 维度 | A: 在 reasoning 节点补全一切 | B: 修复 intention + reasoning 协同（选用） |
|------|------|------|
| F1 修复 | ❌ reasoning 无法生成 tool_calls（不在同一条路径上） | ✅ intention 节点是唯一可生成 tool_calls 的位置 |
| F2 修复 | ✅ 可在 reasoning 回写 evidenceChain | ✅ 同 |
| F3 修复 | ✅ 可在 reasoning 内聚构建 | ✅ 同 |
| 改动范围 | 仅 reasoning.ts | intention.ts + reasoning.ts + types/evidence.ts |
| 职责清晰度 | reasoning 承担工具调用生成？职责错位 | ✅ intention 管工具生成，reasoning 管证据填充 |

### 2.2 选型理由

**选用方案 B**。intention 节点是 LangGraph 中唯一可以产出 `tool_calls` 的节点——管道设计决定了工具调用必须在 intention 阶段生成。reasoning 节点无法替代这个职责。方案 A 试图把工具生成挪到 reasoning 是架构错位。

---

## 三、架构设计

### 3.1 修复后的图路由

```
Dashboard 点击 weekly_report
  explicitIntent="report_analysis" + explicitExpertId="weekly_report"
        │
        ▼
  intention 节点（修复后）
        │
        ├─ L158 前移: explicitExpertId + realtimeToolNames → 强制注入 tool_calls
        │     hasToolResult 判定范围: 本轮（最后 user message 之后）
        │
        ├─ 第 1 轮: return tool_calls → toolNode 执行 → 回路
        │
        ├─ 第 2 轮: hasToolResult=true → 跳过注入
        │     → L78 explicitIntent → return（意图已确定，不再调 LLM）
        │
        ▼
  conditional: isSummary → reasoning
        │
        ├─ toolMessages 可用（第1轮产物）
        ├─ evidenceChain 为空（跳过 retrieval）
        │
        ▼
  reasoning 节点（修复后）
        │
        ├─ F3: expertPackages undefined → 自构建 [weekly_report 包]
        │     含 toolResults + isSummary flag
        │
        ├─ F2: evidenceSource.isSummary && toolMessages > 0
        │     → 工具结果摘要追加到 evidenceChain
        │
        ├─ 走新路径: build() 使用 isSummary prompt 模板
        │     → 工具数据前置（一等证据位）
        │     → LLM 基于实时数据推理
        │
        ▼
  interactionPoint → verdict → response
        │
        ├─ evidenceChain 非空 → 证据链 section 渲染
        ├─ reasoningPath 非空 → 推理链 section 渲染
        └─ confidence > 0 → 置信度展示
```

### 3.2 多轮调用状态机

```
第 1 轮（每次新的 user message）:
  hasToolResult(本轮) = false  →  强制注入 tool_calls  →  toolNode 执行  →  回路

第 2 轮（toolNode 回路返回）:
  hasToolResult(本轮) = true   →  跳过注入
  explicitIntent 存在          →  return（不走 LLM，意图已由 GUI 确定）
  explicitIntent 不存在         →  fall-through 走 LLM 路径解析意图
```

### 3.3 hasToolResult 收窄方案

```
改前:
  const hasToolResult = state.messages.some(m => m instanceof ToolMessage)
  检查全量历史 → 跨轮次污染

改后:
  找到最后一条 user message 的索引 lastUserIdx
  const hasToolResult = state.messages.slice(lastUserIdx + 1).some(
    m => m instanceof ToolMessage || m.role === "tool"
  )
  仅检查本轮消息 → 每轮独立判定
```

### 3.4 EvidenceSource 类型扩展

```typescript
// types/evidence.ts
export type EvidenceSource =
  | "document" | "knowledge" | "knowledge_empty" | "project_context"
  | "keywords" | "multimodal" | "task" | "economic" | "history"
  | "team_input" | "sensor" | "expert"
  | "tool_result"  // 🆕
```

---

## 四、实施步骤 + 依赖图

```
Task 1 (intention.ts) ──┐
                          │ 可并行
Task 2 (types/evidence) ─┘
                          │
                          ▼
Task 3 (reasoning.ts) ──── 依赖 Task 2（类型扩展先就位）
                          │
                          ▼
Task 4 (caijue.toml) ──── 依赖 Task 1 + Task 3（裁决条目指向完成后状态）
                          │
                          ▼
Task 5 (编译验证)
```

### Task 1: intention.ts 修复（F1 + F4）

**文件**: `src/agents/nodes/intention.ts`

| # | 改动 | 说明 |
|---|------|------|
| 1a | 将 L158-186 强制注入逻辑移到 L78 之前 | 确保 explicitExpertId 声明了 realtimeToolNames 时，在 explicitIntent 提前 return 之前执行强制注入 |
| 1b | hasToolResult 收窄到本轮 | 找到最后一条 user message 索引 → slice(lastUserIdx+1) → 检查 ToolMessages |
| 1c | 编译验证 | `npx tsc --noEmit` |

**验收**: Dashboard 点击 weekly_report → 审计日志可见 3 次 tool_call；先点 pest_risk 再点 weekly_report → 第 2 轮工具正常调用。

### Task 2: EvidenceSource 类型扩展（F2 前置）

**文件**: `src/types/evidence.ts`

| # | 改动 | 说明 |
|---|------|------|
| 2a | EvidenceSource 联合新增 `"tool_result"` | 使 F2 的 toolEvidences.source 合法 |
| 2b | 编译验证 | `npx tsc --noEmit` |

### Task 3: reasoning.ts 修复（F2 + F3）

**文件**: `src/agents/nodes/reasoning.ts`

| # | 改动 | 说明 |
|---|------|------|
| 3a | F2: 工具结果回写 evidenceChain | `evidenceSource.isSummary && toolMessages.length > 0` → 构建 toolEvidences[] → return `{ evidenceChain: [...(evidenceChain||[]), ...toolEvidences], verdictResult }` |
| 3b | F3: expertPackages 自构建 | `!expertPackages && evidenceSource.isSummary` → 自行构建最小 expertPackages（expertId + toolResults + isSummary flag） |
| 3c | 编译验证 | `npx tsc --noEmit` |

**验收**: SSE stream 中 structured_output 事件包含非空 evidenceChain.evidences（至少 tool_result 条目）+ 非空 reasoningPath.steps。

### Task 4: caijue.toml 更新

**文件**: `src/caijuehub/caijue.toml`

| # | 改动 | 说明 |
|---|------|------|
| 4a | `resolve-evidence-source` 条目 governance 新增 Runtime Review F1/F2/F3 引用 | 约束：isSummary 专家需确保 intention 产出 tool_calls；工具结果需回写 evidenceChain |

### Task 5: 全链路编译验证

| # | 验证项 |
|---|--------|
| 5a | `npx tsc --noEmit` 零错误 |
| 5b | weekly_report Dashboard 点击 → 工具调用 → 证据链非空 → 推理链非空 |
| 5c | daily_report Dashboard 点击 → 同上验证 |
| 5d | 跨轮次：先 pest_risk 再 weekly_report → weekly_report 工具正常调用 |
| 5e | 非 isSummary 专家零回归（pest_risk / weather_impact 等行为不变） |

---

## 五、验收标准

- [ ] Dashboard 点击"周报分析"→ 审计日志可见 `query_farm_weather`/`query_soil_moisture`/`query_insect_data` 三次 tool_call
- [ ] SSE stream `structured_output` 事件包含非空 `evidenceChain.evidences`（含 tool_result 来源条目）
- [ ] SSE stream `structured_output` 事件包含非空 `reasoningPath.steps`
- [ ] `verdict.confidence.finalConfidence > 0`
- [ ] 前端最终态面板展示证据链 section + 推理链 section
- [ ] `daily_report`（另一个 isSummary 专家）同样验证通过
- [ ] 跨轮次：先点 pest_risk 再点 weekly_report → weekly_report 工具正常调用（hasToolResult 不受污染）
- [ ] 连续多轮：同一 thread 两次点击 weekly_report → 第 2 轮重新调工具（拿最新数据）
- [ ] 非 isSummary 专家（如 pest_risk）行为不受影响（零回归）
- [ ] `EvidenceSource` 类型联合包含 `"tool_result"`
- [ ] `caijue.toml` resolve-evidence-source  governance 已更新
- [ ] `npx tsc --noEmit` 零错误

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| 父 Plan | `.qoder/plans/farm-agent-deep-kb-dualpath-retrieval-plan-v1.md` | ✅ 已生成，§Task 6.5 指向本 Plan |
| Runtime Review | `.qoder/reviews/farm-agent-deep-kb-dualpath-retrieval-review-runtime-v1.md` | ✅ 已生成，F1-F4 共 4 条 |
| 父 Plan Review | `.qoder/reviews/farm-agent-deep-kb-dualpath-retrieval-review-v1.md` | ✅ 已生成 |
| 历史 Review | `.qoder/reviews/farm-agent-tool-calls-blocked-runtime-review-v1.md` | ✅ 已生成，F3 同类问题 |
| ADD Route | `.qoder/plans/farm-agent-isSummary-toolcall-fix-add-route-v1.md` | 待生成 |
| Handoff | `.qoder/plans/farm-agent-isSummary-toolcall-fix-handoff-v1.md` | 待生成 |
| Spec | `.qoder/specs/farm-agent-isSummary-toolcall-fix/spec.md` | 待生成 |
| Tasks | `.qoder/specs/farm-agent-isSummary-toolcall-fix/tasks.md` | 待生成 |
| Checklist | `.qoder/specs/farm-agent-isSummary-toolcall-fix/checklist.md` | 待生成 |
