# farm-agent — 数据库备份与开发安全加固 交接手册

> **适用场景**：运维接手备份策略调整、新增环境部署备份、排查备份失败问题、理解 dev 启动安全机制。

---

## 1. 交接前状态

- 无数据库定时备份机制，数据恢复依赖手动 pg_dump
- crontab 通过 SSH 手动 `echo '...' | crontab -` 管理，无 Git 追踪
- `npm run dev` 启动无环境安全检查，可能误连生产数据库
- `BACKUP_DIR` 未定义，备份路径混入 `DATA_DIR`（容器数据卷），有共损风险
- `package.json` dev 脚本链仅 `predev → db:ensure → farm-service-login → next dev`
- `.gitlab-ci.yml` deploy 阶段无 crontab 安装步骤
- `.env.production` / `.env.development` 无 `BACKUP_DIR` 变量

---

## 2. 交接后状态（目标）

- PostgreSQL 每日凌晨 2:00 自动全库备份，保留 7 天滚动清理
- crontab 定义文件化（`scripts/crontab.txt`），Git 追踪，CI 自动安装
- `npm run dev` 启动前 5 道安全网：runtime-review → env-check → cron-check → db:ensure → login
- `BACKUP_DIR` 与 `DATA_DIR` 物理隔离，降低容器数据卷故障时备份共损风险
- 备份脚本修复两个 bug：`--if-exists` 数据丢失 + 管道输出截断
- 架构文档 `《数据库定时备份与crontab管理架构》.md` 与主架构说明书双向联动

---

## 3. 改动清单

### 新建文件

| # | 文件 | 说明 |
|---|------|------|
| 1 | `scripts/db-backup.sh` | PostgreSQL 定时备份脚本（pg_dump → 临时文件中转 → gzip） |
| 2 | `scripts/crontab.txt` | Git 追踪的 crontab 定义（单条：db-backup.sh @ 2:00 AM） |
| 3 | `scripts/check-dev-env.ts` | npm run dev 环境安全预检（NODE_ENV / DATABASE_URL / FARM_SERVER_BASE_URL） |
| 4 | `scripts/ensure-cron.sh` | 本地 crontab 幂等安装（dev 启动时自动触发） |
| 5 | `docs/.../01-架构/《数据库定时备份与crontab管理架构》.md` | 备份架构完整文档 |

### 修改文件

| # | 文件 | 变更内容 |
|---|------|---------|
| 6 | `.env.production` | 新增 `BACKUP_DIR="/home/ai/data/farm-agent-backups"` |
| 7 | `.env.development` | 新增 `BACKUP_DIR="/home/xmm/data/farm-agent-backups"` |
| 8 | `package.json` | dev 脚本新增 `check-dev-env.ts` + `ensure-cron.sh` 两道安全网 |
| 9 | `.gitlab-ci.yml` | deploy 阶段新增 `crontab $DEPLOY_DIR/scripts/crontab.txt` |
| 10 | `docs/.../01-架构/《技术架构说明书》.md` | 数据存储层新增备份架构交叉引用 |

### bug 修复（无文件新增，脚本内修复）

| bug | 原因 | 修复 |
|-----|------|------|
| `--if-exists` 导致仅导出 2 张表 | pg_dump 16.x 管道模式下 `--if-exists` 输出截断 | 移除 `--if-exists` |
| 管道输出截断（36K 残缺备份） | `podman exec | gzip` 大量数据时截断 | 改为临时文件中转：`pg_dump → .sql → gzip` |

---

## 4. 恢复上下文审计查询（新 AI Session 首次启动必读）

### 总体一键恢复

```text
query_audit_logs({ keyword: "db-backup" })
```
→ 预期返回 4+ 条记录（脚本创建 + 备份目录改造 + 文档）

```text
query_audit_logs({ keyword: "dev-env" })
```
→ 预期返回 4+ 条记录（环境安全预检 + 本地cron安装 + dev脚本改造）

### 逐文件审计查询

```text
query_audit_logs({ targetId: "scripts/db-backup.sh" })
→ 预期返回 CREATE: PostgreSQL 每日定时备份脚本

query_audit_logs({ targetId: "scripts/crontab.txt" })
→ 预期返回 CREATE: Git 追踪的 crontab 定义文件

query_audit_logs({ targetId: "scripts/check-dev-env.ts" })
→ 预期返回 CREATE: npm run dev 环境安全预检

query_audit_logs({ targetId: "scripts/ensure-cron.sh" })
→ 预期返回 CREATE: 本地 crontab 幂等安装

query_audit_logs({ targetId: ".env.production" })
→ 预期返回 MODIFY: 新增 BACKUP_DIR 环境变量

query_audit_logs({ targetId: ".env.development" })
→ 预期返回 MODIFY: 新增 BACKUP_DIR 环境变量

query_audit_logs({ targetId: ".gitlab-ci.yml" })
→ 预期返回 MODIFY: deploy 阶段新增 crontab 安装

query_audit_logs({ targetId: "package.json" })
→ 预期返回 MODIFY: dev 脚本新增安全和 cron 检查

query_audit_logs({ keyword: "数据库定时备份与crontab管理架构" })
→ 预期返回 DOC_CREATED: 备份架构文档
```

### 恢复判定标准

- audit 命中数 ≥ 10
- grep 验证命令：

```bash
grep -R "db-backup\|crontab.txt\|check-dev-env\|ensure-cron\|BACKUP_DIR" \
  scripts/ .env.production .env.development .gitlab-ci.yml package.json | wc -l
# 预期 ≥ 15
```

---

## 5. 关键配置速查

### 环境变量

| 变量 | rfai (production) | 本地 (development) |
|------|-------------------|-------------------|
| `BACKUP_DIR` | `/home/ai/data/farm-agent-backups` | `/home/xmm/data/farm-agent-backups` |
| `DATA_DIR` | `/home/ai/data/farm-agent` | `/home/xmm/data/farm-agent` |

### crontab

```
0 2 * * * /bin/bash $HOME/farm-agent/scripts/db-backup.sh >> $HOME/data/farm-agent-backups/cron.log 2>&1
```

- `$HOME` 由 cron 守护进程自动展开（rfai=`/home/ai`，本地=`/home/xmm`）
- 安装时机：CI deploy 阶段 + `npm run dev` 启动时

### npm run dev 启动链

```
predev (runtime-review)
  → check-dev-env.ts (环境安全检查，阻断式)
    → ensure-cron.sh (crontab幂等安装，非阻断)
      → db:ensure (PG+ChromaDB+迁移)
        → farm-service-login
          → next dev
```

### 恢复备份

```bash
gunzip -c $HOME/data/farm-agent-backups/farm-agent-YYYYMMDD_HHMMSS.sql.gz | \
  podman exec -i farm-agent-postgres psql -U farm_admin -d farm_agent
```

---

## 6. 后置确认

- [ ] rfai 上 crontab 已安装：`ssh rfai crontab -l | grep db-backup`
- [ ] 本地 crontab 已安装：`crontab -l | grep db-backup`
- [ ] rfai 备份目录有文件：`ssh rfai ls -lh /home/ai/data/farm-agent-backups/`
- [ ] `npm run dev` 启动时输出 `[DEV-CHECK] ✅` 和 `[CRON-CHECK] ✅`
- [ ] `DATABASE_URL=postgresql://...@114.115.216.200/... npm run dev` 被阻断
- [ ] CI deploy 阶段日志含 `crontab ✓`
- [ ] 备份文件 gunzip 后含完整 24 张表 COPY 数据

---

### 脱敏要求

本文档禁止出现硬编码密码、API Key、JWT 密钥。所有凭据通过 `${ENV_VAR}` 引用。
