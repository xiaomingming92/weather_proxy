# farm-agent-code-review-fixes-plan-v1

> 来源：`code-review-combined-report.md`（2026-06-29 生成）
> 范围：P0 安全风险 2 项 + P1 健壮性 2 项 + P2 代码重复 2 项，共 6 项

## PLAN 元信息

- **Plan 名称**: code-review-fixes-v1
- **启动时间**: 2026-06-29T14:00:00+08:00
- **主导 AI**: Qoder (farm-agent)
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/29/code-review-fixes-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-06/29/code-review-fixes-handoff-v1.md`
  - Spec: `.qoder/specs/code-review-fixes/spec.md`
  - Tasks: `.qoder/specs/code-review-fixes/tasks.md`
  - Checklist: `.qoder/specs/code-review-fixes/checklist.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|------|-----------|--------|-------------|-----------|------|
| src/lib/auth.ts | COMPONENT | COMPONENT_MODIFIED | JWT_SECRET 硬编码默认值 "dev-secret-key" | 生产环境缺失 JWT_SECRET 时拒绝启动 | 待实施 |
| src/lib/farm-server-client.ts | COMPONENT | COMPONENT_MODIFIED | createQWeatherJwt() 返回占位签名 | 生产环境返回有效 EdDSA 签名或启动时强校验 | 待实施 |
| src/lib/llm.ts | COMPONENT | COMPONENT_DELETED | 旧 LLM 模块（死代码） | 删除，h5Llm 迁移至 llm/index.ts | 待实施 |
| src/lib/llm/index.ts | COMPONENT | COMPONENT_MODIFIED | 不含 h5Llm 导出 | 补充 h5Llm 导出 | 待实施 |
| src/caijuehub/strategies/auth-gateway.ts | COMPONENT | COMPONENT_MODIFIED | 本地重复定义 extractTokenFromRequest | 从 auth.ts 导入 | 待实施 |
| src/agents/index.ts | COMPONENT | COMPONENT_MODIFIED | activeTracers 无 TTL 过期机制 | 增加 30 分钟 TTL 自动清理 | 待实施 |
| src/lib/agent-audit-logger.ts | COMPONENT | COMPONENT_MODIFIED | writeAuditLog 失败仅 console.error | 增加失败计数器 + 周期性 metric 输出 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

`code-review-combined-report.md` 识别出 24 个问题，按优先级选取 P0/P1/P2 共 6 项执行首批修复：

| # | 严重度 | 问题 | 影响 |
|---|--------|------|------|
| 1 | P0 | JWT 硬编码默认密钥 | 生产环境漏配环境变量时使用可预测弱密钥，可被伪造 token |
| 2 | P0 | QWeather JWT 签名占位符 | 生产环境 QWeather API 认证必然失败 |
| 3 | P2 | LLM 模块重复（llm.ts vs llm/index.ts） | 旧文件成死代码，h5Llm 仍依赖旧文件 |
| 5 | P2 | extractTokenFromRequest 重复定义 | 同一函数两处定义，维护负担 |
| 11 | P1 | activeTracers Map 内存泄漏 | 流式请求异常中断时 tracer 永不释放 |
| 12 | P1 | 审计日志静默吞错 | DB 不可用时审计记录静默丢失，无告警 |

### 1.2 目标

将上述 6 个问题从"仍存在"状态修复为"已修复"。

---

## 二、方案选型

无多方案对比——每个问题已有明确的修复建议。

---

## 三、架构设计

无架构变更——所有修复均为局部代码安全加固/健壮性增强/代码去重，不改变系统外部合约。

---

## 四、实施步骤 + 依赖图

```
#1 (auth.ts)        #2 (farm-server-client)   #3 (llm.ts + llm/index.ts)
    │                       │                        │
    └───────────────────────┼────────────────────────┘ (可并行，独立文件)
                            │
    #5 (auth-gateway.ts)    #11 (agents/index.ts)    #12 (agent-audit-logger.ts)
                            │
                            ▼
                      tsc --noEmit + lint
```

### Task 1: #1 JWT 弱密钥修复
- 文件: `src/lib/auth.ts`
- 改动: 环境变量检查前移到模块顶层，生产环境缺 JWT_SECRET 时 throw Error

### Task 2: #2 QWeather JWT 签名修复
- 文件: `src/lib/farm-server-client.ts`
- 改动: 增加生产环境签名校验，占位签名时记录审计 + 抛出明确错误

### Task 3: #3 LLM 模块统一
- 文件: `src/lib/llm.ts`（删除）、`src/lib/llm/index.ts`（补充 h5Llm）
- 改动: 将 h5Llm 相关逻辑迁移到 index.ts，删除旧 llm.ts，更新 3 个 h5 route 引用

### Task 4: #5 extractTokenFromRequest 去重
- 文件: `src/caijuehub/strategies/auth-gateway.ts`
- 改动: 删除本地 extractTokenFromRequest，从 auth.ts 导入

### Task 5: #11 activeTracers TTL 机制
- 文件: `src/agents/index.ts`
- 改动: 增加 30 分钟 TTL 过期 + 定期清理逻辑

### Task 6: #12 审计日志失败计数器
- 文件: `src/lib/agent-audit-logger.ts`
- 改动: writeAuditLog 增加失败计数器，每 100 次失败输出 metric

---

## 五、验收标准

- [ ] `npx tsc --noEmit` 通过
- [ ] 旧 llm.ts 已删除，所有引用指向 llm/index.ts
- [ ] auth-gateway.ts 不再重复定义 extractTokenFromRequest
- [ ] JWT_SECRET 生产环境缺失时启动失败
- [ ] activeTracers 有 30 分钟 TTL 过期机制
- [ ] 审计日志失败有计数器

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/29/code-review-fixes-add-route-v1.md` |
| Handoff | `.qoder/plans/2026-06/29/code-review-fixes-handoff-v1.md` |
| Spec | `.qoder/specs/code-review-fixes/spec.md` |
| Tasks | `.qoder/specs/code-review-fixes/tasks.md` |
| Checklist | `.qoder/specs/code-review-fixes/checklist.md` |
| 源 Review | `code-review-combined-report.md` |
