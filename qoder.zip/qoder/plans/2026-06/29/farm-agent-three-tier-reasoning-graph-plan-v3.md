# farm-agent-aca-framework-plan-v3

> **ACA 框架** = **A**rgumentation（论证框架）+ **C**onstraint Propagation（约束传播）+ **A**djudication（人工裁决）。
>
> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。**不要**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-aca-framework-v3
- **推理范式**: ACA（Argumentation + Constraint + Adjudication）
- **启动时间**: 2026-06-29T12:00:00+08:00
- **主导 AI**: Qoder
- **前身 Plan**:
  - [v1](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/17/farm-agent-three-tier-reasoning-graph-plan-v1.md)（2026-06-17 初版，Phase 1 完成）
  - [v2](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-plan-v2.md)（2026-06-25 修订，Phase 0 完成，轮次 1-4 未启动）
- **原子闭包判定**：本 Plan 整体为 **1 个原子闭包**（业务功能：用户发起多专家联合分析 → professional 图端到端可用）。内部拆分为 **4 轮局部闭包**，每轮职责明确、可独立验证、可独立 handoff 交接
- **v3 变更摘要**:
  1. **代码基线刷新**：v2 发布后 4 天（06/25→06/29）期间发生 2 个介入变更——`h5-agent-route-code-quality`（StreamState 替代 interrupted 布尔）和 `checkpointer-postgres-migration`（MemorySaver→PostgresSaver），确认无架构调整需求
  2. **保留 v2 4 轮结构**：沿用 v2 的生产者/消费者分离设计——轮次 1（类型基石）→ 轮次 2（State+ExpertClaim 生产者）→ 轮次 3（ExpertClaim 消费者，3a/3b 两个子组）→ 轮次 4（图组装+集成）。v3 不改变轮次数量和边界
  3. **补充轮次元信息**：每轮新增「职责边界 + Handoff 交接面」标注
  4. **新增原子闭包判定**：§5.0 执行 ADD Step 0.7 三可性判定
  5. **风险登记**：新增 §七 风险矩阵
  6. **v2 架构保留**：ACA 三阶段、ExpertClaim/ConflictReport 类型体系、冲突检测四类场景、约束松弛三级策略
- **关联文档**:
  - V1 Plan: `.qoder/plans/2026-06/17/farm-agent-three-tier-reasoning-graph-plan-v1.md`
  - V2 Plan: `.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-plan-v2.md`
  - V2 Handoff: `.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-handoff-v2.md`
  - ADD Route: `.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-add-route-v3.md`（待生成）
  - Handoff: `.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-handoff-v3.md`（待生成）
  - Spec: `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md`（待生成）
  - Tasks: `.qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md`（待生成）
  - Checklist: `.qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md`（待生成）
- **ADD-7 审计策略**（v3 刷新——基于实际代码基线，标记已完成项）:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/agents/edges/conditional.ts | COMPONENT | COMPONENT_MODIFIED | routeByIntent 仅 fast/deep 两路 | 新增 isSummary 跳过 retrieval（Phase 1 ✅） | ✅ 已完成 |
| src/agents/nodes/reasoning.ts | COMPONENT | COMPONENT_MODIFIED | isSummary 推理断裂 + "RAG 0条" 误报 | isSummary 识别 + 工具数据一等公民 | ✅ 已完成 |
| src/agents/prompts/experts/factory.ts | COMPONENT | COMPONENT_MODIFIED | 证据区块无条件优先 | isSummary 时工具数据区块前置 | ✅ 已完成 |
| src/agents/prompts/experts/weekly-report.ts | COMPONENT | COMPONENT_MODIFIED | prompt 歧义 | "基于实时监测数据" | ✅ 已完成 |
| src/agents/prompts/experts/daily-report.ts | COMPONENT | COMPONENT_MODIFIED | 同上 | 同上 | ✅ 已完成 |
| src/app/api/h5/agent/route.ts | API_ROUTE | API_MODIFIED | 无 __interrupt__ 检测 | event: interrupt SSE + StreamState 状态机 | ✅ 已完成 |
| src/app/api/h5/agent/[threadId]/resume/route.ts | API_ROUTE | API_CREATED | 不存在 | H5 resume 端点 | ✅ 已完成 |
| src/agents/sse-stream-state.ts | COMPONENT | COMPONENT_CREATED | 不存在（v2 未预料） | StreamState 枚举 + transition() + emitTerminalEvent() | ✅ 已完成（介入变更） |
| src/types/evidence.ts | TYPE | TYPE_MODIFIED | ThinkingLevel = "fast" \| "deep" | ThinkingLevel = "fast" \| "deep" \| "professional" | 待实施 |
| src/agents/prompts/types.ts | TYPE | TYPE_MODIFIED | 无 ExpertClaim / ConflictReport 等类型 | 新增 ExpertClaim / ConflictReport / CoordinationResult / AggregatedReport | 待实施 |
| src/agents/state.ts | COMPONENT | COMPONENT_MODIFIED | 单 massifId 标量 | 新增 massifIds / expertClaims / conflictReports / coordinationResult / aggregatedReport | 待实施 |
| src/agents/nodes/structured-output.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 专家自由文本 → ExpertClaim 结构体转换 | 待实施 |
| src/agents/nodes/conflict-resolver.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 确定性冲突检测（4 类） | 待实施 |
| src/agents/nodes/kb-conflict-aggregator.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 集中式 KB 双源冲突检测 + interrupt（fan-in 后串行节点） | v3 新增 |
| src/agents/nodes/coordination-dialogue.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 定向提问 + 约束松弛求解 | 待实施 |
| src/agents/nodes/aggregation.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 多专家结论格式聚合 | 待实施 |
| src/agents/nodes/intention.ts | COMPONENT | COMPONENT_MODIFIED | 不产出 expertPlan | professional 场景产出 expertPlan（Expert[] + per-expert subIntent） | 待实施 |
| src/agents/index.ts | COMPONENT | COMPONENT_MODIFIED | 单一 workflow | 拆为 fastGraph/deepGraph/professionalGraph + 入口路由 | 待实施 |

---

## 一、背景与目标

> 本节核心内容与 v1/v2 一致。v3 更新：确认 Phase 0 + Phase 1 已交付，当前代码基线支持进入核心实施。

### 1.1 问题现状（维持不变）

| 瓶颈 | 现象 | 根因 | 状态 |
|------|------|------|:--:|
| **汇总专家推理断裂** | weekly_report/daily_report 推理链路断裂 | retrieval 空返回 + reasoning 不区分证据源 | ✅ Phase 1 已修复 |
| **多专家协作缺失** | 多专家场景无互相审查、无冲突检测、无协调机制 | 单管线设计 | ❌ 待修复 |
| **单地块架构限制** | AgentState.massifId 为标量 | 状态模型未设计多地块 | ❌ 待修复 |

### 1.2 目标（维持不变）

1. **汇总专家在 deep 图正常工作** ✅ Phase 1 已完成
2. **新增 ACA Graph（professional 图）**：采用 Argumentation + Constraint + Adjudication 范式
3. **thinkingLevel 扩展为 3 级**：`fast` / `deep` / `professional`
4. **deep 图不动**：单专家推理现有能力不受影响

---

## 二、方案选型

> 维持 v2 选型结论：**方案 B（独立子图 + 入口路由）**。理由同 v2 §二。
> v3 补充：`checkpointer-postgres-migration` 已完成，PostgresSaver 替代 MemorySaver 后 LangGraph interrupt() 状态持久化可靠性提升，对 professional 图交互裁决为正向收益。

---

## 三、架构设计

> 维持 v2 §三 全部架构设计。v3 不做架构变更，仅更新代码基线引用。

### 3.1 三图总览（同 v2）

```
                    ┌──────────────────┐
                    │   __start__       │
                    │   input: {query,  │
                    │     explicitIntent,│
                    │     thinkingLevel?,│
                    │     massifIds[] }  │
                    └────────┬─────────┘
                             │
                             ▼
                    ┌────────────────────┐
                    │    intention        │
                    │    (三段路由判定)    │
                    │thinkingLevel:       │
                    │ fast/deep/prof.     │
                    └────────┬───────────┘
                             │
              ┌──────────────┼──────────────┐
              │ fast         │ deep         │ professional
              ▼              ▼              ▼
        ┌──────────┐  ┌──────────┐  ┌──────────────────┐
        │fastGraph │  │deepGraph │  │ACA Graph (新图) │
        │(不动)    │  │(微调✅)   │  │professional 图    │
        │          │  │          │  │采用 ACA 范式     │
        └──────────┘  └──────────┘  └──────────────────┘
```

### 3.2 deepGraph 现状（✅ 已交付，不需额外工作）

当前 `src/agents/index.ts` 的单一 workflow 编译即为 deepGraph。Phase 1 的 isSummary 路由已嵌入 `routeByIntent()`。
**v3 轮次 3 将把当前 workflow 提取为 `deepGraph`，保持拓扑不变。**

### 3.3 ACA Graph 拓扑（同 v2）

```
intention (产出 expertPlan: Expert[])
    │
    │ thinkingLevel === "professional"
    ▼
┌───────────────────────────────────────┐
│  fan-out (LangGraph Send API)         │
│  per-expert 并行（零 interrupt）:      │
│    retrieval → reasoning →            │
│    structuredOutput → ExpertClaim     │
│    ★ KB 冲突不 interrupt，写入         │
│      ExpertClaim.metadata.kbDisagreement│
└───────────────────────────────────────┘
    │
    ▼ fan-in: ExpertClaim[]
┌───────────────────────────────────────┐
│  kbConflictAggregator（串行，集中式）   │
│  ★ 遍历 ExpertClaim 收集 KB 冲突标记   │
│  ★ 有冲突 → 单次 interrupt()          │
│  ★ 无冲突 → 透传                      │
└───────────────────────────────────────┘
    │
    ▼
┌───────────────────────────────────────┐
│  conflictResolver (确定性，零 LLM)     │
│  四类检测: 前提互斥/资源冲突/          │
│           时序矛盾/执行标准不一致       │
│  → ConflictReport[]                   │
└───────────────────────────────────────┘
    │
    ├── 无冲突/全软冲突 → aggregation
    │
    └── 含硬冲突 → coordinationDialogue (LLM 定向提问)
                      │
                      ├── 冲突可解 → aggregation
                      └── 冲突不可解 → interactionPoint (interrupt())
                                          │
                                          └── 用户裁决 → aggregation
                                                          │
                                                          ▼
                                                    verdict → response → __end__
```

### 3.4 新数据结构（同 v2，不再重复全文——完整定义见 Spec）

- **ExpertClaim**: expertId / claim / reasoningPath / confidence / preconditions / hardConstraints / softConstraints / recommendedActions（含 `method?: string`）/ risksIfIgnored
- **ConflictReport**: type（4 种）/ involvedExperts / description / severity（HARD\|SOFT）/ suggestedResolution
- **CoordinationResult**: resolved / revisedClaims / residualConflicts
- **AggregatedReport**: 合并 claims + conflicts + recommendations summary

### 3.5 State 扩展（同 v2）

```
AgentState 新增字段:
  massifIds: number[]       ← 多地块支持（标量 massifId 保留向后兼容）
  expertPlan: Expert[]      ← professional 图专家执行计划
  expertClaims: ExpertClaim[]   ← per-expert 结构化结论
  conflictReports: ConflictReport[]  ← 冲突检测结果
  coordinationResult: CoordinationResult | null
  aggregatedReport: AggregatedReport | null
```

**massifId/massifIds 双模语义**（v2 明确，v3 沿用）：

| 图 | 使用字段 | 语义 |
|----|---------|------|
| fastGraph | 不使用 | - |
| deepGraph | `massifId`（标量） | 单地块分析 |
| professionalGraph | `massifIds[]`（数组） | 多地块并行分析 |

互斥规则：professional 图设置 `massifIds` 时 `massifId` 必须为 null/undefined。

---

## 四、v3 代码基线刷新

> **v3 独有章节**——评估 v2（06/25）到 v3（06/29）期间介入变更对本 Plan 的影响。

### 4.1 介入变更清单

| 日期 | 变更 Plan | 影响文件 | 对本 Plan 的影响 | 风险等级 |
|------|----------|---------|----------------|:--:|
| 06/26 | `h5-agent-route-code-quality` | `sse-stream-state.ts`（新建）、`h5/agent/route.ts`、`h5/agent/.../resume/route.ts`、`api/agent/chat/stream/route.ts`、`api/agent/resume/route.ts`、`api/agent/[hash]/route.ts` | Phase 0 交付物被重构——interrupted 布尔 → StreamState 枚举，console.* → agentAudit。Professional 图的 interactionPoint `interrupt()` 恢复链路已对齐新状态机 | 🟡 低 |
| 06/26 | `checkpointer-postgres-migration` | checkpointer 从 MemorySaver → PostgresSaver | interrupt() 状态持久化可靠性提升，对 professional 图交互裁决为正向收益。需验证 PostgresSaver 对 `Command({ resume })` 的兼容性 | 🟢 极低 |

### 4.2 基线兼容性确认

| 检查项 | v2 假设 | v3 实际 | 兼容？ |
|--------|--------|--------|:--:|
| H5 路由 `__interrupt__` 检测 | for-await 循环新增 13 行检测 | ✅ 已实现 + StreamState 状态机替代 interrupted 布尔 | ✅ |
| H5 resume 端点 | 133 行新文件 | ✅ 已实现 + agentAudit 替代 console | ✅ |
| Checkpointer 类型 | MemorySaver | PostgresSaver（功能超集） | ✅ |
| LangGraph 版本 | v1.3.2 | v1.3.2（未变） | ✅ |
| `interrupt()` / `Command(resume)` API | 标准 LangGraph API | 未变 | ✅ |

### 4.3 结论

**v3 无需因介入变更调整架构设计**。Phase 0 交付物虽被 `h5-agent-route-code-quality` 重构，但功能语义等价且更健壮（枚举穷举 + 审计一致）。PostgresSaver 迁移对 interrupt/resume 链路为正向收益。

---

## 五、v3 实施路线

### 5.0 原子闭包三可性判定

> **ADD Step 0.7 强制卡位**——在进入实施前，判定本 Plan 的原子闭包边界和轮次拆分方案。

```
原子闭包三可性判定
══════════════════

业务功能: 用户发起多专家联合分析请求 → professional 图 fan-out 并行推理
         → ExpertClaim 结构化论证 → conflictResolver 冲突检测
         → coordinationDialogue 协调 / interactionPoint 人工裁决
         → aggregation 聚合 → verdict → response 返回

Task Groups:
  Group 1: 类型定义 (types/evidence.ts, prompts/types.ts)
  Group 2: State 桥接 + ExpertClaim 生产者 (agents/state.ts, nodes/structured-output.ts)
  Group 3a: ExpertClaim 消费者—确定性 (nodes/conflict-resolver.ts, nodes/aggregation.ts)
  Group 3b: ExpertClaim 消费者—协调 (nodes/coordination-dialogue.ts, nodes/interaction-point-detection.ts 增强)
  Group 4: 图组装 + 入口路由 (nodes/intention.ts, edges/conditional.ts, agents/index.ts)

逐组业务价值判定:
  Group 1 (类型): 不能用 — 仅有类型定义，无运行时行为
  Group 2 (State+生产者): 不能用 — ExpertClaim 生成器存在但无消费者、无图接入
  Group 3 (消费者): 不能用 — 节点代码存在但未接入图，孤立节点不可达
  Group 4 (图组装): 能用 — 所有组件就位，三图路由分发，professional 图端到端可达
  → 判定: Group 1-4 任一缺失则 professional 图不可用，四者构成 1 个原子闭包

判定结论: 需要 1 轮（1 个原子闭包），内部拆分为 4 轮局部闭包便于 handoff 交接

第1轮（局部闭包 1）: Group 1 — 职责: 类型基石
  可独立验证: ✅ tsc --noEmit
  可独立审计: ✅ 纯声明式，无运行时审计点
  可独立恢复: ✅ 通过 changed files 列表恢复上下文
  Handoff 边界: 产出 ExpertClaim / ConflictReport / CoordinationResult / AggregatedReport 类型定义
                + ThinkingLevel 三级扩展。不含任何运行时逻辑

第2轮（局部闭包 2）: Group 2 — 职责: ExpertClaim 生产者
  可独立验证: ✅ tsc --noEmit + structuredOutputNode 单测
  可独立审计: ✅ structuredOutputNode 新增 AgentAuditPhase 字面量
  可独立恢复: ✅ 通过 planKeyword + "structured-output" 恢复上下文
  Handoff 边界: 产出 State 扩展（massifIds/expertClaims 等字段）
                + ExpertClaim 生成节点。不修改现有节点 / index / conditional
  ★ v2 关键设计: 本轮的 ExpertClaim 是下一轮（消费者）的唯一输入契约

第3轮（局部闭包 3）: Group 3a+3b — 职责: ExpertClaim 消费者
  可独立验证: ✅ conflictResolver ≥14 条单测 + aggregation 单测 + coordinationDialogue 单测
  可独立审计: ✅ 各节点新增 agentAudit 调用
  可独立恢复: ✅ 通过 planKeyword + 节点名 恢复上下文
  Handoff 边界: 产出 conflictResolver（纯函数，零 LLM）+ aggregation（纯格式化）
                + coordinationDialogue（LLM 定向提问）+ interactionPoint 增强
                消费上游产出的 ExpertClaim[]，输出 ConflictReport[] / AggregatedReport
  ★ v2 关键设计: 本轮所有节点都消费 ExpertClaim[]——输入契约由轮次 2 定义

第4轮（局部闭包 4）: Group 4 — 职责: 图组装 + 集成
  可独立提交: ✅ 用户可感知 professional 图完整功能（唯一产生 business value 的轮次）
  可独立验证: ✅ 三场景端到端验证
  可独立审计: ✅ 按图路由分离 AgentAuditPhase
  可独立恢复: ✅ 通过 graph compilation 状态恢复上下文
  Handoff 边界: 交付 professional 图可用状态，全部验收标准通过
```

> **轮次关系**：1→2→3→4 串行依赖。2 消费 1 的类型，3 消费 2 的 ExpertClaim[]，4 组装 2+3 的节点到图中。
> 四轮共同构成 1 个原子闭包——只有轮次 4 交付后 business value 才完整，但前 3 轮作为局部闭包各自提供可验证、可 handoff 的中间里程碑。
> **v2 生产者/消费者分离的工程价值**：轮次 2 定义 ExpertClaim 格式（生产者），轮次 3 消费 ExpertClaim（消费者）。如果 ExpertClaim 格式需要调整，只需回溯轮次 2 的 handoff，不污染轮次 1（类型定义）和轮次 3（消费逻辑）。

```
                         Phase 0: H5 Resume ✅    Phase 1: isSummary ✅
                               │                         │
                               └───────────┬─────────────┘
                                           │
                    ╔══════════════════════╧═══════════════════════════╗
                    ║         1 个原子闭包: professional 图            ║
                    ║                                                ║
                    ║  ┌──────────────────────────────────────────┐  ║
                    ║  │ 轮次 1: 类型基石                          │  ║
                    ║  │ 职责: 声明层——零运行时风险                 │  ║
                    ║  │ 验收: tsc --noEmit                       │  ║
                    ║  │ 文件: types/evidence.ts                  │  ║
                    ║  │       prompts/types.ts                   │  ║
                    ║  │ 产出: ExpertClaim / ConflictReport / 等 5 类│  ║
                    ║  └──────────────┬───────────────────────────┘  ║
                    ║                 │                              ║
                    ║  ┌──────────────┴───────────────────────────┐  ║
                    ║  │ 轮次 2: State 桥接 + ExpertClaim 生产者    │  ║
                    ║  │ 职责: 桥接层——类型→运行时                  │  ║
                    ║  │ 验收: tsc --noEmit + structuredOutput 单测 │  ║
                    ║  │ 文件: agents/state.ts                     │  ║
                    ║  │       nodes/structured-output.ts          │  ║
                    ║  │ ★ 定义 ExpertClaim 输入契约（供轮次 3 消费）│  ║
                    ║  └──────────────┬──────────────┬────────────┘  ║
                    ║                 │              │               ║
                    ║  ┌──────────────┴──┐  ┌────────┴──────────┐   ║
                    ║  │ 轮次 3a: 确定性  │  │ 轮次 3b: 格式化+协调│   ║
                    ║  │ conflictResolver │  │ aggregation        │   ║
                    ║  │ (纯函数，零 LLM) │  │ coordinationDialogue│   ║
                    ║  │ 验收: ≥14 条单测 │  │ interactionPoint 增强│   ║
                    ║  │ ★ 消费 ExpertClaim│  │ ★ 消费 ExpertClaim  │   ║
                    ║  └────────┬────────┘  └────────┬──────────┘   ║
                    ║           └─────────────────────┘              ║
                    ║                      │                         ║
                    ║  ┌───────────────────┴─────────────────────┐   ║
                    ║  │ 轮次 4: 图组装 + 入口路由 + 集成验证     │   ║
                    ║  │ 职责: 集成层——消费者可感知价值            │   ║
                    ║  │ 验收: 三场景端到端通过 + 审计路由分离     │   ║
                    ║  │ 文件: nodes/intention.ts               │   ║
                    ║  │       edges/conditional.ts              │   ║
                    ║  │       agents/index.ts                   │   ║
                    ║  └─────────────────────────────────────────┘   ║
                    ╚════════════════════════════════════════════════╝
```

---

### 轮次 1: 类型基石

> **职责边界**：仅声明层——6 个类型/接口定义。**不修改任何运行时逻辑**，不影响现有 fast/deep 图。
> **Handoff 交接面**：产出 5 个新接口 + 1 个类型扩展，下游 AI 通过 `tsc --noEmit` + 文件清单恢复上下文。
> **与 v2 的差异**：沿用 v2 轮次 1 的完整结构。轮次 1 虽薄（约 60 行），但职责纯粹——"定义 ExpertClaim/ConflictReport 等类型"作为独立 handoff 语义清晰，无需在轮次 2 的 State+生产者 handoff 中夹杂类型定义的说明。

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 1.1 | ThinkingLevel 扩展为三级 | `src/types/evidence.ts` | `"fast" \| "deep"` → `"fast" \| "deep" \| "professional"` | `tsc --noEmit` |
| 1.2 | ExpertClaim 接口定义 | `src/agents/prompts/types.ts` | 新增：expertId / claim / preconditions / hardConstraints / softConstraints / recommendedActions（含 `method?: string`） | `tsc --noEmit` |
| 1.3 | ConflictReport 接口定义 | `src/agents/prompts/types.ts` | 新增：type（4 种）/ involvedExperts / description / severity（HARD\|SOFT）/ suggestedResolution | `tsc --noEmit` |
| 1.4 | CoordinationResult 接口定义 | `src/agents/prompts/types.ts` | 新增：resolved / revisedClaims / residualConflicts | `tsc --noEmit` |
| 1.5 | AggregatedReport 接口定义 | `src/agents/prompts/types.ts` | 新增：合并后的统一报告格式 | `tsc --noEmit` |

**验收标准**：
- `npx tsc --noEmit` 零错误
- 新类型定义不与现有类型冲突
- fast/deep 图运行时行为不受影响（仅类型扩展，无逻辑变更）

---

### 轮次 2: State 桥接 + ExpertClaim 生产者

> **职责边界**：桥接层——将轮次 1 的类型定义接入运行时（State 扩展）+ 实现 ExpertClaim 生成器（structuredOutputNode）。
> **Handoff 交接面**：下游轮次 3 通过 ExpertClaim 接口契约消费。下游 AI 通过 `tsc --noEmit` + structuredOutputNode 单测 + 新增 AgentAuditPhase 恢复上下文。
> **依赖轮次 1** 的类型定义。
> **★ v2 生产者/消费者边界**：本轮是 ExpertClaim 的**唯一生产者**——`structuredOutputNode` 接收 reasoning 自由文本，产出 `ExpertClaim[]`。轮次 3 的所有节点都以此 `ExpertClaim[]` 为输入契约。如果 ExpertClaim 格式需要调整，只需修改本轮 handoff，轮次 3 不受影响。

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 2.1 | AgentState 扩展 | `src/agents/state.ts` | 新增 massifIds / expertPlan / expertClaims / conflictReports / coordinationResult / aggregatedReport；保留 massifId；添加双模互斥校验注释 | `tsc --noEmit` + deep 图回归零 |
| 2.2 | structuredOutputNode 实现 | `src/agents/nodes/structured-output.ts` | 接收 reasoning 输出的自由文本 + toolResult + evidence，调用 LLM 转换为 `ExpertClaim` 结构体（含 preconditions / hardConstraints / softConstraints / recommendedActions 提取） | `tsc --noEmit` + 单节点 mock 测试 |

**验收标准**：
- `npx tsc --noEmit` 零错误
- deep 图回归零（单专家推理不受 State 扩展影响）
- structuredOutputNode 单测：给定 mock reasoning 输出 → 产出完整 ExpertClaim 结构体

---

### 轮次 3: ExpertClaim 消费者（ACA 核心逻辑）

> **职责边界**：逻辑层——所有节点都以 `ExpertClaim[]` 为输入，消费上游轮次 2 定义的数据契约。
> **Handoff 交接面**：下游轮次 4 通过 ConflictReport[] / AggregatedReport 接口消费。下游 AI 通过各节点单测 + 新增 AgentAuditPhase 恢复上下文。
> **依赖轮次 2** 的 State 扩展和 ExpertClaim 格式。
> **★ v2 生产者/消费者边界**：本轮是 ExpertClaim 的**消费者**——conflictResolver 消费 ExpertClaim[].preconditions 做前提互斥检测，aggregation 消费 ExpertClaim[].recommendedActions 做去重合并，coordinationDialogue 消费 ExpertClaim[].softConstraints 做约束松弛。kbConflictAggregator 消费 ExpertClaim[].metadata.kbDisagreement 做 KB 双源冲突集中裁决。所有节点的类型签名都以 `ExpertClaim[]` 为入口参数。

#### 3a: kbConflictAggregator（KB 双源冲突集中裁决）

> **v3 新增**——行业调研结论：KB 冲突不在 fan-out 内并行 interrupt，改为 fan-in 后集中处理。
> 对齐 [MADAM-RAG](https://arxiv.org/abs/2504.13079) 的 Aggregator 模式，规避 LangGraph 并行 interrupt 已知 Bug。

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 3a.0 | kbConflictAggregator 实现 | `src/agents/nodes/kb-conflict-aggregator.ts` | 遍历 ExpertClaim[]，收集 metadata.kbDisagreement 标记；有冲突时调用单次 `interrupt()` 呈现 KB 双源矛盾给用户；无冲突时透传 ExpertClaim[] 到 conflictResolver | `tsc --noEmit` + 单测（模拟 1 个/多个/无 KB 冲突场景） |

#### 3a: conflictResolverNode（确定性冲突检测，零 LLM，可与 aggregation 并行）

> **纯函数**——接收 `ExpertClaim[]`，返回 `ConflictReport[]`。借鉴 MAPF mutex propagation。

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 3a.1 | 前提互斥检测 | `src/agents/nodes/conflict-resolver.ts` | pairwise 检查 precondition，内置反义词匹配表（6 组）。纯算法 | 单测 ≥4 条 |
| 3a.2 | 资源冲突检测 | 同上 | 聚合 recommendedActions[].resources[]，按资源ID+时间分组计数。纯算法 | 单测 ≥4 条 |
| 3a.3 | 时序矛盾检测 | 同上 | 比较 deadline 与 timing 时间区间。纯算法 | 单测 ≥3 条 |
| 3a.4 | 执行标准不一致检测 | 同上 | 检查 recommendedActions[].method，内置互斥方法对表（5 组）。纯算法 | 单测 ≥3 条 |
| 3a.5 | severity 判定逻辑 | 同上 | HARD: 前提互斥(pest↔weather类)、资源冲突(农机/人力/地块)、时序矛盾(deadline类)。SOFT: 资源冲突(水源/农资/时间窗口)、执行标准不一致 | 同各项测试覆盖 |

> 可与 3b 并行实现（conflictResolver 和 aggregation 都是纯函数，无 LLM 调用，互不依赖）。

#### 3b: aggregationNode（格式聚合）+ coordinationDialogueNode（约束松弛）+ interactionPoint 增强

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 3b.1 | aggregationNode 实现 | `src/agents/nodes/aggregation.ts` | 接收 ExpertClaim[]，按权重合并为 AggregatedReport：合并 claim、去重 action、标记未解决 ConflictReport | `tsc --noEmit` + 单测 |
| 3b.2 | coordinationDialogueNode 实现 | `src/agents/nodes/coordination-dialogue.ts` | 接收 ConflictReport[] + ExpertClaim[]，4 步协调：① 识别可变项 ② 生成定向提问 ③ 解析修订建议 ④ 约束松弛求解（三级策略） | `tsc --noEmit` + 单测 |
| 3b.3 | interactionPoint 增强 | `src/agents/nodes/interaction-point-detection.ts` | 增加 professional 图分支：检测 `coordinationResult.resolved === false` 时，调用 `interrupt({ conflict, optionA, optionB })` 暂停图。多 interrupt 场景使用 `{ interrupt_id: value }` 映射恢复 | `tsc --noEmit` |

**约束松弛三级策略**（同 v2，v3 补充行业依据）：

> 2 轮上限基于 Becker et al. (2025) [Stay Focused: Problem Drift in Multi-Agent Debate](https://arxiv.org/abs/2502.19559)——超过 3 轮后约 0.8% 的 case 出现"问题漂移"（agent 偏离原始任务），Xu et al. (2023) 也证实精度在第 2 轮后开始下降。农业场景保守取 2 轮。

| 约束类型 | 松弛策略 | 松弛条件 | 终止条件 |
|---------|---------|---------|---------|
| SOFT `penalty < 0.3` | 自动松弛 | penalty 最低 | 最多松弛 N/2 个 |
| SOFT `penalty ≥ 0.3` | LLM 协调对话尝试修订 | penalty 从低到高 | 最多 2 轮 |
| HARD | **永不松弛** | — | 进入 interactionPoint |

**验收标准**（轮次 3 整体）：
- 所有新增节点 `tsc --noEmit` 零错误
- conflictResolver 4 类检测 ≥14 条单测通过，零 LLM 调用
- aggregationNode 单测：ExpertClaim[] → AggregatedReport 格式正确
- coordinationDialogue 定向提问 + 约束松弛单测通过
- interactionPoint 正确调用 `interrupt()` 并呈现结构化选项

---

### 轮次 4: 图组装 + 入口路由 + 集成验证

> **职责边界**：集成层——将轮次 1-3 的所有组件组装到 professionalGraph，实现三图入口路由。这是唯一产生用户可感知业务价值的轮次。
> **Handoff 交接面**：交付 professional 图可用状态。下游 AI 通过 `tsc --noEmit` + 三场景集成验证结果 + graph compilation 状态恢复上下文。
> **依赖轮次 1-3 全部完成**。

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 4.1 | intention 节点增强 | `src/agents/nodes/intention.ts` | professional 场景产出 `expertPlan: Expert[]`（含 per-expert subIntent 拆分 + massifIds[] 绑定） | `tsc --noEmit` |
| 4.2 | routeByIntent 扩展 | `src/agents/edges/conditional.ts` | 新增 professional 路径：`thinkingLevel === "professional"` → professionalGraph | `tsc --noEmit` |
| 4.3 | 三图编译 | `src/agents/index.ts` | 将现有 workflow 提取为 deepGraph；新建 professionalGraph（Send API fan-out + 5 新节点）；fastGraph = 现有 fast 路由。入口函数分发 | 三图编译无异常 |
| 4.4 | 集成验证 | — | 三种场景验证：① 单专家 → deep 图 ② isSummary → deep 图 ③ 多专家 → professional 图 fan-out → ExpertClaim → conflictResolver → aggregation → verdict → response | 路由正确 + 端到端通过 |

**验收标准**（轮次 4 整体）：
- `npx tsc --noEmit` 零错误
- 三个图均可编译（`StateGraph.compile()` 无异常）
- 场景 ①：pest_risk 单专家 → deep 图，RAG 证据链正常，回归零
- 场景 ②：weekly_report（isSummary）→ deep 图，工具数据为一等证据
- 场景 ③：pest_risk + weather + soil 三专家 → professional 图 fan-out → ExpertClaim → conflictResolver → aggregation → verdict → response
- fast 图不受影响
- 审计日志按图路由分离

---

## 六、验收标准（全量）

- [x] Phase 1: weekly_report 场景：工具数据作为一等证据 ✅ 2026-06-17
- [x] Phase 0: H5 chat 路由 `__interrupt__` 检测 + StreamState 状态机 ✅ 2026-06-26
- [x] Phase 0: `POST /api/h5/agent/{threadId}/resume` 端点可用 ✅ 2026-06-26
- [ ] 轮次 1（类型）: `npx tsc --noEmit` 零错误，5 个新接口 + ThinkingLevel 三级扩展
- [ ] 轮次 2（State+生产者）: `npx tsc --noEmit` 零错误 + deep 图回归零 + structuredOutputNode 单测通过
- [ ] 轮次 3（消费者）: kbConflictAggregator 单测 + conflictResolver ≥14 条单测（零 LLM）+ aggregation 单测 + coordinationDialogue 单测 + interactionPoint 增强
- [ ] 轮次 4（集成）: 三图编译成功 + 三种场景路由正确 + pest_risk + weather + soil 端到端通过
- [ ] 前提互斥可正确检测 ≥4 种农业场景
- [ ] 资源冲突可正确检测 ≥4 种农业场景
- [ ] 时序矛盾可正确检测 ≥3 种农业场景
- [ ] 执行标准不一致可正确检测 ≥3 种农业场景
- [ ] 硬冲突残留 → interactionPoint 生成，通过 `interrupt()` + `Command(resume)` 恢复
- [ ] `npx tsc --noEmit` 零错误（全量）
- [ ] fast 图不受影响
- [ ] 审计日志按图路由分离

---

## 七、风险矩阵（v3 新增）

| 风险 | 概率 | 影响 | 缓解措施 |
|------|:--:|------|---------|
| Send API fan-out 在 LangGraph JS 版本中行为与 Python 文档不一致 | 中 | 高——fan-out 失败则 professional 图无法并行执行专家 | 轮次 4.3 前做 Send API 最小可行性验证（2 专家 mock fan-out） |
| 多 expert 并行工具调用在 PostgresSaver 下产生竞态（同一 threadId 并发写 checkpoint） | 低 | 中——checkpoint 覆盖导致 State 丢失 | 单测覆盖并发写场景；PostgresSaver 使用 `rowLock` 或串行化写入 |
| structuredOutputNode LLM 调用无法稳定产出符合 ExpertClaim 格式的 JSON | 中 | 中——后续 conflictResolver 因缺少 preconditions/constraints 字段而漏检冲突 | 增加 JSON schema 约束 + parse 失败重试（最多 2 次） |
| intention 节点 expertPlan 拆分不准确（多专家场景遗漏或误激活） | 中 | 中——漏激活则缺专家意见，误激活则注入无关噪声 | 保留当前 `subIntents` 拆解逻辑作为 baseline，professional 扩展现有 subIntentPlan |
| `StreamState` 状态机与 `interrupt()` 交互点语义冲突（Streaming→Interrupted 转换在 resume 流中重复触发） | 低 | 低——现有 `Resume` 状态已处理此路径 | 轮次 4.4 集成测试覆盖 resume 后二次 interrupt 场景 |
| 中断格式迁移（`{ value: InteractionPoint }`→`InterruptPayload`）导致 H5 前端 SSE 解析失败 | 高 | 高——deep 图现有交互点（Decision/Tradeoff/Clarification/Confirmation）渲染失败，用户无法操作 | H5 前端同步更新 SSE 解析（去掉 `.value` 包裹层，`reason`/`impact` 字段透传不需合并）；轮次 3.4 完成后立即做 deep 图 interrupt 回归测试；Checklist [R] 项覆盖 |

### 7.1 KB 冲突处理策略（Web 调研结论）

> 行业调研发现两个关键风险：
> 1. LangGraph 已知 Bug [#5952](https://github.com/langchain-ai/langgraph/issues/5952)：并行节点中已解决的 interrupt 会持续"幽灵"触发，直到所有并行节点完成
> 2. LangGraph 已知 Bug [#6533](https://github.com/langchain-ai/langgraph/issues/6533)：并行 ToolNode 中 interrupt 恢复值可能路由到错误的 Tool（竞态条件）
> 3. 行业最佳实践（[MADAM-RAG, COLM 2025](https://arxiv.org/abs/2504.13079)）：KB 冲突在 fan-in 后由集中式 Aggregator 处理，不在 fan-out 的并行节点内做 interrupt

**v3 决策：采用集中式 KB 冲突处理（方案 B）**

```
fan-out（per-expert，零 interrupt）:
  reasoning 检测到 KB 双源距离 > 0.3
  → 不调用 interrupt()
  → 写入 ExpertClaim.metadata.kbDisagreement: KBDisagreementPayload
  → 继续完成推理（使用项目 KB 结果作为默认值）

fan-in 汇聚 → ExpertClaim[]

kbConflictAggregator（串行节点，唯一 interrupt 点）:
  → 遍历所有 ExpertClaim，收集 kbDisagreement 标记
  → 有冲突时：单次 interrupt() 呈现给用户
  → 无冲突时：透传 ExpertClaim[] 到 conflictResolver

用户裁决 → Command(resume) → 重新触发受影响 expert 的 reasoning → 重新 structuredOutput
  → 更新 ExpertClaim[] → 继续 conflictResolver → ...
```

**设计理由**：
- deep 图和 professional 图是独立编译的 StateGraph，互不影响——deep 图的 KB 冲突 interrupt 保留原样
- professional 图 fan-out 内零 interrupt，彻底规避 LangGraph 并行 Bug
- 对齐 MADAM-RAG 的 Aggregator 模式：集中检测、单点裁决
- kbConflictAggregator 复用现有 `KBDisagreementPayload` 类型和 SSE interrupt 渲染链路

**resume 后执行范围**（Review P2 回流明确）：

用户裁决后 `Command(resume)` 返回时，仅重新执行受影响 expert 的 reasoning + structuredOutput，局部更新 ExpertClaim[] 中对应条目，**不重跑全量 fan-out**。理由：
1. 未受 KB 冲突影响的 expert（pest/soil）其 ExpertClaim 仍有效，重跑全量 fan-out 会导致不必要的 token 消耗和 ExpertClaim 版本不一致
2. 实现方式：kbConflictAggregator 在 interrupt 前记录 `affectedExpertIds: string[]`，resume 后仅向这些 expertId 发送 `Send("perExpertReasoning", { expertId })` 进行局部重跑
3. 局部重跑后的 ExpertClaim 替换原有条目，然后继续 conflictResolver → ...

---

## 八、补充说明（Review 回流）

> 本节为 2026-06-29 [三版合并 Review](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-v3.md) 的 P0/P1 问题回流。

### 8.1 P0: Spec/Tasks/Checklist 三元组缺失

**Review 发现**：三版 Plan 的 Spec/Tasks/Checklist 全部未生成。v2 已延迟 12 天，v3 若无 Spec 立即进入实施，将重蹈"Plan 是方向图，缺施工图"困境。

**回流处理**：进入 ADD Step 1 前必须生成 `specs/farm-agent-three-tier-reasoning-graph/spec.md`，最低覆盖：
1. **conflictResolver 四类检测的 WHEN-THEN Scenario**：每条对应一个农业场景
2. **coordinationDialogue 约束松弛的 penalty 计算 + prompt 模板**
3. **kbConflictAggregator 的 KB 冲突标记 → interrupt → resume → 局部重跑 全流程**
4. **structuredOutputNode 的 JSON schema 约束**（确保 ExpertClaim 字段完整性）

### 8.2 P1: ADD Route 缺失

**Review 发现**：v3 add-route 未生成。按 ADD Step 3.0 前置守卫，无 add-route 禁止进入代码实现。

**回流处理**：在 Spec 生成后、Step 1 前，调用 `get_add_template({ template: "add-route-template-heavyweight" })` 生成 v3 add-route。

### 8.3 P1: v2 Handoff 未更新

**Review 发现**：v2 Handoff 只覆盖 Phase 0（H5 Resume），下游 AI 读 v2 Handoff 时不知道 v3 存在。

**回流处理**：已更新 v2 Handoff 元信息——新增"后继 Plan"指向 v3 + "关联 Review"指向 v3 Review。

### 8.4 P2: kbConflictAggregator resume 语义

**回流处理**：已在 §7.1 补充 resume 后执行范围说明——仅局部重跑受影响 expert，不重跑全量 fan-out。

### 8.5 P2: 约束松弛"最多 2 轮"行业依据

**回流处理**：已在 §五 轮次 3 补充行业引用：2 轮上限基于 Becker et al. (2025) "问题漂移"发现 + Xu et al. (2023) 精度在第 2 轮后下降的实证。

---

## 九、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| V1 Plan | `.qoder/plans/2026-06/17/farm-agent-three-tier-reasoning-graph-plan-v1.md` | ✅ 现有 |
| V2 Plan | `.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-plan-v2.md` | ✅ 现有 |
| V2 Handoff | `.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-handoff-v2.md` | ✅ 现有 |
| ADD Route | `.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-add-route-v3.md` | ✅ 现有（重型模板） |
| Handoff | `.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-handoff-v3.md` | ✅ 现有（4 轮 13 子章节/轮） |
| Review | `.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-v3.md` | ✅ 现有（2026-06-29 三版合并 Review） |
| Spec | `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md` | ✅ 现有（2026-06-29 4 Requirement） |
| Tasks | `.qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md` | ✅ 现有（2026-06-29 4 轮次 15 Task） |
| Checklist | `.qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md` | ✅ 现有（2026-06-29 4 轮次 30+ [T]/[R] 项） |
| 决策管线架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` | 现有 |
| OS Kernel 架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/Agent-OS-Kernel-架构说明书.md` | 现有 |

---

## 附录 A: v2 → v3 变更对照

| 维度 | v2（2026-06-25） | v3（2026-06-29） |
|------|------------------|------------------|
| 代码基线 | Phase 0 刚交付，H5 路由使用 interrupted 布尔 | Phase 0 + h5-agent-route-code-quality 重构完成，StreamState 枚举替代布尔 |
| Checkpointer | MemorySaver | PostgresSaver（正向收益） |
| 原子闭包判定 | 未执行 | 1 个原子闭包，内部拆分为 4 轮局部闭包（§5.0） |
| 轮次结构 | 4 轮（类型 / State+structuredOutput / 3a+3b+3c / 图组装） | **沿用 4 轮**，补充每轮职责边界 + Handoff 交接面 + 生产者/消费者分界标注 |
| 轮次 3 内部 | 3a/3b/3c 三个子轮 | 3a（冲突检测）可并行 3b（聚合+协调），保留 v2 子任务表 |
| 职责边界 | 未定义 | 每轮明确「职责边界 + Handoff 交接面」 |
| 风险矩阵 | 无 | 新增 §七：5 项风险 + 缓解措施 |
| 介入变更分析 | 无 | 新增 §四：介入变更清单 + 兼容性确认 + 结论 |
| 架构设计 | 完整 ACA 架构 | 完全沿用，无变更 |
