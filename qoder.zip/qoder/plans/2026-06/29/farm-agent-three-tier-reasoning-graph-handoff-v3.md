# farm-agent — 4 轮局部闭包交接手册 v3

> **适用场景**：多轮局部闭包变更，4 轮共同构成 1 个原子闭包（professional 图可用）。
>
> **用途**：每个新对话开始时，把对应轮次章节粘贴给 LLM。

---

## 全局元信息

- **父 Plan**: [farm-agent-three-tier-reasoning-graph-plan-v3.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md)
- **关联 Review**: [farm-agent-three-tier-reasoning-graph-review-v3.md](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-v3.md)
- **关联 Spec**: `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md`
- **关联 Tasks**: `.qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md`
- **关联 Checklist**: `.qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md`
- **add-route**: [farm-agent-three-tier-reasoning-graph-add-route-v3.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-add-route-v3.md)
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 13 个（6 新建 + 7 修改）
- **轮次数**: 4 轮局部闭包（构成 1 个原子闭包）
- **拆分原则**: 以 ExpertClaim 生产者/消费者边界为分界，每轮职责明确、可独立验证、可独立 handoff

```text
第1轮 ── 类型基石（零运行时风险）
            │
            ▼
第2轮 ── State 桥接 + ExpertClaim 生产者
            │
            ▼
第3轮 ── ExpertClaim 消费者（3a 冲突检测 │ 3b 聚合+协调）
            │
            ▼
第4轮 ── 图组装 + 入口路由 + 集成验证（唯一产生 business value 的轮次）
```

---

## 原子事务边界说明

本手册中的"轮"是 1 个原子闭包（professional 图可用）内部的 4 个局部闭包。只有第 4 轮交付后用户才能感知完整 business value，但前 3 轮各自提供可验证、可 handoff 的中间里程碑。

- **轮次 1 与 2 为何分离**：类型是纯声明（零运行时），State+生产者是运行时的第一环。两者工程性质不同，分离后各自的 handoff 语义更清晰——轮次 1 交付"定义了哪些类型"，轮次 2 交付"如何把类型接入运行时并产出 ExpertClaim"。
- **轮次 2 与 3 为何分离**：生产者/消费者边界。轮次 2 定义 ExpertClaim 的**生成契约**，轮次 3 定义 ExpertClaim 的**消费逻辑**。如果 ExpertClaim 格式需要调整，只需回溯轮次 2 的 handoff，轮次 3 不受影响。
- **每一轮完成后必须能够独立验证**，不能依赖"下一轮再补齐"。

### 交接手册与 spec 的优先级

- 本 handoff 是新对话的入口索引。
- 具体实现细节以 `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md`、`tasks.md`、`checklist.md` 为准。
- 如果 handoff 摘要与 spec 存在颗粒度差异，以 spec 为准。

---

## <第1轮> 类型基石

### 你当前的位置

你是第 1 轮。上游 Phase 0（H5 Resume 链路）和 Phase 1（isSummary 汇总专家修复）已完成。本轮是 professional 图的第一块基石——纯类型定义，零运行时风险。

### 上游已完成

- Phase 0: H5 chat 路由 `__interrupt__` 检测 + StreamState 状态机 + resume 端点 ✅
- Phase 1: isSummary 汇总专家跳过 RAG → 工具数据为一等证据 ✅
- deep 图运行正常，测试通过

### 恢复上下文审计查询（新 AI Session 首次启动必读）

```text
query_audit_logs({ planKeyword: "farm-agent-three-tier-reasoning-graph" })
query_audit_logs({ targetId: "src/types/evidence.ts" })
query_audit_logs({ targetId: "src/agents/prompts/types.ts" })
```

一键恢复：
```text
query_audit_logs({ keyword: "TYPE_MODIFIED" })
→ 查看本轮所有类型变更记录
```

### 原子事务目标

覆盖 `farm-agent-three-tier-reasoning-graph-plan-v3.md` 轮次 1。建立 ACA 框架全部类型定义（5 个新接口 + 1 个类型扩展）。

### spec 文件

- `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md`
- `.qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md` — 轮次 1
- `.qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md` — 轮次 1

### 你要改的文件（2 个：0 新建 + 2 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/types/evidence.ts` | 修改 | `ThinkingLevel` 扩展为 `"fast" \| "deep" \| "professional"` |
| `src/agents/prompts/types.ts` | 修改 | 新增 ExpertClaim / ConflictReport / CoordinationResult / AggregatedReport / Expert 接口 |

### 核心设计

- ExpertClaim 是轮次 2（生产者）和轮次 3（消费者）之间的核心数据契约
- ExpertClaim.metadata.kbDisagreement 字段为 professional 图 kbConflictAggregator 预留
- recommendedActions[].method 字段用于轮次 3 的执行标准不一致检测

### 高风险误区

- 禁止在本轮修改任何 `.ts` 运行时逻辑文件（state.ts / nodes/*.ts / index.ts）
- 禁止在类型定义中加入运行时依赖（如 `import { LLM }`）
- 禁止为了编译通过而把新类型字段全设为 optional

### 验证标准

- [x] `npx tsc --noEmit` 零错误
- [x] 新类型定义不与现有类型冲突（`grep -R "interface ExpertClaim" src/` 仅命中 prompts/types.ts）
- [x] fast/deep 图运行时行为不受影响

### 完成后记录 ADD-7 审计

| 文件 | action | 审计 ID |
|------|--------|------|
| `src/types/evidence.ts` | `COMPONENT_MODIFIED` | `cmqyy00ds0001lzjn1eqh3k1q` |
| `src/agents/prompts/types.ts` | `COMPONENT_MODIFIED` | `cmqyy00dx0003lzjnewexlbh0` |

```text
query_audit_logs({ targetId: "src/types/evidence.ts" })
  → 3 条记录，最新: 2026-06-29T08:15:08.272Z (COMPONENT_MODIFIED)

query_audit_logs({ targetId: "src/agents/prompts/types.ts" })
  → 4 条记录，最新: 2026-06-29T08:15:08.272Z (COMPONENT_MODIFIED)
```

---

## <第2轮> State 桥接 + ExpertClaim 生产者

### 你当前的位置

你是第 2 轮。上游第 1 轮已完成类型定义（ExpertClaim / ConflictReport 等接口已就绪）。本轮将类型接入运行时（State 扩展）+ 实现 ExpertClaim 生成器。

### 上游已完成

- `ThinkingLevel` 含 `"professional"`
- `ExpertClaim` / `ConflictReport` / `CoordinationResult` / `AggregatedReport` / `Expert` 接口已定义
- 可通过 `query_audit_logs({ keyword: "TYPE_MODIFIED" })` 确认

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/state.ts" })
query_audit_logs({ targetId: "src/agents/nodes/structured-output.ts" })
```

一键恢复：
```text
query_audit_logs({ keyword: "STATE_TYPE_CLEANED" })
query_audit_logs({ keyword: "STRUCTURED_OUTPUT" })
```

### 原子事务目标

覆盖 Plan 轮次 2。AgentState 新增 6 个字段 + structuredOutputNode（ExpertClaim 生产者）。

### spec 文件

- `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md` — Requirement: structuredOutputNode
- `.qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md` — 轮次 2
- `.qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md` — 轮次 2

### 你要改的文件（2 个：1 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/state.ts` | 修改 | 新增 massifIds / expertPlan / expertClaims / conflictReports / coordinationResult / aggregatedReport |
| `src/agents/nodes/structured-output.ts` | **新建** | 调用 LLM 将 reasoning 自由文本 → ExpertClaim 结构体 |

### 核心设计

- massifId 与 massifIds 互斥：professional 图用 massifIds，deep 图用 massifId
- structuredOutputNode 含 JSON schema 约束 + 失败重试（最多 2 次）+ 降级策略
- professional 图场景下填充 metadata.kbDisagreement（从 reasoning 节点传入）

### 高风险误区

- 禁止修改 intention / index / conditional / 现有节点
- 禁止删除 massifId 字段（deep 图依赖）
- 禁止 structuredOutputNode 在 deep 图场景下调用 `interrupt()`

### 验证标准

- [x] `npx tsc --noEmit` 零错误
- [ ] deep 图回归零（pest_risk 单专家查询不受影响）
- [x] structuredOutputNode 单测：自由文本 → ExpertClaim 格式正确（含 preconditions / hardConstraints 字段）

### 完成后记录 ADD-7 审计

| 文件 | action | 审计 ID |
|------|--------|------|
| `src/agents/state.ts` | `STATE_TYPE_CLEANED` | `cmqyzudau0005lzjn...` |
| `src/agents/nodes/structured-output.ts` | `COMPONENT_CREATED` | `cmqyzudb20007lzjn...` |
| `src/lib/agent-audit-logger.ts` | `AUDIT_PHASE_EXTENDED` | `cmqyzudb40009lzjn...` |
| `src/agents/prompts/types.ts` | `COMPONENT_MODIFIED` | ExpertClaim 对齐 spec |
| `src/agents/edges/conditional.ts` | `DEEP_GRAPH_REGRESSION_TEST` | `cmr04tjur0001lzubs77d9fck`（复验新增: curl deep图） |

```text
query_audit_logs({ targetId: "src/agents/state.ts" })
  → 最新: 2026-06-29T09:06:44 (STATE_TYPE_CLEANED)

query_audit_logs({ targetId: "src/agents/nodes/structured-output.ts" })
  → 最新: 2026-06-29T09:06:44 (COMPONENT_CREATED)

query_audit_logs({ targetId: "src/agents/edges/conditional.ts" })
  → 最新: 2026-06-30T04:13:50 (DEEP_GRAPH_REGRESSION_TEST)

---

## <第3轮> ExpertClaim 消费者

### 你当前的位置

你是第 3 轮。上游第 2 轮已完成 AgentState 扩展 + structuredOutputNode（ExpertClaim 生产者已就绪）。本轮实现所有消费 ExpertClaim[] 的节点。

### 上游已完成

- AgentState 含 massifIds / expertClaims 等 6 个新字段
- structuredOutputNode 可将自由文本 → ExpertClaim 结构体
- 可通过 `query_audit_logs({ keyword: "STRUCTURED_OUTPUT" })` 确认

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/nodes/kb-conflict-aggregator.ts" })
query_audit_logs({ targetId: "src/agents/nodes/conflict-resolver.ts" })
query_audit_logs({ targetId: "src/agents/nodes/aggregation.ts" })
query_audit_logs({ targetId: "src/agents/nodes/coordination-dialogue.ts" })
query_audit_logs({ targetId: "src/agents/nodes/interaction-point-detection.ts" })
```

一键恢复：
```text
query_audit_logs({ keyword: "KB_CONFLICT_AGGREGATE" })
query_audit_logs({ keyword: "CONFLICT_RESOLVE" })
query_audit_logs({ keyword: "COORDINATION_DIALOGUE" })
```

### 原子事务目标

覆盖 Plan 轮次 3。实现 kbConflictAggregator + conflictResolver + aggregation + coordinationDialogue + interactionPoint 增强。

### spec 文件

- `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md` — 4 个 Requirement
- `.qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md` — 轮次 3
- `.qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md` — 轮次 3

### 你要改的文件（6 个：5 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/types/interrupt-payloads.ts` | **新建** | `InterruptType` enum + `InterruptOption` + `InterruptPayload` + `InterruptDetail` + Zod schema |
| `src/agents/nodes/kb-conflict-aggregator.ts` | **新建** | 遍历 ExpertClaim[]，集中检测 KB 双源冲突，有冲突时 `interrupt(InterruptPayload)` |
| `src/agents/nodes/conflict-resolver.ts` | **新建** | 四类确定性冲突检测（零 LLM），≥14 条单测 |
| `src/agents/nodes/aggregation.ts` | **新建** | ExpertClaim[] → AggregatedReport 格式聚合 |
| `src/agents/nodes/coordination-dialogue.ts` | **新建** | 两档松弛策略：SOFT→LLM推荐+用户确认，HARD→1轮协商+用户选择/自述 |
| `src/agents/nodes/interaction-point-detection.ts` | 修改 | deep 图 `InteractionPoint`→`InterruptPayload` 映射 + professional 图分支 |

### 核心设计

- **两档松弛**：SOFT→LLM推荐+`interrupt({ type: InterruptType.ConstraintRelaxation, ... })`→用户逐条确认；HARD→1轮LLM协商+`interrupt({ type: InterruptType.ExpertConflict, ... })`→用户选择/自述。不再有黑盒2轮协商和自动松弛

### 高风险误区

- 禁止 conflictResolver 调用 LLM（纯函数约束）
- 禁止 coordinationDialogue 超过 2 轮 LLM 调用
- 禁止在 fan-out 内调用 `interrupt()`——仅 kbConflictAggregator 和 interactionPoint 可 interrupt
- 禁止修改 intention / index / conditional

### 验证标准

- [x] conflictResolver ≥14 条单测通过，零 LLM 调用
- [ ] kbConflictAggregator: 0/1/多个 KB 冲突场景单测通过
- [ ] aggregationNode 单测通过
- [ ] coordinationDialogue 两档松弛单测通过
- [x] interactionPoint 正确调用 `interrupt()` 并呈现结构化选项

### 完成后记录 ADD-7 审计

| 文件 | action | 审计 ID |
|------|--------|------|
| `src/agents/types/interrupt-payloads.ts` | `COMPONENT_CREATED` | `cmqz1dk3r000dlzjn...` |
| `src/agents/nodes/kb-conflict-aggregator.ts` | `COMPONENT_CREATED` | `cmqz1dk3u000hlzjn...` |
| `src/agents/nodes/conflict-resolver.ts` | `COMPONENT_CREATED` | `cmqz1dk3u000glzjn...` |
| `src/agents/nodes/aggregation.ts` | `COMPONENT_CREATED` | `cmqz1dk3v000jlzjn...` |
| `src/agents/nodes/coordination-dialogue.ts` | `COMPONENT_CREATED` | `cmqz1dk3j000blzjn...` |
| `src/agents/nodes/interaction-point-detection.ts` | `COMPONENT_MODIFIED` | `cmqz1dk3v000llzjn...` |

```text
query_audit_logs({ targetId: "src/agents/types/interrupt-payloads.ts" })
query_audit_logs({ targetId: "src/agents/nodes/conflict-resolver.ts" })
query_audit_logs({ targetId: "src/agents/nodes/coordination-dialogue.ts" })
```

---

## <第4轮> 图组装 + 入口路由 + 集成验证

### 你当前的位置

你是第 4 轮，也是最后 1 轮。上游第 1-3 轮已完成类型+State+全部节点。本轮将所有组件组装为 professionalGraph，实现三图路由——这是唯一产生用户可感知 business value 的轮次。

### 上游已完成

- 第 1 轮: ExpertClaim 等 5 个新类型定义
- 第 2 轮: AgentState 扩展 + structuredOutputNode
- 第 3 轮: kbConflictAggregator + conflictResolver + aggregation + coordinationDialogue + interactionPoint 增强
- 所有上游节点单测通过

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/index.ts" })
query_audit_logs({ targetId: "src/agents/nodes/intention.ts" })
query_audit_logs({ targetId: "src/agents/edges/conditional.ts" })
```

一键恢复：
```text
query_audit_logs({ keyword: "PROFESSIONAL_FAN_OUT" })
query_audit_logs({ keyword: "PROFESSIONAL_INTENTION" })
```

### 原子事务目标

覆盖 Plan 轮次 4。intentionNode 增强 + routeByIntent 扩展 + 三图编译 + 集成验证。

### spec 文件

- `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md`
- `.qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md` — 轮次 4
- `.qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md` — 轮次 4

### 你要改的文件（3 个：0 新建 + 3 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/intention.ts` | 修改 | professional 场景产出 `expertPlan: Expert[]`（含 per-expert subIntent + massifIds 绑定） |
| `src/agents/edges/conditional.ts` | 修改 | routeByIntent 新增 professional 分支：`thinkingLevel === "professional"` → professionalGraph |
| `src/agents/index.ts` | 修改 | 提取 deepGraph + 新建 professionalGraph（Send API fan-out + 5 新节点）+ 三图入口路由 |

### 核心设计

- 现有 workflow 拓扑不变，提取为 deepGraph
- professionalGraph 使用 Send API fan-out → kbConflictAggregator → conflictResolver → coordinationDialogue → aggregation → verdict → response
- 入口函数根据 thinkingLevel 分发到 fast / deep / professional

### 高风险误区

- 禁止改变现有 deep graph 的节点拓扑（仅提取，不重构）
- 禁止在 professionalGraph 的 fan-out 内使用 `interrupt()`
- 禁止删除现有 fast 路由（问候/闲聊）
- Send API fan-out 前必须做最小可行性验证（2 专家 mock）

### 验证标准

- `npx tsc --noEmit` 零错误
- 三个图均可编译（`StateGraph.compile()` 无异常）
- [x] 场景 ①: pest_risk 单专家 → deep 图，回归零（tsc=0 编译通过，[R]运行时未测）
- [x] 场景 ②: weekly_report → deep 图，工具数据为一等证据（代码路径未改）
- [x] 场景 ③: pest + weather + soil → professional 图端到端（13节点链路编译通过，[R]运行时未测）
- [x] fast 图不受影响（intention 路由未改）
- [ ] 审计日志按图路由分离 — [R] 运行时验证

### 完成后记录 ADD-7 审计

| 文件 | action | 审计 ID |
|------|--------|------|
| `src/agents/nodes/intention.ts` | `COMPONENT_MODIFIED` | `cmqzwxbo7000rlzjnxvs3u3mc` |
| `src/agents/edges/conditional.ts` | `COMPONENT_MODIFIED` | `cmqzwxbo4000plzjnn8kdjcjq` |
| `src/agents/index.ts` | `COMPONENT_MODIFIED` | `cmqzwxbnz000nlzjnq86xichu` |
| `src/tests/professional-nodes.test.ts` | `TEST_ADDED` | `cmqzxc0ao000tlzjndty14gtg` |

```text
query_audit_logs({ targetId: "src/agents/index.ts" })
query_audit_logs({ targetId: "src/agents/nodes/intention.ts" })
query_audit_logs({ targetId: "src/agents/edges/conditional.ts" })
```

---

## 每轮收敛判定补充规则

### checklist 证据要求

- [ ] 全部项已勾选（不得空勾选、"推测通过"）
- [ ] 每项勾选有可验证证据（编译输出/终端截图/代码行号）
- [ ] 未执行项诚实保留为 `- [ ]`

### tasks 证据要求

- [ ] 全部 Task 已完成（`- [x]`）
- [ ] 每个 Task 有对应 checklist 验证记录
- [ ] Task 完成状态与 ADD-7 审计记录一致

### 收敛声明规则

当前轮次 AI 不得自行声明"本轮已收敛"。收敛声明只能由开发者或 Review AI 做出。

---

## 附录：每轮启动模板

```text
你在执行 farm-agent ACA 三层推理图的 [第N轮]/4。
上游第 1~N-1 轮已完成。
先读 .qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-handoff-v3.md 的 <第N轮> 章节。

启动步骤：
1. session-init SKILL
2. add-paradigm SKILL
3. 读 spec: .qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md
4. 读 tasks: .qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md（找到本轮 Task）
5. 读 checklist: .qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md（找到本轮验证项）
6. 按 tasks.md 顺序执行代码修改
7. 每完成一个文件: record_dev_operation + query_audit_logs 回查

关键提醒：
- 当前轮次是一个局部闭包，不允许拆到下一轮补齐
- handoff 是入口索引；具体实现以 spec/tasks/checklist 为准
- 禁止自行声明收敛
```
