# farm-agent-code-review-fixes-handoff-v1

> 单轮交接 | 原子闭包: Code Review 首批修复

## 你当前的位置

本轮已完成 code-review-combined-report.md 中 7 个 P0/P1/P2 问题的修复。这是单轮原子事务，无上下游依赖。

## 上游已完成

无。

## 你的 spec 文件

- Spec: `.qoder/specs/code-review-fixes/spec.md`
- Tasks: `.qoder/specs/code-review-fixes/tasks.md`
- Checklist: `.qoder/specs/code-review-fixes/checklist.md`
- Notify Spec: `.qoder/specs/notify-control-center/spec.md`
- Notify Tasks: `.qoder/specs/notify-control-center/tasks.md`
- Notify Checklist: `.qoder/specs/notify-control-center/checklist.md`

## 你要改的文件（已完成）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| src/lib/auth.ts | MODIFIED | JWT_SECRET 生产环境强校验（缺密钥 throw Error） |
| src/lib/farm-server-client.ts | MODIFIED | createQWeatherJwt() 占位签名校验 + audit |
| src/lib/llm.ts | DELETED | 死代码 |
| src/lib/llm/index.ts | MODIFIED | 新增 h5Llm 导出 |
| src/app/api/h5/production-plan/variety-recommend/route.ts | MODIFIED | import 路径更新 |
| src/app/api/h5/production-plan/land-analysis/route.ts | MODIFIED | import 路径更新 |
| src/app/api/h5/production-plan/cost-accounting/route.ts | MODIFIED | import 路径更新 |
| src/caijuehub/strategies/auth-gateway.ts | MODIFIED | 去除 extractTokenFromRequest 重复定义 |
| src/agents/index.ts | MODIFIED | activeTracers 30min TTL + trapCreateTimes |
| src/lib/agent-audit-logger.ts | MODIFIED | ADD-4 三通道 + 企微群告警 (sendWecomAlert) |
| src/lib/wecom-notify.ts | CREATED → MODIFIED | 企微兼容层：re-export sendAlert |
| src/lib/notify/types.ts | CREATED | NotifyAlert / NotifyChannel 接口 |
| src/lib/notify/channels/wecom.ts | CREATED | 企微 NotifyChannel（webhook 逻辑迁移） |
| src/lib/notify/channels/dingtalk.ts | CREATED | 钉钉骨架（enabled=false） |
| src/lib/notify/channels/feishu.ts | CREATED | 飞书骨架（enabled=false） |
| src/lib/notify/control.ts | CREATED | sendAlert() fan-out 控制中心 |
| src/lib/notify/index.ts | CREATED | 统一 re-export |
| scripts/test-wecom-notify.ts | MODIFIED | 改用 sendAlert + fan-out 显示 |
| .env.example | MODIFIED | 新增 DINGTALK/FEISHU 环境变量 |
| .env.development | MODIFIED | 同上（注释状态） |
| src/lib/chroma.ts | DELETED | 与 chroma-client.ts 重复，已删除 |
| src/app/api/document/[id]/vectorize/route.ts | MODIFIED | 改用 DirectChromaClient |
| tests/test-chroma-auth.ts | MODIFIED | chromadb npm 包 → DirectChromaClient |
| tests/test-chroma-new-api.ts | MODIFIED | chromadb npm 包 → DirectChromaClient |
| package.json | MODIFIED | chromadb: deps → devDeps |

## 核心设计

无架构变更。全部为局部安全/健壮性加固。

## 关键契约细化

1. **JWT_SECRET**: 生产环境 (`NODE_ENV=production`) 缺失时模块加载即 throw Error，拒绝启动
2. **QWeather JWT**: `createQWeatherJwt()` 签名仍为 `"PLACEHOLDER_SIGNATURE"` 时 throw + audit，不再静默返回无效 token
3. **LLM 模块统一**: `src/lib/llm/index.ts` 为唯一入口，`src/lib/llm.ts` 已删除，`h5Llm` 已迁移
4. **extractTokenFromRequest**: 唯一定义在 `src/lib/auth.ts`，`auth-gateway.ts` 从那里导入
5. **activeTracers TTL**: 30 分钟过期，`startChainTrace()` 入口执行 `cleanupExpiredTracers()`
6. **审计失败可观测 + 通知控制中心**:
   - `writeAuditLog()` DB 写入失败 → `agentAudit("AUDIT_LOG_WRITE_FAIL")`（ADD-4 三通道：console + file）
   - 文件通道失败 → `console.error` + `auditLogFileWriteFailCount` 独立计数器
   - 每 100 次 DB 失败 → `sendAlert()` fan-out 到所有已启用通知渠道（当前仅企微）
   - **通知控制中心架构** (`src/lib/notify/`): 新增钉钉/飞书只需实现 `NotifyChannel` 接口 + 注册到 `notifyChannels` 数组
   - 暴露 `getAuditLogWriteFailCount()` / `getAuditLogFileWriteFailCount()` / `getWecomSendFailCount()` 供外部 metric 采集
   - `AgentAuditPhase` 新增 `"AUDIT_LOG_WRITE_FAIL"` 字面量

7. **Chroma 客户端统一** (#4):
   - 删除 `src/lib/chroma.ts`（chromadb npm 包封装）
   - `vectorize/route.ts` 改用 `DirectChromaClient`（原生 fetch，0 依赖）
   - `test-chroma-auth.ts` / `test-chroma-new-api.ts` 改用 `DirectChromaClient`
   - `chromadb` 从 `dependencies` 移至 `devDependencies`（4 遗留脚本仍需）
   - 运行时不再依赖 `chromadb` npm 包

## 高风险误区

- 不要重新引入 `src/lib/llm.ts`
- 不要在 auth-gateway.ts 重新定义 extractTokenFromRequest
- QWeather EdDSA 签名仍为占位符——只是现在会 throw 而不是静默失败

## 恢复上下文审计查询

```
# 按文件查询
keyword: "auth.ts" AND action: "COMPONENT_MODIFIED"

# 按 plan 查询
keyword: "code-review-fixes"

# 一键恢复
keyword: "JWT_SECRET" OR "PLACEHOLDER_SIGNATURE" OR "activeTracers" OR "auditLogWriteFailCount" OR "extractTokenFromRequest"
```

## 验证标准

### 已完成验证
- [x] `npx tsc --noEmit` 通过
- [x] 旧 `llm.ts` 已删除
- [x] 无残留 `@/lib/llm"` 引用

### 未执行的端到端验证
- [ ] 生产环境启动验证（需要 `NODE_ENV=production` 环境）
- [ ] QWeather API 实际调用验证
- [ ] 审计失败计数器实际触发验证

## 完成后记录 ADD-7 审计

- src/lib/auth.ts: COMPONENT_MODIFIED (JWT_SECRET 生产校验)
- src/lib/farm-server-client.ts: COMPONENT_MODIFIED (QWeather 占位签名防护)
- src/lib/llm.ts: COMPONENT_DELETED
- src/lib/llm/index.ts: COMPONENT_MODIFIED (h5Llm 导出)
- src/caijuehub/strategies/auth-gateway.ts: COMPONENT_MODIFIED (去重)
- src/agents/index.ts: COMPONENT_MODIFIED (activeTracers TTL)
- src/lib/agent-audit-logger.ts: COMPONENT_MODIFIED (失败计数器 + 企微告警)
- src/lib/chroma.ts: COMPONENT_DELETED
- src/app/api/document/[id]/vectorize/route.ts: COMPONENT_MODIFIED (DirectChromaClient 迁移)
- package.json: BUILD_CONFIG_CHANGED (chromadb: deps → devDeps)
- src/lib/notify/types.ts: FILE_CREATED (NotifyAlert / NotifyChannel / ChannelSendResult)
- src/lib/notify/channels/wecom.ts: FILE_CREATED (企微 channel)
- src/lib/notify/channels/dingtalk.ts: FILE_CREATED (钉钉骨架)
- src/lib/notify/channels/feishu.ts: FILE_CREATED (飞书骨架)
- src/lib/notify/control.ts: FILE_CREATED (sendAlert fan-out)
- src/lib/notify/index.ts: FILE_CREATED (统一 re-export)
- src/lib/wecom-notify.ts: FILE_MODIFIED (兼容层)
- src/lib/agent-audit-logger.ts: FILE_MODIFIED (sendWecomAlert → sendAlert)
- scripts/test-wecom-notify.ts: FILE_MODIFIED (sendAlert + fan-out)
