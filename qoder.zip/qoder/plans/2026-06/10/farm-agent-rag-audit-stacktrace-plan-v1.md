# Plan: 能力专家全量注册 + RAG 链路加固 + API 契约治理

> **来源**: [runtime-review-v2 §5.6-a](../reviews/farm-agent-agrisynapse-integration-runtime-review-v2.md#56-a-rag-可靠性加固--审计--根因--专家注册)
- **修订记录**
- 2026-06-09: 初版，review2 运行时验证触发
- 2026-06-09: **修订v2**——Task 1 扩展：从补 1 个 weather_impact → 补全 Dashboard 全部 9 个神经元（实际新增 8 个专家）
- 2026-06-09: **修订v3**——§2.4 新增三层能力模型架构（业务域→能力专家→能力卡片）。ExpertDomain 从旧 7 值（种植|经济|管收|气象|营养|作业|报告）重新定义为 6 值（耕|种|管|收|巡检|跨域），严格对齐《规划说明书》。专家分为核心专家 + 汇总专家（isSummary），domain 全部按规划说明书审计重新映射。
- 2026-06-09: **修订v4**——§2.4 新增数据溯源链（00-需求→神经元原型→farm-agent API→GUI）、API契约层（对接方配置入口）、caijue.toml裁决映射要求。新增 Task 4（API契约收敛 + caijue.toml更新）。明确 caijuehub 只管 agent 层裁决，API契约层归对接方管理。
- 2026-06-09: **修订v5**——标题从「RAG可靠性加固」更名为「能力专家全量注册 + RAG链路加固 + API契约治理」（反映完整 scope）。核心专家统一 `isSummary: false` 显式声明。术语修正：复合专家→汇总专家（isComposite→isSummary），汇总专家本质是汇总报告生成器，无编排机制。§4 补 ChromaDB 回滚风险分析。
- 2026-06-09: **修订v6**——明确区分「汇总专家」与「混合专家」两个独立概念。汇总专家（isSummary: true）= 视图聚合（daily_report/weekly_report），拼接各核心专家独立报告的章节。混合专家 = 工作流编排 + 奥卡姆剃刀裁剪，在当前农业 agent 中增益有限，仅 roi_analysis 跨域场景可能有价值，属未来概念。
- 2026-06-09: **修订v7**——新增 Task 5：裁决层检索预算集中化（retrievalBudget）。将 topK / contentSlice 从节点硬编码上升为裁决层策略决策，SubIntentExecutionPlan 新增 retrievalBudget 字段。理由：裁决层已知激活专家数和 domain 重叠度，应控制检索预算（token 经济治理）。
- 2026-06-09: **修订v8**——新增 §0 与 Expert Grounding Plan 的职责边界与衔接说明。明确本 Plan 只做降级路径加固（合并查 + cateId 分档 + 动态 topK），Grounding Plan 负责 per-collection 检索。`evidence[i].expertIds` → `evidence[i].grounding` 字段平滑升级路径可追溯。
- 2026-06-09: **修订v9**——Task 3 从纯审计快照扩展为「证据归属结构化分档」。新增 `Evidence.expertIds` + `EvidenceRef.expertIds` 字段；retrieval 阶段在合并查询后按 `knowledgeCateId` 映射出 `expertIds` 打标；reasoning 阶段按 `expertIds` 分组喂给 LLM。解决合并查询扁平结果无法区分哪个证据属于哪个专家的问题。

## PLAN 元信息

- **启动时间**: 2026-06-09
- **关联文档**:
  - Review: `.qoder/reviews/farm-agent-agrisynapse-integration-runtime-review-v2.md` §5.6（上游触发）
  - 崩溃修复: `src/services/knowledge-indexer.ts` 第 209-210 行（`where` 防 undefined，已提交）
  - Spec: `.qoder/specs/farm-agent-rag-audit-stacktrace/spec.md`
  - Tasks: `.qoder/specs/farm-agent-rag-audit-stacktrace/tasks.md`
  - Checklist: `.qoder/specs/farm-agent-rag-audit-stacktrace/checklist.md`
  - Handoff: `.qoder/plans/farm-agent-rag-audit-stacktrace-handoff-v1.md`
  - Grounding Plan: `.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md`（per-collection 检索基础设施，§3.3 降级路径）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState |
|------|-----------|--------|------------|------------|
| `src/agents/experts/registry.ts` | EXPERT_REGISTRY | MODIFY | 3 个专家（crop_compare / roi_analysis / pest_risk），ExpertDomain 仅"种植\|经济\|管收" | 11 个专家（+6核心+2汇总），ExpertDomain 重定义为 6 值（耕|种|管|收|巡检|跨域），按§2.4三层架构审计映射 | ✅ 已 specs |
| `src/services/knowledge-indexer.ts` | SERVICE | MODIFY | `RAG_SEARCH_FAIL` 仅记 `error.message` | 补 `error.stack` 前3帧 | ✅ 已 specs |
| `src/agents/nodes/retrieval.ts` | NODE | MODIFY | 无决策快照日志 | 记 `activeExpertIds` + `expertWhere` + cateId→expertId 分档；`evidence[i].expertIds` 打标 | ✅ 已 specs |
| `src/agents/nodes/reasoning.ts` | NODE | MODIFY | EvidenceRef 无 expertIds，证据扁平喂 LLM | EvidenceRef.expertIds 填充 + 按 expertIds 分组上下文 | ✅ 已 specs |
| `src/types/evidence.ts` | TYPE | MODIFY | Evidence / EvidenceRef 无 expertIds | Evidence.expertIds?: string[] + EvidenceRef.expertIds?: string[] | ✅ 已 specs |
| `src/api/agent/contracts/dashboard-contract.ts` | API_CONTRACT | CREATE | 不存在 | 从 route.ts 收敛 SkillCards + Topics | ✅ 已 specs |
| `src/app/api/agent/[hash]/route.ts` | API_ROUTE | MODIFY | 内联 DASHBOARD_SKILL_CARDS + RECOMMENDED_TOPICS | 改为 import from contracts | ✅ 已 specs |
| `src/caijuehub/caijue.toml` | DECISION_REGISTRY | MODIFY | 无 isSummary/ExpertDomain/contract 条目 | +3 新增 +2 更新 | ✅ 已 specs |
| `src/caijuehub/strategies/sub-intent.ts` | STRATEGY | MODIFY | SubIntentExecutionPlan 无检索预算字段 | 新增 retrievalBudget（topK + contentSlice），裁决层集中控制检索 token 经济 | ✅ 已 specs |

---

## 0. 与 Expert Grounding Plan 的职责边界与衔接

> **关联 Plan**: [Expert Grounding RAG 适配 Plan](../plans/farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md)

### 0.1 职责划分

| | 本 Plan | Expert Grounding Plan |
|---|---|---|
| **定位** | 降级路径的结构化加固 | per-collection 检索基础设施建设 |
| **检索方式** | 全局 collection + evidenceFilter 合并查 | per-expert collection 独立检索 |
| **何时生效** | 所有专家（Grounding Plan 未完成时）/ `grounding.ready()=false` 的专家 | `grounding.ready()=true` 的专家 |
| **证据归属** | 合并查询后置 cateId→expertId 映射，`evidence[i].expertIds: string[]` | per-collection 检索天然归属，`evidence[i].grounding: GroundingStatus` |
| **topK 控制** | 裁决层 `retrievalBudget.topK` 动态计算 | per-collection 无需竞争 |

### 0.2 衔接机制

```
Grounding Plan §3.3 降级路径
                    ┌───────────────────────────────────┐
激活专家 →          │  grounding.ready()                │
                    │  ├─ ready=true → per-collection   │  ← Grounding Plan 负责
                    │  │   expert_pest_risk collection   │    证据天然归属
                    │  │                                │
                    │  ├─ ready=false → 降级路径        │  ← 本 Plan 负责
                    │  │   合并查 + evidenceFilter       │    evidence[i].expertIds 打标
                    │  │   + retrievalBudget 动态 topK   │    retrievalBudget 控制预算
                    │  │   + RETRIEVAL_DECISION 审计     │    审计快照
                    │  └────────────────────────────────┘
                    │
                    │  两条路径的证据在 reasoning 汇合
                    ↓
             reasoning → verdict → response
```

### 0.3 字段平滑升级

```
本 Plan（降级路径）              Grounding Plan（per-collection）
────────────────────            ──────────────────────────
evidence[i] = {                 evidence[i] = {
  expertIds: ["pest_risk"]        grounding: {
                                   collectionName: "expert_pest_risk",
                                   groundingStatus: "anchored",
                                   retrievedVia: "collection_search"
                                 }
                                 // expertIds 不再需要，由 grounding 替代
}
```

Grounding Plan 实施时，`expertIds` 字段无需删除——降级路径上的专家继续使用，per-collection 路径上的专家使用 `grounding`。两条路径的 evidence 在 reasoning 节点统一消费：按 `expertIds` 或 `grounding.collectionName` 分组喂给 LLM。

### 0.4 原子边界

| 边界 | 本 Plan 不碰 | 理由 |
|------|-------------|------|
| ChromaDB per-collection 创建 | ❌ | Grounding Plan Phase 1 |
| `AnalysisExpert.grounding` 字段 | ❌ | Grounding Plan Phase 2 |
| `searchKnowledgeDocuments(collectionName)` 签名扩展 | ❌ | Grounding Plan Phase 3 |
| per-collection 文档迁移脚本 | ❌ | Grounding Plan Phase 1 |
| `grounding.ready()` 健康检查逻辑 | ❌ | Grounding Plan Phase 2 |

| 边界 | Grounding Plan 不碰 | 理由 |
|------|---------------------|------|
| evidenceFilter 合并查询 | ❌ | 本 Plan 降级路径基线 |
| cateId→expertId 后置分档 | ❌ | 本 Plan Task 3 |
| retrievalBudget 动态 topK | ❌ | 本 Plan Task 5 |
| ExpertDomain 重定义 + 专家注册 | ❌ | 本 Plan Task 1 |

### 0.5 降级路径演进

```
阶段 1（本 Plan 完成后）：
  全部 11 个专家 → 合并查 + cateId 分档 + 动态 topK

阶段 2（Grounding Plan 渐进迁移中）：
  pest_risk  → grounding.ready()=true → per-collection
            → grounding.ready()=false → 降级路径（本 Plan 加固后）
  crop_compare → grounding.ready()=false → 降级路径（本 Plan 加固后）
  ...

阶段 3（Grounding Plan 全部完成后）：
  全部 11 个专家 → per-collection
  降级路径 → 保留为永久 fallback
```

---

## 1. 问题概述

用户提问"最近天气对玉米生长有什么影响？"时，RAG 检索环节因代码 crash 返回空数组，LLM 在无证据的情况下凭空生成回答。

**崩溃链路**：

```
用户提问 → intention: intent=analysis, subIntents=["pest_risk"]
         → pest_risk ∈ ANALYSIS_EXPERTS ✓，但 activeExpertIds=[]（专家未激活）
         → retrieval: expertWhere = mergeExpertEvidenceFilters([]) = undefined
         → searchKnowledgeDocuments(query, 5, undefined, undefined)
         → knowledge-indexer.ts: where = undefined
         → JSON.stringify(undefined).slice(0, 60) → TypeError
         → catch 块返回 []，记 RAG_SEARCH_FAIL（仅 error.message，无 stack trace）
         → RAG_EMPTY 误报"知识库无相关文档"
         → LLM 零证据凭空回答
```

**已修复（代码层）**：`knowledge-indexer.ts` 第 209-210 行 `const where = rawWhere ?? {}`，保证 `where` 始终为对象。

**本 plan 覆盖**：根因消除 + 审计加固，从链路三个环节防止复发。

## 2. 根因分析

### 2.1 触发条件：神经元缺专家（规划层系统性遗漏）

`integration-plan-v1` 清点了 23 个工具（含 3 个天气工具），但未审计专家层。Task 0-9 无一个涉及 `ANALYSIS_EXPERTS` 扩展。

**agrisynapse Dashboard 定义了 9 个神经元（Skill Cards）**，对应 `src/app/api/agent/[hash]/route.ts` 中 `DASHBOARD_SKILL_CARDS`：

| Dashboard 神经元 | 现有专家 | 缺口 |
|-----------------|---------|------|
| `daily_report`（农情日报） | ❌ | 新增 |
| `weekly_report`（周报分析） | ❌ | 新增 |
| `growth_report`（生长报告） | ❌ | 新增 |
| `pest_detect`（病虫害识别） | pest_risk ✅ | — |
| `nutrition_diagnose`（营养诊断） | ❌ | 新增 |
| `weather_impact`（天气影响） | ❌ | 新增 |
| `work_plan`（作业规划） | ❌ | 新增 |
| `planting_advice`（种植建议） | ❌ | 新增 |
| `machinery_dispatch`（农机调度） | ❌ | 新增 |

**9 个神经元中 8 个缺专家**。当前 `ANALYSIS_EXPERTS` 仅有 3 个专家（crop_compare/roi_analysis/pest_risk），且 crop_compare 和 roi_analysis 不在 Dashboard 上（其他入口可能用到，保留）。

本次崩溃只是冰山一角——用户问"天气对玉米生长影响"恰好触发了 weather_impact 这条缺失路径。但 nutrition_diagnose、growth_report 等同样会在对应场景触发同类 crash。

### 2.2 传播条件：undefined 透传（Plan 第4轮副作用）

`retrieval.ts` Plan 第4轮新增 `expertWhere` 参数透传：`mergeExpertEvidenceFilters([])` 返回 `undefined`，未做防御。

### 2.3 诊断条件：审计盲区（已有缺陷）

`RAG_SEARCH_FAIL` 仅记 `error.message`，无 `error.stack`。`catch` 块吞异常后正常结束，审计记录 `✔ retrieval`，运维无法定位崩溃位置。

### 2.4 架构设计基础：三层能力模型

> **审计依据**：《大田精准耕播智能决策系统规划说明书》四·农业作业规划（耕种管收巡检）+ 五·经济要素联动

#### 第一层：业务域（ExpertDomain）— 5 核心 + 跨域

来源：《规划说明书》第一层架构图 `← 农业5大业务`

```
ExpertDomain = "耕" | "种" | "管" | "收" | "巡检" | "跨域"
```

| 域 | 定义 | 规划说明书章节 |
|----|------|--------------|
| **耕** | 土地准备、耕作作业 | 四·4.1 耕地规划 |
| **种** | 播种、种植决策 | 三·作物选择推理 + 四·4.2 播种规划 |
| **管** | 生长管理、植保、营养 | 四·4.3 管理规划 |
| **收** | 收获作业 | 四·4.4 收获规划 |
| **巡检** | 巡田监测、设备巡检 | 四·4.5 巡检规划 |
| **跨域** | 贯穿多阶段或超越农业范畴的横向能力 | 五·经济要素联动（ROI）+ 全阶段农机调度 |

> **"跨域" 不是业务域**，而是规划说明书第二层「经济要素联动」在代码层的映射——ROI 超越农业范畴，是任何行为的经济考核。农机调度（machinery_dispatch）贯穿耕种管收巡检全部 5 个阶段，同样属于跨域。

#### 第二层：能力专家（ANALYSIS_EXPERTS）— 核心专家 + 汇总专家

**核心专家**（`isSummary: false` 显式声明）：有独立 RAG 管线（evidenceFilter + promptTemplate）

| 专家 ID | label | domain | 规划说明书映射 |
|---------|-------|--------|--------------|
| `crop_compare` | 作物对比分析 | **种** | 三·3.1 候选作物对比 |
| `planting_advice` | 种植建议 | **种** | 四·4.2 播种规划 |
| `pest_risk` | 病虫害风险评估 | **管** | 四·4.3 管理规划 |
| `weather_impact` | 气象影响分析 | **管** | 四·4.3 管理规划 |
| `nutrition_diagnose` | 营养诊断 | **管** | 四·4.3 管理规划 |
| `growth_report` | 生长报告 | **管** | 四·4.3 管理规划 |
| `roi_analysis` | ROI 投资回报分析 | **跨域** | 五·5.3 ROI/回收周期 |
| `work_plan` | 作业规划 | **跨域** | 四·全章 |
| `machinery_dispatch` | 农机调度 | **跨域** | 四·全章，各阶段不同农机 |

**汇总专家**（`isSummary: true`）：无独立 evidenceFilter，promptTemplate 为汇总模板，将各核心专家的独立报告按章节拼接为总报告

| 专家 ID | label | domain | 汇总哪些核心专家的章节 |
|---------|-------|--------|-----------------|
| `daily_report` | 农情日报 | **跨域** | weather_impact + growth_report + pest_risk + machinery_dispatch 等 |
| `weekly_report` | 周报分析 | **跨域** | 同上 + roi_analysis（趋势 + 经济） |

> **类型扩展**：`AnalysisExpert` 接口新增 `isSummary?: boolean` 字段。汇总专家无独立 evidenceFilter，其 promptTemplate 指示 LLM 按章节汇总各核心专家的独立报告。管线无需感知 isSummary——SubIntent 拆解 + 专家匹配 + 合并检索/推理 = 链路天然通畅。

> **概念区分**：汇总专家 ≠ 混合专家。汇总专家是视图聚合（拼接已有报告章节）；混合专家是工作流编排器（边界桥接 + 优先级识别 + 奥卡姆剃刀裁剪），在当前农业 agent 中增益有限，仅 roi_analysis 跨域场景可能有价值，属未来概念。

#### 第三层：能力卡片（Dashboard SkillCard）— 用户入口

Dashboard 能力卡片 ⊂ ANALYSIS_EXPERTS（前端精选展示 ⊂ 后端完整能力池）

| SkillCard id | 映射专家 | 专家类型 |
|-------------|---------|----------|
| `daily_report` | `daily_report` | 汇总 |
| `weekly_report` | `weekly_report` | 汇总 |
| `growth_report` | `growth_report` | 核心 |
| `pest_detect` | `pest_risk` | 核心 |
| `nutrition_diagnose` | `nutrition_diagnose` | 核心 |
| `weather_impact` | `weather_impact` | 核心 |
| `work_plan` | `work_plan` | 核心（跨域） |
| `planting_advice` | `planting_advice` | 核心 |
| `machinery_dispatch` | `machinery_dispatch` | 核心（跨域） |

#### 架构全景图

```
┌─── 第三层：能力卡片（Dashboard SkillCard，用户入口）─────────────┐
│  daily_report  weekly_report  growth_report  pest_detect  ...    │
│       │              │             │             │               │
│       ▼              ▼             ▼             ▼               │
├─── 第二层：能力专家（ANALYSIS_EXPERTS）──────────────────────────┤
│                                                                   │
│  核心专家（有独立 RAG 管线）     汇总专家（汇总报告，无独立 evidenceFilter）│
│  ┌──────────────────────┐    ┌───────────────────────────────┐   │
│  │ crop_compare    (种)  │    │ daily_report  (跨域, 汇总报告) │   │
│  │ planting_advice (种)  │    │ weekly_report (跨域, 汇总报告) │   │
│  │ pest_risk       (管)  │    │ work_plan     (跨域)          │   │
│  │ weather_impact  (管)  │    │ machinery_dispatch (跨域)     │   │
│  │ nutrition_diag  (管)  │    └───────────────────────────────┘   │
│  │ growth_report   (管)  │                                        │
│  │ roi_analysis    (跨域)│                                        │
│  └──────────────────────┘                                         │
│                                                                   │
├─── 第一层：业务域（ExpertDomain，规划说明书定义）──────────────────┤
│  ┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐          │
│  │ 耕  │  │ 种  │  │ 管  │  │ 收  │  │巡检 │  │跨域 │          │
│  └─────┘  └─────┘  └─────┘  └─────┘  └─────┘  └─────┘          │
│  ← 农业5大核心业务（规划说明书） →    ← 经济要素联动 →          │
└───────────────────────────────────────────────────────────────────┘
```

#### 数据溯源链：需求文档 → 原型 → API 契约 → GUI

> 产品未出货期间，神经元前端虚拟了几个能力卡片作为原型，farm-agent 编码时参考了虚拟定义，因提供 API 给 GUI，将定义收敛到后端。真正的权威来源始终是 00-需求文档。

```
00-需求文档（《规划说明书》《PRD》等）   ← 权威来源 / source of truth
    │
    │  产品初期，神经元前端虚拟了几个能力卡片（原型 demo）
    ▼
agrisynapse 神经元前端（虚拟原型，先跑起来）
    │
    │  farm-agent 编码时参考神经元前端定义
    │  因 farm-agent 提供 API 给 GUI，定义收敛到 API 契约层
    ▼
farm-agent API 契约层（src/api/agent/contracts/）  ← 定义收敛点
    │
    │  GET dashboard API
    ▼
agrisynapse Dashboard 渲染（纯消费方）
```

**溯源原则**：新增/修改专家、SkillCard、RecommendedTopic 时，必须回溯到 00-需求文档审计，禁止仅参考神经元前端虚拟定义。

#### API 契约层：对接方配置入口

farm-agent 对每个对接方（GUI / 其他 agent）提供独立的 API 契约定义，不散落在 route.ts 内联常量中。

```
src/api/agent/
├── contracts/                       ← API 契约定义层
│   ├── dashboard-contract.ts        ← agrisynapse GUI 的契约
│   │   ├── DASHBOARD_SKILL_CARDS    (9个 SkillCard)
│   │   └── RECOMMENDED_TOPICS       (4个推荐话题)
│   └── (future-agent-contract.ts)   ← 未来其他 agent 的契约
├── [hash]/
│   └── route.ts                     ← import from contracts，不再内联
```

**职责边界**：

| 层 | 管什么 | 不管什么 |
|----|---------|----------|
| caijuehub | agent 内部裁决（路由/策略/上下文） | GUI 展示什么卡片 |
| API 契约层 | 对外暴露什么（SkillCards + Topics） | agent 内部如何路由 |
| GUI 层 | 渲染什么（消费 API 契约） | 定义能力 |

#### caijue.toml 裁决映射要求

> 裁决映射集中、裁决实现就近——caijue.toml 是决策全景图，不管实现代码在哪，都能从一个文件追溯所有决策。

本次需更新/新增的 caijue.toml 条目：

| 操作 | caijue id | type | 内容 |
|------|-----------|------|------|
| 更新 | `resolve-sub-intent-plan` | strategy | 标注 isSummary 感知：汇总专家无独立 subIntent，展开为章节引用 |
| 更新 | `merge-expert-evidence-filters` | context | 汇总专家无 evidenceFilter，跳过合并 |
| 新增 | `resolve-expert-domain` | context | ExpertDomain 6 值定义（对齐规划说明书） |
| 新增 | `resolve-dashboard-contract` | contract | API 契约定义：Dashboard SkillCards + RecommendedTopics（指向 contracts/） |
| 新增 | `resolve-retrieval-budget` | strategy | 检索预算裁决：topK / contentSlice 按激活专家数动态计算，节点消费 plan.retrievalBudget |

---

## 3. 修复方案（5 Tasks）

### Task 1: 补全 Dashboard 神经元专家注册（根因消除）

**目标**：按 §2.4 三层能力模型，补全全部 ANALYSIS_EXPERTS，从源头消除“神经元无专家”触发 `expertWhere=undefined` 的路径。

**改动文件**：`src/agents/experts/registry.ts`

**步骤**：

1. 重写 `ExpertDomain` 类型联合（对齐规划说明书）：
   ```typescript
   export type ExpertDomain = "耕" | "种" | "管" | "收" | "巡检" | "跨域"
   ```

2. `AnalysisExpert` 接口新增字段：
   ```typescript
   isSummary?: boolean  // true = 汇总专家，无独立 evidenceFilter，汇总各核心专家报告章节
   ```

3. **现有 3 个专家 domain 重新映射**（对齐新业务域）：

| 专家 ID | 旧 domain | 新 domain | 依据 |
|---------|----------|----------|------|
| `crop_compare` | "种植" | **种** | 三·3.1 候选作物对比 |
| `roi_analysis` | "经济" | **跨域** | 五·经济要素联动（ROI 超越农业范畴） |
| `pest_risk` | "管收" | **管** | 四·4.3 管理规划 |

4. **新增 6 个核心专家**（`isSummary: false` 显式声明）：

| 专家 ID | label | domain | evidenceFilter cateId |
|---------|-------|--------|----------------------|
| `weather_impact` | 气象影响分析 | **管** | `["weather","agri_tech"]` |
| `nutrition_diagnose` | 营养诊断 | **管** | `["agri_tech","planting_technique"]` |
| `growth_report` | 生长报告 | **管** | `["planting_technique","agri_tech"]` |
| `planting_advice` | 种植建议 | **种** | `["planting_technique","agri_tech"]` |
| `work_plan` | 作业规划 | **跨域** | `["agri_tech","weather"]` |
| `machinery_dispatch` | 农机调度 | **跨域** | `["agri_tech"]` |

> 核心专家保留完整属性：id/label/domain/description/inputSchema/outputSections/promptTemplate/evidenceFilter/reportFormats/defaultReportFormat。所有核心专家显式声明 `isSummary: false`（禁止省略，避免 truthy/falsy 判断歧义）。promptTemplate 内容见 §2.4 第二层。

5. **新增 2 个汇总专家**（`isSummary: true`，无独立 evidenceFilter）：

```typescript
daily_report: {
  id: "daily_report",
  label: "农情日报",
  domain: "跨域",
  description: "汇总当日农场各项独立报告，按章节拼接为农情日报总报告",
  isSummary: true,
  inputSchema: [
    { key: "date", label: "日期", required: false },
    { key: "farm_area", label: "农场区域", required: true },
  ],
  outputSections: ["conclusion", "evidence", "reasoning", "confidence"],
  promptTemplate: `你是农情日报生成专家...汇总维度：气象数据/作物生长/农事作业/预警信息/明日建议`,
  // 无 evidenceFilter，汇总模板指示 LLM 按章节拼接各核心专家报告
  reportFormats: ["md", "pdf"],
  defaultReportFormat: "md",
},

weekly_report: {
  id: "weekly_report",
  label: "周报分析",
  domain: "跨域",
  description: "汇总一周农场各项独立报告，按章节拼接为农情周报总报告",
  isSummary: true,
  inputSchema: [
    { key: "week_range", label: "周范围", required: false },
    { key: "farm_area", label: "农场区域", required: true },
  ],
  outputSections: ["conclusion", "evidence", "reasoning", "confidence", "risk", "action_steps"],
  promptTemplate: `你是农情周报分析专家...分析维度：周度趋势/同比环比/异常检测/下周建议/资源需求预估`,
  // 无 evidenceFilter，汇总模板指示 LLM 按章节拼接各核心专家报告
  reportFormats: ["md", "pdf"],
  defaultReportFormat: "md",
},
```

**验证**：
- `Object.keys(ANALYSIS_EXPERTS).length === 11`（3 domain 重映射 + 6 核心新增 + 2 汇总新增）
- `ExpertDomain` 值 = `"耕" | "种" | "管" | "收" | "巡检" | "跨域"`
- Dashboard 9 个 SkillCard id 全部 ∈ `Object.keys(ANALYSIS_EXPERTS)`
- 汇总专家 `isSummary: true`，无 `evidenceFilter`
- 核心专家 `isSummary: false`（显式声明），有独立 `evidenceFilter`
- `availableExpertDomains` 自动扩展为 11 个 → intention prompt 可感知所有神经元
- 用户点 Dashboard 任意神经元 → intention 可匹配 → activeExpertIds 非空 → expertWhere 非 undefined

### Task 2: RAG_SEARCH_FAIL 补 stack trace（平衡点）

**目标**：一行日志定位崩溃位置。stack trace 是诊断信息的平衡点——代码本身就是最好的上下文。

**改动文件**：`src/services/knowledge-indexer.ts` 第 274-280 行 catch 块

```typescript
// 当前（仅 error.message）：
agentAudit("RAG_SEARCH_FAIL", `查询失败: ${query}`, {
  error: error instanceof Error ? error.message : String(error),
})

// 目标（补 stack 前3帧）：
agentAudit("RAG_SEARCH_FAIL", `查询失败: ${query}`, {
  error: error instanceof Error ? error.message : String(error),
  stack: error instanceof Error
    ? (error.stack ?? "").split("\n").slice(1, 4).join("\n")
    : undefined,
})
```

**对标 Spring Boot**：`log.error("msg", e)` 默认带完整异常链 + stack trace。当前 `error.message` 相当于 Spring Boot 里写 `log.error("查询失败: {}", e.getMessage())`——丢了最有价值的诊断信息。

**验证**：
- 模拟 ChromaDB 连接失败 → 审计日志包含 `stack` 字段
- stack 前3帧可定位到具体文件和行号

### Task 3: retrieval 决策快照 + 证据归属结构化分档

**目标**：合并查询结果从扁平数组变为带专家归属的结构化证据链，解决「合并查回来的文档不区分哪个文档属于哪个专家」的问题。三步：cateId→expertId 反向映射构建 → evidence.expertIds 打标 → reasoning 按 expertIds 分组喂 LLM。

**当前问题**：`mergeExpertEvidenceFilters()` 合并所有专家的 `cateId.$in` 做一次 ChromaDB 查询，返回扁平 `knowledgeResults`。每条结果携带 `metadata.knowledgeCateId`，但代码未利用它做归属映射。`reasoning.ts` 把同一份证据列表发给所有专家，LLM 自己猜归属。

**改动文件**：

| 文件 | 操作 |
|------|------|
| `src/types/evidence.ts` | `Evidence` + `EvidenceRef` 接口各新增可选 `expertIds?: string[]` |
| `src/agents/nodes/retrieval.ts` | 构建 cateId→expertId 反向映射 + 证据打标 + `RETRIEVAL_DECISION` 审计 |
| `src/agents/nodes/reasoning.ts` | `EvidenceRef.expertIds` 填充 + 按 expertIds 分组上下文注入 prompt |

**步骤**：

1. `Evidence` 接口新增字段（`src/types/evidence.ts`）：

```typescript
export interface Evidence {
  // ... 现有字段不变 ...
  /** 归属专家 ID 列表（检索阶段填充）。
   *  降级路径（合并查）：retrieval 节点按 cateId 映射后打标
   *  per-collection：天然归属，grounding 替代 expertIds（Grounding Plan 实施时） */
  expertIds?: string[]
}

export interface EvidenceRef {
  // ... 现有字段不变 ...
  /** 归属专家 ID 列表，reasoning 节点按此分组喂 LLM */
  expertIds?: string[]
}
```

2. retrieval 节点构建 cateId→expertId 反向映射（`retrieval.ts`）：

```typescript
// 在 mergeExpertEvidenceFilters 之后、遍历 knowledgeResults 之前
const cateIdToExpertIds = new Map<string, string[]>()
for (const active of activeExperts) {
  const expert = ANALYSIS_EXPERTS[active.expertId]
  if (!expert?.evidenceFilter?.cateId) continue
  for (const cateId of expert.evidenceFilter.cateId.$in) {
    if (!cateIdToExpertIds.has(cateId)) {
      cateIdToExpertIds.set(cateId, [])
    }
    cateIdToExpertIds.get(cateId)!.push(active.expertId)
  }
}
```

3. 证据构造循环中打标 `expertIds`（`retrieval.ts` 第 167 行 for 循环内）：

```typescript
for (const result of knowledgeResults) {
  // ... 现有构造逻辑 ...

  // ★新增: cateId → expertId 归属映射
  const knowledgeCateId = result.metadata?.knowledgeCateId as string | undefined
  const matchedExpertIds = knowledgeCateId
    ? (cateIdToExpertIds.get(knowledgeCateId) ?? [])
    : []

  evidenceChain.push({
    // ... 现有字段不变 ...
    expertIds: matchedExpertIds.length > 0 ? matchedExpertIds : undefined,
  })
}
```

4. retrieval 决策快照审计（紧接 `mergeExpertEvidenceFilters` 后）：

```typescript
const expertWhere = mergeExpertEvidenceFilters(activeExperts)
agentAudit("RETRIEVAL_DECISION", `检索决策: ${searchQuery}`, {
  activeExpertIds: activeExperts.map(e => e.id).join(",") || "(none)",
  expertWhere: expertWhere ? "defined" : "undefined",
  cateIdMapping: Object.fromEntries(cateIdToExpertIds),
})
```

5. reasoning 节点填充 `EvidenceRef.expertIds` + 按专家分组上下文（`reasoning.ts`）：

```typescript
// 填充 EvidenceRef.expertIds
const input: ReasoningInput = {
  query: currentTask.query,
  evidenceList: evidenceChain.map((e) => ({
    id: e.id,
    chunkId: e.chunkId,
    source: e.source,
    reliability: e.reliability,
    relevance: e.relevance,
    docName: typeof e.metadata.documentName === "string" ? e.metadata.documentName : undefined,
    contentExcerpt: e.content.slice(0, plan.retrievalBudget.contentSlice),
    expertIds: e.expertIds,  // ★新增
  })),
}

// 按 expertIds 分组上下文注入 prompt（在 buildAnalysisExpertContext 内或后续）
// 对每个激活专家，从 evidenceList 中筛选 expertIds 包含当前 expertId 的证据
// 注入到对应专家的分析上下文中
```

**cateId → expertId 映射关系**（确定性，无需反查）：

| cateId | 对应专家 |
|--------|---------|
| `weather` | weather_impact |
| `agri_tech` | weather_impact, nutrition_diagnose, growth_report, planting_advice, work_plan, machinery_dispatch |
| `planting_technique` | nutrition_diagnose, growth_report, planting_advice, crop_compare |
| `plant_protection` | pest_risk |
| `market_intel` | roi_analysis |

**注意**：这是**业务层增强**，cateId→expertId 的映射是证据链的结构化归属，不是基础设施日志。RETRIEVAL_DECISION 走业务审计通道（`agentAudit`）。

**验证**：
- 无专家激活时 → 审计日志可见 `activeExpertIds=(none), expertWhere=undefined`
- 有 weather_impact 激活 → `expertIds` 含 `["weather_impact"]`（weather cateId 匹配）
- 有 weather_impact + nutrition_diagnose 同时激活 → agri_tech 类型文档 `expertIds = ["weather_impact", "nutrition_diagnose"]`
- reasoning prompt 中按 `expertIds` 分组，每个专家只看到属于自己的证据
- `tsc --noEmit` 通过，`Evidence` 和 `EvidenceRef` 接口新增字段向后兼容（optional）

### Task 4: API 契约收敛 + caijue.toml 裁决映射更新（架构加固）

**目标**：将散落在 route.ts 内联的 SkillCards + RecommendedTopics 收敛到 API 契约层；同步更新 caijue.toml 裁决映射，使全部决策可追溯。

**改动文件**：

| 文件 | 操作 |
|------|------|
| `src/api/agent/contracts/dashboard-contract.ts` | 新增：从 route.ts 收敛 DASHBOARD_SKILL_CARDS + RECOMMENDED_TOPICS |
| `src/app/api/agent/[hash]/route.ts` | 改为 import from contracts |
| `src/caijuehub/caijue.toml` | 更新 2 条 + 新增 2 条裁决条目 |

**步骤**：

1. 新建 `src/api/agent/contracts/dashboard-contract.ts`，将 route.ts 中 DASHBOARD_SKILL_CARDS + RECOMMENDED_TOPICS 迁移至此，添加治理注释（指向 00-需求文档）

2. route.ts 改为 `import { DASHBOARD_SKILL_CARDS, RECOMMENDED_TOPICS } from "@/api/agent/contracts/dashboard-contract"`

3. caijue.toml 新增裁决条目：
   - `resolve-expert-domain`（context）：ExpertDomain 6 值定义
   - `resolve-dashboard-contract`（contract）：Dashboard API 契约定义

4. caijue.toml 更新现有条目：
   - `resolve-sub-intent-plan`：标注 isSummary 感知
   - `merge-expert-evidence-filters`：汇总专家无 evidenceFilter 跳过

5. 汇总专家无需独立策略文件——SubIntent 拆解 + 合并检索/推理 + 汇总 promptTemplate = 链路天然通畅

**验证**：
- route.ts 不再包含内联常量定义
- `GET dashboard` API 返回值不变（行为等价）
- caijue.toml 新增条目均可追溯到治理文档
- `tsc --noEmit` 通过

### Task 5: 裁决层检索预算集中化（token 经济治理）

**目标**：将 topK / contentSlice 从节点硬编码上升为裁决层策略决策，使裁决层获得对检索 token 经济的治理能力。

**问题**：当前 `retrieval.ts` 硬编码 `topK=5`，`reasoning.ts` 硬编码 `contentSlice=500`。裁决层（`sub-intent.ts`）已知激活专家数和 domain 重叠度，但不控制检索预算。资源分配决策绕过了裁决层。

**改动文件**：

| 文件 | 操作 |
|------|------|
| `src/caijuehub/strategies/sub-intent.ts` | SubIntentExecutionPlan 新增 retrievalBudget 字段 + resolveSubIntentPlan() 计算逻辑 |
| `src/agents/nodes/retrieval.ts` | topK 从硬编码 5 改为消费 plan.retrievalBudget.topK |
| `src/agents/nodes/reasoning.ts` | contentSlice 从硬编码 500 改为消费 plan.retrievalBudget.contentSlice |
| `src/caijuehub/caijue.toml` | 新增 `resolve-retrieval-budget` 裁决条目 |

**步骤**：

1. `SubIntentExecutionPlan` 接口新增：

```typescript
/** 检索预算（裁决层按激活专家数动态计算） */
retrievalBudget: {
  topK: number           // 检索槽位总数
  contentSlice: number   // 每条证据送入 LLM 的最大字符数
}
```

2. `resolveSubIntentPlan()` 内部计算：

```typescript
const expertCount = activateExpertIds.length
const topK = expertCount <= 1 ? 5 : Math.min(expertCount * 5, 20)
// 1专家=5, 2专家=10, 3专家=15, 4+专家=20封顶
const contentSlice = expertCount <= 2 ? 500 : 300
// 专家少时多给上下文，专家多时压缩单条防止 prompt 爆炸
```

3. `NULL_PLAN` 兜底值：

```typescript
retrievalBudget: { topK: 5, contentSlice: 500 }
```

4. 消费方改动：

```typescript
// retrieval.ts（当前）:
searchKnowledgeDocuments(searchQuery, 5, undefined, expertWhere)
// retrieval.ts（改为）:
searchKnowledgeDocuments(searchQuery, plan.retrievalBudget.topK, undefined, expertWhere)

// reasoning.ts（当前）:
contentExcerpt: e.content.slice(0, 500)
// reasoning.ts（改为）:
contentExcerpt: e.content.slice(0, plan.retrievalBudget.contentSlice)
```

5. caijue.toml 新增 `resolve-retrieval-budget`（strategy）：检索预算裁决——topK/contentSlice 按激活专家数动态计算

**算法临界点分析**：

| 场景 | 合并检索 topK=5 vs per-expert topK=5 | 收益差 |
|------|------|------|
| 1 个专家 | 完全相同 | 0 |
| 2 个专家，domain 重叠大 | 结果集高度重叠 | 极小 |
| 3+ 专家，domain 不相交 | 槽位竞争，某专家可能 0 条 | 显著 |
| topK=20+ | 槽位充足，竞争消解 | 趋近于 0 |

**结论**：当前农业 agent 单次查询通常激活 1-2 个专家，per-expert 独立检索收益不大。优先方案是 topK 动态扩容（本 Task），而非架构级 per-expert 检索重构。后者留给专家数真正增长时再做。

**验证**：
- 1 个专家激活 → plan.retrievalBudget.topK === 5
- 2 个专家激活 → plan.retrievalBudget.topK === 10
- 3 个专家激活 → plan.retrievalBudget.topK === 15
- 4+ 个专家激活 → plan.retrievalBudget.topK === 20（封顶）
- retrieval.ts 不再包含 topK 硬编码
- reasoning.ts 不再包含 contentSlice 硬编码
- `tsc --noEmit` 通过

---

## 4. 依赖与约束

- Task 1 独立，可先行（只改 registry.ts）
- Task 2 独立，可先行
- Task 3 独立，可先行（但推荐与 Task 1 同批：需 ANALYSIS_EXPERTS 就位后方可验证 cateId→expertId 映射完整性）
- Task 4 依赖 Task 1（route.ts import 路径需 registry.ts ExpertDomain 先就位），可与 Task 1 同批提交
- Task 5 依赖 Task 1（需激活专家数计算 topK），可与 Task 1 同批提交
- `ExpertDomain` 重定义为 6 值（耕|种|管|收|巡检|跨域）后，须确认 ChromaDB 中有对应 `cateId` 的数据（weather/agri_tech/planting_technique/market_intel 等），否则 evidenceFilter 命中为空 → 降级到无过滤检索（已有 RAG_EXPERT_FILTER_EMPTY 逻辑）
- 新增专家的 `outputSections` 成员必须是 `ResponseSectionType` 联合类型的子集，编译期即可验证
- 汇总专家（isSummary: true）无独立 evidenceFilter，其 promptTemplate 指示 LLM 按章节汇总各核心专家报告。管线无需感知 isSummary——现有 SubIntent + mergeExpertEvidenceFilters + buildAnalysisExpertContext 已覆盖全部场景
- 现有 3 个专家的 domain 字段需重新映射（crop_compare: "种植"→"种"，roi_analysis: "经济"→"跨域"，pest_risk: "管收"→"管"）
- API 契约层收敛后，route.ts 不再包含内联常量，改为 import from contracts
- caijue.toml 新增 `contract` 裁决类型（API 契约定义），需在文件头部类型注释中补充
- **Expert Grounding Plan 原子边界**：本 Plan 不碰 ChromaDB per-collection 创建、`AnalysisExpert.grounding` 字段、`searchKnowledgeDocuments(collectionName)` 签名扩展、per-collection 文档迁移脚本、`grounding.ready()` 健康检查逻辑——全部属于 Expert Grounding Plan（[§0.4](#04-原子边界)）。本 Plan 仅加固降级路径并产出 `evidence[i].expertIds` 字段，Grounding Plan 实施时平滑升级为 `evidence[i].grounding`

### ExpertDomain 重映射回滚风险分析

| 影响链 | ExpertDomain 是否参与 | 结论 |
|---------|----------------------|------|
| registry.ts 类型定义 | ✅ 代码层分类标签 | 仅重命名，无运行时影响 |
| ANALYSIS_EXPERTS 各专家 domain 字段 | ✅ 代码层分类标签 | 仅重命名，无运行时影响 |
| availableExpertDomains（intention prompt） | ✅ 拼入 prompt 文本 | intention 感知新的 6 值，功能正常 |
| ChromaDB `where` 过滤 | ❌ **不参与** | ChromaDB 用 `cateId`（如 weather/agri_tech），不用 ExpertDomain 值 |

**结论**：ExpertDomain 是代码层业务域分类，ChromaDB 查询用 `evidenceFilter.cateId`（如 `weather`/`agri_tech`/`planting_technique`），两者无耦合。domain 从旧 7 值重映射为新 6 值**不影响 ChromaDB 数据和检索**。唯一风险是新增专家的 `evidenceFilter.cateId` 在 ChromaDB 中尚无数据，但已有 `RAG_EXPERT_FILTER_EMPTY` 降级逻辑覆盖。

## 5. 验收标准

- [ ] `ANALYSIS_EXPERTS` 包含 11 个专家（3 domain 重映射 + 6 核心新增 + 2 汇总新增）
- [ ] Dashboard 9 个 SkillCard id 全部 ∈ `Object.keys(ANALYSIS_EXPERTS)`
- [ ] `ExpertDomain` 类型联合 = `"耕" | "种" | "管" | "收" | "巡检" | "跨域"`，严格对齐《规划说明书》
- [ ] 现有 3 个专家 domain 重映射完成（crop_compare→种，roi_analysis→跨域，pest_risk→管）
- [ ] 汇总专家（daily_report/weekly_report）标记 `isSummary: true`，无 evidenceFilter
- [ ] 核心专家（9个）有独立 evidenceFilter + promptTemplate
- [ ] 用户问“天气对玉米生长影响” → intention 匹配 weather_impact → activeExpertIds 非空
- [ ] 用户点 Dashboard 任意神经元 → intention 可匹配对应专家
- [ ] `RAG_SEARCH_FAIL` 审计日志包含 `stack` 字段（前3帧）
- [ ] retrieval 节点调用 searchKnowledgeDocuments 前有 `RETRIEVAL_DECISION` 审计记录
- [ ] `Evidence` 接口含 `expertIds?: string[]`，单专家激活时打标正确（weather cateId → ["weather_impact"]）
- [ ] `EvidenceRef` 接口含 `expertIds?: string[]`，reasoning prompt 按 expertIds 分组喂证据
- [ ] 多专家激活时 agri_tech cateId 文档 `expertIds` 包含所有对应专家
- [ ] cateId→expertId 映射关系在 `RETRIEVAL_DECISION` 审计中可追溯（`cateIdMapping` 字段）
- [ ] `tsc --noEmit` 通过
- [ ] API 契约收敛：DASHBOARD_SKILL_CARDS + RECOMMENDED_TOPICS 迁移到 `src/api/agent/contracts/dashboard-contract.ts`
- [ ] route.ts 改为 import from contracts，不再内联常量
- [ ] `GET dashboard` API 返回值不变（行为等价）
- [ ] caijue.toml 新增 2 条裁决条目（expert-domain / dashboard-contract）
- [ ] caijue.toml 更新 2 条现有条目（sub-intent-plan / merge-expert-evidence-filters）
- [ ] SubIntentExecutionPlan 新增 retrievalBudget 字段（topK + contentSlice）
- [ ] retrieval.ts topK 从硬编码改为消费 plan.retrievalBudget.topK
- [ ] reasoning.ts contentSlice 从硬编码改为消费 plan.retrievalBudget.contentSlice
- [ ] caijue.toml 新增 resolve-retrieval-budget 裁决条目
