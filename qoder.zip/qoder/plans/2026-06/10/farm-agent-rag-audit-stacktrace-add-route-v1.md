# farm-agent-rag-audit-stacktrace-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **绑定**：Plan: `farm-agent-rag-audit-stacktrace-plan-v1.md` · Spec: `../specs/farm-agent-rag-audit-stacktrace/spec.md` · Tasks: `../specs/farm-agent-rag-audit-stacktrace/tasks.md` · Handoff: `farm-agent-rag-audit-stacktrace-handoff-v1.md`

---

## 当前状态快照（生成于 2026-06-10）

> **全部完成**（审计日志确证，2026-06-10）：5 Tasks 全部实施完毕，9 个文件均已修改并记录 ADD-7 审计。

| 文件 | 状态 | 审计日志证据 |
|------|------|------------|
| `registry.ts` | ✅ 完成 | EXPERT_REGISTRY MODIFY: 3→11 experts |
| `knowledge-indexer.ts` | ✅ 完成 | SERVICE MODIFY: stack 前3帧 |
| `evidence.ts` | ✅ 完成 | TYPE MODIFY: +expertIds |
| `retrieval.ts` | ✅ 完成 | NODE MODIFY: cateId映射+expertIds打标+RETRIEVAL_DECISION+topK→plan |
| `reasoning.ts` | ✅ 完成 | NODE MODIFY: EvidenceRef.expertIds+分组上下文+contentSlice→plan |
| `sub-intent.ts` | ✅ 完成 | STRATEGY MODIFY: +retrievalBudget |
| `route.ts` | ✅ 完成 | API_ROUTE MODIFY: import from contracts |
| `dashboard-contract.ts` | ✅ 完成 | API_CONTRACT CREATE: SkillCards+Topics |
| `caijue.toml` | ✅ 完成 | DECISION_REGISTRY MODIFY: +3新增 +2更新 |

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全，项目文档反映即将实现的变更。

**输入**：
- 上游 Review: `../reviews/farm-agent-agrisynapse-integration-runtime-review-v2.md` §5.6-a
- Plan: `farm-agent-rag-audit-stacktrace-plan-v1.md`（v9 修订）
- 规划说明书、架构文档等项目知识库

**动作**：
1. 确认 Specs 三元组就绪：`spec.md` ✅ + `tasks.md` ✅ + `checklist.md` ✅
2. 调用 `find_related_docs` 检索受影响的架构/规范/需求文档
3. 按检索结果更新项目文档（`docs/*/knowledge/`），或声明"本次变更无需更新项目文档"并说明理由
4. 确认 Handoff 就绪（含 round 边界、ADD-7 策略表、回滚方案）✅

**产出**：
- [x] Specs 三元组路径确认 ✅（已就绪）
- [x] 项目文档更新（或无需更新声明）
- [x] Handoff 就绪 ✅（`farm-agent-rag-audit-stacktrace-handoff-v1.md`）

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的所有审计阶段，扩展 `AgentAuditPhase`。

**输入**：
- Plan §3 的 Task 列表
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase` 联合类型

**动作**：
1. 列出本次变更涉及的所有业务阶段
2. 在 `AgentAuditPhase` 联合类型中新增需要的字面量

**本次审计阶段清单**：

| Phase | 使用场景 | Task |
|-------|---------|------|
| `RAG_SEARCH_FAIL` | 知识库检索失败（已有，补 stack） | Task 2 |
| `RETRIEVAL_DECISION` | retrieval 节点决策快照（新增） | Task 3 |
| — | Task 1/4/5 均为结构/配置变更，复用已有 Phase | — |

> 注意：`RETRIEVAL_DECISION` 需确认是否为 `AgentAuditPhase` 已有成员。若否，需在 `agent-audit-logger.ts` 中新增。

**产出**：
- [x] `RETRIEVAL_DECISION` Phase 已确认（或新增）到 `AgentAuditPhase`（审计日志确证: LIB MODIFY +RETRIEVAL_DECISION）
- [x] 审计阶段清单已确认

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用，无需新建 logger 文件。

**输入**：
- `src/lib/agent-audit-logger.ts`
- Step 1 的 AgentAuditPhase 扩展

**动作**：
1. 确认 `agentAudit(phase, detail, extra?)` 接受 Step 1 新增的字面量
2. 确认三通道输出正常（console + file + AuditLog 表）
3. 确认辅助函数可用（`agentAuditNodeStart/End/Error`、`agentAuditRetrieval` 等）

**产出**：
- [x] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan 的 Task 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

**输入**：
- Plan §3 修复方案（每个 Task 的改动文件、步骤、代码模板）
- Plan §4 依赖与约束
- `tasks.md` 的 Task 清单
- Handoff 的 ADD-7 审计策略表

**动作**：

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | 补全Dashboard神经元专家注册 | `src/agents/experts/registry.ts` | 无（结构变更，注册表扩展） | — | 无 | ✅ 完成 |
| 2 | RAG_SEARCH_FAIL补stack trace | `src/services/knowledge-indexer.ts` | `agentAudit("RAG_SEARCH_FAIL", ...)` meta补`stack` | 无（已有Phase补字段） | 无 | ✅ 完成 |
| 3 | 证据归属结构化分档+retrieval决策快照 | `src/types/evidence.ts`, `src/agents/nodes/retrieval.ts`, `src/agents/nodes/reasoning.ts` | `agentAudit("RETRIEVAL_DECISION", ...)` + cateIdMapping | `RETRIEVAL_DECISION`（新增或确认） | Task 1（推荐同批） | ✅ 完成 |
| 4 | API契约收敛+caijue.toml裁决映射更新 | `src/api/agent/contracts/dashboard-contract.ts`(新), `src/app/api/agent/[hash]/route.ts`, `src/caijuehub/caijue.toml` | 无（配置/契约变更） | — | Task 1 | ✅ 完成 |
| 5 | 裁决层检索预算集中化 | `src/caijuehub/strategies/sub-intent.ts`, `src/agents/nodes/retrieval.ts`, `src/agents/nodes/reasoning.ts`, `src/caijuehub/caijue.toml` | 无（裁决参数变更） | — | Task 1 | ✅ 完成 |

### 依赖拓扑

```
Task 1 ──┬──→ Task 4（依赖 ExpertDomain + registry 就位）
         │
         └──→ Task 5（依赖激活专家数计算 topK）

Task 2 ── 独立（只改 knowledge-indexer.ts）

Task 3 ── 独立，但推荐与 Task 1 同批执行（需 ANALYSIS_EXPERTS 就位后方可验证 cateId→expertId 映射完整性）
```

### ADD-7 审计策略（逐文件 beforeState/afterState）

| 文件 | targetType | action | beforeState | afterState |
|------|-----------|--------|------------|------------|
| `src/agents/experts/registry.ts` | EXPERT_REGISTRY | MODIFY | ExpertDomain已更新为6值, isSummary字段已存在, 仅3个专家(crop_compare/roi_analysis/pest_risk)domain已重映射 | 11个专家（3重映射+6核心新增+2汇总新增），核心专家显式`isSummary:false`，汇总专家`isSummary:true`无evidenceFilter |
| `src/services/knowledge-indexer.ts` | SERVICE | MODIFY | `RAG_SEARCH_FAIL`仅记`error.message`，无stack | meta参数补`stack`字段（error.stack前3帧） |
| `src/types/evidence.ts` | TYPE | MODIFY | `Evidence`/`EvidenceRef`无`expertIds`字段 | 各新增`expertIds?: string[]` |
| `src/agents/nodes/retrieval.ts` | NODE | MODIFY | 无cateId→expertId映射, 无evidence.expertIds打标, 无RETRIEVAL_DECISION审计, topK硬编码5 | cateId→expertId反向映射+evidence.expertIds打标+RETRIEVAL_DECISION审计+topK→plan.retrievalBudget.topK |
| `src/agents/nodes/reasoning.ts` | NODE | MODIFY | EvidenceRef无expertIds, 无分组上下文, contentSlice硬编码500 | EvidenceRef.expertIds填充+按expertIds分组+contentSlice→plan.retrievalBudget.contentSlice |
| `src/caijuehub/strategies/sub-intent.ts` | STRATEGY | MODIFY | SubIntentExecutionPlan无retrievalBudget, NULL_PLAN无retrievalBudget | 新增retrievalBudget{topK,contentSlice}+动态计算逻辑+NULL_PLAN兜底 |
| `src/api/agent/contracts/dashboard-contract.ts` | API_CONTRACT | CREATE | 不存在 | 从route.ts收敛DASHBOARD_SKILL_CARDS+RECOMMENDED_TOPICS，含治理注释 |
| `src/app/api/agent/[hash]/route.ts` | API_ROUTE | MODIFY | 内联DASHBOARD_SKILL_CARDS(9个)+RECOMMENDED_TOPICS(4个) | import from contracts，删除内联常量 |
| `src/caijuehub/caijue.toml` | DECISION_REGISTRY | MODIFY | 无resolve-expert-domain/resolve-dashboard-contract/resolve-retrieval-budget, resolve-sub-intent-plan未标注isSummary, merge-expert-evidence-filters未标注汇总跳过 | +3新增(resolve-expert-domain/resolve-dashboard-contract/resolve-retrieval-budget)+2更新(标注isSummary感知+汇总跳过) |

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计

**产出**：
- [x] 全部 Task 的 `[T]` 项通过
- [x] 每个文件有 `record_dev_operation` 记录（审计日志确证: 9 个文件 ≥9 条记录）

---

## Step 3.5：实现审查

**目的**：代码完成后，验证意图与实现无语义鸿沟（ADD-10）。

**输入**：
- `checklist.md`
- `review-implementation-template.md`

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 按 `checklist-template.md` 执行跨项目联调检查
3. 读取 `review-implementation-template.md`，生成 `review-implementation.md`
4. 所有 `[T]` 项通过后，生成 `review-runtime.md`（含 `[R]` 待验证清单）

**产出**：
- [ ] `checklist.md` 全部 `[T]` 项已通过
- [ ] `review-implementation.md` 已生成
- [ ] `review-runtime.md` 已生成

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**输入**：
- 全部修改文件
- MCP 工具：`check_phase_symmetry`、`check_failure_path`

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. `npm run lint` —— 无新增 lint 问题
3. 调用 `check_phase_symmetry` 验证阶段标记完整性
4. 调用 `check_failure_path` 验证失败路径审计等价（ADD-6）

**产出**：
- [x] `tsc --noEmit` 通过
- [x] `npm run lint` 通过
- [ ] 阶段对称性验证通过
- [ ] 失败路径审计等价验证通过

---

## Step 5：AI 自动合规检查

**目的**：扫描全部修改文件的 ADD-1~ADD-7 合规性。

**输入**：
- 全部修改文件的代码
- MCP 工具：`check_add_compliance`

**动作**：
1. 对每个修改文件调用 `check_add_compliance(code, projectPattern="event-based")`
2. 汇总合规报告，标注违规项和风险等级

**产出**：
- [ ] 合规报告已生成
- [ ] 所有违规项有处理决策（修复/豁免/记录）

---

## Step 6：从审计数据定位问题

> **仅当 Step 4/5 发现异常时进入。**

**目的**：根据审计日志定位问题根因。

**动作**：
1. 查询审计日志（`query_audit_logs` 或直接 grep）
2. 对照 Plan 验收到位情况

**产出**：
- [ ] 问题清单（含文件路径和根因分析）

---

## Step 7：修复并验证

> **仅当 Step 6 发现问题时进入。**

**动作**：
1. 按问题优先级逐个修复
2. 修复后回到 Step 4 重新验证

**产出**：
- [ ] 所有问题已修复
- [ ] Step 4/5 复验通过

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**目的**：功能收敛判定，更新 Handoff，回到架构文档做最终校准。

**输入**：
- Handoff: `farm-agent-rag-audit-stacktrace-handoff-v1.md`
- 架构文档: `docs/大田精准耕播智能决策系统/knowledge/01-架构/`

**动作**：
1. **收敛判断**：全部 `[T]` 项通过 + `[R]` 清单已生成 → 功能收敛
2. **Handoff 更新**：更新 Handoff 的 §7（实际产出与偏离）、§8（验证结果）、§9（后置确认），将验证标准中的 `[ ]` 改为已执行状态
3. **Step 0 第二阶段**：回架构文档做最终校准——验证 `docs/大田精准耕播智能决策系统/knowledge/01-架构/` 下相关文档已反映变更（ExpertDomain 6值、三层能力模型、汇总专家概念）
4. **ADD-7 回查**：`query_audit_logs` 确认全部 9 个文件的 `record_dev_operation` 记录已落库，按 action/targetId 交叉验证

**产出**：
- [x] 收敛判定结果
- [x] Handoff 已更新
- [ ] 架构文档已校准
- [x] ADD-7 审计记录已落库确认（10 个文件，≥20 条记录，`query_audit_logs({ keyword: "RAG_AUDIT_STACKTRACE" })` 可查）

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType |
|------|------|------|-----------|
| `src/agents/experts/registry.ts` | MODIFY | Task 1 | EXPERT_REGISTRY |
| `src/services/knowledge-indexer.ts` | MODIFY | Task 2 | SERVICE |
| `src/types/evidence.ts` | MODIFY | Task 3 | TYPE |
| `src/agents/nodes/retrieval.ts` | MODIFY | Task 3 + Task 5 | NODE |
| `src/agents/nodes/reasoning.ts` | MODIFY | Task 3 + Task 5 | NODE |
| `src/caijuehub/strategies/sub-intent.ts` | MODIFY | Task 5 | STRATEGY |
| `src/api/agent/contracts/dashboard-contract.ts` | CREATE | Task 4 | API_CONTRACT |
| `src/app/api/agent/[hash]/route.ts` | MODIFY | Task 4 | API_ROUTE |
| `src/caijuehub/caijue.toml` | MODIFY | Task 4 + Task 5 | DECISION_REGISTRY |

> 共 9 文件：1 CREATE + 8 MODIFY
