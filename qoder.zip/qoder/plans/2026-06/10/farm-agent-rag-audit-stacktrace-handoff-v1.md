# farm-agent — 能力专家全量注册 + RAG 链路加固 + API 契约治理 交接手册

> **适用场景**：单轮变更，5 个独立 Task，修复 RAG 检索崩溃链路（神经元缺专家 → undefined 透传 → 审计盲区）+ 证据归属结构化分档 + 裁决层检索预算集中化。

---

## 1. 交接前状态

- `ANALYSIS_EXPERTS` 含 3 个专家（crop_compare / roi_analysis / pest_risk）
- `ExpertDomain` 类型联合为 `"种植" | "经济" | "管收"`（未对齐规划说明书）
- agrisynapse Dashboard 定义 9 个神经元（DASHBOARD_SKILL_CARDS），8 个无对应 ANALYSIS_EXPERTS
- `RAG_SEARCH_FAIL` 审计日志仅记 `error.message`，无 `error.stack`
- `retrieval.ts` 调用 `searchKnowledgeDocuments` 前无决策上下文审计记录
- `knowledge-indexer.ts` 第 209-210 行 `where` 防 undefined 修复已提交（`const where = rawWhere ?? {}`）

## 2. 交接后状态（目标）

- `ANALYSIS_EXPERTS` 含 11 个专家（3 domain 重映射 + 6 核心新增 + 2 汇总新增）
- `ExpertDomain` 类型联合 = 6 值：`"耕" | "种" | "管" | "收" | "巡检" | "跨域"`（对齐《规划说明书》）
- `AnalysisExpert` 接口新增 `isSummary?: boolean` 字段
- Dashboard 9 个神经元全部有对应 ANALYSIS_EXPERTS
- `RAG_SEARCH_FAIL` 审计日志含 `stack` 字段（前 3 帧），单条日志可定位崩溃位置
- `retrieval.ts` 在 `searchKnowledgeDocuments` 调用前有 `RETRIEVAL_DECISION` 业务审计记录
- `Evidence` + `EvidenceRef` 接口各含 `expertIds?: string[]` 字段
- 合并查询结果在 retrieval 阶段按 `knowledgeCateId` 映射打标 `expertIds`，reasoning 按 expertIds 分组喂 LLM
- 检索预算由裁决层动态计算（`plan.retrievalBudget.topK` / `contentSlice`），节点不再硬编码
- 用户点 Dashboard 任意神经元 → intention 可匹配 → activeExpertIds 非空 → expertWhere 非 undefined

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/agents/experts/registry.ts` | 修改 | ExpertDomain 重写（6值对齐规划说明书）、现有 3 专家 domain 重映射、新增 6 核心 + 2 汇总专家、接口新增 isSummary 字段 |
| 2 | `src/services/knowledge-indexer.ts` | 修改 | RAG_SEARCH_FAIL 审计日志补 error.stack 前 3 帧 |
| 3 | `src/agents/nodes/retrieval.ts` | 修改 | searchKnowledgeDocuments 调用前增加 RETRIEVAL_DECISION 审计记录 + cateId→expertId 反向映射 + evidence.expertIds 打标 + topK 改为消费 plan.retrievalBudget |
| 3a | `src/agents/nodes/reasoning.ts` | 修改 | EvidenceRef.expertIds 填充 + 按 expertIds 分组上下文注入 prompt + contentSlice 改为消费 plan.retrievalBudget |
| 3b | `src/types/evidence.ts` | 修改 | Evidence + EvidenceRef 各新增 expertIds?: string[] |
| 3c | `src/caijuehub/strategies/sub-intent.ts` | 修改 | SubIntentExecutionPlan 新增 retrievalBudget（topK + contentSlice），resolveSubIntentPlan() 动态计算 |
| 4 | `src/api/agent/contracts/dashboard-contract.ts` | 新增 | 从 route.ts 收敛 DASHBOARD_SKILL_CARDS + RECOMMENDED_TOPICS，添加治理注释 |
| 5 | `src/app/api/agent/[hash]/route.ts` | 修改 | 改为 import from contracts，删除内联常量 |
| 6 | `src/caijuehub/caijue.toml` | 修改 | 新增 3 条裁决条目 + 更新 2 条现有条目（含 resolve-retrieval-budget） |

### 现有专家 domain 重映射

| 专家 ID | 旧 domain | 新 domain | 依据 |
|---------|----------|----------|------|
| `crop_compare` | "种植" | **种** | 《规划说明书》三·3.1 |
| `roi_analysis` | "经济" | **跨域** | 《规划说明书》五·经济要素联动 |
| `pest_risk` | "管收" | **管** | 《规划说明书》四·4.3 |

### 新增核心专家（有独立 RAG 管线）

| 专家 ID | label | domain | evidenceFilter cateId |
|---------|-------|--------|----------------------|
| `weather_impact` | 气象影响分析 | 管 | `["weather","agri_tech"]` |
| `nutrition_diagnose` | 营养诊断 | 管 | `["agri_tech","planting_technique"]` |
| `growth_report` | 生长报告 | 管 | `["planting_technique","agri_tech"]` |
| `planting_advice` | 种植建议 | 种 | `["planting_technique","agri_tech"]` |
| `work_plan` | 作业规划 | 跨域 | `["agri_tech","weather"]` |
| `machinery_dispatch` | 农机调度 | 跨域 | `["agri_tech"]` |

### 新增汇总专家（isSummary: true，无独立 evidenceFilter）

| 专家 ID | label | domain | 职责 |
|---------|-------|--------|------|
| `daily_report` | 农情日报 | 跨域 | 汇总各核心专家独立报告，按章节拼接为农情日报总报告 |
| `weekly_report` | 周报分析 | 跨域 | 汇总各核心专家独立报告，按章节拼接为农情周报总报告 |

## 4. 回滚方案

### 代码回滚

```bash
git checkout -- src/agents/experts/registry.ts
git checkout -- src/services/knowledge-indexer.ts
git checkout -- src/agents/nodes/retrieval.ts
git checkout -- src/agents/nodes/reasoning.ts
git checkout -- src/types/evidence.ts
git checkout -- src/caijuehub/strategies/sub-intent.ts
git checkout -- src/caijuehub/caijue.toml
git checkout -- src/app/api/agent/\[hash\]/route.ts
git rm src/api/agent/contracts/dashboard-contract.ts
```

无数据迁移，无需数据回滚。

## 5. 执行前置检查

- [x] `npx tsc --noEmit` 当前无错误（或已知错误与本变更无关）
- [x] `knowledge-indexer.ts` 第 209-210 行 `const where = rawWhere ?? {}` 已存在

## 6. 执行步骤摘要

```text
Task 1 ── ExpertDomain 重写(6值) + 3个domain重映射 + 新增6核心+2汇总专家（registry.ts）
            │
Task 2 ── RAG_SEARCH_FAIL 补 stack 前 3 帧（knowledge-indexer.ts）
            │
Task 3 ── 证据归属结构化分档（evidence.ts + retrieval.ts + reasoning.ts）
│           ├─ Evidence/EvidenceRef.expertIds 类型定义
│           ├─ cateId→expertId 反向映射 + evidence.expertIds 打标
│           ├─ RETRIEVAL_DECISION 审计快照（含 cateIdMapping）
│           ├─ reasoning 按 expertIds 分组注入 prompt
│           └─ topK/contentSlice 改为消费 plan.retrievalBudget
            │
Task 4 ── API契约收敛 + caijue.toml裁决映射更新（contracts/ + route.ts + caijue.toml）
            │
            ▼
编译验证 (tsc --noEmit + lint)
```

Task 1 是主要工作量（ExpertDomain重写 + 3个domain重映射 + 8个专家定义 + isSummary字段）。Task 2 3 行改动。Task 3 是核心修复（5 文件联动：types + retrieval + reasoning + sub-intent + caijue.toml）。Task 4 含 API 契约迁移 + caijue.toml 更新。Task 4 依赖 Task 1，Task 3 推荐与 Task 1 同批验证，其他独立。

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| 现有 3 个专家 domain 重映射后，前端 intention prompt 可能硬编码旧值 | intention 无法匹配 | intention prompt 用 `Object.keys(ANALYSIS_EXPERTS)` 动态生成，无硬编码 |
| ChromaDB 中部分 cateId 无数据，evidenceFilter 命中为空 | 对应专家激活后 RAG 降级到无过滤检索 | 已有 RAG_EXPERT_FILTER_EMPTY 降级逻辑 |
| 8 个新专家的 `outputSections` 与 `ResponseSectionType` 不兼容 | 编译失败 | 编译期即可发现，tsc --noEmit 检查 |
| 汇总专家 `isSummary: true` 但 retrieval.ts 未感知 | 汇总专家被误走独立 RAG 管线 | 当前 retrieval.ts 用 `mergeExpertEvidenceFilters`，汇总专家无 evidenceFilter 会自然返回 undefined，不崩溃。管线无需感知 isSummary——SubIntent + 合并检索/推理 + 汇总 promptTemplate = 链路通畅 |
| ChromaDB 文档元数据缺少 `knowledgeCateId` | cateId→expertId 映射失败，`expertIds` 为空数组 | 降级路径：`expertIds` 为空时 reasoning 仍可正常消费（证据归全体专家，与当前行为等价） |

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用，AI 助手在自己的对话中**直接复制粘贴这些参数调用工具即可**，不需要写 SQL。keyword 查询可恢复完整开发上下文，逐文件查询可按需恢复特定文件的变更细节。

### 总体一键恢复

```text
query_audit_logs({ keyword: "RAG_AUDIT_STACKTRACE" })
```
→ 预期返回 20+ 条记录（含 Plan 修订、Spec 同步、代码实施、Handoff 更新全部链路上的审计记录）

### 逐文件审计查询

```text
query_audit_logs({ targetId: "src/agents/experts/registry.ts" })
→ 预期返回 EXPERT_REGISTRY MODIFY: 3→11 experts (domain重映射+6核心+2汇总)

query_audit_logs({ targetId: "src/services/knowledge-indexer.ts" })
→ 预期返回 SERVICE MODIFY: RAG_SEARCH_FAIL 补 stack

query_audit_logs({ targetId: "src/agents/nodes/retrieval.ts" })
→ 预期返回 NODE MODIFY: RETRIEVAL_DECISION + cateId→expertId分档 + topK→plan

query_audit_logs({ targetId: "src/agents/nodes/reasoning.ts" })
→ 预期返回 NODE MODIFY: EvidenceRef.expertIds + contentSlice→plan.retrievalBudget

query_audit_logs({ targetId: "src/types/evidence.ts" })
→ 预期返回 TYPE MODIFY: Evidence + EvidenceRef +expertIds

query_audit_logs({ targetId: "src/caijuehub/strategies/sub-intent.ts" })
→ 预期返回 STRATEGY MODIFY: SubIntentExecutionPlan +retrievalBudget

query_audit_logs({ targetId: "src/api/agent/contracts/dashboard-contract.ts" })
→ 预期返回 API_CONTRACT CREATE: SkillCards + Topics 收敛

query_audit_logs({ targetId: "src/app/api/agent/[hash]/route.ts" })
→ 预期返回 API_ROUTE MODIFY: 改为 import from contracts

query_audit_logs({ targetId: "src/caijuehub/caijue.toml" })
→ 预期返回 DECISION_REGISTRY MODIFY: +2新增 +2更新
```

### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE action IN (
  'EXPERT_REGISTRY_MODIFY',
  'SERVICE_MODIFY',
  'NODE_MODIFY',
  'TYPE_MODIFY',
  'STRATEGY_MODIFY'
)
AND "targetId" IN (
  'src/agents/experts/registry.ts',
  'src/services/knowledge-indexer.ts',
  'src/agents/nodes/retrieval.ts',
  'src/agents/nodes/reasoning.ts',
  'src/types/evidence.ts',
  'src/caijuehub/strategies/sub-intent.ts'
)
ORDER BY "createdAt" DESC;
```

### 恢复判定标准

- action 命中数 ≥ 8
- grep 验证命令（全部验证通过，2026-06-10）：

```bash
grep -R "weather_impact\|nutrition_diagnose\|growth_report\|planting_advice\|work_plan\|machinery_dispatch\|daily_report\|weekly_report" src/agents/experts/registry.ts
grep -R "stack" src/services/knowledge-indexer.ts
grep -R "RETRIEVAL_DECISION" src/agents/nodes/retrieval.ts
grep -R "expertIds" src/agents/nodes/retrieval.ts
grep -R "expertIds" src/agents/nodes/reasoning.ts
grep -R "expertIds" src/types/evidence.ts
grep -R "retrievalBudget" src/caijuehub/strategies/sub-intent.ts
grep -R "DASHBOARD_SKILL_CARDS" src/api/agent/contracts/dashboard-contract.ts
grep -R "dashboard-contract" src/app/api/agent/\[hash\]/route.ts
grep -R "resolve-expert-domain\|resolve-dashboard-contract\|resolve-retrieval-budget" src/caijuehub/caijue.toml
```

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过
- [x] `ANALYSIS_EXPERTS` 含 11 个专家（3 domain 重映射 + 6 核心新增 + 2 汇总新增）
- [x] Dashboard 9 个 SkillCard id 全部 ∈ `Object.keys(ANALYSIS_EXPERTS)`
- [x] `ExpertDomain` 类型联合 = `"耕" | "种" | "管" | "收" | "巡检" | "跨域"`
- [x] 现有 3 个专家仅 domain 字段被重映射
- [x] 汇总专家（daily_report/weekly_report）`isSummary: true`，无 evidenceFilter
- [x] `RAG_SEARCH_FAIL` 审计日志含 `stack` 字段
- [x] retrieval 节点有 `RETRIEVAL_DECISION` 审计记录（含 `cateIdMapping` 字段）
- [x] `Evidence` / `EvidenceRef` 含 `expertIds?: string[]` 字段
- [x] 证据按 cateId→expertId 映射正确打标
- [x] 所有文件改动已记录 ADD-7 审计（`query_audit_logs` 可回查，10 个文件）
- [x] `SubIntentExecutionPlan` 含 `retrievalBudget` 字段，retrieval/reasoning 消费 plan 而非硬编码

---

## 10. 给 Expert Grounding Plan 的交接说明

> **目标 Plan**: [farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md](file:///home/xmm/ai/farm-agent/.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md)

### 接手的基座

Expert Grounding Plan 的降级路径（`grounding.ready()=false`）需要本 Plan 加固后的基座：

| 本 Plan 产出 | Expert Grounding Plan 使用方式 |
|-------------|-------------------------------|
| `evidence[i].expertIds: string[]` | per-collection 实施时，降级路径证据继续打 `expertIds`；新路径用 `grounding` 字段替代 |
| cateId→expertId 反向映射逻辑 | Grounding Plan 不需要此逻辑（per-collection 天然归属），但降级路径上保留 |
| `RETRIEVAL_DECISION` 审计（含 `cateIdMapping`） | 降级事件 `EXPERT_GROUNDING_DEGRADED` 审计与本审计共存，可交叉排查 |
| `plan.retrievalBudget.topK` | per-collection 路径下 topK 含义变为单 collection 内检索数（无需动态扩容），但降级路径继续使用 |
| `Evidence.expertIds` (optional) | `Evidence.grounding` 新增后两者共存，推理节点按 `expertIds \|\| grounding.collectionName` 分组 |

### 不阻塞保证

- 本 Plan 的 `expertIds` 字段为 optional，不影响 Grounding Plan §3.4 的 `grounding` 字段新增
- 两条路径的证据在 reasoning 统一汇合，分组逻辑对 `expertIds` 和 `grounding.collectionName` 兼容
- Grounding Plan 实施无需删除本 Plan 的任何代码——降级路径作为永久 fallback 保留

---

### 脱敏要求

本 Handoff 文档不包含任何硬编码凭据值。所有环境变量引用见 `.env.development` / `.env.production`。
