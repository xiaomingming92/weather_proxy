# farm-agent-rag-audit-stacktrace-add-route-v2

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **绑定**：Plan: `farm-agent-rag-audit-stacktrace-plan-v1.md` (v9) · Spec: `.qoder/specs/farm-agent-rag-audit-stacktrace/spec.md` · Tasks: `.qoder/specs/farm-agent-rag-audit-stacktrace/tasks.md` · Handoff: `farm-agent-rag-audit-stacktrace-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全，项目文档反映即将实现的变更。

**输入**：
- 上游 Review: `.qoder/reviews/farm-agent-agrisynapse-integration-runtime-review-v2.md` §5.6（RAG 可靠性加固触发源）
- Plan 文档（v9，已含 5 Tasks + 依赖拓扑 + 23 条验收标准）
- Grounding Plan: `farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md`（§3.3 降级路径 + §0 边界协议）

**动作**：
1. 确认 Specs 三元组就绪：生成 `spec.md` + `tasks.md` + `checklist.md`，内容必须同步至 Plan v9
2. 调用 `find_related_docs` 检索《规划说明书》中 ExpertDomain 业务域定义（四·耕种管收巡检 + 五·经济要素联动）、Dashboard 能力卡片定义、caijue.toml 裁决条目规范
3. 按检索结果更新项目文档，或声明"本次变更无需更新项目文档"并说明理由
4. 确认 Handoff 就绪：含 round 边界、ADD-7 策略表、回滚方案

**产出**：
- [ ] Specs 三元组路径确认：`.qoder/specs/farm-agent-rag-audit-stacktrace/`
- [ ] 项目文档更新（或无需更新声明）
- [ ] Handoff 就绪

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的所有审计阶段，扩展 `AgentAuditPhase`。

**输入**：
- Plan §3 的 5 个 Task 列表
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase` 联合类型

**动作**：
1. 列出本次变更涉及的所有业务阶段：
   - `RETRIEVAL_DECISION`（**新增**）：检索决策快照——记录 `activeExpertIds` + `expertWhere` + `cateIdMapping`
   - `RAG_SEARCH_FAIL`（**已有，加固**）：补 `error.stack` 前 3 帧
   - `RAG_EXPERT_FILTER_EMPTY`（已有，不变）
   - `RAG_EMPTY`（已有，不变）
2. 在 `AgentAuditPhase` 联合类型中新增 `"RETRIEVAL_DECISION"` 字面量

**产出**：
- [ ] 本次审计阶段清单

| Phase | 使用场景 | Task |
|-------|---------|------|
| `RETRIEVAL_DECISION` | 检索决策快照：激活专家 + where 条件 + cateId→expertId 映射 | Task 3 |
| `RAG_SEARCH_FAIL` | 已有阶段，加固：补 stack trace 前 3 帧 | Task 2 |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用，无需新建 logger 文件。

**输入**：
- `src/lib/agent-audit-logger.ts`
- Step 1 的 AgentAuditPhase 扩展

**动作**：
1. 确认 `agentAudit(phase, detail, extra?)` 接受 Step 1 新增的 `"RETRIEVAL_DECISION"` 字面量
2. 确认三通道输出正常（console + file + AuditLog 表）
3. 确认辅助函数可用：`agentAuditNodeStart/End/Error`、`agentAuditRetrieval`、`agentAuditRequest/Response/Error`

**产出**：
- [ ] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan 的 Task 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

**输入**：
- Plan §3 修复方案（每个 Task 的改动文件、步骤、代码模板）
- Plan §4 依赖与约束
- `tasks.md` 的 Task 清单
- Handoff 的 ADD-7 审计策略表

### Task 映射表

| # | Task | 文件 | targetType | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|-----------|------|------|
| 1 | 补全 Dashboard 神经元专家注册 | `src/agents/experts/registry.ts` | EXPERT_REGISTRY | `agentAudit("REGISTRY_UPDATED", ...)` 记录新旧专家数 | — | 无 | ⬜ |
| 2 | RAG_SEARCH_FAIL 补 stack trace | `src/services/knowledge-indexer.ts` | SERVICE | 加固已有 `RAG_SEARCH_FAIL` 审计的 extra 字段 | — | 无 | ⬜ |
| 3 | retrieval 决策快照 + 证据归属分档 | `src/types/evidence.ts` + `src/agents/nodes/retrieval.ts` + `src/agents/nodes/reasoning.ts` | TYPE + NODE + NODE | `RETRIEVAL_DECISION` 审计 + cateId→expertId 映射打标 | `RETRIEVAL_DECISION` | 推荐与 Task1 同批 | ⬜ |
| 4 | API 契约收敛 + caijue.toml 裁决映射 | `src/api/agent/contracts/dashboard-contract.ts` + `src/app/api/agent/[hash]/route.ts` + `src/caijuehub/caijue.toml` | API_CONTRACT + API_ROUTE + DECISION_REGISTRY | 无新增 Phase（纯结构收敛） | — | Task 1 | ⬜ |
| 5 | 裁决层检索预算集中化 | `src/caijuehub/strategies/sub-intent.ts` + `src/agents/nodes/retrieval.ts` + `src/agents/nodes/reasoning.ts` + `src/caijuehub/caijue.toml` | STRATEGY + NODE + NODE + DECISION_REGISTRY | 裁决层预算计算 + 节点消费 plan.retrievalBudget | — | Task 1 | ⬜ |

### 依赖拓扑

```
                   ┌─────────────┐
                   │   Task 1    │  ← 独立先行（registry.ts，最重）
                   │  专家注册    │
                   └──────┬──────┘
                          │
          ┌───────────────┼───────────────┐
          │               │               │
          ▼               ▼               ▼
    ┌──────────┐   ┌──────────┐   ┌──────────┐
    │  Task 3  │   │  Task 4  │   │  Task 5  │
    │ 证据分档  │   │ 契约收敛  │   │ 检索预算  │
    └──────────┘   └──────────┘   └──────────┘
     (推荐同批)     (依赖Task1)     (依赖Task1)

Task 2 ── 独立，可任意时机执行
```

**执行顺序**：Task 1 → Task 2 → (Task 3 + Task 4 + Task 5 可并行)

### 各 Task 执行详情

#### Task 1：补全 Dashboard 神经元专家注册
- **改动文件**: `src/agents/experts/registry.ts`
- **当前状态**（代码读取确认）:
  - `ExpertDomain` 已是 `"耕" | "种" | "管" | "收" | "巡检" | "跨域"` ✅
  - `AnalysisExpert` 接口已有 `isSummary?: boolean` ✅
  - 现有 3 个专家 domain 已重映射：crop_compare→种, roi_analysis→跨域, pest_risk→管 ✅
  - **缺失 6 个核心专家 + 2 个汇总专家** ❌
- **动作**:
  1. 在 `ANALYSIS_EXPERTS` 对象中新增 6 个核心专家（`isSummary: false` 显式声明）：
     - `weather_impact`（管）、`nutrition_diagnose`（管）、`growth_report`（管）
     - `planting_advice`（种）、`work_plan`（跨域）、`machinery_dispatch`（跨域）
  2. 新增 2 个汇总专家（`isSummary: true`）：`daily_report`、`weekly_report`
  3. 汇总专家无 `evidenceFilter` 字段
  4. 插入 `agentAudit("REGISTRY_UPDATED", ...)` 记录专家总数变更
  5. 验证：`Object.keys(ANALYSIS_EXPERTS).length === 11`
- **验证**：`tsc --noEmit` 通过，Dashboard 9 个 SkillCard id 全部 ∈ `Object.keys(ANALYSIS_EXPERTS)`

#### Task 2：RAG_SEARCH_FAIL 补 stack trace
- **改动文件**: `src/services/knowledge-indexer.ts` L274-279
- **当前状态**（代码读取确认）:
  ```typescript
  // L276-278: 仅 error.message，无 stack
  agentAudit("RAG_SEARCH_FAIL", `查询失败: ${query}`, {
    error: error instanceof Error ? error.message : String(error),
  })
  ```
- **动作**:
  1. 在 extra 中新增 `stack` 字段：`error.stack?.split("\n").slice(1, 4).join("\n")`
  2. 不改变函数签名，不改变 catch 块的控制流
- **验证**：模拟 ChromaDB 连接失败 → 审计日志包含 `stack` 字段，可定位到文件行号

#### Task 3：retrieval 决策快照 + 证据归属结构化分档
- **改动文件**: `src/types/evidence.ts` + `src/agents/nodes/retrieval.ts` + `src/agents/nodes/reasoning.ts`
- **当前状态**（代码读取确认）:
  - `Evidence` 接口（evidence.ts L16-30）：无 `expertIds` 字段 ❌
  - `EvidenceRef` 接口（evidence.ts L32-40）：无 `expertIds` 字段 ❌
  - `retrieval.ts` L108-113：`activeExperts` + `expertWhere` 存在，但无 cateId→expertId 映射、无 `RETRIEVAL_DECISION` 审计、证据构造无 expertIds 打标
  - `reasoning.ts` L92-103：EvidenceRef 映射无 `expertIds`，contentExcerpt 硬编码 500
- **动作**（按数据流顺序）:
  1. **evidence.ts**: `Evidence` 和 `EvidenceRef` 各加 `expertIds?: string[]`
  2. **retrieval.ts**: 在 `mergeExpertEvidenceFilters` 之后，遍历 `activeExperts` 构建 `cateIdToExpertIds: Map<string, string[]>`
  3. **retrieval.ts**: 证据构造循环中按 `result.metadata.knowledgeCateId` 查映射表，打标 `expertIds`
  4. **retrieval.ts**: 紧接 `mergeExpertEvidenceFilters` 后插入 `agentAudit("RETRIEVAL_DECISION", ...)`（activeExpertIds + expertWhere + cateIdMapping）
  5. **reasoning.ts**: `EvidenceRef` 映射中补 `expertIds: e.expertIds`
  6. **reasoning.ts**: 按 `expertIds` 分组证据，注入到 `buildAnalysisExpertContext` 的专家上下文块中
- **验证**：无专家激活时 `activeExpertIds=(none)`；单专家激活时 `expertIds` 正确映射；多专家激活时 `agri_tech` 文档归属所有对应专家

#### Task 4：API 契约收敛 + caijue.toml 裁决映射更新
- **改动文件**: `src/api/agent/contracts/dashboard-contract.ts`(新建) + `src/app/api/agent/[hash]/route.ts` + `src/caijuehub/caijue.toml`
- **当前状态**（代码读取确认）:
  - `route.ts` L38-109：`DASHBOARD_SKILL_CARDS` + `RECOMMENDED_TOPICS` 内联定义 ❌
  - `src/api/agent/contracts/` 目录不存在 ❌
  - `caijue.toml`：有 `resolve-sub-intent-plan`(L92-104) 和 `merge-expert-evidence-filters`(L161-171)，但无 isSummary 感知标注；无 `resolve-expert-domain`、`resolve-dashboard-contract`、`resolve-retrieval-budget` 条目
- **动作**:
  1. 新建 `src/api/agent/contracts/dashboard-contract.ts`，迁移 route.ts 的 DASHBOARD_SKILL_CARDS + RECOMMENDED_TOPICS，添加治理注释（指向 00-需求文档）
  2. route.ts 删除内联常量，改为 `import { DASHBOARD_SKILL_CARDS, RECOMMENDED_TOPICS } from "@/api/agent/contracts/dashboard-contract"`
  3. caijue.toml 新增 `resolve-expert-domain`（context）：ExpertDomain 6 值定义
  4. caijue.toml 新增 `resolve-dashboard-contract`（contract）：Dashboard API 契约定义
  5. caijue.toml 更新 `resolve-sub-intent-plan`：标注 isSummary 感知
  6. caijue.toml 更新 `merge-expert-evidence-filters`：汇总专家无 evidenceFilter 跳过
  7. caijue.toml 文件头注释新增 `contract` 裁决类型
- **验证**：route.ts 不再含内联常量；`GET dashboard` API 返回值不变（行为等价）；caijue.toml 新增条目可追溯到治理文档

#### Task 5：裁决层检索预算集中化
- **改动文件**: `src/caijuehub/strategies/sub-intent.ts` + `src/agents/nodes/retrieval.ts` + `src/agents/nodes/reasoning.ts` + `src/caijuehub/caijue.toml`
- **当前状态**（代码读取确认）:
  - `SubIntentExecutionPlan`（sub-intent.ts L23-35）：无 `retrievalBudget` 字段 ❌
  - `NULL_PLAN`（sub-intent.ts L39-44）：无 `retrievalBudget` ❌
  - `retrieval.ts` L119：`searchKnowledgeDocuments(searchQuery, 5, ...)` 硬编码 topK=5
  - `reasoning.ts` L101：`e.content.slice(0, 500)` 硬编码 contentSlice=500
- **动作**:
  1. `SubIntentExecutionPlan` 接口新增 `retrievalBudget: { topK: number; contentSlice: number }`
  2. `resolveSubIntentPlan()` 内部计算：`topK = expertCount <= 1 ? 5 : Math.min(expertCount * 5, 20)`；`contentSlice = expertCount <= 2 ? 500 : 300`
  3. `NULL_PLAN` 补 `retrievalBudget: { topK: 5, contentSlice: 500 }`
  4. `retrieval.ts` L119：`5` → `plan.retrievalBudget.topK`
  5. `reasoning.ts` L101：`500` → `plan.retrievalBudget.contentSlice`
  6. caijue.toml 新增 `resolve-retrieval-budget`（strategy）
- **验证**：1专家→topK=5；2专家→topK=10；3专家→topK=15；4+专家→topK=20；retrieval.ts/reasoning.ts 不再含硬编码数字

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计（targetType 见 Task 映射表）

**产出**：
- [ ] 全部 5 个 Task 的 `[T]` 项通过
- [ ] 每个文件有 `record_dev_operation` 记录

---

## Step 3.5：实现审查（ADD-10 语义鸿沟检查）

**目的**：代码完成后，验证意图与实现无语义鸿沟。

**输入**：
- `checklist.md`
- `review-implementation-template.md`

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 按 `checklist-template.md` 执行跨项目联调检查：
   - [T] 格式契约：`Evidence.expertIds` 为 `string[] | undefined`，向后兼容
   - [T] 框架版本：不新增依赖
   - [T] 环境变量：不新增
   - [T] API 选择：`GET dashboard` 行为等价
3. 读取 `review-implementation-template.md`，生成 `review-implementation.md`
4. 所有 `[T]` 项通过后，生成 `review-runtime.md`（含 `[R]` 待验证清单）

**产出**：
- [ ] `checklist.md` 全部 `[T]` 项已通过
- [ ] `review-implementation.md` 已生成
- [ ] `review-runtime.md` 已生成

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**输入**：
- 全部修改文件（9 个文件）
- MCP 工具：`check_phase_symmetry`、`check_failure_path`

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. `npm run lint` —— 无新增 lint 问题
3. 调用 `check_phase_symmetry` 验证阶段标记完整性
4. 调用 `check_failure_path` 验证失败路径审计等价（ADD-6）
5. 按 Plan §5 验收标准逐条验证（23 条）

**关键验证场景**（Task 3 核心场景）：

| 场景 | 预期行为 | 验证方法 |
|------|---------|---------|
| 无专家激活 | `RETRIEVAL_DECISION` 日志: `activeExpertIds=(none), expertWhere=undefined` | 查审计日志 |
| 单专家(weather_impact) | `expertIds` 含 `["weather_impact"]` | 查 evidenceChain |
| 多专家(weather_impact + nutrition_diagnose) | agri_tech 文档 `expertIds = ["weather_impact", "nutrition_diagnose"]` | 查 evidenceChain |
| 1专家 | `plan.retrievalBudget.topK = 5` | 断点调试 |
| 4+专家 | `plan.retrievalBudget.topK = 20` | 断点调试 |
| Dashboard API | `GET dashboard` 返回值不变 | curl 对比 |

**产出**：
- [ ] `tsc --noEmit` 通过
- [ ] `npm run lint` 通过
- [ ] 阶段对称性验证通过
- [ ] 失败路径审计等价验证通过
- [ ] 23 条验收标准全部满足

---

## Step 5：AI 自动合规检查

**目的**：扫描全部修改文件的 ADD-1~ADD-7 合规性。

**输入**：
- 全部修改文件的代码
- MCP 工具：`check_add_compliance`

**动作**：
1. 对每个修改文件调用 `check_add_compliance(code, projectPattern="event-based")`
2. 汇总合规报告，标注违规项和风险等级

**重点检查项**：

| ADD 规则 | 检查内容 | 涉及文件 |
|----------|---------|---------|
| ADD-1 可观测性 | retrieval 节点有 `RETRIEVAL_DECISION` 审计；knowledge-indexer catch 块 stack trace 完整 | retrieval.ts, knowledge-indexer.ts |
| ADD-2 阶段标记对称 | `RETRIEVAL_DECISION` 在每次检索前调用，与 `NODE_START`/`NODE_END` 不冲突 | retrieval.ts |
| ADD-3 最小可观测单元 | 证据构造循环内每条证据有 `expertIds` 打标 | retrieval.ts |
| ADD-4 三通道输出 | agentAudit 三通道正常 | 全文件 |
| ADD-5 审计数据即业务数据 | `expertIds` 字段参与 reasoning 分组，是业务逻辑的一部分 | evidence.ts, reasoning.ts |
| ADD-6 失败路径等价 | RAG_SEARCH_FAIL 的 extra 信息密度（含 stack）≥ 成功路径 | knowledge-indexer.ts |
| ADD-7 开发操作审计 | 9 个文件每个有 `record_dev_operation` 记录 | 全文件 |

**产出**：
- [ ] 合规报告已生成
- [ ] 所有违规项有处理决策（修复/豁免/记录）

---

## Step 6：从审计数据定位问题

> **仅当 Step 4/5 发现异常时进入。**

**目的**：根据审计日志定位问题根因。

**动作**：
1. 查询审计日志：`query_audit_logs({ targetType: "RETRIEVAL_DECISION" })`
2. 对照 Plan §5 验收标准逐项排查
3. 重点关注：cateId→expertId 映射完整性、expertIds 打标准确性、topK 动态计算正确性

**产出**：
- [ ] 问题清单（含文件路径和根因分析）

---

## Step 7：修复并验证

> **仅当 Step 6 发现问题时进入。**

**动作**：
1. 按问题优先级逐个修复
2. 修复后回到 Step 4 重新验证

**产出**：
- [ ] 所有问题已修复
- [ ] Step 4/5 复验通过

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**目的**：功能收敛判定，更新 Handoff，回到架构文档做最终校准。

**输入**：
- Handoff 文档：`farm-agent-rag-audit-stacktrace-handoff-v1.md`
- 架构文档：`docs/大田精准耕播智能决策系统/knowledge/01-架构/`

**动作**：
1. **收敛判断**：
   - 全部 `[T]` 项通过 + `[R]` 清单已生成 → 功能收敛
   - Plan §5 全部 23 条验收标准满足
2. **Handoff 更新**：
   - 更新 §7（实际产出与偏离）：记录 9 个文件的实际改动 vs Plan 预期
   - 更新 §8（验证结果）：checklist 勾选结果 + 运行时验证结果
   - 更新 §9（后置确认）：ADD-7 审计回查确认
3. **Step 0 第二阶段**：
   - 回架构文档做最终校准 — 验证《大田精准耕播智能决策系统》架构文档中 ExpertDomain 定义、三层能力模型、API 契约层描述已反映变更
   - 逐项对照：文档描述 vs 实际实现（registry.ts 的 11 个专家、caijue.toml 的 5 条裁决条目）
   - 如有偏差，输出偏差报告提交开发者决策
4. **ADD-7 回查**：
   - `query_audit_logs` 确认全部 9 个文件的 `record_dev_operation` 记录已落库
   - 按 targetType/action 交叉验证

**产出**：
- [ ] 收敛判定结果
- [ ] Handoff 已更新
- [ ] 架构文档已校准
- [ ] ADD-7 审计记录已落库确认

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/agents/experts/registry.ts` | MODIFY | Task 1 | EXPERT_REGISTRY | ⬜ |
| `src/services/knowledge-indexer.ts` | MODIFY | Task 2 | SERVICE | ⬜ |
| `src/types/evidence.ts` | MODIFY | Task 3 | TYPE | ⬜ |
| `src/agents/nodes/retrieval.ts` | MODIFY | Task 3, Task 5 | NODE | ⬜ |
| `src/agents/nodes/reasoning.ts` | MODIFY | Task 3, Task 5 | NODE | ⬜ |
| `src/api/agent/contracts/dashboard-contract.ts` | CREATE | Task 4 | API_CONTRACT | ⬜ |
| `src/app/api/agent/[hash]/route.ts` | MODIFY | Task 4 | API_ROUTE | ⬜ |
| `src/caijuehub/caijue.toml` | MODIFY | Task 4, Task 5 | DECISION_REGISTRY | ⬜ |
| `src/caijuehub/strategies/sub-intent.ts` | MODIFY | Task 5 | STRATEGY | ⬜ |
| `src/lib/agent-audit-logger.ts` | MODIFY | Step 1 | INFRA | ⬜ |
