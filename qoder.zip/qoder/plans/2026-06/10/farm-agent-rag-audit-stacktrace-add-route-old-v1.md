# farm-agent-rag-audit-stacktrace-add-route-v1

> **绑定**：Plan: `.qoder/plans/farm-agent-rag-audit-stacktrace-plan-v1.md` · Spec: `.qoder/specs/farm-agent-rag-audit-stacktrace/spec.md` · Tasks: `.qoder/specs/farm-agent-rag-audit-stacktrace/tasks.md` · Handoff: `.qoder/plans/farm-agent-rag-audit-stacktrace-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全，项目文档反映即将实现的变更。

**动作**：
1. ✅ Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
2. ✅ Plan 已就绪（v9，含证据归属结构化分档 + 检索预算集中化）
3. ✅ Handoff 已就绪（含回滚方案 + 验证命令 + ADD-7 策略表）
4. ✅ 项目文档已修正：
   - 《ADD开发工作路径与文档协同规范》— `.trae/` → `.qoder/` + 偏差声明
   - 《ADD可审计开发范式案例参考》— 偏差声明
   - SKILL.md — 旧 API 清理 + 深层参考文档引用
5. ✅ tasks.md 依赖拓扑已修正（对齐 Plan §4）

**产出**：
- [x] Specs 三元组路径确认
- [x] 项目文档更新（3 个文件修正）
- [x] Handoff 就绪
- [x] tasks.md 依赖拓扑与 Plan 一致

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的所有审计阶段，扩展 `AgentAuditPhase`。

**动作**：
1. ✅ 分析 Plan §3 的 5 个 Task，仅 Task 3 引入新审计阶段
2. ✅ 在 `src/lib/agent-audit-logger.ts` 的 `AgentAuditPhase` 中新增 `"RETRIEVAL_DECISION"` 字面量

**产出**：
- [x] 本次审计阶段清单

| Phase | 使用场景 | Task |
|-------|---------|------|
| `RETRIEVAL_DECISION` | 检索决策快照（cateId→expertId 映射、activeExpertIds、expertWhere） | Task 3 |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用，无需新建 logger 文件。

**动作**：
1. ✅ 确认 `agentAudit(phase, detail, extra?)` 接受 `"RETRIEVAL_DECISION"` 字面量
2. ✅ 确认三通道输出正常（console + file + AuditLog 表）
3. ✅ 确认辅助函数可用：`agentAuditNodeStart/End/Error`、`agentAuditRetrieval`、`agentAuditRequest/Response/Error`、`setAuditContext`

**产出**：
- [x] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | 专家全量注册 | `registry.ts` | 无（结构变更），仅 ADD-7 record_dev_operation | — | 无 | 🔄 类型+3旧专家已改，8新专家待加 |
| 2 | Stack trace 补全 | `knowledge-indexer.ts` | `agentAudit("RAG_SEARCH_FAIL", ...)` extra 补 `stack` 前3帧 | — | 无 | ⬜ |
| 3 | 证据归属分档 | `evidence.ts` + `retrieval.ts` + `reasoning.ts` | `agentAudit("RETRIEVAL_DECISION", ...)` + evidence.expertIds 打标 | `RETRIEVAL_DECISION` | 推荐与 Task 1 同批 | ⬜ |
| 4 | API 契约收敛 | `dashboard-contract.ts`(新) + `route.ts` + `caijue.toml` | 无（架构收敛），仅 ADD-7 record_dev_operation | — | Task 1 | ⬜ |
| 5 | 检索预算集中化 | `sub-intent.ts` + `retrieval.ts` + `reasoning.ts` + `caijue.toml` | 无（参数治理），仅 ADD-7 record_dev_operation | — | Task 1 | ⬜ |

### 依赖拓扑

```
Task 1 ──┬──→ Task 4（依赖 ExpertDomain + registry 就位）
         │
         └──→ Task 5（依赖 activateExpertIds.length 计算 topK）

Task 2 ── 独立（只改 knowledge-indexer.ts）

Task 3 ── 独立，推荐与 Task 1 同批（需 EXPERTS 就位后验证 cateId 映射）
```

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 按 Plan 元信息 ADD-7 策略表逐文件记录

### ADD-7 审计策略（来自 Plan 元信息）

| 文件 | targetType | action | beforeState | afterState |
|------|-----------|--------|------------|------------|
| `src/agents/experts/registry.ts` | EXPERT_REGISTRY | MODIFY | 3专家，ExpertDomain "种植\|经济\|管收" | 11专家，6值（耕\|种\|管\|收\|巡检\|跨域） |
| `src/services/knowledge-indexer.ts` | SERVICE | MODIFY | RAG_SEARCH_FAIL 仅 error.message | 补 error.stack 前3帧 |
| `src/agents/nodes/retrieval.ts` | NODE | MODIFY | 无决策快照 | cateId→expertId 分档 + RETRIEVAL_DECISION |
| `src/agents/nodes/reasoning.ts` | NODE | MODIFY | EvidenceRef 无 expertIds | +expertIds + 按分组喂 LLM |
| `src/types/evidence.ts` | TYPE | MODIFY | 无 expertIds | Evidence.expertIds? + EvidenceRef.expertIds? |
| `src/api/agent/contracts/dashboard-contract.ts` | API_CONTRACT | CREATE | 不存在 | SkillCards + Topics |
| `src/app/api/agent/[hash]/route.ts` | API_ROUTE | MODIFY | 内联常量 | import from contracts |
| `src/caijuehub/caijue.toml` | DECISION_REGISTRY | MODIFY | 无相关条目 | +3新增 +2更新 |
| `src/caijuehub/strategies/sub-intent.ts` | STRATEGY | MODIFY | 无检索预算字段 | +retrievalBudget |

**产出**：
- [ ] 全部 5 个 Task 代码实施完成
- [ ] 每个文件有 `record_dev_operation` 记录
- [ ] 9 个文件 ADD-7 审计全覆盖

---

## Step 3.5：实现审查

**目的**：代码完成后，验证意图与实现无语义鸿沟（ADD-10）。

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 按 `checklist-template.md` 执行跨项目联调检查
3. 读取 `review-implementation-template.md`，生成 `review-implementation.md`
4. 所有 `[T]` 项通过后，生成 `review-runtime.md`

**关键验证项**：
- `Object.keys(ANALYSIS_EXPERTS).length === 11`
- Dashboard 9 个 SkillCard id 全部 ∈ `Object.keys(ANALYSIS_EXPERTS)`
- `ExpertDomain` 6 值正确
- 汇总专家 `isSummary: true`，无 `evidenceFilter`
- 核心专家 `isSummary: false` 显式声明
- `Evidence` / `EvidenceRef` 含 `expertIds?: string[]`
- `retrieval.ts` 含 cateId→expertId 反向映射
- `reasoning.ts` 按 expertIds 分组注入上下文
- `RAG_SEARCH_FAIL` 含 `stack` 字段
- `RETRIEVAL_DECISION` 含 `activeExpertIds` + `expertWhere` + `cateIdMapping`
- `SubIntentExecutionPlan` 含 `retrievalBudget`
- `retrieval.ts` 不含 topK 硬编码
- `reasoning.ts` 不含 contentSlice 硬编码
- API 契约收敛：SkillCards + Topics → `contracts/dashboard-contract.ts`
- `route.ts` 改为 import from contracts
- `caijue.toml` +3 新增 +2 更新

**产出**：
- [ ] `checklist.md` 全部 `[T]` 项已通过
- [ ] `review-implementation.md` 已生成
- [ ] `review-runtime.md` 已生成

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. `npm run lint` —— 无新增 lint 问题
3. 调用 `check_phase_symmetry` 验证 `RETRIEVAL_DECISION` 阶段标记完整性
4. 调用 `check_failure_path` 验证 `RAG_SEARCH_FAIL` 失败路径审计等价（ADD-6）

**产出**：
- [ ] `tsc --noEmit` 通过
- [ ] `npm run lint` 通过
- [ ] `check_phase_symmetry` 通过
- [ ] `check_failure_path` 通过

---

## Step 5：AI 自动合规检查

**目的**：扫描全部 9 个修改文件的 ADD-1~ADD-7 合规性。

**动作**：
1. 对 9 个修改文件逐文件调用 `check_add_compliance(code, projectPattern="event-based")`
2. 汇总合规报告

**产出**：
- [ ] 合规报告已生成
- [ ] 所有违规项有处理决策

---

## Step 6：从审计数据定位问题

> **仅当 Step 4/5 发现异常时进入。**

**产出**：
- [ ] 问题清单（或"无异常"）

---

## Step 7：修复并验证

> **仅当 Step 6 发现问题时进入。**

**产出**：
- [ ] 所有问题已修复
- [ ] Step 4/5 复验通过

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**目的**：功能收敛判定，更新 Handoff，回到架构文档做最终校准。

**动作**：
1. **收敛判断**：全部 `[T]` 项通过 + `[R]` 清单已生成 → 功能收敛
2. **Handoff 更新**：更新 `handoff-v1.md` 的 §7（实际产出与偏离）、§8（验证结果）、§9（后置确认）
3. **Step 0 第二阶段**：回架构文档做最终校准——验证 `docs/大田精准耕播智能决策系统/knowledge/01-架构/` 下《ADD开发工作路径与文档协同规范》已反映本次变更
4. **ADD-7 回查**：`query_audit_logs` 确认全部 9 个文件 `record_dev_operation` 记录已落库

**产出**：
- [ ] 收敛判定结果
- [ ] Handoff 已更新
- [ ] 架构文档已校准
- [ ] ADD-7 审计记录已落库确认

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 |
|------|------|------|-----------|-------|
| `src/agents/experts/registry.ts` | MODIFY | 1 | EXPERT_REGISTRY | ⬜ |
| `src/services/knowledge-indexer.ts` | MODIFY | 2 | SERVICE | ⬜ |
| `src/types/evidence.ts` | MODIFY | 3 | TYPE | ⬜ |
| `src/agents/nodes/retrieval.ts` | MODIFY | 3 | NODE | ⬜ |
| `src/agents/nodes/reasoning.ts` | MODIFY | 3 | NODE | ⬜ |
| `src/api/agent/contracts/dashboard-contract.ts` | CREATE | 4 | API_CONTRACT | ⬜ |
| `src/app/api/agent/[hash]/route.ts` | MODIFY | 4 | API_ROUTE | ⬜ |
| `src/caijuehub/caijue.toml` | MODIFY | 4+5 | DECISION_REGISTRY | ⬜ |
| `src/caijuehub/strategies/sub-intent.ts` | MODIFY | 5 | STRATEGY | ⬜ |
