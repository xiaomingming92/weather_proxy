# farm-agent-agrisynapse-api-doc-notify-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对。Spec 补充类型定义和 WHEN-THEN 场景。

## PLAN 元信息

- **Plan 名称**: farm-agent-agrisynapse-api-doc-notify-v1
- **启动时间**: 2026-06-26T18:00:00+08:00
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/26/farm-agent-agrisynapse-api-doc-notify-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-06/26/farm-agent-agrisynapse-api-doc-notify-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-agrisynapse-api-doc-notify-review-v1.md`
  - Spec: `.qoder/specs/agrisynapse-api-doc-notify/spec.md`
  - Tasks: `.qoder/specs/agrisynapse-api-doc-notify/tasks.md`
  - Checklist: `.qoder/specs/agrisynapse-api-doc-notify/checklist.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `scripts/notify-agrisynapse-api-version.sh` | COMPONENT | COMPONENT_CREATED | 无独立通知脚本，Agrisynapse 文档变更仅手动通知 | Agrisynapse 主文档版本变更自动推送到独立 IM 通道（企业微信/钉钉/飞书），与 H5 完全解耦 | ✅ 已完成 |
| `scripts/notify-h5-api-version.sh` | COMPONENT | COMPONENT_RENAMED | 旧 `notify-h5-sse-sync.sh`，基于 SSE 事件基线校验 | 重命名并重构为主文档版本驱动通知，复用共享推送库 | ✅ 已完成 |
| `scripts/_notify_lib.sh` | COMPONENT | COMPONENT_CREATED | 无共享推送库，每个 notify 脚本自建 push 逻辑 | 多平台推送共享库（企业微信/钉钉加签/飞书），按 CHANNEL_NAME 分渠道构建文档链接 | ✅ 已完成 |
| `scripts/sync-sse-event-docs.sh` | COMPONENT | COMPONENT_CREATED | 无 | 本地开发工具：校验 H5↔GUI SSE 事件类型一致性 | ✅ 已完成 |
| `src/app/api/agent/docs/[doc]/route.ts` | COMPONENT | COMPONENT_CREATED | Agrisynapse 文档无公网端点，仅依赖 H5 路径 | 新增 Agrisynapse 独立文档端点 `/api/agent/docs/agrisynapse` + `/api/agent/docs/agrisynapse-sse` | ✅ 已完成 |
| `.env.production` | CONFIG | CONFIG_UPDATED | 仅 `NOTIFY_WEBHOOK_URLS` + `DINGTALK_SECRET` 通用通道 | 新增 H5/Agrisynapse 分通道块，移除通用通道遗留变量 | ✅ 已完成 |
| `.env.example` | CONFIG | CONFIG_UPDATED | 含通用通道占位 | 移除通用通道，仅保留 H5/Agrisynapse 分通道 | ✅ 已完成 |
| `.gitlab-ci.yml` | CONFIG | CONFIG_UPDATED | 仅 `notify` job | 拆分为 `notify-h5` + `notify-agrisynapse` 独立 job，各自 source `.env.production` | ✅ 已完成 |

---

## 一、背景与目标

### 1.1 问题现状

- Agrisynapse（神经元 GUI）与 H5 共用一套 SSE 事件类型，但文档和通知体系混在一起
- 旧 `notify-doc-update.sh` 只覆盖 H5 主文档，Agrisynapse 文档变更无人通知
- 没有 Agrisynapse 公网文档端点，通知里的链接只能指向 H5 路径
- 钉钉加签变量命名混乱（`WECOM_*_KEY` 实际是钉钉而不是企业微信）

### 1.2 目标

1. H5 和 Agrisynapse 各自独立的 API 文档版本通知通道
2. SSE 子文档变更 → 主文档版本联动 → CI 自动推送
3. Agrisynapse 拥有独立公网文档端点
4. 推送能力共享库化，钉钉加签变量正名
5. 主文档版本驱动通知，而非 SSE 事件类型基线校验

---

## 二、方案选型

| 方案 | 通知触发 | 文档端点 | 环境变量 | 复杂度 | 结论 |
|------|---------|---------|---------|--------|------|
| A: 扩展旧脚本 | 单脚本多 if-else | H5 路径复用 | 通用 vars | 低 | ❌ 耦合 |
| B: 独立脚本+共享库 | git diff 主文档版本 | H5/Agent 各自端点 | 分通道 vars | 中 | ✅ |
| C: Webhook 平台化 | 独立微服务 | 统一网关 | 集中配置 | 高 | ❌ 过度 |

**选型理由**：方案 B 平衡了独立性（每项目一脚本）与复用性（共享推送库），符合当前项目规模。

---

## 三、架构设计

```
                         .env.production（单一文件分块）
                    ┌──────────┬──────────┐
                    │ H5 分块   │ Agrisynapse 分块 │
                    │ NOTIFY_H5 | NOTIFY_AGRISYNAPSE |
                    └────┬─────┴─────┬────┘
                         │           │
            ┌────────────┼─────┐ ┌───┼──────────────┐
            │notify-h5-api    │ │notify-agrisynapse │
            │  -version.sh    │ │  -api-version.sh  │
            │  检测 H5 主文档  │ │  检测 GUI 主文档  │
            └────────┬────────┘ └───┬───────────────┘
                     │              │
                     └──────┬───────┘
                            ▼
                    ┌───────────────┐
                    │ _notify_lib.sh│ ← 共享推送库
                    │ 企业微信/钉钉  │
                    │ 加签/飞书     │
                    └───────┬───────┘
                            │
              ┌─────────────┼─────────────┐
              ▼             ▼             ▼
         企业微信        钉钉          飞书
```

**文档端点映射**：

| 渠道 | 主文档 | SSE 文档 |
|------|--------|---------|
| H5 | `/api/h5/docs` | `/api/h5/docs/sse` |
| Agrisynapse | `/api/agent/docs/agrisynapse` | `/api/agent/docs/agrisynapse-sse` |

**通知触发链路**：

```
SSE 子文档变更 → 开发者更新 SSE 文档 + bump 主文档版本号
                    → Git Push to main
                    → CI: git diff --name-only HEAD~1 HEAD 检测主文档变更
                    → 提取版本号+变更说明
                    → 按渠道推送 IM 通知
```

---

## 四、实施步骤 + 依赖图

```
Task 1 (共享推送库) ── 无前置
          │
          ▼
Task 2 (H5 脚本重构) ── 依赖 Task 1
Task 3 (Agrisynapse 脚本) ── 依赖 Task 1
          │
          ▼
Task 4 (Agrisynapse 文档端点) ── 依赖 Task 3
          │
          ▼
Task 5 (环境变量对齐) ── 依赖 Task 2,3
          │
          ▼
Task 6 (CI 配置) ── 依赖 Task 5
          │
          ▼
Task 7 (文档更新) ── 依赖 Task 6
```

### Task 1: 共享推送库 `_notify_lib.sh`

- 多平台推送：企业微信 markdown、钉钉 markdown+加签、飞书 text
- 按 CHANNEL_NAME 构建文档链接
- JSON 转义、HTTP 状态码检查

### Task 2: H5 脚本重构为 `notify-h5-api-version.sh`

- 检测 H5 主文档版本变更（git diff）
- 提取版本号+日期+变更说明
- 调用 `_notify_lib.sh` 推送

### Task 3: Agrisynapse 脚本 `notify-agrisynapse-api-version.sh`

- 检测 `神经元GUI-API对接文档.md` 版本变更
- SSE 子文档变更但主文档未升版 → 黄色警告
- 调用 `_notify_lib.sh` 推送

### Task 4: Agrisynapse 文档端点

- 新增 `src/app/api/agent/docs/[doc]/route.ts`
- 注册 `agrisynapse` + `agrisynapse-sse` 两个文档路径
- 支持 markdown/json 格式

### Task 5: 环境变量对齐

- `.env.production` 分通道块
- `.env.example` 移除通用通道
- 变量正名：`WECOM_*_KEY/SECRET` → `DINGTALK_*_SECRET`

### Task 6: CI 配置

- 拆分 `notify` job 为 `notify-h5` + `notify-agrisynapse`
- 传入 `$CI_COMMIT_BEFORE_SHA $CI_COMMIT_SHA`

### Task 7: 文档更新

- 更新 SSE 协议文档的同步机制说明
- 清理旧 `notify-doc-update.sh` 引用

---

## 五、验收标准

- [ ] `notify-h5-api-version.sh` 在 main 分支 H5 主文档版本变更时推送到 H5 群
- [ ] `notify-agrisynapse-api-version.sh` 在 main 分支 Agrisynapse 主文档版本变更时推送到 Agrisynapse 群
- [ ] `/api/agent/docs/agrisynapse` 端点可访问，返回 markdown
- [ ] 钉钉加签变量命名正确（`DINGTALK_*_SECRET`，非 `WECOM_*_KEY`）
- [ ] `.env.production` 无通用通道遗留
- [ ] 旧 `notify-doc-update.sh` 已删除
- [ ] SSE 子文档变更且主文档未升版时 CI 输出黄色警告

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/26/farm-agent-agrisynapse-api-doc-notify-add-route-v1.md` |
| Handoff | `.qoder/plans/2026-06/26/farm-agent-agrisynapse-api-doc-notify-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-agrisynapse-api-doc-notify-review-v1.md` |
| Spec | `.qoder/specs/agrisynapse-api-doc-notify/spec.md` |
| Tasks | `.qoder/specs/agrisynapse-api-doc-notify/tasks.md` |
| Checklist | `.qoder/specs/agrisynapse-api-doc-notify/checklist.md` |
