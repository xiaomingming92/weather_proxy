# checkpointer-postgres-migration-plan

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。不要写完整实现——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: checkpointer-postgres-migration
- **启动时间**: 2026-06-26T10:00:00+08:00
- **修订时间**: 2026-06-26
- **主导 AI**: Qoder
- **前置 Plan**: 无（独立基础设施改造）
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-add-route-v1.md`
  - Review: `.qoder/reviews/checkpointer-postgres-migration-review-v1.md`
  - Handoff: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-handoff.md`
  - Specs: `.qoder/specs/checkpointer-postgres-migration/` (spec.md + tasks.md + checklist.md)
- **现有 checkpointer**: `MemorySaver`（`src/agents/index.ts:231`）
- **现有 LangGraph 版本**: `@langchain/langgraph@^1.3.2`, `@langchain/langgraph-checkpoint@^1.0.2`

---

## 一、背景与目标

### 1.1 问题现状

**现象**：VPS 部署（PM2 restart）后，调用方（瑞丰耘 Java 后端）调用 H5 resume 端点时报错：

```
farm-agent 返回 error SSE 事件
dataJson={"type":"error","message":"u is not async iterable"}
```

**根因**：`MemorySaver` 将 LangGraph checkpoint 保存在 Node.js 进程内存中。

checkpointer 在 LangGraph 中的作用不限于 `interrupt()` / resume 场景——**每次 graph 节点执行后，LangGraph 都会通过 checkpointer 保存当前状态**（消息历史、graph 状态、中间变量等）。当同一个 `thread_id` 再次调用 `invoke/stream` 时，LangGraph 从 checkpointer 加载上一次的 checkpoint 来恢复完整上下文。

因此 PM2 重启 / 部署更新 → 进程重启 → **所有 thread 的全部历史状态丢失**（不仅是中断中的 thread）。只是 `interrupt()` 断点后的 resume 是显式操作，错误暴露得更直接（报 `"u is not async iterable"`）；而普通多轮对话在重启后，用户可能只是感觉"AI 不记得之前的对话了"，错误静默但影响同样严重。

**影响范围**：
- **显式影响**：所有在部署/重启前被 `interrupt()` 暂停的 thread，重启后无法 resume
- **隐式影响**：所有历史对话的多轮上下文在重启后丢失（普通对话无显式报错，但 AI 失去历史记忆）

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | 替换 MemorySaver 为 PostgreSQL 持久化 checkpointer | 部署后 thread 中断状态不丢失 |
| P0 | resume 在服务重启后可正常恢复 | 调用方不再收到 "u is not async iterable" |
| P1 | 零停机迁移 | 现有对话不受影响，checkpoint 表自动创建 |
| P2 | 清理旧 checkpoint（可选） | 过期 checkpoint 自动清理策略 |

---

## 二、技术方案

### 2.1 选型：`@langchain/langgraph-checkpoint-postgres`

项目已有 `@langchain/langgraph-checkpoint@^1.0.2`（LangGraph checkpointer 基础包）。需确认是否已内置 PostgreSQL 适配器，否则安装 `@langchain/langgraph-checkpoint-postgres`。

**数据库连接**：复用现有 PostgreSQL 实例（`DATABASE_URL` 已在 `.env.production` 配置），checkpoint 数据存入独立 schema 或同库独立表。

### 2.2 变更范围

**核心改动**：

| 文件 | 改动 | 说明 |
|------|------|------|
| `src/agents/index.ts:231` | 替换 `new MemorySaver()` | 改为 `PostgresSaver` 实例 |
| `prisma/schema/` | 新增 checkpoint 表 Prisma schema | 或使用 LangGraph 自动建表 |
| `src/lib/checkpointer.ts` | 新建 checkpointer 工厂模块 | 封装连接池和生命周期管理 |
| `.env.production` | 确认 DATABASE_URL | 已存在，无需改动 |

**不改的部分**：
- agent 节点的 `interrupt()` 调用方式不变 — LangGraph API 对 checkpointer 透明
- `streamAgent()` 调用方式不变
- resume 端点代码不变

### 2.3 迁移策略

1. LangGraph `PostgresSaver` 会在首次连接时自动创建 checkpoint 表（如 `langgraph_checkpoints`）
2. 同时保留 `MemorySaver` 的降级路径：如果 PostgreSQL 连接失败，fallback 到 MemorySaver + 日志告警
3. 部署流程：先合并代码 → PM2 restart → 新 checkpoint 自动写入 PostgreSQL → 旧 MemorySaver 状态自然过期

---

## 三、风险与缓解

| 风险 | 概率 | 缓解措施 |
|------|------|---------|
| PostgreSQL 连接池耗尽 | 低 | 使用连接池复用，与 Prisma 共享连接设置 |
| checkpoint 表无限增长 | 中 | 设置 TTL 清理策略或定期清理脚本 |
| LangGraph API 版本不兼容 | 低 | 已安装 `@langchain/langgraph-checkpoint@^1.0.2`，API 稳定 |
| 迁移期间短暂不可用 | 低 | 保留 MemorySaver fallback，部署即生效 |

---

## 四、验收标准

1. 启动 farm-agent → 发起对话 → 产生交互点（`__interrupt__`）→ `pm2 restart farm-agent` → 调用 resume 端点 → 正常恢复 SSE 流（不再报 `"u is not async iterable"`）
2. PostgreSQL 中 `langgraph_checkpoints` 表有对应 thread 的 checkpoint 记录
3. 连续多次对话 + 多次 resume 后，状态正常
4. 发起多轮对话（同一 thread_id 多次 stream）→ `pm2 restart farm-agent` → 再次发送消息（同一 thread_id）→ AI 仍能引用之前的对话上下文（消息历史未丢失）

---

## 五、涉及 Commit

```
feat(agent): 将 checkpointer 从 MemorySaver 迁移至 PostgreSQL 持久化

- 新增 src/lib/checkpointer.ts，封装 PostgresSaver 连接池和生命周期
- src/agents/index.ts：替换 MemorySaver 为 PostgreSQL checkpointer
- 新增 MemorySaver fallback 路径（PostgreSQL 不可用时降级 + 日志告警）
- 部署重启后 thread 中断状态不丢失，resume 正常恢复

BREAKING: 无。LangGraph API 对 checkpointer 透明，调用方无感。
```
