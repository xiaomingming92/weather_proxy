# h5-agent-route-code-quality-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。绑定：Plan `h5-agent-route-code-quality-plan-v1.md`。
>
> **模式**：轻量（Lightweight）——改动范围小（3 文件），无需 spec sync + DPS/RAHS 闸门。
>
> **触发来源**：Runtime 审视 — `src/app/api/h5/agent/route.ts` 审计函数缺失 + 状态管理原始。

---

## 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: H5 Agent 路由代码质量 — 审计函数替换 + SSE 流状态机

Task Groups:
  Group A（审计函数）: agentAudit 枚举扩展 + route.ts 6 处 console→agentAudit
  Group B（状态机）: sse-stream-state.ts 新建 + route.ts 枚举状态机替代布尔标志

逐组业务价值判定:
  Group A: 可用 — 独立改动可验证（query_audit_logs 可查询审计记录）
  Group B: 可用 — 独立改动可验证（tsc 编译期检查 + transition 非法转换审计）

判定结论: 1 轮（1 个原子闭包）

第1轮（原子闭包1）: Task A+B — 业务功能: 审计可回溯 + 状态机类型安全
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## Step 0：文档先行

- Plan 已创建 ✅
- §2.2 状态机设计已定稿（enum StreamState + shouldEarlyReturn）✅
- §2.2.1 模块位置已决策（sse-stream-state.ts）✅

---

## Step 1-8：执行（轻量模式）

| Step | 操作 | 产出 |
|------|------|------|
| 1 | 新建 `sse-stream-state.ts` | enum StreamState + transition/isTerminal/canResume/shouldEarlyReturn ✅ |
| 2 | 扩展 `agent-audit-logger.ts` | 新增 7 个 AgentAuditPhase ✅ |
| 3 | 改造 `h5/agent/route.ts` | 6 处 console→agentAudit + 状态机 ✅ |
| 4 | tsc 编译验证 | 零错误 ✅ |
| 5 | VPS 部署 | pm2 restart farm-agent |
| 6 | 审计验证 | query_audit_logs({ keyword: "H5_CHAT" }) 可查询 ✅ |
| 7 | devlog | record_dev_operation × 6 ✅ |
| 8 | 验收闭环 | 更新 handoff + Plan 修订时间 ✅ |

---

## 附录：文件清单

| 文件 | 操作 | Task | ADD-7 状态 |
|------|------|------|------------|
| `src/agents/sse-stream-state.ts` | CREATE | B | ✅ |
| `src/lib/agent-audit-logger.ts` | MODIFY | A | ✅ |
| `src/app/api/h5/agent/route.ts` | MODIFY | A + B | ✅ |
