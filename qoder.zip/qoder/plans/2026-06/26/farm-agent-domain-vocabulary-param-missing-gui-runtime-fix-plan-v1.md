# farm-agent-domain-vocabulary-param-missing-gui-runtime-fix-plan-v1

> **Plan/Spec 边界提醒**：Runtime 纠正型 Plan，仅记录\"已发现→需修正\"的偏差，不展开完整方案选型。

## PLAN 元信息

- **Plan 名称**: farm-agent-domain-vocabulary-gui-bus-fix-v1
- **启动时间**: 2026-06-26T09:00:00+08:00
- **主导 AI**: Qoder
- **父 Plan**: `farm-agent-domain-vocabulary-plan-v1.md`
- **关联 Review**: `.qoder/reviews/streaming-event-bus-runtime-review-v2.md`（F3 发现）
- **关联文档**:
  - Handoff: `.qoder/plans/2026-06/26/farm-agent-domain-vocabulary-param-missing-gui-runtime-fix-handoff-v1.md`（待创建）

## 一、背景

`farm-agent-domain-vocabulary-plan-v1` 新增了 `ParamMissingEvent` SSE 事件类型，通过已有的 stream-bus 发出。H5 和 Hash 端点已注册 stream-bus 可正常接收，但 GUI 端点的 stream 和 resume 路由从未注册 `registerStreamBus`，导致 `param_missing` 事件不可达。

## 二、改动

| # | 文件 | 操作 | 内容 |
|---|------|:--:|------|
| 1 | `src/app/api/agent/stream/route.ts` | 修改 | 新增 `registerStreamBus` + `GlobalStateProvider` + `CognitiveEventBus`（对齐 Hash 端点模式） |
| 2 | `src/app/api/agent/resume/route.ts` | 修改 | 同上 |

## 三、验收

- [ ] `tsc --noEmit` 通过
- [ ] GUI stream 路由注册 stream-bus，param_missing 事件可达
- [ ] GUI resume 路由注册 stream-bus，param_missing 事件可达
