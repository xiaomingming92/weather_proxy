# farm-agent-agent-os-state-persistence-plan-v2

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。不要写完整实现——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: agent-os-state-persistence-v2
- **启动时间**: 2026-06-26T12:00:00+08:00
- **主导 AI**: Qoder
- **前置 Plan**:
  - [checkpointer-postgres-migration-plan](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/26/checkpointer-postgres-migration-plan.md) — checkpointer MemorySaver → PostgreSQL（**必须先完成**）
  - [co-agent-simplified-v1](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-05/28/farm-agent-多轮对话能力专家链路优化统一状态管理-plan-v1.md) — 8 轮局部闭包已收敛
- **触发 Review**: [checkpointer-runtime-review-v1](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-多轮对话状态管理-checkpointer-runtime-review-v1.md)
- **关联文档**:
  - ADD Route: 待创建
  - Handoff: 待创建
  - Review: `.qoder/reviews/farm-agent-多轮对话状态管理-checkpointer-runtime-review-v1.md`
  - Specs: 待创建

---

## 一、背景与目标

### 1.1 为什么需要 v2

co-agent-simplified-v1（8 轮）已完成全部业务功能：类型收敛、响应裁决、专家管线、语义缓存、演化闭环、三层审计、Global State Model。但 [Runtime 纠正 Review](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-多轮对话状态管理-checkpointer-runtime-review-v1.md) 发现该 Plan 存在一个结构性认知缺口：

**Plan 在设计跨轮状态管理方案时未意识到 LangGraph checkpointer 已是 graph 状态的持久化引擎。**

具体表现为：

1. AnalysisContext 的手动持久化（`ChatThread.metadata`）与 checkpointer 的自动持久化（`AgentState`）形成双重状态管理层，关系未界定
2. 第 8 轮 Global State Model 未提及 checkpointer 作为底层持久化引擎
3. 缺少 Agent OS 重启后的无损恢复策略（类比 Linux 从磁盘重建）

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | 界定 AnalysisContext 与 AgentState 的职责边界 | 按"是否被 graph 节点消费"拆分字段归属，`activeExperts`/`runtimeInputs` 迁入 AgentState |
| P0 | Global State Model 明确 checkpointer 为 graph 状态的 canonical store | 第 8 轮架构文档补充 checkpointer + dispatch_journal + scheduled_tasks 三层持久化 |
| P0 | Agent OS 重启无损恢复策略 | PM2 重启后 graph 状态 + 分析上下文 + 未完成副作用全部可恢复 |

---

## 二、架构设计

### 2.1 模式 B'：以"是否被 graph 节点消费"为判定标准

```
AgentState + checkpointer (执行态)     ChatThread.metadata (观测态)
────────────────────────────────       ──────────────────────────
messages          （已有，reasoning消费）  turnHistory       （诊断记录）
evidenceChain     （已有，reasoning消费）  totalTurns        （统计）
verdictResult     （已有，response消费）
activeExperts     （★应迁入，retrieval消费）
runtimeInputs     （★应迁入，reasoning消费）
```

**判定标准**：字段是否在 graph 节点的 `state.xxx` 中被读取？

- `activeExperts` → retrieval 节点用 `state.activeExperts` 过滤 evidence → **必须在 AgentState**
- `runtimeInputs` → reasoning 节点用 `state.runtimeInputs` 注入 prompt → **必须在 AgentState**
- `turnHistory` → 无任何节点消费，仅诊断记录 → 留在 ChatThread.metadata
- `totalTurns` → 纯统计 → 留在 ChatThread.metadata

### 2.2 Agent OS 三层持久化

```
┌─────────────────────────────────────────────────────┐
│                  Agent OS                            │
│                                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────┐ │
│  │ checkpointer  │  │ dispatch_    │  │ scheduled_  │ │
│  │ (graph状态)   │  │ journal      │  │ tasks       │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬─────┘ │
│         │                 │                  │       │
│         ▼                 ▼                  ▼       │
│  ┌──────────────────────────────────────────────┐    │
│  │              PostgreSQL                       │    │
│  │  langgraph_checkpoints  ← graph 状态          │    │
│  │  dispatch_journal       ← 调度意图日志        │    │
│  │  scheduled_tasks        ← 定时任务            │    │
│  │  ChatThread.metadata    ← 分析上下文          │    │
│  └──────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────┘
```

| 层 | 存什么 | 重启后 | 恢复方式 |
|---|------|:--:|------|
| checkpointer | AgentState（messages, evidenceChain, activeExperts, runtimeInputs...） | ✅ 无损 | `checkpointer.getTuple(threadId)` |
| dispatch_journal | 调度令发送状态（INTENT→SENT→ACKED→DONE） | ✅ 可恢复 | 查 PENDING 状态 → 问对方确认 → 补发/继续 |
| scheduled_tasks | 定时任务（cron_expr, next_run, status） | ✅ 可补发 | DB 轮询，不用 setTimeout |
| ChatThread.metadata | turnHistory, totalTurns | ✅ 无损 | Prisma 查询 |

### 2.3 dispatch_journal：副作用操作的 WAL

类比 Linux 的预写日志（WAL）——在执行副作用之前先写盘：

```sql
CREATE TABLE dispatch_journal (
  id          TEXT PRIMARY KEY,
  from_agent  TEXT NOT NULL,
  to_agent    TEXT NOT NULL,
  command     JSONB NOT NULL,
  status      TEXT NOT NULL,  -- 'INTENT' | 'SENT' | 'ACKED' | 'DONE' | 'FAILED'
  machine_ack JSONB,
  created_at  TIMESTAMP,
  updated_at  TIMESTAMP
);
```

流程：`INSERT INTENT → POST 调度令 → UPDATE SENT → 等 ACK → UPDATE ACKED → UPDATE DONE`

重启恢复：查 `status IN ('INTENT', 'SENT')` → 未发的补发，已发的问对方确认。

### 2.4 scheduled_tasks：定时任务的持久化

```sql
CREATE TABLE scheduled_tasks (
  id        TEXT PRIMARY KEY,
  agent     TEXT NOT NULL,
  action    TEXT NOT NULL,
  payload   JSONB,
  cron_expr TEXT,
  next_run  TIMESTAMP NOT NULL,
  last_run  TIMESTAMP,
  status    TEXT DEFAULT 'PENDING'
);
```

不用 `setTimeout()`，用 DB 轮询（30s 粒度）。凌晨 6 点该发调度令时恰好在重启 → 6:00:30 启动完成 → 查到 `next_run = 06:00 < NOW()` → 补发。

### 2.5 与 Global State Model 的关系

第 8 轮已实施的 `GlobalSystemState` 七域模型应明确：

> **Global State Model 不是再造一个持久化存储，而是跨 store 的统一访问层。**
>
> 它知道每类数据在哪：messages → checkpointer，turnHistory → ChatThread.metadata，cache → SemanticCache。

---

## 三、变更范围

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/agents/state.ts` | MODIFY | AgentState 新增 `activeExperts`、`runtimeInputs` |
| `src/services/analysis-context.ts` | MODIFY | AnalysisContext 移除 `activeExperts`、`runtimeInputs`（迁入 AgentState） |
| `src/agents/nodes/retrieval.ts` | MODIFY | 从 `state.activeExperts` 读取（替代从 AnalysisContext 加载） |
| `src/agents/nodes/reasoning.ts` | MODIFY | 从 `state.runtimeInputs` 读取 |
| `src/agents/global-state.ts` | MODIFY | GlobalSystemState 补充 checkpointer / dispatch_journal / scheduled_tasks 引用 |
| Prisma schema | 新增 | `dispatch_journal` 表、`scheduled_tasks` 表 |
| `src/lib/checkpointer.ts` | MODIFY | 新增 `recoverDispatches()`、`startScheduler()` 恢复函数 |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY | AnalysisContext 加载/保存逻辑调整（不再处理 activeExperts/runtimeInputs） |
| `docs/.../技术架构说明书.md` | MODIFY | 补充 §8.3 状态分层 + §8.8 Agent OS 恢复策略 |

**不改的部分**：
- `src/agents/index.ts` 的 graph 拓扑不变
- `src/agents/nodes/intention.ts` / `verdict.ts` / `interaction-point-detection.ts` 不变
- `src/caijuehub/` 裁决中心不变
- `src/services/semantic-cache.ts` / `path-metrics.ts` / `cache-ttl-stats.ts` 不变
- 第 1-7 轮已通过的局部闭包验证不变

---

## 四、验收标准

1. `activeExperts` 和 `runtimeInputs` 仅存在于 AgentState（`grep` 确认 AnalysisContext 中无残留）
2. `npx tsc --noEmit` 零新增错误
3. 激活专家 → 多轮对话 → `pm2 restart` → 再次对话 → AI 仍记得已激活的专家
4. dispatch_journal 写入 INTENT → 进程 kill → 重启 → `recoverDispatches()` 查到 INTENT 记录 → 补发
5. scheduled_tasks 设置 06:00 任务 → 06:00 时进程 down → 06:01 启动 → 任务自动补发

---

## 五、关联文档

| 文档 | 路径 |
|------|------|
| Runtime 纠正 Review | `.qoder/reviews/farm-agent-多轮对话状态管理-checkpointer-runtime-review-v1.md` |
| checkpointer 迁移 Plan | `.qoder/plans/2026-06/26/checkpointer-postgres-migration-plan.md` |
| 父 Plan (v1) | `.qoder/plans/2026-05/28/farm-agent-多轮对话能力专家链路优化统一状态管理-plan-v1.md` |
| 父 Plan Handoff | `.qoder/plans/2026-05/28/farm-agent-多轮对话能力专家链路优化统一状态管理-7轮原子事务交接-handoff-v1.md` |

---

## 六、涉及 Commit

```
feat(agent-os): Agent OS 状态持久化与无损恢复架构 v2

- 界定 AnalysisContext 与 AgentState 职责边界（模式 B'：节点消费判定）
- activeExperts / runtimeInputs 迁入 AgentState，由 checkpointer 统一管理
- 新增 dispatch_journal 表（副作用操作 WAL）
- 新增 scheduled_tasks 表（定时任务持久化，DB 轮询替代 setTimeout）
- Global State Model 明确 checkpointer 为 graph 状态 canonical store
- Agent OS 重启恢复策略：类比 Linux 从磁盘重建

BREAKING: AnalysisContext.activeExperts 和 AnalysisContext.runtimeInputs 移除，
         迁移至 AgentState。下游读取方需调整 import 路径。
```
