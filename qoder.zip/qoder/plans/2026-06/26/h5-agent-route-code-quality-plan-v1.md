# h5-agent-route-code-quality-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对。不要写完整实现——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: h5-agent-route-code-quality-v1
- **启动时间**: 2026-06-26T10:00:00+08:00
- **修订时间**: 2026-06-26（实施方案：enum 枚举 + shouldEarlyReturn + 7 审计阶段 + add-route + handoff）
- **主导 AI**: Qoder
- **父 Plan**: [farm-agent-ruifengyun-h5-api-plan-v2.md](../23/farm-agent-ruifengyun-h5-api-plan-v2.md)（H5 agent 端点所属）
- **触发来源**: Runtime 审视 — `src/app/api/h5/agent/route.ts` 审计函数缺失 + 状态管理原始
- **关联文档**:
  - Handoff: `.qoder/plans/2026-06/26/h5-agent-route-code-quality-handoff-v1.md`（已创建）
  - ADD Route: `.qoder/plans/2026-06/26/h5-agent-route-code-quality-add-route-v1.md`（已创建）

---

## 一、背景与目标

### 1.1 问题现状

`src/app/api/h5/agent/route.ts` 存在两个代码质量问题：

**P0 — 6 处 `console.log/error` 直接调用**：

| 行 | 当前 | 问题 |
|----|------|------|
| 80 | `console.error(`${PREFIX} 请求异常:`, errorMsg)` | 异常未入 AuditLog，生产排障无法回溯 |
| 95 | `console.log(`${PREFIX} [chat] 开始`)` | 请求入口无审计记录 |
| 139 | `console.log(`${PREFIX} [chat] 新建线程: ${thread.id}`)` | 线程创建不可审计 |
| 260 | `console.log(`${PREFIX} [chat] 中断, ...`)` | 中断事件无审计记录 |
| 301 | `console.log(`${PREFIX} [chat] 完成, ...`)` | 完成事件无审计记录 |
| 313 | `console.error(`${PREFIX} [chat] 流式异常:`, errorMsg)` | 流式异常未入 AuditLog |

`setAuditContext`/`clearAuditContext` 已导入（L18-19）但 `agentAudit` 函数未导入，6 处关键事件全部绕过审计链路写入 AuditLog。

**P1 — 原始布尔标志替代状态机**：

```typescript
let interrupted = false  // L233 — 当前方案
```

SSE 流式生命周期实际有 5 个状态：`idle` / `streaming` / `interrupted` / `done` / `error`。终端状态（`done`/`error`/`interrupted`）直接复用 SSE 协议事件名，零割裂。单一布尔标志只能表达"是否中断"，无法区分 `idle`（尚未启动）vs `done`（正常结束）vs `error`（异常终止）。

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | 6 处 `console.*` 替换为 `agentAudit` | 所有关键事件可审计，`query_audit_logs` 可回溯 |
| P1 | 引入 SSE 流状态机替代 `interrupted` 布尔标志 | 状态转换可枚举、不可逆、可审计 |

### 1.3 不改

- 不修改 H5 agent 路由的业务逻辑（认证、线程管理、SSE 推送）
- Phase 1 仅改造 `h5/agent/route.ts`；`sse-stream-state.ts` 模块设计为公共库，其他端点（chat/stream、agent/[hash]、resume）后续分阶段接入

---

## 二、方案设计

### 2.1 审计函数替换

```typescript
// 导入
import { agentAudit, setAuditContext, clearAuditContext } from "@/lib/agent-audit-logger"

// 替换表
console.error(`${PREFIX} 请求异常:`, errorMsg)
→ agentAudit("H5_CHAT_ERROR", `请求异常: ${errorMsg}`)  // 注：此处 traceId 尚未分配，setAuditContext 在上层调用方

console.log(`${PREFIX} [chat] 开始`)
→ agentAudit("H5_CHAT_START", `traceId=${traceId}`)

console.log(`${PREFIX} [chat] 新建线程: ${thread.id}`)
→ agentAudit("H5_CHAT_THREAD_CREATE", `traceId=${traceId}, threadId=${thread.id}`)

console.log(`${PREFIX} [chat] 中断, ...`)
→ agentAudit("H5_CHAT_INTERRUPT", `traceId=${traceId}, 等待 resume`)

console.log(`${PREFIX} [chat] 完成, ...`)
→ agentAudit("H5_CHAT_COMPLETE", `traceId=${traceId}, ${durationMs}ms`)

console.error(`${PREFIX} [chat] 流式异常:`, errorMsg)
→ agentAudit("H5_CHAT_STREAM_ERROR", `traceId=${traceId}, 流式异常: ${errorMsg}`)
```

新增审计阶段需同步到 `AgentAuditPhase` 类型中（`src/lib/agent-audit-logger.ts`）。

### 2.2 状态机设计

```typescript
// 状态枚举 — 终端状态直接使用 SSE 协议事件名，零割裂
export enum StreamState {
  Idle        = "idle",
  Streaming   = "streaming",
  Interrupted = "interrupted",
  Done        = "done",
  Error       = "error",
}

// 状态转换（不可逆，共 5 条合法路径）
// StreamState.Idle ──streamAgent成功────→ StreamState.Streaming
// StreamState.Idle ──streamAgent异常────→ StreamState.Error
// StreamState.Streaming ──__interrupt__─→ StreamState.Interrupted
// StreamState.Streaming ──循环正常结束───→ StreamState.Done
// StreamState.Streaming ──循环内异常─────→ StreamState.Error

// 状态判断方法
isTerminal(state): boolean     // Done | Error | Interrupted
canResume(state): boolean      // Interrupted（客户端可调用 resume）
shouldEarlyReturn(state): boolean  // Interrupted | Error（不发 done）
```

替代 `interrupted` 布尔标志：
```typescript
// 替换前
let interrupted = false
if (chunkRecord.__interrupt__) { interrupted = true; break }
if (interrupted) { controller.close(); return }

// 替换后
import { transition, shouldEarlyReturn, StreamState } from "@/agents/sse-stream-state"
let streamState = StreamState.Idle
for await (...) {
  if (chunkRecord.__interrupt__) { streamState = transition(streamState, StreamState.Interrupted); break }
}
if (shouldEarlyReturn(streamState)) { controller.close(); return }
// 仅 shouldEarlyReturn 为 false（即 StreamState.Done）时走正常结束逻辑
```

### 2.2.1 StreamState 模块位置

**定义位置**：`src/agents/sse-stream-state.ts`（新建独立模块）。

**理由**：
- `StreamState` 是 SSE 连接生命周期状态，属于路由层概念，不应放入 `NodeStreamController`（节点内部流控）或 `stream-bus.ts`（基础设施层）
- 五位端点（`h5/agent`、`chat/stream`、`agent/[hash]`、`agent/resume`、`h5/resume`）共享同一状态机，独立模块避免重复定义
- `stream-bus.ts` 保持轻量（只管推送），状态管理独立可测试

**职责边界**：
```
sse-stream-state.ts（新增）       NodeStreamController（已有，不改）
├── StreamState 类型定义          ├── agent 节点内部流控
├── transition() 转换函数         ├── emitStreamEvent 封装
├── isTerminal/canResume/needsDone ├── token/responseEnd 等方法
└── 路由层消费                    └── 节点内调用，不感知路由层
```

### 2.3 实施心得（已验证）

#### LangGraph interrupt 机制
- `interrupt()` 通过**抛出 `GraphInterrupt`** 实现暂停，任何 `try/catch` 包裹它的代码必须 `rethrow`，否则图继续运行
- `graph.stream()` 返回 `Promise<AsyncIterable>`，resume 端点**必须 `await` 解包后再 `for await`**，否则 "not async iterable"
- `Command({ resume })` 的值会变成 `interrupt()` 的返回值，恢复后节点从头执行（`interrupt()` 之前的代码会重新跑）

#### 状态机边界
- 状态入口**必须显式声明**：`for` 前加 `transition(Idle, Streaming)`，不在转换表里开 `Idle → Interrupted` 后门
- 终端状态直接复用 SSE 协议事件名（`done` / `error` / `interrupted`），不额外维护映射表
- `shouldEarlyReturn()` 替代裸字符串比较，所有状态判断封装在状态机模块内

#### 裁决层集中
- 终端事件（interrupt/done/error）统一走 `caijuehub/strategies/sse-terminal-event.ts`，路由层不散落 `encoder.encode` + `JSON.stringify`
- `handleInterrupt()` / `handleError()` 一体化：状态转换 + 事件发送
- 流式事件（token/structured_update 等）由 `NodeStreamController` → `stream-bus` 处理，不混入裁决层

---

## 三、变更范围

| 文件 | 改动 | 说明 |
|------|------|------|
| `src/lib/agent-audit-logger.ts` | 新增 7 个 `AgentAuditPhase`（H5_CHAT_START / THREAD_CREATE / INTERRUPT / COMPLETE / STREAM_ERROR / H5_CHAT_ERROR / SSE_STATE_ILLEGAL_TRANSITION） | 枚举扩展 |
| `src/agents/sse-stream-state.ts` | 新建：`enum StreamState` + `transition()` + `isTerminal()` / `canResume()` / `shouldEarlyReturn()` | 状态机核心 |
| `src/app/api/h5/agent/route.ts` | 6 处 `console.*` → `agentAudit()`；`interrupted` 布尔 → `StreamState` 枚举状态机 | 核心改动 |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| CREATE | COMPONENT | `src/agents/sse-stream-state.ts` | enum StreamState + state machine | ✅ |
| MODIFY | COMPONENT | `src/lib/agent-audit-logger.ts` | 新增 7 个 AgentAuditPhase | ✅ |
| MODIFY | API_ROUTE | `src/app/api/h5/agent/route.ts` | console→agentAudit + state machine | ✅ |
| CREATE | PLAN | `h5-agent-route-code-quality-plan-v1.md` | 本 Plan | ✅ |
| CREATE | HANDOFF | `h5-agent-route-code-quality-handoff-v1.md` | 交接手册 | ✅ |
| CREATE | HANDOFF | `h5-agent-route-code-quality-add-route-v1.md` | add-route 执行映射 | ✅ |

**恢复关键词**：
```text
query_audit_logs({ keyword: "h5-agent-route-code-quality" })
→ 返回全部 6 条本轮 ADD-7 审计记录
```

---

## 四、验收标准

- [x] `npx tsc --noEmit` 零错误
- [x] `query_audit_logs({ keyword: "H5_CHAT" })` 可查询到请求入口/中断/完成/异常等审计记录
- [x] 5 条状态转换全部合法（`Idle→Streaming`、`Idle→Error`、`Streaming→Interrupted`、`Streaming→Done`、`Streaming→Error`）
- [x] `transition()` 拒绝非法转换（如 `Done→Streaming`）
- [x] `shouldEarlyReturn()` 替代裸字符串比较
- [x] 中断后不发 `done` 事件行为不变

---

## 五、涉及 Commit

```
refactor(h5-agent): 替换 console 为 agentAudit + 引入 SSE 流状态机

- 新建 src/agents/sse-stream-state.ts：enum StreamState + transition/isTerminal/canResume/shouldEarlyReturn
- 新增 7 个 AgentAuditPhase（H5_CHAT_START/THREAD_CREATE/INTERRUPT/COMPLETE/STREAM_ERROR/H5_CHAT_ERROR/SSE_STATE_ILLEGAL_TRANSITION）
- src/app/api/h5/agent/route.ts：6 处 console.* → agentAudit()；interrupted 布尔 → StreamState 枚举
- 状态转换不可逆（Idle/Streaming/Interrupted/Done/Error），终端状态复用 SSE 协议事件名
```
