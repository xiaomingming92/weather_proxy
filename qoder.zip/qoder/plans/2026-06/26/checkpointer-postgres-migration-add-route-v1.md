# checkpointer-postgres-migration-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"，包含 `check_spec_sync` 文档-代码交叉校验。
>
> **绑定**：Plan: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-plan.md` · Spec: `.qoder/specs/checkpointer-postgres-migration/spec.md` · Tasks: `.qoder/specs/checkpointer-postgres-migration/tasks.md` · Handoff: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-handoff.md`

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全，项目文档反映即将实现的变更。

**输入**：
- Plan: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-plan.md`
- 项目知识库（`docs/大田精准耕播智能决策系统/knowledge/`）

**动作**：
1. 确认 Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md` → ✅ 已创建
2. 调用 `find_related_docs` 检索受影响的架构/规范/需求文档 → 0 条匹配
3. 按检索结果更新项目文档 → **无需更新**：本次变更是纯基础设施改造（MemorySaver → PostgreSQL），LangGraph API 对上层完全透明，不涉及架构文档、需求文档、接口合约变更
4. 确认 Handoff 就绪 → 待生成

**产出**：
- [ ] 验证并更新项目状态：Specs 三元组路径确认 → `.qoder/specs/checkpointer-postgres-migration/`
- [ ] 验证并更新项目状态：项目文档已更新（或无需更新声明已记录）→ ✅ 无需更新
- [ ] 验证并更新项目状态：Handoff 就绪 → 待创建

### 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: LangGraph checkpointer 从 MemorySaver 迁移至 PostgreSQL，确保 PM2 重启后 thread 中断状态不丢失

Task Groups:
  Group A (Task 1: 安装依赖): 纯环境准备，不产生业务价值
  Group B (Task 2: checkpointer 工厂模块): 核心实现组件，单独不可用（无调用点）
  Group C (Task 3: agents/index.ts 替换): 连接工厂与编译，单独不可用（无工厂）
  Group D (Task 4: 端到端验证): 验证闭环，不产生新代码

逐组业务价值判定:
  Group A (安装依赖): 不能用 — 纯环境准备，用户无感知
  Group B (工厂模块): 不能用 — 缺少调用点，无实际效果
  Group C (替换调用点): 不能用 — 需要 Group B 的工厂函数
  Group D (验证): 不能用 — 验证不产生功能

判定结论: 需要 1 轮（1 个原子闭包）

第1轮（原子闭包1）: Task Groups {A, B, C} — 业务功能: Checkpointer PostgreSQL 持久化
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
  说明: Task A+B+C 合在一起完成"checkpointer 持久化"这个完整业务功能——
  安装依赖 + 创建工厂 + 替换调用点，三者缺一不可。
  Task D (端到端验证) 属于 [R] 运行时验证，在部署后执行。
```

### §0.8 DPS 闸门（上游文档质量校验）

> **重型强制**：Step 0 完成后、进入 Step 1 前，调用 `check_dps` 验证上游文档质量。

调用 `check_dps({ planKeyword: "checkpointer-postgres-migration" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |
| 70–84 | 🟡 | 回退补齐短板 |
| < 70 | 🔴 | 回退细化 Plan |

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的所有审计阶段，扩展 `AgentAuditPhase`。

**输入**：
- Plan §2 变更范围
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase` 联合类型

**动作**：
1. 列出本次变更涉及的所有业务阶段：
   - `CHECKPOINTER_POSTGRES_CONNECT` — PostgreSQL checkpointer 连接成功
   - `CHECKPOINTER_MEMORY_FALLBACK` — PostgreSQL 不可用，降级为 MemorySaver
2. 在 `AgentAuditPhase` 联合类型中新增字面量

**产出**：
- [ ] 验证并更新项目状态：本次审计阶段清单已同步到 tasks.md Step 1 区域

| Phase | 使用场景 | Task |
|-------|---------|------|
| `CHECKPOINTER_POSTGRES_CONNECT` | PostgresSaver 连接成功 | Task 2 |
| `CHECKPOINTER_MEMORY_FALLBACK` | PostgreSQL 不可用降级 | Task 2 |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用，无需新建 logger 文件。

**输入**：
- `src/lib/agent-audit-logger.ts`
- Step 1 的 AgentAuditPhase 扩展

**动作**：
1. 确认 `agentAudit(phase, detail, extra?)` 接受 Step 1 新增的字面量
2. 确认三通道输出正常（console + file + AuditLog 表）
3. 在 `src/lib/checkpointer.ts` 中植入审计点：
   - 连接成功: `agentAudit("CHECKPOINTER_POSTGRES_CONNECT", "PostgresSaver 已连接", { host, port, database })`
   - 降级: `agentAudit("CHECKPOINTER_MEMORY_FALLBACK", "PostgreSQL 不可用，降级为 MemorySaver", { error })`

**产出**：
- [ ] 验证并更新项目状态：`agentAudit()` 通道确认可用，状态已同步到 checklist.md ADD 规则合规项

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan 的 Task 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

**输入**：
- Plan §2 变更范围
- `tasks.md` 的 Task 清单
- Handoff 的 ADD-7 审计策略表

**动作**：

### §3.0 前置守卫（重型强制）

调用 `check_add_route_status` 确认 add-route 文件有效存在。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | 安装依赖 | `package.json` | 无（npm 操作） | — | 无 | ⬜ |
| 2 | checkpointer 工厂模块 | `src/lib/checkpointer.ts` | `agentAudit("CHECKPOINTER_POSTGRES_CONNECT", ...)` / `agentAudit("CHECKPOINTER_MEMORY_FALLBACK", ...)` | `CHECKPOINTER_POSTGRES_CONNECT`, `CHECKPOINTER_MEMORY_FALLBACK` | Task 1 | ⬜ |
| 3 | agents/index.ts 替换 | `src/agents/index.ts` | 无（import 替换） | — | Task 2 | ⬜ |

### 依赖拓扑

```
Task 1 ──→ Task 2 ──→ Task 3
(安装)     (工厂)     (替换)
```

### 每个 Task 完成后（重型强制执行）

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计
3. **验证并更新项目状态**：将该 Task 在 `tasks.md` 中逐子项勾选为 `[x]`

**产出**：
- [ ] 验证并更新项目状态：全部 Task 的 `[T]` 项通过，`tasks.md` 已完成项已逐项勾选
- [ ] 验证并更新项目状态：每个文件有 `record_dev_operation` 记录，`checklist.md` ADD-7 审计项已确认
- [ ] 验证并更新项目状态：调用 `check_spec_sync` 确认 spec 文档勾选状态与实际代码一致

---

## Step 3.5：实现审查

**目的**：代码完成后，验证意图与实现无语义鸿沟（ADD-10）。

**输入**：
- `checklist.md`
- `review-implementation-template.md`

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 按 `checklist-template.md` 执行跨项目联调检查
3. 读取 `review-implementation-template.md`，生成 `review-implementation.md`
4. 所有 `[T]` 项通过后，生成 `review-runtime.md`（含 `[R]` 待验证清单）
5. **重型强制**：调用 `check_spec_sync` 确认 `tasks.md` / `checklist.md` 全部已完成项的勾选状态正确

**产出**：
- [ ] 验证并更新项目状态：`checklist.md` 全部 `[T]` 项已通过并勾选
- [ ] 验证并更新项目状态：`review-implementation.md` 已生成
- [ ] 验证并更新项目状态：`review-runtime.md` 已生成（含 `[R]` 待验证清单）
- [ ] 验证并更新项目状态：`check_spec_sync` 通过

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**输入**：
- 全部修改文件
- MCP 工具：`check_phase_symmetry`、`check_failure_path`

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. `npm run lint` —— 无新增 lint 问题
3. 调用 `check_phase_symmetry` 验证阶段标记完整性
4. 调用 `check_failure_path` 验证失败路径审计等价（ADD-6）：PostgreSQL 不可用 → MemorySaver 降级路径有审计

**产出**：
- [ ] `tsc --noEmit` 通过
- [ ] `npm run lint` 通过
- [ ] 阶段对称性验证通过
- [ ] 失败路径审计等价验证通过

### §4.6 RAHS 闸门（下游执行健康度校验）

调用 `check_rahs({ planKeyword: "checkpointer-postgres-migration" })`。

| RAHS | 判定 | 动作 |
|------|:--:|------|
| ≥ 90 | 🟢 | 进入 Step 5 |
| 70–89 | 🟡 | 自检 |
| < 70 | 🔴 | 回退 Step 3 |

- [ ] RAHS 已通过（≥ 90），可进入 Step 5

---

## Step 5：AI 自动合规检查

**目的**：扫描全部修改文件的 ADD-1~ADD-7 合规性。

**输入**：
- 全部修改文件的代码
- MCP 工具：`check_add_compliance`

**动作**：
1. 对每个修改文件调用 `check_add_compliance(code, projectPattern="event-based")`
2. 汇总合规报告

**产出**：
- [ ] 验证并更新项目状态：合规报告已生成
- [ ] 验证并更新项目状态：`checklist.md` ADD 规则合规检查项已同步勾选

---

## Step 6：从审计数据定位问题

> 仅当 Step 4/5 发现异常时进入。

---

## Step 7：修复并验证

> 仅当 Step 6 发现问题时进入。

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**目的**：功能收敛判定，更新 Handoff，回到架构文档做最终校准。

**动作**：
1. **收敛判断**：全部 `[T]` 项通过 + `[R]` 清单已生成 + RAHS ≥ 90 → 功能收敛
2. **RAHS 最终核定**：调用 `check_rahs({ planKeyword: "checkpointer-postgres-migration" })`
3. **验证并更新项目状态**：`tasks.md` 全部 Task 已完成
4. **Handoff 更新**：更新 Handoff 的验证结果和后置确认
5. **Step 0 第二阶段**：回架构文档做最终校准——无相关架构文档需更新（本次为纯基础设施改造）
6. **ADD-7 回查**：`query_audit_logs` 确认全部 `record_dev_operation` 记录已落库

**产出**：
- [ ] 验证并更新项目状态：收敛判定结果
- [ ] 验证并更新项目状态：`tasks.md` + `checklist.md` 全部完成项已勾选
- [ ] 验证并更新项目状态：Handoff 已更新
- [ ] 验证并更新项目状态：架构文档已校准（无需更新）
- [ ] 验证并更新项目状态：ADD-7 审计记录已落库确认

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `package.json` | MODIFY | Task 1 | BUILD_CONFIG | ⬜ |
| `src/lib/checkpointer.ts` | CREATE | Task 2 | COMPONENT | ⬜ |
| `src/agents/index.ts` | MODIFY | Task 3 | COMPONENT | ⬜ |
| `src/lib/agent-audit-logger.ts` | MODIFY | Step 1 | COMPONENT | ⬜ |
