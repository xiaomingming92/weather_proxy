# farm-agent — Checkpointer PostgreSQL 持久化迁移 交接手册

> **适用场景**：单轮变更。将 LangGraph checkpointer 从 MemorySaver 迁移至 PostgreSQL，解决 PM2 重启后 thread 中断状态丢失问题。

---

## 1. 交接前状态

- checkpointer 使用 `MemorySaver`（`src/agents/index.ts:231`）
- PM2 重启 / 部署更新 → 进程重启 → 所有中断中 thread 的 checkpoint 状态丢失
- 调用方（瑞丰耘 Java 后端）resume 时报 `"u is not async iterable"` 错误
- PostgreSQL 已部署运行（端口 5433），`pg` 包已在 dependencies

---

## 2. 交接后状态（目标）

- checkpointer 使用 `PostgresSaver`（`@langchain/langgraph-checkpoint-postgres`）
- checkpoint 数据写入 PostgreSQL `langgraph_checkpoints` 表（LangGraph 自动建表）
- PM2 重启后 thread 中断状态不丢失，resume 正常恢复 SSE 流
- PostgreSQL 不可用时自动降级为 `MemorySaver` + 日志告警
- LangGraph API 对上层完全透明——`interrupt()` / `resume` / `streamAgent()` 无需修改

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `package.json` | 修改 | 新增 `@langchain/langgraph-checkpoint-postgres@^1.0.4` |
| 2 | `src/lib/checkpointer.ts` | 新建 | checkpointer 工厂模块：PostgresSaver 连接池 + MemorySaver fallback |
| 3 | `src/agents/index.ts` | 修改 | 第 231 行 `new MemorySaver()` 替换为 `await createCheckpointer()` |
| 4 | `src/lib/agent-audit-logger.ts` | 修改 | `AgentAuditPhase` 新增 `CHECKPOINTER_POSTGRES_CONNECT` / `CHECKPOINTER_MEMORY_FALLBACK` |

---

## 4. 回滚方案

### 代码回滚

```bash
git revert <commit>
# 或
git reset --hard <previous-commit>
```

### 数据回滚

LangGraph `PostgresSaver` 自动建表，回滚后 PostgreSQL 中的 `langgraph_checkpoints` 表可保留（不影响 MemorySaver 运行），或手动删除：

```sql
DROP TABLE IF EXISTS langgraph_checkpoints;
DROP TABLE IF EXISTS langgraph_checkpoint_writes;
```

---

## 5. 执行前置检查

- [ ] PostgreSQL 服务运行中（`npm run db:status` 或 `pg_isready -h localhost -p 5433`）
- [ ] `DATABASE_URL` 在 `.env.production` 中已配置
- [ ] `@langchain/langgraph-checkpoint@^1.0.2` 已安装
- [ ] `pg` 包已安装（v8.20.0）
- [ ] `npx tsc --noEmit` 当前无错误（或已知错误与本变更无关）

---

## 6. 执行步骤摘要

```text
Task 1: npm install @langchain/langgraph-checkpoint-postgres
            │
            ▼
Task 2: 新建 src/lib/checkpointer.ts
        ├── 解析 DATABASE_URL → pg Pool 配置
        ├── PostgresSaver 实例化
        ├── try-catch fallback → MemorySaver
        └── 导出 createCheckpointer()
            │
            ▼
Task 3: 修改 src/agents/index.ts
        ├── import { createCheckpointer }
        └── const checkpointer = await createCheckpointer()
            │
            ▼
Task 4: npx tsc --noEmit
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| PostgreSQL 连接池耗尽 | 新对话无法创建 checkpoint | 使用连接池复用，与 Prisma 共享 pg 连接设置 |
| checkpoint 表无限增长 | 磁盘占用增加 | P2 后续 Plan 处理 TTL 清理策略 |
| LangGraph API 版本不兼容 | 编译/运行时错误 | 已确认兼容 |
| Top-level await 问题 | `src/agents/index.ts` 需改为 async 初始化 | `createCheckpointer()` 为 async，ESM 支持 |

### 认知修正（devlog 回流）

执行过程中发现 `co-agent-simplified-v1`（多轮对话状态管理 Plan）存在 checkpointer 认知缺口：
- 原 Plan 将"无对话记忆"视为功能缺失 → 实为 checkpointer 未持久化
- AnalysisContext 与 AgentState 形成双重状态管理 → 生成 v2 Plan 界定职责边界
- 详见 Runtime 纠正 Review 和 v2 Plan

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用，AI 助手在自己的对话中**直接复制粘贴这些参数调用工具即可**，不需要写 SQL。共 3 条审计记录可恢复完整开发上下文。

### 总体一键恢复

```text
query_audit_logs({ keyword: "checkpointer-postgres-migration" })
```
→ 预期返回 3+ 条记录

### 逐任务/逐文件审计查询

```text
query_audit_logs({ targetId: "src/lib/checkpointer.ts" })
→ 预期返回 COMPONENT_CREATED: checkpointer 工厂模块创建

query_audit_logs({ targetId: "src/agents/index.ts" })
→ 预期返回 COMPONENT_MODIFIED: MemorySaver → PostgresSaver 替换

query_audit_logs({ keyword: "CHECKPOINTER" })
→ 预期返回 2 条: AgentAuditPhase 新增阶段
```

### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "DevOperation"
WHERE "planKeyword" = 'checkpointer-postgres-migration'
ORDER BY "createdAt" DESC;
```

### 恢复判定标准

- action 命中数 ≥ 3
- grep 验证命令：

```bash
grep -R "checkpointer-postgres-migration" .qoder/specs/
grep -R "createCheckpointer" src/
```

---

## 9. 后置确认

### 编译期验证（已完成）

- [x] `npx tsc --noEmit` — 改动文件零新增错误（仅预先存在的 `cost-accounting/route.ts` 报错与本变更无关）
- [x] ADD-2 阶段对称：3 处 `agentAudit` 调用通过（event-based 模式）
- [x] ADD-6 失败路径：catch 块 `agentAudit("CHECKPOINTER_MEMORY_FALLBACK")` extra 字段与 try 块等价
- [x] ADD-1/4 审计导入：`agentAudit` 从 `@/lib/agent-audit-logger` 完整导入
- [x] ADD-7 审计：5 条 `record_dev_operation` 记录已落库（query_audit_logs 可回查）

### 运行时验证（待部署后执行）

- [R] PostgreSQL `langgraph_checkpoints` 表自动创建
- [R] `pm2 restart farm-agent` 后 resume 端点正常恢复（不再报 `"u is not async iterable"`）
- [R] `pm2 restart farm-agent` 后多轮对话上下文保持

---

### 脱敏要求

Handoff 文档中 **禁止出现** 以下类型的硬编码值：
- 数据库密码（`POSTGRES_PASSWORD`）→ 值见 `.env.production`
- JWT 密钥（`JWT_SECRET`）→ 值见 `.env.production`
- API Key（`OPENAI_API_KEY_*`）→ 值见 `.env.production`

所有凭据值应通过 `${ENV_VAR}` 引用，并标注"值见 `.env.development` / `.env.production`"。
