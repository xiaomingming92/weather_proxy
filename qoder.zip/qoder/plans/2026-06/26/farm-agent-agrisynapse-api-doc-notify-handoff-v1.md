# farm-agent-agrisynapse-api-doc-notify-handoff-v1

> 单轮交接：Agrisynapse API 文档通知体系建设

## 你当前的位置
你是第 1 轮（唯一轮）。本轮实现 Agrisynapse（神经元 GUI）API 文档的独立通知通道、公网文档端点、以及 H5 通知体系的同步重构。

## 上游已完成
无上游依赖（全新功能）。

## 你的 spec 文件
`.qoder/specs/agrisynapse-api-doc-notify/`

## 你要改的文件

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `scripts/_notify_lib.sh` | 新增 | 多平台 IM 推送共享库 |
| `scripts/notify-h5-api-version.sh` | 重命名+重构 | H5 主文档版本驱动通知 |
| `scripts/notify-agrisynapse-api-version.sh` | 新增 | Agrisynapse 主文档版本驱动通知 |
| `src/app/api/agent/docs/[doc]/route.ts` | 新增 | Agrisynapse 文档公网端点 |
| `.env.production` | 修改 | 分通道环境变量 |
| `.env.example` | 修改 | 移除通用通道 |
| `.gitlab-ci.yml` | 修改 | 拆分 notify jobs |
| `scripts/notify-doc-update.sh` | 删除 | 旧通用通知脚本 |

## 核心设计

**通知触发链路**：
```
SSE 子文档变更 → bump 主文档版本号 → git push main
    → CI: git diff HEAD~1 HEAD 检测主文档变更
    → 提取版本号+变更说明 → 按 CHANNEL_NAME 推送 IM
```

**推送架构**：`_notify_lib.sh` 共享库 → 两个独立脚本调用 → 各自推送独立 IM 通道。

## 关键契约细化

1. **文档端点隔离**：H5 用 `/api/h5/docs`，Agrisynapse 用 `/api/agent/docs/`，不得跨路径复用
2. **环境变量**：`NOTIFY_H5_WEBHOOK_URLS` / `NOTIFY_AGRISYNAPSE_WEBHOOK_URLS` 分通道独立
3. **钉钉加签**：仅需 `DINGTALK_*_SECRET`（一个值），不要 `_KEY`
4. **通知格式**：企业微信 `<font color="info">`，钉钉 `**加粗**`，飞书纯文本
5. **CI job**：`notify-h5` + `notify-agrisynapse`，各自 source `.env.production`

## 高风险误区
- 不要给 Agrisynapse 用 `/api/h5/docs` 路径
- 不要用 `WECOM_*_KEY` 命名钉钉加签变量
- 不要删除 `sync-sse-event-docs.sh`（它是开发工具，不是通知脚本）

## 验证标准

- [x] `bash -n` 三个脚本语法检查通过
- [x] `bash notify-h5-api-version.sh HEAD~1 HEAD` 正确输出
- [x] `bash notify-agrisynapse-api-version.sh HEAD~1 HEAD` 正确输出
- [x] 旧 `notify-doc-update.sh` 已删除
- [x] `.env.example` 无通用通道
- [ ] CI 实际推送（部署后验证）
- [ ] `/api/agent/docs/agrisynapse` 公网可访问
