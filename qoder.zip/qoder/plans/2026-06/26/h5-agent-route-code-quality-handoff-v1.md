# h5-agent-route-code-quality — 1 轮 代码质量整改 交接手册

> **适用场景**：H5 Agent 路由代码质量整改 — 审计函数替换 + SSE 流状态机。
> **主责 Plan**: `h5-agent-route-code-quality-plan-v1.md`

---

## 全局元信息

- **父 Plan**: [farm-agent-ruifengyun-h5-api-plan-v2.md](../../2026-06/23/farm-agent-ruifengyun-h5-api-plan-v2.md) §9
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 3 个（1 新建 + 2 修改）
- **轮次数**: 1 轮

```text
第1轮 ── 审计函数替换 + SSE 流状态机（3 文件）
```

---

## 原子事务边界说明

本轮是原子闭包：`agent-audit-logger.ts` 的新枚举值是 `route.ts` 审计调用的前提，`sse-stream-state.ts` 是 `route.ts` 状态机的前提，三者必须同轮交付。

---

## <第1轮> 审计函数替换 + SSE 流状态机

### 你当前的位置

你是第 1 轮（共 1 轮）。Runtime 审视 — `src/app/api/h5/agent/route.ts` 审计函数缺失 + 状态管理原始。

### 上游已完成

- `farm-agent-ruifengyun-h5-api-v2` 已交付 H5 agent 端点
- `streaming-event-bus-plan-v1` 已交付 stream-bus 基础设施

### 恢复上下文审计查询

```text
query_audit_logs({ keyword: "h5-agent-route-code-quality" })
→ 返回全部 6 条本轮 ADD-7 审计记录
```

```text
query_audit_logs({ targetId: "src/agents/sse-stream-state.ts" })
→ 返回 2 条：CREATE + MODIFY（enum StreamState）

query_audit_logs({ targetId: "src/app/api/h5/agent/route.ts" })
→ 返回 1 条：MODIFY（console→agentAudit + state machine）
```

### 你要改的文件（3 个：1 新建 + 2 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/sse-stream-state.ts` | 新建 | `enum StreamState` + `transition()` + `isTerminal()` / `canResume()` / `shouldEarlyReturn()` |
| `src/lib/agent-audit-logger.ts` | 修改 | 新增 7 个 `AgentAuditPhase` |
| `src/app/api/h5/agent/route.ts` | 修改 | 6 处 `console.*` → `agentAudit()` + `StreamState` 枚举替代 `interrupted` 布尔 |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| CREATE | COMPONENT | `src/agents/sse-stream-state.ts` | enum StreamState + state machine | ✅ |
| MODIFY | COMPONENT | `src/lib/agent-audit-logger.ts` | 新增 7 个 AgentAuditPhase | ✅ |
| MODIFY | API_ROUTE | `src/app/api/h5/agent/route.ts` | console→agentAudit + state machine | ✅ |
| CREATE | PLAN | `h5-agent-route-code-quality-plan-v1.md` | 本 Plan | ✅ |
| CREATE | HANDOFF | `h5-agent-route-code-quality-handoff-v1.md` | 本交接手册 | ✅ |
| CREATE | HANDOFF | `h5-agent-route-code-quality-add-route-v1.md` | add-route | ✅ |

**恢复关键词**：
```text
query_audit_logs({ keyword: "h5-agent-route-code-quality" })
→ 返回全部 6 条
```

### 验证

- [x] `npx tsc --noEmit` 零错误
- [x] `query_audit_logs({ keyword: "H5_CHAT" })` 可查询审计记录
- [x] 5 条状态转换合法，`transition()` 拒绝非法转换
- [x] `shouldEarlyReturn()` 替代裸字符串比较

### 部署

```bash
pm2 restart farm-agent
```
