# farm-agent-agrisynapse-api-doc-notify-add-route-v1

## 元信息
- **绑定 Plan**: `farm-agent-agrisynapse-api-doc-notify-plan-v1.md`
- **绑定 Spec**: `.qoder/specs/agrisynapse-api-doc-notify/`
- **绑定 Handoff**: `farm-agent-agrisynapse-api-doc-notify-handoff-v1.md`
- **模板**: heavyweight（后端系统/多层管线）

## Step 状态

| Step | 名称 | 状态 |
|------|------|------|
| Step 0 | 文档先行 | [x] |
| Step 1 | 功能分析与审计阶段 | [x] |
| Step 2 | 审计基础设施 | [x] |
| Step 3 | 业务逻辑实现与审计植入 | [x] |
| Step 3.5 | 实现审查 | [x] |
| Step 4 | 审计数据验证 | [x] |
| Step 5 | AI 自动合规检查 | [x] |
| Step 6 | 从审计数据定位问题 | [x] |
| Step 7 | 修复并验证 | [x] |
| Step 8 | 收敛判断 | [ ] |

## Step 3 Task 映射表

| Task | 改动文件 | 审计植入点 | 依赖 |
|------|---------|-----------|------|
| Task 1 | `scripts/_notify_lib.sh` (new) | 无 | 无 |
| Task 2 | `scripts/notify-h5-api-version.sh` (rename+refactor) | 无 | Task 1 |
| Task 3 | `scripts/notify-agrisynapse-api-version.sh` (new) | 无 | Task 1 |
| Task 4 | `src/app/api/agent/docs/[doc]/route.ts` (new) | 无 | Task 3 |
| Task 5 | `.env.production`, `.env.example` (update) | 无 | Task 2,3 |
| Task 6 | `.gitlab-ci.yml` (update) | 无 | Task 5 |
| Task 7 | `scripts/notify-doc-update.sh` (delete) | 无 | Task 6 |

## 文件清单

| 文件 | targetType | 操作 |
|------|-----------|------|
| `scripts/_notify_lib.sh` | COMPONENT | CREATED |
| `scripts/notify-h5-api-version.sh` | COMPONENT | RENAMED + MODIFIED |
| `scripts/notify-agrisynapse-api-version.sh` | COMPONENT | CREATED |
| `src/app/api/agent/docs/[doc]/route.ts` | COMPONENT | CREATED |
| `.env.production` | CONFIG | CONFIG_UPDATED |
| `.env.example` | CONFIG | CONFIG_UPDATED |
| `.gitlab-ci.yml` | CONFIG | CONFIG_UPDATED |
| `scripts/notify-doc-update.sh` | COMPONENT | DELETED |
