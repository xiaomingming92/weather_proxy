# Agent OS Kernel 管线接入 — Plan v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。不写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: agent-os-kernel-wiring-v1
- **启动时间**: 2026-06-11
- **主导 AI**: Qoder
- **关联文档**:
  - Plan Review: `.qoder/reviews/farm-agent-os-kernel-wiring-plan-review-v1.md`
  - Runtime Review: `.qoder/reviews/farm-agent-expert-grounding-rag-adaptation-review-runtime-v2.md`（断裂点来源）
  - ADD Route: `.qoder/plans/farm-agent-os-kernel-wiring-add-route-v1.md`
  - 上游 Spec: `.qoder/specs/farm-agent-global-state/`
- **Specs 策略**: 无独立 Spec。本次变更为 OS Kernel 内部的管线接入（横切变更），所有类型定义（GlobalStateProvider / CognitiveEventBus / PolicyUpdateLoop / EVENT_CONSUMER_REGISTRY）已在上游 Spec `farm-agent-global-state` 中完整定义。本 Plan 仅负责将已定义的类型接入 LangGraph 图节点，不新增类型、不修改上游 Spec。实现细节由 Plan §3.2 文件变更清单 + Runtime Review §10 受影响文件清单共同定义。
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/agents/index.ts | COMPONENT | COMPONENT_MODIFIED | ToolNode 裸注册，wrapNodeWithAudit 无 OS 集成 | ToolNode 包装器 + wrapNodeWithAudit 注入 OS 对象 + retrieval 出口/reasoning 入口钩子 | ✅ 已实施 |
| src/agents/global-state.ts | COMPONENT | COMPONENT_MODIFIED | ExecutionStateSnapshot 缺少 lastTool* 字段 | 新增 3 个字段 | ✅ 已实施 |
| src/agents/state.ts | COMPONENT | COMPONENT_MODIFIED | AgentState 无 fallbackFlags | 新增 fallbackFlags 字段 | ✅ 已实施 |
| src/agents/nodes/retrieval.ts | COMPONENT | COMPONENT_MODIFIED | 不 emit 不 updateDomain | emit evidence:retrieved + updateDomain("agent") 实时（不等流结束） + evidenceChain 轮次覆盖 | ✅ 已实施 |
| src/agents/nodes/reasoning.ts | COMPONENT | COMPONENT_MODIFIED | 只读 evidenceChain | 追加消费 state.messages 工具结果 + fallbackFlags 降级 prompt | ✅ 已实施 |
| src/caijuehub/strategies/event-consumer-strategies.ts | COMPONENT | COMPONENT_MODIFIED | 1 个消费者 | 4 个消费者 | ✅ 已实施 |
| src/agents/policy-update-loop.ts | COMPONENT | COMPONENT_MODIFIED | evaluate() 无 toolExecutionStats | 新增 toolExecutionStats 参数 | ✅ 已实施 |
| docs/大田精准耕播智能决策系统/knowledge/01-架构/Agent-OS-Kernel-架构说明书.md | DOCUMENT | DOCUMENT_CREATED | 无 OS Kernel 文档 | OS Kernel 架构说明书 | ✅ 已实施 |

---

## 一、背景与目标

### 1.1 问题现状

第 8 轮架构合流闭包在 `specs/farm-agent-global-state/` 中定义了完整的 Agent OS Kernel 三层（GlobalStateProvider / CognitiveEventBus / PolicyUpdateLoop），三组件代码已落地，类型定义和 API 均已就绪。但管线接入存在严重断裂：[v2 runtime review](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-expert-grounding-rag-adaptation-review-runtime-v2.md) 识别出 **6 个断裂点**：

| 断裂点 | 现象 | 严重度 |
|--------|------|:--:|
| A: ToolNode ↔ OS Kernel | ToolNode 不 emit `action:proposed`，不更新 `execution` 域 | P0 |
| B: RAG ↔ OS Kernel | retrieval 不 emit `evidence:retrieved`，不更新 `agent` 域 | P1 |
| C: Tool+RAG 合流 | reasoning 不读 `state.messages` 中工具结果 | P1 |
| D: 概念文档 | Agent OS Kernel 无架构说明书 | P1 |
| E: BSP 约束 | ToolNode 内逐工具不可见（架构约束，不阻塞修复） | 架构 |
| F: 多租户隔离 | per-request 碰巧隔离，无 tenantId 字段 | P2 |
| G: evidenceChain 跨轮残留 | 同 thread 跨轮次 evidenceChain 不清空，零命中时旧证据冒充新报告 | P1 |

断裂点 D/E/F 本质是文档和架构约束问题（补文档、加字段），不需要复杂设计权衡。断裂点 A/B/C 是代码层面的信号断裂——设计已完备（事件类型、状态字段、消费策略均就绪），但无人把管线节点"接入插座"。

### 1.2 目标

1. **ToolNode 接入 OS Kernel**：包装 ToolNode，在工具执行后 emit `action:proposed` + updateDomain("execution")
2. **retrieval 接入 OS Kernel**：在检索完成后 emit `evidence:retrieved` + updateDomain("agent")
3. **reasoning 合流**：消费 `state.messages` 中的工具结果，与 `evidenceChain` 合并注入 prompt
4. **EVENT_CONSUMER_REGISTRY 补全**：注册 3 个缺失消费者
5. **PolicyUpdateLoop 工具感知**：`evaluate()` 能读取工具调用统计
6. **OS Kernel 架构说明书**：文档独立成篇
7. **多租户隔离**：`tenantId` 字段 + `getHistory({ filter })`
8. **evidenceChain 轮次隔离**：通过 wrapNodeWithAudit 节点边界钩子，retrieval 出口写入 evidenceCount、reasoning 入口注入 fallbackFlags，零命中时走降级 prompt（Review v2 §2.4）

---

## 二、方案选型

### 2.1 OS 内核对象注入通道

review §9 第 3 条已记录三种可行通道，Plan 阶段选定：

| 方案 | 做法 | 优势 | 劣势 | 结论 |
|------|------|------|------|:--:|
| A: RunnableConfig 注入 | `agent.stream(input, { configurable: { globalStateProvider, eventBus } })` | LangGraph 原生，与 thread_id 同机制，不污染 state | 需在调用链上透传 config：addNode 回调、wrapNodeWithAudit、目标节点函数均需加可选 `config?` 参数 | **选用** |
| B: wrapNodeWithAudit 签名扩展 | 改为 `(nodeName, state, nodeFn, os)` | 显式，类型安全 | 所有节点签名要改，ToolNode 不归 wrapNodeWithAudit 管需单独处理 | 备选 |
| C: AgentState 携带 | `AgentState._osProvider` 字段 | 最简单 | checkpointer 序列化非可序列化对象，快照膨胀，反序列化失败 | **禁用** |

**选型理由**：方案 A 是 LangGraph 的标准 config 传递机制。**需要以下签名变更**（均在末尾追加可选 `config?` 参数，TS 兼容性优于方案 B 的必选位置参数）：

| 变更点 | 当前签名 | 新签名 | 数量 |
|--------|---------|--------|:--:|
| addNode 回调 | `(state) => {...}` | `(state, config?) => {...}` | 6 处 |
| wrapNodeWithAudit | `(nodeName, state, nodeFn)` | `(nodeName, state, nodeFn, config?)` | 1 处 |
| retrieval/reasoning 节点函数 | `(state) => {...}` | `(state, config?) => {...}` | 2 处 |

总计 9 处签名变更。其余节点（intention/verdict/response/interactionPointDetection）的 addNode 回调也需加 `config?`（LangGraph 框架要求），但节点函数内部不消费 config，参数可忽略。

**传递链路**：
```
route.ts: globalStateProvider/eventBus 从 streamAgent input 移入 config.configurable
  ↓
streamAgent: config 参数扩展 configurable 类型（L194 spread 已覆盖）
  ↓
agent.stream(input, config) → LangGraph 将 config 注入每个节点
  ↓
addNode 回调: (state, config) → wrapNodeWithAudit(nodeName, state, nodeFn, config)
  ↓
节点函数: (state, config?) → 从 config.configurable 取 OS 对象
```

### 2.2 ToolNode 包装策略

ToolNode 是 LangGraph 原生类，不能直接改源码。两种包装方案：

| 方案 | 做法 | 结论 |
|------|------|:--:|
| 继承 ToolNode | `class OsAwareToolNode extends ToolNode { ... }` | ToolNode 内部结构不稳定，LangGraph 版本升级可能破坏 |
| 包装函数 | 在 `addNode("toolNode", ...)` 前包裹一层自定义节点函数 | **选用** |

**选型理由**：LangGraph `addNode` 接受 `RunnableLike`，直接传一个自定义 `(state, config) => Promise<StateUpdate>` 函数即可，完全掌控节点行为，不依赖 ToolNode 内部实现。

### 2.3 retrieval/reasoning 获取 OS 内核对象的方式

选定方案 A（RunnableConfig），retrieval/reasoning 节点从 `RunnableConfig.configurable` 中取 `globalStateProvider` 和 `eventBus`。**wrapNodeWithAudit 签名需改为 `(nodeName, state, nodeFn, config?)`**——config 由 addNode 回调传入，wrapNodeWithAudit 透传给 nodeFn。config 为可选参数，不传时行为不变（向后兼容）。

---

## 三、架构设计

### 3.1 整体变更范围

```
                    ┌──────────────────────────────┐
                    │        OS Kernel              │
                    │                               │
                    │  GlobalStateProvider          │
                    │  CognitiveEventBus            │
                    │  PolicyUpdateLoop             │
                    │  EVENT_CONSUMER_REGISTRY      │
                    └────┬──────┬──────┬────────────┘
                         │      │      │
              ┌──────────┘      │      └──────────┐
              ▼                 ▼                 ▼
    ┌─────────────────┐ ┌──────────────┐ ┌──────────────┐
    │   ToolNode      │ │  retrieval   │ │  reasoning   │
    │   包装器         │ │  (修改)      │ │  (修改)      │
    │   (新增/替换)    │ │              │ │              │
    │                 │ │ + emit       │ │ + 读 messages │
    │ + emit          │ │ + updateDmn  │ │ + 读 snapshot │
    │ + updateDomain  │ │              │ │              │
    └─────────────────┘ └──────────────┘ └──────────────┘
```

### 3.2 文件变更清单

| 文件 | 变更类型 | 变更内容 |
|------|---------|------|
| `src/agents/index.ts` | 修改 | ToolNode → 包装函数；注入 config.configurable 到 agent.stream()；wrapNodeWithAudit 在边界 emit/updateDomain |
| `src/agents/global-state.ts` | 修改 | ExecutionStateSnapshot 新增 lastToolName/lastToolStatus/lastToolDurationMs；GlobalSystemState.meta 新增 tenantId |
| `src/agents/state.ts` | 修改 | AgentState 新增 `fallbackFlags` 字段（`{ ragEmpty: boolean, toolResultsEmpty: boolean }`），由 wrapNodeWithAudit 写入、reasoning 读取 |
| `src/agents/nodes/retrieval.ts` | 修改 | 从 config 取 OS 对象；emit evidence:retrieved；updateDomain("agent") 在检索完成后立即执行 |
| `src/agents/nodes/reasoning.ts` | 修改 | 消费 state.messages 中 ToolMessage；从 config 取 getSnapshot()；合并到 prompt |
| `src/caijuehub/strategies/event-consumer-strategies.ts` | 修改 | 注册 3 个消费者 |
| `src/agents/policy-update-loop.ts` | 修改 | evaluate() 新增 toolExecutionStats 参数 |
| `src/agents/cognitive-event-bus.ts` | 修改 | getHistory 支持 `filter: { threadId? }` |
| `src/app/api/agent/chat/stream/route.ts` | 修改 | globalStateProvider/eventBus 从 streamAgent input 移入 config.configurable（Plan §2.1 传递链路）；threadId 注入 configurable（Task 7 多租户隔离） |
| `docs/大田精准耕播智能决策系统/knowledge/01-架构/Agent-OS-Kernel-架构说明书.md` | 新增 | 架构说明书 |

### 3.3 不修改的文件

- `src/agents/nodes/intention.ts` — 意图节点行为不变
- `src/agents/nodes/verdict.ts` — 裁决节点不变
- `src/agents/nodes/response.ts` — 响应节点不变
- `src/agents/nodes/interaction-point-detection.ts` — 交互点检测不变
- `src/agents/edges/conditional.ts` — 条件路由不变
- `src/agents/prompts/*.ts` — Prompt 模板不变
- `src/agents/stream-bus.ts` — SSE 事件通道不变
- `src/agents/response-strategy.ts` — 策略裁决不变

---

## 四、实施步骤 + 依赖图

```
Task 1: ToolNode 包装器 (A)     Task 2: GlobalState 扩展
         │                                    │
         ├────────────────┬───────────────────┘
         ▼                ▼
Task 3: retrieval OS接入+证据隔离(B/G)   Task 4: reasoning 合流+降级(C/G)
         │                    │
         └────────┬───────────┘
                  ▼
Task 5: EVENT_CONSUMER_REGISTRY 补全
                  │
                  ▼
Task 6: PolicyUpdateLoop 工具感知
                  │
                  ▼
Task 7: 多租户隔离 + getHistory filter
                  │
                  ▼
Task 8: OS Kernel 架构说明书
                  │
                  ▼
Task 9: npx tsc + 验证清单 V1-V8
```

### Task 1: ToolNode 包装器注入 OS Kernel 信号（断裂点 A）

**目标**：ToolNode 执行后 emit `action:proposed` + updateDomain("execution")。

**改动文件**：`src/agents/index.ts`

**实施要点**：
- 在 `addNode("toolNode", ...)` 处替换为自定义节点函数
- ToolNode 继承 `Runnable`，包装函数内调用 `toolNodeInst.invoke(state, config)` 执行工具并获取 ToolMessage[]
- 工具完成后 emit action:proposed（每个工具一条事件） + updateDomain("execution")（累加 toolCallsCount）
- OS 对象从 RunnableConfig.configurable 中获取
- `toolNodeInst.invoke()` 返回 `{ messages: ToolMessage[] }` 的 state update，包装函数在其上叠加 OS 信号后返回

**验收**：验证清单 V1 (action:proposed emit)、V2 (toolCallsCount > 0)、V3 (lastToolName)

### Task 2: ExecutionStateSnapshot 扩展 + GlobalSystemState.meta.tenantId

**目标**：补充缺失字段。

**改动文件**：`src/agents/global-state.ts`

**实施要点**：
- ExecutionStateSnapshot 新增 lastToolName/lastToolStatus/lastToolDurationMs
- GlobalSystemState.meta 新增 tenantId?: string

**验收**：类型无新增错误，字段可被 Task 1 的 updateDomain 写入

### Task 3: retrieval 节点 OS 感知 + evidenceChain 轮次隔离（断裂点 B/G）

**目标**：retrieval 执行后 emit evidence:retrieved + updateDomain("agent") + 通过 wrapNodeWithAudit 实现 evidenceChain 轮次隔离。

**改动文件**：`src/agents/nodes/retrieval.ts`、`src/agents/index.ts`（wrapNodeWithAudit）

**实施要点**：
- 从 config 取 OS 对象
- 在 searchKnowledgeDocuments 完成后 emit evidence:retrieved
- 同步更新 globalStateProvider.updateDomain("agent")，evidenceCount 在 wrapper return 前写入（不等流结束）
- wrapNodeWithAudit 在 retrieval 出口处调用 `updateDomain("agent", ...)`，evidenceCount 反映当前轮真实命中数
- 当前轮检索前，state.evidenceChain 被新结果自然覆盖（LangGraph state reducer：retrieval 节点返回 `{ evidenceChain: newResults }` 即替换上一轮旧证据）——轮次隔离由 retrieval 节点自身的返回行为保证，不需显式清空。但需验证 state reducer 行为

**验收**：验证清单 V5 (evidence:retrieved emit)、新增 V9 (evidenceChain 轮次隔离: Turn2 检索零命中后 reasoning 不读到 Turn1 证据)

### Task 4: reasoning 节点合流 + fallbackFlags 降级（断裂点 C/G）

**目标**：reasoning 消费 state.messages 中 ToolMessage + getSnapshot().execution + **读取 fallbackFlags 走降级 prompt**。

**改动文件**：`src/agents/nodes/reasoning.ts`

**时序语义**：reasoning 读到的 ToolMessage 来自 toolNode → intention 回环后的上一个 super-step，不是与 reasoning 同属一个 super-step。messages 在 LangGraph 中是累加的（每次回环追加 ToolMessage 而不清除），因此 reasoning 执行时 state.messages 已包含所有已执行工具的结果。功能上可工作，但实施者需明确这一时序差异。

**实施要点**：
- reasoning.ts 当前全文件零处 `state.messages` 引用——这是**新增一个完整输入源**，不是追加消费
- 从 state.messages 中提取 ToolMessage，提取工具名 + 执行结果摘要
- 从 config 取 getSnapshot().execution（含 lastToolName/lastToolStatus/lastToolDurationMs）
- 将工具结果摘要合并到 reasoning prompt 上下文（需新增 prompt 模板段落）
- **从 state.fallbackFlags 读取降级标志**：`ragEmpty === true` 时，prompt 注入 `[系统提示] 本轮RAG检索返回 0 条结果，基于模型知识回答，置信度较低。`
- **fallbackFlags 写入时机**：由 wrapNodeWithAudit 在 reasoning 入口处根据 `getSnapshot().agent.evidenceCount === 0` 写入 state.fallbackFlags
- 不改变 evidenceChain 消费逻辑

**验收**：验证清单 V4 (prompt 含 toolResultsCount > 0)

### Task 5: EVENT_CONSUMER_REGISTRY 补全

**目标**：注册 3 个缺失消费者。

**改动文件**：`src/caijuehub/strategies/event-consumer-strategies.ts`

**实施要点**：
- 新增 retrieval-context-consumer：订阅 action:proposed，策略 wait
- 新增 reasoning-context-consumer：订阅 evidence:retrieved + action:proposed，策略 wait
- 新增 tool-audit-consumer：订阅 action:proposed (tool_call)，策略 wait

**验收**：验证清单 V7 (registry.length >= 4)

### Task 6: PolicyUpdateLoop 工具感知

**目标**：evaluate() 能读取工具调用统计，产出含 toolCallSuccessRate 的决策。

**改动文件**：`src/agents/policy-update-loop.ts`

**实施要点**：
- evaluate() 新增 toolExecutionStats 参数
- 从 eventBus.getHistory() 中提取工具调用模式
- decisionReason 含 toolCallSuccessRate

**验收**：验证清单 V6 (decisionReason 含 toolCallSuccessRate)

### Task 7: 多租户隔离

**目标**：线程级隔离显式化。

**改动文件**：`src/agents/global-state.ts`、`src/agents/cognitive-event-bus.ts`

**实施要点**：
- GlobalSystemState.meta.tenantId 字段（Task 2 已完成类型定义）
- CognitiveEventBus.getHistory() 支持 filter: { threadId? }
- route.ts 中注入 sessionId 到 configurable

**验收**：getHistory({ threadId }) 返回当前会话事件

### Task 8: Agent OS Kernel 架构说明书（断裂点 D）

**目标**：补全缺失的架构文档。

**改动文件**：`docs/大田精准耕播智能决策系统/knowledge/01-架构/Agent-OS-Kernel-架构说明书.md`

**实施要点**：
- Linux 同构映射表
- OS 子系统清单与状态
- 新子系统注册规范
- 消费策略使用指南（pull/wait/skip/fallback 四种策略的含义、选择原则、适用场景）
- **消费者自查 vs OS Kernel 感知**（核心设计原则）：OS Kernel 负责"让数据实时可用"（横切接入后，节点出口写入域，下游消费者入口读到真实值而非过期数据）；消费者负责"决定何时消费"（通过 dependsOn 检查域是否就绪，而非重新读原始工具输出）。此原则是 EVENT_CONSUMER_REGISTRY 扩展指南的理论前提。
- **横切变更的 Spec 复用规范**：当变更不引入新类型、仅将已有 Spec 定义的类型接入管线节点时，可在 Plan 中声明 `Specs 策略: 无独立 Spec，上游 Spec <路径> 已覆盖类型定义`。此为 ADD 流程中 Plan 与 Spec 职责边界的正式约定。

**验收**：文档存在，覆盖 review §6.3 五项缺失 + 消费者自查原则 + Spec 复用规范

### Task 9: 编译验证 + Runtime 清单

**目标**：零新增类型错误，V1-V9 全部通过。

**验收**：
- `npx tsc --noEmit` 零新增错误
- V1-V9 全部 [R] 通过

---

## 五、验收标准

- [x] Task 1: ToolNode 包装器 emit action:proposed + updateDomain("execution")
- [x] Task 2: ExecutionStateSnapshot 扩展 + meta.tenantId
- [x] Task 3: retrieval emit evidence:retrieved + updateDomain("agent")
- [x] Task 4: reasoning prompt 含工具结果 + fallbackFlags 降级 prompt
- [x] Task 5: EVENT_CONSUMER_REGISTRY >= 4 个消费者
- [x] Task 6: PolicyUpdateLoop 能读取工具调用统计
- [x] Task 7: getHistory({ threadId }) 按会话过滤
- [x] Task 8: Agent OS Kernel 架构说明书存在（含行业三条分层线）
- [x] Task 9: `npx tsc --noEmit` 零新增 + V1-V9 全通过

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| Plan Review | `.qoder/reviews/farm-agent-os-kernel-wiring-plan-review-v1.md` |
| Runtime Review | `.qoder/reviews/farm-agent-expert-grounding-rag-adaptation-review-runtime-v2.md` |
| 上游 Spec | `.qoder/specs/farm-agent-global-state/` |
| ADD Route | `.qoder/plans/farm-agent-os-kernel-wiring-add-route-v1.md` |
| OS Kernel 架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/Agent-OS-Kernel-架构说明书.md` |
