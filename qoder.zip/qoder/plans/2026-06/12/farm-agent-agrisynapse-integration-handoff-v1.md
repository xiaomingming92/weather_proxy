# farm-agent-agrisynapse-integration-handoff

## Handoff 元信息

- 交接时间: 2026-06-08T10:00:00.000Z
- 关联 Plan: `.qoder/plans/farm-agent-agrisynapse-integration-plan-v1.md`
- 关联 Spec: `.qoder/specs/agrisynapse-farm-agent-integration/spec.md`
- 关联 Tasks: `.qoder/specs/agrisynapse-farm-agent-integration/tasks.md`
- 关联 Checklist: `.qoder/specs/agrisynapse-farm-agent-integration/checklist.md`
- 关联 Review: `.qoder/reviews/agrisynapse-farm-agent-integration-review2.md`
- 当前状态: 代码实施完成，编译验证通过，待运行时联调验收

---

## 1. 交接前状态

### 1.1 代码分布

| 文件 | 状态 |
|------|------|
| agrisynapse `src/views/llm/` | UI 框架完整但完全静态，硬编码 6 个 skillCards + 6 个 chips |
| agrisynapse `src/api/agent/` | 不存在 |
| agrisynapse `src/store/modules/agentChat.ts` | 不存在 |
| farm-agent `src/app/api/agent/[hash]/route.ts` | 已就绪，但认证逻辑硬编码 `requireRole()` + `getUserFromRequest()` |
| farm-agent `src/middleware.ts` | 不存在（proxy.ts 未注册） |
| farm-agent `src/caijuehub/strategies/` | 已有 10 个裁决点（policy 域），无认证/握手裁决 |

### 1.2 原始认证模型

```
agrisynapse → Authorization: Bearer {JWT} → farm-agent proxy → requireRole() + getUserFromRequest()
                                      → Farm-Server token 经 handshake 透传
```

---

## 2. 交接后状态（目标）

### 2.1 文件布局

```
agrisynapse/src/
├── api/agent/
│   ├── types.ts                    ← 新建: 请求/响应/SSE 类型定义
│   └── index.ts                    ← 新建: fetch-based 客户端（无 JWT）
├── store/modules/
│   └── agentChat.ts                ← 新建: Pinia Store 惰性握手+SSE流式
└── views/llm/
    ├── dashboard/index.vue         ← 修改: onMounted 仅 GET dashboard
    └── components/
        └── LlmChatView.vue         ← 修改: inline 渲染消息/证据/工具/裁决

farm-agent/src/
├── middleware.ts                   ← 新建: 注册 proxy.ts 为中间件
├── proxy.ts                        ← 修改: requireRole → resolveAuthGateway
├── app/api/agent/[hash]/route.ts   ← 修改: 裁决层替代硬编码
├── caijuehub/
│   ├── caijue.toml                 ← 修改: 10→12 裁决点
│   └── strategies/
│       ├── auth-gateway.ts         ← 新建: 多身份源认证网关
│       └── agrisynapse-handshake.ts← 新建: 握手 thread 路由裁决
└── lib/
    └── credential/
        └── service-token.ts        ← 新建: service 账户 token 管理
```

### 2.2 修订后认证模型

```
agrisynapse → hash-path (SHA-256) → farm-agent proxy → validateHash()
           → userVO (body)        → auth-gateway → mode: hash-only
                                                  → user: null (userId from body)
                                   → route.ts → resolveHandshakeThread({action, userId})
           → 不传任何 token
           
farm-agent 内部 → lib/credential/service-token.ts → Farm-Server
                (LLM 不可达，grep -r 验证通过)
```

---

## 3. 改动清单

| # | 文件 | 操作 | 说明 |
|---|------|------|------|
| 1 | agrisynapse `src/api/agent/types.ts` | CREATE | HandshakeRequest(action), ChatRequest(userId), SSEEvent(10种) |
| 2 | agrisynapse `src/api/agent/index.ts` | CREATE | fetch-based, 无 Authorization, Logger 全函数覆盖 |
| 3 | agrisynapse `src/store/modules/agentChat.ts` | CREATE | 惰性握手(resume→new), SSE事件分发, startNewChat |
| 4 | agrisynapse `src/views/llm/dashboard/index.vue` | MODIFY | onMounted 仅 getDashboard, 无 handshake |
| 5 | agrisynapse `src/views/llm/components/LlmChatView.vue` | MODIFY | inline 渲染: 消息气泡 + 证据条 + 工具调用 + 裁决面板 + SSE 输入框 |
| 6 | farm-agent `src/middleware.ts` | CREATE | 注册 proxy.ts 为 Next.js 中间件 |
| 7 | farm-agent `src/caijuehub/strategies/auth-gateway.ts` | CREATE | resolveAuthGateway → { mode: jwt\|hash-only, user } |
| 8 | farm-agent `src/caijuehub/strategies/agrisynapse-handshake.ts` | CREATE | resolveHandshakeThread({action, userId}) → { thread, isNew, auditAction } |
| 9 | farm-agent `src/proxy.ts` | MODIFY | requireRole → resolveAuthGateway, OPTIONS 放行 |
| 10 | farm-agent `src/app/api/agent/[hash]/route.ts` | MODIFY | handshake 调 resolveHandshakeThread, chat userId 按 auth mode |
| 11 | farm-agent `src/lib/agent-gateway-audit.ts` | MODIFY | 新增 GATEWAY_HANDSHAKE_RESUME_NO_THREAD |
| 12 | farm-agent `src/caijuehub/caijue.toml` | MODIFY | 10→12 裁决点 (新增 agrisynapse-handshake + auth-gateway) |
| 13 | farm-agent `src/lib/credential/service-token.ts` | CREATE | service 账户登录 Farm-Server, 缓存+5min提前刷新 |

---

## 4. 回滚方案

### 4.1 代码回滚

```bash
# agrisynapse 侧: 删除新建文件
rm agrisynapse/src/api/agent/types.ts
rm agrisynapse/src/api/agent/index.ts
rm agrisynapse/src/store/modules/agentChat.ts

# agrisynapse 侧: 恢复修改文件
git checkout -- agrisynapse/src/views/llm/dashboard/index.vue
git checkout -- agrisynapse/src/views/llm/components/LlmChatView.vue

# farm-agent 侧: 删除新建文件
rm src/middleware.ts
rm src/caijuehub/strategies/auth-gateway.ts
rm src/caijuehub/strategies/agrisynapse-handshake.ts
rm src/lib/credential/service-token.ts

# farm-agent 侧: 恢复修改文件
git checkout -- src/proxy.ts
git checkout -- src/app/api/agent/\[hash\]/route.ts
git checkout -- src/lib/agent-gateway-audit.ts
git checkout -- src/caijuehub/caijue.toml
```

### 4.2 数据回滚

handshake 创建的 ChatThread + UserProfile 记录无敏感数据，可保留或手动清理：
```sql
DELETE FROM "ChatThread" WHERE "id" LIKE 'thread_%';
DELETE FROM "UserProfile" WHERE "userId" IN (SELECT id FROM "User" WHERE "username" = '${SERVICE_USERNAME}');
```

---

## 5. 执行前置检查

- [x] farm-agent `npx tsc --noEmit` 通过
- [x] agrisynapse `vue-tsc --noEmit` 通过（仅 TS 7.0 废弃警告）
- [x] `grep -r "lib/credential" src/agents/` 无匹配（LLM 隔离验证）
- [x] agrisynapse 请求不携带 Authorization header
- [x] caijue.toml 新增 2 个裁决点已注册
- [ ] farm-agent 开发服务器可被 agrisynapse 访问（CORS / 同域 / 代理）

---

## 6. 执行步骤摘要

```
Task 0 (文档先行) ──┐
Task 1 (API 客户端) ─┤
Task 6 (跨域认证)   ─┤ 可并行
Task 8 (裁决层)    ──┤
Task 9 (凭证隔离)  ──┤
                    ▼
Task 2 (Store)     ──┐
                    ▼
Task 3 (仪表盘)    ──┤
Task 4 (消息组件)  ──┤ 可部分并行
                    ▼
Task 5 (流式聊天)  ──┘
                    ▼
Task 7 (编译验证)  ── ✅ 通过
```

**实施顺序**：按依赖图执行，Task 7 在全部完成后验证。Task 8-9 为 review2 新增架构修正。

---

## 7. 关键风险点

| 风险 | 概率 | 影响 | 缓解 |
|------|------|------|------|
| proxy.ts 未注册为中间件 | 高（已发生） | 高 | 已修复: 新建 `src/middleware.ts` 正确注册 |
| hash 种子不一致 | 中 | 高 | 双端 `HASH_SEED_TEXT` / `VITE_HASH_SEED_TEXT` 环境变量对齐 |
| CORS 预检失败 | 中 | 高 | next.config.ts headers() + proxy OPTIONS 放行 + middleware 注册 |
| agrisynapse hash 窗口与 farm-agent 不同步 | 低 | 中 | SHA-256 10分钟窗口 ±1 容差，handoff 带 nextHash |
| service token 环境变量未配置 | 中 | 中 | `getServiceToken()` 返回 null 时工具降级提示 |
| resume 返回 null 用户困惑 | 低 | 低 | GUI 自动 fallback 到 new（initSession 内处理） |

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

### 8.1 总体一键恢复

```
query_audit_logs({ keyword: "review2" })
```
→ 预期返回 6 条记录，覆盖 Task 8-9 全部文件

```
query_audit_logs({ keyword: "agrisynapse" })
```
→ 预期返回 17 条记录，覆盖全部 15 个代码文件 + 3 个文档

### 8.2 逐文件审计查询

| 文件 | query_audit_logs 调用 | 预期 |
|------|----------------------|------|
| agrisynapse types.ts | `query_audit_logs({ targetId: "agrisynapse/src/api/agent/types.ts" })` | CREATE + MODIFY |
| agrisynapse index.ts | `query_audit_logs({ targetId: "agrisynapse/src/api/agent/index.ts" })` | CREATE + MODIFY |
| agrisynapse agentChat.ts | `query_audit_logs({ targetId: "agrisynapse/src/store/modules/agentChat.ts" })` | CREATE + MODIFY |
| agrisynapse dashboard | `query_audit_logs({ targetId: "agrisynapse/src/views/llm/dashboard/index.vue" })` | MODIFY ×2 |
| LlmChatWelcome.vue | `query_audit_logs({ targetId: "agrisynapse/src/views/llm/components/LlmChatWelcome.vue" })` | COMPONENT_MODIFIED |
| LlmChatInput.vue | `query_audit_logs({ targetId: "agrisynapse/src/views/llm/components/LlmChatInput.vue" })` | COMPONENT_MODIFIED |
| LlmChatView.vue | `query_audit_logs({ keyword: "LlmChatView" })` | COMPONENT_MODIFIED |
| auth-gateway.ts | `query_audit_logs({ targetId: "src/caijuehub/strategies/auth-gateway.ts" })` | CREATE |
| agrisynapse-handshake.ts | `query_audit_logs({ targetId: "src/caijuehub/strategies/agrisynapse-handshake.ts" })` | CREATE |
| service-token.ts | `query_audit_logs({ targetId: "src/lib/credential/service-token.ts" })` | CREATE |
| middleware.ts | `query_audit_logs({ targetId: "src/middleware.ts" })` | CREATE |
| proxy.ts + route.ts + caijue.toml | `query_audit_logs({ keyword: "requireRole" })` | MODIFY (4 files) |
| next.config.ts + .env | `query_audit_logs({ keyword: "next.config" })` | COMPONENT_MODIFIED |
| tasks/checklist 验收 | `query_audit_logs({ keyword: "ADD Step 4" })` | MODIFY (2 files) |
| plan + handoff | `query_audit_logs({ targetId: ".qoder/plans/farm-agent-agrisynapse-integration-plan-v1.md" })` | CREATE + MODIFY ×2 |

### 8.3 SQL 管理员验证

```sql
-- 全量审计日志验证（覆盖 plan 13 项改动 + review2 新增）
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE "targetId" IN (
  'agrisynapse/src/api/agent/types.ts',
  'agrisynapse/src/api/agent/index.ts',
  'agrisynapse/src/store/modules/agentChat.ts',
  'agrisynapse/src/views/llm/dashboard/index.vue',
  'agrisynapse/src/views/llm/components/LlmChatWelcome.vue',
  'agrisynapse/src/views/llm/components/LlmChatInput.vue',
  'src/caijuehub/strategies/auth-gateway.ts',
  'src/caijuehub/strategies/agrisynapse-handshake.ts',
  'src/lib/credential/service-token.ts',
  'src/middleware.ts',
  '.qoder/plans/farm-agent-agrisynapse-integration-plan-v1.md'
)
ORDER BY "createdAt" DESC;
```

### 8.4 恢复判定标准

| 判定项 | 方法 | 通过标准 |
|--------|------|---------|
| 裁决层文件存在 | `ls src/caijuehub/strategies/auth-gateway.ts src/caijuehub/strategies/agrisynapse-handshake.ts` | 两个文件均存在 |
| proxy 调用裁决 | `grep "resolveAuthGateway" src/proxy.ts` | 有输出 |
| route 调用裁决 | `grep "resolveHandshakeThread" src/app/api/agent/\[hash\]/route.ts` | 有输出 |
| LLM 隔离 | `grep -r "lib/credential" src/agents/` | 无输出 |
| middleware 注册 | `ls src/middleware.ts` | 存在 |
| caijue.toml 完备 | `grep "agrisynapse-handshake\|auth-gateway" src/caijuehub/caijue.toml` | 两行均有输出 |
| 编译通过 | `npx tsc --noEmit` | 零错误 |
| agrisynapse 无 JWT | `grep "Authorization" agrisynapse/src/api/agent/index.ts` | 无 Bearer 相关输出 |
| LlmChatWelcome 审计 | `query_audit_logs({ targetId: "agrisynapse/src/views/llm/components/LlmChatWelcome.vue" })` | COMPONENT_MODIFIED |
| LlmChatInput 审计 | `query_audit_logs({ targetId: "agrisynapse/src/views/llm/components/LlmChatInput.vue" })` | COMPONENT_MODIFIED |
| 审计日志完备 | `query_audit_logs({ keyword: "agrisynapse" })` | ≥ 17 条 |

---

## 9. 后置确认

- [x] `npx tsc --noEmit` 编译通过
- [x] agrisynapse `vue-tsc --noEmit` 编译通过
- [x] `grep -r "lib/credential" src/agents/` LLM 隔离验证
- [x] caijue.toml 裁决点 10→12
- [x] 审计日志完整覆盖 15 个代码文件 + 3 个文档（`query_audit_logs({ keyword: "agrisynapse" })` ≥ 17 条）
- [x] LlmChatWelcome.vue 审计补录完成
- [x] LlmChatInput.vue 审计补录完成
- [x] targetId 路径格式规范已写入 project_rules.md（farm-agent + codein2027）
- [ ] 浏览器中 agrisynapse → /llm/dashboard → 真实技能卡片
- [ ] 发送消息 → SSE 流式 AI 回复 + 工具调用展示
- [ ] agrisynapse 无 JWT 请求 farm-agent 不返回 401

---

## 10. 跨 Session 变更: 知识库工程文档排除与向量 CRUD

### 10.1 背景

farm-agent 从 team-coordinator-agent 迁移时，ChromaDB `farm_agent` 集合带了旧项目的工程文档向量（PRD、架构说明书、API 接口文档等），污染 RAG 检索。

### 10.2 改动清单

| # | 文件 | 操作 | 说明 |
|---|------|------|------|
| 14 | `src/lib/audit-logger.ts` | MODIFY | 新增 `VECTOR_DELETE_START/DONE/FAIL` 审计阶段 |
| 15 | `src/services/knowledge-indexer.ts` | MODIFY | 新增 `listVectorFileNames()` + `deleteVectorsByFileName()`，加审计日志 |
| 16 | `src/constants/doc-status.ts` | MODIFY | `KNOWLEDGE_EXCLUDED_DIRS` 为唯一来源，`getExcludedFileNames()` 自动遍历推导 |
| 17 | `src/app/api/knowledge/vectors/route.ts` | CREATE | DELETE 三模式: `?fileName=` / `?path=`(递归) / `?cleanupExcluded=true` |
| 18 | `src/app/api/knowledge/vectors/files/route.ts` | CREATE | GET 向量文件列表，支持 `?excluded=true` 过滤 |
| 19 | `src/services/knowledge-sync.ts` | MODIFY | 传入 `doc.filePath`，命中排除目录自动标记 OUTDATED |
| 20 | `scripts/register-knowledge-files.ts` | MODIFY | 注册时检查 `isExcludedKnowledgeFile(fileName, filePath)` |
| 21 | `scripts/cleanup-engineering-vectors.ts` | MODIFY | 改调 API（走审计日志），支持 `--dry-run` / `--yes` |

### 10.3 排除规则设计

```
KNOWLEDGE_EXCLUDED_DIRS (唯一来源):
  ├── docs/大田精准耕播智能决策系统
  └── docs/农业智能体(把地种智能体)

getExcludedFileNames() → 遍历上述目录，自动推导文件名集合
isExcludedKnowledgeFile(name, filePath?) → filePath 前缀匹配，无 filePath 时靠外部传入的文件名集合
```

### 10.4 清理结果

```
ChromaDB farm_agent: 692 → 433 向量 (删除 259 个工程文档向量, 17 个文件)
审计日志: logs/knowledge-base/kb-audit.log (每次删除含 deleted/scanned/duration_ms)
```

### 10.5 恢复上下文审计查询

```
query_audit_logs({ targetId: "src/app/api/knowledge/vectors/route.ts" })
query_audit_logs({ targetId: "src/constants/doc-status.ts" })
query_audit_logs({ keyword: "VECTOR_DELETE" })
```
