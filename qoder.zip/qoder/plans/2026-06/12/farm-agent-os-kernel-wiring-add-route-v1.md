# farm-agent-os-kernel-wiring-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Review 的分析结论——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"，包含 `check_spec_sync` 文档-代码交叉校验。
>
> **绑定**：
> - Plan: `.qoder/plans/farm-agent-os-kernel-wiring-plan-v1.md`
> - Plan Review: `.qoder/reviews/farm-agent-os-kernel-wiring-plan-review-v1.md`
> - Runtime Review: `.qoder/reviews/farm-agent-expert-grounding-rag-adaptation-review-runtime-v2.md`（断裂点来源）
> - 上游 Spec: `.qoder/specs/farm-agent-global-state/`
> - 关联 add-route: 本 Plan 为 Expert Grounding RAG 适配的后续管线接入，上游 add-route: `.qoder/plans/farm-agent-Expert-Grounding-RAG适配-add-route-v1.md`（已完成）

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Plan Review 二元组齐全，更新受影响的项目文档。

**输入**：
- Plan Review: `.qoder/reviews/farm-agent-os-kernel-wiring-plan-review-v1.md`（P0 问题已回流）
- Runtime Review v2: `.qoder/reviews/farm-agent-expert-grounding-rag-adaptation-review-runtime-v2.md`
- 上游 Spec: `.qoder/specs/farm-agent-global-state/`

**动作**：
1. 确认 Plan Review 已生成 ✅
2. Plan Review 中 P0 问题（签名数量、验收标准V9、§3.3文档不一致）已回流至 Plan ✅
3. 无需新建 Spec——本次为 OS Kernel 内部横切变更（管线接入），上游 Spec `farm-agent-global-state` 覆盖了 OS Kernel 类型定义。实现细节由 Plan §3.2 文件变更清单 + Runtime Review §10 受影响文件清单共同定义

**产出**：
- [x] 验证并更新项目状态：Plan Review 已生成，P0 问题已回流
- [x] 验证并更新项目状态：Specs 覆盖声明——上游 Spec `farm-agent-global-state` 覆盖 OS Kernel 类型定义，本 Plan 为管线接入横切变更，无需独立 Spec。详见 Plan 元信息「Specs 策略」字段

### 原子闭包三可性判定（Step 0.7 产出）

> 执行时间：2026-06-11。

**业务功能**：Agent OS Kernel 管线接入——将 GlobalStateProvider / CognitiveEventBus / PolicyUpdateLoop 三组件的信号管线接入 LangGraph 图节点，修复 Runtime Review v2 识别的 7 个断裂点。

**原子闭包分析**：

| Task Group | 业务含义 | 独立交付业务价值？ |
|-----------|---------|-------------------|
| Task 1+2: ToolNode 包装器 + GlobalState 扩展 | ToolNode emit action:proposed + updateDomain("execution") | ❌ 只写不读——下游（reasoning/PolicyLoop）未接入，信号孤岛 |
| Task 3: retrieval OS 接入 + 证据隔离 | retrieval emit evidence:retrieved + evidenceChain 轮次隔离 | ❌ 无 ToolNode 信号 = OS 内核只看到 evidence，看不到 execution |
| Task 4: reasoning 合流 + 降级 | reasoning 消费 tools 结果 + fallbackFlags 降级 | ❌ 无 retrieval 实时 emit = getSnapshot().agent.evidenceCount 为旧值，降级误判 |
| Task 5: EVENT_CONSUMER_REGISTRY 补全 | 注册 3 个消费者 | ❌ 无事件可消费——注册表是空壳 |
| Task 6: PolicyUpdateLoop 工具感知 | evaluate() 读取 toolExecutionStats | ❌ 无 Task 1/5 产出 = toolExecutionStats 为空 |
| Task 7: 多租户隔离 | tenantId + getHistory filter | ❌ 对用户不可见——无独立业务价值，属于基础设施加固 |
| Task 8: OS Kernel 架构说明书 | 文档 | ❌ 文档不能独立交付——无代码落地验证 |
| Task 9: tsc + V1-V9 验证 | 编译验证 | ❌ 验证是 Task 1-8 的质检工序 |

```
原子闭包三可性判定
══════════════════
业务功能: Agent OS Kernel 管线接入（修复 7 断裂点，打通 ToolNode → RAG → reasoning → OS Kernel 四层信号链路）

拆分尝试: 任取一个 Task 独立交付 → 无独立业务价值
  - 单交 Task 1+2: ToolNode 写 execution 域但下游不读，无感知
  - 单交 Task 1+2+3: retrieval 也写 agent 域，但 reasoning 不读 fallbackFlags，证据轮次隔离不生效
  - 单交 Task 1+2+3+4: 核心信号链路打通，但消费者注册表缺失，PolicyLoop 无工具感知
  - 单交 Task 7: 多租户字段加上了但无写入方使用，无法验证

判定结论: ✅ 单轮原子闭包
  Task 1-9 共同构成 "OS Kernel 管线接入" 的最小业务闭包，
  任一 Task 单独交付均无法闭环——信号链路从 emit → consume → 决策是完整链，断裂任意一环则全部失效。

可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
(整体作为单轮，四可性在全部 Task 完成后一起满足)
```

**Handoff 模式判定**：单轮 → 使用现有 `handoff-single-round-template.md`。

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的所有审计阶段，扩展 `AgentAuditPhase`。

**输入**：
- Plan §2 方案选型（config 注入通道 + ToolNode 包装策略）
- Plan §3.2 文件变更清单（9 个文件）
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase` 联合类型

**动作**：
1. 在 `AgentAuditPhase` 中新增：
   - `OS_KERNEL_TOOL_EMIT` — ToolNode 包装器 emit action:proposed
   - `OS_KERNEL_TOOL_STATE` — ToolNode 包装器 updateDomain("execution")
   - `OS_KERNEL_EVIDENCE_EMIT` — retrieval 节点 emit evidence:retrieved
   - `OS_KERNEL_EVIDENCE_STATE` — retrieval 出口 updateDomain("agent")
   - `OS_KERNEL_REASONING_MERGE` — reasoning 消费 state.messages 工具结果
   - `OS_KERNEL_FALLBACK_FLAG` — wrapNodeWithAudit 写入 fallbackFlags（reasoning 入口）
   - `OS_KERNEL_CONSUMER_READY` — resolveEventConsumerReadiness 调用
   - `OS_KERNEL_SESSION_FILTER` — getHistory({ threadId }) 过滤

**产出**：
- [x] 验证并更新项目状态：本次审计阶段清单已同步

| Phase | 使用场景 | Task |
|-------|---------|------|
| `OS_KERNEL_TOOL_EMIT` | ToolNode 包装器 emit action:proposed | Task 1 |
| `OS_KERNEL_TOOL_STATE` | ToolNode 包装器 updateDomain("execution") | Task 1 |
| `OS_KERNEL_EVIDENCE_EMIT` | retrieval emit evidence:retrieved | Task 3 |
| `OS_KERNEL_EVIDENCE_STATE` | retrieval 出口 updateDomain("agent") | Task 3 |
| `OS_KERNEL_REASONING_MERGE` | reasoning 合流 state.messages | Task 4 |
| `OS_KERNEL_FALLBACK_FLAG` | wrapNodeWithAudit 注入 fallbackFlags | Task 3/4 |
| `OS_KERNEL_CONSUMER_READY` | consumer 就绪判定 | Task 5 |
| `OS_KERNEL_SESSION_FILTER` | getHistory filter | Task 7 |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用，上层无需修改。

**输入**：
- `src/lib/agent-audit-logger.ts`（`agentAudit()` + `agentAuditNodeStart/End/Error`）
- `src/lib/layer2-callback.ts`（`AuditCallback extends BaseCallbackHandler`）

**动作**：
1. 确认 `agentAudit()` 接受 Step 1 新增字面量（需 Step 1 先扩展 `AgentAuditPhase`）
2. 确认 trident 三通道正常（console + file + DB）

**产出**：
- [x] 验证并更新项目状态：`agentAudit()` 通道确认可用，仅需扩展 `AgentAuditPhase` 联合类型

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan Task 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

**输入**：
- Plan §4 实施步骤 + 依赖图（Task 1-9）
- Plan §3.2 文件变更清单
- Runtime Review §2 断裂点分析

**动作**：

### §3.0 前置守卫（重型强制）

调用 `check_add_route_status({ planKeyword: "os-kernel-wiring" })` 确认 add-route 就位。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | ToolNode 包装器 + config 传递链路 | `src/agents/index.ts` + `src/app/api/agent/chat/stream/route.ts` | `OS_KERNEL_TOOL_EMIT` / `OS_KERNEL_TOOL_STATE` | 2 个 | 无 | ✅ |
| 2 | GlobalState 扩展 | `src/agents/global-state.ts` | 无（类型定义） | — | 无 | ✅ |
| 3 | retrieval OS 接入 + 证据隔离 | `src/agents/nodes/retrieval.ts` + `src/agents/index.ts`(wrapNodeWithAudit) | `OS_KERNEL_EVIDENCE_EMIT` / `OS_KERNEL_EVIDENCE_STATE` / `OS_KERNEL_FALLBACK_FLAG` | 3 个 | Task 1/2 | ✅ |
| 4 | reasoning 合流 + 降级 | `src/agents/nodes/reasoning.ts` + `src/agents/index.ts`(addNode) + `src/agents/state.ts` | `OS_KERNEL_REASONING_MERGE` / `OS_KERNEL_FALLBACK_FLAG` | 2 个 | Task 1/2/3 | ✅ |
| 5 | EVENT_CONSUMER_REGISTRY 补全 | `src/caijuehub/strategies/event-consumer-strategies.ts` | `OS_KERNEL_CONSUMER_READY` | 1 个 | Task 3/4 | ✅ |
| 6 | PolicyUpdateLoop 工具感知 | `src/agents/policy-update-loop.ts` | 无（签名扩展） | — | Task 1/5 | ✅ |
| 7 | 多租户隔离 | `src/agents/global-state.ts` + `src/agents/cognitive-event-bus.ts` + `src/app/api/agent/chat/stream/route.ts` | `OS_KERNEL_SESSION_FILTER` | 1 个 | 无 | ✅ |
| 8 | OS Kernel 架构说明书 | `docs/.../Agent-OS-Kernel-架构说明书.md` | 无（纯文档） | — | Task 1-7 | ✅ |
| 9 | 编译验证 + V1-V9 | `npx tsc --noEmit` | 无（编译） | — | Task 1-8 | ✅ |

### 依赖拓扑

```
Task 1 (ToolNode 包装器) ──┬──→ Task 3 (retrieval OS接入)
Task 2 (GlobalState 扩展) ──┤         │
                             │         ├──→ Task 4 (reasoning 合流)
                             │         │         │
                             │         └──┬──────┘
                             │            ▼
                             │     Task 5 (Consumer 补全)
                             │            │
                             ├────────────┼──→ Task 6 (PolicyLoop 工具感知)
                             │            │
Task 7 (多租户隔离) ──────────┤            │
                             │            │
                             └────────────┴──→ Task 8 (OS Kernel 架构说明书)
                                                   │
                                                   ▼
                                             Task 9 (tsc + V1-V9)
```

**产出**：
- [x] 验证并更新项目状态：全部 Task 1-8 已实现并 tsc 通过
- [x] 验证并更新项目状态：每个文件有 `record_dev_operation` 记录

---

## Step 3.5：实现审查

**目的**：代码完成后，验证意图与实现无语义鸿沟（ADD-10）。

**动作**：
1. 逐项验证 Plan §五 验收标准 V1-V9
2. 生成 `review-implementation.md`
3. 调用 `check_spec_sync` 确认文档-代码一致（上游 Spec `farm-agent-global-state`）

**产出**：
- [x] 验证并更新项目状态：V1-V9 全部通过
- [x] 验证并更新项目状态：`review-implementation.md` 已生成
- [x] 验证并更新项目状态：`check_spec_sync` 通过（横切变更无独立Spec，上游 farm-agent-global-state 覆盖）

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**动作**：
1. `npx tsc --noEmit` —— 零新增类型错误
2. 调用 `check_phase_symmetry` 验证阶段标记完整性（Step 1 定义的 8 个 Phase 是否全部使用）
3. 调用 `check_failure_path` 验证降级路径审计等价
   - fallbackFlags 零命中降级路径：retrieval 零命中 → fallbackFlags.ragEmpty=true → reasoning 降级 prompt
   - ToolNode 空工具路径：无 tool_calls → 跳过 ToolNode → execution.toolCallsCount=0
4. 调用 `check_spec_sync`

**产出**：
- [x] `tsc --noEmit` 通过（零新增错误）
- [x] 阶段对称性验证通过
- [x] 失败路径审计等价验证通过
- [x] 验证并更新项目状态：`check_spec_sync` 通过（仅 Handoff 缺失阻断，Step 8 产出）

---

## Step 5：AI 自动合规检查

**目的**：扫描全部修改文件的 ADD-1~ADD-7 合规性。

**动作**：
1. 对每个 TS 修改文件调用 `check_add_compliance`
2. 汇总合规报告

**产出**：
- [x] 验证并更新项目状态：合规报告已生成（10/10 文件检查完成）
- [x] 验证并更新项目状态：违规项处理决策已记录（route.ts PolicyUpdateLoop catch 补充 agentAuditError）

---

## Step 6：从审计数据定位问题

> **仅当 Step 4/5 发现异常时进入。**

---

## Step 7：修复并验证

> **仅当 Step 6 发现问题时进入。**

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**目的**：功能收敛判定，更新 Handoff，回架构文档做最终校准。

**动作**：
1. **收敛判断**：V1-V9 全部通过 + tsc 零新增 + EventBus timeline 含 action:proposed/evidence:retrieved 事件 + fallbackFlags 降级路径可验证 → 功能收敛
2. 调用 `check_spec_sync` 做最终交叉校验
3. Handoff 更新（单轮 handoff-single-round-template）
4. Step 0 第二阶段：回架构文档 `Agent-OS-Kernel-架构说明书.md` 校准，确保与代码实现一致
5. ADD-7 回查：审计策略表（Plan 元信息表格）全部状态更新为"已实施"

**产出**：
- [x] 验证并更新项目状态：收敛判定结果（V1-V9 全通过，tsc 零新增，RAHS 100）
- [x] 验证并更新项目状态：`check_spec_sync` 四者一致确认（Handoff 已创建，回滚覆盖完整）
- [x] 验证并更新项目状态：Handoff 已更新
- [x] 验证并更新项目状态：架构文档已校准（Agent-OS-Kernel-架构说明书.md 318 行）
- [x] 验证并更新项目状态：ADD-7 审计记录已落库确认（10/10 文件）

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/agents/index.ts` | MODIFY | 1/3 | CODE | ✅ |
| `src/agents/global-state.ts` | MODIFY | 2/7 | CODE | ✅ |
| `src/agents/state.ts` | MODIFY | 3/4 | CODE | ✅ |
| `src/agents/nodes/retrieval.ts` | MODIFY | 3 | CODE | ✅ |
| `src/agents/nodes/reasoning.ts` | MODIFY | 4 | CODE | ✅ |
| `src/caijuehub/strategies/event-consumer-strategies.ts` | MODIFY | 5 | CODE | ✅ |
| `src/agents/policy-update-loop.ts` | MODIFY | 6 | CODE | ✅ |
| `src/agents/cognitive-event-bus.ts` | MODIFY | 7 | CODE | ✅ |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY | 1/7 | CODE | ✅ |
| `src/lib/agent-audit-logger.ts` | MODIFY | Step 1 | CODE | ✅ |
| `docs/.../Agent-OS-Kernel-架构说明书.md` | CREATE | 8 | DOC | ✅ |
| `.qoder/reviews/farm-agent-os-kernel-wiring-plan-review-v1.md` | CREATE | Step 0 | DOC | ✅ |
| `.qoder/plans/farm-agent-os-kernel-wiring-handoff-v1.md` | CREATE | Step 8 | DOC | ✅ |
