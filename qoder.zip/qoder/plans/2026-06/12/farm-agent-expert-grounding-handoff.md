# farm-agent — Expert Grounding RAG 适配 交接手册

> **适用场景**：单轮变更。将 Expert Grounding 从概念层下沉到 ChromaDB 索引层 + 裁决层 per-expert topK 分配。

---

## 1. 交接前状态

- ChromaDB：单 `farm_agent` collection，全量文档混存
- 检索：`searchKnowledgeDocuments(query, topK, undefined, mergedWhere)` 全局搜索 + 合并 cateId 过滤
- 证据归属：cateId → `cateIdToExpertIds` 反向映射（间接，多 Expert 共享 cateId 时歧义）
- 裁决层：`RetrieveBudget` 仅有全局 `topK`，无 per-expert 分配
- `getChromaCollection()` 为私有单例，不支撑多 collection

---

## 2. 交接后状态（目标）

- ChromaDB：3 个 Expert collection（`expert_crop_compare` / `expert_roi_analysis` / `expert_pest_risk`）+ 保留 `farm_agent` 为 fallback
- 检索：per-expert 并行循环，`Promise.all` 每人用自己的 topK + collection/where
- 证据归属：直接标注 `expertIds: [expertId]`（出生即标注，无歧义）
- 裁决层：`RetrieveBudget.perExpertTopK: Record<expertId, number>`，核心 5 / 汇总 10
- `getChromaCollection(collectionName?)` 为 public 导出，支撑 registry 和 retrieval 双端调用

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/agents/experts/filter-types.ts` | 修改 | 新增 `GroundingStatus` 接口 |
| 2 | `src/agents/experts/registry.ts` | 修改 | `AnalysisExpert` 新增 `grounding` 字段；3 个 Expert 配置 collectionName + ready() |
| 3 | `src/caijuehub/strategies/sub-intent.ts` | 修改 | `RetrieveBudget` 新增 `perExpertTopK`；`resolveRetrieveBudget()` per-expert 分配 |
| 4 | `src/services/knowledge-indexer.ts` | 修改 | `getChromaCollection()` 导出 + 多 collection Map；`searchKnowledgeDocuments()` options 签名 + `collectionName` 路由 |
| 5 | `src/agents/nodes/retrieval.ts` | 修改 | per-expert `Promise.all` 循环；移除 `mergeExpertEvidenceFilters` + `cateIdToExpertIds`；直接标注 `expertIds` |
| 6 | `src/agents/types/index.ts` | 修改 | `Evidence` 新增 `grounding` 字段 |
| 7 | `src/lib/agent-audit-logger.ts` | 修改 | 新增 3 个 `AgentAuditPhase`（`EXPERT_GROUNDING_READY/DEGRADED/COLLECTION_SEARCH`） |
| 8 | `scripts/init-chroma-collection.ts` | 修改 | 新增多 collection 创建/同步函数 |
| 9 | `src/agents/nodes/intention.ts` | 修改 | 新增 `KEYWORD_EXPERT_MAP` 关键词→Expert 映射兜底激活 |

### 运行时缺陷修复（2026-06-11）

| # | 文件 | 修复内容 |
|---|------|---------|
| B1 | `src/agents/nodes/retrieval.ts` | L122 `activeExperts.map()`→`expertIds.map()`，使 `subIntentPlan` fallback 生效 |
| B2 | `src/agents/nodes/retrieval.ts` | 空 expert 时回退 `searchKnowledgeDocuments(searchQuery, 5)` 全局检索 |
| B3 | `src/api/agent/contracts/dashboard-contract.ts` | `resolveKeywordExperts()` 改为从 `DASHBOARD_SKILL_CARDS.description` 片段匹配推导（覆盖技能卡片+技能中心双场景） |
| B4 | `src/agents/nodes/intention.ts` | `ensureAnalysisContext()` 空壳兜底：`state.analysisContext` 为 null 时创建合法空壳 Context，防止三路径（explicitExpertId/LLM/关键词兜底）的 `activateExpert()` 被短路丢弃 |

---

## 4. 回滚方案

### 代码回滚

```bash
git reset --hard <commit>
```

### 数据回滚

- 文档迁移用复制非移动 → 原 `farm_agent` collection 数据完整
- 回滚只需切回 `where` 子句检索路径（retrieval 节点保留降级分支）
- 3 个 Expert collection 可保留不删（不影响旧路径运行）

---

## 5. 执行前置检查

- [ ] ChromaDB 集群可用（本地 + VPS 双端）
- [ ] `npx tsc --noEmit` 当前无 Expert Grounding 相关错误
- [ ] 全量 `farm_agent` collection 中文档数 ≥ 1
- [ ] `rag-audit-stacktrace` Plan 的 evidence.expertIds 已就绪

---

## 6. 执行步骤摘要

```text
Task 1 (init-chroma) ── 创建 3 个 Expert collection
            │
            ▼
Task 2 (registry) ── AnalysisExpert + grounding
       │
       ├──────────────────────┐
       ▼                      ▼
Task 3 (filter-types)    Task 4 (sub-intent)
  GroundingStatus           perExpertTopK
       │                      │
       └──────────┬───────────┘
                  ▼
Task 5 (knowledge-indexer) ── getChromaCollection 多 collection
       │
       ▼
Task 6 (knowledge-indexer) ── searchKnowledgeDocuments options 签名
       │
       ├──────────────────────┐
       ▼                      ▼
Task 7 (retrieval)       Task 8 (types/evidence)
  per-expert 循环           grounding 字段
       │                      │
       └──────────┬───────────┘
                  ▼
Task 9 (retrieval) ── source + grounding 写入
       │
       ▼
Task 10 (验证) ── 本地 + VPS 端到端
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| `searchKnowledgeDocuments` 签名变更破坏现有调用方 | test 文件和旧代码编译失败 | 逐一更新调用方；test 文件 `searchKnowledgeDocuments("test query")` 保持兼容 |
| per-expert `Promise.all` 并行导致 embedding 服务 QPS 超限 | 检索超时或失败 | 3 个 Expert × 每人 1 次 embedding = 最多 3 并发，QPS 风险低 |
| 裁决层 `perExpertTopK` 新增字段导致下游类型不匹配 | retrieval 节点读取 `perExpertTopK[expertId]` 时报 undefined | `NULL_PLAN` 包含 `perExpertTopK: {}`；retrieval 节点兜底 `plan.retrievalBudget.topK` |
| `agri_tech` 被 6 个 Expert 共享，文档复制冗余 | 约 16MB+ 额外存储 | 首期接受；长期评估引用方案 |

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用，直接复制粘贴调用即可。

### 总体一键恢复

```text
query_audit_logs({ keyword: "Expert-Grounding" })
```
→ 预期返回本 Plan 所有 ADD-7 记录

### 逐文件审计查询

```text
query_audit_logs({ targetId: "src/caijuehub/strategies/sub-intent.ts" })
→ 预期返回 DOC_MODIFIED: RetrieveBudget + perExpertTopK

query_audit_logs({ targetId: "src/services/knowledge-indexer.ts" })
→ 预期返回 DOC_MODIFIED: getChromaCollection 多 collection + searchKnowledgeDocuments 签名

query_audit_logs({ targetId: "src/agents/nodes/retrieval.ts" })
→ 预期返回 DOC_MODIFIED: per-expert 循环检索

query_audit_logs({ targetId: "src/agents/experts/registry.ts" })
→ 预期返回 DOC_MODIFIED: AnalysisExpert + grounding

query_audit_logs({ keyword: "GroundingStatus" })
→ 预期返回 DOC_MODIFIED: filter-types 类型定义
```

### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE action IN (
  'DOC_CREATED',
  'DOC_MODIFIED',
  'CODE_MODIFIED'
)
AND "targetId" LIKE '%expert-grounding%'
ORDER BY "createdAt" DESC;
```

### 恢复判定标准

- action 命中数 ≥ 7（6 个代码文件 + specs 三元组 + add-route + handoff）
- grep 验证命令：

```bash
grep -R "perExpertTopK" src/caijuehub/
grep -R "GroundingStatus" src/agents/experts/
grep -R "collectionName" src/services/
```

---

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过
- [x] `resolveRetrieveBudget(["pest_risk", "daily_report"])` → `perExpertTopK.pest_risk === 5` 且 `perExpertTopK.daily_report === 10`
- [R] 手动 API 调用：3 个 Expert 的 collection 检索 + 降级路径 + evidence 格式
- [R] VPS（rfai）端到端验证
- [x] 所有文件改动已记录 ADD-7 审计（`query_audit_logs` 可回查）
- [x] B1-B4 运行时缺陷已修复（retrieval.ts + intention.ts，2026-06-11/12）
- [x] review-runtime.md §🐛 已登记 B1-B4 缺陷-修复-验证三元组
- [x] tasks.md Task Group F 已记录 B1-B4
- [x] checklist.md 运行时缺陷修复验证 § 已添加
