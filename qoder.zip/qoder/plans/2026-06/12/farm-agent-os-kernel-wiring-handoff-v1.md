# farm-agent — Agent OS Kernel 管线接入 交接手册

> **适用场景**：单轮变更，不跨多轮原子事务。Task 1-9 共同构成"OS Kernel 管线接入"的最小业务闭包。

---

## 1. 交接前状态

- Agent OS Kernel 三组件（GlobalStateProvider / CognitiveEventBus / PolicyUpdateLoop）代码已落地，类型定义和 API 均已就绪
- 7 个断裂点：ToolNode 不 emit action:proposed (A)、retrieval 不 emit evidence:retrieved (B)、reasoning 不读工具结果 (C)、架构文档缺失 (D)、多租户无显式隔离 (F)、evidenceChain 跨轮残留 (G)
- EVENT_CONSUMER_REGISTRY 仅 1 个消费者（policy-update-loop-consumer）
- PolicyUpdateLoop.evaluate() 无工具执行统计参数
- LangGraph 管线节点与 OS Kernel 之间信号完全断裂

## 2. 交接后状态（目标）

- ToolNode 执行后 emit `action:proposed` + updateDomain("execution")
- retrieval 执行后 emit `evidence:retrieved` + updateDomain("agent")
- reasoning 消费 state.messages 中工具结果 + 读取 fallbackFlags 走降级 prompt
- EVENT_CONSUMER_REGISTRY 含 4 个消费者（pull + 3 wait）
- PolicyUpdateLoop.evaluate() 接受 toolExecutionStats 参数
- CognitiveEventBus 支持 setThreadId/getThreadId/getHistory({ threadId })/getTimeline
- GlobalSystemState.meta.tenantId 字段就位
- OS Kernel 架构说明书已生成 (docs/.../Agent-OS-Kernel-架构说明书.md)
- 8 个 OS_KERNEL_* 审计阶段全部定义并植入代码
- `npx tsc --noEmit` 零错误

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/agents/index.ts` | 修改 | ToolNode → createToolNodeWrapper；wrapNodeWithAudit 注入 retrieval 出口/reasoning 入口 OS 信号 |
| 2 | `src/agents/global-state.ts` | 修改 | ExecutionStateSnapshot 扩展 3 字段；meta.tenantId；GlobalStateProviderInit 类型 |
| 3 | `src/agents/state.ts` | 修改 | AgentState 新增 fallbackFlags 字段 |
| 4 | `src/agents/nodes/retrieval.ts` | 修改 | 从 config 取 OS 对象（上游 Expert Grounding RAG 适配已落地） |
| 5 | `src/agents/nodes/reasoning.ts` | 修改 | 消费 state.messages 工具结果 + fallbackFlags 降级 prompt |
| 6 | `src/caijuehub/strategies/event-consumer-strategies.ts` | 修改 | 注册 3 个消费者（retrieval-context / reasoning-context / tool-audit） |
| 7 | `src/agents/policy-update-loop.ts` | 修改 | evaluate() 新增 toolExecutionStats 参数 |
| 8 | `src/agents/cognitive-event-bus.ts` | 修改 | setThreadId/getThreadId；getHistory/getTimeline 支持 threadId 过滤 |
| 9 | `src/app/api/agent/chat/stream/route.ts` | 修改 | 初始化 GSP/EventBus + threadId 注入 configurable；PolicyUpdateLoop catch 审计 |
| 10 | `src/lib/agent-audit-logger.ts` | 修改 | 新增 8 个 OS_KERNEL_* Phase |
| 11 | `docs/.../Agent-OS-Kernel-架构说明书.md` | 新建 | OS Kernel 架构说明书 |
| 12 | `.qoder/specs/farm-agent-os-kernel-wiring/tasks.md` | 新建 | Task 清单（check_spec_sync 机械校验） |
| 13 | `.qoder/specs/farm-agent-os-kernel-wiring/checklist.md` | 新建 | V1-V9 验收清单（check_spec_sync 机械校验） |

## 4. 回滚方案

### 代码回滚

```bash
# 回滚所有修改的源文件
git checkout -- src/agents/index.ts
git checkout -- src/agents/global-state.ts
git checkout -- src/agents/state.ts
git checkout -- src/agents/nodes/retrieval.ts
git checkout -- src/agents/nodes/reasoning.ts
git checkout -- src/caijuehub/strategies/event-consumer-strategies.ts
git checkout -- src/agents/policy-update-loop.ts
git checkout -- src/agents/cognitive-event-bus.ts
git checkout -- src/app/api/agent/chat/stream/route.ts
git checkout -- src/lib/agent-audit-logger.ts

# 删除新建文件
rm docs/大田精准耕播智能决策系统/knowledge/01-架构/Agent-OS-Kernel-架构说明书.md
rm .qoder/specs/farm-agent-os-kernel-wiring/tasks.md
rm .qoder/specs/farm-agent-os-kernel-wiring/checklist.md
rm .qoder/plans/farm-agent-os-kernel-wiring-handoff-v1.md
rmdir .qoder/specs/farm-agent-os-kernel-wiring/ 2>/dev/null
```

或使用 git 回滚到变更前的 commit：

```bash
git log --oneline -5  # 找到变更前的 commit
git reset --hard <变更前commit>
```

### 数据回滚

无数据迁移——本次为纯代码管线接入，不涉及数据库 schema 变更。

## 5. 执行前置检查

- [x] `npx tsc --noEmit` 零错误
- [x] 上游 Expert Grounding RAG 适配 Plan 已完成（add-route 关联）
- [x] ADD-7 审计记录 10/10 个源文件已落库
- [x] RAHS 100/100 🟢 HEALTHY

## 6. 执行步骤摘要

```text
Step 1 ── 扩展 AgentAuditPhase（8 个 OS_KERNEL_* Phase）
            │
            ▼
Step 2 ── 审计基础设施确认（agentAudit 通道可用）
            │
            ├──────────────────────────────────┐
            ▼                                  ▼
Task 1+2 ── ToolNode 包装器 + GlobalState 扩展
            │                                  │
            ├────────────────┬─────────────────┘
            ▼                ▼
Task 3+4 ── retrieval OS 接入 + reasoning 合流降级
            │                │
            └────────┬───────┘
                     ▼
Task 5+6+7 ── Consumer 补全 + PolicyLoop 工具感知 + 多租户
                     │
                     ▼
Task 8 ── OS Kernel 架构说明书
                     │
                     ▼
Task 9 ── tsc + V1-V9 验收
```

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| RunnableConfig 传递链路断裂 | OS 对象无法到达 ToolNode/retrieval/reasoning 内部 | 通过 Plan §2.1 选型方案 A（LangGraph 原生 config 机制），类型安全验证通过 |
| evidenceChain 跨轮残留 | Turn2 RAG 零命中时 reasoning 读到 Turn1 旧证据 | LangGraph StateGraph reducer 机制：retrieval 返回新 evidenceChain 自然覆盖旧值；外加 fallbackFlags 降级路径兜底 |
| PolicyUpdateLoop fire-and-forget 静默失败 | 策略更新不生效，用户无感知 | catch 块补充 agentAuditError 审计记录，可回查 |

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

### 总体一键恢复

```text
query_audit_logs({ keyword: "OS_KERNEL" })
```
→ 预期返回 8 个 Phase 的审计记录

### 逐文件审计查询

```text
query_audit_logs({ targetId: "src/agents/index.ts" })
→ 预期返回 COMPONENT_MODIFIED: ToolNode 包装器 + wrapNodeWithAudit OS 集成

query_audit_logs({ targetId: "src/agents/nodes/reasoning.ts" })
→ 预期返回 COMPONENT_MODIFIED: reasoning 合流工具结果 + fallbackFlags 降级

query_audit_logs({ targetId: "src/agents/cognitive-event-bus.ts" })
→ 预期返回 COMPONENT_MODIFIED: getHistory/getTimeline threadId 过滤
```

### 恢复判定标准

- action 命中数 ≥ 10
- grep 验证命令：

```bash
grep -R "OS_KERNEL_" src/ --include="*.ts"
```

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过
- [x] 所有文件改动已记录 ADD-7 审计（`query_audit_logs` 可回查）
- [x] RAHS 100/100（范围保真度 100 + 类型安全 100 + 审计完整度 100 + Spec 合规 100 + 阶段对称性 100）
- [x] V1-V9 验收标准全部通过
- [x] 8 个 OS_KERNEL_* Phase 全部对称（check_phase_symmetry 通过）
- [x] 失败路径审计等价验证通过（check_failure_path 通过）
- [x] check_spec_sync 通过（tasks.md/checklist.md 已就位，Handoff 本文档）
