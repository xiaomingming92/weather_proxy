# PLAN：farm-agent Podman 数据卷拆离项目，统一 `$HOME/data/farm-agent`

## PLAN 元信息

- **Plan 名称**: farm-agent-podman数据卷拆离统一-datadir-v1
- **启动时间**: 2026-05-29T10:00:00+08:00
- **主导 AI**: Trae (ADD 范式)
- **参考 precedent**: co-agent 已完成同类改造（`co-agent-podman数据卷拆离统一-datadir-v1`）
- **关联文档**:
  - Execution: `.qoder/plans/farm-agent-podman数据卷拆离统一-datadir-execution-v1.md`
  - Handoff: `.qoder/plans/farm-agent-podman数据卷拆离统一-datadir-handoff-v1.md`
  - Specs: `.qoder/specs/farm-agent-podman-datadir-v1/`（spec.md + tasks.md + checklist.md）
  - Review: `.qoder/reviews/farm-agent-chroma-persistence-runtime-review-v1.md`（runtime-review-v1 触发 Task 12）

- **ADD-7 审计策略**:

| # | 文件 | targetType | action | beforeState | afterState |
|---|------|-----------|--------|------------|-----------|
| 1 | podman-compose.yml | CONFIG | CONFIG_PATH_VAR_FARM | volumes 硬编码 `./data/postgres`, `./data/chroma` | volumes: `${DATA_DIR}/postgres`, `${DATA_DIR}/chroma` |
| 2 | docker-compose.yml | CONFIG | CONFIG_DOCKER_FARM_NAMING | co-agent 遗留 docker-compose.yml（team-coordinator 命名 + 旧 Chroma 0.4.24 + 旧 auth API + 硬编码凭据） | 改造为 farm-agent 命名 + Chroma 1.5.9 + new auth API + ${DATA_DIR} + ${POSTGRES_PASSWORD}/${CHROMA_AUTH_TOKEN}（凭据值见 `.env.development`/`.env.production`） |
| 3 | db-ensure.sh | SCRIPT | SCRIPT_FIX_CONTAINER_REF | 引用 `team-coordinator-*`、`team_admin`、`team_coordinator`、硬编码 chroma token `team-coordinator-*-token` | 引用 `farm-agent-*`、`farm_admin`、`farm_agent`、`${CHROMA_AUTH_TOKEN}` + DATA_DIR 导出 |
| 4 | db-ensure.bat | SCRIPT | SCRIPT_FIX_CONTAINER_REF | 引用 `team-coordinator-postgres`, `team_admin`, `team_coordinator` | 引用 `farm-agent-postgres`, `farm_admin`, `farm_agent` |
| 5 | start-db.sh | SCRIPT | SCRIPT_FIX_CONTAINER_REF | 引用 `team-coordinator-postgres`, `team_admin`, `team_coordinator` + `mkdir -p data/postgres` | 引用 `farm-agent-postgres`, `farm_admin`, `farm_agent` + export DATA_DIR + 删除 mkdir |
| 6 | start-db.bat | SCRIPT | SCRIPT_FIX_CONTAINER_REF | 引用 `team-coordinator-postgres`, `team_admin`, `team_coordinator` + `mkdir data\postgres` | 引用 `farm-agent-postgres`, `farm_admin`, `farm_agent` |
| 7 | stop-db.sh | SCRIPT | SCRIPT_FIX_CONTAINER_REF | 引用 `team-coordinator-postgres`, `team-coordinator-chroma` | 引用 `farm-agent-postgres`, `farm-agent-chroma` |
| 8 | stop-db.bat | SCRIPT | SCRIPT_FIX_CONTAINER_REF | 引用 `team-coordinator-postgres`, `team-coordinator-chroma` | 引用 `farm-agent-postgres`, `farm-agent-chroma` |
| 9 | start-infrastructure.sh | SCRIPT | SCRIPT_FIX_CONTAINER_REF | 引用 chroma collection `team_coordinator` + 硬编码 chroma token | 引用 chroma collection `farm_agent` + `${CHROMA_AUTH_TOKEN}` + 端口 5433/8001 |
| 10 | db-status.sh | SCRIPT | SCRIPT_FIX_CONTAINER_REF | 引用 `team-coordinator-postgres` + 端口 8000 | 引用 `farm-agent-postgres` + 端口 8001 |
| 11 | db-wait.sh | SCRIPT | SCRIPT_FIX_CONTAINER_REF | 引用 `team-coordinator-postgres`, `team_admin`, `team_coordinator` | 引用 `farm-agent-postgres`, `farm_admin`, `farm_agent` |
| 12 | `podman-compose.yml` | CONFIG | CONFIG_ENV_VAR_CREDENTIALS | `POSTGRES_PASSWORD`、`CHROMA_AUTHN_CREDENTIALS` 硬编码 | `${POSTGRES_PASSWORD}`、`${CHROMA_AUTH_TOKEN}`，值见 `.env.development`/`.env.production` |
| 13 | `docker-compose.yml` | CONFIG | CONFIG_ENV_VAR_CREDENTIALS | `POSTGRES_PASSWORD`、`AUTH_TOKENS`/`AUTH_CREDENTIALS` 硬编码 | `${POSTGRES_PASSWORD}`、`${CHROMA_AUTH_TOKEN}` |
| 14 | `.env.development` | CONFIG | CONFIG_ENV_FILE_CREATE | 不存在 | 新建，定义 `POSTGRES_PASSWORD`、`CHROMA_AUTH_TOKEN` 等（已 gitignored） |
| 15 | `.env.production` | CONFIG | CONFIG_ENV_FILE_CREATE | 不存在 | 新建，同上 |
| 16 | 本地 `$HOME/data/farm-agent/` | FILESYSTEM | DATA_MIGRATE_FARM | 不存在 | 新建 + 如有数据则迁移 |
| 17 | 本地 `./data/` | FILESYSTEM | DATA_PERM_CHMOD_FARM | 容器 owner 权限 | `chmod -R a+rX` 保留历史 |

---

## Step 0：文档先行

### 0.1 变更影响分析

| 维度 | 分析 |
|------|------|
| **变更类型** | 基础设施配置重构 — 容器数据卷路径从项目内 `./data/` 拆离到 `$HOME/data/farm-agent/`；容器/DB 引用从 co-agent 命名修正为 farm-agent 命名 |
| **影响范围** | `podman-compose.yml` + `docker-compose.yml` + `db-ensure.sh/.bat` + `start-db.sh/.bat` + `stop-db.sh/.bat` + 本地文件系统 |
| **业务接口** | 无变更 |
| **外部合约** | 无变更 |
| **数据库 Schema** | 无变更 |
| **数据安全** | ⚠️ 涉及容器数据迁移，必须保留备份 + 回滚方案 |

### 0.2 文档搜索结果

`find_related_docs` 搜索无业务文档匹配 — 这是部署基础设施层面变更。

### 0.3 文档更新说明

**跳过理由（ADD-0.1）**：纯基础设施配置重构，不涉及业务接口、合约、外部行为变更。

### 0.4 项目内 data/ 处理原则（重要）

**与 co-agent 一致**：项目内 `./data/` 改权限保留作历史记录，不删除。

```bash
chmod -R a+rX ./data/     # 所有人可读，保留原目录结构
# 项目新容器挂载 $HOME/data/farm-agent/，不再读取 ./data/
```

### 0.5 数据集隔离保证

farm-agent 与 co-agent 数据**天然隔离**，通过不同的 `$HOME` 子目录：

```
co-agent:   $HOME/data/co-agent/postgres/  (容器端口 5432)
farm-agent: $HOME/data/farm-agent/postgres/ (容器端口 5433)
```

两个项目的 compose 文件使用不同的容器名、网络名、DB 名、用户名、密码，互不干扰。

---

## Step 1：功能分析与变更范围定义

### 1.1 当前问题（现状分析）

#### 问题 1：podman-compose.yml 硬编码项目内路径

```yaml
volumes:
  - ./data/postgres:/var/lib/postgresql/data:Z
  - ./data/chroma:/chroma/chroma:Z
```

co-agent 已改造为 `${DATA_DIR}/postgres`，farm-agent 尚未改造。

#### 问题 2：docker-compose.yml 是 co-agent 遗留副本

[分析见下文 1.2 节]

#### 问题 3：全部脚本引用 co-agent 容器名（9 个脚本，25 处引用）

| 文件 | 当前引用 |
|------|---------|
| `db-ensure.sh` | `team-coordinator-postgres`, `team-coordinator-chroma`, `team_admin`, `team_coordinator`, 硬编码 chroma token (L80-81 fallback path), chroma collection `team_coordinator` (L111) |
| `db-ensure.bat` | `team-coordinator-postgres`, `team_admin`, `team_coordinator` |
| `start-db.sh` | `team-coordinator-postgres`, `team_admin`, `team_coordinator` |
| `start-db.bat` | `team-coordinator-postgres`, `team_admin`, `team_coordinator` |
| `stop-db.sh` | `team-coordinator-postgres`, `team-coordinator-chroma` |
| `stop-db.bat` | `team-coordinator-postgres`, `team-coordinator-chroma` |
| `start-infrastructure.sh` | chroma collection `team_coordinator` (L49), 硬编码 chroma token (L50), 端口 5432/8000 |
| `db-status.sh` | `team-coordinator-postgres` (L14), 端口 8000 (L19) |
| `db-wait.sh` | `team-coordinator-postgres`, `team_admin`, `team_coordinator` (L15) |

这些脚本应该引用 `farm-agent-postgres`、`farm-agent-chroma`、`farm_admin`、`farm_agent`、`${CHROMA_AUTH_TOKEN}`。

**凭据隔离原则**：所有敏感凭据（密码、token）定义在 `.env.development` / `.env.production`（已 gitignored），compose 文件和脚本通过 `${ENV_VAR}` 引用。

`detect-runtime.sh` 和 `detect-runtime.bat` 是运行时检测库，不引用具体容器名，不受影响。

### 1.2 docker-compose.yml 问题分析

`docker-compose.yml` 完全使用 co-agent 的命名（`team-coordinator-postgres`、`team_admin`、`team_coordinator`、`team-coordinator-chroma`、`team-network`），ChromaDB 版本也是旧的 `0.4.24`，使用旧版 Chroma auth API。

而 `podman-compose.yml` 已正确配置为 farm-agent 命名（`farm-agent-postgres`、`farm_admin`、`farm_agent`、`farm-agent-chroma`、`farm-agent-network`），ChromaDB 版本为 `1.5.9`，使用新版 auth API。

**farm-agent 是对外项目，必须同时支持 Docker 和 Podman**。`docker-compose.yml` 不能删除，需要与 `podman-compose.yml` 完全对齐：

| 维度 | docker-compose.yml（当前） | 目标 |
|------|--------------------------|------|
| 镜像前缀 | 无（`postgres:16-alpine`） | 保持无前缀（Docker 默认从 docker.io 拉取） |
| 容器名 | `team-coordinator-postgres/chroma` | `farm-agent-postgres/chroma` |
| 端口映射 | `5432:5432`, `8000:8000` | `5433:5432`, `8001:8000` |
| 数据卷 | `./data/postgres`, `./data/chroma` | `${DATA_DIR}/postgres`, `${DATA_DIR}/chroma` |
| DB 名 | `team_coordinator` | `farm_agent` |
| 用户 | `team_admin` | `farm_admin` |
| 密码 | `team_secure_pass_2024`（硬编码） | `${POSTGRES_PASSWORD}`（值见 `.env.development`/`.env.production`） |
| 网络 | `team-network` | `farm-agent-network` |
| Chroma 版本 | `0.4.24` | `1.5.9`（与 podman-compose.yml 对齐） |
| Chroma auth | 旧 API（`TokenAuthServerProvider`） | 新 API（`TokenAuthnProvider`） |
| Chroma token | `team-coordinator-secret-token-2026`（硬编码） | `${CHROMA_AUTH_TOKEN}`（值见 `.env.development`/`.env.production`） |
| Healthcheck | `CMD-SHELL` | `CMD`（与 podman-compose.yml 对齐） |
| Volumes SELinux | 无 `:Z` | 保持无 `:Z`（Docker 不需要 SELinux 标签） |

### 1.3 设计原则

```
不写死 /home/xmm/ 或 /home/ai/
        ↓
用 $HOME 动态推导: $HOME/data/farm-agent
        ↓
本地 xmm → /home/xmm/data/farm-agent/
VPS  ai   → /home/ai/data/farm-agent/
任何机器 → /home/$USER/data/farm-agent/
        ↓
.env 文件中不设置 DATA_DIR，由脚本运行时从 $HOME 推导
```

### 1.4 DATA_DIR 的来源策略

| 场景 | DATA_DIR 来源 | 值示例 |
|------|--------------|--------|
| `db-ensure.sh` | `DATA_DIR="${DATA_DIR:-$HOME/data/farm-agent}"` | `/home/xmm/data/farm-agent` |
| `start-db.sh` | `export DATA_DIR="${DATA_DIR:-$HOME/data/farm-agent}"` | `/home/xmm/data/farm-agent` |
| `podman-compose` | 从 shell 继承 `DATA_DIR`（由脚本 export） | 取决于调用者 |

`.env` 文件中**不设置** `DATA_DIR`，避免写死用户名。

### 1.5 变更清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `podman-compose.yml` | MODIFY | `volumes:` `./data/` → `${DATA_DIR}/` |
| 2 | `docker-compose.yml` | MODIFY | 改造为 farm-agent 命名 + Chroma 1.5.9 + ${DATA_DIR} + 端口/DB/用户/密码全部与 podman-compose.yml 对齐 |
| 3 | `db-ensure.sh` | MODIFY | 修正容器/DB 引用 + DATA_DIR 动态推导 |
| 4 | `db-ensure.bat` | MODIFY | 修正容器/DB 引用 |
| 5 | `start-db.sh` | MODIFY | 修正容器/DB 引用 + export DATA_DIR + 删除 `mkdir -p data/postgres` |
| 6 | `start-db.bat` | MODIFY | 修正容器/DB 引用 |
| 7 | `stop-db.sh` | MODIFY | 修正容器引用 |
| 8 | `stop-db.bat` | MODIFY | 修正容器引用 |
| 9 | `start-infrastructure.sh` | MODIFY | 修正 chroma collection/token 引用 + 端口对齐 |
| 10 | `db-status.sh` | MODIFY | 修正容器引用 + 端口对齐 |
| 11 | `db-wait.sh` | MODIFY | 修正容器/DB 引用 |
| 12 | `podman-compose.yml` | MODIFY | 凭据 `${POSTGRES_PASSWORD}` / `${CHROMA_AUTH_TOKEN}` 化 |
| 13 | `docker-compose.yml` | MODIFY | 同上 |
| 14 | `.env.development` | CREATE | 新建，定义敏感凭据（已 gitignored） |
| 15 | `.env.production` | CREATE | 新建，同上 |
| 16 | 本地 `./data/` | CHMOD | `chmod -R a+rX` 保留历史 |
| 17 | 本地 `$HOME/data/farm-agent/` | CREATE+MIGRATE | 新建目录 + 如有数据则迁移 |

### 1.6 不受影响的文件

- TypeScript 业务代码（全部无关）
- Prisma Schema
- Next.js 配置
- `detect-runtime.sh`, `detect-runtime.bat`（运行时检测库，不引用具体容器名）
- `.env` 文件（不新增 DATA_DIR 变量）

---

## Step 2：审计基础设施

**不涉及新业务代码，无需创建审计日志器。** 通过 ADD-7 开发操作审计覆盖。

---

## Step 3：实施概要（详见 execution + handoff）

1. `podman-compose.yml` → `${DATA_DIR}` + `${POSTGRES_PASSWORD}`/`${CHROMA_AUTH_TOKEN}` 化
2. `docker-compose.yml` → 全面 farm 化（容器名/DB/Chroma/端口） + `${DATA_DIR}` + 凭据 `${ENV_VAR}` 化
3. `db-ensure.sh` → 修正容器/chroma collection/auth token 引用 + DATA_DIR 动态推导
4. `db-ensure.bat` → 修正容器/DB 引用
5. `start-db.sh` → 修正容器/DB 引用 + export DATA_DIR + 删除 `mkdir -p data/postgres`
6. `start-db.bat` → 修正容器/DB 引用
7. `stop-db.sh` → 修正容器引用
8. `stop-db.bat` → 修正容器引用
9. `start-infrastructure.sh` → 修正 chroma collection/token 引用 + 端口
10. `db-status.sh` → 修正容器引用 + 端口
11. `db-wait.sh` → 修正容器/DB 引用
12. `.env.development` / `.env.production` → 新建（凭据在此，已 gitignored）
13. 本地迁移：chmod data/ + cp 到 `$HOME/data/farm-agent/`
14. 本地验证
15. 推送提交

---

## Step 4：验证检查

### 4.1 本地

- [ ] `podman inspect` 挂载源 = `/home/xmm/data/farm-agent/postgres`
- [ ] `npm run dev` 启动成功
- [ ] `ls -la ./data/` 目录存在且可读（历史记录）
- [ ] `${DATA_DIR}` 未被写死在任何 .env 文件中
- [ ] `grep -rn "team-coordinator" scripts/` 无残留引用
- [ ] `grep -rn "team_admin" scripts/` 无残留引用
- [ ] `grep -rn "team_coordinator" scripts/` 无残留引用

### 4.2 CI

farm-agent 当前无 `.gitlab-ci.yml`，无需 CI 验证。

---

## Step 5：合规检查

| 条件 | 判定 |
|------|------|
| 无硬编码用户名 | ✅ `$HOME` 动态推导 |
| 容器/DB 引用一致（全部 farm-agent 命名） | 待验证 |
| 项目内 data/ 保留为历史 | ✅ chmod 不删除 |
| ADD-7 审计记录完整 | 待记录 |
| handoff 齐全 | 待创建 |
| 与 co-agent 数据集隔离 | ✅ 不同 `$HOME` 子目录 + 不同端口/容器名/DB 名 |

---

## Step 6：收敛判断

| 条件 | 判定 |
|------|------|
| 本地 `$HOME/data/farm-agent/` 挂载成功 | 待验证 |
| 项目 `./data/` 保留可读 | 待验证 |
| 脚本无 co-agent 残留引用 | 待验证 |
| 无硬编码路径残留 | 待验证 |
| compose 无硬编码凭据残留 | 待验证 |
| .env.development / .env.production 已创建 | 待验证 |
| docker-compose.yml 已全面 farm 化 | 待验证 |

---

## 回滚方案

### 代码回滚

```bash
cd ~/ai/farm-agent
git reset --hard <回滚到的 commit>
```

### 数据回滚

数据安全：`$HOME/data/farm-agent/` 和 `./data/` 两处都有数据（迁移后 chmod 只读），最坏情况从 `./data/` 恢复：

```bash
cp -a ./data/postgres/* $HOME/data/farm-agent/postgres/
cp -a ./data/chroma/* $HOME/data/farm-agent/chroma/
```

### 回滚风险

- **低风险**：代码回滚仅影响 compose + 脚本文件，数据始终在磁盘上
- **回滚后验证**：`podman inspect` 确认挂载路径 + 服务 HTTP 200
