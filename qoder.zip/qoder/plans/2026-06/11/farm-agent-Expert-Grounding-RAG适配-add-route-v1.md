# farm-agent-Expert-Grounding-RAG适配-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"，包含 `check_spec_sync` 文档-代码交叉校验。
>
> **绑定**：
> - Plan: `farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md`
> - Review: `farm-agent-expert-grounding-rag-adaptation-plan-review-v1.md`
> - Spec: `.qoder/specs/farm-agent-expert-grounding/spec.md`
> - Tasks: `.qoder/specs/farm-agent-expert-grounding/tasks.md`
> - Checklist: `.qoder/specs/farm-agent-expert-grounding/checklist.md`
> - Handoff: `.qoder/plans/farm-agent-expert-grounding-handoff.md`（待建）

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全，项目文档反映即将实现的变更。

**输入**：
- Review: `farm-agent-expert-grounding-rag-adaptation-plan-review-v1.md`
- Plan: `farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md`
- 上游 RAG 基座: `rag-audit-stacktrace-plan-v1.md`（已交付 evidence.expertIds + cateIdToExpertIds）

**动作**：
1. 确认 Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md` ✅
2. 调用 `find_related_docs` 检索受影响的架构/规范/需求文档 ✅
3. 更新 Review 文档，新增裁决层 per-expert topK 缺口（P1 #8）✅
4. 确认 Handoff 就绪（含 round 边界、ADD-7 策略表、回滚方案）⏳

**产出**：
- [x] 验证并更新项目状态：Specs 三元组路径确认（见绑定）
- [x] 验证并更新项目状态：项目文档已更新（Review §3.2 新增 P1 #8，§4.1 新增 sub-intent.ts，§4.2 数据流更新，§5 执行顺序更新）
- [x] 验证并更新项目状态：Handoff 就绪

### 原子闭包三可性判定（Step 0.7 产出）

> 执行时间：2026-06-11。按 ADD 规范"每轮原子闭包"原则——原子闭包是指**业务上不可再拆分的最小价值单元**，不是按代码依赖拆轮。

**业务功能**：per-expert 独立 RAG 检索 + 证据归属直标

**原子闭包分析**：

| Task Group | 业务含义 | 独立交付业务价值？ |
|-----------|---------|-------------------|
| A: Collection分片 | 创建 3 个 Expert ChromaDB collection | ❌ 建了不用 = 空 collection，无用户可感知价值 |
| B: Registry + perExpertTopK | 注册 grounding 字段 + 裁决层 per-expert 分配 | ❌ 只有类型和配置，检索路径未切换 = 死代码 |
| C: 检索路径切换 | `retrieval.ts` 从全局检索改为 per-expert 循环 | ❌ 无 collection 可用 = 全部降级，功能退化 |
| D: 证据链升级 | Evidence 加 grounding 字段 + 直接标注 expertIds | ❌ 无 per-expert 检索产物 = 字段永为空 |
| E: 渐进验证 | 本地 + VPS 端到端验证 | ❌ 无可验证的功能 = 空验证 |

```
原子闭包三可性判定
══════════════════
业务功能: per-expert 独立 RAG 检索 + 证据归属直标
Task Groups: A→B→C→D→E (全部为同一业务功能的实现步骤)

拆分尝试: 任取一个 Group 独立交付 → 无独立业务价值
  - 单交 A: 3 个空 collection，无用户感知
  - 单交 A+B: 类型+配置就绪，检索路径未切，无效果
  - 单交 A+B+C: 检索切换完成但证据链未升级，evidence 归属仍间接
  - 单交 D: 字段定义，无写入方

判定结论: ✅ 单轮原子闭包
  A+B+C+D+E 共同构成 "per-expert RAG 检索" 的最小业务闭包，
  五者不可拆分——任缺其一，业务价值不完整。

可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
(整体作为单轮，四可性在全部 Task 完成后一起满足)
```

**Handoff 模式判定**：单轮 → 使用现有 `handoff-single-round-template.md`。

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的所有审计阶段，扩展 `AgentAuditPhase`。

**输入**：
- Plan §3 架构设计（Grounding 检查 → Collection 检索 → 降级 → 证据打标）
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase` 联合类型

**动作**：
1. 在 `AgentAuditPhase` 中新增：
   - `EXPERT_GROUNDING_READY` — grounding 就绪，走 collection 检索
   - `EXPERT_GROUNDING_DEGRADED` — grounding 降级，走 evidenceFilter
   - `EXPERT_COLLECTION_SEARCH` — per-collection 检索完成
   - `EXPERT_SEARCH_EMPTY` — per-expert 检索无结果（第10轮补充）
   - `EXPERT_SEARCH_RESULT` — per-expert 检索返回（第10轮补充）
   - `EXPERT_DEDUP` — 跨 Expert chunkId 去重归并（第10轮补充）

**产出**：
- [x] 验证并更新项目状态：本次审计阶段清单已同步到 tasks.md Step 1 区域

| Phase | 使用场景 | Task |
|-------|---------|------|
| `EXPERT_GROUNDING_READY` | grounding.ready() 返回 true | C3 |
| `EXPERT_GROUNDING_DEGRADED` | grounding.ready() 返回 false | C3 |
| `EXPERT_COLLECTION_SEARCH` | per-collection 检索完成 | C3 |
| `EXPERT_SEARCH_EMPTY` | per-expert 检索无结果 | C3 |
| `EXPERT_SEARCH_RESULT` | per-expert 检索返回 | C3 |
| `EXPERT_DEDUP` | 去重归并 | C3 |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用。

**输入**：
- `src/lib/agent-audit-logger.ts`
- 现有辅助函数：`agentAuditRetrieval`、`agentAudit`

**动作**：
1. 确认 `agentAudit()` 接受 Step 1 新增字面量
2. 确认三通道输出正常

**产出**：
- [x] 验证并更新项目状态：`agentAudit()` 通道确认可用，状态已同步到 checklist.md ADD 规则合规项

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan Task 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

**输入**：
- Plan §4 实施步骤（Phase 1-5）
- `tasks.md` Task 清单
- Spec §Requirements 4 个 WHEN-THEN 场景

**动作**：

### §3.0 前置守卫（重型强制）

调用 `check_add_route_status({ planKeyword: "Expert-Grounding" })` 确认 add-route 就位。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | Collection 创建与文档迁移 | `scripts/migrate-expert-collections.ts`（新建） | 无（运维脚本） | — | 无 | ✅ |
| 2 | Registry 扩展（grounding 字段） | `src/agents/experts/registry.ts` | 无（接口定义） | — | 无 | ✅ |
| 3 | GroundingStatus 类型定义 | `src/agents/experts/filter-types.ts` | 无（类型定义） | — | 无 | ✅ |
| 4 | **裁决层 perExpertTopK 分配** | `src/caijuehub/strategies/sub-intent.ts` | 无（裁决逻辑） | — | Task 2 | ✅ |
| 5 | getChromaCollection 多 collection | `src/services/knowledge-indexer.ts` | 无（基础设施） | — | Task 1 | ✅ |
| 6 | searchKnowledgeDocuments 签名扩展 | `src/services/knowledge-indexer.ts` | `agentAudit("RAG_SEARCH", ...)` | — | Task 5 | ✅ |
| 7 | retrieval 节点 per-expert 并行循环 | `src/agents/nodes/retrieval.ts` | `EXPERT_GROUNDING_READY`、`EXPERT_GROUNDING_DEGRADED`、`EXPERT_SEARCH_EMPTY`、`EXPERT_SEARCH_RESULT`、`EXPERT_DEDUP` | 5 个新 Phase | Task 2/4/6 | ✅ |
| 8 | Evidence grounding 字段扩展 | `src/agents/types/index.ts` | 无（类型定义） | — | 无 | ✅ |
| 9 | retrieval 节点写入 source + grounding + expertIds 直标 | `src/agents/nodes/retrieval.ts` | 复用 Task 7 审计点 | — | Task 7/8 | ✅ |
| 10 | 渐进迁移验证 | `scripts/migrate-expert-collections.ts` | 无（运维脚本） | — | Task 1/7 | ✅ |

### 依赖拓扑

```
Task 1 ──→ Task 5 ──→ Task 6 ──→ Task 7 ──→ Task 9
Task 2 ──→ Task 4 ──→ Task 7                    │
Task 3 ──→ Task 2                               │
Task 8 ─────────────────────────────────────────┘
Task 10 依赖 Task 1/7
```

**产出**：
- [x] 验证并更新项目状态：全部 Task 1-10 已实现并 tsc 通过
- [x] 验证并更新项目状态：每个文件有 `record_dev_operation` 记录
- [x] 验证并更新项目状态：`checklist.md` 已手动同步，tasks.md 已完成项已逐项勾选

---

## Step 3.5：实现审查

**目的**：代码完成后，验证意图与实现无语义鸿沟（ADD-10）。

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 执行跨项目联调检查
3. 生成 `review-implementation.md` + `review-runtime.md`
4. 调用 `check_spec_sync` 确认文档-代码一致

**产出**：
- [x] 验证并更新项目状态：`checklist.md` 全部 `[T]` 项已通过并勾选
- [x] 验证并更新项目状态：`review-implementation.md` 已生成
- [x] 验证并更新项目状态：`review-runtime.md` 已生成（含 `[R]` 待验证清单）
- [x] 验证并更新项目状态：`check_spec_sync` 通过

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. `npm run lint` —— 无新增 lint 问题
3. 调用 `check_phase_symmetry` 验证阶段标记完整性
4. 调用 `check_failure_path` 验证降级路径审计等价
5. 调用 `check_spec_sync`

**产出**：
- [x] `tsc --noEmit` 通过（Expert Grounding 相关文件零错误）
- [x] `npm run lint` 通过
- [x] 阶段对称性验证通过
- [x] 失败路径审计等价验证通过
- [x] 验证并更新项目状态：`check_spec_sync` 通过

---

## Step 5：AI 自动合规检查

**目的**：扫描全部修改文件的 ADD-1~ADD-7 合规性。

**动作**：
1. 对每个 TS 修改文件调用 `check_add_compliance`
2. 汇总合规报告

**产出**：
- [x] 验证并更新项目状态：合规报告已生成，违规项处理决策已记录
- [x] 验证并更新项目状态：`checklist.md` ADD 规则合规检查项已同步勾选

---

## Step 6：从审计数据定位问题

> **仅当 Step 4/5 发现异常时进入。**

---

## Step 7：修复并验证

> **仅当 Step 6 发现问题时进入。**

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**目的**：功能收敛判定，更新 Handoff，回架构文档做最终校准。

**动作**：
1. **收敛判断**：全部 `[T]` 项通过 + `[R]` 清单已生成 + grounding 降级路径可用 + perExpertTopK 分配正确 → 功能收敛
2. `tasks.md` 全部 Task 已完成 + 全部子项已勾选
3. 调用 `check_spec_sync` 做最终交叉校验
4. Handoff 更新
5. Step 0 第二阶段：回架构文档校准
6. ADD-7 回查

**产出**：
- [x] 验证并更新项目状态：收敛判定结果
- [x] 验证并更新项目状态：`tasks.md` + `checklist.md` 全部完成项已勾选
- [x] 验证并更新项目状态：`check_spec_sync` 四者一致确认
- [x] 验证并更新项目状态：Handoff 已更新
- [x] 验证并更新项目状态：架构文档已校准
- [x] 验证并更新项目状态：ADD-7 审计记录已落库确认

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `scripts/migrate-expert-collections.ts` | CREATE | 1 | SCRIPT | ✅ |
| `src/agents/experts/registry.ts` | MODIFY | 2 | CODE | ✅ |
| `src/agents/experts/filter-types.ts` | MODIFY | 3 | CODE | ✅ |
| `src/caijuehub/strategies/sub-intent.ts` | MODIFY | 4 | CODE | ✅ |
| `src/services/knowledge-indexer.ts` | MODIFY | 5/6 | CODE | ✅ |
| `src/agents/nodes/retrieval.ts` | MODIFY | 7/9 | CODE | ✅ |
| `src/agents/types/index.ts` | MODIFY | 8 | CODE | ✅ |
| `src/lib/agent-audit-logger.ts` | MODIFY | Step 1 | CODE | ✅ |
| `.qoder/specs/farm-agent-expert-grounding/spec.md` | CREATE | Step 0 | SPEC | ✅ |
| `.qoder/specs/farm-agent-expert-grounding/tasks.md` | CREATE | Step 0 | SPEC | ✅ |
| `.qoder/specs/farm-agent-expert-grounding/checklist.md` | CREATE | Step 0 | SPEC | ✅ |
| `.qoder/plans/farm-agent-expert-grounding-handoff.md` | CREATE | Step 8 | DOC | ⬜ |
