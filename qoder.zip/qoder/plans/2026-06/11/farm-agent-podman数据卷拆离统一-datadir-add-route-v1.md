# farm-agent-podman数据卷拆离统一-datadir-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **绑定**：
> - Plan: `.qoder/plans/farm-agent-podman数据卷拆离统一-datadir-plan-v1.md`
> - Spec: `.qoder/specs/farm-agent-podman-datadir-v1/spec.md`
> - Tasks: `.qoder/specs/farm-agent-podman-datadir-v1/tasks.md`
> - Checklist: `.qoder/specs/farm-agent-podman-datadir-v1/checklist.md`
> - Handoff: `.qoder/plans/farm-agent-podman数据卷拆离统一-datadir-handoff-v1.md`
> - Execution: `.qoder/plans/farm-agent-podman数据卷拆离统一-datadir-execution-v1.md`
> - Review: `.qoder/reviews/farm-agent-chroma-persistence-runtime-review-v1.md`

---

## 执行历史说明

本 Plan 首轮执行时**未生成 specs 三元组和 add-route**（仅有 Plan + Execution + Handoff），导致执行链路不可控、执行结果漂移——Task 1-11 的 volume Source 端（`${DATA_DIR}`）全部正确落地，但 Destination 端（`/chroma/chroma` vs `PERSIST_DIRECTORY: "/data"`）对齐验证完全缺失。runtime-review-v1 通过 `collectionCount: 0` 暴露根因后，补建了 specs 三元组，现补建 add-route 并执行 Task 12（ChromaDB 持久化修复）。

| 阶段 | 状态 | 说明 |
|------|------|------|
| 首轮执行（Task 1-11） | ✅ 已完成 | 无 specs/add-route，执行漂移 |
| specs 补建 | ✅ 已完成 | runtime-review-v1 触发 |
| add-route 补建（本文档） | ✅ 已完成 | Step 0.5 |
| Task 12 执行 | ✅ 已完成 | 本地 + VPS 双端完成 |
| Step 3.5—Step 8 闭环 | ✅ 已完成 | 2026-06-11，含 MCP 盲区诊断 |

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全，项目文档反映即将实现的变更。

**动作**：
1. 确认 Specs 三元组就绪 ✅：
   - `spec.md` — 4 个 Requirement（数据卷路径变量化、docker-compose 全面 farm 化、脚本引用 farm 化、凭据隔离）
   - `tasks.md` — 12 个 Task（Task 1-11 ✅，Task 12 ⬜）
   - `checklist.md` — 对应检查项
2. 调用 `find_related_docs` 检索受影响的文档 → 纯基础设施配置变更，无业务文档受影响 ✅
3. Handoff 就绪 ✅（含 round 边界、ADD-7 策略表、回滚方案）
4. Review 就绪 ✅（`farm-agent-chroma-persistence-runtime-review-v1.md`，§5.1 修复方案）

**产出**：
- [x] Specs 三元组路径确认
- [x] 项目文档更新（无需更新声明 — 纯基础设施配置）
- [x] Handoff 就绪
- [x] Review 就绪

**状态**：✅ 已完成

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的所有审计阶段，扩展 `AgentAuditPhase`。

**分析**：本次变更是纯基础设施配置（compose 文件 + shell 脚本 volume 路径修正），不涉及业务逻辑，无需扩展 `AgentAuditPhase` 联合类型。

**产出**：
- [x] 本次审计阶段清单：无新增 Phase（通过 ADD-7 `record_dev_operation` 覆盖）

**状态**：✅ 已完成（无需修改）

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用，无需新建 logger 文件。

**分析**：本次变更不涉及业务代码中的审计日志植入。变更审计通过 MCP 工具 `record_dev_operation`（ADD-7 开发操作审计）覆盖。

**产出**：
- [x] `agentAudit()` 通道确认 — 本次无需使用

**状态**：✅ 已完成（无需修改）

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Specs Tasks 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | podman-compose.yml 路径变量化 + 凭据 ENV_VAR 化 | `podman-compose.yml` | `record_dev_operation(CONFIG)` | — | 无 | ✅ |
| 2 | docker-compose.yml 全面 farm 化 | `docker-compose.yml` | `record_dev_operation(CONFIG)` | — | 无 | ✅ |
| 3 | db-ensure.sh 全面修正引用 + DATA_DIR | `scripts/db-ensure.sh` | `record_dev_operation(SCRIPT)` | — | 无 | ✅ |
| 4 | db-ensure.bat 修正容器引用 | `scripts/db-ensure.bat` | `record_dev_operation(SCRIPT)` | — | 无 | ✅ |
| 5 | start-db.sh 修正引用 + DATA_DIR | `scripts/start-db.sh` | `record_dev_operation(SCRIPT)` | — | 无 | ✅ |
| 6 | start-db.bat 修正容器引用 | `scripts/start-db.bat` | `record_dev_operation(SCRIPT)` | — | 无 | ✅ |
| 7 | stop-db.sh / stop-db.bat 修正引用 | `scripts/stop-db.sh`, `scripts/stop-db.bat` | `record_dev_operation(SCRIPT)` | — | 无 | ✅ |
| 8 | start-infrastructure.sh 修正 collection/token/端口 | `scripts/start-infrastructure.sh` | `record_dev_operation(SCRIPT)` | — | 无 | ✅ |
| 9 | db-status.sh / db-wait.sh 修正引用 | `scripts/db-status.sh`, `scripts/db-wait.sh` | `record_dev_operation(SCRIPT)` | — | 无 | ✅ |
| 10 | .env.development / .env.production 新建 | `.env.development`, `.env.production` | `record_dev_operation(CONFIG)` | — | 无 | ✅ |
| 11 | 本地数据迁移 + 历史保留 | `$HOME/data/farm-agent/`, `./data/` | `record_dev_operation(FILESYSTEM)` | — | Task 1/2 | ✅ |
| **12** | **ChromaDB 持久化修复 + 数据恢复** | `podman-compose.yml`, `docker-compose.yml`, `scripts/db-ensure.sh` | `record_dev_operation(CONFIG/SCRIPT)` | — | Task 1/3 | **✅ 已完成** |

### Task 12 详细动作（本 add-route 核心增量）

**触发来源**：`runtime-review-v1` §5.1 修复方案

**改动**（3 处 volume Destination 修正）：

| 文件 | 行号 | 修复前 | 修复后 |
|------|------|--------|--------|
| `podman-compose.yml` | L52 | `${DATA_DIR}/chroma:/chroma/chroma:Z` | `${DATA_DIR}/chroma:/data:Z` |
| `docker-compose.yml` | L52 | `${DATA_DIR}/chroma:/chroma/chroma` | `${DATA_DIR}/chroma:/data` |
| `scripts/db-ensure.sh` | L82 | `-v "$DATA_DIR/chroma:/chroma/chroma"` | `-v "$DATA_DIR/chroma:/data"` |

**修复后操作**：
1. 重启 chroma 容器使配置生效
2. 数据恢复：通过知识库同步或 `data/exports/chroma-export-*.json` 导入
3. 验证 `collectionCount > 0`
4. VPS（rfai）同步修复

### 依赖拓扑

```
Task 1-11（已完成）──→ Task 12（ChromaDB 持久化修复）
```

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[x]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计

**产出**：
- [x] Task 1-11 的 `[x]` 项通过
- [x] Task 1-11 每个文件有 `record_dev_operation` 记录
- [x] Task 12 的 `[x]` 项通过（3 文件 Destination 修正 + 690 条向量恢复 + 容器重启验证）
- [x] Task 12 每个文件有 `record_dev_operation` 记录（3 条 MODIFY 已落库）

**状态**：✅ 已完成（Task 1-12 全部完成，VPS 同步待用户手动执行）

---

## Step 3.5：实现审查

**目的**：代码完成后，验证意图与实现无语义鸿沟（ADD-10）。

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. Task 12 修复后生成 runtime 验证清单

**产出**：
- [x] `checklist.md` Task 12 全部 `[x]` 项已通过
- [x] runtime-review-v1 §5.1 修复验证通过（Mount Destination=/data + 690 向量 + 重启验证 + VPS 同步）

**状态**：✅ 已完成

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**动作**：
1. 无 TypeScript 变更 → `tsc --noEmit` / `npm run lint` 不适用 ✅
2. 调用 `check_phase_symmetry` — 无新增 Phase，跳过 ✅
3. 调用 `check_failure_path` — ⚠️ MCP 工具仅支持 TS 代码，`.yml`/`.sh` 无法验证（MCP 盲区，见 Step 5 诊断）

**产出**：
- [x] Task 12 变更文件无语法错误（bash -n + yq validate）
- [x] 失败路径已覆盖：数据恢复失败时 export 文件仍在 `data/exports/`，可重试

**状态**：✅ 已完成（非 TS 变更，MCP 工具无覆盖能力）

---

## Step 5：AI 自动合规检查

**目的**：扫描全部修改文件的 ADD-1~ADD-7 合规性。

**动作**：
1. 对 3 个修改文件（`podman-compose.yml`、`docker-compose.yml`、`scripts/db-ensure.sh`）调用 `check_add_compliance`
2. ⚠️ **MCP 工具盲区**：`check_add_compliance` schema 要求 `code` 参数为 TypeScript 代码文本，无法检查 `.yml`、`.sh` 等基础设施配置
3. 手动合规自检替代：

| 文件 | ADD-1 审计优先 | ADD-6 失败等价 | 结论 |
|------|--------------|--------------|------|
| `podman-compose.yml` | ADD-7 `record_dev_operation` 已记录 ✅ | 配置回滚方案已存在 ✅ | 手动通过 |
| `docker-compose.yml` | ADD-7 `record_dev_operation` 已记录 ✅ | 同上 ✅ | 手动通过 |
| `scripts/db-ensure.sh` | ADD-7 `record_dev_operation` 已记录 ✅ | 同上 ✅ | 手动通过 |

**产出**：
- [x] 合规报告已生成（手动自检，MCP 工具不覆盖非 TS 文件）
- [x] 所有违规项有处理决策：**MCP 工具类型盲区，需增强 `check_add_compliance` 支持非 TS 文件**

**状态**：✅ 已完成（手动自检通过，发现 MCP 工具能力缺口）

---

## Step 6：从审计数据定位问题

> **仅当 Step 4/5 发现异常时进入。**

**状态**：✅ 跳过（Step 4/5 无代码级异常，发现 MCP 工具能力缺口已记录）

---

## Step 7：修复并验证

> **仅当 Step 6 发现问题时进入。**

**状态**：✅ 跳过（无代码级问题需修复）

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**记录时间**：2026-06-11T11:15:00+08:00（本地），2026-06-11T11:10:00+08:00（VPS）

**动作**：
1. **收敛判断**：Task 12 全部 `[x]` 项通过 + runtime `[R]` 清单已验证 → ✅ 功能收敛
2. **Handoff 更新**：Handoff §7 追加 Task 12 持久化修复记录（见下）
3. **Step 0 第二阶段**：基础设施变更不涉及业务架构文档 ✅
4. **ADD-7 回查**：

| 文件 | ADD-7 记录数 | 状态 |
|------|------------|------|
| `podman-compose.yml` | 1 MODIFY (Task 12) + 1 首轮 | ✅ 已落库 |
| `docker-compose.yml` | 1 MODIFY (Task 12) + 1 首轮 | ✅ 已落库 |
| `scripts/db-ensure.sh` | 1 MODIFY (Task 12) + 1 首轮 | ✅ 已落库 |
| add-route 创建 | 1 CREATE | ✅ 已落库 |

**Handoff 后置补充**（§7 实际产出与偏离）：
- Task 12 偏离 Plan 原始设计：原 Plan 仅定义 Source 端迁移（`./data/` → `${DATA_DIR}/`），未考虑 Destination 端对齐
- runtime-review-v1 触发 3 处 volume Destination 修正 + 690 条向量恢复 + VPS 同步
- VPS 额外发现 Prisma 迁移 `20260606082431` 失败阻塞启动，已 `migrate resolve --applied` 解决

**产出**：
- [x] 收敛判定结果
- [x] Handoff 已更新（后置补充记录）
- [x] ADD-7 审计记录已落库确认（4 条）

**状态**：✅ 已完成

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `podman-compose.yml` | MODIFY | Task 1 + Task 12 | CONFIG | ✅ |
| `docker-compose.yml` | MODIFY | Task 2 + Task 12 | CONFIG | ✅ |
| `scripts/db-ensure.sh` | MODIFY | Task 3 + Task 12 | SCRIPT | ✅ |
| `scripts/db-ensure.bat` | MODIFY | Task 4 | SCRIPT | ✅ |
| `scripts/start-db.sh` | MODIFY | Task 5 | SCRIPT | ✅ |
| `scripts/start-db.bat` | MODIFY | Task 6 | SCRIPT | ✅ |
| `scripts/stop-db.sh` | MODIFY | Task 7 | SCRIPT | ✅ |
| `scripts/stop-db.bat` | MODIFY | Task 7 | SCRIPT | ✅ |
| `scripts/start-infrastructure.sh` | MODIFY | Task 8 | SCRIPT | ✅ |
| `scripts/db-status.sh` | MODIFY | Task 9 | SCRIPT | ✅ |
| `scripts/db-wait.sh` | MODIFY | Task 9 | SCRIPT | ✅ |
| `.env.development` | CREATE | Task 10 | CONFIG | ✅ |
| `.env.production` | CREATE | Task 10 | CONFIG | ✅ |
| `$HOME/data/farm-agent/` | CREATE+MIGRATE | Task 11 | FILESYSTEM | ✅ |
| `./data/` | CHMOD（保留历史，禁止删除） | Task 11 | FILESYSTEM | ✅ |
