# farm-agent Expert Grounding RAG 适配 Plan v1

## PLAN 元信息

- **Plan 名称**: farm-agent-expert-grounding-rag-adaptation-v1
- **启动时间**: 2026-06-04
- **前置依赖**: 第 8 轮架构合流闭包（GlobalSystemState + CognitiveEventBus + PolicyUpdateLoop + Embedded Path Evolution）完成
- **关联 Review**: `.qoder/reviews/farm-agent-expert-grounding-rag-adaptation-plan-review-v1.md` ← 本 Plan 的预执行审查（ADD-9）
- 父 Plan Review: `.qoder/reviews/farm-agent-多轮对话能力专家链路优化统一状态管理-round8-global-state-spec-review-v1.md` §8.4
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **承接计划**: 本 Plan 是 [farm-agent-多轮对话能力专家链路优化统一状态管理-plan-v1.md](file:///home/xmm/ai/farm-agent/.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-plan-v1.md) 的下一个独立计划，其 7+1 轮原子事务完成后，第 9 轮 Expert Grounding 作为 RAG 基础设施的专项改造启动

---

## 1. 背景

第 8 轮后，`activateExpert()` 在概念层声明了 Expert Grounding 的意图——激活的是一个"已锚定的 Grounding Domain"，不是运行时检索过滤条件。但底层 RAG 基础设施未改造：当前使用 `evidenceFilter`（ChromaDB where 子句）在检索时模拟 Grounding 行为——全局搜索 + cateId 过滤。管线正常运行，但精度和效率存在折损。

第 9 轮的自然入口：将 Expert Grounding 从概念层的 `activateExpert()` 声明下沉到 ChromaDB 的索引层，为每个专家建立独立的 collection，实现真正的知识域锚定。

---

## 2. 目标

| 维度 | 当前 | 目标 |
|------|------|------|
| 知识域隔离 | ChromaDB where 子句（运行时过滤） | 每个 expert 独立 collection（`expert_crop_compare` / `expert_roi_analysis` / `expert_pest_risk`） |
| Grounding 确认 | 无 | `groundingDomainReady(expertId): Promise<boolean>` 确认 collection 存在、索引完整、同步时效 |
| 检索路径 | `searchKnowledgeDocuments(query, topK, undefined, where)` | `searchKnowledgeDocuments(query, topK, collectionName)` 在 expert collection 内检索 |
| 证据链溯源 | `source = "chroma_doc_xxx"` | `source = "expert:pest_risk/chroma_doc_xxx"` 含 Grounding 来源 |
| 渐进迁移 | 不支持 | 新旧两条路径共存，未迁移 expert 走旧路径，已迁移走新路径 |

---

## 3. 架构设计

### 3.1 ChromaDB Collection 分片

```
当前:
  chroma_collection_agriculture  （全量农业知识库）
    ├── planting_technique 类别文档（作物对比用）
    ├── plant_protection   类别文档（植保用）
    ├── agri_tech          类别文档（农业技术用）
    ├── market_intel       类别文档（ROI 分析用）
    └── ... 其他类别

第 9 轮:
  expert_crop_compare  （作物对比专用 collection）
    └── cateId: planting_technique 的所有文档

  expert_roi_analysis  （ROI 分析专用 collection）
    └── cateId: market_intel, economic_data 的所有文档

  expert_pest_risk     （植保专用 collection）
    └── cateId: plant_protection, agri_tech 的所有文档
```

### 3.2 ANALYSIS_EXPERTS Registry 扩展

```typescript
interface AnalysisExpert {
  id: string
  label: string
  domain: ExpertDomain
  // ... 现有字段不变 ...

  // ★第9轮新增★
  grounding: {
    collectionName: string                        // ChromaDB collection 名称
    ready: () => Promise<GroundingStatus>         // 确认知识域就绪
  }
}

interface GroundingStatus {
  ready: boolean
  collectionName: string
  documentCount: number
  lastSyncedAt: string
  indexHealth: "healthy" | "degraded" | "empty"
}
```

### 3.3 检索降级路径

```
裁决层（caijuehub）
  ↓
resolveRetrieveBudget(experts) → perExpertTopK: { pest_risk: 5, crop_compare: 5, roi_analysis: 5, ... }
  │  核心 Expert 分配 5，汇总 Expert 分配 10
  ↓
activateExpert(pest_risk)
  ↓
grounding.ready()
  ↓
  ├─ ready=true  → searchKnowledgeDocuments(query, perExpertTopK[expertId], { collectionName })
  │                 在 expert_pest_risk collection 内向量匹配
  │
  ├─ ready=false → searchKnowledgeDocuments(query, perExpertTopK[expertId], { where: {...} })
  │                 evidenceFilter 降级方案（当前路径），全局搜索 + cateId 过滤
  │                 写入 AuditLog: EXPERT_GROUNDING_DEGRADED
  │
  └─ 渐进迁移: 部分 expert 走新路径，部分走降级路径，互不阻塞
```

> **P1 #8（Review 回流修正）**：`RetrieveBudget` 接口新增 `perExpertTopK: Record<expertId, number>`，由裁决层 `resolveRetrieveBudget()` 按 Expert 属性分配（核心 5 / 汇总 10）。检索节点不再使用固定 `topK`，改为 `perExpertTopK[expertId]`。

> **P1 #7（Review 回流修正）**：`searchKnowledgeDocuments()` 新签名示例：
> ```typescript
> // 新路径（Grounded Expert）
> searchKnowledgeDocuments(query, perExpertTopK[expertId], { collectionName: "expert_pest_risk" })
>
> // 降级路径（未迁移 Expert）
> searchKnowledgeDocuments(query, perExpertTopK[expertId], undefined, expert.evidenceFilter)
>
> // SearchOptions 互斥路由（collectionName 与 filter 二选一）
> interface SearchOptions {
>   collectionName?: string            // 目标 collection（新路径）
>   filter?: Record<string, unknown>   // where 子句（降级路径）
> }
> ```

### 3.4 证据链溯源升级

```
当前:
  evidence[i].source = "chroma_doc_xxx"

第9轮:
  evidence[i].source = "expert:pest_risk/chroma_doc_xxx"
  evidence[i].grounding = {
    collectionName: "expert_pest_risk",
    groundingStatus: "anchored",  // "anchored" | "degraded" | "unavailable"
    retrievedVia: "collection_search" | "fallback_evidence_filter"
  }
```

---

## 4. 实施步骤

> **P2（Review 回流修正）**：Phase 编号改为 Task Group（A-E），避免与 ADD Step 0-8 编号冲突。

### Task Group A: Collection 分片基础设施

| 步骤 | 内容 | 文件 |
|------|------|------|
| A.1 | ChromaDB 创建 3 个 expert collection（`expert_crop_compare` / `expert_roi_analysis` / `expert_pest_risk`） | ChromaDB 管理脚本 |
| A.2 | 从全量 collection 中按 cateId 迁移文档到对应 expert collection | 同步脚本 |
| A.3 | 向量化工具支持指定目标 collection | `scripts/init-chroma-collection.ts` 扩展 |
| A.4 | 知识库同步流程支持多 collection 写入 | `src/services/knowledge-sync.ts` |

### Task Group B: Registry 扩展

| 步骤 | 内容 | 文件 |
|------|------|------|
| B.1 | `AnalysisExpert` 接口新增 `grounding` 字段 | `src/agents/experts/registry.ts` |
| B.2 | 3 个 expert 各配置 `collectionName` 和 `grounding.ready()` | 同上 |
| B.3 | `GroundingStatus` 类型定义 | `src/agents/experts/filter-types.ts` |

### Task Group C: 检索路径切换

| 步骤 | 内容 | 文件 |
|------|------|------|
| C.1 | `searchKnowledgeDocuments()` 签名扩展：支持 `SearchOptions { collectionName?, filter? }` 可选参数。`collectionName` 与 `where` 互斥——传 `collectionName` 时走 collection 搜索，传 `filter` 时走 where 降级。 | `src/services/knowledge-indexer.ts` |
| C.2 | retrieval 节点：`activateExpert` 后调用 `grounding.ready()`，就绪走新路径，否则降级 | `src/agents/nodes/retrieval.ts` |
| C.3 | 降级时写入 AuditLog（`EXPERT_GROUNDING_DEGRADED`）| `src/agents/nodes/retrieval.ts` |

### Task Group D: 证据链升级

| 步骤 | 内容 | 文件 |
|------|------|------|
| D.1 | `Evidence` 类型新增可选 `grounding` 字段 | `src/agents/types/index.ts` |
| D.2 | retrieval 节点写入 `source` 和 `grounding` 字段 | `src/agents/nodes/retrieval.ts` |

### Task Group E: 渐进迁移与验证（Phase 1: 3 个 Expert）

| 步骤 | 内容 |
|------|------|
| E.1 | 逐 expert 迁移 collection（一次只迁移一个，其余走降级路径） |
| E.2 | `groundingDomainReady()` 验证 collection 存在、文档数 ≥ 阈值、最后同步时间在窗口内 |
| E.3 | 迁移完成后关闭旧路径的 evidenceFilter 降级（或保留为永久 fallback） |

### Task Group F: 其余 8 个 Expert 迁移路线图（Phase 2）

> **P1 #4（Review 回流修正）**：原 Plan 仅覆盖 3/11 Expert（27%），Review 要求补充完整迁移 roadmap。

| 阶段 | Expert | cateId 来源 | 预估文档量 | 优先级 |
|------|--------|-----------|----------|:--:|
| Phase 2a | `disease_diagnosis` / `pest_warning` | `plant_protection` | ~200 | P1 |
| Phase 2b | `fertilizer_plan` / `soil_analysis` | `soil_science`, `agri_tech` | ~150 | P1 |
| Phase 2c | `irrigation_plan` / `climate_analysis` | `water_management`, `weather_data` | ~120 | P2 |
| Phase 2d | `yield_prediction` / `market_analysis` | `economic_data`, `market_intel` | ~100 | P2 |
| Phase 2e | `daily_report` / `weekly_report`（汇总 Expert） | 不建独立 collection，动态聚合核心 Expert 的检索结果 | 0 | P2 |

**汇总 Expert 策略**（P2 回流修正）：`daily_report` 和 `weekly_report` 不建独立 collection。它们作为"二级检索节点"，从已激活的核心 Expert 结果集中聚合，避免为汇总 Expert 创建低信息密度的独立知识域。

**agri_tech 共享策略**（P1 #5 回流修正）：`agri_tech` 被 6 个 Expert 共享（`pest_risk`, `pest_warning`, `crop_compare`, `fertilizer_plan`, `soil_analysis`, `irrigation_plan`）。首期采用**复制策略**——每个 Expert collection 各存一份 `agri_tech` 文档（预估冗余 16MB+）。Phase 2 后评估 ChromaDB 跨 collection 引用方案（当前 ChromaDB 原生不支持）。

**ChromaCollectionManager**（P1 #6 回流修正）：`getChromaCollection()` 从单例改为 `Map<string, ChromaCollection>` 缓存。`searchKnowledgeDocuments()` 接收 `SearchOptions`，通过 `collectionName` 或 `where` 互斥路由：
```typescript
interface SearchOptions {
  collectionName?: string  // 指定目标 collection（新路径）
  filter?: Record<string, unknown>  // where 子句过滤（降级路径）
}
// collectionName 与 filter 互斥——同时传入时 collectionName 优先
```

**Embedding 成本评估**（P2 回流修正）：Phase 1（3 个 Expert）预估新增 embedding API 调用：3 collection × 平均 150 文档 = 450 次。使用 `text-embedding-3-small`（$0.02/1M tokens）预估成本 < $0.05。Phase 2（剩余 8 个 Expert）预估 1,200 次调用。

---

## 5. 不阻塞原则

- 第 9 轮改造全程，第 8 轮的 evidenceFilter 降级方案持续生效
- 所有 expert 默认走降级路径，迁移一个切换一个
- 单 expert 的新旧路径切换通过 `grounding.ready()` 的返回值决定，无硬编码
- 全局 collection 不做删除（保留为未迁移 expert 的 fallback）
- 裁决层 `resolveRetrieveBudget()` 按 Expert 属性分配 `perExpertTopK`，未迁移 Expert 同样受益于合理 topK

---

## 6. 验收标准

- [ ] 3 个 expert collection 在 ChromaDB 中创建且文档数 ≥ 对应 cateId 的文档数
- [ ] `grounding.ready()` 对已迁移的 expert 返回 `{ ready: true, indexHealth: "healthy" }`
- [ ] `activateExpert(pest_risk)` 后的检索在 `expert_pest_risk` collection 内进行（非全文搜索）
- [ ] 未迁移的 expert 走 evidenceFilter 降级路径，管线不受阻
- [ ] `evidence[i].source` 格式为 `expert:{expertId}/{chroma_doc_id}`
- [ ] `evidence[i].grounding` 字段正确标记检索路径（`collection_search` 或 `fallback_evidence_filter`）
- [ ] AuditLog 中降级事件有记录
- [ ] `npx tsc --noEmit` 零新增类型错误
- [ ] `RetrieveBudget.perExpertTopK` 按 Expert 属性正确分配（核心 5 / 汇总 10）

---

## 7. 关联文档

- **Plan Review**: `.qoder/reviews/farm-agent-expert-grounding-rag-adaptation-plan-review-v1.md` ← 本 Plan 的预执行审查（ADD-9）
- Spec: .qoder/specs/farm-agent-expert-grounding/spec.md
- Tasks: .qoder/specs/farm-agent-expert-grounding/tasks.md
- Checklist: .qoder/specs/farm-agent-expert-grounding/checklist.md
- **add-route**: `.qoder/plans/farm-agent-Expert-Grounding-RAG适配-add-route-v1.md`
- `.qoder/reviews/farm-agent-多轮对话能力专家链路优化统一状态管理-round8-global-state-spec-review-v1.md` §8.4（父 Plan Review）
- `.qoder/specs/farm-agent-global-state/spec.md`
- `src/agents/experts/registry.ts` — ANALYSIS_EXPERTS 定义
- `src/agents/nodes/retrieval.ts` — retrieval 节点
- `src/lib/chroma.ts` — ChromaDB 客户端
- `.qoder/plans/farm-agent-rag-audit-stacktrace-handoff-v1.md` — 上游 Handoff（本 Plan 的降级路径基座）

---

## 8. Review 回流记录

> **0.6.5 卡位执行记录**：以下 Review 问题已在本 Plan v2 中修正（2026-06-11）。

| Review 问题 | 优先级 | 回流位置 | 状态 |
|:--|:--|:--|:--:|
| #1 缺失 add-route | P0 | §7 关联文档 | ✅ |
| #2 缺失 specs 三元组 | P0 | §7 关联文档 | ✅ |
| #3 缺失 Handoff | P0 | §7 关联文档 | ✅ |
| #4 Expert 迁移仅 3/11 | P1 | §4 Task Group F（Phase 2 roadmap） | ✅ |
| #5 agri_tech 被 6 Expert 共享冗余 | P1 | §4 Task Group F（复制策略 + 引用方案） | ✅ |
| #6 getChromaCollection() 单例改造 | P1 | §4 Task Group F（ChromaCollectionManager + SearchOptions 互斥） | ✅ |
| #7 searchKnowledgeDocuments() 签名 | P1 | §4 Task Group C.1（SearchOptions 接口） | ✅ |
| #8 RetrieveBudget 缺失 perExpertTopK | P1 | §3.3 数据流图（裁决层前置 + perExpertTopK） | ✅ |
| — Phase 编号冲突 | P2 | §4 Phase → Task Group（A-F） | ✅ |
| — 汇总 Expert 策略 | P2 | §4 Task Group F（不建 collection，动态聚合） | ✅ |
| — Embedding 成本 | P2 | §4 Task Group F（450 次 / < $0.05） | ✅ |
