# farm-agent — 工具调用管线集成 交接手册

> **Plan**: farm-agent-tools-pipeline-v1
> **轮次**: 第二阶段（Task 5-9: 工具迁移 + 管线集成 + 编译验证）
> **完成时间**: 2026-06-06

---

## 1. 交接前状态

- LangGraph 管线 6 节点（intention→retrieval→reasoning→interactionPointDetection→verdict→response），无 toolNode
- agent 工具仅含 14 个内部 CRUD 工具（文档/任务/项目/用户），无外部数据获取能力
- Farm-Server 的 9 个技能卡片需要的土墒/虫情/气象站/地块数据完全未接入
- 天气/时间工具在 co-agent 存在但未迁移

---

## 2. 交接后状态（目标）

- LangGraph 管线 7 节点（+toolNode），支持工具调用回环（intention→toolNode→intention）
- 23 个工具全部注册：14 个原有 + 2 个时间 + 2 个天气 + 5 个 Farm-Server
- intention 节点使用 `getLLMWithTools()` 绑定全部工具，LLM 可自主调用外部 API
- Farm-Server token 通过 `setFarmTokenProvider` 请求级注入，工具调用时按需获取
- `npx tsc --noEmit` + `npm run build` 零错误通过

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/agents/tools/impl/time-tools.ts` | 新建 | `get_current_time` + `calculate_date` 时间工具 |
| 2 | `src/agents/tools/impl/weather-tools.ts` | 新建 | `query_weather_realtime` + `query_weather_forecast`，QWeather JWT EdDSA |
| 3 | `src/agents/tools/impl/farm-data-tools.ts` | 新建 | 5个Farm-Server工具：土墒/虫情/虫害类别/气象站/地块 |
| 4 | `src/agents/tools/schemas/time-tools.ts` | 新建 | Zod schema: CurrentTimeSchema, DateCalculateSchema |
| 5 | `src/agents/tools/schemas/weather-tools.ts` | 新建 | Zod schema: WeatherForecastSchema, WeatherRealtimeSchema |
| 6 | `src/agents/tools/schemas/farm-data-tools.ts` | 新建 | Zod schema: SoilMoisturePageSchema 等 |
| 7 | `src/lib/farm-token-context.ts` | 新建 | TokenProvider 模式：请求级注入 Farm-Server token |
| 8 | `src/agents/tools/index.ts` | 修改 | 注册全部 9 个新工具（原 14 → 23） |
| 9 | `src/agents/edges/conditional.ts` | 修改 | `routeByIntent` 新增 `hasToolCalls()` 检测 → `"toolNode"` 路由 |
| 10 | `src/agents/index.ts` | 修改 | 新增 `ToolNode` 节点 + 条件边 + `toolNode→intention` 回环 |
| 11 | `src/agents/nodes/intention.ts` | 修改 | 使用 `getLLMWithTools()`；检测 `tool_calls` 后透传 AIMessage |
| 12 | `src/app/api/agent/[hash]/route.ts` | 修改 | `setFarmTokenProvider`/`clearFarmTokenProvider` 注入 |
| 13 | `src/lib/auth/credential-store.ts` | 修复 | Prisma `InputJsonValue` 类型转换 |
| 14 | `src/services/report-generator.ts` | 修复 | pdfmake PdfPrinter 构造函数 `any` 类型声明 |

---

## 4. 管线拓扑（变更后）

```
__start__
    │
    ▼
intention ──(有 tool_calls)──► toolNode ──► intention (工具调用回环)
    │
    ├──(thinkingLevel=fast)──► response ──► __end__
    │
    └──(thinkingLevel=deep)──► retrieval → reasoning → interactionPointDetection
                                                          │
                                    ┌─────────────────────┤
                                    ▼                     ▼
                                  verdict            response
                                    │
                                    ▼
                                response ──► __end__
```

---

## 5. 工具注册清单（23 个）

### 内部工具（14 个）
`searchOnlineDocuments` `indexDocuments` `reindexAllDocuments` `createTask` `updateTask` `getTasks` `deleteTask` `createProject` `getProjects` `getProject` `updateProject` `getCurrentUser` `getTeamMembers` `assignTask`

### 外部数据工具（9 个）
| 工具名 | 类别 | 数据来源 |
|--------|------|---------|
| `get_current_time` | 时间 | 本地 `new Date()` |
| `calculate_date` | 时间 | 本地计算 |
| `query_weather_realtime` | 天气 | QWeather API (EdDSA JWT) |
| `query_weather_forecast` | 天气 | QWeather API (3d/7d/10d/15d) |
| `query_soil_moisture` | Farm-Server | `/moisture-data/page` |
| `query_insect_data` | Farm-Server | `/insect-data/page` |
| `query_insect_type` | Farm-Server | `/insect-type/page` |
| `query_farm_weather` | Farm-Server | `/weather-data/page` |
| `query_massif` | Farm-Server | `/massif/page` |

---

## 6. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| QWeather EdDSA 签名使用 `crypto.createSign("SHA-256")` 而非真正的 Ed25519 | 生产环境 QWeather API 可能鉴权失败 | 部署前验证 QWeather JWT 签名算法，必要时引入 `jose` 库 |
| Farm-Server token 未配置或过期 | 5 个 Farm-Server 工具全部返回 token 缺失错误 | `setFarmTokenProvider` 返回 null 时工具会抛出明确错误，LLM 应能降级处理 |
| ToolNode 回环无深度限制 | LLM 可能陷入无限工具调用循环 | LangGraph `recursionLimit` 默认 25，后续可加自定义限制 |
| 天气工具内部有独立的 JWT 实现，未复用 farm-server-client 的 qweather auth | 双份 JWT 签名代码 | 非阻塞，可后续重构统一 |

---

## 7. 恢复上下文审计查询（新 AI Session 首次启动必读）

### 总体一键恢复

```text
query_audit_logs({ keyword: "toolNode" })
```
→ 预期返回 3-5 条（管线集成相关）

```text
query_audit_logs({ keyword: "管线集成" })
```
→ 预期返回 5 条（本次全部改动）

### 逐文件审计查询

```text
query_audit_logs({ targetId: "src/agents/index.ts" })
→ COMPONENT_MODIFIED: 管线集成 ToolNode

query_audit_logs({ targetId: "src/agents/edges/conditional.ts" })
→ COMPONENT_MODIFIED: routeByIntent hasToolCalls

query_audit_logs({ targetId: "src/agents/nodes/intention.ts" })
→ COMPONENT_MODIFIED: getLLMWithTools

query_audit_logs({ targetId: "src/agents/tools/index.ts" })
→ COMPONENT_MODIFIED: 注册 9 个新工具
```

### 恢复判定标准

- `query_audit_logs` 命中 ≥ 5 条
- `grep -R "toolNode" src/agents/` 应有 4 处引用
- `grep -R "getLLMWithTools" src/agents/` 应在 intention.ts 中有引用

---

## 8. 后置确认

- [x] `npx tsc --noEmit` 通过（零错误）
- [x] `npm run build` 成功，`/api/agent/[hash]` 路由注册为 `ƒ (Dynamic)`
- [x] 所有文件改动已记录 ADD-7 审计（5 条 `COMPONENT_MODIFIED`）
- [x] 管线拓扑：`intention→toolNode/retrieval/response`, `toolNode→intention` 回环
