# farm-agent-seed-catalog-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度（文件路径 + Phase 验收标准 + 架构维度全覆盖）。**不要**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-seed-catalog-v1
- **启动时间**: 2026-06-16T10:00:00+08:00
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/farm-agent-seed-catalog-add-route-v1.md`
  - Handoff: `.qoder/plans/farm-agent-seed-catalog-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-seed-catalog-review-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| prisma/schema.prisma | MODEL | MODEL_CREATED | 无 SeedCatalog/SeedPrice 表 | 新增 SeedCatalog + SeedPrice 两个 model | 待实施 |
| src/app/api/seed-catalog/route.ts | COMPONENT | COMPONENT_CREATED | 无种子目录 API | 新增 CRUD + 分页查询 API | 待实施 |
| src/tools/query-seed-catalog.ts | COMPONENT | COMPONENT_CREATED | crop_compare 无种子查询工具 | 新增 query_seed_catalog 实时工具 | 待实施 |
| src/agents/experts/registry.ts | COMPONENT | COMPONENT_MODIFIED | crop_compare.realtimeToolNames 未设置 | crop_compare.realtimeToolNames: ["query_seed_catalog"] | 待实施 |
| src/tools/registry.ts | COMPONENT | COMPONENT_MODIFIED | 工具注册表无 seed_catalog 条目 | 新增 query_seed_catalog 工具注册 | 待实施 |
| agrisynapse/src/api/seed/index.ts | COMPONENT | COMPONENT_CREATED | 无种子目录前端 API 封装 | 新增 SeedApi CRUD 封装 | 待实施 |
| agrisynapse/src/views/seed/index.vue | COMPONENT | COMPONENT_CREATED | 无种子管理页面 | 新增品种列表 + 价格管理 CRUD 页面 | 待实施 |
| agrisynapse/src/router/ | COMPONENT | COMPONENT_MODIFIED | 无 /seed 路由 | 新增 /seed 路由入口 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

`crop_compare`（作物对比分析）专家目前仅靠 RAG 知识文档（`expert_crop_compare` collection）提供品种特性、栽培技术等非结构化知识。但做品种对比决策时，还需要结构化数据支撑：

- **品种基本信息**：审定编号、育种单位、生育期、预期亩产、抗逆性评级
- **市场价格**：不同渠道（经销商/电商/直供）的种子价格、包装规格
- **适宜区域**：品种适合在哪些区域、什么季节种植

这些数据目前不在系统中，"作物对比分析"的分析结果缺少商业维度。

### 1.2 目标

为 `crop_compare` 专家（及未来 `planting_advice`、`roi_analysis` 等）增加**结构化种子商品数据层**：

1. **数据持久化**：Prisma 新增 `SeedCatalog`（品种目录）+ `SeedPrice`（价格记录）两张表
2. **Agent 工具**：新增 `query_seed_catalog` 实时工具，供决策层自动调用
3. **管理后台**：agrisynapse 新增种子目录 CRUD 管理页面
4. **价格辅助采集**：预留 Web 搜索 API 接口辅助填充价格数据（结果需人工确认入库）
5. **注册中心生效**：`crop_compare` 注册 `realtimeToolNames: ["query_seed_catalog"]`

---

## 二、方案选型

### 2.1 候选方案对比

| 方案 | 数据实时性 | 数据可靠性 | 实现复杂度 | 结论 |
|------|-----------|-----------|-----------|------|
| A: 纯外部搜索 API 实时查询 | 高 | 低（价格来源不可控） | 中 | ❌ 污染专家推理 |
| B: 纯人工录入（管理后台 CRUD） | 低 | 高 | 低 | ⚠️ 效率不足 |
| **C: 搜索 API 辅助采集 + 人工确认入库** | 中 | 高 | 中 | ✅ 最佳平衡 |

### 2.2 选型理由

采用方案 C：**本地数据库为权威源 + Web 搜索 API 做辅助采集**。

- 专家推理时只查本地 PostgreSQL → 快速、可靠、可追溯
- 价格更新周期按月/季，非实时 → 搜索 API 辅助填充，人工审核确认入库
- 数据采集侧预留搜索 API 接口，不污染核心推理链路
- 不做外部实时依赖 → 农场弱网环境可用

---

## 三、架构设计

### 3.1 数据模型（Prisma）

```
SeedCatalog（品种目录）
├── id                String @id @default(cuid())
├── cropName          String         // 作物名称（如"小麦"）
├── varietyName       String         // 品种名（如"济麦22"）
├── approvalNo        String?        // 审定编号
├── breederOrg        String?        // 育种单位
├── growthDays        Int?           // 生育期（天）
├── yieldExpectation  Float?         // 预期亩产（kg）
├── resistanceRating  Json?          // 抗逆性评级 {"drought":"高","pest":"中",...}
├── suitableRegions   Json?          // 适宜区域 ["华北","黄淮海"]
├── suitableSeason    String?        // 适宜季节（"春播"/"秋播"）
├── updatedAt         DateTime @updatedAt

SeedPrice（价格记录 — 独立表，保留历史）
├── id                String @id @default(cuid())
├── catalogId         String         // FK → SeedCatalog
├── catalog           SeedCatalog    @relation(...)
├── price             Float          // 单价（元/公斤）
├── packageSpec       String?        // 包装规格（"5kg/袋"）
├── channel           PriceChannel   // 渠道枚举
├── supplierName      String?        // 供应商名称
├── effectiveDate     DateTime       // 价格生效日期
├── createdAt         DateTime @default(now())
```

**PriceChannel 枚举**：`DEALER`（经销商）、`ECOMMERCE`（电商）、`DIRECT_SUPPLY`（直供）

### 3.2 模块分布

```
farm-agent (Next.js 后端)
├── prisma/schema.prisma          → SeedCatalog + SeedPrice 模型
├── src/app/api/seed-catalog/
│   ├── route.ts                  → GET(分页)/POST(创建)
│   ├── [id]/
│   │   └── route.ts              → GET(详情)/PUT(更新)/DELETE(删除)
│   └── price/
│       └── route.ts              → POST(新增价格)
├── src/tools/query-seed-catalog.ts → Agent 工具实现
├── src/tools/registry.ts         → 工具注册
└── src/agents/experts/registry.ts → crop_compare 引用新工具

agrisynapse (Vue 3 前端)
├── src/api/seed/index.ts         → 前端 API 封装
├── src/views/seed/index.vue      → 品种 + 价格管理页面
└── src/router/                   → 路由注册
```

### 3.3 数据流

```
[管理后台] agrisynapse seed/index.vue
     │ CRUD (axios)
     ▼
[farm-agent API] /api/seed-catalog/...
     │ Prisma
     ▼
[PostgreSQL] SeedCatalog + SeedPrice

[Agent 推理] crop_compare Expert
     │ realtimeToolNames: ["query_seed_catalog"]
     ▼
[决策层] auto inject tool_call
     │ query_seed_catalog({ cropName, region })
     ▼
[Prisma 直查] 返回结构化品种 + 价格数据

[辅助采集] 搜索 API（预留）
     │ 搜索种子价格
     ▼
[管理后台] 预填表单 → 人工审核 → 确认入库
```

---

## 四、实施步骤 + 依赖图

```
Task 1.1: Prisma 模型 ──→ Task 2.1: API CRUD ──→ Task 4.1: 前端 API 封装 → Task 4.3: 路由
         │                    │
         │                    └──→ Task 2.2: Agent 工具 → Task 3.1: Registry 更新
         │
         └──→ Task 4.2: 前端页面
```

### Phase 1: 数据模型 (prisma/schema.prisma)

- [ ] Task 1.1: `prisma/schema.prisma` — 新增 SeedCatalog + SeedPrice 模型 + PriceChannel 枚举 → `npx prisma migrate dev`
  - 验收: migrate 成功，SeedCatalog + SeedPrice 表可查

### Phase 2: 后端 API

- [ ] Task 2.1: `src/app/api/seed-catalog/route.ts` — 品种 CRUD（分页/创建/更新/删除）
  - 验收: curl 测试 GET/POST 端点
- [ ] Task 2.2: `src/app/api/seed-catalog/[id]/route.ts` — 品种详情/更新/删除
  - 验收: curl 测试 GET/PUT/DELETE 端点
- [ ] Task 2.3: `src/app/api/seed-catalog/price/route.ts` — 价格新增
  - 验收: curl 测试 POST 端点
- [ ] Task 2.4: `src/tools/query-seed-catalog.ts` — Agent 工具（Prisma 查询品种 + 最新价格）
  - 验收: 导入工具，Prisma 查询返回正确格式

### Phase 3: Agent 注册

- [ ] Task 3.1: `src/tools/registry.ts` — 注册 query_seed_catalog
  - 验收: tsc 通过，工具名在注册表可查到
- [ ] Task 3.2: `src/agents/experts/registry.ts` — crop_compare.realtimeToolNames 更新
  - 验收: tsc 通过，字段值正确

### Phase 4: 前端管理页面

- [ ] Task 4.1: `agrisynapse/src/api/seed/index.ts` — SeedApi CRUD 封装
  - 验收: 类型检查通过
- [ ] Task 4.2: `agrisynapse/src/views/seed/index.vue` — 品种列表 + 编辑弹窗
  - 验收: 前端构建成功，页面可访问
- [ ] Task 4.3: `agrisynapse/src/router/` — 路由注册 + 菜单入口
  - 验收: 菜单可见，点击跳转正确

---

## 五、验收标准

### Phase 1: 数据模型
- [ ] `npx prisma migrate dev` 成功创建 SeedCatalog + SeedPrice 表
- [ ] PriceChannel 枚举含 DEALER/ECOMMERCE/DIRECT_SUPPLY

### Phase 2: 后端 API
- [ ] `GET /api/seed-catalog` 分页查询正确（cropName/varietyName 筛选）
- [ ] `GET /api/seed-catalog/[id]` 返回品种详情
- [ ] `POST /api/seed-catalog` 创建品种成功
- [ ] `PUT /api/seed-catalog/[id]` 更新品种成功
- [ ] `DELETE /api/seed-catalog/[id]` 删除品种成功
- [ ] `POST /api/seed-catalog/price` 新增价格成功
- [ ] `query_seed_catalog` 工具按 cropName+region 返回品种列表 + 最新价格

### Phase 3: Agent 注册
- [ ] `crop_compare.realtimeToolNames` 包含 `"query_seed_catalog"`
- [ ] `src/tools/registry.ts` 注册了 `query_seed_catalog`

### Phase 4: 前端管理页面
- [ ] agrisynapse `src/views/seed/` 页面可进行品种和价格的完整 CRUD
- [ ] 预留搜索采集 API 端点已定义（接口签名 + 返回空实现）
- [ ] `npx tsc --noEmit` 通过(farm-agent)
- [ ] `npm run build` 通过(agrisynapse)

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/farm-agent-seed-catalog-add-route-v1.md` |
| Handoff | `.qoder/plans/farm-agent-seed-catalog-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-seed-catalog-review-v1.md` |
| Spec | `.qoder/specs/farm-agent-seed-catalog/spec.md` |
| Tasks | `.qoder/specs/farm-agent-seed-catalog/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-seed-catalog/checklist.md` |

---

## 七、Review 回流记录（0.6.5 卡位）

> Review: `.qoder/reviews/farm-agent-seed-catalog-review-v1.md`

| Review 问题 | 严重程度 | 回流位置 | 回流方式 |
|------------|---------|---------|---------|
| P1-1: Spec 缺少返回格式契约 | P1 | Spec §Requirements "Agent 种子查询工具" | 补充 THEN 返回格式定义 |
| P1-2: Plan 缺少 API 路由路径约定 | P1 | Plan §3.2 模块分布 | 补充路由目录树结构 |
| P2-1: Tasks 未定义前端 UI 行为 | P2 | 已知不处理 | 实现时弹性决定 |
| P2-2: 搜索 API 预留未标记 | P2 | Plan §5 验收标准 | 新增验收项 |
