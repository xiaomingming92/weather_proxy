# farm-agent-seed-crawler-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。不要在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-seed-crawler-v1
- **启动时间**: 2026-06-16T12:00:00+08:00
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/farm-agent-seed-crawler-add-route-v1.md`
  - Handoff: `.qoder/plans/farm-agent-seed-crawler-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-seed-crawler-review-v1.md`
  - 父 Plan (种子目录): `.qoder/plans/farm-agent-seed-catalog-plan-v1.md`
  - 父 Spec: `.qoder/specs/farm-agent-seed-catalog/spec.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/services/seed-crawler.ts` | SERVICE | SERVICE_CREATED | 不存在 | 种子爬虫服务：公开品种审定爬取 + 搜索引擎价格搜索 | 待实施 |
| `src/app/api/seed-catalog/crawl/route.ts` | API_ROUTE | ROUTE_CREATED | 不存在 | POST /api/seed-catalog/crawl 预览端点 | 待实施 |
| `src/app/api/seed-catalog/batch-save/route.ts` | API_ROUTE | ROUTE_CREATED | 不存在 | POST /api/seed-catalog/batch-save 批量入库端点 | 待实施 |
| `src/agents/tools/schemas/seed-crawler.ts` | SCHEMA | SCHEMA_CREATED | 不存在 | CrawlSeedInfoSchema zod 定义 | 待实施 |
| `src/agents/tools/impl/seed-crawler.ts` | TOOL | TOOL_CREATED | 不存在 | crawl_seed_info Agent 工具（不入库，返回预览数据） | 待实施 |
| `src/agents/tools/index.ts` | REGISTRY | REGISTRY_UPDATED | 无爬虫工具 | 注册 crawlSeedInfoTool | 待实施 |
| `agrisynapse/src/views/seed/index.vue` | COMPONENT | COMPONENT_UPDATED | 无爬取按钮 | 新增爬取品种按钮 + 预览对话框 + 勾选入库 | 待实施 |
| `agrisynapse/src/api/seed/index.ts` | API_CLIENT | API_CLIENT_UPDATED | 无爬虫 API | 新增 crawl() + batchSave() 方法 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

种子目录管理功能（seed-catalog）已交付，但品种基础信息和价格数据完全依赖**人工逐条录入**。`query_seed_catalog` 工具只查询本地 DB，无法获取外部数据。公开品种审定网站（中国种业大数据平台、第一种业网等）有大量结构化品种数据，搜索引擎上有散落的价格信息，但目前没有自动采集通道。

### 1.2 目标

1. **爬虫服务**：爬取公开品种审定公告获取品种基础信息（品种名、审定编号、育种单位、适宜区域等），通过搜索引擎搜索品种的市场价格信息
2. **GUI 触发**：agrisynapse 种子目录页面提供「爬取品种」按钮，爬取结果呈现在**临时预览表格**中，用户勾选后按条目批量写入 `seed_catalog` + `seed_price` 表
3. **LLM 可调用**：提供 `crawl_seed_info` Agent 工具，LLM 可调用获取预览数据（**不入库**，未来由独立 graph 控制持久化）
4. **合规约束**：仅访问无需登录、无需付费的公开网页

---

## 二、方案选型

### 2.1 搜索引擎选型

| 方案 | 免费 | 无需 API Key | 中文搜索质量 | 结论 |
|------|:---:|:---:|:---:|------|
| A: DuckDuckGo HTML | ✅ | ✅ | 中 | **选用** |
| B: Serper API | ❌ | ❌ | 高 | 需付费+Key |
| C: Bing Search API | ❌ | ❌ | 高 | 需付费+Key |

### 2.2 HTML 解析选型

| 方案 | 轻量 | Node.js 原生 | 结论 |
|------|:---:|:---:|------|
| A: cheerio | ✅ | ❌ | **选用**（成熟、轻量、jQuery-like API） |
| B: 纯正则 | ✅ | ✅ | 脆弱，HTML 结构变化易崩 |

### 2.3 数据流设计

```
GUI 触发                          LLM 触发
─────────                         ─────────
爬取按钮 → POST /crawl            crop_compare → crawl_seed_info tool
     │                                  │
     ▼                                  ▼
  seed-crawler 服务（共享核心逻辑）
  ├─ crawlVarietyInfo() → 爬公开审定网站
  └─ searchSeedPrices() → 搜索引擎搜价格
     │                                  │
     ▼                                  ▼
  返回预览数据 ←────────────────→ 返回预览数据
  (不入库)                           (不入库)
     │
     ▼
  用户勾选 → POST /batch-save → 写入 SeedCatalog + SeedPrice
```

### 2.4 选型理由

- DuckDuckGo HTML 端点免费且无需 API Key，适合 MVP
- cheerio 是 Node.js 最成熟的 HTML 解析库（~1MB，零原生依赖）
- 爬虫服务与 API 端点分离，GUI 和 Agent 工具共享同一核心逻辑
- LLM 工具不入库，保持纯函数语义，未来由独立 graph 控制持久化

---

## 三、架构设计

### 3.1 爬虫服务 (`src/services/seed-crawler.ts`)

核心模块，纯函数设计，不依赖 Express/Next.js 上下文：

- `crawlVarietyInfo(cropName, varietyName?)` — 爬取公开品种审定网站，返回品种基础信息数组
- `searchSeedPrices(cropName, varietyName)` — 通过搜索引擎搜索品种价格，返回价格预览数组
- `crawlSeedInfo(cropName, varietyName?)` — 组合调用，返回完整的预览数据结构

**数据源优先级**：
1. 品种审定信息：中国种业大数据平台 (`202.127.42.47:6010`) → 第一种业网 (`a-seed.cn`)
2. 价格信息：DuckDuckGo 搜索 `"{品种名} 种子价格"`

**合规约束**：
- 仅 GET 请求公开页面，不 POST 不登录
- 请求间隔 ≥ 1s，携带标准 User-Agent
- 不存储 cookies、不绕过反爬

### 3.2 API 端点

#### `POST /api/seed-catalog/crawl`（预览端点）

- 输入：`{ cropName, varietyName? }`
- 输出：预览数据数组（品种信息 + 搜索结果摘要），**不写入 DB**
- 用途：GUI 爬取按钮触发

#### `POST /api/seed-catalog/batch-save`（入库端点）

- 输入：`{ items: CrawlPreviewItem[] }` — 用户勾选的条目
- 逻辑：对每个 item，UPSERT `SeedCatalog`（按 varietyName 去重）→ 如有价格信息则创建 `SeedPrice`
- 输出：`{ created: number, updated: number, errors: string[] }`
- 用途：GUI 勾选后批量入库

### 3.3 Agent 工具 (`crawl_seed_info`)

- 调用爬虫服务的 `crawlSeedInfo()` 函数
- **仅返回预览数据，不入库**
- 注册到 `crop_compare` 专家的 `realtimeToolNames`
- 审计：`agentAudit` + `writeAuditLog` 全流程

### 3.4 前端 GUI (agrisynapse)

种子目录页面 (`/llm/seed`) 新增：
- 「爬取品种」按钮（搜索栏右侧）
- 爬取预览对话框：输入作物名 → 爬取 → 结果表格（带 checkbox）→ 「导入选中」按钮
- 表格列：☑ | 品种名 | 审定编号 | 育种单位 | 适宜区域 | 价格摘要 | 来源

---

## 四、实施步骤 + 依赖图

```
Phase 1 (爬虫服务 + 依赖安装)
  └─ Task 1.1: npm install cheerio
  └─ Task 1.2: 创建 src/services/seed-crawler.ts

Phase 2 (API 端点)  ← 依赖 Phase 1
  └─ Task 2.1: 创建 POST /api/seed-catalog/crawl/route.ts
  └─ Task 2.2: 创建 POST /api/seed-catalog/batch-save/route.ts

Phase 3 (Agent 工具) ← 依赖 Phase 1
  └─ Task 3.1: 创建 schemas/seed-crawler.ts
  └─ Task 3.2: 创建 impl/seed-crawler.ts
  └─ Task 3.3: 注册到 tools/index.ts + crop_compare realtimeToolNames

Phase 4 (前端 GUI) ← 依赖 Phase 2
  └─ Task 4.1: agrisynapse SeedApi 新增 crawl() + batchSave()
  └─ Task 4.2: seed/index.vue 新增爬取按钮 + 预览对话框 + 导入逻辑

Phase 5 (验证) ← 依赖全部
  └─ Task 5.1: tsc --noEmit
  └─ Task 5.2: curl 验证 crawl + batch-save API
  └─ Task 5.3: RAHS 检查
```

**可并行**：Phase 2 和 Phase 3 可并行（都只依赖 Phase 1）

---

## 五、验收标准

- [ ] `cheerio` 依赖已安装
- [ ] `seed-crawler.ts` 服务可独立调用，爬取公开品种审定页面返回结构化数据
- [ ] `POST /api/seed-catalog/crawl` 返回预览数据（不入库）
- [ ] `POST /api/seed-catalog/batch-save` 将勾选项写入 SeedCatalog + SeedPrice
- [ ] `crawl_seed_info` Agent 工具注册成功，LLM 可调用
- [ ] 种子目录页面有「爬取品种」按钮，预览对话框可勾选导入
- [ ] `npx tsc --noEmit` 零错误
- [ ] 爬虫仅访问公开页面，无登录/付费页面访问记录

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/farm-agent-seed-crawler-add-route-v1.md` |
| Handoff | `.qoder/plans/farm-agent-seed-crawler-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-seed-crawler-review-v1.md` |
| Spec | `.qoder/specs/farm-agent-seed-crawler/spec.md` |
| Tasks | `.qoder/specs/farm-agent-seed-crawler/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-seed-crawler/checklist.md` |
| 父 Spec (种子目录) | `.qoder/specs/farm-agent-seed-catalog/spec.md` |
