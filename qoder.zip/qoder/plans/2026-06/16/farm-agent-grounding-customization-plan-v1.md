# farm-agent-grounding-customization-plan-v1

> Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。

## PLAN 元信息

- **Plan 名称**: farm-agent-grounding-customization-v1
- **启动时间**: 2026-06-15T19:30:00+08:00
- **范围**: farm-agent API 层 + kb-sync-expert-collections 脚本 + agrisynapse 前端页面
- **触发来源**: Expert Grounding collection 同步完成后，需要可管理的文档→专家集合显式映射，替代纯文件名关键词推断
- **关联文档**:
  - 本 Plan: `.qoder/plans/farm-agent-grounding-customization-plan-v1.md`
  - ADD Route: `.qoder/plans/farm-agent-grounding-customization-add-route-v1.md`（待生成）
  - Handoff: `.qoder/plans/farm-agent-grounding-customization-handoff-v1.md`（待生成）
  - Review: `.qoder/reviews/farm-agent-grounding-customization-review-v1.md`（待生成）
  - 上游 Plan: `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md`（Expert Grounding collection 初始化）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/app/api/knowledge/upload/route.ts` | API | API_UPDATED | FormData 仅接收 file，不接收 grounding | FormData 可选接收 `grounding` JSON 字段，存入 Document.metadata | 待实施 |
| `src/app/api/knowledge/documents/[id]/grounding/route.ts` | API | API_CREATED | 无单文档 grounding 配置接口 | PUT 读取/更新 Document.metadata.grounding | 待实施 |
| `src/app/api/knowledge/grounding/batch/route.ts` | API | API_CREATED | 无批量 grounding 配置接口 | POST 批量指派 docIds→expertIds | 待实施 |
| `src/app/api/knowledge/grounding/stats/route.ts` | API | API_CREATED | 无 grounding 覆盖率统计 | GET 返回 per-collection doc count/覆盖率 | 待实施 |
| `src/services/knowledge-sync.ts` | SERVICE | SERVICE_UPDATED | syncKnowledgeBase 仅写入 farm_agent | 同步后自动调 kb-sync-expert-collections 写 expert collections | 待实施 |
| `scripts/kb-sync-expert-collections.ts` | SCRIPT | SCRIPT_UPDATED | inferCateIds(fileName) 关键词推断 | metadata.grounding 优先 → keywords fallback | 待实施 |
| agrisynapse: `src/views/llm/customization/index.vue` | COMPONENT | COMPONENT_UPDATED | 占位页面 | 文档上传+grounding 指派+文档列表+同步触发 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

当前 `kb-sync-expert-collections.ts` 通过 `inferCateIds(fileName)` 做纯文件名关键词匹配来决定文档归属哪个 Expert Collection：

```typescript
// 当前逻辑：纯关键词推断
const CATEGORY_KEYWORDS = [
  { cateId: "plant_protection", keys: ["植保", "病虫害", "农药", ...] },
  { cateId: "weather", keys: ["天气", "气象", "气候", ...] },
  // ...
]
```

**缺陷**：
| 问题 | 影响 |
|------|------|
| **不可控** | 文档名不含关键词 → fallback 到 `agri_tech + planting_technique`，7 个 collection 都写入，造成噪声 |
| **不可见** | 管理员无法查看某篇文档被同步到了哪些 Expert Collection |
| **不可改** | 想调整文档归属必须改文件名或改脚本代码 |
| **weather_impact / roi_analysis 永久为空** | 无匹配关键词的文档 → collection 0 条，专家 grounding 永远 fallback 到全局检索 |
| **无法做优先级/权重** | 同一篇文档对多个 Expert 的重要性不同，关键词方案无法区分 |

### 1.2 目标

1. **上传时即可指派**：`POST /api/knowledge/upload` 支持可选 `grounding` 字段，上传同时指定 expertIds/domains
2. **同步时自动写 expert collections**：`syncKnowledgeBase` 向量化文档到 `farm_agent` 后，自动根据 grounding 配置同步到 Expert Collections，无需单独跑脚本
3. **事后可编辑**：新增 3 个 API 端点（单文档编辑、批量指派、覆盖率统计）+ customization 页面可视化管理
4. **优先级链兜底**：显式配置 > domain 路由 > 关键词推断，保证新老文档都能正确归属

---

## 二、架构设计

### 2.1 数据模型

**存储位置**：复用 `Document.metadata` JSON 字段（Prisma Json 类型），无需改 Schema。

```typescript
// Document.metadata.grounding
// 用户只维护 expertIds。domain（中文业务域）是从 expert 自动推导的只读属性，cateId 是 sync 脚本内部路由标识
type ExpertId = "crop_compare" | "pest_risk" | "weather_impact" | "nutrition_diagnose"
              | "growth_report" | "planting_advice" | "work_plan" | "machinery_dispatch"
              | "roi_analysis" | "daily_report" | "weekly_report"

interface DocumentGrounding {
  // 用户选择的专家 ID（Registry 中的 key），非 collection 名
  // 多选数组，覆盖多领域时同时指派多个专家
  expertIds: ExpertId[]
  priority: "high" | "normal" | "low"
  manualOverride: boolean
  // 不暴露 domains/cateId 给用户:
  //   - domain（中文: 种/管/收/耕/巡检/跨域）: 自动从 ANALYSIS_EXPERTS[expertId].domain 推导，只读
  //   - cateId（英文: planting_technique/agri_tech/...）: sync 脚本内部 fallback 路由，用户不可见
}

// 文档在前端列表中的展示模型（含自动推导字段）
interface DocumentWithGrounding {
  // ... 基础字段 (id, name, status, ...)
  grounding?: DocumentGrounding
  // 自动推导（只读，不存储）
  derivedDomains: ExpertDomain[]   // 从 expertIds 各 expert.domain 去重
  derivedLabels: string[]          // 从 expertIds 各 expert.label 收集
}
```

### 2.2 expertId → Collection 解析映射

```
用户存储的 expertId（"pest_risk"）
        │
        ▼
ANALYSIS_EXPERTS["pest_risk"].grounding?.collectionName
        │
        ├── 非汇总专家 → "expert_pest_risk"  ← 直接写入 ChromaDB
        │
        ├── 汇总专家（isSummary=true, 无 grounding）
        │     → 其 summaryOf 子专家们各自的 collectionName → 聚合写入
        │
        └── 找不到 expert → 跳过
```

**三层概念区分**：

| 层级 | 名称 | 值示例 | 用户可见 | 用途 |
|------|------|--------|---------|------|
| 业务域 | `domain` | "种" / "管" / "跨域" | ✅ 只读筛选 | 前端按业务域分组过滤文档列表 |
| 专家 | `expertId` | "pest_risk" | ✅ 读写 | 用户指派文档归属哪个专家 |
| 内部路由 | `cateId` | "plant_protection" | ❌ 不可见 | sync 脚本关键词 fallback 路由 |

**`domain` 的自动推导**：
```
文档的 expertIds = ["pest_risk", "growth_report"]
        │
        ▼ 查 Registry
ANALYSIS_EXPERTS["pest_risk"].domain = "管"
ANALYSIS_EXPERTS["growth_report"].domain = "管"
        │
        ▼ 去重
文档的 derivedDomains = ["管"]    ← 前端显示用，不存入 metadata
```

**注意**：`derivedDomains` 不存入数据库，是 API 返回时的计算字段。避免数据冗余和不一致。

### 2.4 API 设计

```
# ─── 上传（增强） ───
POST /api/knowledge/upload
     FormData: { file: File, grounding?: string }
     grounding 为 JSON 字符串: { expertIds?: ExpertId[], priority?: string, manualOverride?: boolean }
     校验: expertIds 中每个值必须存在于 ANALYSIS_EXPERTS，否则 400
     Response: { success: true, data: { id, grounding, ... } }

# ─── 单文档编辑 ───
PUT  /api/knowledge/documents/:id/grounding
     Body: { grounding: { expertIds: ExpertId[], priority?, manualOverride? } }
     校验: 同上
     Response: { success: true, data: { id, grounding } }

# ─── 批量指派 ───
POST /api/knowledge/grounding/batch
     Body: {
       docIds: string[],
       expertIds: ExpertId[],
       mode: "add" | "replace" | "remove"
     }
     Response: { success: true, data: { matched: number, updated: number } }

# ─── 覆盖率统计 ───
GET  /api/knowledge/grounding/stats
     Response: {
       success: true,
       data: {
         totalDocs: number,
         configuredDocs: number,
         perExpert: Array<{
           expertId: string,
           label: string,           // 从 Registry 读取
           collectionName: string,  // 从 Registry 读取
           docCount: number,        // ChromaDB 中实际文档数
           configuredCount: number, // 显式指派的文档数
         }>
       }
     }
```

### 2.3 Sync 脚本优先级链

```
文档的 metadata.grounding
  │
  ├── expertIds.length > 0
  │     ├── 遍历 expertIds
  │     │   ├── ANALYSIS_EXPERTS[expertId].grounding?.collectionName
  │     │   │     → 有 → 写入该 collection
  │     │   │     → 无（汇总专家 isSummary=true）→ 解析 summaryOf 子专家 → 聚合写入
  │     │   └── 找不到 expert → 跳过 + 日志告警
  │     └── 错误防护: expertId 不在 Registry 中 → HTTP 400（上传时校验）
  │
  └── ⬇ expertIds 为空（无配置）→ 全自动 fallback
        → inferCateIds(fileName) → CATEID_TO_COLLECTIONS 路由
```

**核心原则**：
- **用户只维护 `expertIds`，不维护 domain/cateId**。domain 是 sync 脚本内部的关键词推断产物，对用户透明
- **多领域文档**：`expertIds` 是多选数组，一篇文档可以同时指派给 `["pest_risk", "crop_compare", "growth_report"]`
- **用户选错专家**：前端下拉显示 `label`（如「病虫害风险评估」）降低误选；即使选错，LLM 推理时拿到不相关证据会自动忽略，影响可控
- **无配置存量文档**：`expertIds` 为空 → 走关键词 fallback，行为与现状一致

### 2.5 上传→向量化→Expert Collection 同步链路

```
用户上传文件 + grounding 配置
        │
        ▼
POST /api/knowledge/upload
  FormData: file + grounding={"expertIds":["expert_pest_risk"],"domains":["plant_protection"]}
        │
        ├── ① 保存文件 → Document 表 (metadata 含 grounding)
        │
        ▼
用户点击「同步知识库」
        │
        ▼
POST /api/knowledge/sync → syncKnowledgeBase()
        │
        ├── ② 向量化文档 → farm_agent collection
        │
        ▼
  ✨ 新增: syncExpertCollectionsForDoc(docId, grounding)
        │
        ├── ③ 读取 metadata.grounding
        ├── ④ 优先级链解析目标 expert collections
        └── ⑤ 写入 expert_pest_risk / expert_crop_compare / ...
```

**关键改动**：`src/services/knowledge-sync.ts` 的 `syncKnowledgeBase()` 完成后，对每篇新索引的文档调用 `syncExpertCollectionsForDoc()`，让向量化和 Expert Collection 同步在一次操作中完成。

### 2.6 前端页面结构

```
customization/index.vue
├── 顶部统计栏（已配置文档数 / 总数，per-expert 覆盖率）
├── 文档筛选栏
│   ├── 按业务域 domain 筛选（中文: 种/管/收/耕/巡检/跨域，自动推导只读）
│   ├── 按专家 expertId 筛选（已指派/未指派）
│   └── 按标签 keyword 搜索
├── 文档列表（复用现有文档列表样式）
│   ├── 每行显示：文档名、已指派专家标签（中文 label）、业务域徽章
│   └── 行操作：编辑 expertIds（抽屉 → 多选专家下拉，显示 label + domain 图标）
├── 批量操作栏（选中多篇 → 指派/替换/移除专家）
└── 同步按钮（触发 POST /api/knowledge/sync → SSE 进度）
```

**用户交互要点**：
- 用户**只选专家**（多选下拉，显示中文 label + 业务域图标），不选 domain/cateId
- 业务域 domain（中文）在列表中是自动推导的只读徽章，用于筛选，不能手动修改
- 多领域文档 → 多选多个专家即可，domain 自动聚合

---

## 三、实施步骤

```
Task 0: upload 接口 + grounding 接收 ──┐
Task 1: grounding CRUD API (3 端点)   ──┤ 可并行
                                        │
                                        ▼
Task 2: knowledge-sync 自动写 expert   ──┐
Task 3: kb-sync-expert-collections 更新 ──┤ 依赖 Task 0/1
                                        │
                                        ▼
Task 4: agrisynapse 前端页面           ── 依赖 Task 0/1/2
                                        │
                                        ▼
Task 5: 编译验证 + E2E 测试
```

### Task 0: upload 接口增强（接收 grounding）

- `POST /api/knowledge/upload` FormData 增加可选 `grounding` 字段（JSON string）
- 解析后存入 `Document.metadata.grounding`
- 校验 `expertIds` 合法（必须是 11 个 Registry expertId 之一），否则返回 400 + 具体错误信息
- response 中返回 `grounding` 确认

### Task 1: grounding CRUD API（3 个端点）

1. `PUT /api/knowledge/documents/[id]/grounding/route.ts`
   - 读取 `Document.metadata` → 更新 `metadata.grounding` → 保存
   - 校验：`expertIds` 必须是 `ANALYSIS_EXPERTS` 的 key 子集，否则返回 400
2. `POST /api/knowledge/grounding/batch/route.ts`
   - 接收 `{ docIds, expertIds, mode }`
   - `mode="add"`: 追加到已有 expertIds
   - `mode="replace"`: 替换 entire grounding
   - `mode="remove"`: 从已有 expertIds 中移除
3. `GET /api/knowledge/grounding/stats/route.ts`
   - 遍历所有 documents 统计 grounding 配置率
   - 查询 ChromaDB 各 Expert Collection 的文档数与 grounding 覆盖数对比

### Task 2: knowledge-sync 自动联动 Expert Collection

- `src/services/knowledge-sync.ts` 中新增 `syncExpertCollectionsForDoc(docId, grounding)` 函数
- `syncKnowledgeBase()` 在每篇文档索引完成后调用此函数
- 优先级链逻辑复用 `kb-sync-expert-collections.ts` 的 `resolveDocGrounding()`
- 审计日志记录 `EXPERT_SYNC_AUTO` phase

### Task 3: kb-sync-expert-collections.ts 优先级链更新

- 新增 `resolveDocGrounding(docMeta)` 函数实现优先级链（供 Task 2 和手动脚本复用）
- 修改 `main()` 中路由逻辑
- `getExpertCollections(cateIds)` 改为 `getExpertCollections(cateIds, grounding)`

### Task 4: agrisynapse customization/index.vue

- 文档列表：复用 `GET /api/knowledge/documents` 接口，增加 grounding 状态列
- 筛选栏：domain / label / expert / grounding 状态（已配置/未配置）
- 编辑抽屉：domain 多选、expert 多选、priority 单选、manualOverride 开关
- 批量操作栏：选中多篇 → 指派/替换/移除
- 统计栏：GroundingStats 组件显示覆盖率
- 同步按钮：SSE 进度条

### Task 5: 编译验证 + E2E

- farm-agent `tsc --noEmit` 零错误
- agrisynapse `vue-tsc --noEmit` 仅预存错误
- Runtime 验证：配置 1 篇文档的 grounding → 触发同步 → ChromaDB expert collection 新增 → 对话测试 grounding 命中

---

## 四、验收标准

- [ ] `POST /api/knowledge/upload` 接收 `grounding` 字段并存入 Document.metadata，非法 expertId 返回 400
- [ ] `syncKnowledgeBase` 向量化后自动将文档同步到 grounding.expertIds 对应的 Expert Collections
- [ ] Expert Collection 写入幂等：重复同步不产生重复向量
- [ ] `PUT /api/knowledge/documents/:id/grounding` 能成功读写，非法 expertId 校验拦截
- [ ] `POST /api/knowledge/grounding/batch` 三种 mode（add/replace/remove）均正确
- [ ] `GET /api/knowledge/grounding/stats` 返回准确的 per-expert 统计
- [ ] sync 脚本：expertIds 优先 → Expert Collection；无配置 → 关键词 fallback
- [ ] customization 页面支持上传时指派专家、文档列表筛选、编辑 expertIds、批量操作、触发同步
- [ ] 配置后的文档在对话中 Expert Grounding 命中（`grounding: true`）
- [ ] `weather_impact` / `roi_analysis` 管理员可手动指派文档后不再为空

---

## 五、关联文档

| 文档 | 路径 |
|------|------|
| 本 Plan | `.qoder/plans/farm-agent-grounding-customization-plan-v1.md` |
| ADD Route | `.qoder/plans/farm-agent-grounding-customization-add-route-v1.md` |
| Handoff | `.qoder/plans/farm-agent-grounding-customization-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-grounding-customization-review-v1.md` |
| Spec | `.qoder/specs/grounding-customization/spec.md` |
| Tasks | `.qoder/specs/grounding-customization/tasks.md` |
| Checklist | `.qoder/specs/grounding-customization/checklist.md` |
| 上游 Plan | `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md` |
| `src/app/api/knowledge/upload/route.ts` | 上传 API（增强） |
| `src/services/knowledge-sync.ts` | 知识库同步服务（新增 Expert Collection 自动联动） |
| 前端页面 | agrisynapse `src/views/llm/customization/index.vue` |
