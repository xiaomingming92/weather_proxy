# PLAN: farm-agent Grounding 知识分类体系 — 多阶段实施

> Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。

## PLAN 元信息

- **Plan 名称**: farm-agent-grounding-customization-v3
- **启动时间**: 2026-06-16T12:00:00+08:00
- **范围**: farm-agent 知识分类裁决层 + kb-sync 完全重写 + 语义缓存改进 + agrisynapse customization 页面 + GB/T 13745 数据集成
- **触发来源**: 前版 Plan v1/v2 多轮 Review + 领域专家对三层分类模型的修正 + 司农 hybrid-rag 技术借鉴
- **关联文档**:
  - 本 Plan: `.qoder/plans/farm-agent-grounding-customization-plan-v3.md`
  - ADD Route: `.qoder/plans/farm-agent-grounding-customization-add-route-v1.md`
  - Handoff: `.qoder/plans/farm-agent-grounding-customization-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-grounding-customization-review-v3.md`
  - 上游 Plan: `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md`（Expert Grounding collection 初始化）
  - 借鉴源: 司农 hybrid-rag (南农+南理工)
- **前版 Plan**: v1 / v2 已作废，全部内容吸收至本 Plan

---

## 〇、概述

### 0.1 问题基线

当前 `kb-sync-expert-collections.ts` 通过 6 个 hardcoded cateId + 文件名关键词推断来决定文档归属。

**三大知识来源各有不同分类特征，一套逻辑无法覆盖：**

| 来源 | 文档类型 | 示例 | 特征 |
|------|---------|------|------|
| 学术/技术文献 | 论文、标准 | — | 自带 GB/T 13745 代码 |
| 邗江区农技站 | 定期技术报告 | 「2025年第6期 小麦主要病虫害发生及防治意见」 | 文件名含期号+作物+技术三维标签 |
| 农技云 App | 省级农业部门文章 | 江苏省农业农村厅发布 | 页面自带栏目标签 |

**核心缺陷**：不可控、不可见、不可改——用户无法查看/修正文档归属。

### 0.2 本计划目标

在 **不改 Prisma Schema** 的前提下，实现 5 阶段改进：

| Step | 改进 | 解决什么 |
|------|------|---------|
| 1 | 知识分类基座（GB/T 13745 + Resolver + 映射表） | 建立 disciplineCode 原子知识单元体系 |
| 2 | 数据链路（kb-sync 重写 + upload 自动分类 + 双写替换） | disciplineCode → expertId → collectionName 三级链 |
| 3 | 缓存与分块升级（per-collection 缓存 + SmartChunker） | 避免一刀切淘汰；语义分块替代固定长度 |
| 4 | 管理界面（grounding API + customization 一期） | 上传后自动分类，失败人工标注 |
| 5 | 批量管理 + 前端二期 + 端到端验证 | 映射管理、批量指派、E2E |

### 0.3 三层分类模型

```
Layer 1: 农业活动域    ExpertDomain: "耕" | "种" | "管" | "收" | "巡检" | "跨域"
         (Registry 已有，只读徽章，前端列表筛选)

Layer 2: GB/T 13745 二级   cateId: "210.30" 农艺学 / "210.60" 植物保护学
         (从 disciplineCode 前6位自动推导，内部使用)

Layer 3: GB/T 13745 三级   disciplineCode: "210.6040" 农药学 / "210.6020" 植物病理学
         ★ 核心 ★  用户可 CRUD，sync 路由基础
```

### 0.4 独立裁决层（Discipline Resolver）

```
                     ┌──────────────────────────────┐
                     │     Discipline Resolver      │
                     └──────────────┬───────────────┘
          ┌─────────────────────────┼─────────────────────────┐
          ▼                         ▼                         ▼
┌─────────────────────┐ ┌─────────────────────┐ ┌─────────────────────┐
│ 子裁决器 A          │ │ 子裁决器 B          │ │ 子裁决器 C          │
│ GB/T 13745 解析器   │ │ 农技推广体系解析器   │ │ 栏目标签解析器      │
├─────────────────────┤ ├─────────────────────┤ ├─────────────────────┤
│ 策略:               │ │ 策略:               │ │ 策略:               │
│ 提取文档自带代码    │ │ 文件名模式匹配:      │ │ 栏目标签 → 映射表   │
│ "210.6040"          │ │ "小麦"+"病虫防治"    │ │                    │
│ 内容关键词 → 映射表 │ │ → "210.6020/6040"   │ │                    │
└─────────────────────┘ └─────────────────────┘ └─────────────────────┘
          │                         │                         │
          └─────────────────────────┼─────────────────────────┘
                                    ▼
                    任一置信度 ≥ 0.7 → AUTO_CLASSIFIED
                    全部 < 0.7 → PENDING_CLASSIFY（前端人工标注）

                     ┌──────────────────────────────┐
                     │   disciplineCode → expertId  │
                     │   ★ Registry 动态推导 ★      │
                     │   ANALYSIS_EXPERTS.{id}      │
                     │     .grounding.disciplineCodes│
                     └──────────────────────────────┘
```

### 0.5 借鉴技术清单

| # | 技术 | 来源 | 纳入 Step |
|---|------|------|----------|
| 1 | 语义分块 (SmartChunker) | 司农 | Step 3 |
| 2 | LLM 仲裁器（灰色区域，Phase 2） | 司农 | Step 1+ |
| 3 | 两阶段关键词 → 自动预标注 | 司农 | Step 1 |
| 4 | 子裁决器评分归一化融合 | 司农 | Step 1 |
| 5 | 断点续传入库 | 司农 | Step 2 |
| 6 | 安全切分三级回退 | 司农 | Step 3 |
| 7 | per-collection 语义缓存 | 自研 | Step 3 |

---

## Step 1: 知识分类基座

### 1.1 目标

建立 GB/T 13745 三级学科数据体系 + 独立裁决层 + 映射表基础设施。**这是全链路根基，未完成前禁止进入 Step 2-5。**

### 1.2 文件清单

| 文件 | action | 说明 |
|------|--------|------|
| `src/data/gbt13745-agriculture.json` | CREATE | GB/T 13745 农业科学 210 全量三级学科（≥ 60 条） |
| `src/services/discipline-resolver.ts` | CREATE | 多源裁决器链 + 两阶段关键词预标注 + 子裁决器评分归一化融合 |
| ~~`data/discipline-to-expert-mapping.json`~~ | ~~CREATE~~ → **DEPRECATED** | ~~disciplineCode ↔ expertId 映射表（JSON 配置文件）~~ → **[v3.1 废弃] 改为 Registry `grounding.disciplineCodes` 动态推导** |
| `src/agents/experts/registry.ts` | **UPDATE (v3.1)** | 各 Expert 新增 `grounding.disciplineCodes` 字段，替代 JSON 文件方案 |

### 1.3 实施细节

**gbt13745-agriculture.json**:
- 数据来源：GB/T 13745-2009 标准全文人工录入
- 校验：三级学科数与标准一致（≥ 60 条）
- 结构：`[{ code, name, parentCode, parentName }]`

**Discipline Resolver**:
- 子裁决器 A: GB/T 13745 代码提取（正则匹配文档内容中的 `210.xxxx` 模式）
- 子裁决器 B: 邗江文件名模式匹配（作物×阶段×技术 三维标签 → disciplineCode 映射表，预置 30+ 规则）
- 子裁决器 C: 栏目标签匹配（预设标签 → disciplineCode 映射）
- 归一化融合: min-max 归一化后取 `max(scoreA, scoreB, scoreC)`
- LLM 灰色区域仲裁: Phase 2 引入（0.5-0.7 区间），先收集实际置信度分布

**disciplineCode → expertId 映射**:
- ~~v3.0: `data/discipline-to-expert-mapping.json` — JSON 配置文件，管理员可 CRUD（Step 5 提供管理界面）~~
- ~~v3.0: 旧 `CATEID_TO_EXPERT_COLLECTION`（knowledge-indexer.ts L48-55）保留为 fallback~~
- **v3.1: 废弃 JSON 文件方案**，改为在 `ANALYSIS_EXPERTS` Registry 中为每个 Expert 声明 `grounding.disciplineCodes`
- **v3.1:** `resolveExpertIds()` 遍历 Registry 查找匹配的 expertId，映射管理界面通过 API 读写 Registry 配置

### 1.4 验收标准

- [ ] `data/gbt13745-agriculture.json` 就绪，`require()` 解析成功，≥ 60 条
- [ ] Resolver 三个子裁决器可独立调用，单元测试通过
- [ ] 输入"小麦病虫害防治"→ 输出至少 1 条 disciplineCode
- [ ] 输入邗江文档名"小麦主要病虫害发生及防治意见"→ 输出 `["210.6020", "210.6040"]`

### 1.5 ADD-7 审计策略

| 文件 | targetType | action | beforeState | afterState |
|-----|-----------|--------|------------|-----------|
| `src/data/gbt13745-agriculture.json` | DATA | DATA_CREATED | 无 | 210 农业科学全量三级学科 |
| `src/services/discipline-resolver.ts` | SERVICE | DISCIPLINE_RESOLVER_CREATED | cateId 关键词推断 | 多源裁决器链 + 归一化融合 |
| ~~`data/discipline-to-expert-mapping.json`~~ | ~~DATA~~ | ~~MAPPING_CREATED~~ → **DEPRECATED** | ~~无~~ | ~~disciplineCode ↔ expertId 映射~~ → **[v3.1] 方案废弃** |
| `src/agents/experts/registry.ts` | SERVICE | **REGISTRY_DISCIPLINE_MAPPED** (v3.1) | 无 disciplineCodes | 各 Expert 声明 grounding.disciplineCodes |

---

## Step 2: 数据链路

### 2.1 目标

重写 kb-sync 路由链 + upload API 自动分类 + 替换 knowledge-indexer.ts 现有双写为 disciplineCode 链。

### 2.2 文件清单

| 文件 | action | 说明 |
|------|--------|------|
| `scripts/kb-sync-expert-collections.ts` | REWRITE | disciplineCode → expertId → collectionName 三级链 + 断点续传入库 |
| `src/services/knowledge-indexer.ts` | UPDATE | 双写替换：CATEID_TO_EXPERT_COLLECTION → disciplineCode 链 |
| `src/services/knowledge-sync.ts` | **UPDATE (v3.1)** | sync 调用 `indexKnowledgeDocument` 时透传 `doc.metadata`（含 `grounding.disciplineCodes`），启用 Expert Grounding 双写 |
| `src/app/api/knowledge/upload/route.ts` | UPDATE | 上传时自动裁决 disciplineCodes，失败 PENDING_CLASSIFY |

### 2.3 实施细节

**kb-sync 路由链**:
```
disciplineCodes → 查映射表 → expertId[] → registry.grounding.collectionName → ChromaDB
```
- 断点续传入库：记录已同步 docId
- 存量文档迁移：三阶段（共存→批量转换→清理 cateId 逻辑）

**双写替换**:
- `indexKnowledgeDocumentWithProgress` 参数 `expertCateIds` → `disciplineCodes`
- 内部映射: `disciplineCodes → resolveExpertIds() → registry.grounding.collectionName`
- 旧 `CATEID_TO_EXPERT_COLLECTION` 保留为 fallback
- **v3.1 补充**: `indexKnowledgeDocument`（简化版，sync 调用）同步增加 Expert Grounding 双写：从 `doc.metadata.grounding.disciplineCodes` 提取 → `resolveExpertIds()` → 写入 expert 集合。修复前 sync 只写 `farm_agent` 主集合。

**INDEXED 存量文档 grounding 回填**:
- `syncAllKnowledge()` 的 statics 循环原逻辑：对 INDEXED 文档调用 `indexKnowledgeDocument("", Buffer.from(""), doc)` 因内容为空必抛错，grounding 从未更新。
- **修复**: statics 循环不再重新向量化，改为三条分支处理 grounding 元数据：
  1. **有 disciplineCodes 无 expertIds** → 调 `resolveExpertIds(disciplineCodes)` 动态解析 → 写回 `metadata.grounding.expertIds`
  2. **两者都无** → 调 `resolveDisciplineCodes(doc.name)` 自动分类 → 置信度 ≥ 0.7 则写入 disciplineCodes + 解析 expertIds
  3. **已有 expertIds** → 仅刷新 `lastSync`
- 全部通过 Registry 动态推导，零硬编码。

**upload 自动分类**:
- 上传完成后自动调用 DisciplineResolver
- 成功 → `metadata.grounding` + `AUTO_CLASSIFIED`
- 失败 → `PENDING_CLASSIFY`，前端高亮

### 2.4 验收标准

- [ ] kb-sync 按 disciplineCode → expertId → collectionName 链正确路由
- [ ] 断点续传：已同步 docId 不重复写入
- [ ] 存量 cateId 文档走共存 fallback，新文档走 disciplineCode
- [ ] upload 自动分类准确率 ≥ 80%（邗江文档测试集）
- [ ] 分类失败 → PENDING_CLASSIFY，前端高亮

### 2.5 ADD-7 审计策略

| 文件 | targetType | action | beforeState | afterState |
|-----|-----------|--------|------------|-----------|
| `scripts/kb-sync-expert-collections.ts` | SCRIPT | SYNC_REWRITTEN | cateId 关键词推断 | disciplineCode 三级链 + 断点续传 |
| `src/services/knowledge-indexer.ts` | SERVICE | DUAL_WRITE_REPLACED | expertCateIds + CATEID_TO_EXPERT_COLLECTION | ~~disciplineCodes + mapping.json~~ → **[v3.1] disciplineCodes + Registry 推导** |
| `src/services/knowledge-sync.ts` | SERVICE | **SYNC_STATICS_GROUNDING_BACKFILL (v3.1)** | sync 传原始 doc + statics 空内容抛错 | INDEXED 文档三条分支：回填 expertIds / 自动分类 / 刷新 lastSync |
| `src/app/api/knowledge/upload/route.ts` | API | UPLOAD_AUTO_CLASSIFY | FormData 仅 file | 上传自动裁决 → AUTO/PENDING |

---

## Step 3: 缓存与分块升级

### 3.1 目标

语义缓存从全局一刀切改为 per-collection generation map；引入 SmartChunker 语义分块。

> **注意**：SmartChunker 是 Python→TS 移植（司农 chunker.py 439 行），预估 2-3 天。**Step 3 可独立排期，不阻塞 Step 2/4。**

### 3.2 文件清单

| 文件 | action | 说明 |
|------|--------|------|
| `src/services/semantic-cache.ts` | UPDATE | per-collection generation map |
| `src/services/smart-chunker.ts` | CREATE | 语义分块 + 安全切分三级回退 |

### 3.3 实施细节

**per-collection 缓存**:
- 当前: `bumpKbGeneration()` → 全局 `kbGeneration++` → 全部缓存失效
- 改进: `bumpCollectionGeneration("expert_pest_risk")` → 只淘汰该 collection 的缓存
- CacheEntry 记录 `affectedCollections: string[]`
- get() 时比对每个 collection 的 generation

**SmartChunker**:
- embedding 相似度 + 动态百分位阈值（15%）→ 自动检测章节断点
- LLM 仲裁器：相似度在阈值 ± margin 模糊区时 LLM 判断（默认倾向 MERGE）
- 安全切分: 段落 → 句子 → 硬切+overlap 三级回退
- 替换当前 `RecursiveCharacterTextSplitter(chunkSize=1000)`

### 3.4 验收标准

- [ ] 上传到 expert_pest_risk 的文档不淘汰 expert_crop_compare 的缓存
- [ ] SmartChunker 对邗江结构化文档的分块质量优于固定长度切分
- [ ] 安全切分三级回退：超大文档可正确降级

### 3.5 ADD-7 审计策略

| 文件 | targetType | action | beforeState | afterState |
|-----|-----------|--------|------------|-----------|
| `src/services/semantic-cache.ts` | SERVICE | CACHE_PER_COLLECTION | 全局 bumpKbGeneration() | per-collection bumpCollectionGeneration() |
| `src/services/smart-chunker.ts` | SERVICE | SMART_CHUNKER_CREATED | RecursiveCharacterTextSplitter | 语义分块 + 安全切分三级回退 |

---

## Step 4: 管理界面

### 4.1 目标

grounding CRUD API + agrisynapse customization 页面一期（MVP：上传+列表+人工标注）。

### 4.2 文件清单

| 文件 | action | 说明 |
|------|--------|------|
| `src/app/api/knowledge/documents/[id]/grounding/route.ts` | CREATE | PUT disciplineCodes + expertIds |
| `src/app/api/knowledge/grounding/batch/route.ts` | CREATE | POST 批量指派 |
| `src/app/api/knowledge/grounding/stats/route.ts` | CREATE | GET per-discipline + per-expert 统计 |
| `src/app/api/knowledge/grounding/disciplines/route.ts` | CREATE | GET 全量 GB/T 13745 学科列表（前端下拉） |
| agrisynapse: `src/views/llm/customization/index.vue` | REWRITE | 占位页面 → 一期 MVP |

### 4.3 实施细节

**Grounding CRUD API**:
- `PUT /documents/:id/grounding` — 校验 expertId ∈ ANALYSIS_EXPERTS，非法返回 400
- `POST /grounding/batch` — mode: add | replace | remove
- `GET /grounding/stats` — per-discipline + per-expert 覆盖率
- `GET /grounding/disciplines` — 全量学科列表（含中文名）

**customization 一期**:
- 上传组件 + 自动分类结果展示（成功/待分类标记）
- 文档列表（筛选: disciplineCode / expertId / 分类状态 / 业务域）
- disciplineCode/expertId 编辑抽屉（多选下拉，显示中文 label）
- 每行显示：文档名 + 分类状态标签 + 中文学科名 + 业务域徽章

### 4.4 验收标准

- [ ] `PUT /documents/:id/grounding` 非法 expertId 返回 400
- [ ] `POST /grounding/batch` 三种 mode 均正确
- [ ] `GET /grounding/stats` 返回准确统计
- [ ] 定制页面一期：文档列表+筛选+编辑抽屉可用

### 4.5 ADD-7 审计策略

| 文件 | targetType | action | beforeState | afterState |
|-----|-----------|--------|------------|-----------|
| `src/app/api/knowledge/documents/[id]/grounding/route.ts` | API | API_CREATED | 无 | PUT grounding |
| `src/app/api/knowledge/grounding/batch/route.ts` | API | API_CREATED | 无 | POST 批量 |
| `src/app/api/knowledge/grounding/stats/route.ts` | API | API_CREATED | 无 | GET 统计 |
| `src/app/api/knowledge/grounding/disciplines/route.ts` | API | API_CREATED | 无 | GET 学科列表 |
| agrisynapse: `src/views/llm/customization/index.vue` | COMPONENT | COMPONENT_REWRITTEN | 占位页面 | 一期 MVP |

---

## Step 5: 批量管理 + 前端二期 + E2E

### 5.1 目标

映射管理面板 + 批量操作 + 同步按钮 + 端到端验证。

### 5.2 文件清单

| 文件 | action | 说明 |
|------|--------|------|
| `src/app/api/knowledge/grounding/mapping/route.ts` | CREATE | ~~v3.0: PUT 管理 disciplineCode ↔ expertId 映射表（JSON 文件）~~ → **[v3.1] GET/PUT 管理 Registry grounding.disciplineCodes** |
| ~~`src/caijuehub/strategies/discipline-resolver.ts`~~ | -- | **[v3.1 新增]** `resolveExpertIds()` 从 Registry 动态推导（原返回 []） |
| agrisynapse: `src/views/llm/customization/index.vue` | UPDATE | 二期：映射管理 + 批量 + 同步 + SSE 进度 |

### 5.3 实施细节

**映射管理**:
- ~~v3.0: `PUT /grounding/mapping` — 读写 `discipline-to-expert-mapping.json`~~
- ~~v3.0: 前端映射管理面板：表格展示 + 行编辑~~
- **v3.1: 废弃 JSON 文件方案。** 映射管理改为 Registry 驱动：
  - `GET /grounding/mapping` — 返回 Registry 中所有 Expert 的 `grounding.disciplineCodes`
  - `PUT /grounding/mapping` — 更新指定 Expert 的 `grounding.disciplineCodes`
  - `resolveExpertIds(codes)` — 遍历 Registry，匹配 disciplineCodes 交集 → expertId[]
  - 前端映射管理面板：表格展示每个 Expert 的学科代码，支持编辑

**前端二期**:
- 批量操作栏：选中多篇 → 指派/替换/移除
- 同步按钮：触发 `POST /api/knowledge/sync` → SSE 进度条
- 映射管理面板：disciplineCode ↔ expertId 可视化编辑

### 5.4 E2E 验证

- farm-agent `tsc --noEmit` 零错误
- agrisynapse `vue-tsc --noEmit` 仅预存错误
- 上传邗江文档 → 自动分类 → 同步 → ChromaDB expert collection 新增 → 对话 grounding 命中

### 5.5 验收标准

- [ ] ~~v3.0: 映射管理面板可读写 discipline-to-expert-mapping.json~~ → **[v3.1] 映射面板可查看/编辑各 Expert 的 disciplineCodes**
- [ ] **v3.1:** `resolveExpertIds()` 从 Registry 正确推导 expertId
- [ ] 批量指派正确
- [ ] 同步按钮 + SSE 进度正常
- [ ] 全链路：上传→分类→同步→对话命中

### 5.6 ADD-7 审计策略

| 文件 | targetType | action | beforeState | afterState |
|-----|-----------|--------|------------|-----------|
| `src/app/api/knowledge/grounding/mapping/route.ts` | API | API_CREATED | 无 | ~~v3.0: PUT 映射管理~~ → **[v3.1] GET/PUT Registry 映射** |
| `src/caijuehub/strategies/discipline-resolver.ts` | SERVICE | **RESOLVER_EXPERT_LINKED** (v3.1) | resolveExpertIds 返回 [] | 从 Registry 动态推导 expertId[] |
| `src/agents/experts/registry.ts` | SERVICE | **REGISTRY_DISCIPLINE_MAPPED** (v3.1) | grounding 无 disciplineCodes | 各 Expert 声明 disciplineCodes |
| agrisynapse: `src/views/llm/customization/index.vue` | COMPONENT | COMPONENT_UPDATED | 一期 MVP | 二期：批量+映射+同步 |

---

## 六、执行顺序

```
Step 1 (知识分类基座) ─────────────────────┐
  G1: gbt13745-agriculture.json 就绪       │
  G2: discipline-resolver.ts 纯规则版      │
                                           │
                                           ├──→ Step 2 (数据链路)
                                           │    依赖 Step 1 (Resolver + 映射表)
                                           │
                                           ├──→ Step 3 (缓存+分块)
                                           │    可独立排期，不阻塞 Step 2/4
                                           │
                                           ├──→ Step 4 (管理界面)
                                           │    依赖 Step 1 (映射表) + Step 2 (upload API)
                                           │
                                           └──→ Step 5 (批量+E2E)
                                                依赖 Step 4
```

**推荐执行策略**：
1. **Step 1 先做**（全链路根基，前置门禁 G1/G2）
2. **Step 2 紧随**（依赖 Step 1，打通数据链路）
3. **Step 3 可并行**（SmartChunker 独立排期，不影响主线）
4. **Step 4 紧随 Step 2**（管理界面依赖 API）
5. **Step 5 收尾**

---

## 七、关联文档

| 文档 | 路径 |
|------|------|
| 本 Plan | `.qoder/plans/farm-agent-grounding-customization-plan-v3.md` |
| ADD Route | `.qoder/plans/farm-agent-grounding-customization-add-route-v1.md` |
| Handoff | `.qoder/plans/farm-agent-grounding-customization-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-grounding-customization-review-v3.md` |
| Spec | `.qoder/specs/grounding-customization/spec.md` |
| Tasks | `.qoder/specs/grounding-customization/tasks.md` |
| Checklist | `.qoder/specs/grounding-customization/checklist.md` |
| GB/T 13745 数据 | `src/data/gbt13745-agriculture.json` |
| Discipline Resolver | `src/caijuehub/strategies/discipline-resolver.ts` |
| Expert Registry | `src/agents/experts/registry.ts` |
| ~~映射表~~ | ~~`data/discipline-to-expert-mapping.json`~~ → **[v3.1 废弃]** |
| SmartChunker | `src/services/smart-chunker.ts` |
| 语义缓存 (改进) | `src/services/semantic-cache.ts` |
| Sync 脚本 (重写) | `scripts/kb-sync-expert-collections.ts` |
| 前端页面 | agrisynapse `src/views/llm/customization/index.vue` |
| 借鉴源 | 司农 hybrid-rag (南农+南理工) |
| 上游 Plan | `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md` |

---

## 八、v3.2 补丁记录（2026-06-16）

> 实际运行中发现的数据一致性与前端渲染缺陷，涉及 Step 2 + Step 4/5 交叉区域。

### 8.1 问题基线

| # | 现象 | 根因 | 影响范围 |
|---|------|------|----------|
| 1 | 8 个同步出错文件在 UI 显示「就绪」 | `syncAllKnowledge` statics 循环 catch 只 log 不设 ERROR 状态 | Step 2: knowledge-sync.ts |
| 2 | 同步结果 `errors: []`, `knowledgeUpdateErrors: 0` | 返回值硬编码，不跟踪实际失败数 | Step 2: knowledge-sync.ts |
| 3 | 状态列无法区分 error/pending/outdated | 前端只判断 `status === 'indexed'`（而后端返回 `'ready'`） | Step 4: customization/index.vue |
| 4 | 「就绪可用」统计卡数字始终为 0 | `readyCount` 计算用 `'indexed'` 而非后端实际返回的 `'ready'` | Step 4: customization/index.vue |
| 5 | 分页控件缺少页码大小切换、总数显示 | 使用原始 `el-pagination` 而非项目封装的 `Pagination` 组件 | Step 5: customization/index.vue |

### 8.2 修复文件清单

| 文件 | action | 说明 |
|------|--------|------|
| `src/services/knowledge-sync.ts` | UPDATE | 新增 `pendingErrorCount` / `staticErrorCount` 计数器 + `errorNames` 数组；statics 循环 catch 设置 `DOC_STATUS.ERROR`；返回值使用真实计数 |
| agrisynapse: `src/views/llm/customization/index.vue` | UPDATE | 替换 `el-pagination` → `Pagination` 组件；新增 `STATUS_MAP` + `statusTagType()` + `statusLabel()` 渲染所有 UIStatus；修复 `readyCount` 判断条件 |

### 8.3 后端修复细节（Step 2: knowledge-sync.ts）

**syncAllKnowledge() 错误追踪**:
- `pendingDocs` 循环 catch: `pendingErrorCount++` + `errorNames.push(doc.name)` → 原有 `DOC_STATUS.ERROR` 设置保持不变
- `statics` 循环 catch: **新增** `staticErrorCount++` + `errorNames.push(doc.name)` + `prisma.document.update({ status: DOC_STATUS.ERROR, ... })` → 避免回填失败时文档继续显示为 ready
- 返回值: `errors: errorNames`（原来 `[] as string[]`）、`knowledgeUpdateErrors: pendingErrorCount + staticErrorCount`（原来 `0`）、`knowledgeUpdateIndexed: pendingDocs.length - pendingErrorCount`（原来 `pendingDocs.length`）

### 8.4 前端修复细节（Step 4/5: customization/index.vue）

**分页统一**: `el-pagination`（仅 prev/pager/next）→ 项目封装 `Pagination` 组件（total/sizes/prev/pager/next/jumper），与 farm-info 页面保持一致。

**状态列渲染**: 新增 `STATUS_MAP` 查表，覆盖后端 `STATUS_DISPLAY` 返回的全部 UIStatus：

| status 值 | 中文标签 | el-tag type |
|-----------|---------|-------------|
| `ready` | 就绪 | success (绿) |
| `error` | 错误 | danger (红) |
| `outdated` | 过期 | warning (橙) |
| `pending` | 待处理 | info (灰) |
| `processing` | 处理中 | primary (蓝) |
| `unknown` | 未知 | info (灰) |

**readyCount 修正**: `d.status === 'indexed'` → `d.status === 'ready'`（匹配后端 `STATUS_DISPLAY[INDEXED] = "ready"`）。

### 8.5 ADD-7 审计策略

| 文件 | targetType | action | beforeState | afterState |
|-----|-----------|--------|------------|----------|
| `src/services/knowledge-sync.ts` | SERVICE | SYNC_ERROR_TRACKING_FIXED | 同步返回值 errors/knowledgeUpdateErrors 硬编码；statics catch 不设 ERROR | 真实错误计数+回填失败状态标记 |
| agrisynapse: `src/views/llm/customization/index.vue` | COMPONENT | STATUS_RENDERING_AND_PAGINATION_FIXED | 状态列只判断 'indexed'；readyCount 失效；el-pagination 原始控件 | STATUS_MAP 全状态渲染；Pagination 组件；readyCount 修正 |
