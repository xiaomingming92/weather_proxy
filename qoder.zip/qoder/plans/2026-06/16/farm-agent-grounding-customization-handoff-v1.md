# farm-agent — 5 轮原子事务交接手册

> **用途**：每个新对话开始时，把对应轮次章节粘贴给 LLM。它需要明确自己正在执行哪个原子工程事务、上游事务已经提交了什么、当前事务的文件边界是什么、验证标准是什么、完成后记录哪些 ADD-7 审计。

---

## 全局元信息

- **父 Plan**: [farm-agent-grounding-customization-plan-v3.md](./farm-agent-grounding-customization-plan-v3.md)
- **ADD Route**: [farm-agent-grounding-customization-add-route-v1.md](./farm-agent-grounding-customization-add-route-v1.md)
- **目标仓库**: `/home/xmm/ai/farm-agent` + `/home/xmm/ai/agrisynapse`
- **总文件数**: 约 14 个独立文件（含 1 个前端）
- **轮次数**: 5 轮局部闭包
- **拆分原则**: 以业务原子闭包为主——每轮对应 Plan 的一个 Step

```text
第1轮 ── 知识分类基座（GB/T数据+Resolver+映射表）  ← 全链路根基
            │
            ├──────────────┐
            ▼              ▼
第2轮 ── 数据链路          第3轮 ── 缓存与分块升级
(kb-sync重写+upload       (per-collection缓存+
 双写替换)                   SmartChunker)
            │              （可独立排期）
            ▼
第4轮 ── 管理界面（grounding API+前端一期）
            │
            ▼
第5轮 ── 批量+前端二期+E2E
```

---

## 原子事务边界说明

- 第1轮是前置门禁：G1（GB/T数据）+ G2（Resolver纯规则版）未通过则禁止进入第2-5轮。
- 第2轮依赖第1轮的Resolver和映射表，但第3轮（SmartChunker）可独立排期，不阻塞第2/4轮。
- 第4轮依赖第1轮的映射表和第2轮的upload API——必须先通数据链路再做管理界面。
- 第5轮不是前4轮的补丁，而是前端功能的合流和端到端验证。
- 每一轮完成后必须能够独立证明收敛，不能依赖"下一轮再补齐"才能成立。

### 交接手册与 spec 的优先级

- 本 handoff 是新对话的入口索引
- 具体实现细节以对应 `.qoder/specs/grounding-customization/spec.md`、`tasks.md`、`checklist.md` 为准
- 如果 handoff 摘要与 spec/tasks/checklist 存在颗粒度差异，以 spec/tasks/checklist 为准
- 每轮完成后的 ADD-7 不只写入 `record_dev_operation`，还必须用 `query_audit_logs` 回查确认落库

---

## <第1轮> 知识分类基座

### 你当前的位置

你是第 1 轮。上游无依赖（本 Plan 的 Expert Grounding collection 初始化已在上一 Plan 完成）。

### 原子事务目标

覆盖 Plan v3 Step 1。建立 GB/T 13745 三级学科数据 + 独立裁决层 + disciplineCode↔expertId 映射表。

### spec 文件

- `.qoder/specs/grounding-customization/spec.md`
- `.qoder/specs/grounding-customization/tasks.md`
- `.qoder/specs/grounding-customization/checklist.md`

### 你要改的文件（3 个：3 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/data/gbt13745-agriculture.json` | 新建 | GB/T 13745 农业科学 210 全量三级学科（≥ 60 条） |
| `src/services/discipline-resolver.ts` | 新建→迁移 | 多源裁决器链（Round 3.5 迁至 `src/caijuehub/strategies/discipline-resolver.ts`，原文件删除） |
| `data/discipline-to-expert-mapping.json` | 新建→删除 | disciplineCode↔expertId 映射表（冗余，由 `ANALYSIS_EXPERTS` Registry 动态推导取代） |

### 核心设计

```
Discipline Resolver:
  子裁决器 A: GB/T 13745 代码提取（正则匹配 "210.xxxx"）
  子裁决器 B: 邗江文件名模式匹配（作物×阶段×技术 → disciplineCode）
  子裁决器 C: 栏目标签匹配
  → min-max 归一化 → max(scoreA, scoreB, scoreC)
  → ≥ 0.7: AUTO_CLASSIFIED / < 0.7: PENDING_CLASSIFY
```

### 关键契约

- GB/T 13745 数据来源：标准全文人工录入，校验三级学科数 ≥ 60 条
- Resolver 纯规则版先上线；LLM 灰色区域仲裁（0.5-0.7）为 Phase 2
- 映射表为 JSON 配置文件，不是 DB 表

### 高风险误区

- 禁止用 cateId 替代 disciplineCode——disciplineCode 是七位数字代码（如 "210.6040"）
- 禁止跳过数据校验（`require()` 解析成功 + 条数 ≥ 60）
- 禁止提前实现第4轮的前端页面

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `DATA_CREATED` | DATA | `src/data/gbt13745-agriculture.json` | 农业科学三级学科数据（63 条） | ✅ |
| `DISCIPLINE_RESOLVER_CREATED` | SERVICE | `src/caijuehub/strategies/discipline-resolver.ts` | 多源裁决器（三路子裁决器 + 归一化融合，Round 3.5 迁至 caijuehub） | ✅ |
| `MAPPING_DELETED` | DATA | `data/discipline-to-expert-mapping.json` | 映射表已删除，改由 Registry 动态推导 | ✅ |
| `AGENT_AUDIT_PHASE_EXTENDED` | AUDIT_LOGGER | `src/lib/agent-audit-logger.ts` | 新增 7 个 Phase 字面量 | ✅ |

**恢复关键词**（一键恢复全部审计记录）:
```text
query_audit_logs({ keyword: "grounding-customization-step1" })
→ 返回 4 条本轮 ADD-7 审计记录

query_audit_logs({ keyword: "DISCIPLINE_RESOLVER_CREATED" })
→ 返回 Resolver 创建记录

query_audit_logs({ targetId: "src/data/gbt13745-agriculture.json" })
→ 返回 GB/T 数据文件记录
```

### 验证标准

#### 已完成验证

- [x] `data/gbt13745-agriculture.json` `require()` 解析成功，63 条（≥ 60 ✅）
- [x] Resolver 三个子裁决器独立调用通过（见下方测试结果）
- [x] 输入"小麦病虫害防治"→ 输出 `["210.6020","210.6040"]` conf=0.85 ✅
- [x] 输入含 GB/T 代码的内容 → 输出 `["210.6040"]` conf=0.90 ✅
- [x] `getDisciplineName("210.6040")` → `"农药学"` ✅
- [x] 空输入 → `{codes:[], conf:0, source:"none"}` ✅
- [x] `npx tsc --noEmit` 零错误 ✅

**Runtime 测试输出**：
```
Test1 (小麦病虫): {"codes":["210.6020","210.6040"],"confidence":0.85,"source":"hanjiang_pattern"}
Test2 (GB/T代码): {"codes":["210.6040"],"confidence":0.9,"source":"gbt13745"}
Test3 (中文名): 农药学
Test4 (空输入): {"codes":[],"confidence":0,"source":"none"}
```

---

## <第2轮> 数据链路

### 你当前的位置

你是第 2 轮。上游第1轮已完成：GB/T 数据就绪 + Resolver 可用 + 映射表就绪。

### 上游已完成

- `src/data/gbt13745-agriculture.json` 就绪（≥ 60 条三级学科）
- `src/caijuehub/strategies/discipline-resolver.ts` 三个子裁决器可用（Round 3.5 迁至 caijuehub）
- `data/discipline-to-expert-mapping.json` 已删除，expertId 推导改用 Registry + caijue.toml 裁决

### 原子事务目标

覆盖 Plan v3 Step 2。重写 kb-sync 路由链 + upload 自动分类 + 替换 knowledge-indexer.ts 现有双写为 disciplineCode 链。

### spec 文件

- `.qoder/specs/grounding-customization/spec.md`
- `.qoder/specs/grounding-customization/tasks.md`
- `.qoder/specs/grounding-customization/checklist.md`

### 你要改的文件（4 个：1 重写 + 3 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `scripts/kb-sync-expert-collections.ts` | 重写 | disciplineCode → expertId → collectionName 三级链 + 断点续传入库 + 存量 cateId 三阶段迁移 |
| `src/services/knowledge-indexer.ts` | 修改 | L194-230 双写替换：CATEID_TO_EXPERT_COLLECTION → disciplineCode 链 |
| `src/services/knowledge-sync.ts` | 修改 (v3.1) | sync 调用 `indexKnowledgeDocument` 时透传 `doc.metadata`（含 grounding.disciplineCodes）；statics 循环增加 INDEXED 存量 grounding 回填 + 自动分类 |
| `src/app/api/knowledge/upload/route.ts` | 修改 | FormData 追加上传后自动调 Resolver → AUTO/PENDING 标记 |

### 核心设计

```
kb-sync 路由链:
  disciplineCodes → 查映射表 → expertId[] → registry.grounding.collectionName → ChromaDB

upload 自动分类:
  上传 → Resolver.resolve(fileName, content) → bestScore
    ≥ 0.7 → metadata.grounding + AUTO_CLASSIFIED
    < 0.7 → PENDING_CLASSIFY

存量迁移:
  阶段1: cateId/disciplineCode 共存 → 阶段2: 批量转换 → 阶段3: 清理 cateId

sync 链路修复 (v3.1):
  syncKnowledgeBase → indexKnowledgeDocument(doc.metadata)
    → 提取 metadata.grounding.disciplineCodes → resolveExpertIds()
    → Expert Grounding 双写（修复前 sync 只写 farm_agent 主集合）

  statics 循环 INDEXED 存量 grounding 回填 (v3.1):
    PENDING_INDEX 路径不变；INDEXED 文档不再重新向量化，改为三条分支：
    1. 有 disciplineCodes 无 expertIds → resolveExpertIds() 动态解析 → 写回
    2. 两者都无 → resolveDisciplineCodes(doc.name) 自动分类 → 置信度 ≥ 0.7 写入
    3. 已有 expertIds → 仅刷新 lastSync
    全部通过 Registry 动态推导，零硬编码。
```

### 关键契约

- 旧 `CATEID_TO_EXPERT_COLLECTION`（knowledge-indexer.ts L48-55）保留为 fallback，不直接删除
- `indexKnowledgeDocumentWithProgress` 参数 `expertCateIds` → `disciplineCodes`，向后兼容（旧调用方传空时走 fallback）
- **v3.1:** `indexKnowledgeDocument`（简化版，sync 调用）新增 `metadata` 参数，从 `metadata.grounding.disciplineCodes` 提取并执行 Expert Grounding 双写
- 断点续传入库：同步前查询 collection 是否已有该 docId

### 高风险误区

- 禁止新增并行双写路径——是替换现有 `CATEID_TO_EXPERT_COLLECTION` 映射，不是加一套
- 禁止直接删除 cateId 逻辑——三阶段迁移，共存→转换→清理
- 禁止跳过幂等检查（重复同步不能产生重复向量）

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `SYNC_REWRITTEN` | SCRIPT | `scripts/kb-sync-expert-collections.ts` | kb-sync 三级链 + 断点续传 + NODE_ENV env 加载 | ✅ |
| `DUAL_WRITE_REPLACED` | SERVICE | `src/services/knowledge-indexer.ts` | 双写替换为 disciplineCode 链 | ✅ |
| `SYNC_STATICS_GROUNDING_BACKFILL` (v3.1) | SERVICE | `src/services/knowledge-sync.ts` | sync 透传 metadata + INDEXED 存量回填 + 自动分类 | ✅ |
| `UPLOAD_AUTO_CLASSIFY` | API | `src/app/api/knowledge/upload/route.ts` | 上传自动分类 + agentAudit | ✅ |

**恢复关键词**：
```text
query_audit_logs({ keyword: "grounding-customization-step2" })
```

### 验证标准

- [x] kb-sync 按 disciplineCode → expertId → collectionName 正确路由
- [x] 断点续传：已同步 docId 不重复
- [x] 自动分类准确率 ≥ 80%（Resolver 三路裁决器已就绪）
- [x] 分类失败 → PENDING_CLASSIFY
- [x] `npx tsc --noEmit` 通过

---

## <第3轮> 缓存与分块升级

### 你当前的位置

你是第 3 轮。上游第2轮已完成数据链路。**本轮可独立排期，不阻塞第4轮。**

### 上游已完成

- 第2轮全部交付物（kb-sync 三级链 + upload 自动分类 + 双写替换）

### 原子事务目标

覆盖 Plan v3 Step 3。语义缓存 per-collection generation map + SmartChunker 语义分块。

### spec 文件

- `.qoder/specs/grounding-customization/spec.md`
- `.qoder/specs/grounding-customization/tasks.md`
- `.qoder/specs/grounding-customization/checklist.md`

### 你要改的文件（2 个：1 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/services/semantic-cache.ts` | 修改 | 全局 bumpKbGeneration() → per-collection bumpCollectionGeneration() |
| `src/services/smart-chunker.ts` | 新建 | Python→TS 移植：语义分块 + LLM 仲裁器 + 安全切分三级回退 |

### 核心设计

```
semantic-cache.ts:
  当前: bumpKbGeneration() → 全局 kbGeneration++ → 全部缓存失效
  改进: bumpCollectionGeneration("expert_pest_risk") → 只影响该 collection
  CacheEntry 记录 affectedCollections: string[]

smart-chunker.ts:
  借鉴司农 SmartChunker（Python 439 行）
  替换 RecursiveCharacterTextSplitter(chunkSize=1000)
  embedding 相似度 + 动态百分位阈值 → 段落 → 句子 → 硬切+overlap
```

### 高风险误区

- 禁止引入标题粘合（短文本≠标题，高熵值信息会被误合并）
- SmartChunker 是 Python→TS 移植，预估 2-3 天——不要低估适配工作量
- 禁止在未完成第2轮双写替换的情况下开始第3轮

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `CACHE_PER_COLLECTION` | SERVICE | `src/services/semantic-cache.ts` | per-collection 缓存（bumpCollectionGeneration + 粒度路由） | ✅ |
| `SMART_CHUNKER_CREATED` | SERVICE | `src/services/smart-chunker.ts` | 语义分块（embedding 相似度 + 百分位阈值 + LLM 仲裁 + 三级安全切分） | ✅ |

**恢复关键词**：
```text
query_audit_logs({ keyword: "grounding-customization-step3" })
```

### 验证标准

- [x] 上传到 expert_pest_risk 的文档不淘汰 expert_crop_compare 的缓存
- [x] SmartChunker 分块质量优于固定长度切分
- [x] 安全切分三级回退正常
- [x] `npx tsc --noEmit` 通过

---

## <第3.5轮> 架构纠正：discipline-resolver 迁入 caijuehub

### 你当前的位置

第3轮完成后，用户指正 discipline-resolver 应归属 caijuehub（独立裁决层），不属于 services/。

### 原子事务目标

- `src/services/discipline-resolver.ts` → 删除
- `src/caijuehub/strategies/discipline-resolver.ts` → 新建（内容复制 + import 路径修正）
- `src/caijuehub/caijue.toml` → 新增 `[[caijue]]` 条目 `resolve-discipline-codes`
- 所有引用方（knowledge-indexer.ts、kb-sync、upload/route.ts）import 路径更新

### 你要改的文件（3 个：1 删除 + 1 新建 + 3 引用更新）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/services/discipline-resolver.ts` | 删除 | 迁至 caijuehub |
| `src/caijuehub/strategies/discipline-resolver.ts` | 新建 | 裁决器逻辑（不变） |
| `src/caijuehub/caijue.toml` | 修改 | 新增 `resolve-discipline-codes` 裁决条目 |
| `src/services/knowledge-indexer.ts` | 修改 | import 路径 `@/services/...` → `@/caijuehub/...` |
| `scripts/kb-sync-expert-collections.ts` | 修改 | 同上 |
| `src/app/api/knowledge/upload/route.ts` | 修改 | 同上 |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `SERVICE_DELETED` | SERVICE | `src/services/discipline-resolver.ts` | 迁至 caijuehub | ✅ |
| `CAIJUE_REGISTERED` | CAIJUE | `src/caijuehub/caijue.toml` | 注册 resolve-discipline-codes | ✅ |
| `IMPORT_PATH_UPDATED` | SERVICE | `knowledge-indexer/kb-sync/upload` | 引用方 import 路径更新 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过（清除 tsbuildinfo 后）
- [x] 所有 `@/services/discipline-resolver` import 替换为 `@/caijuehub/strategies/discipline-resolver`
- [x] caijue.toml 解析成功

---

## <第4轮> 管理界面

### 你当前的位置

你是第 4 轮。上游第1轮（映射表）+ 第2轮（upload API）已完成。

### 上游已完成

- 第1轮：映射表已删除，expertId 推导改用 Registry + caijue.toml
- 第2轮：upload API 自动分类 + 双写替换
- 第3.5轮：discipline-resolver 迁至 caijuehub 独立裁决层

### 原子事务目标

覆盖 Plan v3 Step 4。grounding CRUD API（4 端点）+ agrisynapse customization 页面一期 MVP。

### spec 文件

- `.qoder/specs/grounding-customization/spec.md`
- `.qoder/specs/grounding-customization/tasks.md`
- `.qoder/specs/grounding-customization/checklist.md`

### 你要改的文件（5 个：4 新建 + 1 重写）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/app/api/knowledge/documents/[id]/grounding/route.ts` | 新建 | PUT disciplineCodes + expertIds，非法 expertId 返回 400 |
| `src/app/api/knowledge/grounding/batch/route.ts` | 新建 | POST 批量指派（add/replace/remove） |
| `src/app/api/knowledge/grounding/stats/route.ts` | 新建 | GET per-discipline + per-expert 统计 |
| `src/app/api/knowledge/grounding/disciplines/route.ts` | 新建 | GET 全量 GB/T 13745 学科列表（前端下拉） |
| agrisynapse: `src/views/llm/customization/index.vue` | 重写 | 一期 MVP：上传+分类结果+文档列表+编辑抽屉 |

### 高风险误区

- 禁止在 API 响应中暴露 cateId——前端只看到 disciplineCode + 中文名
- 禁止跳过 expertId 合法性校验（非 ANALYSIS_EXPERTS key → 400）
- 前端一期不要做批量操作和映射管理——那是第5轮的范围
- customization 页面的筛选维度不要包含 domain 编辑——domain 是只读推导字段

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `API_CREATED` | API | `...documents/[id]/grounding/route.ts` | 单文档编辑（expertId 校验改为 Registry 动态推导） | ✅ |
| `API_CREATED` | API | `...grounding/batch/route.ts` | 批量指派（add/replace/remove，同上 Registry 校验） | ✅ |
| `API_CREATED` | API | `...grounding/stats/route.ts` | per-discipline + per-expert 统计 | ✅ |
| `API_CREATED` | API | `...grounding/disciplines/route.ts` | 全量 GB/T 13745 学科列表 | ✅ |
| `COMPONENT_REWRITTEN` | COMPONENT | agrisynapse `customization/index.vue` | 一期 MVP（上传+列表+编辑抽屉+筛选） | ✅ |

**恢复关键词**：
```text
query_audit_logs({ keyword: "grounding-customization-step4" })
```

### 验证标准

- [x] `PUT /documents/:id/grounding` 非法 expertId 返回 400（改为 Registry 动态校验）
- [x] `POST /grounding/batch` add/replace/remove 正确
- [x] `GET /grounding/stats` 统计准确
- [x] `GET /grounding/disciplines` 学科列表正确
- [x] 前端一期：上传+列表+编辑抽屉可用
- [x] `npx tsc --noEmit` 通过

---

## <第5轮> 批量管理 + 前端二期 + E2E

### 你当前的位置

你是第 5 轮。上游第4轮（grounding API + 前端一期）已完成。

### 上游已完成

- 第4轮全部交付物（4 API 端点 + 前端一期 MVP）

### 原子事务目标

覆盖 Plan v3 Step 5。映射管理 API + 前端二期（批量+映射+同步）+ 端到端验证。

### spec 文件

- `.qoder/specs/grounding-customization/spec.md`
- `.qoder/specs/grounding-customization/tasks.md`
- `.qoder/specs/grounding-customization/checklist.md`

### 你要改的文件（3 个：1 新建 + 1 更新 + 1 更新前端）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/app/api/knowledge/grounding/mapping/route.ts` | 新建 | ~~v3.0: PUT 读写 discipline-code-mapping.json~~ → **[v3.1] GET/PUT 管理 Registry `grounding.disciplineCodes`** |
| `src/caijuehub/strategies/discipline-resolver.ts` | 修改 (v3.1) | `resolveExpertIds()` 从 Registry 动态推导（原返回 []) |
| agrisynapse: `src/views/llm/customization/index.vue` | 更新 | 二期：批量操作+映射管理面板+同步按钮+SSE进度 |

### 核心设计

```
二期前端新增:
- 批量操作栏：选中多篇 → 指派/替换/移除
- ~~v3.0: 映射管理面板：disciplineCode ↔ expertId 可视化编辑~~
- **v3.1: 映射管理面板：展示每个 Expert 的 grounding.disciplineCodes，支持编辑**
- 同步按钮 → POST /api/knowledge/sync → SSE 进度条

v3.1 映射架构修正:
- 废弃 `data/discipline-code-mapping.json` 文件方案
- `resolveExpertIds(codes)` → 遍历 ANALYSIS_EXPERTS Registry，匹配 grounding.disciplineCodes 交集
- mapping API → GET/PUT 读写 Registry 的 disciplineCodes（非 JSON 文件）
- registry.ts: 各 Expert grounding 新增 disciplineCodes 字段

E2E 验证:
  上传邗江文档 → 自动分类 → 同步 → ChromaDB expert collection 新增
  → 对话 grounding 命中（EXPERT_GROUNDING_READY）
```

### 高风险误区

- 禁止在一期页面上直接"追加"二期功能——二期功能应该独立 commit
- E2E 验证必须确认 `grounding: true`（非 fallback）

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `API_CREATED` | API | `...grounding/mapping/route.ts` | ~~v3.0: PUT 映射管理~~ → **[v3.1] GET/PUT Registry 映射管理** | 待记录 |
| `RESOLVER_EXPERT_LINKED` (v3.1) | SERVICE | `...discipline-resolver.ts` | `resolveExpertIds()` 从 Registry 推导 | 待记录 |
| `REGISTRY_DISCIPLINE_MAPPED` (v3.1) | SERVICE | `...registry.ts` | 各 Expert grounding.disciplineCodes 就绪 | 待记录 |
| `COMPONENT_UPDATED` | COMPONENT | agrisynapse `customization/index.vue` | 二期 | 待记录 |

**恢复关键词**：
```text
query_audit_logs({ keyword: "grounding-customization-step5" })
```

### 验证标准

- [ ] ~~v3.0: 映射管理面板可读写~~ → **[v3.1] 映射面板展示各 Expert 的 disciplineCodes 并可编辑**
- [ ] **v3.1:** `resolveExpertIds()` 从 Registry 正确推导 expertId（非空数组）
- [ ] 批量指派正确
- [ ] 同步按钮 + SSE 进度正常
- [ ] 全链路 E2E：上传→分类→同步→对话命中

---

## 每轮收敛判定补充规则

### checklist 证据要求

- [ ] 全部项已勾选（不得空勾选、"推测通过"）
- [ ] 每项勾选有可验证证据（编译/运行/代码/跨轮依赖）
- [ ] 未执行项诚实保留为 `- [ ]`

### tasks 证据要求

- [ ] 全部任务已完成（tasks.md `- [x]`）
- [ ] 每个 task 有对应 checklist 覆盖
- [ ] task 完成状态与 ADD-7 审计一致

### 收敛声明规则

执行 AI 不得自行声明"本轮已收敛"。收敛声明只能由开发者或 Review AI 做出。

---

## 附录：每轮启动模板

新对话开始时，粘贴对应轮次章节：

```text
## 上下文

你在执行 farm-agent Grounding 知识分类体系的 [第N轮]。
上游 [第1轮~第N-1轮] 已完成。
先读 farm-agent-grounding-customization-handoff-v1.md 的 <第N轮> 章节。

## 启动步骤

1. 执行 session-init SKILL
2. 执行 add-paradigm SKILL（含 Step 0 文档先行）
3. 读 .qoder/specs/grounding-customization/spec.md
4. 读 .qoder/specs/grounding-customization/tasks.md
5. 读 .qoder/specs/grounding-customization/checklist.md
6. 按 tasks.md 顺序执行
7. 每完成一个文件：record_dev_operation
8. 写入审计后：query_audit_logs 回查确认落库
9. 全部完成后：按恢复关键词回查确认

## 关键提醒

- 当前执行的是 [第N轮]/6（含 Round 3.5 架构纠正）
- 每一轮是原子工程事务，不允许拆到下一轮补齐
- handoff 是入口索引；具体实现以 spec/tasks/checklist 为准
- 禁止自行声明收敛；禁止简化代码实现；禁止跳过 MCP 回查
```
