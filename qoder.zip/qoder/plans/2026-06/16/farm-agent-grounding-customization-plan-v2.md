# farm-agent-grounding-customization-plan-v2

> Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。

## PLAN 元信息

- **Plan 名称**: farm-agent-grounding-customization-v2
- **启动时间**: 2026-06-16T10:00:00+08:00
- **范围**: farm-agent 知识分类裁决层 + kb-sync 完全重写 + agrisynapse customization 页面 + GB/T 13745 数据集成
- **触发来源**: v1 Plan Review 结论 + 领域专家对三层分类模型的修正
- **关联文档**:
  - 本 Plan: `.qoder/plans/farm-agent-grounding-customization-plan-v2.md`
  - 前版 Plan: `.qoder/plans/farm-agent-grounding-customization-plan-v1.md`（作废）
  - 前版 Review: `.qoder/reviews/farm-agent-grounding-customization-review-v1.md`（作废，P0 项已吸收）
  - ADD Route: `.qoder/plans/farm-agent-grounding-customization-add-route-v1.md`（待重新生成）
  - Handoff: `.qoder/plans/farm-agent-grounding-customization-handoff-v1.md`（待生成）
  - Review: `.qoder/reviews/farm-agent-grounding-customization-review-v2.md`（待生成）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/services/discipline-resolver.ts` | SERVICE | SERVICE_CREATED | 无独立裁决层，cateId 关键词推断 | 多源裁决器链 + 两阶段关键词预标注 + 子裁决器评分归一化融合 + LLM 灰色区域仲裁 | 待实施 |
| `src/data/gbt13745-agriculture.json` | DATA | DATA_CREATED | 无 GB/T 13745 结构化数据 | 农业科学 210 全量三级学科（8 个二级 + 60+ 个三级） | 待实施 |
| `src/services/smart-chunker.ts` | SERVICE | SERVICE_CREATED | 固定长度切分 | 语义分块（embedding 相似度 + 动态百分位阈值）+ 安全切分三级回退 | 待实施 |
| `src/services/semantic-cache.ts` | SERVICE | SERVICE_UPDATED | 全局 kbGeneration，一刀切淘汰 | per-collection generation map，只淘汰受影响 expert 的缓存 | 待实施 |
| `scripts/kb-sync-expert-collections.ts` | SCRIPT | SCRIPT_REWRITTEN | cateId 关键词推断 → CATEID_TO_COLLECTIONS 路由 | disciplineCode → expertId → collectionName 三级链 + 断点续传入库 | 待实施 |
| `src/app/api/knowledge/upload/route.ts` | API | API_UPDATED | FormData 仅接收 file | 上传时自动裁决 disciplineCodes，失败则 PENDING_CLASSIFY | 待实施 |
| `src/app/api/knowledge/documents/[id]/grounding/route.ts` | API | API_CREATED | 无 | PUT disciplineCodes + expertIds | 待实施 |
| `src/app/api/knowledge/grounding/batch/route.ts` | API | API_CREATED | 无 | POST 批量指派 | 待实施 |
| `src/app/api/knowledge/grounding/stats/route.ts` | API | API_CREATED | 无 | GET per-discipline + per-expert 统计 | 待实施 |
| `src/services/knowledge-sync.ts` | SERVICE | SERVICE_UPDATED | 仅写 farm_agent | 同步后自动联动 Expert Collections（幂等） | 待实施 |
| agrisynapse: `src/views/llm/customization/index.vue` | COMPONENT | COMPONENT_REWRITTEN | 占位页面 | 上传+自动分类+人工标注+同步管理 | 待实施 |

---

## 〇、前置门禁（P0 阻断）

**以下产出必须在任何其他 Task 开始前完成，否则所有下游任务无法启动：**

| 门禁项 | 产出 | 验证方式 |
|--------|------|---------|
| G1 | `data/gbt13745-agriculture.json` 就绪（≥ 60 条三级学科） | `node -e "require('./src/data/gbt13745-agriculture.json')"` 解析成功 |
| G2 | `src/services/discipline-resolver.ts` 纯规则版可用（三个子裁决器可独立调用） | 单元测试：输入"小麦病虫害防治"→输出至少1条 disciplineCode |

**未通过 G1/G2 前，禁止进入 Task 3-9。**

---

## 一、背景与目标

### 1.1 问题现状

当前 `kb-sync-expert-collections.ts` 通过 6 个 hardcoded cateId + 文件名关键词推断来决定文档归属哪些 Expert Collection。存在三个层次的问题：

| 层次 | 问题 |
|------|------|
| **分类粒度** | cateId 是粗粒度的"二级学科"（如 `plant_protection`），专业农业知识以三级学科为原子单元提交（如 `210.6040 农药学`、`210.6020 植物病理学`） |
| **分类体系** | 只有一套关键词匹配逻辑，无法适配三种完全不同的知识来源：GB/T 13745 学术文献、邗江农技站报告（按作物+阶段+技术三维标签）、农技云 App 文章（按省级栏目标签） |
| **可管理性** | 不可控、不可见、不可改——用户无法查看某篇文档归属了哪些 Expert Collection，更无法手动修正或指派 |

### 1.2 三大知识来源

| 来源 | 文档类型 | 示例 | 分类特征 |
|------|---------|------|---------|
| **学术/技术文献** | 论文、标准、专利、技术报告 | — | 自带 GB/T 13745 代码或可从内容提取 |
| **邗江区农技站** | 定期农业技术信息报告（PDF/docx） | 「2025年第6期 小麦主要病虫害发生及防治意见」 | 文件名含期号+作物+阶段+技术类型三维标签 |
| **农技云 App** | 江苏省农业农村厅发布文章（粘贴） | — | 页面自带栏目标签（植保/栽培/土肥等） |

### 1.3 目标

1. **独立裁决层**：构建 Discipline Resolver，含多源子裁决器链，GB/T 13745 为必要子集
2. **自动分类**：上传时自动运行裁决层，成功则直接入库，失败则 PENDING_CLASSIFY → 前端人工标注
3. **kb-sync 完全重写**：路由链路改为 `disciplineCode → expertId → collectionName`，不再硬编码 cateId
4. **customization 页面**：上传+自动分类结果展示+人工标注+同步管理一站式

---

## 二、架构设计

### 2.1 三层分类模型

```
Layer 1: 农业活动域
  ExpertDomain: "耕" | "种" | "管" | "收" | "巡检" | "跨域"
  来源: Registry ANALYSIS_EXPERTS[expertId].domain
  用户: 只读徽章，前端列表筛选

Layer 2: GB/T 13745 二级学科
  cateId: "210.30" 农艺学 / "210.60" 植物保护学 / "210.50" 土壤学
  来源: 从 disciplineCode 前 6 位推导
  用户: 不可见，内部分组

Layer 3: GB/T 13745 三级学科 ★ 核心 ★
  disciplineCode: "210.6040" 农药学 / "210.6020" 植物病理学
  来源: 裁决层自动识别 或 用户手动指派
  用户: 可 CRUD，前端多选
```

### 2.2 独立裁决层 (Discipline Resolver)

```
                     ┌──────────────────────────────┐
                     │     Discipline Resolver      │
                     │     (独立裁决层)              │
                     └──────────────┬───────────────┘
                                    │
          ┌─────────────────────────┼─────────────────────────┐
          ▼                         ▼                         ▼
┌─────────────────────┐ ┌─────────────────────┐ ┌─────────────────────┐
│ 子裁决器 A          │ │ 子裁决器 B          │ │ 子裁决器 C          │
│ GB/T 13745 解析器   │ │ 农技推广体系解析器   │ │ 省级农业部门解析器   │
├─────────────────────┤ ├─────────────────────┤ ├─────────────────────┤
│ 适用: 学术文献       │ │ 适用: 邗江农技报告   │ │ 适用: 农技云文章      │
│ 策略:               │ │ 策略:               │ │ 策略:               │
│ 1. 提取文档自带     │ │ 文件名模式匹配:      │ │ 1. 页面栏目标签      │
│    disciplineCode   │ │ "小麦"+"病虫防治"    │ │    → disciplineCode │
│ 2. 内容关键词 →     │ │ → "210.6020"        │ │ 2. 内容关键词       │
│    映射表           │ │ → "210.6040"        │ │    → 映射表         │
│ 3. 置信度评分       │ │ 模式表预置 30+ 规则  │ │ 3. 置信度评分        │
└─────────────────────┘ └─────────────────────┘ └─────────────────────┘
          │                         │                         │
          └─────────────────────────┼─────────────────────────┘
                                    ▼
                    ┌──────────────────────────────┐
                    │  任一子裁决器 置信度 >= 阈值   │
                    │  → AUTO_CLASSIFIED           │
                    │  全部 < 阈值                  │
                    │  → PENDING_CLASSIFY          │
                    └──────────────────────────────┘
```

### 2.3 数据模型

```typescript
// GB/T 13745 结构化数据 (data/gbt13745-agriculture.json)
interface GbtDiscipline {
  code: string           // "210.6040"
  name: string           // "农药学"
  parentCode: string     // "210.60" (二级)
  parentName: string     // "植物保护学"
  description?: string
}

// Document.metadata.grounding (v2)
interface DocumentGrounding {
  disciplineCodes: string[]     // ["210.6040", "210.6020"]
  expertIds: ExpertId[]         // ["pest_risk"]
  classification: {
    source: "gbt13745" | "hanjiang_pattern" | "app_label" | "manual" | "keyword_fallback"
    confidence: number          // 0-1
    resolverChain: string[]     // ["gbt13745_parser", "hanjiang_pattern_matcher"]
    classifiedAt: string        // ISO timestamp
  }
  priority: "high" | "normal" | "low"
  manualOverride: boolean
}

// 前端展示模型 (API 返回，含推导字段)
interface DocumentWithGroundingView {
  // ... 基础字段
  grounding?: DocumentGrounding
  derivedDomains: ExpertDomain[]    // 从 expertIds 推导
  derivedDisciplineNames: string[]  // "农药学", "植物病理学" 等中文名
  classificationStatus: "auto" | "pending" | "manual"
}
```

### 2.4 上传自动分类流程

```
POST /api/knowledge/upload (file)
        │
        ├── ① 保存文件 + 创建 Document (PENDING_INDEX)
        │
        ▼
   DisciplineResolver.resolve(fileName, content)
        │
        ├── 子裁决器 A: 提取 GB/T 13745 代码 (置信度 scoreA)
        ├── 子裁决器 B: 邗江文件名模式匹配 (置信度 scoreB)
        ├── 子裁决器 C: 栏目标签匹配 (置信度 scoreC)
        │
        ▼
   best = max(scoreA, scoreB, scoreC)
        │
        ├── best >= 0.7 → AUTO_CLASSIFIED
        │     → 写入 Document.metadata.grounding
        │     → classificationStatus = "auto"
        │
        └── best < 0.7 → PENDING_CLASSIFY
              → grounding 为 null
              → classificationStatus = "pending"
              → 前端列表高亮标记，提示用户人工标注
```

### 2.5 kb-sync 路由链（重写后）

```
文档的 metadata.grounding
  │
  ├── disciplineCodes.length > 0
  │     ├── disciplineCode → 查映射表 → expertId[]
  │     │     映射表: { "210.6040": ["pest_risk"], "210.6020": ["pest_risk"], ... }
  │     │     可由管理员在页面上维护
  │     │
  │     ├── expertId → ANALYSIS_EXPERTS[expertId].grounding.collectionName
  │     │     → "expert_pest_risk"
  │     │
  │     └── 幂等写入: 先查 collection 是否已有该 docId，有则 skip
  │
  └── disciplineCodes 为空 → 旧关键词 fallback (兼容存量)
```

### 2.6 前端页面结构

```
customization/index.vue
├── 顶部统计栏
│   ├── auto / pending / manual 分类比例
│   └── per-discipline + per-expert 覆盖率
│
├── 上传区
│   ├── 文件上传 (FormData + file)
│   └── 上传后自动运行分类 → 展示结果
│       ├── 成功 → 绿色标记，显示 disciplineCodes + 中文名
│       └── 失败 → 橙色 PENDING，引导人工标注
│
├── 文档列表
│   ├── 筛选: 分类状态 / disciplineCode / expertId / domain(业务域徽章)
│   ├── 每行: 文档名 + 分类状态标签 + 中文学科名 + 专家名 + 业务域徽章
│   └── 行操作: 编辑 disciplineCodes + expertIds (抽屉，多选下拉)
│
├── 批量操作栏
│   └── 选中多篇 → 指派/替换/移除 disciplineCode 或 expertId
│
├── 映射管理 (disciplineCode ↔ expertId 映射表)
│   └── 管理员可以配置: 210.6040 农药学 → pest_risk
│
└── 同步按钮
    └── 触发 POST /api/knowledge/sync → SSE 进度 + 自动联动 Expert Collection
```

---

## 三、实施步骤

```
Task 0: GB/T 13745 数据准备    ──┐
Task 1: Discipline Resolver      ──┤ 可并行
Task 2: 语义分块 (SmartChunker)   ──┤
                                    │
                                    ▼
Task 3: 重写 kb-sync              ── 依赖 Task 0/1（路由链 + 断点续传）
                                    │
                                    ▼
Task 4: upload API + auto-classify ── 依赖 Task 1/2
                                    │
                                    ▼
Task 5: grounding CRUD API        ── 依赖 Task 0
                                    │
                                    ▼
Task 6: knowledge-sync 自动联动   ── 依赖 Task 3
                                    │
                                    ▼
Task 7: 语义缓存 per-collection   ── 依赖 Task 3
                                    │
                                    ▼
Task 8: agrisynapse 前端页面      ── 依赖 Task 4/5/6
                                    │
                                    ▼
Task 9: 编译验证 + E2E
```

### Task 0: GB/T 13745 农业科学全量数据

- 从 GB/T 13745-2009 提取 210 农业科学下所有二、三级学科
- 写入 `src/data/gbt13745-agriculture.json`
- 结构: `[{ code, name, parentCode, parentName }]`
- 预置 8 个二级学科 + 60+ 个三级学科

### Task 1: Discipline Resolver 独立裁决层

- `src/services/discipline-resolver.ts`
- 链式调用三个子裁决器，返回最优结果 + 置信度
- 子裁决器 A: GB/T 13745 代码提取（正则匹配文档内容中的 `210.xxxx` 模式）
- 子裁决器 B: 邗江文件名模式匹配（作物×阶段×技术 三维标签 → disciplineCode 映射表）
- 子裁决器 C: 栏目标签匹配（预设标签 → disciplineCode 映射）
- 置信度阈值: 0.7 (可配置)

### Task 2: 语义分块 (SmartChunker) — 可独立排期，不阻塞主线

> **注意**：司农 hybrid-rag/chunker.py 是 Python 实现（439 行，含 embedding + LLM arbiter），
> 移植到 TypeScript 需适配 embedding API 差异 + LLM 调用接口，预估 2-3 天。
> **Task 2 不阻塞 Task 3-6 的主线**，可在数据链路打通后独立排期上线。

借用司农 hybrid-rag 的 SmartChunker，替换当前 `RecursiveCharacterTextSplitter` 固定长度切分：

- `src/services/smart-chunker.ts`
- embedding 相似度 + 动态百分位阈值（15%）→ 自动检测章节断点
- LLM 仲裁器：相似度在阈值 ± margin 模糊区时，LLM 判断合并/切分（默认倾向 MERGE）
- 安全切分三级回退：按段落 → 按句子 → 按字符硬切 + overlap
- 不引入标题粘合（短文本≠标题，高熵值信息会被误合并）

### Task 3: 重写 kb-sync-expert-collections.ts

- 路由链: `disciplineCode → 映射表 → expertId → registry → collectionName`
- 映射表存储：`data/discipline-to-expert-mapping.json`（JSON 配置文件，管理员可 CRUD）
- 保留关键词 fallback 兼容存量文档
- 幂等写入: 同步前查询 collection 是否已有该 docId
- 断点续传入库：记录已同步 docId

#### 存量文档 cateId → disciplineCode 迁移策略

存量文档的 `metadata` 中可能存有旧的 `cateId` 字段（如 `"plant_protection"`），
新的 disciplineCode 体系上线后，分三步平滑迁移：

```
阶段1 (共存): kb-sync 同时读取 cateId 和 disciplineCodes
              disciplineCodes 优先，cateId 作为 fallback
阶段2 (迁移): 跑一次性脚本 cateId → disciplineCode 批量转换
              存量文档自动写入 disciplineCodes
阶段3 (清理): 删除 kb-sync 中 cateId 解析逻辑
              只读 disciplineCodes
```

### Task 4: upload API 自动分类

- `POST /api/knowledge/upload` 完成后自动调用 DisciplineResolver
- 分类成功 → 写入 metadata.grounding + status AUTO_CLASSIFIED
- 分类失败 → status PENDING_CLASSIFY，前端高亮提示

### Task 5: grounding CRUD API

- `PUT /api/knowledge/documents/:id/grounding` — 单文档编辑 disciplineCodes + expertIds
- `POST /api/knowledge/grounding/batch` — 批量指派
- `GET /api/knowledge/grounding/stats` — per-discipline + per-expert 统计
- `GET /api/knowledge/grounding/disciplines` — 返回全量 GB/T 13745 学科列表（供前端下拉）
- `PUT /api/knowledge/grounding/mapping` — 管理 disciplineCode ↔ expertId 映射表

### Task 6: knowledge-sync 自动联动（替换现有双写）

> **现状**：`knowledge-indexer.ts` L194-230 已实现基于 `expertCateIds` + `CATEID_TO_EXPERT_COLLECTION` 的双写。
> **策略**：不是新增并行路径，而是把现有 `CATEID_TO_EXPERT_COLLECTION` 映射表替换为 `disciplineCode → expertId → collectionName` 三级链。

- `indexKnowledgeDocumentWithProgress` 的 `expertCateIds` 参数改为 `disciplineCodes`
- 内部映射链: `disciplineCodes → resolveExpertIds(disciplineCodes) → registry.grounding.collectionName`
- 幂等: 先查后写，不产生重复向量
- 审计日志: EXPERT_SYNC_AUTO phase
- 旧 `CATEID_TO_EXPERT_COLLECTION` 保留为 fallback，兼容未迁移的调用方

### Task 7: 语义缓存 per-collection generation map

- `src/services/semantic-cache.ts` 改进
- 当前：全局 `kbGeneration++` → 一刀切淘汰所有缓存
- 改进：per-collection version map → 只淘汰受影响的 expert collection 缓存
- bumpKbGeneration → bumpCollectionGeneration(collectionName: string)
- CacheEntry 记录 `affectedCollections: string[]`
- get() 时比对 entry.affectedCollections 中每个 collection 的 generation

### Task 8: agrisynapse customization/index.vue

> **分两期交付（降低单次变更风险）**

**一期（MVP）**: 文档列表 + 人工标注
- 上传组件 + 自动分类结果展示（成功/待分类标记）
- 文档列表（筛选: disciplineCode / expertId / 分类状态）
- disciplineCode/expertId 编辑抽屉

**二期**: 映射管理 + 批量操作
- disciplineCode ↔ expertId 映射管理面板
- 批量指派
- 同步按钮 + SSE 进度

### Task 9: 编译验证 + E2E

- farm-agent tsc 零错误
- agrisynapse vue-tsc 仅预存错误
- Runtime: 上传邗江文档 → 自动分类 → 同步 → ChromaDB expert collection 新增 → 对话 grounding 命中

---

## 四、验收标准

- [ ] 前置门禁 G1/G2 通过后才启动下游 Task
- [ ] GB/T 13745 农业科学全量数据正确导入 `data/gbt13745-agriculture.json`（数据来源：GB/T 13745-2009 标准全文人工录入，校验：三级学科数与标准一致 ≥ 60 条）
- [ ] Discipline Resolver 纯规则版先上线；LLM 灰色区域仲裁（0.5-0.7 区间）为 Phase 2，先收集实际置信度分布数据再决定是否引入
- [ ] SmartChunker 语义分块替换固定长度切分，安全切分三级回退正常（独立排期，不阻塞主线）
- [ ] 上传邗江农技文档自动识别为 `["210.6020", "210.6040"]`，自动分类准确率 ≥ 80%
- [ ] 分类失败的文档标记为 PENDING_CLASSIFY，前端正确高亮
- [ ] 存量文档 cateId → disciplineCode 三阶段迁移（共存→批量转换→清理）
- [ ] kb-sync 按 disciplineCode → expertId → collectionName 链正确路由，断点续传入库
- [ ] 现有 knowledge-indexer.ts 双写替换为 disciplineCode 链，旧 CATEID_TO_EXPERT_COLLECTION 保留为 fallback
- [ ] Expert Collection 写入幂等，同步延迟 < 5s/文档
- [ ] 语义缓存 per-collection generation：仅淘汰受影响 collection 的缓存
- [ ] 定制页面一期（文档列表+人工标注）可用

---

## 五、关联文档

| 文档 | 路径 |
|------|------|
| 本 Plan | `.qoder/plans/farm-agent-grounding-customization-plan-v2.md` |
| ADD Route | `.qoder/plans/farm-agent-grounding-customization-add-route-v1.md` |
| Handoff | `.qoder/plans/farm-agent-grounding-customization-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-grounding-customization-review-v2.md` |
| Spec | `.qoder/specs/grounding-customization/spec.md` |
| Tasks | `.qoder/specs/grounding-customization/tasks.md` |
| Checklist | `.qoder/specs/grounding-customization/checklist.md` |
| GB/T 13745 数据 | `src/data/gbt13745-agriculture.json` |
| Discipline Resolver | `src/services/discipline-resolver.ts` |
| SmartChunker | `src/services/smart-chunker.ts` |
| 语义缓存 (改进) | `src/services/semantic-cache.ts` |
| Sync 脚本 (重写) | `scripts/kb-sync-expert-collections.ts` |
| 前端页面 | agrisynapse `src/views/llm/customization/index.vue` |
| 借鉴源 | 司农 hybrid-rag (南农+南理工) |
