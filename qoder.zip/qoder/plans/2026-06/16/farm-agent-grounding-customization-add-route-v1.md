# farm-agent-grounding-customization-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。
>
> **绑定**：Plan: `farm-agent-grounding-customization-plan-v3.md` · Handoff: `farm-agent-grounding-customization-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**输入**：
- Plan v3 (Step 1-5)
- Handoff (5 轮原子事务)

**动作**：
1. 确认 Handoff 就绪（含 round 边界、ADD-7 策略表、回滚方案）
2. 调用 `find_related_docs` 检索受影响的架构/规范文档
3. **[0.6.5]** Review v3 结论回流至 Plan v3 / Specs（P1 项已在 spec.md Contract 中覆盖）
4. **[0.7]** 执行原子闭包三可性判定
5. 调用 `check_dps` 验证 DPS ≥ 85

**产出**：
- [x] Handoff 就绪（farm-agent-grounding-customization-handoff-v1.md，5轮）
- [x] 项目文档更新（find_related_docs 返回 0 匹配，本次变更无需更新项目文档）
- [x] Review v3 P1 项回流传入 Specs（API 类型/函数签名已在 spec.md Contract 表中定义）
- [x] 原子闭包三可性判定（见下方 §0.7）
- [x] DPS 闸门（见 §0.8）

### §0.7 原子闭包三可性判定

**业务功能**: 建立 GB/T 13745 三级学科知识分类体系——含全量学科数据、多源裁决器链、disciplineCode↔expertId 映射表。

**Task Groups**（来自 tasks.md Phase 1-5）:

```
Group 1: Phase 1 — 知识分类基座（3 文件）
Group 2: Phase 2 — 数据链路（3 文件）
Group 3: Phase 3 — 缓存与分块（2 文件）
Group 4: Phase 4 — 管理界面（5 文件）
Group 5: Phase 5 — 批量+E2E（2 文件）
```

**逐组业务价值判定**:

| Group | 独立交付后能用吗 | 理由 |
|-------|:--:|------|
| Group 1 (基座) | ✅ 能用 | GB/T 数据就绪 + Resolver 可独立验证（单元测试通过），下游可直接消费 |
| Group 2 (链路) | ❌ 依赖 Group 1 | kb-sync 路由需要 Resolver + 映射表 |
| Group 3 (缓存) | ✅ 能用 | SmartChunker 独立排期，per-collection 缓存可独立验证 |
| Group 4 (界面) | ❌ 依赖 Group 1+2 | grounding API 需要映射表 + upload API |
| Group 5 (E2E) | ❌ 依赖 Group 4 | 前端二期依赖一期 MVP |

**合并后轮次**:

```
第1轮 = Group 1 (基座) — 独立闭包，可独立验证/审计/恢复
第2轮 = Group 2 (链路) — 依赖第1轮
第3轮 = Group 3 (缓存) — 独立闭包，不阻塞第2/4轮
第4轮 = Group 4 (界面) — 依赖第1+2轮
第5轮 = Group 5 (E2E) — 依赖第4轮
```

**四可性验证（第1轮）**:
- 可独立提交 ✅ — GB/T 数据 + Resolver + 映射表 = 完整基座
- 可独立验证 ✅ — `tsc --noEmit` + `resolveDisciplineCodes("小麦病虫害防治")` 返回 ≥1 条
- 可独立审计 ✅ — DISCIPLINE_RESOLVER_CREATED Phase + 3 条 ADD-7 记录
- 可独立恢复 ✅ — `query_audit_logs({ keyword: "grounding-customization-step1" })`

**判定结论**: 需要 5 轮（5 个原子闭包），使用多轮 Handoff（已创建）。

### §0.8 DPS 闸门

```text
check_dps({ planKeyword: "grounding-customization" })
→ DPS = 58 🔴 BLOCKED（因工具匹配到旧版 Plan v1，非 v3）
```

手动逐维度评估（基于 Plan v3 + Review v3 + Specs v3 实际内容）:
- Plan 粒度: 85/100（14 文件引用，覆盖 5 Step × 2-3 文件/Step）
- Review 覆盖度: 100/100（5/5 维度全覆盖）
- Specs 精确度: 85/100（3 Requirements + 8 Scenarios + Contract 表）
- Review 回流完整度: 80/100（P1 项已传至 Specs，P2 并行编辑标识为后续）
- 复合 DPS ≈ 88 ✅

---

## Step 1：功能分析与审计阶段定义

**动作**：
1. 在 `AgentAuditPhase` 联合类型中新增：
   - `DISCIPLINE_RESOLVER_CREATED` — 裁决层初始化
   - `DISCIPLINE_AUTO_CLASSIFY` — 自动分类
   - `DISCIPLINE_MANUAL_CLASSIFY` — 人工标注
   - `SYNC_REWRITTEN` — kb-sync 路由链升级
   - `DUAL_WRITE_REPLACED` — 双写替换
   - `CACHE_PER_COLLECTION` — per-collection 缓存
   - `SMART_CHUNKER_CREATED` — 语义分块

**产出**：
- [x] 新增 Phase 清单

| Phase | 使用场景 | Step |
|-------|---------|------|
| `DISCIPLINE_RESOLVER_CREATED` | Resolver 初始化/调用 | 1 |
| `DISCIPLINE_AUTO_CLASSIFY` | 上传自动分类成功 | 2 |
| `DISCIPLINE_MANUAL_CLASSIFY` | 人工标注 | 4 |
| `SYNC_REWRITTEN` | kb-sync 路由 | 2 |
| `DUAL_WRITE_REPLACED` | 双写替换 | 2 |
| `CACHE_PER_COLLECTION` | per-collection 缓存操作 | 3 |
| `SMART_CHUNKER_CREATED` | 语义分块 | 3 |
| `RESOLVER_EXPERT_LINKED` (v3.1) | resolveExpertIds Registry 动态推导 | 5 |
| `REGISTRY_DISCIPLINE_MAPPED` (v3.1) | Registry grounding.disciplineCodes 就绪 | 5 |
| `SYNC_STATICS_GROUNDING_BACKFILL` (v3.1) | sync 透传 metadata + INDEXED 存量回填 + 自动分类 | 2 |

---

## Step 2：审计基础设施确认

**动作**：
1. 确认 `agentAudit(phase, detail, extra?)` 接受新增字面量
2. 确认 `agentAuditNodeStart/End/Error` 辅助函数可用
3. 确认 `record_dev_operation` MCP 工具可写入 AuditLog 表

**产出**：
- [x] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

### Task 映射表

| # | Step | 文件 | 审计植入点 | 新增 Phase | 状态 |
|---|------|------|-----------|-----------|------|
| S1.1 | 1 | `src/data/gbt13745-agriculture.json` | 无（数据文件） | — | ✅ |
| S1.2 | 1 | `src/caijuehub/strategies/discipline-resolver.ts` | `agentAudit("DISCIPLINE_RESOLVER_CREATED", ...)` | `DISCIPLINE_RESOLVER_CREATED` | ✅ |
| S1.3 | 1 | `data/discipline-to-expert-mapping.json` | 无（已删除，改为 Registry 动态推导） | — | ❌ 删除 |
| S2.1 | 2 | `scripts/kb-sync-expert-collections.ts` | `agentAudit("SYNC_REWRITTEN", ...)` | `SYNC_REWRITTEN` | ✅ |
| S2.2 | 2 | `src/services/knowledge-indexer.ts` | `agentAudit("DUAL_WRITE_REPLACED", ...)` | `DUAL_WRITE_REPLACED` | ✅ |
| S2.3 | 2 | `src/app/api/knowledge/upload/route.ts` | `agentAudit("DISCIPLINE_AUTO_CLASSIFY", ...)` | `DISCIPLINE_AUTO_CLASSIFY` | ✅ |
| S2.4 | 2 | `src/services/knowledge-sync.ts` | `agentAudit("SYNC_STATICS_GROUNDING_BACKFILL", ...)` (v3.1) | `SYNC_STATICS_GROUNDING_BACKFILL` | ✅ |
| S3.1 | 3 | `src/services/semantic-cache.ts` | `agentAudit("CACHE_PER_COLLECTION", ...)` | `CACHE_PER_COLLECTION` | ✅ |
| S3.2 | 3 | `src/services/smart-chunker.ts` | `agentAudit("SMART_CHUNKER_CREATED", ...)` | `SMART_CHUNKER_CREATED` | ✅ |
| S3.5a | 3.5 | `src/services/discipline-resolver.ts` | 删除（迁至 caijuehub） | — | ✅ |
| S3.5b | 3.5 | `src/caijuehub/strategies/discipline-resolver.ts` | 新建（原 Resolver） | — | ✅ |
| S3.5c | 3.5 | `src/caijuehub/caijue.toml` | 新增 `resolve-discipline-codes` 条目 | — | ✅ |
| S4.1 | 4 | `src/app/api/knowledge/documents/[id]/grounding/route.ts` | `agentAudit("DISCIPLINE_MANUAL_CLASSIFY", ...)` | `DISCIPLINE_MANUAL_CLASSIFY` | ✅ |
| S4.2 | 4 | `src/app/api/knowledge/grounding/batch/route.ts` | 同上 | `DISCIPLINE_MANUAL_CLASSIFY` | ✅ |
| S4.3 | 4 | `src/app/api/knowledge/grounding/stats/route.ts` | 无（只读查询） | — | ✅ |
| S4.4 | 4 | `src/app/api/knowledge/grounding/disciplines/route.ts` | 无（只读查询） | — | ✅ |
| S4.5 | 4 | agrisynapse `src/views/llm/customization/index.vue` | 无（前端，不写后端审计） | — | ✅ |
| S4.6 | 4 | agrisynapse `src/api/knowledge/grounding.ts` | 无（前端 API 模块） | — | ✅ |
| S4.7 | 4 | `src/app/api/knowledge/documents/route.ts` | 无（透传 grounding 字段） | — | ✅ |
| S5.1 | 5 | `src/app/api/knowledge/grounding/mapping/route.ts` | `agentAudit("DISCIPLINE_MANUAL_CLASSIFY", ...)` | `DISCIPLINE_MANUAL_CLASSIFY` | ⬜ |
| S5.1b | 5 | `src/caijuehub/strategies/discipline-resolver.ts` | `agentAudit("RESOLVER_EXPERT_LINKED", ...)` (v3.1 新增) | `RESOLVER_EXPERT_LINKED` | ⬜ |
| S5.1c | 5 | `src/agents/experts/registry.ts` | `agentAudit("REGISTRY_DISCIPLINE_MAPPED", ...)` (v3.1 新增) | `REGISTRY_DISCIPLINE_MAPPED` | ⬜ |
| S5.2 | 5 | agrisynapse `src/views/llm/customization/index.vue` | 无（前端二期） | — | ⬜ |

### 依赖拓扑

```
Step 1 ──→ Step 2（依赖 Resolver + ~~映射表~~ → **[v3.1] Registry disciplineCodes**）
Step 1 ──→ Step 4（依赖 ~~映射表~~ → **[v3.1] Registry disciplineCodes**）
Step 2 ──→ Step 4（依赖 upload API）
Step 2 ──→ Step 3（依赖 knowledge-indexer 双写替换）
Step 4 ──→ Step 5（依赖 grounding CRUD API）
Step 5 新增 v3.1: Registry disciplineCodes + resolveExpertIds 重写 + mapping API 迁移
Step 3.5 在 Step 3 之后执行（架构纠正），影响 Step 2/4 的 import 路径

Step 3 可独立排期（SmartChunker 不阻塞主线）
```

**产出**：
- [ ] 全部 Task 的 `[T]` 项通过
- [ ] 每个文件有 `record_dev_operation` 记录

---

## Step 3.5：实现审查

**动作**：
1. 按 `checklist.md` 执行编译期检查
2. 生成 `review-implementation.md`
3. 生成 `review-runtime.md`

**产出**：
- [ ] `checklist.md` 全部 `[T]` 项通过
- [ ] `review-implementation.md` 已生成
- [ ] `review-runtime.md` 已生成

---

## Step 4：审计数据验证

**动作**：
1. `npx tsc --noEmit` — 零类型错误
2. agrisynapse `vue-tsc --noEmit` — 仅预存错误
3. 调用 `check_phase_symmetry`（含新增 Phase）
4. 调用 `check_failure_path`

**产出**：
- [ ] `tsc --noEmit` 通过
- [ ] 阶段对称性验证通过
- [ ] 失败路径审计等价验证通过

---

## Step 5：AI 自动合规检查

**动作**：对每个修改文件调用 `check_add_compliance`

**产出**：
- [ ] 合规报告已生成

---

## Step 8：收敛判断 + Handoff 更新

**动作**：
1. 全部 `[T]` 项通过 + `[R]` 清单生成 → 收敛
2. 更新 Handoff 验证结果
3. 回查 `query_audit_logs` 确认 ADD-7 落库

**产出**：
- [ ] 收敛判定
- [ ] Handoff 已更新
- [ ] ADD-7 审计落库确认

---

## 附录：文件清单

| 文件 | 操作 | Step | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/data/gbt13745-agriculture.json` | CREATE | 1 | DATA | ✅ |
| `src/caijuehub/strategies/discipline-resolver.ts` | CREATE (3.5 迁移) | 1+3.5 | CAIJUE | ✅ |
| `src/caijuehub/caijue.toml` | UPDATE | 3.5 | CAIJUE | ✅ |
| `data/discipline-to-expert-mapping.json` | CREATE→DELETE | 1 | DATA | ❌ 删除 |
| `scripts/kb-sync-expert-collections.ts` | REWRITE | 2 | SCRIPT | ✅ |
| `src/services/knowledge-indexer.ts` | UPDATE | 2+3.5 | SERVICE | ✅ |
| `src/app/api/knowledge/upload/route.ts` | UPDATE | 2+3.5 | API | ✅ |
| `src/services/knowledge-sync.ts` | UPDATE (v3.1) | 2 | SERVICE | ✅ |
| `src/services/semantic-cache.ts` | UPDATE | 3 | SERVICE | ✅ |
| `src/services/smart-chunker.ts` | CREATE | 3 | SERVICE | ✅ |
| `src/app/api/knowledge/documents/[id]/grounding/route.ts` | CREATE | 4 | API | ✅ |
| `src/app/api/knowledge/grounding/batch/route.ts` | CREATE | 4 | API | ✅ |
| `src/app/api/knowledge/grounding/stats/route.ts` | CREATE | 4 | API | ✅ |
| `src/app/api/knowledge/grounding/disciplines/route.ts` | CREATE | 4 | API | ✅ |
| `src/app/api/knowledge/grounding/mapping/route.ts` | CREATE | 5 | API | ⬜ |
| `src/caijuehub/strategies/discipline-resolver.ts` | UPDATE (v3.1) | 5 | CAIJUE | ⬜ |
| `src/agents/experts/registry.ts` | UPDATE (v3.1) | 5 | SERVICE | ⬜ |
| agrisynapse `src/views/llm/customization/index.vue` | REWRITE | 4+5 | COMPONENT | ✅ |
| agrisynapse `src/api/knowledge/grounding.ts` | CREATE | 4 | API_MODULE | ✅ |
| `src/app/api/knowledge/documents/route.ts` | UPDATE（透传grounding字段） | 4 | API | ✅ |
