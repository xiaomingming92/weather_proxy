# farm-agent-seed-catalog-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **绑定**：Plan: `.qoder/plans/farm-agent-seed-catalog-plan-v1.md` · Spec: `.qoder/specs/farm-agent-seed-catalog/spec.md` · Tasks: `.qoder/specs/farm-agent-seed-catalog/tasks.md` · Handoff: `.qoder/plans/farm-agent-seed-catalog-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全，项目文档反映即将实现的变更。

**输入**：
- 用户需求（上游驱动）
- Plan 文档（已生成）

**动作**：
1. 确认 Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md` ✅
2. 调用 `find_related_docs` 检索受影响的架构/规范/需求文档 → 结果：无已有文档需要修改（种子目录为全新功能模块）
3. 声明"本次变更无需更新项目文档"——理由：种子目录是新增的独立数据模块，不影响现有架构文档描述的管线逻辑（决策管线 / RAG 检索 / 裁决层）
4. 确认 Handoff 就绪（含 round 边界、ADD-7 策略表、回滚方案）

**产出**：
- [ ] Specs 三元组路径确认 ✅ `.qoder/specs/farm-agent-seed-catalog/`
- [ ] 项目文档更新（已声明无需更新）
- [ ] Handoff 就绪

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的所有审计阶段，扩展 `AgentAuditPhase`。

**输入**：
- Plan §4 的 Task 列表
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase` 联合类型

**动作**：
1. 列出本次变更涉及的所有业务阶段：种子目录 CRUD（纯数据操作，无复杂管线审计）
2. 本次无需新增 AgentAuditPhase 字面量——种子目录 API 和工具是纯 Prisma 查询，不涉及 Agent OS、推理节点、裁决层等运行时管线

**产出**：
- [ ] 本次无需新增 AgentAuditPhase（纯数据层变更，无管线审计）

| Phase | 使用场景 | Task |
|-------|---------|------|
| — | 无新增 | — |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用，无需新建 logger 文件。

**输入**：
- `src/lib/agent-audit-logger.ts`

**动作**：
1. 确认 `agentAudit(phase, detail, extra?)` 可用
2. 确认三通道输出正常（console + file + AuditLog 表）

**产出**：
- [ ] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan 的 Task 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

**输入**：
- Plan §4 实施步骤
- `tasks.md` 的 Task 清单

**动作**：

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1.1 | Prisma 模型 | `prisma/schema.prisma` | 无（DDL 变更） | — | 无 | ⬜ |
| 2.1 | API CRUD | `src/app/api/seed-catalog/route.ts` | 无（纯 REST CRUD） | — | Task 1.1 | ⬜ |
| 2.2 | Agent 工具 | `src/tools/query-seed-catalog.ts` | 无（纯查询工具） | — | Task 1.1 | ⬜ |
| 3.1 | Expert 注册 | `src/agents/experts/registry.ts` | 无（配置变更） | — | Task 2.2 | ⬜ |
| 3.1 | 工具注册 | `src/tools/registry.ts` | 无（配置变更） | — | Task 2.2 | ⬜ |
| 4.1 | 前端 API 封装 | `agrisynapse/src/api/seed/index.ts` | 无（前端文件） | — | Task 2.1 | ⬜ |
| 4.2 | 前端页面 | `agrisynapse/src/views/seed/index.vue` | 无（前端文件） | — | Task 4.1 | ⬜ |
| 4.3 | 前端路由 | `agrisynapse/src/router/` | 无（前端文件） | — | Task 4.2 | ⬜ |

### 依赖拓扑

```
Task 1.1 ──────┬────────────────┐
               ▼                ▼
Task 2.1 (API)            Task 2.2 (工具)
               │                │
               │                ▼
               │         Task 3.1 (注册)
               │
               ▼
Task 4.1 (前端 API) ──→ Task 4.2 (页面) ──→ Task 4.3 (路由)
```

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计

**产出**：
- [ ] 全部 Task 的 `[T]` 项通过
- [ ] 每个文件有 `record_dev_operation` 记录

---

## Step 3.5：实现审查

**目的**：代码完成后，验证意图与实现无语义鸿沟（ADD-10）。

**输入**：
- `checklist.md`
- `review-implementation-template.md`

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 按 `checklist-template.md` 执行跨项目联调检查（前端 API 格式契约）
3. 读取 `review-implementation-template.md`，生成 `review-implementation.md`
4. 所有 `[T]` 项通过后，生成 `review-runtime.md`

**产出**：
- [ ] `checklist.md` 全部 `[T]` 项已通过
- [ ] `review-implementation.md` 已生成
- [ ] `review-runtime.md` 已生成

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. `npm run lint` —— 无新增 lint 问题
3. 纯数据层变更，无需调用 `check_phase_symmetry`/`check_failure_path`

**产出**：
- [ ] `tsc --noEmit` 通过
- [ ] `npm run lint` 通过

---

## Step 5：AI 自动合规检查

**目的**：扫描全部修改文件的 ADD-1~ADD-7 合规性。

**动作**：
1. 对每个修改文件调用 `check_add_compliance(code, projectPattern="event-based")`
2. 汇总合规报告

**产出**：
- [ ] 合规报告已生成

---

## Step 6-7：问题定位与修复

> 仅当 Step 4/5 发现异常时进入。

---

## Step 8：收敛判断 + Handoff 更新

**目的**：功能收敛判定，更新 Handoff。

**动作**：
1. 全部 `[T]` 项通过 → 功能收敛
2. Handoff 更新：§7（实际产出）、§8（验证结果）、§9（后置确认）
3. ADD-7 回查：`query_audit_logs` 确认全部 `record_dev_operation` 记录已落库

**产出**：
- [ ] 收敛判定结果
- [ ] Handoff 已更新
- [ ] ADD-7 审计记录已落库确认

---

## 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: 为 crop_compare 专家提供结构化种子商品数据查询能力，并配套管理后台 CRUD

Task Groups:
  Group 1（数据模型）: Task 1.1 — Prisma 建表
  Group 2（后端 API）: Task 2.1 + Task 2.2 — CRUD API + Agent 工具
  Group 3（Agent 注册）: Task 3.1 — registry 更新
  Group 4（前端）: Task 4.1 + 4.2 + 4.3 — 管理页面

逐组业务价值判定:
  Group 1（建表）: 不能用 — 表建好了但没有 API，用户无法使用
  Group 2（后端）: 部分能用 — API 可用但 Agent 管线没接上，crop_compare 专家无法调用
  Group 3（注册）: 不能用 — 纯配置变更，依赖 Group 2
  Group 4（前端）: 部分能用 — 管理页面可用但 Agent 工具未连接

合并判定:
  Group 1+2+3 合并 → crop_compare 专家可查询种子数据（Agent 侧价值） ✅
  Group 4 → 管理员可维护种子数据（管理侧价值） ✅

判定结论: 需要 2 轮（2 个原子闭包）

第1轮（原子闭包1）: Task 1.1 + 2.1 + 2.2 + 3.1
  业务功能: crop_compare 专家可通过 query_seed_catalog 工具查询 PostgreSQL 中的结构化种子数据
  可独立提交✅ 可独立验证✅（tsc + curl API + 工具查询） 可独立审计✅ 可独立恢复✅

第2轮（原子闭包2）: Task 4.1 + 4.2 + 4.3
  业务功能: 管理员可在 agrisynapse 中通过 CRUD 页面管理种子品种和价格数据
  可独立提交✅ 可独立验证✅（前端构建 + 页面访问） 可独立审计✅ 可独立恢复✅
```

> **判定结论**：分为 2 轮执行。第1轮交付 Agent 侧价值（专家可查询种子数据），第2轮交付管理侧价值（管理后台 CRUD）。

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `prisma/schema.prisma` | MODIFY | 1.1 | MODEL | ⬜ |
| `src/app/api/seed-catalog/route.ts` | CREATE | 2.1 | COMPONENT | ⬜ |
| `src/tools/query-seed-catalog.ts` | CREATE | 2.2 | COMPONENT | ⬜ |
| `src/tools/registry.ts` | MODIFY | 3.1 | COMPONENT | ⬜ |
| `src/agents/experts/registry.ts` | MODIFY | 3.1 | COMPONENT | ⬜ |
| `agrisynapse/src/api/seed/index.ts` | CREATE | 4.1 | COMPONENT | ⬜ |
| `agrisynapse/src/views/seed/index.vue` | CREATE | 4.2 | COMPONENT | ⬜ |
| `agrisynapse/src/router/` | MODIFY | 4.3 | COMPONENT | ⬜ |
