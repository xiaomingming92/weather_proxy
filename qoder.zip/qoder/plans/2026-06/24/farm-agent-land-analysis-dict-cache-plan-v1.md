# farm-agent-land-analysis-dict-cache-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。不要写完整 TS 类型定义和 WHEN-THEN 场景——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-land-analysis-dict-cache-v1
- **启动时间**: 2026-06-24T12:00:00+08:00
- **修订时间**: 2026-06-24（Review v1 回流：P0-1/P1-1/P1-2 写入 Plan）
- **修订时间**: 2026-06-25（增量：Farm-Server 地块 API 字段 & 字典类型全量同步完成；新增 Task 7—`farm-data-tools.ts` Agent 工具接入 DictCache 字段翻译）
- **主导 AI**: Qoder
- **前置 Plan**: `.qoder/plans/2026-06/23/farm-agent-ruifengyun-h5-api-plan-v2.md`（H5 认证+路径重构+端点创建，dict-cache 实施前需 rebase 到该 Plan runtime 修复后的 route.ts 基线）
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/24/farm-agent-land-analysis-dict-cache-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-06/24/farm-agent-land-analysis-dict-cache-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-land-analysis-dict-cache-review-v1.md`
  - Specs: `.qoder/specs/farm-agent-land-analysis-dict-cache/`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/app/api/h5/production-plan/land-analysis/route.ts` | COMPONENT | COMPONENT_MODIFIED | fertility 硬编码 `{0:'低',1:'中',2:'高'}`，soilTypeSummary 未计算，fertilityLevel 处理不兼容 null/中文文本 | 从字典缓存层读取映射，确定性计算 fertilitySummary + soilTypeSummary（面积加权），兼容 number/string/null | 待实施 |
| `src/lib/farm-api/dict-cache.ts` (新建) | COMPONENT | COMPONENT_CREATED | 不存在，枚举映射散落在各 route.ts 中硬编码 | in-memory Map<dictType, Map<value, label>>，启动时全量预加载，支持按 dictType 查询 label | 待实施 |
| `src/lib/farm-api/massif.ts` | COMPONENT | COMPONENT_MODIFIED | MassifDTO.fertilityLevel 类型为 `number?`，与 OpenAPI int32 一致但与部分环境实际返回的中文文本不一致 | fertilityLevel 类型改为 `number \| string \| null`，兼容两边 | ✅ 已实施（2026-06-24） |
| `src/lib/farm-api/massif.ts` | COMPONENT | COMPONENT_MODIFIED | MassifDTO 缺 qrCodeUrl/remark 字段 | 补全 `qrCodeUrl?: string`、`remark?: string` | ✅ 已实施（2026-06-25） |
| `src/agents/tools/impl/farm-data-tools.ts` | COMPONENT | COMPONENT_MODIFIED | MASSIF_COLUMNS 缺 status/qrCodeUrl/remark；queryMassifTool 不翻译枚举字段 | 补全 3 列 + Task 7 接入 DictCache 字段翻译 | ✅ 已实施（2026-06-25） |
| `src/app/api/h5/production-plan/land-analysis/route.ts` | COMPONENT | COMPONENT_MODIFIED | DictCache preload 仅 3 个 dictType | 补全 farm_massif_status/type → 5 个 | ✅ 已实施（2026-06-25） |
| `docs/大田精准耕播智能决策系统/knowledge/02-规范/dict-data-api.md` | DOC | DOC_UPDATED | 仅含 2 个 dictType | 第 2 章新增 3 个字典汇总 + 自动同步脚本就位 | ✅ 已实施（2026-06-25） |

---

## 一、背景与目标

### 1.1 问题现状

**P0 — route.ts soilInfo 数据错误**：
- `fertility` 返回 `"未知 100%"`：因 `fertilityLevel` 可能为 `null`（API 未填充该字段）或为中文文本（`"中"`），而代码按 `number` 硬编码映射 `{0:'低',1:'中',2:'高'}`，导致全部 fallback 到 `'未知'`
- `soilTypeSummary` 缺失：LLM prompt 输出字段名为 `soilType`（逗号分隔），与 Zod schema 的 `soilTypeSummary` 不匹配，且无百分比格式（消费者要求 `"粘壤土 60%  壤土 40%"` 两空格分隔格式）

**P1 — 枚举映射散落硬编码**：
- `moistureType`（土壤分类）的值→中文标签映射不存在于代码中，仅依赖 LLM prompt 中的自然语言指令推断
- `fertilityLevel` 映射硬编码在 route.ts 内，与 Farm-Server 实际返回值存在类型不一致（OpenAPI 定义 `int32`，但 .md 示例显示 `"中"`）
- 所有枚举映射无统一数据源，同一映射在不同 route 中可能不一致

**P1 — 本地 .md 文档与 OpenAPI 规范漂移**：
- `地块基本信息管理接口文档.v2.md` 中 `fertilityLevel` 示例值混淆（创建请求用 `"2"`，GET 响应示例用 `"中"`），而 OpenAPI 定义为 `integer, int32, 0=低/1=中/2=高`
- `landform` 枚举值在 OpenAPI 中明确定义（`0=平原/1=盆地/2=丘陵/3=山地/4=高原`），但 .md 文档中完全缺失
- `moistureType` 在 OpenAPI 和 .md 中均无枚举值说明
- 同类漂移也存在于土墒、气象、虫情等 .v2.md 文档中

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | 修复 route.ts 的 fertility 和 soilTypeSummary 输出 | fertility 返回 `"高 x% 中 x% 低 x%"` 格式；soilTypeSummary 返回 `"类型A x%  类型B x%"` 格式（两空格分隔） |
| P1 | 建立字典缓存层 | `DictCache` 模块通过 farmClient 代理调用 `/system/dict-data/type`，启动时预加载已知 dictType，提供 `getLabel(dictType, value): string` 接口 |
| P1 | route.ts 接入字典缓存 | fertilityLevel、moistureType 映射改为从 DictCache 读取，消除硬编码 |
| P2 | .md 文档与 OpenAPI 差异记录 | 在 `地块基本信息管理接口文档.v2.md` 中新增"枚举值映射"和"与 OpenAPI 差异记录"章节 |

---

## 二、方案选型

### 2.1 字典缓存层方案对比

| 方案 | 数据新鲜度 | 可用性（Farm-Server 挂掉时） | 复杂度 | 结论 |
|------|-----------|---------------------------|--------|------|
| A: 每次请求实时调 dict API | 最高 | 不可用，接口耦合 | 低 | ❌ 增加外部依赖和延迟 |
| B: 启动时全量加载 + in-memory Map，无刷新 | 低（需重启） | 高（自治） | 最低 | ❌ 枚举变更需重启 |
| C: 启动时全量加载 + 定时刷新（crontab 或 setInterval） | 高（可配置间隔） | 高（有兜底缓存） | 中 | ✅ 推荐 |
| D: Prisma 落库 + 定时同步 | 高 | 最高（本地 DB） | 高 | ❌ 过度工程化 |

### 2.2 选型理由

**选择方案 C**：in-memory Map + 定时刷新。理由：
- 字典数据（枚举映射）变更频率极低（以月/年计），无需实时同步
- Farm-Server 不可用时仍可正常工作（使用缓存值兜底）
- 不引入新的持久化依赖（无需 Prisma schema 变更）
- 刷新间隔可配置（默认 1 小时），启动时立即加载

### 2.3 OpenAPI 同步方案

OpenAPI → .md 同步属于独立的基础设施需求，与本次 route.ts 修复解耦。本次 Plan 仅做**差异记录**（在 .md 中标记已知偏差），同步机制的实现方案单独讨论。

---

## 三、架构设计

### 3.1 模块关系

```
                    ┌────────────────────┐
                    │  Farm-Server        │
                    │  /system/dict-data/ │
                    │  type?type=xxx      │
                    └────────┬───────────┘
                             │ HTTP (farmClient)
                             ▼
                    ┌────────────────────┐
                    │  DictCache          │  ← 新建 src/lib/farm-api/dict-cache.ts
                    │  - preloadAll()     │
                    │  - getLabel(type,v) │
                    │  - refreshLoop()    │
                    └────────┬───────────┘
                             │ import
                             ▼
┌───────────────┐    ┌────────────────────┐
│ land-analysis │◄───│  其他 H5 route.ts   │  ← 未来消费者
│   route.ts    │    │  (variety, etc.)   │
└───────────────┘    └────────────────────┘
```

### 3.2 DictCache 接口契约

```typescript
// 模块: src/lib/farm-api/dict-cache.ts

interface DictEntry {
  label: string    // 显示文本（如 "平原"）
  value: string    // 实际值（如 "0"）
}

class DictCache {
  // 启动时调用，全量加载已知 dictType。getToken 用于获取 Farm-Server 认证 token
  static async preload(dictTypes: string[], getToken: () => Promise<string>): Promise<void>

  // 按类型+值查询标签，未命中返回 fallback
  static getLabel(dictType: string, value: string | number, fallback?: string): string

  // 按类型获取全部映射（供百分比计算等场景）
  static getMap(dictType: string): Map<string, string>

  // 注册静态映射兜底（Farm-Server 无字典数据时使用）
  static registerStatic(dictType: string, mapping: Record<string, string>): void

  // 启动定时刷新（setInterval）
  static startRefreshLoop(intervalMs?: number): void
}
```

### 3.3 已知 dictType 清单

从 dict-data-api.md 和 OpenAPI 推断：

| dictType | 用途 | 影响字段 | 调用方 |
|----------|------|---------|--------|
| `farm_massif_landform` | 地貌类型（0=平原/1=盆地/2=丘陵/3=山地/4=高原） | `landform` | land-analysis route.ts |
| `farm_massif_fertility_level` | 肥力等级（0=低/1=中/2=高） | `fertilityLevel` | land-analysis route.ts |
| `farm_massif_moisture_type` | 土壤性质（0=沙土/1=壤土/2=粘土/3=砂壤土/4=粉壤土/5=粘壤土/6=重粘土） | `moistureType` | land-analysis route.ts |
| `farm_massif_status` | 地块状态（0=正常耕种/1=休耕/2=建设占用/3=废弃） | `status` | farm-data-tools.ts（Task 7） |
| `farm_massif_type` | 地块类型（0=耕地/1=园地/2=林地/3=设施农用地/4=草地/5=撂荒地/6=其他） | `type` | farm-data-tools.ts（Task 7） |

> **更新 (2026-06-25)**：5 个 dictType 均已在 Farm-Server 字典接口注册，`DictCache` 已全部支持。Task 7 将 `status`/`type` 的翻译能力接入 Agent 工具链路。

> **注意**：`moistureType` 对应的 dictType 名称需要从 Farm-Server 确认，可能在 `/system/dict-data/type` 的响应中搜索包含 `moisture` 或 `soil` 的 dictType。
>
> **P0-1 兜底策略（Review v1 回流）**：实施前调用 `/system/dict-data/type` 确认/搜索 moistureType 对应的 dictType。如 Farm-Server 无该字典，则通过 `DictCache.registerStatic("farm_massif_moisture_type", {...})` 注册静态映射作为兜底——从 OpenAPI 规范或已验证的硬编码枚举定义中提取。

### 3.4 route.ts 改动点

> **P1-2 Next.js 生命周期适配（Review v1 回流）**：Next.js API Routes 无传统启动钩子，DictCache 采用 lazy-init 模式：首次 `getLabel()` 调用时触发 `preload()`，加 Promise 锁防止并发重复加载；定时刷新改用模块顶层 `setInterval`（长期运行的 Node.js 进程下有效），降级为 TTL 惰性刷新（缓存过期后下次查询自动刷新）。

**fertility 计算**（原 166-178 行）：
- `fertilityLevel` 取值兼容 `number | string | null`
- 映射表改为 `DictCache.getMap("farm_massif_fertility_level")`
- 保留面积加权逻辑不变

**soilTypeSummary 计算**（新增，参照 fertility 模式）：
- 按 `moistureType` 分组，从 DictCache 查 label
- 面积加权计算百分比
- 输出格式：两空格分隔，如 `"粘壤土 60%  壤土 40%"`

**LLM prompt 更新**：
- `fertilitySummary` 和 `soilTypeSummary` 均传入 userInput（已计算好，LLM 直接使用）
- 更新 land-analysis.ts prompt 的 soilInfo schema，字段名对齐 `soilTypeSummary`

### 3.5 LLM 输出后处理

LLM 输出后，从 `parsed` 中提取 LLM 推断的 `basicInfo`/`climateInfo`，但 `soilInfo` 中的 `fertility` 和 `soilTypeSummary` **强制覆盖**为 route.ts 确定性计算的值。这解决了 LLM prompt 输出 schema 与 Zod 验证 schema 字段名不匹配的问题。

---

## 四、实施步骤 + 依赖图

> **前置条件（Review v1 回流 P0-1）**：实施前必须先调用 `/system/dict-data/type` 确认 moistureType 对应的 dictType 是否存在。不存在则准备 DictCache.registerStatic 的静态映射数据。

```
Task 0 (P0-1 前置确认: moistureType dictType) ── 阻塞所有后续 Task
                             │
                             ▼
Task 1 (route.ts 肥力修复) ──┐
                             │ 可并行
Task 2 (DictCache 模块)    ──┘
                             │
                             ▼
Task 3 (route.ts 接入 DictCache + soilTypeSummary)
                             │
                             ▼
Task 4 (LLM prompt 更新 + 后处理)
                             │
                             ▼
Task 5 (.md 文档差异记录)
                             │
                             ▼
Task 6 (编译验证 + 端到端测试)
                             │
                             ▼
Task 7 (farm-data-tools.ts Agent 工具接入 DictCache 字段翻译) [2026-06-25 增量]
```

### Task 0: 前置确认 moistureType dictType（P0 阻断）

- [ ] 调用 `/system/dict-data/type` 搜索包含 `moisture`/`soil` 的 dictType
- [ ] 如存在 → 更新 §3.3 表格中的确切 dictType 名称
- [ ] 如不存在 → 准备 `DictCache.registerStatic("farm_massif_moisture_type", {...})` 静态映射（来源：OpenAPI 规范或已验证枚举定义）

### Task 1: 修复 route.ts 肥力计算（P0）

**改动文件**: `src/app/api/h5/production-plan/land-analysis/route.ts`

- [ ] `fertilityLevel` 取值兼容 `number | string | null`（`String(p.fertilityLevel)` 统一转 string 查映射表）
- [ ] 映射表扩展为 `{ '0':'低', '1':'中', '2':'高', '低':'低', '中':'中', '高':'高' }`，兼容中文文本直传
- [ ] 保留面积加权逻辑
- [ ] 验证标准：给定 mock plots 数据，fertility 输出 `"高 60% 中 40%"` 格式

### Task 2: 创建 DictCache 模块（P1）

**新建文件**: `src/lib/farm-api/dict-cache.ts`

- [ ] 实现 `DictCache` 类（in-memory Map<dictType, Map<value, label>>）
- [ ] `preload(dictTypes)` 方法：通过 farmClient 逐个调用 `/system/dict-data/type?type=xxx`，解析 `DictDataVO[]` 填充 Map
- [ ] `getLabel(dictType, value, fallback?)` 方法
- [ ] `getMap(dictType)` 方法
- [ ] `startRefreshLoop(intervalMs)` 方法
- [ ] 错误处理：Farm-Server 不可用时使用已有缓存，首次加载失败则 fallback 到硬编码兜底映射
- [ ] 验证标准：独立单元测试，mock farmClient 验证 preload → getLabel 链路

### Task 3: route.ts 接入 DictCache（P1）

**改动文件**: `src/app/api/h5/production-plan/land-analysis/route.ts`

- [ ] 启动时（模块顶层或首次请求）调用 `DictCache.preload([...knownTypes])`
- [ ] fertility 计算改用 `DictCache.getLabel("farm_massif_fertility_level", String(p.fertilityLevel))`
- [ ] 新增 soilTypeSummary 计算：按 `moistureType` 分组 → `DictCache.getLabel("farm_massif_moisture_type", ...)` → 面积加权 → `"类型A x%  类型B x%"` 格式
- [ ] 删除硬编码的 `FERTILITY_LABELS` 和新增的 `MOISTURE_TYPE_LABELS`
- [ ] `soilTypeSummary` 和 `fertilitySummary` 传入 userInput
- [ ] 验证标准：给定 mock 数据，输出格式符合小程序消费者要求

### Task 4: LLM prompt 更新 + 后处理（P1）

**改动文件**: `src/agents/prompts/experts/land-analysis.ts`, `src/app/api/h5/production-plan/land-analysis/route.ts`

- [ ] land-analysis.ts prompt 中 soilInfo 字段名 `soilType` → `soilTypeSummary`
- [ ] prompt 中明确 `fertilitySummary` 和 `soilTypeSummary` 直接使用输入值，无需推理
- [ ] route.ts LLM 响应后处理：`result.soilInfo.fertility = fertilitySummary`, `result.soilInfo.soilTypeSummary = soilTypeSummary`
- [ ] 验证标准：Zod schema 校验通过（`landAnalysisSchema.safeParse` 返回 success）

### Task 5: .md 文档差异记录（P2）

**改动文件**: `docs/大田精准耕播智能决策系统/knowledge/02-规范/地块基本信息管理接口文档.v2.md`

- [ ] 新增"枚举值映射"章节（landform / fertilityLevel / moistureType 的来源与映射表）
- [ ] 新增"与 OpenAPI 差异记录"章节（标注已知类型不一致）
- [ ] 验证标准：文档描述与实际 API + 字典接口一致

### Task 6: 编译验证 + 端到端

- [ ] `npx tsc --noEmit` 通过
- [ ] `npm run lint` 通过
- [ ] 手动测试 `/api/h5/production-plan/land-analysis` 端点，验证 response 中 soilInfo 字段格式

### Task 7: Agent 工具接入 DictCache 字段翻译（P1）[2026-06-25 增量]

**改动文件**: `src/agents/tools/impl/farm-data-tools.ts`

**背景**：`queryMassifTool` 返回给 LLM 的是原始整数值（`type: 0, status: 2, moistureType: 1`），LLM 需自行推断含义。应接入 DictCache 将枚举字段翻译为中文标签后再返回。

- [ ] 从 `src/lib/farm-api/dict-cache` import `getLabel`
- [ ] 定义 `MASSIF_DICT_MAP`：`type→farm_massif_type`、`status→farm_massif_status`、`moistureType→farm_massif_moisture_type`、`landform→farm_massif_landform`、`fertilityLevel→farm_massif_fertility_level`
- [ ] 在 `queryMassifTool` 执行函数中，`unwrapPageResponse` 后遍历 `list`，将匹配的字段值通过 `getLabel(dictType, String(value), String(value))` 翻译
- [ ] 翻译后的值保留原始值作为 fallback（DictCache 未命中时兜底）
- [ ] 验证标准：工具返回的 massif 数据中 `type`/`status`/`moistureType` 等字段为中文标签

> **前置依赖**：依赖 Task 2（DictCache 模块）、Task 0（dictType 确认）。
> 其他 Agent 工具（`querySoilMoistureTool`/`queryInsectDataTool`）暂无枚举字段需翻译，本次仅覆盖 `queryMassifTool`。

---

## 五、验收标准

- [ ] fertility 返回 `"高 x% 中 x% 低 x%"` 格式，不再出现 `"未知 100%"`
- [ ] soilTypeSummary 返回 `"粘壤土 x%  壤土 x%"` 格式（两空格分隔）
- [ ] DictCache 模块可独立导入使用，preload → getLabel 链路正常
- [ ] route.ts 不再包含硬编码的枚举映射常量
- [ ] DictCache 在 Farm-Server 不可用时使用缓存兜底，不抛异常
- [ ] Zod schema 校验通过（不再因字段名不匹配而 fallback 到 raw output）
- [ ] .md 文档中枚举值来源可追溯
- [ ] `farm-data-tools.ts` `queryMassifTool` 返回数据中 `type`/`status`/`moistureType`/`landform`/`fertilityLevel` 已翻译为中文标签（Task 7）

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/24/farm-agent-land-analysis-dict-cache-add-route-v1.md` |
| Handoff | `.qoder/plans/2026-06/24/farm-agent-land-analysis-dict-cache-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-land-analysis-dict-cache-review-v1.md` |
| Spec | `.qoder/specs/farm-agent-land-analysis-dict-cache/spec.md` |
| Tasks | `.qoder/specs/farm-agent-land-analysis-dict-cache/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-land-analysis-dict-cache/checklist.md` |
