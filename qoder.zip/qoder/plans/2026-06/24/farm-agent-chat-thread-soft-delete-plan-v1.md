# farm-agent-chat-thread-soft-delete-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对。不要写完整 TS 类型定义、WHEN-THEN 场景——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-chat-thread-soft-delete-v1
- **启动时间**: 2026-06-24T12:10:00Z
- **父 Plan**: `chat-thread-tab-plan-v1.md`（2026-05-26，聊天列表管理 Tab 计划）
- **关联文档**:
  - Runtime Review: `.qoder/reviews/farm-agent-chat-thread-soft-delete-runtime-review-v1.md`
  - ADD Route: `.qoder/plans/2026-06/24/farm-agent-chat-thread-soft-delete-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-06/24/farm-agent-chat-thread-soft-delete-handoff-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `prisma/main.prisma` | SCHEMA | SCHEMA_MODIFIED | ChatThread 无 deletedAt 字段 | ChatThread 新增 deletedAt DateTime? | 待实施 |
| `src/services/chat-persistence.ts` | SERVICE | SERVICE_MODIFIED | deleteThread() 物理删除 + getThread/getThreadsByUser 不过滤已删除 | deleteThread() 软删除 + 查询过滤 deletedAt=null | 待实施 |
| `docs/大田精准耕播智能决策系统/knowledge/01-架构/《聊天实例管理技术文档》.md` | DOC | DOC_UPDATED | 4.3 节删除对话描述未区分软/硬删除 | 补充软删除语义和数据恢复说明 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

[Runtime Review 发现 #1](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-chat-thread-soft-delete-runtime-review-v1.md)：

- `ChatThread.deleteThread()` 使用 `prisma.chatThread.delete()` **物理删除**
- 关联的 `ChatMessage` 和 `ChainTraceRecord` 因 `onDelete: Cascade` 级联删除
- 用户删除对话 → 数据永久丢失，无法恢复
- 线上已验证：`thread_132b2f77-06df-409e-924c-42a47a190e4f` 返回 `"对话不存在"`

### 1.2 目标

将 ChatThread 删除从**物理删除**改为**软删除**：
- `ChatThread` 模型新增 `deletedAt DateTime?` 字段
- `deleteThread()` 设置 `deletedAt = now()` 而非 DELETE 行
- 所有查询自动过滤 `deletedAt != null` 的线程
- API 行为对外不变（依然返回 success），但数据可恢复

---

## 二、方案选型

| 方案 | 数据安全 | 实现复杂度 | 兼容性 | 结论 |
|------|---------|-----------|--------|------|
| A: 新增 deletedAt 字段 + Service 层软删除 | ✅ 数据不丢失 | 低（1 字段 + 3 方法改造） | ✅ 完全向后兼容 | **采用** |
| B: 新增 status 字段（active/deleted）| ✅ 数据不丢失 | 低 | ✅ 但语义不如 deletedAt 明确 | 不采用 |
| C: 不做软删除，前端加确认弹窗 | ❌ 数据仍丢失 | 最低 | ✅ | 不采用 |

### 2.2 选型理由

方案 A 是项目既有模式：`ProductionPlan.status`、`FarmTask.completion` 均采用状态标记而非物理删除。`deletedAt` 比 `status` 更精确地表达"何时被删除"，且 `DateTime?` 天然支持 `null = 未删除` 的查询过滤。

---

## 三、架构设计

### 3.1 数据模型变更

```
ChatThread
  + deletedAt: DateTime?   ← 新增，null = 未删除，非 null = 已删除
```

### 3.2 Service 层变更

```
deleteThread(threadId)
  改前: prisma.chatThread.delete({ where: { id: threadId } })
  改后: prisma.chatThread.update({ where: { id: threadId }, data: { deletedAt: new Date() } })

getThread(threadId)
  改前: findUnique({ where: { id: threadId } })
  改后: findUnique({ where: { id: threadId, deletedAt: null } })

getThreadsByUser(userId)
  改前: findMany({ where: { userId } })
  改后: findMany({ where: { userId, deletedAt: null } })
```

### 3.3 API 层

`DELETE /api/agent/chat/threads?threadId=` 对外合约不变：
- 请求参数不变
- 响应 `{ success: true }` 不变
- 内部行为从物理删除变为软删除

---

## 四、实施步骤 + 依赖图

```
Task 1 (Schema + Migration)
          │
          ▼
Task 2 (Service 改造)
          │
          ▼
Task 3 (文档更新)
          │
          ▼
Task 4 (tsc 验证 + 部署)
```

### Task 1: Prisma Schema 添加 deletedAt 字段 + 生成 Migration

- [ ] `prisma/main.prisma` ChatThread 模型新增 `deletedAt DateTime?`
- [ ] 执行 `npx prisma migrate dev --name add_deletedat_to_chatthread` 生成迁移
- [ ] 确认迁移 SQL 正确（ALTER TABLE "ChatThread" ADD COLUMN "deletedAt" TIMESTAMP）

### Task 2: ChatPersistenceService 软删除改造

- [ ] `deleteThread()`: `prisma.chatThread.delete()` → `prisma.chatThread.update({ data: { deletedAt: new Date() } })`
- [ ] `getThread()`: where 条件增加 `deletedAt: null`
- [ ] `getThreadsByUser()`: where 条件增加 `deletedAt: null`
- [ ] 审计日志保持不变（THREAD_DELETE phase + "线程删除成功"）

### Task 3: 文档更新

- [ ] `《聊天实例管理技术文档》.md` §4.3 补充软删除说明：删除后数据保留，可通过 API 恢复
- [ ] 补充故障排查条目：对话误删后的恢复方式

### Task 4: 验证

- [ ] `npx tsc --noEmit` 通过
- [ ] 部署 rfai 后验证：创建线程 → 删除 → 直接查 DB 确认 deletedAt 非空、行未删除
- [ ] 验证已删除线程不在 thread 列表中返回

---

## 五、验收标准

- [ ] `ChatThread` 表存在 `deletedAt` 列，默认 NULL
- [ ] 删除线程后 `deletedAt` 被设置为当前时间，行未被物理删除
- [ ] `getThreadsByUser()` 不返回已删除线程
- [ ] `getThread()` 对已删除线程返回 null（日志 `[THREAD_LOAD] 线程不存在`）
- [ ] tsc 编译通过
- [ ] 文档已更新

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| Runtime Review | `.qoder/reviews/farm-agent-chat-thread-soft-delete-runtime-review-v1.md` |
| 父 Plan | `.qoder/plans/2026-05/26/chat-thread-tab-plan-v1.md` |
| ADD Route | `.qoder/plans/2026-06/24/farm-agent-chat-thread-soft-delete-add-route-v1.md` |
| Handoff | `.qoder/plans/2026-06/24/farm-agent-chat-thread-soft-delete-handoff-v1.md` |
| 技术文档 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《聊天实例管理技术文档》.md` |
