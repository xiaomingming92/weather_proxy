# farm-agent-structured-data-agrisynapse-rehydration-fix-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度（文件路径 + Phase 验收标准 + 架构维度全覆盖）。**不要**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-structured-data-agrisynapse-rehydration-fix-v1
- **启动时间**: 2026-06-24T09:00:00+08:00
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/24/farm-agent-structured-data-agrisynapse-rehydration-fix-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-06/24/farm-agent-structured-data-agrisynapse-rehydration-fix-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-structured-data-agrisynapse-rehydration-fix-review-v1.md`
  - 前序 Plan（主联动）: `.qoder/plans/2026-05/18/fix-streaming-structured-data-plan-v1.md` — 解决了 farm-agent 侧 structured_update 事件字段不全的问题，但未覆盖 agrisynapse 侧的 rehydration 路径
  - 前序 Plan（次联动）: `.qoder/plans/2026-06/17/farm-agent-intermediate-streaming-ui-fix-plan-v1.md` — 修改了 agentChat.ts 的 loadThread 方法（同一段 rehydration 代码），引入了 streamingTraces 间接读取
  - 前序 Plan（三级联动）: `.qoder/plans/2026-06/15/farm-agent-reasoning-structured-dataflow-plan-v1.md` — 引入了 reasoning.ts 的 F2 工具证据回填逻辑，其 evidenceChain content 构建方式是 Bug #3 的根因
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| agrisynapse `src/store/modules/agentChat.ts` | STORE | REHYDRATION_FIX | loadThread 中 verdict/evidenceChain/reasoningPath 直接透传 metadata（无形状转换） | loadThread 中 verdict 字段做 camelCase→snake_case 转换；evidenceChain 提取 evidencs 数组；reasoningPath 提取 steps 数组 | 待实施 |
| agrisynapse `src/store/modules/agentChat.ts` | STORE | SSE_PATH_VERIFY | structured_update handler 中 verdict 转换逻辑存在但 evidenceChain/reasoningPath 提取逻辑也正确 | 确认无需修改，增加注释标记 SSE 路径与 rehydration 路径的形状一致性 | 待实施 |
| farm-agent `src/agents/nodes/reasoning.ts` | NODE | EVIDENCE_CONTENT_FIX | F2 工具证据回填时 content 存原始 HTTP 响应字符串（`tm.content.slice(0,500)`），无 data 字段 | content 改为摘要描述；data 字段从 state.toolResults 或解析 tm.content 填充结构化行数据 | 待实施 |
| agrisynapse `src/views/llm/components/LlmChatView.vue` | COMPONENT | TOOL_EVIDENCE_RENDER_FIX | 证据链 tool 类型渲染内容依赖 `(e as any).data` 做表格渲染，但当前 tool evidence 无 data 字段 | 增加 tool 源证据的 data-less 回退渲染（摘要+recordCount），不依赖 data 字段存在 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

用户反馈 `thread_83f7d51e-4861-4ee3-904e-1e86a313cdb0` 的聊天响应数据存在三个问题，经全链路审计日志追踪和代码分析，根因定位如下：

**Bug #1：最终态置信度分析数值没有持久化（P0）**

- **现象**：页面刷新后，判决面板的置信度数值显示为 0%（SSE 流式时正常）
- **根因**：agrisynapse `agentChat.ts` 的 rehydration 路径（`loadThread`）直接透传 `metaObj.verdict` 到前端消息模型，不做字段名转换
- **数据流断裂点**：
  ```
  后端 response.ts → StructuredVerdict (camelCase: baseConfidence, finalConfidence)
    → DB metadata 存储 camelCase
    → SSE 路径 agentChat.ts:381-392 显式转换 camelCase→snake_case ✅
    → Rehydration agentChat.ts:501 直接透传 ❌（前端渲染期望 snake_case: final_confidence）
  ```

**Bug #2：证据链/推理链大量内容没有持久化（P0）**

- **现象**：页面刷新后，证据链面板渲染出 3 个字符串（"evidences"/"totalScore"/"sourceBreakdown"）而非证据项；推理路径渲染出 2 个字符串（"steps"/"traces"）
- **根因**：后端构建的是嵌套结构（`{ evidences: [...] }`, `{ steps: [...] }`），SSE 路径提取了内层数组，但 rehydration 路径传入整个外层对象
- **数据流断裂点**：
  ```
  后端 response.ts → evidenceChain: { evidences: [...], totalScore, sourceBreakdown }
    → SSE 路径 agentChat.ts:369-372 提取 ec.evidences 数组 ✅
    → Rehydration agentChat.ts:502 传入整个对象 ❌
    → 前端 v-for="e in msg.evidenceChain" 遍历对象 keys
  ```

**Bug #3：工具响应渲染成原始 HTTP 响应（P0）**

- **现象**：证据链中 tool_result 类型的 content 显示为原始 HTTP JSON 响应（如 `{"success":true,"data":{"code":0,...}}`）
- **根因**：`reasoning.ts` F2 工具证据回填时，content 直接截取 `tm.content`（原始 HTTP 响应），未消费 `state.toolResults` 的结构化数据，也未设置 `data` 字段（前端表格依赖 `(e as any).data`）
- **数据流断裂点**：
  ```
  state.toolResults → { toolName, list: [...], columns: [...] }  ← 有结构化数据
  tm.content → "{"success":true,"data":{"code":0,"data":{"list":[...]}}}"  ← 原始 HTTP 响应
  evidenceChain[tool_result].content = tm.content.slice(0, 500)  ← 存了原始响应
  evidenceChain[tool_result].data = undefined  ← 无表格数据
  ```

### 1.2 目标

1. **置信度数据 rehydration 一致性**：DB 加载路径与 SSE 流式路径产出的 `verdict.confidence` 字段形状一致（统一为 snake_case）
2. **证据链/推理路径 rehydration 一致性**：DB 加载路径产出与 SSE 路径一致的扁平数组（而非嵌套对象）
3. **工具证据内容结构化**：evidenceChain 中 tool_result 类型的内容使用结构化摘要 + data 字段支持前端表格渲染

---

## 二、方案选型

### 2.1 候选方案对比

| 方案 | 修改点 | 影响面 | 维护成本 | 结论 |
|------|--------|--------|---------|------|
| **A: 在 rehydration 路径做转换**（agrisynapse 侧修复） | agentChat.ts loadThread 增加字段形状转换 + 嵌套提取 | 仅 1 个文件（agrisynapse），工具证据修复需额外 2 个文件 | 低（转换逻辑集中在 rehydration 入口） | ✅ 采用 |
| B: 在 DB 写入路径统一形状（farm-agent 侧修复） | response.ts 改为输出 snake_case + 扁平数组 | 影响 SSE 路径（需修改后端 + SSE handler + 已存数据） | 高（破坏 SSE 路径的现有转换逻辑 + 存量数据不兼容） | ❌ 风险大 |

### 2.2 选型理由

方案 A 遵循 **ADD-3（最小可观测单元）**——只在数据流的消费端补齐缺失的转换，不改动上游已有契约。方案 B 需要同时修改后端输出格式、SSE handler 的提取逻辑（当前依赖嵌套结构提取），且已有 2026-05-18 的 `fix-streaming-structured-data-plan-v1` 建立了 "SSE 路径提取内层" 的既定事实，改后端输出会导致 SSE 路径的提取代码变冗余。

---

## 三、架构设计

### 3.1 数据流修复全景

```
┌─ farm-agent 后端 ────────────────────────────────────────────────┐
│                                                                   │
│  reasoning.ts [F2 回填]                                           │
│  ┌─────────────────────────────────────────────────────────┐     │
│  │ tool evidence:                                          │     │
│  │   content: 摘要描述（不再存原始 HTTP 响应）               │     │
│  │   data: { list, columns } ← 从 state.toolResults 取值   │     │
│  └─────────────────────────────────────────────────────────┘     │
│                          │                                        │
│  response.ts                                                    │
│  ┌─────────────────────────────────────────────────────────┐     │
│  │ structuredResponse (camelCase, 嵌套)                      │     │
│  │   → SSE: { evidenceChain, reasoningPath, verdict, ... }  │     │
│  └─────────────────────────────────────────────────────────┘     │
│                          │                                        │
└──────────────────────────┼────────────────────────────────────────┘
                           │
            ┌──────────────┼──────────────┐
            ▼              ▼              ▼
        SSE 流          DB 存储        Rehydration
            │              │              │
┌───────────┼──────────────┼──────────────┼──────────────────────────┐
│ agrisynapse 前端                                                    │
│                                                                     │
│  agentChat.ts SSE handler          agentChat.ts loadThread          │
│  ┌────────────────────────┐       ┌──────────────────────────┐     │
│  │ verdict: 提取 + 转换    │       │ verdict: 提取 + 转换 ✅   │     │
│  │   camelCase→snake_case  │       │   (与 SSE 路径一致)       │     │
│  │ evidenceChain:          │       │ evidenceChain:           │     │
│  │   提取 .evidences 数组   │       │   提取 .evidences 数组 ✅  │     │
│  │ reasoningPath:          │       │ reasoningPath:           │     │
│  │   提取 .steps 数组       │       │   提取 .steps 数组 ✅     │     │
│  └────────────────────────┘       └──────────────────────────┘     │
│                                                                     │
│  LlmChatView.vue (渲染)                                             │
│  ┌────────────────────────────────────────────────────────┐       │
│  │ tool 源证据渲染:                                        │       │
│  │   v-if="data" → 表格渲染（正常路径）                     │       │
│  │   v-else → 回退摘要渲染（新增）                          │       │
│  │ verdict 置信度:                                         │       │
│  │   统一使用 snake_case 字段 (final_confidence, ...)      │       │
│  └────────────────────────────────────────────────────────┘       │
└─────────────────────────────────────────────────────────────────────┘
```

### 3.2 修复策略：在 rehydration 入口统一归一化

```
loadThread(messages) {
  messages.map(m => {
    const meta = m.metadata

    // ★ 归一化 verdict: camelCase → snake_case（与 SSE handler 一致）
    const rawVerdict = meta.verdict
    let verdict = rawVerdict
    if (rawVerdict?.confidence) {
      const c = rawVerdict.confidence
      verdict = { ...rawVerdict, confidence: {
        base_confidence: c.baseConfidence ?? c.base_confidence ?? 0,
        reliability_discount: c.reliabilityDiscount ?? c.reliability_discount ?? 0,
        conflict_discount: c.conflictDiscount ?? c.conflict_discount ?? 0,
        uncertainty_discount: c.uncertaintyDiscount ?? c.uncertainty_discount ?? 0,
        final_confidence: c.finalConfidence ?? c.final_confidence ?? 0,
        breakdown: c.breakdown ?? c.factors ?? [],
      }}

    // ★ 归一化 evidenceChain: 提取 .evidences 数组（与 SSE handler 一致）
    const rawChain = meta.evidenceChain
    const evidenceChain = rawChain?.evidences ?? (Array.isArray(rawChain) ? rawChain : [])

    // ★ 归一化 reasoningPath: 提取 .steps 数组（与 SSE handler 一致）
    const rawPath = meta.reasoningPath
    const reasoningPath = rawPath?.steps ?? (Array.isArray(rawPath) ? rawPath : [])

    return { ...msg, verdict, evidenceChain, reasoningPath }
  })
}
```

---

## 四、实施步骤 + 依赖图

```
Task 1 (agrisynapse rehydration verdict 转换)
  │  文件: agentChat.ts
  │  Bug #1
  │
Task 2 (agrisynapse rehydration evidenceChain/reasoningPath 提取)
  │  文件: agentChat.ts (同文件，可合并)
  │  Bug #2
  │
  └────┬────┘
       │
       ▼
Task 3 (farm-agent tool evidence content 结构化)
  │  文件: reasoning.ts
  │  Bug #3 后端侧
  │
       │
       ▼
Task 4 (agrisynapse tool evidence 回退渲染)
  │  文件: LlmChatView.vue
  │  Bug #3 前端侧
  │
       │
       ▼
Task 5 (编译验证 + 手动测试)
```

### Task 1: agrisynapse rehydration — verdict 字段骆驼/蛇形转换

**文件**: `agrisynapse/src/store/modules/agentChat.ts`（`loadThread` 方法）

**改动**: 在 `loadThread` 的 `messages.map` 中，将 `metaObj.verdict` 的 confidence 字段从 camelCase 转换为 snake_case，与 SSE handler（lines 381-392）保持一致。

**审计点**: ADD-7 记录 `targetType: "STORE"`, `action: "REHYDRATION_FIX"`, `beforeState: "camelCase透传"`, `afterState: "snake_case归一化"`

### Task 2: agrisynapse rehydration — evidenceChain/reasoningPath 嵌套提取

**文件**: `agrisynapse/src/store/modules/agentChat.ts`（`loadThread` 方法，同文件）

**改动**: 在 `loadThread` 的 `messages.map` 中，对 `evidenceChain` 执行 `metaObj.evidenceChain?.evidences ?? (Array.isArray(metaObj.evidenceChain) ? metaObj.evidenceChain : [])`；对 `reasoningPath` 执行 `metaObj.reasoningPath?.steps ?? (Array.isArray(metaObj.reasoningPath) ? metaObj.reasoningPath : [])`

**向后兼容**: `Array.isArray` 回退确保 SSE 路径已提取的数组不会被二次包装

### Task 3: farm-agent tool evidence content 结构化

**文件**: `farm-agent/src/agents/nodes/reasoning.ts`（F2 工具证据回填代码段，约 L441-457）

**改动**: 
1. 工具证据的 `content` 改为摘要描述（如 `"[query_farm_weather] 查询成功，返回 12 条记录"`），而非原始 HTTP 响应截断
2. 从 `state.toolResults` 传递 `data` 字段（`{ list, columns }`），供前端表格渲染

### Task 4: agrisynapse tool evidence 回退渲染

**文件**: `agrisynapse/src/views/llm/components/LlmChatView.vue`（证据链 tool 源渲染区域）

**改动**: 在 tool 源证据项展开时，当 `(e as any).data` 不存在时，增加摘要信息渲染（显示 content 文本 + recordCount），作为无表格数据时的回退 UI。

### Task 5: 编译验证 + 手动测试

- `npx tsc --noEmit`（agrisynapse 侧）
- `npx tsc --noEmit`（farm-agent 侧）
- 手动测试：发送消息 → 确认 SSE 流式时 evidenceChain/verdict/reasoningPath 正常 → 刷新页面 → 确认全部数据保持 → 发送第二条消息 → 确认不破坏上一轮

---

## 五、验收标准

- [ ] 刷新页面后，判决面板置信度数值与 SSE 流式时一致（非 0%）
- [ ] 刷新页面后，证据链面板渲染出证据项列表而非对象 key
- [ ] 刷新页面后，推理路径面板渲染出推理步骤列表而非对象 key
- [ ] 证据链中 tool_result 类型的内容显示为摘要描述，非原始 HTTP JSON
- [ ] 工具数据支持表格渲染（有 data 字段时）
- [ ] SSE 流式路径行为不变（regression-free）
- [ ] `npx tsc --noEmit` 两端零错误
- [ ] 发送第二条消息后，上一轮结构化数据不被损坏

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/24/farm-agent-structured-data-agrisynapse-rehydration-fix-add-route-v1.md` |
| Handoff | `.qoder/plans/2026-06/24/farm-agent-structured-data-agrisynapse-rehydration-fix-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-structured-data-agrisynapse-rehydration-fix-review-v1.md` |
| Spec | `.qoder/specs/farm-agent-agrisynapse-rehydration-fix-v1/spec.md` |
| Tasks | `.qoder/specs/farm-agent-agrisynapse-rehydration-fix-v1/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-agrisynapse-rehydration-fix-v1/checklist.md` |
| 前序 Plan（主联动） | `.qoder/plans/2026-05/18/fix-streaming-structured-data-plan-v1.md` |
| 前序 Plan（次联动） | `.qoder/plans/2026-06/17/farm-agent-intermediate-streaming-ui-fix-plan-v1.md` |
| 前序 Plan（三级联动） | `.qoder/plans/2026-06/15/farm-agent-reasoning-structured-dataflow-plan-v1.md` |

---
*本规划版本: v1.0*
