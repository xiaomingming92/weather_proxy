# farm-agent-structured-data-agrisynapse-rehydration-fix-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。
>
> **绑定**：Plan: `farm-agent-structured-data-agrisynapse-rehydration-fix-plan-v1.md` · Spec: `farm-agent-agrisynapse-rehydration-fix-v1/spec.md` · Tasks: `farm-agent-agrisynapse-rehydration-fix-v1/tasks.md` · Handoff: `farm-agent-structured-data-agrisynapse-rehydration-fix-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs 三元组齐全。

**输入**：
- Plan: `.qoder/plans/2026-06/24/farm-agent-structured-data-agrisynapse-rehydration-fix-plan-v1.md`
- 联动 Plan: `fix-streaming-structured-data-plan-v1`, `intermediate-streaming-ui-fix-plan-v1`, `reasoning-structured-dataflow-plan-v1`

**动作**：
1. 确认 Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md` ✅
2. 调用 `find_related_docs` 检索受影响的架构/规范文档 → 命中 0 篇（纯 bug fix，不触发项目文档变更）
3. **项目文档更新声明**：本次为纯 bug fix，修复 agrisynapse rehydration 路径的数据字段形状不一致问题，不涉及项目架构文档（`docs/*/knowledge/`）的任何变更。理由：改动仅影响数据流消费端的归一化逻辑，不影响接口契约和系统架构。
4. 确认 Handoff 待生成（Step 8 收敛后）

**产出**：
- [ ] Specs 三元组路径确认
- [x] 项目文档无需更新声明（纯 bug fix）
- [ ] Handoff 就绪

---

## Step 1：功能分析与审计阶段定义

**目的**：本次为纯 bug fix（数据流归一化），不涉及新的业务阶段，无需扩展 AgentAuditPhase。

**动作**：
1. 列出本次变更涉及的所有业务阶段：无新增业务阶段
2. 无需扩展 `AgentAuditPhase` 联合类型
3. 确认审计数据通道：复用中央 `agent-audit-logger.ts`

**产出**：
- [ ] 本次审计阶段清单（无新增 Phase）
- [x] 确认无需扩展 AgentAuditPhase

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用。

**动作**：
1. 确认 `agentAudit(phase, detail, extra?)` 可用（无新增 Phase）
2. 确认辅助函数可用

**产出**：
- [ ] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan Task 1-4 实施代码修改。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | verdict rehydration 归一化 | agrisynapse `agentChat.ts` (loadThread) | `record_dev_operation` | — | 无 | ⬜ |
| 2 | evidenceChain/reasoningPath 嵌套提取 | agrisynapse `agentChat.ts` (loadThread) | `record_dev_operation` | — | Task 1（同文件可合并） | ⬜ |
| 3 | tool evidence content 结构化 | farm-agent `reasoning.ts` (F2 backfill) | `agentAudit("REASONING_EVIDENCE_BACKFILL", ...)`（已有） | — | 无 | ⬜ |
| 4 | tool evidence 回退渲染 | agrisynapse `LlmChatView.vue` | 无（纯渲染逻辑） | — | Task 3 | ⬜ |
| 5 | 编译验证 + 回归测试 | — | `record_dev_operation` | — | Task 1-4 | ⬜ |

### 依赖拓扑

```
Task 1 ──┐
          │ 可并行（同文件同一段代码）
Task 2 ──┘

Task 3 ──→ Task 4 → Task 5
```

### ADD-7 审计策略

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| agrisynapse `agentChat.ts` | STORE | REHYDRATION_FIX | loadThread 中 verdict 直接透传 camelCase；evidenceChain 传入嵌套对象 `{evidences:[],...}`；reasoningPath 传入嵌套对象 `{steps:[],...}` | verdict confidence 字段 camelCase→snake_case 转换；evidenceChain 提取 `.evidences` 数组；reasoningPath 提取 `.steps` 数组 | ⬜ |
| farm-agent `reasoning.ts` | NODE | EVIDENCE_CONTENT_FIX | F2 工具证据 content 为 `tm.content.slice(0,500)`（原始 HTTP 响应），无 data 字段 | content 改为摘要描述；data 从 state.toolResults 填充 `{list, columns}` | ⬜ |
| agrisynapse `LlmChatView.vue` | COMPONENT | RENDERING_FIX | tool 源证据无 data 时渲染空白表格 | 无 data 时回退渲染 content 文本摘要 | ⬜ |

**产出**：
- [ ] 全部 Task 的 `[T]` 项通过
- [ ] 每个文件有 `record_dev_operation` 记录
- [ ] `check_add_route_completeness` 返回 `complete`

---

## Step 3.5：实现审查

**目的**：代码完成后，验证意图与实现无语义鸿沟（ADD-10）。

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 跨项目联调检查：确认 SSE 事件格式不变、metadata JSON 结构不变
3. 生成 `review-implementation.md`
4. 所有 `[T]` 项通过后，生成 `review-runtime.md`

**产出**：
- [ ] `checklist.md` 全部 `[T]` 项已通过
- [ ] `review-implementation.md` 已生成
- [ ] `review-runtime.md` 已生成

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**动作**：
1. `npx tsc --noEmit`（agrisynapse）—— 零类型错误
2. `npx tsc --noEmit`（farm-agent）—— 零类型错误
3. 手动触发功能验证

**产出**：
- [ ] `tsc --noEmit` 两项目零错误
- [ ] 手动验证通过

---

## Step 5：AI 自动合规检查

**目的**：扫描全部修改文件的 ADD-1~ADD-7 合规性。本次纯 bug fix，无新增审计阶段，合规检查聚焦于：
- 修改后的 rehydration 路径与 SSE 路径产出形状一致（ADD-2 对称）
- 失败路径兼容（旧版无 data 的 tool evidence 不崩溃）

**产出**：
- [ ] 合规报告已生成

---

## Step 6-7：定位问题 + 修复验证

> 仅当 Step 4/5 发现异常时进入。

**产出**：
- [ ] 无异常则跳过

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**目的**：功能收敛判定，生成 Handoff，回到架构文档做最终校准。

**收敛条件**：
- [ ] checklist.md 全部 [T] 项已勾选且有可验证证据
- [ ] tasks.md 全部任务已完成
- [ ] `check_add_route_completeness` 返回 `complete`
- [ ] 刷新页面后置信度/证据链/推理路径全部正确渲染
- [ ] 工具证据 content 为可读摘要
- [ ] SSE 流式路径回归正常

**收敛后**：
1. 生成 Handoff 交接手册
2. 回到架构文档做最终校准（Step 0 第二阶段）

**产出**：
- [ ] 收敛判定结果
- [ ] Handoff 已生成
- [ ] 架构文档已校准（声明无变更）
- [ ] ADD-7 审计记录已落库确认

---

## 原子闭包判定

```
原子闭包三可性判定
══════════════════
业务功能: 修复 agrisynapse rehydration 路径结构化数据渲染缺陷（3 个 P0 Bug）

Task Groups:
  Group A (rehydration 归一化): Task 1 + Task 2 — agrisynapse agentChat.ts loadThread 字段形状转换
  Group B (工具证据结构化): Task 3 + Task 4 — farm-agent reasoning.ts content 构建 + agrisynapse LlmChatView 回退渲染

逐组业务价值判定:
  Group A (rehydration 归一化): 能用 — 修复后用户刷新页面即可看到正确的置信度/证据链/推理路径，独立产生完整业务价值
  Group B (工具证据结构化): 能用 — 修复后工具证据在证据链中显示可读摘要，有 data 时支持表格渲染，独立产生完整业务价值

判定结论: 需要 1 轮（1 个原子闭包）— 两个 Group 虽可独立验证，但共享同一验收路径（刷新页面），合为一轮减少回归次数

第1轮（原子闭包）: Task Groups {A, B} — 业务功能: 修复 agrisynapse rehydration 路径全部结构化数据渲染缺陷
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| agrisynapse `src/store/modules/agentChat.ts` | MODIFY | Task 1, 2 | STORE | ⬜ |
| farm-agent `src/agents/nodes/reasoning.ts` | MODIFY | Task 3 | NODE | ⬜ |
| agrisynapse `src/views/llm/components/LlmChatView.vue` | MODIFY | Task 4 | COMPONENT | ⬜ |
