# farm-agent — Land Analysis DictCache 字典缓存层 交接手册

> **适用场景**：单轮变更。修复 land-analysis 端点肥力/土壤类型输出，新建 DictCache 字典缓存层。
> **最新修订**: 2026-06-25 — 增量：Farm-Server 地块 API 字段 & 字典类型全量同步（MassifDTO + MASSIF_COLUMNS + DictCache preload 扩展 + 文档自动化同步）

---

## 1. 交接前状态

- `land-analysis/route.ts` fertility 硬编码 `{0:'低',1:'中',2:'高'}`，fertilityLevel 为 null/中文时输出"未知"
- soilTypeSummary 完全缺失
- 枚举映射散落在各 route 硬编码，无统一数据源
- MassifDTO.fertilityLevel 类型为 `number?`，与实际返回 `string|null` 不兼容

## 2. 交接后状态（目标）

- fertility 兼容 number/string/null，不出现"未知"
- soilTypeSummary 按面积加权输出 `"粘壤土 60%  壤土 40%"` 格式
- DictCache 提供统一字典查询接口（`getLabel`/`getMap`/`registerStatic`）
- LLM 后处理强制覆盖 soilInfo，不依赖 LLM 精度
- 5 个新增 AgentAuditPhase 覆盖全链路

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/lib/farm-api/dict-cache.ts` | 新建 | in-memory 字典缓存层，lazy-init + TTL + registerStatic 兜底 |
| 2 | `src/app/api/h5/production-plan/land-analysis/route.ts` | 修改 | fertility + soilTypeSummary 确定性计算 + LLM 后处理覆盖 |
| 3 | `src/lib/farm-api/massif.ts` | 修改 | fertilityLevel 类型 → `number \| string \| null` |
| 4 | `src/agents/prompts/experts/land-analysis.ts` | 修改 | 字段名 soilType → soilTypeSummary |
| 5 | `src/lib/agent-audit-logger.ts` | 修改 | 新增 5 个 Phase 字面量 |
| 6 | `docs/.../地块基本信息管理接口文档.v2.md` | 修改 | 枚举值映射 + OpenAPI 差异记录 |

### 2026-06-25 增量（Farm-Server 地块 API 全量同步）

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 7 | `src/lib/farm-api/massif.ts` | 修改 | MassifDTO 补全 `qrCodeUrl?: string`、`remark?: string`（Farm-Server 新增字段） |
| 8 | `src/agents/tools/impl/farm-data-tools.ts` | 修改 | MASSIF_COLUMNS 补全 `status`/`qrCodeUrl`/`remark` 三列 |
| 9 | `src/app/api/h5/production-plan/land-analysis/route.ts` | 修改 | DictCache preload 补全 `farm_massif_status`/`farm_massif_type`（3→5） |
| 10 | `docs/.../dict-data-api.md` | 修改 | 第 2 章新增 3 个字典类型汇总（status/moisture_type/type） |
| 11 | `scripts/sync-farm-api-index.ts` | 新建 | Farm-Server 文档同步总入口（STEPS 注册表） |
| 12 | `scripts/sync-farm-dict-api-docs.ts` | 新建 | 地块字典数据自动同步脚本（保留第1章，重写第2章） |
| 13 | `scripts/crontab.txt` | 修改 | 每日 9:00 统一入口 + 聚合日志 |
| 14 | `package.json` | 修改 | `docs:sync-farm-service-api` → index 统领 |

## 4. 回滚方案

```bash
git revert <commit>
```

无数据迁移，纯代码变更。

## 5. 执行前置检查

- [ ] Task 0: 调用 `/system/dict-data/type` 确认 moistureType dictType 或准备 registerStatic 静态映射
- [ ] `ensureValidToken(0, "service")` Farm-Server token 可用
- [ ] `npx tsc --noEmit` 当前基线的已知错误与本次变更无关

## 6. 执行步骤摘要

```text
Task 0 ── 前置确认 moistureType dictType（P0 阻断）
            │
            ▼
Task 1 ── 肥力修复（兼容 number/string/null）  ──┐
                                                   │
Task 2 ── DictCache 模块（lazy-init + TTL）      ──┤ 可并行
                                                   │
            ┌──────────────────────────────────────┘
            ▼
Task 3 ── 接入 DictCache + soilTypeSummary
            │
            ▼
Task 4 ── Prompt 更新 + 后处理覆盖
            │
            ▼
Task 5 ── 文档差异记录
            │
            ▼
Task 6 ── tsc + lint + E2E curl
```

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| moistureType dictType 不存在 | soilTypeSummary 输出"未知" | registerStatic 静态映射兜底 |
| Farm-Server 字典接口不可用 | DictCache 预加载失败 | 启动时已有缓存则继续使用；首次无缓存则 fallback 到 registerStatic |
| Next.js cold start 多次 preload | 并发重复请求 dict API | Promise 锁防并发 |

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

### 总体一键恢复

```text
query_audit_logs({ keyword: "dict-cache" })
```
→ 预期返回 ≥ 5 条记录

### 逐文件审计查询

```text
query_audit_logs({ targetId: "src/lib/farm-api/dict-cache.ts" })
→ COMPONENT_CREATED: DictCache 模块创建

query_audit_logs({ targetId: "src/app/api/h5/production-plan/land-analysis/route.ts" })
→ COMPONENT_MODIFIED: fertility + soilTypeSummary 改造

query_audit_logs({ keyword: "LAND_FERTILITY_CALC" })
→ agentAudit: 肥力计算审计记录
```

## 9. 后置确认

- [ ] `npx tsc --noEmit` 通过
- [ ] `npm run lint` 通过
- [ ] `check_phase_symmetry` 通过
- [ ] `check_failure_path` 通过
- [ ] `check_spec_sync` 通过
- [ ] RAHS ≥ 90
- [ ] 所有文件改动已记录 ADD-7 审计
- [ ] curl E2E 验证 fertility 不出现"未知"，soilTypeSummary 格式正确

---

## 10. Devlog（开发操作日志）

> 本节约会记录本次增量交付中的开发操作，确保交付物与实际行为一致、可追溯。

### 2026-06-25 增量执行记录

| 时间 | 操作 | 文件/工具 | 结果 |
|------|------|----------|------|
| 17:00 | Plan 定稿 | `farm-agent-massif-api-sync-plan-v1.md` | ✅ 含变更清单+影响范围+实施策略 |
| 17:05 | DOC_UPDATED | `dict-data-api.md` 新增 3 个 dictType 汇总章节 + 请求参数说明 | ✅ 5 个字典完整枚举 |
| 17:10 | MODIFY | `src/lib/farm-api/massif.ts` MassifDTO 补全 qrCodeUrl/remark | ✅ 23 字段完整 |
| 17:15 | MODIFY | `src/agents/tools/impl/farm-data-tools.ts` MASSIF_COLUMNS 补全 status/qrCodeUrl/remark | ✅ 14 列 |
| 17:20 | MODIFY | `src/app/api/h5/production-plan/land-analysis/route.ts` DictCache preload 补全 farm_massif_status/type | ✅ 3→5 dictType |
| 17:25 | CREATE | `scripts/sync-farm-api-index.ts` 统一同步入口 | ✅ 2 任务注册 |
| 17:25 | CREATE | `scripts/sync-farm-dict-api-docs.ts` 字典文档自动同步 | ✅ 保留第1章+重写第2章 |
| 17:30 | MODIFY | `scripts/crontab.txt` 改为 9:00 index 统领 + `package.json` npm script 改指 index | ✅ 1 条 cron + 1 条 npm |
| 17:35 | 运行验证 | `tsx scripts/sync-farm-api-index.ts` | ✅ 2/2 成功 (92 路径 + 26 条字典) |
| 17:40 | 端到端测试 | `tsx scripts/test-massif-sync.ts` MassifDTO + 5 dict API | ✅ 23 字段 + 5/5 dict 拉取成功 |
| 17:45 | Plan 索引更新 | `plans/index.md` 追加 plan 条目 | ✅ 4 条 06-25 记录 |
| 17:50 | ADD-7 审计 | `record_dev_operation` × 6 条 + `query_audit_logs` 回查 | ✅ 6/6 落库确认 |
| 18:00 | Plan 归属评估 | 4 个 plan 中判定 `land-analysis-dict-cache-plan-v1.md` 接管 Task 7 | ✅ 1 个归属 + 对应 plan/handoff 更新 |
| 18:05 | MODIFY | `land-analysis/route.ts` plots 补全 qrCodeUrl/remark/status（9→12 字段） | ✅ 端到端透传 |
| 18:05 | MODIFY | `land-analysis.ts` prompt 输入说明补全 status/qrCodeUrl/remark | ✅ 与 route.ts 对齐 |
| 18:10 | DOC_UPDATED | `瑞丰耘H5小程序API对接文档.md` §3.1 perPlotDetails 补全 status/qrCodeUrl/remark | ✅ 与 API 实际返回对齐 |
| 18:15 | **Task 7 实施** | `farm-data-tools.ts` queryMassifTool 接入 DictCache 字段翻译 | ✅ 5 字段枚举→中文标签，非阻塞预加载，tsc 零错误 |
| 18:20 | Handoff 收尾 | handoff §10 补全 + plan 审计表更新 + MCP devlog | ✅ 全链路可追溯 |

### 审计日志回查

```text
# 地块 DTO 变更
query_audit_logs({ targetId: "src/lib/farm-api/massif.ts" })
→ MODIFY: MassifDTO 补全 qrCodeUrl/remark

# 字典文档变更
query_audit_logs({ targetId: "docs/大田精准耕播智能决策系统/knowledge/02-规范/dict-data-api.md" })
→ DOC_UPDATED: 3 个 dictType 汇总

# 工具列变更
query_audit_logs({ targetId: "src/agents/tools/impl/farm-data-tools.ts" })
→ MODIFY: MASSIF_COLUMNS 补全 status/qrCodeUrl/remark

# 字典预加载变更
query_audit_logs({ targetId: "src/app/api/h5/production-plan/land-analysis/route.ts" })
→ MODIFY: DictCache preload 3→5 dictType

# 同步脚本
query_audit_logs({ targetId: "scripts/sync-farm-api-index.ts" })
→ CREATE: 统一同步入口

# H5 字段透传
query_audit_logs({ targetId: "src/app/api/h5/production-plan/land-analysis/route.ts" })
→ MODIFY: plots 补全 qrCodeUrl/remark/status, DictCache preload 3→5

# H5 API 对接文档
query_audit_logs({ targetId: "docs/大田精准耕播智能决策系统/knowledge/02-规范/瑞丰耘H5小程序API对接文档.md" })
→ DOC_UPDATED: perPlotDetails 补全 3 个新字段

# Task 7 字典翻译
query_audit_logs({ targetId: "src/agents/tools/impl/farm-data-tools.ts" })
→ MODIFY: queryMassifTool 接入 DictCache 字段翻译 (MASSIF_DICT_MAP + translateMassifFields)
```

### 待办（下一轮增量）

- [x] `farm-data-tools.ts` `queryMassifTool` 接入 DictCache 字段翻译（type/status/moistureType/landform/fertilityLevel → 中文标签），归于 `farm-agent-land-analysis-dict-cache-plan-v1.md` ✅ 已实施
