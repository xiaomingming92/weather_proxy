# farm-agent-land-analysis-dict-cache-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。重型（Heavyweight）模式——每步强制 check_spec_sync。
>
> **绑定**：Plan: `.qoder/plans/2026-06/24/farm-agent-land-analysis-dict-cache-plan-v1.md` · Spec: `.qoder/specs/farm-agent-land-analysis-dict-cache/` · Handoff: `.qoder/plans/2026-06/24/farm-agent-land-analysis-dict-cache-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**动作**：
1. Specs 三元组待创建：`spec.md` + `tasks.md` + `checklist.md`
2. 调用 `find_related_docs` 检索受影响的规范/接口文档
3. 项目文档更新：plan §3.3 确认 moistureType dictType；§3.4 补 DictCache 接口 boundary
4. Handoff 待创建

**产出**：
- [ ] Specs 三元组就绪
- [ ] 项目文档已更新
- [ ] Handoff 就绪
- [ ] DPS ≥ 85 → 进入 Step 1

### §0.7 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: 修复 land-analysis 端点肥力/土壤类型输出错误，建立 DictCache 字典缓存层替代硬编码枚举映射

逐组业务价值判定:
  Task 0 (前置确认): 不能用 — 仅是前置检查，不产生可感知业务功能
  Task 1 (肥力修复): 不能用 — 独立交付后 fertility 修复但 soilTypeSummary 仍缺失，功能不完整
  Task 2 (DictCache): 不能用 — 模块建好但没有消费者，用户无感知
  Task 3 (接入+soilTypeSummary): 不能用 — 依赖 Task 1+2 的成果
  Task 4 (prompt+后处理): 不能用 — 依赖 Task 3 的确定性计算输出
  Task 5 (文档): 不能用 — 纯文档
  Task 6 (验证): 不能用 — 纯验证

判定结论: 需要 1 轮（1 个原子闭包）

第1轮（原子闭包1）: Task 0-6 — 业务功能: 修复 land-analysis 肥力/土壤输出 + DictCache 字典缓存层
  可独立提交: ✅ Task 1-4 共同构成完整修复
  可独立验证: ✅ tsc + lint + curl E2E 验证
  可独立审计: ✅ 5 个新增 Phase 覆盖全链路
  可独立恢复: ✅ audit logs 可查询恢复
```

---

## Step 1：功能分析与审计阶段定义

**新增 AgentAuditPhase**：

| Phase | 使用场景 | Task |
|-------|---------|------|
| `DICT_CACHE_PRELOAD` | DictCache 启动/懒加载 | Task 2 |
| `DICT_CACHE_REFRESH` | 定时刷新周期 | Task 2 |
| `DICT_CACHE_FALLBACK` | 字典未命中走兜底 | Task 3 |
| `LAND_FERTILITY_CALC` | 肥力面积加权计算 | Task 1/3 |
| `LAND_SOILTYPE_CALC` | 土壤类型面积加权计算 | Task 3 |

---

## Step 2：审计基础设施确认

`agentAudit()` 通道已就绪（项目已有 30+ 审计阶段），新增 Phase 自动支持三通道输出。

---

## Step 3：业务逻辑实现与审计植入

### §3.0 前置守卫

调用 `check_add_route_status` 确认本 add-route 文件有效存在。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 0 | 前置确认 moistureType dictType | — | 调用 dict API 确认 | — | 无 | ⬜ |
| 1 | 肥力计算修复 | `land-analysis/route.ts` | `agentAudit("LAND_FERTILITY_CALC", ...)` | `LAND_FERTILITY_CALC` | Task 0 | ⬜ |
| 2 | DictCache 模块 | `dict-cache.ts` (新建) | `agentAudit("DICT_CACHE_PRELOAD", ...)` / `DICT_CACHE_REFRESH` | `DICT_CACHE_PRELOAD/REFRESH` | 无（可与 Task 1 并行） | ⬜ |
| 3 | route.ts 接入 DictCache + soilTypeSummary | `land-analysis/route.ts` | `agentAudit("LAND_SOILTYPE_CALC", ...)` + `DICT_CACHE_FALLBACK` | `LAND_SOILTYPE_CALC` + `DICT_CACHE_FALLBACK` | Task 1, 2 | ⬜ |
| 4 | LLM prompt 更新 + 后处理 | `land-analysis.ts` + `route.ts` | 无新增（复用已有 audit） | — | Task 3 | ⬜ |
| 5 | .md 文档差异记录 | `地块基本信息管理接口文档.v2.md` | 无（文档变更） | — | Task 4 | ⬜ |
| 6 | 编译验证 + E2E | — | 无 | — | Task 5 | ⬜ |

### 依赖拓扑

```
Task 0 (P0 阻断) ──→ 所有后续 Task
Task 1 ──┐
         ├──→ Task 3 ──→ Task 4 ──→ Task 5 ──→ Task 6
Task 2 ──┘
```

---

## Step 4：审计数据验证 + RAHS 闸门

- [ ] `tsc --noEmit` 通过
- [ ] `npm run lint` 通过
- [ ] `check_phase_symmetry` 通过
- [ ] `check_failure_path` 通过
- [ ] `check_spec_sync` 通过
- [ ] RAHS ≥ 90

---

## Step 5：AI 自动合规检查

- [ ] `check_add_compliance` 全文件扫描通过

---

## Step 8：收敛判断 + Handoff 更新

- [ ] 全部 `[T]` 项通过 + RAHS ≥ 90
- [ ] `check_spec_sync` 四者一致
- [ ] Handoff 更新完成
- [ ] ADD-7 审计回查确认

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/app/api/h5/production-plan/land-analysis/route.ts` | MODIFY | 1/3/4 | COMPONENT | ⬜ |
| `src/lib/farm-api/dict-cache.ts` | CREATE | 2 | COMPONENT | ⬜ |
| `src/lib/farm-api/massif.ts` | MODIFY | 1 | COMPONENT | ⬜ |
| `src/agents/prompts/experts/land-analysis.ts` | MODIFY | 4 | PROMPT | ⬜ |
| `docs/.../地块基本信息管理接口文档.v2.md` | MODIFY | 5 | DOC | ⬜ |
| `src/lib/agent-audit-logger.ts` | MODIFY | 1 | INFRA | ⬜ |
