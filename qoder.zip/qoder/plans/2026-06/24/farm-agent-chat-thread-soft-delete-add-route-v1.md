# farm-agent-chat-thread-soft-delete-add-route-v1

> **绑定**: Plan: `farm-agent-chat-thread-soft-delete-plan-v1.md` · Handoff: `farm-agent-chat-thread-soft-delete-handoff-v1.md`

## Step 0：文档先行

- [x] Specs: 复用 `chat-thread-spec` (`.qoder/specs/chat-thread-spec/`)
- [x] 项目文档: `《聊天实例管理技术文档》.md` 在 Task 3 更新
- [x] Runtime Review 已完成: `.qoder/reviews/farm-agent-chat-thread-soft-delete-runtime-review-v1.md`

## Step 1：审计阶段

无需新增 `AgentAuditPhase`。复用现有：
- `THREAD_DELETE` — 删除线程（chat-persistence-logger.ts 已有）
- `THREAD_LOAD` — 加载线程（已有）

## Step 3：Task 映射表

| # | Task | 文件 | 审计植入 | 依赖 | 状态 |
|---|------|------|---------|------|------|
| 1 | Schema + Migration | `prisma/main.prisma` + migration | — | 无 | ⬜ |
| 2 | Service 软删除改造 | `src/services/chat-persistence.ts` | 复用 THREAD_DELETE/THREAD_LOAD | Task 1 | ⬜ |
| 3 | 文档更新 | `docs/.../《聊天实例管理技术文档》.md` | — | Task 2 | ⬜ |
| 4 | 验证 | tsc + 部署 | — | Task 3 | ⬜ |

## 依赖拓扑

```
Task 1 (Schema) ──→ Task 2 (Service) ──→ Task 3 (Doc) ──→ Task 4 (Verify)
```

## 附录：文件清单

| 文件 | 操作 | Task | targetType |
|------|------|------|-----------|
| `prisma/main.prisma` | MODIFY | 1 | SCHEMA |
| `src/services/chat-persistence.ts` | MODIFY | 2 | SERVICE |
| `docs/.../《聊天实例管理技术文档》.md` | MODIFY | 3 | DOC |
