# farm-agent-devlog-table-split-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。不要写完整实现——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-devlog-table-split-v1
- **启动时间**: 2026-06-25T12:00:00+08:00
- **主导 AI**: Qoder
- **修订时间**: 2026-06-25 v1.1 → v1.2 → v1.3（Task 2/3 完成：migration 手动建表 + MCP 双工具切 DevOperation）
- **前置 Plan**: `add-qoder-integration-plan-v1.md`（L1 词汇预埋已完成，devlog 语义已澄清为 AuditLog 落库）
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/25/farm-agent-devlog-table-split-add-route-v1.md`（待创建）
  - Handoff: `.qoder/plans/2026-06/25/farm-agent-devlog-table-split-handoff-v1.md`（✅ 已创建）
  - Review: `.qoder/reviews/farm-agent-devlog-table-split-review-v1.md`（✅ 已创建，P1-1+P2-1 非阻断）
  - Specs: `.qoder/specs/farm-agent-devlog-table-split/`（待创建）

---

## 一、背景与目标

### 1.1 问题现状

当前 `AuditLog` 表混合承载两类数据：

| 写入来源 | 触发方式 | 数据量级 | 生命周期 |
|---------|---------|:--:|------|
| `agentAudit()` / `AuditCallback` | 每次请求自动写入 | 大（每天数千条） | 可定期清理 |
| `record_dev_operation`（devlog） | 开发操作手动/自动写入 | 小（每天数十条） | 永久保留 |

**P0 — session-init 上下文恢复被污染**：

`query_audit_logs({})` 默认查最近 2 小时，在高频请求期间返回的全是运行时审计日志（`NODE_START`、`AGENT_LLM_CALL` 等），开发操作记录被淹没。session-init 无法恢复开发上下文。

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | devlog 独立存储 | `record_dev_operation` 写入 `DevOperation` 表，不再写入 `AuditLog` |
| P0 | session-init 查新表 | `query_audit_logs` 默认查询 `DevOperation`，恢复开发上下文 |
| P1 | 运行时审计不受影响 | `agentAudit()` / `AuditCallback` 继续写入 `AuditLog`，零改动 |

---

## 二、方案选型

| 方案 | 侵入性 | 效果 | 结论 |
|------|--------|------|:--:|
| A: 拆表（同库新增 DevOperation） | 中（改 Prisma Schema + MCP 工具） | session-init 查询精纯 | ✅ |
| B: 拆库（新 Postgres DB） | 高（新连接串 + 新 Prisma Client） | 过度工程化 | ❌ |
| C: 不改（加 action 过滤查询） | 低（只改 MCP 查询逻辑） | 治标不治本，过滤逻辑脆弱 | ❌ |

**选择方案 A**：同库新增 `DevOperation` 表。

---

## 三、架构设计

```
PostgreSQL (farmer)
  ├── AuditLog         ← agentAudit() / AuditCallback（运行时审计，可清理）
  └── DevOperation     ← record_dev_operation（开发操作，永久保留）
         │
         ▼
  MCP farm-agent-dev-tools
    ├── record_dev_operation → INSERT INTO DevOperation
    └── query_audit_logs     → SELECT FROM DevOperation
```

### DevOperation 表结构

```prisma
model DevOperation {
  id          String   @id @default(cuid())
  userId      String
  user        User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  planKeyword String                        // 关联 Plan（同 check_dps/check_rahs 的定位键），同一 Plan 下所有 devlog 共享
  action      String                        // RULE_MODIFIED / SKILL_MODIFIED / AGENT_CREATED / COMPONENT_CREATED...
  targetType  String                        // RULE / SKILL / AGENT / COMPONENT / PLAN / DOC...
  targetId    String                        // 文件路径
  beforeState Json?                         // 改前状态
  afterState  Json?                         // 改后状态
  reason      String?                       // 操作原因
  createdAt   DateTime @default(now())

  @@index([planKeyword])
}
```

> **字段语义对比**：AuditLog.traceId = 请求级追踪；DevOperation.planKeyword = Plan 级分组。devlog 没有 HTTP 请求上下文，用 planKeyword 做会话恢复键。

### 迁移策略

1. **新建 DevOperation 表**（Prisma migration）
2. **MCP 工具改造**：`record_dev_operation` 写新表，`query_audit_logs` 查新表
3. **旧数据保留**：`AuditLog` 中已有的 devlog 记录不动，不迁移（量小，session-init 查新表后自然过渡）
4. **`AuditLog` 零改动**：`agentAudit()` 和 `AuditCallback` 继续写旧表

---

## 四、实施步骤

```
Task 1: Prisma Schema 新增 DevOperation
       │
       ▼
Task 2: 数据库 migration
       │
       ▼
Task 3: MCP 工具改造 (record_dev_operation + query_audit_logs)
       │
       ▼
Task 4: session-init 引用更新
       │
       ▼
Task 5: 编译 + 回测
```

### Task 1: Prisma Schema ✅

**文件**: `prisma/main.prisma`

- [x] 新增 `DevOperation` model（含 userId + planKeyword + @@index）
- [x] `User` model 新增反向关系 `devOps DevOperation[]`
- [x] 孤儿迁移清理（8 个 ALTER-only 迁移目录删除）
- [x] `squash_baseline` 补全：ProductionPlan(+status/massifIds/CHECK) / SeedCatalog(+grainPrice/varietyCharacteristics) / FarmTask(+completion)
- [x] `npx prisma validate` 通过
- [x] `npx prisma generate` 通过

### Task 2: 数据库 migration ✅

- [x] 迁移文件手动创建：`20260626000000_add_dev_operation/migration.sql`（幂等）
- [x] DevOperation 表已通过 SQL 直接建在数据库中
- [x] 4 个迁移全部通过 `migrate resolve --applied` 标记

### Task 3: MCP 工具改造 ✅

**文件**: `.qoder/scripts/mcp-server.ts`

- [x] `record_dev_operation`：`prisma.auditLog.create` → `prisma.devOperation.create`，新增 `planKeyword` 入参
- [x] `query_audit_logs`：`prisma.auditLog.findMany` → `prisma.devOperation.findMany`，`traceId` → `planKeyword`

### Task 4: session-init 引用更新

**文件**: `.qoder/skills/session-init/SKILL.md`

- [ ] Step 2 的 `query_audit_logs` 调用说明无需改动（MCP 工具已内部切换表，接口不变）

### Task 5: 编译 + 回测

- [ ] `npx prisma generate` 重新生成 Prisma Client
- [ ] `npx tsc --noEmit` 通过
- [ ] 调用 `record_dev_operation` → 确认写入 `DevOperation`
- [ ] 调用 `query_audit_logs` → 确认从 `DevOperation` 读取
- [ ] session-init 执行 → 确认开发上下文恢复正常
- [ ] **P2-1 DPS/RAHS 一致性**：调用 `check_dps` 和 `check_rahs` 确认评分与拆表前一致

---

## 五、验收标准

- [ ] `DevOperation` 表存在且有数据
- [ ] `record_dev_operation` 写入 `DevOperation` 而非 `AuditLog`
- [ ] `query_audit_logs` 查询 `DevOperation` 而非 `AuditLog`
- [ ] `agentAudit()` 继续写入 `AuditLog`（不受影响）
- [ ] `npx tsc --noEmit` 通过

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/25/farm-agent-devlog-table-split-add-route-v1.md`（待创建） |
| Handoff | `.qoder/plans/2026-06/25/farm-agent-devlog-table-split-handoff-v1.md`（待创建） |
| Review | `.qoder/reviews/farm-agent-devlog-table-split-review-v1.md`（待创建） |
| Spec | `.qoder/specs/farm-agent-devlog-table-split/spec.md`（待创建） |
| Tasks | `.qoder/specs/farm-agent-devlog-table-split/tasks.md`（待创建） |
| Checklist | `.qoder/specs/farm-agent-devlog-table-split/checklist.md`（待创建） |
