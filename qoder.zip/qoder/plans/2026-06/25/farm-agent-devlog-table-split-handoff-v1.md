# farm-agent — devlog 表拆分 交接手册

> **父 Plan**: [farm-agent-devlog-table-split-plan-v1.md](./farm-agent-devlog-table-split-plan-v1.md)
> **目标仓库**: `/home/xmm/ai/farm-agent`
> **轮次**: 单轮

---

## 原子事务目标

将 `record_dev_operation` 写入和 `query_audit_logs` 查询从 `AuditLog` 表独立到 `DevOperation` 表，解决 session-init 上下文恢复被运行时审计日志污染的问题。

---

## 你要改的文件

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `prisma/main.prisma` | 修改 | 新增 DevOperation model + User.devOps 反向关系 |
| `prisma/migrations/20260601000000_squash_baseline/` | 修改 | 幂等化 + 列补全（ProductionPlan/SeedCatalog/FarmTask） |
| `prisma/migrations/20260626000000_add_dev_operation/` | 新建 | DevOperation 表迁移（幂等） |
| `.qoder/scripts/mcp-server.ts` | 修改 | record_dev_operation / query_audit_logs 切到 DevOperation |

---

## 核心设计

```
PostgreSQL
  ├── AuditLog      ← agentAudit() / AuditCallback（运行时）
  └── DevOperation  ← record_dev_operation（开发期）

MCP 工具:
  record_dev_operation → prisma.devOperation.create
  query_audit_logs     → prisma.devOperation.findMany
```

---

## 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] 4 迁移全部幂等（IF NOT EXISTS / DO 块）
- [x] `prisma generate --schema=prisma` 通过
- [ ] 重启 MCP Server 后 devlog 写入 DevOperation
- [ ] session-init 恢复正常

---

## ADD-7 恢复关键词

```text
query_audit_logs({ planKeyword: "farm-agent-devlog-table-split" })
→ 返回全部本轮 ADD-7 审计记录
```
