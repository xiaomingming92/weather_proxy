# add-qoder-integration-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节。
>
> **模式**：重型（Heavyweight）——适用。
>
> **绑定**：Plan: `add-qoder-integration-plan-v1.md` · Spec: `.qoder/specs/add-qoder-integration/spec.md` · Tasks: `.qoder/specs/add-qoder-integration/tasks.md` · Handoff: `add-qoder-integration-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**目的**：确认 Plan + Review + Specs 三元组就绪，Review 结论已回流。

**输入**：
- Plan: `add-qoder-integration-plan-v1.md`
- Review: `add-qoder-integration-review-v1.md`

**动作**：
1. ✅ Plan 已生成（三轮拆分，L1-L3）
2. ✅ Review 已生成（P0-1 词汇覆盖不足 + P0-2 验收闭环缺 devlog）
3. ✅ 0.6.5 回流完成：Plan §3.2 已从 9 条扩展到 6 类 ~45 条分类词汇表
4. ⬜ Specs 三元组待生成：`spec.md` + `tasks.md` + `checklist.md`
5. ⬜ 本次为纯 Qoder 配置改造（.qoder/rules、.qoder/skills、.qoder/agents），不涉及 `docs/` 项目文档变更——需在产出中声明"无需更新项目文档"

**产出**：
- [ ] 验证并更新项目状态：Specs 三元组路径确认
- [ ] 验证并更新项目状态：项目文档已更新（或无需更新声明已记录）
- [ ] 验证并更新项目状态：Handoff 就绪

### §0.8 DPS 闸门（上游文档质量校验）

调用 `check_dps({ planKeyword: "add-qoder-integration" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |
| 70–84 | 🟡 | 回退补齐短板 |
| < 70 | 🔴 | 回退细化 Plan |

- [ ] DPS 已通过（≥ 85），可进入 Step 1

### 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: 将 ADD 范式词汇、操作惯例、门禁编排预埋到 Qoder 工作流中，
         使 LLM 对 ADD 术语产生本能响应，零额外 prompt。

Task Groups:
  Group 1（第1轮 L1 词汇预埋）: project_rules.md + AGENTS.md
  Group 2（第2轮 L2 操作惯性）: session-init/SKILL.md
  Group 3（第3轮 L3 Agent 编排）: add-orchestrator.md

逐组业务价值判定:
  Group 1 (L1 词汇预埋):
    独立交付后 → LLM 能本能响应 devlog/handoff/DPS 等术语 ✅ 能用
    独立验证 → 检查 project_rules.md 六类词汇表完整性 ✅ 可验证
    独立审计 → 每个文件有 record_dev_operation ✅ 可审计
    结论: 可作为独立轮次

  Group 2 (L2 操作惯性):
    独立交付后 → session-init 自动注入 index.md + ADD 状态 ✅ 能用
    但有依赖 → 词汇映射表（Group 1）是操作惯性的语义基础
    结论: 依赖 Group 1，但可独立交付业务价值，可作为独立轮次

  Group 3 (L3 Agent 编排):
    独立交付后 → 门禁在 Step 边界自动触发 ✅ 能用
    但有依赖 → 词汇（Group 1）+ 上下文注入（Group 2）是编排的基础
    结论: 依赖 Group 1+2，可独立交付，可作为独立轮次

判定结论: 需要 3 轮（3 个原子闭包）

第1轮（原子闭包1）: Group 1 — ADD 词汇本能响应
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
第2轮（原子闭包2）: Group 2 — ADD 上下文自动注入
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
第3轮（原子闭包3）: Group 3 — ADD 门禁自动编排
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更的审计阶段。本次为 Qoder 配置文件改造，不涉及 `src/` 代码，但需通过 `record_dev_operation` 记录每次文件变更。

**动作**：
1. 本次不扩展 `AgentAuditPhase`（不改 `src/lib/agent-audit-logger.ts`）
2. 使用 `record_dev_operation` MCP 工具记录文件变更（ADD-7）
3. 在 `project_rules.md` 本身也需记录变更

**产出**：
- [ ] 验证并更新项目状态：审计策略已确认（纯 MCP record_dev_operation，无需 AgentAuditPhase 扩展）

---

## Step 2：审计基础设施确认

**目的**：确认 `record_dev_operation` MCP 工具可用。

**动作**：
1. 确认 farm-agent-dev-tools MCP Server 已连接
2. 确认 `record_dev_operation` 和 `query_audit_logs` 可用

**产出**：
- [ ] 验证并更新项目状态：MCP 工具可用性已确认

---

## Step 3：业务逻辑实现与审计植入

**目的**：按三轮依赖拓扑，逐轮实施文件改动 + MCP 审计记录。

### §3.0 前置守卫

调用 `check_add_route_status({ planKeyword: "add-qoder-integration" })` 确认 add-route 有效存在。

### Task 映射表

| # | Task | 文件 | 操作 | 依赖 | 状态 |
|---|------|------|------|------|:--:|
| 1 | L1 词汇映射表写入 | `.qoder/rules/project_rules.md` | MODIFY | 无 | ⬜ |
| 2 | L1 词汇速查表写入 | `AGENTS.md` | MODIFY | Task 1 | ⬜ |
| 3 | L2 session-init 增强 | `.qoder/skills/session-init/SKILL.md` | MODIFY | Task 1,2 | ⬜ |
| 4 | L3 编排 Agent 创建 | `.qoder/agents/add-orchestrator.md` | CREATE | Task 1,2,3 | ⬜ |

### 依赖拓扑

```
Task 1 (project_rules.md) ──┐
                             │ 可并行
Task 2 (AGENTS.md) ─────────┘
             │
             ▼
Task 3 (session-init SKILL) ── 依赖 L1 词汇已就位
             │
             ▼
Task 4 (add-orchestrator) ── 依赖 L1+L2 已就位
```

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计
3. 更新 tasks.md 逐子项勾选

**产出**：
- [ ] 验证并更新项目状态：全部 Task 完成，tasks.md 已逐项勾选
- [ ] 验证并更新项目状态：每个文件有 record_dev_operation 记录

---

## Step 3.5：实现审查

**目的**：验证 Qoder 配置文件语法正确、格式一致。

**动作**：
1. 验证 project_rules.md Markdown 表格语法正确
2. 验证 AGENTS.md 表格语法正确
3. 验证 session-init SKILL YAML frontmatter + Markdown 正确
4. 验证 add-orchestrator.md YAML frontmatter + Markdown 正确

**产出**：
- [ ] 验证并更新项目状态：4 个文件语法验证通过
- [ ] 验证并更新项目状态：review-implementation.md 已生成
- [ ] 验证并更新项目状态：review-runtime.md 已生成

---

## Step 4：审计数据验证

**目的**：确认所有 record_dev_operation 记录已落库。

**动作**：
1. 调用 `query_audit_logs({ keyword: "add-qoder" })` 确认全部审计记录
2. 检查每个文件的 beforeState/afterState 记录完整性

**产出**：
- [ ] 所有 record_dev_operation 记录已落库
- [ ] query_audit_logs 回查确认

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "add-qoder-integration" })`。

- [ ] RAHS 已通过（≥ 90），可进入 Step 5

---

## Step 5：AI 自动合规检查

**目的**：确认所有文件符合 Qoder 规范。

**动作**：
1. 验证 Skills 符合 create-skill 模板格式
2. 验证 Agents 符合 create-subagent 模板格式
3. 验证 Rules 符合 project_rules.md 已有格式

**产出**：
- [ ] 验证并更新项目状态：合规检查通过

---

## Step 8：收敛判断 + Handoff 更新

**目的**：三轮全部完成后，确认功能收敛，写 devlog日志(走mcp) + 更新 handoff。

**动作**：
1. **收敛判断**：三轮全部完成 + query_audit_logs 确认无遗漏
2. **RAHS 最终核定**：调用 `check_rahs({ planKeyword: "add-qoder-integration" })`
3. **写 devlog日志(走mcp)** → `.qoder/plans/2026-06/25/` 下记录本轮实施
4. **更新 handoff**：记录三轮实际产出与偏离
5. **ADD-7 回查**：`query_audit_logs` 确认全部记录落库

**产出**：
- [ ] 验证并更新项目状态：收敛判定完成
- [ ] 验证并更新项目状态：devlog 已写入
- [ ] 验证并更新项目状态：handoff 已更新
- [ ] 验证并更新项目状态：ADD-7 审计回查确认

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|:--:|
| `.qoder/rules/project_rules.md` | MODIFY | Task 1 | RULE | ⬜ |
| `AGENTS.md` | MODIFY | Task 2 | RULE | ⬜ |
| `.qoder/skills/session-init/SKILL.md` | MODIFY | Task 3 | SKILL | ⬜ |
| `.qoder/agents/add-orchestrator.md` | CREATE | Task 4 | AGENT | ⬜ |
