# farm-agent-api-change-auto-adapt-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。不要写完整 TS 类型定义和 WHEN-THEN 场景——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-api-change-auto-adapt-v1
- **启动时间**: 2026-06-25T12:00:00+08:00
- **修订时间**: 2026-06-25（初版）
- **主导 AI**: Qoder
- **前置 Plan**: 无（独立基础设施改造，不阻塞其他 Plan）
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/25/farm-agent-api-change-auto-adapt-add-route-v1.md`（待创建）
  - Handoff: `.qoder/plans/2026-06/25/farm-agent-api-change-auto-adapt-handoff-v1.md`（待创建）
  - Review: `.qoder/reviews/farm-agent-api-change-auto-adapt-review-v1.md`（待创建）
  - Specs: `.qoder/specs/farm-agent-api-change-auto-adapt/`（待创建）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/caijuehub/caijue.toml` | CONFIG | CONFIG_MODIFIED | 无 Farm-Server API 依赖映射裁决条目 | 新增 `farm-server-api-dependency-map` contract 类型条目 | 待实施 |
| `src/lib/farm-api/dependency-map.ts` (新建) | COMPONENT | COMPONENT_CREATED | 不存在，API→代码依赖关系无显式声明 | 集中声明所有 Farm-Server API 路径到 farm-agent 代码文件的映射 | 待实施 |
| `scripts/sync-farm-api-index.ts` | SCRIPT | SCRIPT_MODIFIED | 无脑覆盖生成文档，不检测变更 | 增加 OpenAPI 快照保存、diff 检测、变更报告生成 | 待实施 |
| `scripts/crontab.txt` | CONFIG | CONFIG_MODIFIED | 仅 sync 脚本，无后续处理 | sync 后输出变更报告，有变更时写标记文件供 ADD 流程消费 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

**P0 — Farm-Server API 变更无法自动传导到 farm-agent 代码**：

当前 `docs:sync-farm-service-api` 脚本每天 9:00 定时拉取 Farm-Server OpenAPI spec → 生成 Markdown 文档 → 结束。文档生成后没有机制告知"API 变了什么"，更无法自动改造 farm-agent 中依赖这些 API 的代码。

后果：Farm-Server 新增字段/接口后，farm-agent 的 TypeScript 类型定义（如 `MassifDTO`）落后于实际响应，LLM prompt 中的字段说明过时，DictCache 的 dictType 列表缺失新类型——这些问题全靠人工发现和手动修复。

**P1 — API→代码依赖关系散落在人脑和记忆中**：

Farm-Server 的 `/farm/massif/getMassif` 变了 → 哪些 farm-agent 文件受影响？目前依赖 AI 记忆和经验判断，没有声明式的依赖映射表。

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | sync 脚本具备变更检测能力 | 拉取新 spec 后，与上次快照 diff，输出结构化变更报告（新增/删除/修改的端点、字段、参数） |
| P0 | 建立 API→代码依赖映射 | `dependency-map.ts` 覆盖当前所有已对接的 Farm-Server API 端点，映射到具体文件和影响部位 |
| P1 | sync 后自动生成变更影响报告 | 变更报告 × 依赖映射 → 输出「受影响文件清单 + 影响部位」，为后续自动改造提供输入 |
| P2 | 为后续 ADD 自动改造留钩子 | 变更报告 + 影响清单写入约定路径，供 ADD 工作流或 AI 助手消费 |

> **非目标（本次不做的）**：
> - 自动修改代码（那是 ADD 流程的职责，sync 脚本只负责"发现 + 定位"）
> - 实时监听 Farm-Server 变更（保持 cron 定时拉取模式）

---

## 二、方案选型

### 2.1 变更检测方案对比

| 方案 | 精确度 | 复杂度 | 额外依赖 | 结论 |
|------|--------|--------|---------|------|
| A: 生成 md 后 git diff | 低（只知文件变了，不知具体哪个字段） | 最低 | git | ❌ 粒度太粗，无法定位到字段级变更 |
| B: 保存 OpenAPI JSON 快照，结构化 diff | 高（字段级：新增/删除/类型变更） | 中 | 无（纯 TS 实现） | ✅ 推荐 |
| C: 引入 OpenAPI diff 工具（如 openapi-diff） | 最高 | 高 | npm 包 | ❌ 过度工程化 |

### 2.2 选型理由

**选择方案 B**：保存 OpenAPI JSON 快照 + 结构化 diff。

- Farm-Server 返回的是标准 OpenAPI 3.x JSON，结构稳定可解析
- 字段级 diff 逻辑简单：对比 `paths` 下的 method→path 条目，再对比 `parameters`/`requestBody`/`responses` 的 schema 字段
- 不引入新依赖，纯 TypeScript 实现，与现有 `sync-farm-api-index.ts` 同语言栈
- 粒度足够下游消费（知道"哪个端点的哪个字段变了"）

### 2.3 依赖映射存储方案

| 方案 | 可维护性 | AI 可消费性 | 结论 |
|------|---------|-----------|------|
| A: 纯 TS 文件 (`dependency-map.ts`) | 高（类型安全 + IDE 补全） | 高（静态 import） | ✅ 推荐 |
| B: 放 caijue.toml | 中（TOML 无类型检查） | 高（统一治理入口） | ❌ TOML 不适合表达复杂嵌套映射 |

**选择方案 A + caijue 条目做索引**：

- `src/lib/farm-api/dependency-map.ts` 作为映射的真值源（类型安全、可测试）
- `caijue.toml` 新增 contract 条目 `farm-server-api-dependency-map`，指向该文件，保持治理可见性
- 两者不重复内容——caijue 只管"存在性声明"，dependency-map.ts 管具体映射数据

---

## 三、架构设计

### 3.1 整体流程

```
cron 每天 9:00
     │
     ▼
sync-farm-api-index.ts (增强)
     │
     ├─ ① 拉取 OpenAPI JSON
     │     │
     │     ▼
     ├─ ② 对比上次快照 (data/snapshots/openapi-{date}.json)
     │     │
     │     ├─ 无变更 → 结束
     │     │
     │     ▼ 有变更
     ├─ ③ 生成结构化变更报告 → data/snapshots/api-changes-{date}.json
     │     │
     │     ▼
     ├─ ④ 查询 dependency-map.ts → 输出影响清单
     │     │
     │     ▼
     ├─ ⑤ 写入变更标记文件 → data/snapshots/.pending-api-changes
     │     │
     │     ▼
     └─ ⑥ (未来) ADD 工作流消费标记文件 → 自动创建 Plan/Spec → 改代码

                    ┌──────────────────────────┐
                    │ caijue.toml               │
                    │ [[caijue]]                │
                    │ id = "farm-server-api-    │
                    │   dependency-map"         │
                    │ type = "contract"         │
                    │ status = "active"         │
                    │ implementation =          │
                    │   "src/lib/farm-api/      │
                    │    dependency-map.ts"     │
                    └──────────┬───────────────┘
                               │ 指向
                               ▼
                    ┌──────────────────────────┐
                    │ dependency-map.ts         │
                    │                          │
                    │ DEPENDENCY_MAP = {       │
                    │   "/farm/massif/get": {  │
                    │     files: [...],        │
                    │     affects: "MassifDTO" │
                    │   },                     │
                    │   ...                    │
                    │ }                        │
                    └──────────────────────────┘
```

### 3.2 数据流与文件约定

| 产物 | 路径 | 说明 |
|------|------|------|
| OpenAPI 快照 | `data/snapshots/openapi-{YYYY-MM-DD}.json` | 每次 sync 保存的完整 OpenAPI JSON，用于下次 diff |
| 变更报告 | `data/snapshots/api-changes-{YYYY-MM-DD}.json` | 结构化变更清单（仅在有变更时生成） |
| 变更标记 | `data/snapshots/.pending-api-changes` | 空标记文件，存在 = 有待处理的 API 变更。ADD 流程或 AI 会话启动时检查 |

### 3.3 变更报告结构

```typescript
interface ApiChangeReport {
  syncDate: string              // "2026-06-25"
  previousSnapshot: string      // "data/snapshots/openapi-2026-06-24.json"
  changes: EndpointChange[]
}

type EndpointChange =
  | { kind: "endpoint_added"; method: string; path: string; summary: string }
  | { kind: "endpoint_removed"; method: string; path: string; summary: string }
  | { kind: "field_changed"; method: string; path: string;
      location: "param" | "requestBody" | "response";
      changes: FieldDiff[] }

interface FieldDiff {
  field: string                  // 字段路径，如 "data.qrCodeUrl"
  change: "added" | "removed" | "type_changed"
  oldType?: string
  newType?: string
}
```

### 3.4 依赖映射结构

```typescript
// src/lib/farm-api/dependency-map.ts

interface DependencyEntry {
  /** 受影响文件列表（相对于项目根目录） */
  files: string[]
  /** 具体影响部位描述（供 AI 和人类阅读理解） */
  affects: string
}

/** Farm-Server API 路径 → farm-agent 代码依赖映射 */
const DEPENDENCY_MAP: Record<string, DependencyEntry> = {
  "/farm/massif/getMassif": {
    files: ["src/lib/farm-api/massif.ts"],
    affects: "MassifDTO 接口字段（响应体 data 对象）",
  },
  "/farm/massif/page": {
    files: [
      "src/lib/farm-api/massif.ts",
      "src/app/api/h5/production-plan/land-analysis/route.ts",
    ],
    affects: "分页查询参数 + MassifDTO 字段",
  },
  "/farm/massif/options": {
    files: ["src/lib/farm-api/massif.ts"],
    affects: "MassifDTO 字段",
  },
  "/system/dict-data/type": {
    files: ["src/lib/farm-api/dict-cache.ts"],
    affects: "dictType 列表 + 静态兜底映射 registerStatic",
  },
  "/farm/weather-data/page": {
    files: ["src/app/api/h5/production-plan/land-analysis/route.ts"],
    affects: "天气数据查询参数与响应结构",
  },
  "/farm/moisture-data/page": {
    files: ["src/app/api/h5/production-plan/land-analysis/route.ts"],
    affects: "土壤水分数据查询参数与响应结构",
  },
}
```

### 3.5 裁决层条目

在 `caijue.toml` 末尾追加：

```toml
[[caijue]]
id = "farm-server-api-dependency-map"
type = "contract"
description = "Farm-Server API → farm-agent 代码依赖映射：声明每个 Farm-Server 端点变更时受影响的 farm-agent 文件及影响部位。sync 脚本 + ADD 流程消费此映射定位改造范围"
status = "active"
governance = [
  { doc = "plans/farm-agent-api-change-auto-adapt-plan-v1.md", section = "三", key_point = "依赖映射结构 + 消费方式" },
]
implementation = "src/lib/farm-api/dependency-map.ts"
inputs = []
outputs = ["DEPENDENCY_MAP: Record<apiPath, { files, affects }>"]
```

---

## 四、实施步骤 + 依赖图

```
Task 0 (caijue.toml 裁决条目) ── 无依赖，可先行
Task 1 (dependency-map.ts)    ── 依赖 Task 0 (治理声明先于实现)
                                    │
                                    ▼
Task 2 (sync 脚本增强: diff 引擎) ── 依赖 Task 1 (diff 完后查 dependency-map 生成影响清单)
                                    │
                                    ▼
Task 3 (sync 脚本增强: 快照管理 + 变更报告输出)
                                    │
                                    ▼
Task 4 (变更标记文件 + cron 适配)
                                    │
                                    ▼
Task 5 (验证: 手动跑 sync 确认全链路)
```

### Task 0: caijue.toml 新增裁决条目

**改动文件**: `src/caijuehub/caijue.toml`

- [ ] 在文件末尾追加 `[[caijue]]` 条目 `farm-server-api-dependency-map`
- [ ] 类型 `contract`，状态 `active`
- [ ] 指向实现文件 `src/lib/farm-api/dependency-map.ts`

### Task 1: 创建 dependency-map.ts

**新建文件**: `src/lib/farm-api/dependency-map.ts`

- [ ] 定义 `DependencyEntry` 接口和 `DEPENDENCY_MAP` 常量
- [ ] 覆盖当前所有已对接的 Farm-Server 端点（按 §3.4 清单）
- [ ] 导出 `getAffectedFiles(apiPath: string): DependencyEntry | undefined` 查询函数
- [ ] 验证标准：每个映射条目中的 `files` 路径确实存在

### Task 2: sync 脚本增加 diff 引擎

**改动文件**: `scripts/sync-farm-api-index.ts`

- [ ] 在拉取 OpenAPI JSON 后，将原始 JSON 保存到 `data/snapshots/openapi-{today}.json`
- [ ] 查找最近一次快照（非今天的），若存在则执行结构化 diff
- [ ] diff 逻辑：对比 `paths` 键 → 对比每个 method+path 的 parameters/requestBody/responses schema
- [ ] 输出变更摘要到 stdout（新增 X 个端点 / 删除 Y 个端点 / Z 个端点字段变更）
- [ ] 验证标准：模拟两次不同版本的 spec，确认 diff 结果正确

### Task 3: sync 脚本增加变更报告 + 影响清单输出

**改动文件**: `scripts/sync-farm-api-index.ts`

- [ ] 将变更报告写入 `data/snapshots/api-changes-{today}.json`（结构见 §3.3）
- [ ] 利用 dependency-map.ts 查询每个变更端点 → 汇总受影响文件清单
- [ ] 输出影响清单到 stdout（含文件路径 + 影响部位描述）
- [ ] 清理旧快照（保留最近 7 天）
- [ ] 验证标准：变更报告 JSON 格式正确，影响清单覆盖所有受影响文件

### Task 4: 变更标记文件 + cron 适配

**改动文件**: `scripts/sync-farm-api-index.ts`, `scripts/crontab.txt`（仅 review，不修改 cron 注册逻辑）

- [ ] 有变更时，写入 `data/snapshots/.pending-api-changes` 空标记文件（内容为变更日期）
- [ ] 无变更时，删除 `.pending-api-changes`（若存在）
- [ ] 验证标准：手动跑 sync 后检查标记文件是否正确创建/删除

### Task 5: 验证 + 清理

- [ ] `npx tsc --noEmit` 通过（sync 脚本是 tsx 直接运行，但类型检查不能崩）
- [ ] 手动执行 `npm run docs:sync-farm-service-api`，确认:
  - 快照保存正常
  - diff 输出合理
  - 变更报告 JSON 生成
  - 标记文件正确
- [ ] 确认 `data/snapshots/` 目录已加入 `.gitignore`（快照不应入版本控制）

---

## 五、验收标准

- [ ] `caijue.toml` 中存在 `farm-server-api-dependency-map` 条目，指向 `dependency-map.ts`
- [ ] `dependency-map.ts` 覆盖所有当前对接的 Farm-Server 端点
- [ ] `npm run docs:sync-farm-service-api` 执行后：
  - 首次运行：生成 `openapi-{date}.json` 快照，无 diff（无历史对比基准）
  - 第二次运行（API 无变化）：输出 "无变更"，不生成变更报告
  - 模拟 API 有变化后运行：输出结构化变更报告 + 受影响文件清单
- [ ] `.pending-api-changes` 标记文件在有变更时存在，无变更时不存在
- [ ] 旧快照自动清理（保留 7 天）

---

## 六、后续扩展（本次不实施）

| 扩展方向 | 说明 | 依赖本次的 |
|---------|------|----------|
| ADD 自动消费标记文件 | AI 会话启动时检查 `.pending-api-changes`，自动创建 ADD Plan | Task 4 标记文件 |
| 自动代码改造 | 根据变更报告 + dependency-map 自动修改 DTO/类型定义 | Task 2 diff + Task 1 依赖映射 |
| 更多 Farm-Server 端点对接 | 新增端点时同步追加 dependency-map.ts 条目 | Task 1 dependency-map 结构 |
| agrisynapse 同步联动 | 将依赖映射扩展到 agrisynapse 项目 | Task 1 跨项目路径支持 |

---

## 七、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/25/farm-agent-api-change-auto-adapt-add-route-v1.md`（待创建） |
| Handoff | `.qoder/plans/2026-06/25/farm-agent-api-change-auto-adapt-handoff-v1.md`（待创建） |
| Review | `.qoder/reviews/farm-agent-api-change-auto-adapt-review-v1.md`（待创建） |
| Spec | `.qoder/specs/farm-agent-api-change-auto-adapt/spec.md`（待创建） |
| Tasks | `.qoder/specs/farm-agent-api-change-auto-adapt/tasks.md`（待创建） |
| Checklist | `.qoder/specs/farm-agent-api-change-auto-adapt/checklist.md`（待创建） |
