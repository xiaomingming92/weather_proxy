# farm-agent-wecom-doc-notify-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。不要写完整 Shell 脚本实现和 WHEN-THEN 场景——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-wecom-doc-notify-v1
- **启动时间**: 2026-06-25T12:00:00+08:00
- **修订时间**: 2026-06-25（v1.1 增量：多平台 Webhook 支持 — 企业微信 + 钉钉 + 飞书，环境变量改为 `NOTIFY_WEBHOOK_URLS` 逗号分隔，URL 域名自动识别平台）
- **主导 AI**: Qoder
- **前置依赖**:
  - Atom RSS 订阅源已上线（`GET /api/h5/docs?format=rss`，2026-06-24）
  - 企业微信群机器人 Webhook URL 已获取
  - 钉钉 / 飞书群机器人 Webhook URL 可选
  - GitLab CI 流水线 `prepare → build → deploy → notify → verify` 五阶段正常运行
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/25/farm-agent-wecom-doc-notify-add-route-v1.md`
  - Spec: `.qoder/specs/farm-agent-wecom-doc-notify/spec.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `scripts/notify-doc-update.sh` | COMPONENT | COMPONENT_MODIFIED | 单一 WECOM_WEBHOOK_URL，仅企业微信 | 支持 NOTIFY_WEBHOOK_URLS（逗号分隔），URL 域名自动识别平台（企业微信/钉钉/飞书），各平台独立消息格式，任一失败不阻塞其余 | 待实施 |
| `.gitlab-ci.yml` | COMPONENT | COMPONENT_MODIFIED | deploy 阶段内嵌通知 | 独立 notify 阶段（deploy → notify → verify），阶段解耦 | ✅ 已实施（v1.0） |
| `.env.production` | CONFIG | CONFIG_MODIFIED | 含 WECOM_WEBHOOK_URL | 改为 NOTIFY_WEBHOOK_URLS（逗号分隔，支持多平台多群） | 待实施 |
| `.env.example` | CONFIG | CONFIG_MODIFIED | 含 WECOM_WEBHOOK_URL 模板 | 改为 NOTIFY_WEBHOOK_URLS 模板 + 平台说明注释 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

**P1 — API 文档变更无自动通知**：
- `docs/大田精准耕播智能决策系统/knowledge/02-规范/瑞丰耘H5小程序API对接文档.md` 已内置 Atom RSS 订阅源（`GET /api/h5/docs?format=rss`），支持 Feedly / 飞书机器人等客户端订阅
- 但企业微信是团队日常协作工具，RSS 的 Pull 模式与企业微信 Webhook 的 Push 模式存在协议断层
- 目前每次文档版本升级（如 v4.1→v4.2）后，对接方（瑞丰耘小程序后台）无法自动感知变更，需人工通知

**P2 — RSS 订阅方式覆盖面不足**：
- Feedly 订阅需要对接方主动配置，并非所有团队成员都会使用 RSS 阅读器
- 企业微信群聊是信息触达率最高的渠道，但缺少自动化桥接

**P2 — 单一平台局限**（v1.1 增量）：
- v1.0 仅支持企业微信，但团队可能同时使用钉钉、飞书等协作工具
- 不同对接方使用不同 IM 平台，需支持多群多平台同时推送
- 消息格式需适配各平台差异（如企业微信支持 `<font color>`，钉钉不支持）

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P1 | 文档变更自动推送到企业微信群 | Git Push 到 main 且 API 文档变更时，群内收到 Markdown 格式通知（含版本号、日期、变更摘要、文档链接） |
| P1 | 通知脚本可复用 | `scripts/notify-doc-update.sh` 独立可执行，不绑定 CI 环境，支持手动触发 |
| P1 | 多平台多群并发推送（v1.1） | `NOTIFY_WEBHOOK_URLS` 逗号分隔多个 URL，URL 域名自动识别平台，并发推送 |
| P2 | 不阻塞部署流程 | 任一 Webhook 不可用时通知失败不影响 CI 流水线通过（降级为 warn 日志） |

---

## 二、方案选型

### 2.1 通知触发方式对比

| 方案 | 触发时机 | 延迟 | 覆盖范围 | 复杂度 | 结论 |
|------|----------|------|---------|--------|------|
| A: GitLab CI 阶段 | Git Push → main | 实时（CI 执行期间） | 所有 Git 驱动的文档变更 | 低 | ✅ 推荐 |
| B: Cron 轮询 RSS | 定时（如每小时） | ≤1h | 含非 Git 来源的变更 | 中 | ❌ 过度工程化 |
| C: 文档端点内嵌推送 | 每次 HTTP 请求 | 实时 | 仅触发于有人访问时 | 高（副作用耦合） | ❌ 架构污染 |
| D: Git Hook（pre-receive） | Git Push | 实时 | 所有 Git 驱动的变更 | 低 | ❌ 需 GitLab 服务端配置，不可控 |

### 2.2 选型理由

**选择方案 A（GitLab CI）**：

- 文档变更的唯一入口是 Git Push（文档纳入版本控制，无服务器端直接修改路径），CI 天然覆盖所有变更场景
- 现有 `.gitlab-ci.yml` 已包含 `prepare → build → deploy → verify` 四阶段，在 `deploy` 末尾追加通知步骤零侵入
- 企业微信 Webhook 本质是 HTTP POST，CI 环境中 `curl` 即可完成，无需额外依赖
- 方案 B（Cron 轮询）引入状态管理（需持久化"上次推送的 entry ID"），且 1 小时缓存导致通知延迟不可控
- 方案 C 将推送耦合到文档端点，违反单一职责
- 方案 D 需要 GitLab Server 端配置 pre-receive hook，超出项目可控范围

### 2.3 通知内容方案

**选择企业微信 Markdown 消息类型**（`msgtype: "markdown"`）：

- 支持字体颜色（版本号高亮）、超链接（文档 URL）、引用块（变更摘要）
- 相比 `text` 类型可读性更好，相比 `news` 类型更简洁（无需封面图）

### 2.4 多平台消息格式适配（v1.1）

| 平台 | URL 特征 | 消息类型 | 格式降级策略 |
|------|----------|---------|-------------|
| 企业微信 | `qyapi.weixin.qq.com` | markdown | 原生支持 `<font color="info">` 版本号高亮 |
| 钉钉 | `oapi.dingtalk.com` | markdown | 不支持 `<font>` → 版本号改为 `**v4.2**` 加粗 |
| 飞书 | `open.feishu.cn` | interactive card | 富文本卡片，标题+字段+链接按钮。若 URL 非标准卡片 Webhook 则降级为 text |

**选型理由**：
- 脚本内按 URL 域名做 `case` 分支，无需外部依赖
- 各平台独立构造 payload 函数，互不耦合
- 任一平台失败不影响其余平台推送（`for url in urls; do send "$url" || true; done`）

---

## 三、架构设计

### 3.1 模块关系

```
┌──────────────────────────────────────────────────────────────┐
│                    GitLab CI Pipeline                         │
│                                                              │
│  prepare → build → deploy ───→ notify ───→ verify            │
│                                  │                           │
│                                  ▼                           │
│                      ┌────────────────────┐                  │
│                      │ notify-doc-update  │                  │
│                      │       .sh          │                  │
│                      │                    │                  │
│                      │ 1. git diff       │                  │
│                      │ 2. grep 版本/日期  │                  │
│                      │ 3. for each URL:  │                  │
│                      │    ├─ qyapi... → 企业微信 markdown    │
│                      │    ├─ oapi...  → 钉钉 markdown        │
│                      │    └─ open...  → 飞书 card/text       │
│                      └────────┬───────────┘                  │
│                               │                              │
└───────────────────────────────┼──────────────────────────────┘
                                │ curl POST (并发)
                    ┌───────────┼───────────┐
                    ▼           ▼           ▼
               企业微信群   钉钉群     飞书群
```

环境变量:
  NOTIFY_WEBHOOK_URLS   → 逗号分隔的 Webhook URL 列表（如 qyapi.xxx,oapi.xxx）
  WECOM_WEBHOOK_URL     → [向后兼容] 单企业微信 URL，NOTIFY_WEBHOOK_URLS 未设时 fallback
  DOCS_BASE_URL         → 文档站点根 URL

### 3.2 脚本契约

```
scripts/notify-doc-update.sh

输入:
  - 环境变量 NOTIFY_WEBHOOK_URLS（逗号分隔的 Webhook URL 列表，优先使用）
  - 环境变量 WECOM_WEBHOOK_URL（向后兼容，NOTIFY_WEBHOOK_URLS 未设时 fallback）
  - 参数 $1: before SHA（git diff 起点，CI 中为 $CI_COMMIT_BEFORE_SHA）
  - 参数 $2: after SHA（git diff 终点，CI 中为 $CI_COMMIT_SHA）

平台路由规则:
  qyapi.weixin.qq.com    → send_wecom()   → markdown（支持 <font color>）
  oapi.dingtalk.com       → send_dingtalk()→ markdown（版本号降级为 **v4.2** 加粗）
  open.feishu.cn          → send_feishu()  → interactive / text
  其他                      → warn 跳过

输出:
  - 成功: 各平台群内收到通知；stdout 输出 "[wecom] ✓" / "[dingtalk] ✓" / "[feishu] ✓"
  - 跳过: 所有 URL 未配置 或 文档未变更 → exit 0
  - 部分失败: 失败平台输出 warn，其余正常推送，exit 0
```

### 3.3 文档头解析规则

依赖 `瑞丰耘H5小程序API对接文档.md` 头部格式（现状已验证一致）：

```markdown
# 瑞丰耘 H5 / 小程序 API 对接文档（v4.2 — 计划状态化 + 自动完成）

> 版本: v4.2 | 更新: 2026-06-24 | 对接方: 瑞丰耘小程序后台
>
> **v4.1 → v4.2 变更**：计划新增 status 字段...
```

| 提取项 | 正则 | 示例 |
|--------|------|------|
| 版本号 | `版本[：:]\s*v?[\d.]+` | `v4.2` |
| 更新日期 | `更新[：:]\s*\d{4}-\d{2}-\d{2}` | `2026-06-24` |
| 最新变更摘要 | `> \*\*v?[\d.]+\s*→\s*v?[\d.]+\s*变更\*\*[：:]\s*.+`（取第一条） | `计划新增 status 字段...` |

### 3.4 CI 集成位置

`.gitlab-ci.yml` 中独立 `notify` 阶段（`prepare → build → deploy → notify → verify`）。
- `deploy` 成功后触发，此时文档已部署，通知中链接的 HTML 版本可正常访问
- `notify` 失败不影响 `verify` 健康检查
- 失败不阻塞流水线：`|| true` 降级

---

## 四、实施步骤 + 依赖图

```
Task 1 (notify-doc-update.sh 脚本) ── 无前置依赖
                │
                ▼
Task 2 (.gitlab-ci.yml 集成) ── 依赖 Task 1
                │
                ▼
Task 3 (环境变量配置 + 端到端验证) ── 依赖 Task 2
```

### Task 1: 改造 notify-doc-update.sh（多平台支持）

**改动文件**: `scripts/notify-doc-update.sh`

- [ ] 读取 `NOTIFY_WEBHOOK_URLS` 环境变量，逗号分隔为数组；未设则 fallback 到 `WECOM_WEBHOOK_URL`
- [ ] 实现 `detect_platform(url)` 函数：按域名识别平台（qyapi→wecom / oapi→dingtalk / open.feishu→feishu）
- [ ] 实现 `send_wecom(url)` 函数：企业微信 markdown 格式（`<font color="info">`）
- [ ] 实现 `send_dingtalk(url)` 函数：钉钉 markdown 格式（版本号降级为 `**v4.2**` 加粗）
- [ ] 实现 `send_feishu(url)` 函数：飞书 text 格式（简化版，不引入卡片复杂度）
- [ ] 主流程：for each URL → detect platform → 调用对应 send 函数 → 失败 warn 但继续
- [ ] 向后兼容：`WECOM_WEBHOOK_URL` 仍可单独使用
- [ ] 验证标准：本地设置多 URL 后执行，各平台日志独立输出

### Task 2: 更新环境变量配置

**改动文件**: `.env.production`, `.env.example`

- [ ] `.env.production`：`WECOM_WEBHOOK_URL` 替换为 `NOTIFY_WEBHOOK_URLS`（逗号分隔）
- [ ] `.env.example`：同步更新模板 + 平台格式注释
- [ ] 验证标准：文件格式一致，注释清晰

---

## 五、验收标准

- [ ] `scripts/notify-doc-update.sh` 支持 `NOTIFY_WEBHOOK_URLS` 逗号分隔多 URL
- [ ] URL 域名自动识别平台（qyapi→企业微信 / oapi→钉钉 / open.feishu→飞书）
- [ ] 各平台独立消息格式：企业微信 `<font color>` / 钉钉 `**v4.2**` 加粗 / 飞书 text
- [ ] 向后兼容：仅设 `WECOM_WEBHOOK_URL` 时仍按企业微信格式推送
- [ ] 任一平台失败不影响其余平台推送
- [ ] Git Push 到 main 且 API 文档变更时，所有已配置平台群内收到通知
- [ ] 非文档变更的 Push 不触发通知
- [ ] `.env.production` / `.env.example` 使用 `NOTIFY_WEBHOOK_URLS`

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/25/farm-agent-wecom-doc-notify-add-route-v1.md` |
| Spec | `.qoder/specs/farm-agent-wecom-doc-notify/spec.md` |
| Atom RSS 端点 | `src/app/api/h5/docs/route.ts` |
| API 对接文档 | `docs/大田精准耕播智能决策系统/knowledge/02-规范/瑞丰耘H5小程序API对接文档.md` |
