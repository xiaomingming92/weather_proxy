# farm-agent — ACA 三层推理图 Handoff v2

> **适用场景**：单轮交付。Phase 0 — H5 Resume 链路修复（Professional 图交互裁决的前置依赖）。
> **最新修订**: 2026-06-25 — Phase 0 交付
> **关联 Plan**: [farm-agent-three-tier-reasoning-graph-plan-v2.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-plan-v2.md)
> **后继 Plan**: [farm-agent-three-tier-reasoning-graph-plan-v3.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md)（2026-06-29 取代 v2，当前权威版本）
> **关联 Review**: [farm-agent-three-tier-reasoning-graph-review-v3.md](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-v3.md)（2026-06-29 三版合并 Review）
> **Plan 关键词**: `farm-agent-three-tier-reasoning-graph`

---

## 1. 交接前状态

| 问题 | 现象 | 影响 |
|------|------|------|
| H5 路由无 `__interrupt__` 检测 | `for-await` 循环仅检查 `nodeName === "response"`，完全忽略 `chunk.__interrupt__` | interactionPoint 触发时流静默结束，前端无感知 |
| H5 端无 resume 端点 | `/api/h5/agent/[threadId]/resume/` 目录不存在 | 前端无法恢复 interrupt 暂停的 agent 流 |
| Web UI 对比 | `/api/agent/stream/route.ts` 和 `/api/agent/resume/route.ts` 均已正确实现 | H5 端落后于 Web UI 的交互点能力 |

## 2. 交接后状态（目标）

- ✅ H5 chat 路由检测 `chunk.__interrupt__`，输出 `event: interrupt` SSE 事件（对齐 Web UI 实现）
- ✅ `POST /api/h5/agent/{threadId}/resume` 端点可用，使用 `Command({ resume })` 恢复流
- ✅ 后续 Professional 图的 interactionPoint 裁决可在 H5 端正常工作
- ✅ `tsc --noEmit` 零错误

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|:--:|------|
| 1 | `src/app/api/h5/agent/route.ts` | 修改 | for-await 循环新增 13 行 `__interrupt__` 检测逻辑：`if (chunk.__interrupt__)` → 解析数组 → 输出 `event: interrupt` SSE |
| 2 | `src/app/api/h5/agent/[threadId]/resume/route.ts` | **新建** | 133 行 H5 专属 resume 端点：URL params threadId + H5 认证（X-Api-Key / X-Session-Id）+ `Command({ resume: { choice, note } })` 恢复流 + SSE 输出 + OPTIONS CORS |
| 3 | `.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-plan-v2.md` | 修改 | Plan 新增 Phase 0 章节（审计表 2 条 + 实施步骤 + 依赖拓扑 + 验收标准） |

## 4. 修复原理

```
修复前:
  H5 SSE 流 → interactionPoint interrupt()
  → chunk.__interrupt__ 出现
  → H5 路由 不检测 → 流静默结束 ❌
  → 无 resume 端点 → 无法恢复 ❌

修复后:
  H5 SSE 流 → interactionPoint interrupt()
  → chunk.__interrupt__ 出现
  → H5 路由 检测 → event: interrupt ✅
  → 用户选择 → POST /api/h5/agent/{threadId}/resume
  → Command(resume) → agent 从 interrupt 断点恢复 ✅
```

## 5. 回滚方案

```bash
# 回滚 H5 路由（保留 resume 端点不影响正常功能，但可同时清理）
git checkout HEAD~1 -- src/app/api/h5/agent/route.ts
rm -r src/app/api/h5/agent/\[threadId\]/resume/

# 回滚 Plan
git checkout HEAD~1 -- .qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-plan-v2.md
```

## 6. 验证方法

```bash
# 编译验证
npx tsc --noEmit

# 手工测试（需要运行时）
# 1. 发送 H5 chat 请求触发 interactionPoint
# 2. 观察 SSE 流中是否出现 event: interrupt
# 3. 调用 POST /api/h5/agent/{threadId}/resume 恢复
```

## 7. Devlog 审计记录

| ID | action | targetId | 说明 |
|----|--------|----------|------|
| `cmqth89hh001flzcy8a1v8jb8` | MODIFY | `src/app/api/h5/agent/route.ts` | H5 路由新增 `__interrupt__` 检测 |
| `cmqth89hj001hlzcy4ark38hf` | CREATE | `src/app/api/h5/agent/[threadId]/resume/route.ts` | 新建 H5 resume 端点 |
| `cmqth89hb001dlzcyvx2ivvld` | PLAN_UPDATED | `.qoder/plans/...plan-v2.md` | v2 Plan 新增 Phase 0 |

> 全部记录可查：`query_audit_logs({ planKeyword: "farm-agent-three-tier-reasoning-graph" })`

## 8. 后续依赖

本 Phase 0 交付后，Plan v2 的 4 轮原子事务可按序推进：

```
Phase 0 ✅ → 轮次 1: 类型基石 → 轮次 2: State 桥接 → 轮次 3: ACA 核心 → 轮次 4: 图组装
```

下一轮（轮次 1）依赖本 Phase 无额外阻塞——仅 `tsc --noEmit` 零错误即可进入。
