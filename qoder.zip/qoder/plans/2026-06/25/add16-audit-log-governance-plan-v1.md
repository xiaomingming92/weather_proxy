# ADD-16 裁决层契约强制门禁 — plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。本 Plan 为规则增强项目，不涉及代码逻辑变更。

## PLAN 元信息

- **Plan 名称**: add16-audit-log-governance-v1
- **启动时间**: 2026-06-25T14:00:00.000Z
- **主导 AI**: Qoder
- **触发来源**: Plan `audit-log-bypass-governance-plan-v1` 的裁决层治理衍生需求
- **关联文档**:
  - 母 Plan: `.qoder/plans/2026-06/25/audit-log-bypass-governance-plan-v1.md`
  - Review: `.qoder/reviews/streaming-event-bus-runtime-review-v1.md`
  - 裁决层契约: `docs/大田精准耕播智能决策系统/knowledge/01-架构/《裁决层-AuditLog写入契约》.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `.qoder/rules/project_rules.md` | RULE | RULE_ADDED | 无 ADD-16 规则 | 新增 ADD-16 裁决层契约强制门禁 | ✅ 已完成 |
| `.qoder/rules/theory-practice-map.toml` | RULE | RULE_UPDATED | 无 ADD-16 映射 | 新增 ADD-16 理论→实践映射 | ✅ 已完成 |

---

## 一、背景与目标

### 1.1 问题现状

AI 在修改审计/日志相关代码时经常绕过 ADD 范式：
- 直接调 `prisma.auditLog.create` 而不走 `writeAuditLog`
- 不知道"这个场景该用 `agentAudit` 还是 `streamBusAudit`"
- 新增 phase 不在 caijue.toml 注册，也不读裁决层契约

根本原因：**缺少一条 P0 级规则明确告诉 AI"这些文件受裁决层管辖，修改前必须先读契约"**。

### 1.2 目标

在 `project_rules.md` 中新增 ADD-16 规则，实现：
1. 明确列出管辖文件清单
2. 强制 AI 在编码前读取裁决层契约
3. 强制 AI 在编码前核对 caijue.toml
4. 强制 AI 在编码后调用 Guardian 门禁

---

## 二、架构设计

### 2.1 生效链路

```
AI 准备修改被管辖文件
  │
  ▼
project_rules.md ADD-16（always_on, P0 优先级）
  │
  ├─ ① 读取《裁决层-AuditLog写入契约》
  ├─ ② 核对 caijue.toml
  ├─ ③ 调用 add-flow-guardian
  │
  ▼
ESLint no-restricted-syntax（编译时阻断 prisma.auditLog.create）
  │
  ▼
CI grep 扫描（PR 时检测绕过）
```

### 2.2 管辖文件清单

| 模块 | 文件 | 为什么受管辖 |
|:--|:--|:--|
| Agent 管线审计 | `agent-audit-logger.ts` | L2 统一入口所在 |
| 流式事件总线 | `stream-bus-logger.ts`, `stream-bus.ts` | 高频 token 审计所在 |
| Gateway 审计 | `agent-gateway-audit.ts` | 独立审计入口 |
| Farm-Server 客户端 | `farm-server-client.ts` | 独立 L1+L2 模式 |
| 凭证管理 | `credential-store.ts` | 独立审计入口 |
| 运行时诊断 | `append-runtime-finding.ts` | 独立审计入口 |
| 聊天流式路由 | `chat/stream/route.ts` | SSE 审计入口 |
| Layer 2 回调 | `layer2-callback.ts` | 独立审计入口 |
| 任何新建的 | `*-logger.ts`, `*-audit.ts` | 新入管辖 |

---

## 三、验收标准

- [ ] `project_rules.md` 含 ADD-16 完整定义（管辖文件清单 + 判定规则）
- [ ] `theory-practice-map.toml` 含 ADD-16 映射
- [ ] P0 优先级表含 ADD-16 条目
- [ ] AI 修改管辖文件前自动读取裁决层契约（验证方式：对话中 AI 先 Read 契约再改代码）

---

## 四、关联文档

| 文档 | 路径 |
|------|------|
| 母 Plan | `.qoder/plans/2026-06/25/audit-log-bypass-governance-plan-v1.md` |
| 裁决层契约 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《裁决层-AuditLog写入契约》.md` |
| 项目规则 | `.qoder/rules/project_rules.md` |
| 理论映射 | `.qoder/rules/theory-practice-map.toml` |
| Review | `.qoder/reviews/streaming-event-bus-runtime-review-v1.md` |
