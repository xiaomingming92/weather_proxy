# farm-agent — 领域词汇注入与工具上下文类型化 交接手册

> **适用场景**：单轮交付。Task 1-6.5 — 领域触发词汇表建立 + Tool Context category 分区渲染 + caijuehub 裁决层 + SSE param_missing 事件。
> **最新修订**: 2026-06-26 — 全部 Task 完成
> **关联 Plan**: [farm-agent-domain-vocabulary-plan-v1.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-plan-v1.md)
> **Plan 关键词**: `farm-agent-domain-vocabulary`

---

## 1. 交接前状态

- LLM 缺乏领域"语义本能"——用户说"虫害严重"，LLM 不知道匹配 pest_risk 专家
- `runtimeInputs` 类型为 `Record<string, unknown>`，Factory.ts 无法按语义分区渲染
- 工具调用参数（massifId）缺少动态裁决——Zod schema 中全部 optional，LLM 可能空手调工具
- SSE 流无 param_missing 事件，前端无法感知工具参数缺失
- cost-accounting 专家缺失 config 文件

## 2. 交接后状态（目标）

- ✅ `DOMAIN_TRIGGERS` 集中管理 14 个专家的触发词 + collection 提示
- ✅ `RuntimeInputCategory` 枚举型（`"toolContext" | "analysis"`），factory.ts 按 category 分两段渲染
- ✅ `RuntimeInputEntry` 字段必填 category，全链路类型安全（`Record<string, RuntimeInputEntry>`）
- ✅ caijuehub 裁决层动态判断 massifId 是否必须（3 工具覆盖）
- ✅ SSE stream 新增 `ParamMissingEvent` 事件类型
- ✅ `tsc --noEmit` 零错误

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|:--:|------|
| 1 | `src/lib/agent-audit-logger.ts` | 修改 | 新增 4 个 AgentAuditPhase |
| 2 | `src/services/analysis-context.ts` | 修改 | `RuntimeInputEntry` 新增 `category` 字段 + `RuntimeInputCategory` 枚举 |
| 3 | `src/agents/prompts/types.ts` | 修改 | `Record<string, unknown>` → `Record<string, RuntimeInputEntry>`（2 处） |
| 4 | `src/agents/nodes/reasoning.ts` | 修改 | runtimeInputs 类型修复 |
| 5 | `src/agents/nodes/retrieval.ts` | 修改 | runtimeInputs 类型修复 |
| 6 | `src/agents/prompts/experts/factory.ts` | 修改 | category 分区渲染（`【工具调用上下文】` + `【运行时参数】`）+ agentAudit 调用 |
| 7 | `src/caijuehub/strategies/resolve-tool-params.ts` | **新建** | 裁决层：3 工具 massifId 动态必须性判断 |
| 8 | `src/agents/stream-bus.ts` | 修改 | 新增 `ParamMissingEvent` |
| 9 | `src/lib/stream-bus-logger.ts` | 修改 | 新增 `STREAM_BUS_EMIT_PARAM_MISSING` phase |

## 4. 验证方法

```bash
# 编译验证
npx tsc --noEmit

# 类型验证
# factory.ts 中 entry.label / entry.value 可直接访问（非 unknown）
# RuntimeInputEntry.category 必填，编译期检查
```

## 5. 回滚方案

```bash
git checkout HEAD~1 -- src/lib/agent-audit-logger.ts \
  src/services/analysis-context.ts \
  src/agents/prompts/types.ts \
  src/agents/nodes/reasoning.ts \
  src/agents/nodes/retrieval.ts \
  src/agents/prompts/experts/factory.ts \
  src/agents/stream-bus.ts \
  src/lib/stream-bus-logger.ts
rm src/caijuehub/strategies/resolve-tool-params.ts
```

## 6. Devlog 审计记录

| ID | action | targetId | 说明 |
|----|--------|----------|------|
| `cmquc0yup` | MODIFY | `src/lib/agent-audit-logger.ts` | +4 AgentAuditPhase |
| `cmquc0yul` | MODIFY | `src/services/analysis-context.ts` | +category 字段 + 枚举 |
| `cmquc0yup` | MODIFY | `src/agents/prompts/types.ts` | Record<string, unknown> → RuntimeInputEntry |
| `cmquc0yuo` | MODIFY | `src/agents/prompts/experts/factory.ts` | 分区渲染 + 触发词注入 |
| `cmquc0yuk` | MODIFY | `src/agents/nodes/reasoning.ts` | 类型修复 |
| `cmquc0yup` | MODIFY | `src/agents/nodes/retrieval.ts` | 类型修复 |
| `cmquc0yuo` | CREATE | `src/caijuehub/strategies/resolve-tool-params.ts` | 裁决层 |
| `cmquc0yuo` | MODIFY | `src/agents/stream-bus.ts` | ParamMissingEvent |
| `cmquc0yuc` | MODIFY | `src/lib/stream-bus-logger.ts` | +1 phase |

> 全部记录可查：`query_audit_logs({ planKeyword: "farm-agent-domain-vocabulary" })`
