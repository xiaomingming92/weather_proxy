# farm-agent-aca-framework-plan-v2

> **ACA 框架** = **A**rgumentation（论证框架）+ **C**onstraint Propagation（约束传播）+ **A**djudication（人工裁决）。这是 professional 图的推理范式命名——三位专家各自产出结构化论证（Argumentation），确定性冲突检测利用硬约束/软约束传播（Constraint），不可解冲突交由人工裁决点（Adjudication），而非 LLM 自由辩论。
>
> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度（文件路径 + Phase 验收标准 + 架构维度全覆盖）。**不要**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-aca-framework-v2
- **推理范式**: ACA（Argumentation + Constraint + Adjudication）
- **启动时间**: 2026-06-25T12:00:00+08:00
- **主导 AI**: Qoder
- **前身 Plan**: [farm-agent-three-tier-reasoning-graph-plan-v1.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/17/farm-agent-three-tier-reasoning-graph-plan-v1.md)（2026-06-17 初版）
- **v2 变更摘要**:
  1. 实施路线由 4 个粗粒度 Phase 重构为 **4 轮原子事务**，每轮具备独立交付能力和明确验收标准
  2. 补充 Web 调研结论：LangGraph `interrupt()`/`Command(resume=...)` 机制、`Send` API fan-out 模式、MAPF mutex propagation 冲突检测算法借鉴
  3. 解决 v1 Review 中识别的 3 个 P1 问题：massifId/massifIds 双模语义、冲突检测算法参考、约束松弛策略定义
  4. 新增 **Phase 0：H5 Resume 链路修复**——H5 端缺少 `__interrupt__` 检测和 resume 端点，是 professional 图交互裁决的前置依赖
  5. 开篇定义 **依赖拓扑**（含 Phase 0），使 Spec 生成和任务拆分有据可依
- **关联文档**:
  - V1 Plan: `.qoder/plans/2026-06/17/farm-agent-three-tier-reasoning-graph-plan-v1.md`
  - V3 Plan: `.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md`（**2026-06-29 取代本 Plan，当前权威版本**）
  - ADD Route: `.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-add-route-v2.md`（待生成）
  - Handoff: `.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-handoff-v2.md`（待生成）
  - Review: `.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-v1.md`（待生成）
  - Spec: `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md`（待生成）
  - Tasks: `.qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md`（待生成）
  - Checklist: `.qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md`（待生成）
- **ADD-7 审计策略**（v2 更新：新增 3 条 v2 特有记录，其余沿用 v1）:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/agents/edges/conditional.ts | COMPONENT | COMPONENT_MODIFIED | routeByIntent 仅 fast/deep 两路；无 evidenceSource 路由 | 新增 routeByEvidenceSource；routeByIntent 新增 professional 分支 | ✅ 已完成 |
| src/agents/nodes/reasoning.ts | COMPONENT | COMPONENT_MODIFIED | L67 因 evidenceChain 为空拒绝 isSummary 推理；L186 错误注入"RAG 0条结果" | isSummary 识别 + 工具数据一等公民 + prompt 按证据源差异化 | ✅ 已完成 |
| src/agents/prompts/experts/factory.ts | COMPONENT | COMPONENT_MODIFIED | 证据区块无条件优先于工具数据区块 | isSummary 时工具数据区块前置，去掉"RAG 0条结果"前缀 | ✅ 已完成 |
| src/agents/prompts/experts/weekly-report.ts | COMPONENT | COMPONENT_MODIFIED | prompt 说"引用核心专家独立报告" | 改为"基于以下实时监测数据" | ✅ 已完成 |
| src/agents/prompts/experts/daily-report.ts | COMPONENT | COMPONENT_MODIFIED | 同上歧义 prompt | 同上修正 | ✅ 已完成 |
| src/agents/index.ts | COMPONENT | COMPONENT_MODIFIED | 单一 workflow 编译为 agent | 拆为 fastGraph/deepGraph/professionalGraph 三个编译图；新增入口路由 | 待实施 |
| src/agents/nodes/structured-output.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 专家自由文本 → ExpertClaim 结构体转换 | 待实施 |
| src/agents/nodes/conflict-resolver.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 确定性冲突检测（前提互斥/资源冲突/时序矛盾/执行标准不一致） | 待实施 |
| src/agents/nodes/coordination-dialogue.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 定向提问协调 + 约束松弛求解 | 待实施 |
| src/agents/nodes/aggregation.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 多专家结论格式聚合 | 待实施 |
| src/agents/state.ts | COMPONENT | COMPONENT_MODIFIED | 单 massifId 标量；无 ExpertClaim[] / ConflictReport[] | 新增 massifIds / expertClaims / conflictReports / aggregatedReport；保留 massifId 向后兼容 | 待实施 |
| src/types/evidence.ts | TYPE | TYPE_MODIFIED | ThinkingLevel = "fast" \| "deep" | ThinkingLevel = "fast" \| "deep" \| "professional" | 待实施 |
| src/agents/prompts/types.ts | TYPE | TYPE_MODIFIED | 无 ExpertClaim / ConflictReport 类型 | 新增 ExpertClaim / ConflictReport / CoordinationResult 类型 | 待实施 |
| src/agents/reports/weekly-report.template.ts | REPORT | REPORT_MODIFIED | 引用 displayContent 等已存在 section | 对齐工具数据优先的 evidence source 变更 | 待实施 |
| src/agents/nodes/intention.ts | COMPONENT | COMPONENT_MODIFIED | 产出 thinkingLevel + expertPlan（已有） | professional 场景下产出 expertPlan: Expert[]（含 per-expert subIntent 拆分） | v2 新增 |
| src/app/api/h5/agent/route.ts | API_ROUTE | API_MODIFIED | for-await 循环不检测 chunk.__interrupt__；交互点触发时流静默结束 | 新增 __interrupt__ 检测 + 输出 event: interrupt SSE 事件 | v2 新增-Phase 0 |
| src/app/api/h5/agent/[threadId]/resume/route.ts | API_ROUTE | API_CREATED | H5 端无 resume 端点 | 新增 H5 resume 端点，镜像 /api/agent/resume 模式，使用 H5 认证上下文 | v2 新增-Phase 0 |

---

## 一、背景与目标

> 本节内容与 [v1 §一](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/17/farm-agent-three-tier-reasoning-graph-plan-v1.md) 一致，维持不变。Phase 1 已在 2026-06-17 前置交付完成。

### 1.1 问题现状

当前 Agent 管线（deep graph）存在三个瓶颈：

| 瓶颈 | 现象 | 根因 |
|------|------|------|
| **汇总专家推理断裂** | weekly_report/daily_report（isSummary=true）跳过 RAG 后，reasoning 节点收到空 evidenceChain + warning 证据，prompt 误称"RAG 检索返回 0 条结果"，而工具数据（weather/soil/insect）实际已获取并可用 | retrieval.ts 对 isSummary 返回空数组 → reasoning.ts L67 逻辑不区分证据源 → factory.ts 证据区块无条件优先于工具数据区块 |
| **多专家协作缺失** | 当用户提问涉及 pest_risk + weather + soil 三个专家时，当前管线仅做 per-expert 并行 RAG 检索 + 合并推理，专家之间无互相审查、无冲突检测、无协调机制 | 单管线设计未考虑多专家联合场景 |
| **单地块架构限制** | AgentState.massifId 为标量，无法支持"分析农场全部 5 个地块本周趋势" | 状态模型未设计多地块并行查询 |

### 1.2 目标

1. **汇总专家在 deep 图内正常工作**（✅ Phase 1 已完成）：跳过 RAG 检索，工具数据升级为一等证据源，推理链路通畅
2. **新增 ACA Graph（professional 图）**：采用 **A**rgumentation + **C**onstraint + **A**djudication 范式，支持 2-N 个专家联合协作——每位专家产出结构化论证（Argumentation），确定性冲突检测利用约束传播（Constraint），不可解冲突交由人工裁决（Adjudication）
3. **thinkingLevel 从 2 级扩展为 3 级**：`fast` / `deep` / `professional`
4. **deep 图不动**：单专家推理的现有能力（证据链、四元置信度、推理路径）不受影响

---

## 二、方案选型

> 本节内容与 [v1 §二](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/17/farm-agent-three-tier-reasoning-graph-plan-v1.md) 一致，维持不变。

### 2.1 候选方案对比

| 维度 | A: 在现有管线上加 if-else | B: 独立子图 + 入口路由（选用） |
|------|--------------------------|-------------------------------|
| 实现复杂度 | 低（在 reasoning/retrieval 内部分支） | 中（新建 3 个编译图 + 4 个新节点） |
| deep 图稳定性 | 高风险——改动现有节点逻辑，可能引入回归 | 零风险——deep 图不动，仅 isSummary 证据路由修正 |
| professional 扩展性 | 差——后续新增专家协调逻辑需继续在单节点内堆积 if-else | 好——professional 图独立演化，节点职责清晰 |
| 行业对标 | 无（MAC 论文用的就是多 Agent 独立子图模式） | 对齐 LangGraph Subgraph + MAC 多 Agent 模式 |
| 审计干净度 | 差——同一个 reasoning 节点的审计日志混合两种业务模式 | 好——按图路由分离审计阶段 |

### 2.2 选型理由

**选用方案 B（独立子图 + 入口路由）**。理由：

- professional 图的节点序列（fan-out → crossReview → conflictResolver → coordinationDialogue → aggregation）与 deep 图（retrieval → reasoning → interactionPoint → verdict）拓扑完全不同，不应塞进同一管线
- deep 图已被验证为行业领先的单专家推理管线，不应为兼容新模式而污染其逻辑
- LangGraph Subgraph 模式原生支持多图编译 + 入口路由
- MAC 论文（Nature 2025）验证了多 Agent 独立子图 + Supervisor 聚合的有效性，本项目在此基础上进一步提出 **ACA 范式**：用结构化论证替代 LLM 自由辩论，用约束传播替代黑盒冲突解决，用人工裁决替代自动降级。

---

## 三、架构设计

> 本节内容与 [v1 §三](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/17/farm-agent-three-tier-reasoning-graph-plan-v1.md) 一致，维持不变。以下各子节完整保留 v1 的架构描述——包括三图总览、deepGraph 微调、ACA Graph 拓扑、数据结构、节点复用矩阵和 State 扩展。这些是实施的基础蓝图，不因 atom 拆分而改变。

### 3.1 三图总览

> **ACA 范式定义**：Argumentation（论证框架，每位专家输出结构化 ExpertClaim 而非自由文本）→ Constraint Propagation（约束传播，hard/soft 确定性检测而非 LLM 对话协商）→ Adjudication（人工裁决，冲突不可解时 interactionPoint 呈现结构化选项而非自动 fallback）。

```
                    ┌──────────────────┐
                    │   __start__       │
                    │   input: {query,  │
                    │     explicitIntent,│
                    │     thinkingLevel?,│
                    │     massifIds[] }  │
                    └────────┬─────────┘
                             │
                             ▼
                    ┌────────────────────┐
                    │    intention        │
                    │    (三段路由判定)    │
                    │thinkingLevel:       │
                    │ fast/deep/prof.     │
                    └────────┬───────────┘
                             │
              ┌──────────────┼──────────────┐
              │ fast         │ deep         │ professional
              ▼              ▼              ▼
        ┌──────────┐  ┌──────────┐  ┌──────────────────┐
        │fastGraph │  │deepGraph │  │ACA Graph (新图) │
        │(不动)    │  │(微调)    │  │professional 图    │
        │          │  │          │  │采用 ACA 范式     │
        └──────────┘  └──────────┘  └──────────────────┘
```

| 图 | 职责 | 专家数 | 拓扑 |
|----|------|--------|------|
| fastGraph | 问候/闲聊 | 0 | intention → response |
| deepGraph | 单专家分析（含汇总专家） | 1 | intention → [toolNode] → [retrieval] → reasoning → interactionPoint → verdict → response |
| professionalGraph | 多专家联合 + 冲突协调 | 2-N | intention → fan-out → per-expert(ACA 三阶段: retrieval+reasoning→Argumentation structuredOutput→Constraint conflictResolver→协调/裁决→Adjudication) → aggregation → verdict → response |

### 3.2 deepGraph 微调：汇总专家证据路由

```
deep graph 内新增 routeByEvidenceSource：

  intention
       │
       │ routeByEvidenceSource (new)
       │
  ┌────┴────────────────────┐
  │ RAG evidence expert     │ isSummary expert
  │ (pest_risk, growth...)  │ (weekly_report, daily_report)
  │                         │
  ▼                         ▼
┌──────────┐          ┌──────────────┐
│ toolNode │          │  toolNode    │
│ (可选)    │          │  (强制)       │
└────┬─────┘          └──────┬───────┘
     │                       │
     ▼                       │
┌──────────┐                 │  ← 跳过 retrieval
│retrieval │                 │
└────┬─────┘                 │
     │                       │
     ▼                       ▼
┌──────────────────────────────────┐
│           reasoning              │
│  RAG expert: evidence ← chunks  │
│  isSummary:   evidence ← tools  │
└──────────────────────────────────┘
```

关键改动：
- [src/agents/edges/conditional.ts](file:///home/xmm/ai/farm-agent/src/agents/edges/conditional.ts)：新增 `routeByEvidenceSource`，isSummary → 跳过 retrieval，直入 reasoning
- [src/agents/nodes/reasoning.ts](file:///home/xmm/ai/farm-agent/src/agents/nodes/reasoning.ts)：L67 不再因空 evidenceChain 拒绝 isSummary；L186 去掉误导性"RAG 0条结果"前缀
- [src/agents/prompts/experts/factory.ts](file:///home/xmm/ai/farm-agent/src/agents/prompts/experts/factory.ts)：isSummary 时工具数据区块升为一等证据位置
- [src/agents/prompts/experts/weekly-report.ts](file:///home/xmm/ai/farm-agent/src/agents/prompts/experts/weekly-report.ts)：prompt 从"引用核心专家报告"改为"基于实时监测数据"

### 3.3 ACA Graph 拓扑（professional 图）

> 本图为 ACA 范式的完整载体。每位专家走独立论证链路（retrieval → reasoning → structuredOutput），产出 ExpertClaim 结构体。汇聚后经 Constraint 层做确定性冲突检测，不可解冲突进入 Adjudication 层（人工裁决点 interactionPoint）。

```
                    ┌─────────────────────────────────────┐
                    │          __start__                   │
                    │  input: {query, massifId[], ...}     │
                    └───────────────┬─────────────────────┘
                                    │
                                    ▼
                    ┌───────────────────────────────┐
                    │      intention (意图解析)       │
                    │  产出: subIntents[],            │
                    │        expertPlan: Expert[]    │
                    │  例: [pest_risk, weather, soil]│
                    └───────────────┬───────────────┘
                                    │
                         ┌──────────┴──────────┐
                         │  thinkingLevel       │
                         │  deep → deepGraph     │  (已有管线，不动)
                         │  professional →       │
                         └──────────┬───────────┘
                                    │
                    ════════════════╧═══════════════
                    ║   professional fan-out 层    ║
                    ════════════════╤═══════════════
                                    │
              ┌─────────────────────┼─────────────────────┐
              │                     │                     │
              ▼                     ▼                     ▼
    ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
    │ Expert A         │ │ Expert B         │ │ Expert C         │
    │ (pest_risk)      │ │ (weather_impact) │ │ (nutrition)      │
    └────────┬─────────┘ └────────┬─────────┘ └────────┬─────────┘
             │                    │                    │
             │  ┌─────────────────┴─────────────────┐  │
             │  │       per-expert 并行执行          │  │
             │  │  (LangGraph Send API fan-out)     │  │
             │  └─────────────────┬─────────────────┘  │
             │                    │                    │
             ▼                    ▼                    ▼
    ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
    │ 1. retrieval     │ │ 1. retrieval     │ │ 1. retrieval     │
    │    RAG 证据检索   │ │    RAG 证据检索   │ │    RAG 证据检索   │
    │    + tool调用    │ │    + tool调用    │ │    + tool调用    │
    └────────┬─────────┘ └────────┬─────────┘ └────────┬─────────┘
             │                    │                    │
             ▼                    ▼                    ▼
    ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
    │ 2. reasoning     │ │ 2. reasoning     │ │ 2. reasoning     │
    │    独立深度推理   │ │    独立深度推理   │ │    独立深度推理   │
    │                  │ │                  │ │                  │
    │  输入: evidence  │ │  输入: evidence  │ │  输入: evidence  │
    │       toolResult │ │       toolResult │ │       toolResult │
    │       runtimeIn  │ │       runtimeIn  │ │       runtimeIn  │
    └────────┬─────────┘ └────────┬─────────┘ └────────┬─────────┘
             │                    │                    │
             ▼                    ▼                    ▼
    ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
    │ 3. structuredOutput││ 3. structuredOutput││ 3. structuredOutput│
    │  ★ 不再是自由文本  │ │  ★ 不再是自由文本  │ │  ★ 不再是自由文本  │
    └────────┬─────────┘ └────────┬─────────┘ └────────┬─────────┘
             │                    │                    │
             └────────────────────┼────────────────────┘
                                  │
                    ══════════════╧═══════════════
                    ║  结构体汇聚 (fan-in)       ║
                    ══════════════╤═══════════════
                                  │
                    ┌─────────────┴─────────────┐
                    │  ExpertClaims[]           │
                    │  每项: {                  │
                    │    expertId,              │
                    │    claim,                 │
                    │    evidence,              │
                    │    preconditions[],       │
                    │    hardConstraints[],     │
                    │    softConstraints[],     │
                    │    confidence,            │
                    │    recommendedActions[],  │
                    │    risks_if_ignored[]     │
                    │  }                        │
                    └─────────────┬─────────────┘
                                  │
                                  ▼
                    ══════════════╧═══════════════
                    ║   冲突检测层 (确定性逻辑)   ║
                    ══════════════╤═══════════════
                                  │
                    ┌─────────────┴─────────────┐
                    │  ConflictResolver         │
                    │                           │
                    │  检测四类冲突:              │
                    │                           │
                    │  1. 前提互斥               │
                    │     A.precondition         │
                    │     ∩ B.precondition = ∅   │
                    │     例: "无降雨" vs         │
                    │         "明天大雨"          │
                    │                           │
                    │  2. 资源冲突               │
                    │     A.action 所需资源       │
                    │     ∩ B.action 所需资源     │
                    │     > 可用上限              │
                    │     例: 同一天同一台机械     │
                    │                           │
                    │  3. 时序矛盾               │
                    │     A.action.deadline       │
                    │     < B.action.earliest     │
                    │     例: 打药窗口周五结束    │
                    │          降雨周五才开始     │
                    │                           │
                    │  4. 执行标准不一致          │
                    │     A.action.method         │
                    │     ≠ B.action.method       │
                    │     例: 专家A建议生物防治    │
                    │          专家B建议化学防治   │
                    └─────────────┬─────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │  ConflictReport[]          │
                    │  每项: {                   │
                    │    type,                   │
                    │    involvedExperts[],      │
                    │    description,            │
                    │    severity: HARD | SOFT,  │
                    │    suggestedResolution     │
                    │  }                         │
                    └─────────────┬─────────────┘
                                  │
                         ┌────────┴────────┐
                         │                 │
                    无冲突/             有冲突
                    全软冲突            含硬冲突
                         │                 │
                         ▼                 ▼
              ┌───────────────┐  ┌───────────────────────┐
              │  直接聚合     │  │  CoordinationDialogue  │
              │               │  │  (协调对话轮)           │
              │  按权重合并   │  │                        │
              │  格式对齐     │  │  不是开放式辩论          │
              │  生成统一视图 │  │  是定向提问+约束松弛:    │
              └───────┬───────┘  │                        │
                      │          │  1. 识别冲突中的可变项   │
                      │          │  2. 向相关专家定向提问:   │
                      │          │     "weather: 后天有窗口?"│
                      │          │     "pest: 推迟24h风险?" │
                      │          │  3. 收集修订建议         │
                      │          │  4. 尝试约束松弛求解     │
                      │          └───────────┬───────────┘
                      │                      │
                      │             ┌────────┴────────┐
                      │             │                 │
                      │        冲突可解           冲突不可解
                      │         (松弛成功)         (硬冲突残留)
                      │             │                 │
                      │             ▼                 ▼
                      │  ┌───────────────┐  ┌──────────────────────┐
                      │  │ 协调结果合并   │  │ interactionPoint     │
                      │  └───────┬───────┘  │  (人工裁决点)          │
                      │          │          │                       │
                      │          │          │  生成结构化选项:        │
                      │          │          │  {                    │
                      │          │          │   conflict,           │
                      │          │          │   optionA: {          │
                      │          │          │    采纳pest建议,       │
                      │          │          │    风险: 药效降低      │
                      │          │          │   },                  │
                      │          │          │   optionB: {          │
                      │          │          │    等雨停再打,         │
                      │          │          │    风险: 虫害加重      │
                      │          │          │   }                   │
                      │          │          │  }                    │
                      │          │          │                       │
                      │          │          │  ★ interrupt()       │
                      │          │          │    图暂停，不结束       │
                      │          │          │    State 完整保留     │
                      │          │          │    (expertClaims[]    │
                      │          │          │     conflictReports[] │
                      │          │          │     全部在内存)        │
                      │          │          └──────────┬───────────┘
                      │          │                      │
                      │          │          ┌──────────┴───────────┐
                      │          │          │  用户选择后           │
                      │          │          │  Command(resume=     │
                      │          │          │    optionA/optionB)  │
                      │          │          │  图从 interrupt()    │
                      │          │          │  下一行继续执行       │
                      │          │          └──────────┬───────────┘
                      │          │                      │
                      │          │                      ▼
                      │          │          ┌──────────────────────┐
                      │          │          │  aggregation         │
                      │          │          │  (携带用户选择的      │
                      │          │          │   专家结论聚合)       │
                      │          │          └──────────┬───────────┘
                      │          │                      │
                      └──────────┼──────────────────────┘
                                 │
                                 ▼
                    ┌───────────────────────┐
                    │    aggregation         │
                    │   (格式聚合层)          │
                    │                        │
                    │  合并已协调的专家结论    │
                    │  + 冲突标记 (如有残留)  │
                    │  → AggregatedReport    │
                    └───────────┬───────────┘
                                │
                                ▼
                    ┌───────────────────────┐
                    │    verdict             │
                    │   (业务裁决)            │
                    │                        │
                    │  与 deep graph 共享    │
                    │  verdictNode           │
                    │  → VerdictResult       │
                    └───────────┬───────────┘
                                │
                                ▼
                    ┌───────────────────────┐
                    │    response            │
                    │   (回复生成)            │
                    │                        │
                    │  与 deep graph 共享    │
                    │  responseNode          │
                    └───────────┬───────────┘
                                │
                                ▼
                           __end__
```

### 3.3.1 ACA 三阶段对照

| ACA 阶段 | 对应节点 | 核心能力 | 关键数据结构 |
|---------|---------|---------|------------|
| **A**rgumentation | retrieval + reasoning + structuredOutput | 每位专家独立论证，产出结构化主张 | ExpertClaim（claim + evidence + confidence + preconditions） |
| **C**onstraint | conflictResolver + coordinationDialogue | 确定性冲突检测（前提互斥/资源冲突/时序矛盾/执行标准不一致），约束松弛求解 | ConflictReport（type + severity HARD/SOFT + suggestedResolution） |
| **A**djudication | interactionPoint + verdict | 硬冲突残留时向人类呈现结构化权衡选项 | 结构化选项（optionA/optionB 含风险标注） |

### 3.3.2 深图内部：汇总专家证据路由

```
deep graph 内部路由优化:

  intention (识别 isSummary expert)
       │
       │ routeByEvidenceSource
       │
  ┌────┴────────────────────┐
  │                         │
  │ RAG evidence expert     │ isSummary expert
  │ (pest_risk, ...)        │ (weekly_report, daily_report)
  │                         │
  ▼                         ▼
┌──────────┐          ┌──────────────┐
│ toolNode │          │  toolNode    │  ← 同样会调工具
│ (可选)    │          │  (强制)       │
└────┬─────┘          └──────┬───────┘
     │                       │
     ▼                       │
┌──────────┐                 │  ← 不回到 intention loop
│retrieval │                 │     工具数据够了，不需要 LLM 再决定
└────┬─────┘                 │
     │                       │
     ▼                       ▼
┌──────────────────────────────────┐
│           reasoning              │
│                                  │
│  RAG expert:                     │
│    evidence ← RAG chunks         │
│    toolResults ← 补充上下文        │
│                                  │
│  isSummary expert:               │
│    evidence ← toolResults        │  ← 工具数据升级为一等证据
│    RAG ← 不参与                   │
│    prompt 不再说"0条结果"          │
└──────────────┬───────────────────┘
               │
               ▼
     interactionPoint → verdict → response
```

### 3.4 新数据结构

**ExpertClaim** — 每位专家推理后的结构化输出（论证框架 + 约束传播）：

```typescript
interface ExpertClaim {
  expertId: string
  expertLabel: string

  // ── 论证框架 ──
  claim: string                     // 核心主张
  reasoningPath: ReasoningStep[]    // 推理链条（已有）
  confidence: ConfidenceBreakdown   // 四元置信度（已有）

  // ── 约束传播 ──
  preconditions: string[]           // 前提条件（如"无降雨"、"温度<35℃"）
  hardConstraints: {                // 硬约束（不可违反）
    type: "time" | "resource" | "dependency"
    description: string
  }[]
  softConstraints: {                // 软约束（可放松）
    type: "time" | "resource" | "dependency"
    description: string
    penalty: number                 // 违反代价（0-1 归一化，1=最高代价）
  }[]

  // ── 输出 ──
  recommendedActions: {
    action: string
    timing: string
    resources: string[]
    deadline?: string
    method?: string                  // 执行方法（用于检测执行标准不一致）
  }[]
  risksIfIgnored: RiskItem[]        // 已有类型
}
```

**ConflictReport** — 冲突检测层输出：

```typescript
interface ConflictReport {
  type: "PRECONDITION_CONFLICT" | "RESOURCE_CONFLICT" | "TEMPORAL_CONFLICT" | "METHOD_CONFLICT"
  involvedExperts: string[]         // 涉及冲突的 expertId 列表
  description: string               // 人类可读的冲突描述
  severity: "HARD" | "SOFT"        // HARD = 不可自动解决，需人工裁决
  suggestedResolution?: string      // 建议的解决方向
}
```

**CoordinationResult** — 协调对话轮输出：

```typescript
interface CoordinationResult {
  resolved: boolean                 // true = 冲突已解，false = 仍有硬冲突残留
  revisedClaims: ExpertClaim[]      // 修订后的专家结论
  residualConflicts: ConflictReport[] // 未能解决的残留冲突
}
```

**冲突检测四类场景**（确定性逻辑，非 LLM）：

> 以下示例基于 farm-agent 实际注册的专家体系（pest_risk / weather_impact / soil_health / growth_stage / nutrition / water）展开，覆盖 4 类冲突的典型农业业务场景。

#### 类型 1：前提互斥（PRECONDITION_CONFLICT）

> **定义**：两位专家的论证建立在互斥的环境前提之上（`A.precondition ∩ B.precondition = ∅`）。检测方式：pairwise 对比 ExpertClaim.preconditions[]，通过反义词匹配表 + LLM 提取的标准化前提比较。

**按专家域分类的常见前提互斥**：

| 冲突对 | 专家A的前提 | 专家B的前提 | 互斥原因 | severity |
|--------|-----------|-----------|---------|:--:|
| pest ↔ weather | 天气晴朗、无降雨（打药窗口） | 未来24h降水量>10mm | 打药前提与降雨预报直接相悖 | HARD |
| pest ↔ weather | 风力<3级（无人机喷药） | 未来24h风力5-6级 | 风速超无人机作业安全阈值 | HARD |
| pest ↔ weather | 气温15-28℃（药剂活性区间） | 未来48h最低温降至8℃ | 低温导致药剂失效 | HARD |
| growth ↔ soil | 土壤含水量 60-80%（追肥窗口） | 当前土壤含水量 25%（干旱） | 干旱条件下追肥烧根 | HARD |
| growth ↔ weather | 连续3天晴好（除草剂窗口） | 未来48h持续降雨 | 除草剂被雨水冲刷失效 | HARD |
| water ↔ weather | 需灌溉（土壤缺水） | 未来24h中雨 | 灌溉与降雨重复，浪费水资源 | SOFT |
| nutrition ↔ soil | 土壤pH 6.0-7.0（氮肥有效） | 当前pH 5.2（偏酸） | 酸性土壤氮肥利用率骤降 | SOFT |

**反义词匹配表**（确定性检测的基础词表）：

```
降雨 ↔ 无降雨 / 晴朗 / 晴天
高温 ↔ 低温 / 寒潮
大风 ↔ 无风 / 微风
干旱 ↔ 湿润 / 多雨
偏酸 ↔ 偏碱
积水 ↔ 排水良好
```

#### 类型 2：资源冲突（RESOURCE_CONFLICT）

> **定义**：多位专家的推荐行动争用同一有限业务资源（`Σ(action.resources) > availableResources`）。检测方式：聚合 ExpertClaim.recommendedActions[].resources[]，按资源ID + 时间分组计数，任一资源出现超额即为冲突。

**农业业务中可量化的资源类型**：

| 资源类别 | 资源示例 | 冲突场景 | 数据来源 |
|---------|---------|---------|---------|
| **农机设备** | 拖拉机#1、收割机#2、植保无人机#3、播种机#4 | pest 需要 拖拉机#1 周一打药，nutrition 需要 拖拉机#1 周一施肥 → 同一设备同一天冲突 | 设备台账（外部系统或 state 注入） |
| **人力** | 技术员张工、农机手李工 | pest 需要 张工 周一下午打药，water 需要 张工 周一下午巡田 → 同一人同时间段冲突 | 人员排班（state 或外部系统） |
| **地块** | massifId=42（1号试验田） | pest 建议 #42 周一打药，growth 建议 #42 周一追肥 → 同一地块同日不能执行两种作业（药害风险） | AgentState.massifIds[] |
| **水源** | 灌溉井#1（日供水 2000m³） | water 建议 灌溉井#1 周一供 1500m³，soil 建议同一井同一天供 1000m³ → 合计 2500m³ > 2000m³ | 灌溉设施数据（工具查询） |
| **农资** | 农药A库存 50L、化肥B库存 200kg | pest 建议 用 农药A 30L 周一，pest（另一地块）建议 用 农药A 30L 周一 → 合计 60L > 50L 库存 | 农资库存系统（工具查询） |
| **时间窗口** | 周一下午 2-4 点（非雨、非高温时段） | pest 建议 周一 2-4pm 打药，water 建议 周一 2-4pm 灌溉 → 作业时间重叠（两类作业不可同时进行） | ExpertClaim.recommendedActions[].timing |

**severity 判定**：
- 农机/人力/地块冲突 → HARD（不可调和，需人工协调）
- 水源/农资/时间窗口冲突 → SOFT（可通过调整用量或时间协商解决）

#### 类型 3：时序矛盾（TEMPORAL_CONFLICT）

> 定义同 v1：`A.deadline < B.earliest`，时间区间不相交。

| 冲突对 | 专家A的时间约束 | 专家B的时间约束 | 矛盾点 | severity |
|--------|--------------|--------------|--------|:--:|
| pest ↔ weather | 打药窗口周五18:00前结束（虫害临界期） | 降雨周五20:00才开始 | 打药必须在降雨前完成，但降雨前无窗口 | HARD |
| pest ↔ growth | 除草剂有效期至本周日 | 安全间隔期需≥7天（距上次施肥仅5天） | 时间窗口不足以满足安全间隔 | HARD |
| nutrition ↔ water | 追肥最佳窗口: 6月10-15日 | 灌溉计划: 6月14-16日 | 追肥和灌溉需间隔≥3天，窗口重叠 | SOFT |

#### 类型 4：执行标准不一致（METHOD_CONFLICT）

> **定义**：两位专家推荐了互斥的农事操作方法（`A.method ≠ B.method` 且两种方法不可并行）。检测方式：维护互斥方法对表 + ExpertClaim.recommendedActions[].method 比对。

| 冲突对 | 专家A的方法 | 专家B的方法 | 互斥原因 | severity |
|--------|-----------|-----------|---------|:--:|
| pest ↔ pest（不同地块） | 化学防治（氯虫苯甲酰胺） | 生物防治（赤眼蜂） | 化学药剂会杀死赤眼蜂，不能同时使用 | SOFT |
| nutrition ↔ soil | 化肥追施（尿素 50kg/亩） | 有机肥方案（堆肥 2000kg/亩） | 两种施肥方案不可叠加，需择一 | SOFT |
| water ↔ growth | 漫灌（大水量） | 滴灌（精准控水） | 同一地块同一作物只能选一种灌溉方式 | SOFT |

**互斥方法对表**（确定性检测的基础词表）：

```
化学防治 ↔ 生物防治
化肥追施 ↔ 有机肥方案
漫灌 ↔ 滴灌
深耕 ↔ 免耕
单作 ↔ 间作
```

### 3.5 节点复用矩阵

| 节点 | fastGraph | deepGraph | professionalGraph |
|------|-----------|-----------|-------------------|
| intentionNode | ✅ | ✅ | ✅ |
| toolNode | - | ✅ | ✅（per-expert） |
| retrievalNode | - | ✅ | ✅（per-expert） |
| reasoningNode | - | ✅ | ✅（per-expert，增强结构化输出） |
| interactionPointDetectionNode | - | ✅ | ✅ |
| verdictNode | - | ✅ | ✅ |
| responseNode | ✅ | ✅ | ✅ |
| structuredOutputNode | - | - | ✅（新） |
| conflictResolverNode | - | - | ✅（新） |
| coordinationDialogueNode | - | - | ✅（新） |
| aggregationNode | - | - | ✅（新） |

### 3.6 State 扩展

```
AgentState 新增字段:
  thinkingLevel: "fast" | "deep" | "professional"  ← 类型扩展
  massifIds: number[]       ← 多地块支持（标量 massifId 保留向后兼容）
                            ← dual-mode 规则: professional 图用 massifIds，deep 图用 massifId，互斥使用
  expertPlan: Expert[]      ← professional 图专家执行计划
  expertClaims: ExpertClaim[]   ← per-expert 结构化结论
  conflictReports: ConflictReport[]  ← 冲突检测结果
  coordinationResult: CoordinationResult | null  ← 协调对话结果
  aggregatedReport: AggregatedReport | null      ← 聚合后的统一报告
```

**massifId/massifIds 双模语义**（v2 明确，解决 v1 P1-1）：

| 图 | 使用字段 | 语义 |
|----|---------|------|
| fastGraph | 不使用 | - |
| deepGraph | `massifId`（标量） | 单地块分析，同现有 |
| professionalGraph | `massifIds[]`（数组） | 多地块并行分析，fan-out 时按地块拆分 |

两个字段互斥：professional 图设置 `massifIds` 时，`massifId` 必须为 `null`/`undefined`，反之亦然。入口路由处做校验。

---

## 四、原子实施路线（v2 核心变更）

> **v2 重新设计**：将 v1 的 Phase 2-4 按照 [原子定义分步执行原则](memory://f094ed47-5be9-493c-8cdd-a72510f355c0) 拆分为 **1 个前置修复 + 4 轮原子事务**。每轮具备独立交付能力、明确验收标准和最小依赖范围。
>
> 原则上遵循：Phase 0（运行时基础链路）→ ① 类型定义（零运行时风险）→ ② 状态桥接（连接类型与运行时）→ ③ 核心逻辑（确定性 + LLM 分离）→ ④ 图组装（集成验证）。

### 4.0 Phase 0: H5 Resume 链路修复（前置依赖）

> **优先级**：🔴 最高。Professional 图的 interactionPoint 依赖 LangGraph `interrupt()` / `Command(resume=...)` 机制，而 H5 端当前**完全无法处理交互点**——主路由不检测 `__interrupt__`，且缺少 resume 端点。本阶段为后续所有轮次的前置条件。

**问题诊断**：

| 对比维度 | Web UI (`/api/agent/`) | H5 (`/api/h5/agent/`) |
|----------|----------------------|----------------------|
| 主路由 `__interrupt__` 检测 | ✅ `stream/route.ts:34-44` | ❌ 缺失——for-await 循环不检测 |
| Resume 端点 | ✅ `POST /api/agent/resume` | ❌ 整个目录不存在 |
| interrupt() 触发后 | 前端收到 `event: interrupt`，渲染交互卡片 | **流静默结束**，前端无知觉 |

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 0.1 | H5 chat 路由增加 `__interrupt__` 检测 | `src/app/api/h5/agent/route.ts` | 在 for-await 循环中新增 `if (chunk.__interrupt__)` 分支，输出 SSE `event: interrupt` 事件（格式对齐 Web UI `/api/agent/stream/route.ts` 的实现） | `tsc --noEmit` + 模拟 interactionPoint 触发 → H5 前端收到 `event: interrupt` |
| 0.2 | 新建 H5 resume 端点 | `src/app/api/h5/agent/[threadId]/resume/route.ts` | 镜像 `/api/agent/resume/route.ts` 模式：① 从 URL params 读取 threadId ② 复用 H5 认证上下文 ③ 使用 `Command({ resume: ... })` 恢复 agent 流 ④ 输出标准 SSE 流 | `tsc --noEmit` + 模拟 resume → agent 流从 interrupt 断点恢复 |

**验收标准**：
- H5 交互点触发时，前端收到 `event: interrupt` SSE 事件，可渲染交互卡片
- 前端提交选择后，`POST /api/h5/agent/{threadId}/resume` 恢复流，LLM 继续推理
- `tsc --noEmit` 零错误

### 4.1 依赖拓扑总览

```
                          Phase 1: deep graph 汇总专家修复
                          ✅ 2026-06-17 已完成，不纳入本轮
                                  │
                    ┌─────────────┴─────────────┐
                    │  Phase 0: H5 Resume 修复    │
                    │  前置依赖（必须先交付）      │
                    │  依赖: 无                   │
                    │  文件: h5/agent/route.ts    │
                    │        h5/agent/.../resume  │
                    └─────────────┬─────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │  轮次 1: 类型基石           │
                    │  零运行时风险，纯类型定义    │
                    │  依赖: Phase 0              │
                    │  文件: types/evidence.ts    │
                    │        prompts/types.ts      │
                    └─────────────┬─────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │  轮次 2: State 桥接         │
                    │  连接类型定义与运行时        │
                    │  依赖: 轮次 1               │
                    │  文件: agents/state.ts      │
                    │        nodes/structured-    │
                    │        output.ts             │
                    └─────────────┬─────────────┘
                                  │
              ┌───────────────────┼───────────────────┐
              │                   │                   │
              ▼                   ▼                   ▼
    轮次 3a: 确定性层      轮次 3b: 格式化层    轮次 3c: 协调层
    conflictResolver     aggregation          coordinationDialogue
    (纯算法，零LLM)       (纯格式化，无外部依赖)  (LLM 协调)
    依赖: 轮次 1(类型)     依赖: 轮次 1(类型)     依赖: 轮次 3a + 3b
              │                   │                   │
              └───────────────────┼───────────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │  轮次 4: 图组装 + 路由      │
                    │  编译三图 + 集成验证        │
                    │  依赖: 轮次 1-3             │
                    │  文件: agents/index.ts       │
                    │        edges/conditional.ts  │
                    │        nodes/intention.ts     │
                    └─────────────────────────────┘
```

### 4.1 轮次 1: 类型基石（零运行时风险）

> **目标**：建立 ACA 框架全部类型定义，`tsc --noEmit` 通过即交付。**不修改任何运行时逻辑**，不影响现有 fast/deep 图。

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 1.1 | ThinkingLevel 扩展为三级 | `src/types/evidence.ts` | `"fast" \| "deep"` → `"fast" \| "deep" \| "professional"` | `tsc --noEmit` |
| 1.2 | ExpertClaim 接口定义 | `src/agents/prompts/types.ts` | 新增：expertId / claim / preconditions / hardConstraints / softConstraints / recommendedActions（含 `method?: string` 用于方法冲突检测） | `tsc --noEmit` |
| 1.3 | ConflictReport 接口定义 | `src/agents/prompts/types.ts` | 新增：type（4 种）/ involvedExperts / description / severity(HARD\|SOFT) / suggestedResolution | `tsc --noEmit` |
| 1.4 | CoordinationResult 接口定义 | `src/agents/prompts/types.ts` | 新增：resolved / revisedClaims / residualConflicts | `tsc --noEmit` |
| 1.5 | AggregatedReport 接口定义 | `src/agents/prompts/types.ts` | 新增：合并后的统一报告格式（claims + conflicts + recommendations summary） | `tsc --noEmit` |

**验收标准**：
- `npx tsc --noEmit` 零错误
- 新类型定义不与现有类型冲突
- fast/deep 图运行时行为不受影响（仅类型扩展，无逻辑变更）

### 4.2 轮次 2: State 桥接 + 结构化输出

> **目标**：将类型定义连接到运行时 State + 实现 structuredOutputNode。依赖轮次 1 的类型定义。
>
> **Web 调研背景**：structuredOutputNode 调用 LLM 将专家自由文本转换为 ExpertClaim 结构体，是 Argumentation 阶段的最后一环。LangGraph 上 LLM 调用遵循标准结构——传入 state，返回 state update。

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 2.1 | AgentState 扩展 | `src/agents/state.ts` | 新增 massifIds / expertPlan / expertClaims / conflictReports / coordinationResult / aggregatedReport 字段；保留 massifId 向后兼容；添加双模互斥校验注释 | `tsc --noEmit` + 现有 deep 图回归（state 扩展不影响已有路径） |
| 2.2 | structuredOutputNode 实现 | `src/agents/nodes/structured-output.ts` | 接收 reasoning 输出的自由文本 + toolResult + evidence，调用 LLM 转换为 `ExpertClaim` 结构体（含 preconditions / hardConstraints / softConstraints / recommendedActions 提取） | `tsc --noEmit` + 单节点 mock 测试（给定模拟 reasoning 输出，验证产出 ExpertClaim 格式） |
| 2.3 | 编译验证 | tsconfig | `npx tsc --noEmit` | — |

**验收标准**：
- `npx tsc --noEmit` 零错误
- deep 图回归：单专家推理不受影响（AgentState 扩展向后兼容）
- structuredOutputNode 单测：给定自由文本输入 → 输出完整 ExpertClaim 结构体（含 preconditions / hardConstraints / softConstraints / recommendedActions）

### 4.3 轮次 3: ACA 核心逻辑

> **目标**：实现 conflictResolver（确定性检测）、aggregation（格式化）、coordinationDialogue（LLM 协调）三个节点。依赖轮次 2 的 State 和 ExpertClaim 类型。
>
> **设计关键**：`conflictResolver` 是**纯函数**——接收 `ExpertClaim[]`，返回 `ConflictReport[]`，**不调用 LLM**。`aggregation` 同样是纯格式化逻辑。**两者互不依赖，可并行实现**。`coordinationDialogue` 依赖前两者的输出格式，需串联。

#### 4.3a: conflictResolver（确定性冲突检测）

> **Web 调研参考**：借鉴 MAPF (Multi-Agent Path Finding) 的 [mutex propagation](https://ojs.aaai.org/index.php/ICAPS/article/view/6677) 技术。Mutex propagation 通过 planning graph 两层传播检测 agent 间互斥：① action mutex（opposing effects / one action deletes another's precondition）② proposition mutex（conflicting propositions / all achieving actions are pairwise mutex）③ reachability mutex（time-expanded MDD node pairs cannot coexist）。本项目场景虽非路径规划，但三类检测逻辑直接对应。

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 3a.1 | 前提互斥检测（proposition mutex） | `src/agents/nodes/conflict-resolver.ts` | 输入 `ExpertClaim[]`，对 pairwise 专家检查 precondition 是否互斥。内置反义词匹配表（降雨↔无降雨、高温↔低温、大风↔微风 等 6 组）。**纯算法，零 LLM 调用** | 单元测试≥4 条：① pest(晴朗无雨)↔weather(明天大雨)→HARD ② pest(风力<3级)↔weather(风力5-6级)→HARD ③ growth(土壤湿润追肥)↔soil(当前干旱)→HARD ④ water(需灌溉)↔weather(未来24h中雨)→SOFT |
| 3a.2 | 资源冲突检测（action mutex） | 同上文件 | 对每对专家，聚合 `recommendedActions[].resources[]`（资源ID为农机/人力/地块/水源/农资/时间窗口 6 类），按资源ID+时间分组计数，Σ > 可用上限则冲突 | 单元测试≥4 条：① pest+nutrition争用同一拖拉机#1同一天→HARD ② pest+water争用同一技术员同一下午→HARD ③ pest+growth同一地块同日打药+追肥→HARD ④ water+soil同一井超额用水→SOFT |
| 3a.3 | 时序矛盾检测（reachability mutex） | 同上文件 | 对每对专家，比较 `recommendedActions[].deadline` 与 `timing`（转换为时间区间），若区间不相交判定时序冲突 | 单元测试≥3 条：① pest(打药窗口周五结束)↔weather(降雨周五才开始)→HARD ② pest(除草剂有效期至周日)↔growth(安全间隔需7天仅剩5天)→HARD ③ nutrition(追肥6/10-15)↔water(灌溉6/14-16需间隔≥3天)→SOFT |
| 3a.4 | 执行标准不一致检测（method mutex） | 同上文件 | 对每对专家，检查 `recommendedActions[].method` 是否互斥。内置互斥方法对表（化学防治↔生物防治、漫灌↔滴灌 等 5 组）。**纯算法，零 LLM 调用** | 单元测试≥3 条：① pest(化学防治)↔pest另一地块(生物防治)→SOFT ② nutrition(化肥追施)↔soil(有机肥)→SOFT ③ water(漫灌)↔growth(滴灌)→SOFT |
| 3a.5 | severity 判定逻辑 | 同上文件 | HARD: 前提互斥(pest↔weather类)、资源冲突(农机/人力/地块类)、时序矛盾(deadline类)。SOFT: 资源冲突(水源/农资/时间窗口)、执行标准不一致 | 同上各测试覆盖 HARD/SOFT 分类 |

**验收标准**：
- 所有 4 类冲突场景的单元测试通过
- 零 LLM 调用（函数签名不接收 LLM/config 参数）
- `tsc --noEmit` 零错误

#### 4.3b: aggregation（格式聚合）

> 可与 4.3a 并行实现。

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 3b.1 | aggregationNode 实现 | `src/agents/nodes/aggregation.ts` | 接收 `ExpertClaim[]`（可能已含 coordinationDialogue 修订），按权重合并为 `AggregatedReport`：① 合并各专家 claim 为统一叙述 ② 聚合 recommendedActions 去重 ③ 标记未解决的 ConflictReport ④ 格式化输出 | `tsc --noEmit` + 单元测试（给定 2 个 ExpertClaim → 输出 AggregatedReport） |

**验收标准**：
- 给定 mock ExpertClaim[] → 输出 AggregatedReport 格式正确
- 合并逻辑：相同 action 去重，不同 action 保留
- `tsc --noEmit` 零错误

#### 4.3c: coordinationDialogue（约束松弛 + 协调对话）

> **依赖 4.3a 和 4.3b**，在两者完成后开始。
>
> **Web 调研参考**：约束松弛参考 [Lagrangian relaxation](https://wyeoh.github.io/assets/pdf/iat-GordonVYLAC12.pdf) 思想——将硬约束转为软约束，引入 penalty function。本项目采用**定向提问模式**（非开放式辩论）：识别冲突中的可变项，向相关专家定向提问，尝试在允许范围内调整参数使冲突可解。

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 3c.1 | coordinationDialogueNode 实现 | `src/agents/nodes/coordination-dialogue.ts` | 接收 `ConflictReport[]` + `ExpertClaim[]`，执行 4 步协调：① 识别可变项（softConstraints 中 penalty < 阈值的约束 + expertPlan 中可替换的 expert）② 生成定向提问（如 "weather: 后天有窗口?" "pest: 推迟24h风险?"）③ 解析修订建议 → 更新 revisedClaims ④ 尝试约束松弛求解（硬约束不可松，软约束按 penalty 排序逐次松） | `tsc --noEmit` + 单元测试（给定 mock ConflictReport[] → 输出 CoordinationResult） |
| 3c.2 | interactionPoint 增强（v2 更新） | `src/agents/nodes/interaction-point.ts` | 在现有 interactionPointDetectionNode 中增加 professional 图分支：检测 `coordinationResult.resolved === false` 时，调用 `interrupt({ conflict, optionA, optionB })` 暂停图执行。**注意**：当多个 expert 并行产生多个冲突时，需按 [LangGraph 官方规范](https://docs.langchain.com/oss/python/langgraph/interrupts#handling-multiple-interrupts) 使用 `{ interrupt_id: value }` 映射恢复 | `tsc --noEmit` |

**验收标准**：
- 给定 mock 冲突 → coordinationDialogue 生成定向提问（非开放式辩论）
- 约束松弛策略：软约束按 penalty 升序松弛，硬约束永不松
- interactionPoint 正确调用 `interrupt()` 并呈现结构化选项
- `tsc --noEmit` 零错误

**约束松弛策略**（v2 明确，解决 v1 P1-3）：

| 约束类型 | 松弛策略 | 松弛条件 | 终止条件 |
|---------|---------|---------|---------|
| SOFT `penalty < 0.3` | 自动松弛（忽略该约束） | penalty 最低的 soft constraint | 最多松弛 N/2 个（N=总冲突数） |
| SOFT `penalty ≥ 0.3` | 由 LLM 在协调对话中尝试修订 | penalty 从低到高逐次尝试 | 最多 2 轮协调对话 |
| HARD | **永不松弛** | — | 一旦所有 HARD 冲突无法通过定向提问解决 → 进入 interactionPoint |

### 4.4 轮次 4: 图组装 + 入口路由 + 集成验证

> **目标**：将轮次 1-3 的所有节点组装为 professionalGraph，并实现三图入口路由。**依赖轮次 1-3 全部完成**。
>
> **Web 调研参考**：LangGraph 的 [Send API](https://docs.langchain.com/oss/python/langgraph/graph-api#send) 支持从 conditional edge 返回 `[Send("node", state)]` 实现动态 fan-out，所有目标节点在同一 superstep 内并行执行。fan-out 后自动 fan-in，`ExpertClaim[]` 通过 `Annotated[list, operator.add]` reducer 汇聚。

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 4.1 | professionalGraph 编译 | `src/agents/index.ts` | `new StateGraph(AgentState)` 添加 professional 图专属节点（tool/retrieval/reasoning 复用 + structuredOutput/conflictResolver/coordinationDialogue/aggregation 新节点），使用 Send API 实现 fan-out → fan-in | `tsc --noEmit` + 图编译无异常 |
| 4.2 | intention 节点增强 | `src/agents/nodes/intention.ts` | professional 场景下产出 `expertPlan: Expert[]`（含 per-expert subIntent 拆分，从 state 中读取 massifIds[] 为每个 expert 绑定目标地块） | `tsc --noEmit` + 模拟 professional 场景验证 expertPlan 产出 |
| 4.3 | routeByIntent 扩展 professional 分支 | `src/agents/edges/conditional.ts` | 在 `routeByIntent` 中新增 professional 路径：thinkingLevel === "professional" → professionalGraph | `tsc --noEmit` |
| 4.4 | 入口路由 | `src/agents/index.ts` | 在 `createAgentGraph()` 中根据 thinkingLevel 分发到 fastGraph / deepGraph / professionalGraph | 编译成功 + 三种 graph 实例化通过 |
| 4.5 | 集成验证 | — | 模拟三种场景验证路由正确性：① 单专家 → deep 图 ② 汇总专家 → deep 图（isSummary） ③ 多专家冲突 → professional 图 | 三个场景路由正确，无异常 |

**验收标准**：
- `npx tsc --noEmit` 零错误
- 三个图均可编译（`StateGraph.compile()` 无异常）
- 场景 ①：pest_risk 单专家 → deep 图，RAG 证据链正常，回归零
- 场景 ②：weekly_report（isSummary）→ deep 图，工具数据为一等证据，无 "RAG 0条结果" 错误
- 场景 ③：pest_risk + weather + soil 三专家 → professional 图 fan-out 并行推理 → 各自产出 ExpertClaim → conflictResolver 检测冲突 → 无硬冲突时 aggregation 聚合 → verdict → response
- fast 图（问候/闲聊）不受影响
- 审计日志按图路由分离，ACA Graph 有独立 AgentAuditPhase

---

## 五、验收标准

- [x] Phase 1: weekly_report 场景：工具数据作为一等证据被 reasoning 消费，输出含趋势分析 + 异常标注 + 建议（✅ 2026-06-17）
- [ ] Phase 0: H5 chat 路由检测 `__interrupt__` 并输出 `event: interrupt` SSE 事件
- [ ] Phase 0: `POST /api/h5/agent/{threadId}/resume` 端点可用，`Command(resume)` 恢复流正常
- [ ] 轮次 1: `npx tsc --noEmit` 零错误，新类型定义不与现有冲突
- [ ] 轮次 2: deep 图回归零（单专家推理不受影响），structuredOutputNode 单测通过
- [ ] 轮次 3a: 4 类冲突检测 ≥14 条单元测试全部通过（前提互斥 4 条 + 资源冲突 4 条 + 时序矛盾 3 条 + 方法冲突 3 条），零 LLM 调用
- [ ] 轮次 3b: aggregationNode 单测通过
- [ ] 轮次 3c: coordinationDialogue 定向提问 + 约束松弛单元测试通过
- [ ] 轮次 4: 三图编译成功 + 三种场景路由正确
- [ ] 轮次 4: pest_risk + weather + soil 三专家场景端到端通过：fan-out 并行推理 → ExpertClaim → conflictResolver → coordinationDialogue → aggregation → verdict → response
- [ ] 前提互斥可正确检测 ≥4 种农业场景：pest打药↔weather降雨、pest无人机↔weather大风、growth追肥↔soil干旱、water灌溉↔weather降雨
- [ ] 资源冲突可正确检测 ≥4 种农业场景：拖拉机争用、技术员争用、同地块作业冲突、灌溉井超额
- [ ] 时序矛盾可正确检测 ≥3 种农业场景：打药窗口vs降雨时间、除草剂有效期vs安全间隔、追肥vs灌溉窗口重叠
- [ ] 执行标准不一致可正确检测 ≥3 种农业场景：化学vs生物防治、化肥vs有机肥、漫灌vs滴灌
- [ ] 硬冲突残留 → interactionPoint 生成，用户可见结构化选项，通过 LangGraph `interrupt()` + `Command(resume=...)` 恢复
- [ ] `npx tsc --noEmit` 零错误（全部轮次）
- [ ] fast 图（问候/闲聊）不受影响
- [ ] 审计日志按图路由分离，ACA Graph 有独立 AgentAuditPhase

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| V1 Plan | `.qoder/plans/2026-06/17/farm-agent-three-tier-reasoning-graph-plan-v1.md` | ✅ 现有 |
| ADD Route | `.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-add-route-v2.md` | 待生成 |
| Handoff | `.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-handoff-v2.md` | 待生成 |
| Review | `.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-v1.md` | 待生成 |
| Spec | `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md` | 待生成 |
| Tasks | `.qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md` | 待生成 |
| Checklist | `.qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md` | 待生成 |
| 决策管线架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` | 现有 |
| OS Kernel 架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/Agent-OS-Kernel-架构说明书.md` | 现有 |

---

## 附录 A: v1 → v2 变更对照

| 维度 | v1（2026-06-17） | v2（2026-06-25） |
|------|------------------|------------------|
| 实施路线 | 4 个粗粒度 Phase | **4 轮原子事务**（轮次 3 内部分解为 3a/3b/3c 可并行子任务） |
| 冲突类型 | 3 类 | **4 类**（新增"执行标准不一致"） |
| ExpertClaim | recommendedActions 不含 method | `method?: string` 用于检测执行标准不一致 |
| massifId/massifIds | 未定义双模语义 | 明确互斥规则：professional 图用 massifIds，deep 图用 massifId |
| 冲突检测算法 | 未提供参考 | 借鉴 MAPF mutex propagation（proposition/action/reachability mutex） |
| 约束松弛策略 | 未定义 | 3 级策略：penalty<0.3 自动松 / penalty≥0.3 LLM 协调 / HARD 不松 |
| interactionPoint | 未提多 interrupt 恢复 | 补充 LangGraph `{interrupt_id: value}` 映射恢复方案 |
| Web 调研 | 未做 | 完成：LangGraph interrupt/Command/Send API + MAPF mutex propagation + Lagrangian relaxation |
