# Farm-Server 地块 API 字段 & 字典类型同步 — plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。**不要**在 Plan 中写完整 TS 类型定义——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-massif-api-sync-v1
- **启动时间**: 2026-06-25T17:00:00.000Z
- **主导 AI**: Qoder
- **修订记录**:
  - 2026-06-25: 初版
- **触发来源**: Farm-Server 服务端 API 字段新增 + 字典类型新增
- **关联文档**:
  - API 文档: `docs/大田精准耕播智能决策系统/knowledge/02-规范/Farm-Server API接口文档（自动生成）.md`
  - 字典文档: `docs/大田精准耕播智能决策系统/knowledge/02-规范/dict-data-api.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | 说明 | 状态 |
|-----|-----------|--------|------|------|
| `docs/.../dict-data-api.md` | DOC | DOC_UPDATED | 新增 3 个字典类型汇总章节 | ✅ 已完成 |
| `src/lib/farm-api/massif.ts` | COMPONENT | MODIFY | MassifDTO 补全 qrCodeUrl/remark | ✅ 已完成 |
| `src/agents/tools/impl/farm-data-tools.ts` | COMPONENT | MODIFY | MASSIF_COLUMNS 补全 status/qrCodeUrl/remark | ✅ 已完成 |
| `src/app/api/h5/production-plan/land-analysis/route.ts` | API_ROUTE | MODIFY | DictCache preload 补全 farm_massif_status/type | ✅ 已完成 |
| `.qoder/plans/2026-06/25/farm-agent-massif-api-sync-plan-v1.md` | PLAN | CREATE | 本次同步 Plan | ✅ 已完成 |
| `.qoder/plans/index.md` | PLAN | MODIFY | 索引增量追加 | ✅ 已完成 |

---

## 背景

Farm-Server（`http://192.168.2.3:7101`）API 于 2026-06-25 更新了地块相关接口，farm-agent 需同步适配。

### 变更清单

**A. 地块基本信息接口新增 2 个字段**（影响 create/get/getMassif/update 四个端点）：

| 字段 | 类型 | 说明 |
|------|------|------|
| `qrCodeUrl` | string | 地块二维码 |
| `remark` | string | 备注 |

**B. 字典接口新增 3 个 dictType**（`GET /system/dict-data/type`）：

| dictType | 中文名 | 枚举值 |
|----------|--------|--------|
| `farm_massif_status` | 地块状态 | 0=正常耕种, 1=休耕, 2=建设占用, 3=废弃 |
| `farm_massif_moisture_type` | 土壤性质 | 0=沙土, 1=壤土, 2=粘土, 3=砂壤土, 4=粉壤土, 5=粘壤土, 6=重粘土 |
| `farm_massif_type` | 地块类型 | 0=耕地, 1=园地, 2=林地, 3=设施农用地, 4=草地, 5=撂荒地, 6=其他 |

---

## 影响范围

### Prisma Schema — 无需改动
- `main.prisma` / `nongqing.prisma`：地块数据来自外部 Farm-Server API，非本地存储，无 Massif 模型。

### 必须更新

| 文件 | 改动 | 原因 |
|------|------|------|
| `src/lib/farm-api/massif.ts` | `MassifDTO` 接口补全 `qrCodeUrl?: string` 和 `remark?: string` | 与 Farm-Server 响应字段对齐，否则 TS 类型不完整 |

### 可选更新（按需）

| 文件 | 建议 |
|------|------|
| `src/agents/tools/impl/farm-data-tools.ts` | `MASSIF_COLUMNS` 可新增 qrCodeUrl/remark 列 |
| `src/app/api/h5/production-plan/land-analysis/route.ts` | DictCache preload 列表可补全 `farm_massif_status` 和 `farm_massif_type`（当前业务未使用） |

### 文档 — 已完成

| 文件 | 状态 |
|------|------|
| `dict-data-api.md` | ✅ 已补全 3 个字典类型汇总 + 请求参数说明 |
| `Farm-Server API接口文档（自动生成）.md` | ✅ 已自动同步，qrCodeUrl/remark 已在 4 个端点出现 |

---

## 实施策略

本次为轻量同步，不走完整 ADD 9 阶段。改动范围小、影响面可控：

1. 补全 `MassifDTO` 接口（1 文件，2 行）
2. 独立于现有 ADD 流水线，不阻塞其他任务
