# AuditLog 绕过治理 — 禁止 prisma.auditLog.create 直调 — plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。**不要**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: audit-log-bypass-governance-v1
- **启动时间**: 2026-06-25T12:00:00.000Z
- **主导 AI**: Qoder
- **修订记录**:
  - 2026-06-25: 初版
  - 2026-06-25: Review 回流（P1-1~P1-4）：修正依赖图、Task 4 更新为 3 条 ESLint 规则、Task 2 补充 buffer 清理、Task 3 加入 agent-gateway-audit.ts
  - 2026-06-25: 联动回流 → `farm-agent-review-and-evidence-hardening-plan-v1.md`（append-runtime-finding.ts 收口 writeAuditLog + instrumentation.ts 全局边界捕获 + source 类型扩展）
  - 2026-06-25: 全部 Task 实施完成；instrumentation 链架构分层（append-runtime-finding-light.ts 零 I/O 入队 + append-runtime-finding.ts 动态 import I/O + proxy.ts 首次 flush）
  - 2026-06-25: 运行时发现队列增加两级缓存背压控制（L1 工作区 / L2 等待区 + 同源去重 + flush 并发上限），参数可配
- **触发来源**: runtime-review `streaming-event-bus-runtime-review-v1.md`
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/25/audit-log-bypass-governance-add-route-v1.md`
  - Spec: `.qoder/specs/audit-log-bypass-governance/spec.md`
  - Tasks: `.qoder/specs/audit-log-bypass-governance/tasks.md`
  - Checklist: `.qoder/specs/audit-log-bypass-governance/checklist.md`
  - Handoff: `.qoder/plans/2026-06/25/audit-log-bypass-governance-handoff-v1.md`
  - Review: `.qoder/reviews/streaming-event-bus-runtime-review-v1.md`（触发来源）
  - Plan Review: `.qoder/reviews/audit-log-bypass-governance-review-v1.md`（ADD-9 方案评审）
  - 裁决层契约: `docs/大田精准耕播智能决策系统/knowledge/01-架构/《裁决层-AuditLog写入契约》.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/agents/stream-bus.ts` | COMPONENT | COMPONENT_REFACTOR | 逐 token 调 streamBusAudit 写 DB | token 入内存 buffer，response_end flush 1 条 DB | ✅ 已实施 |
| `src/lib/stream-bus-logger.ts` | COMPONENT | COMPONENT_REFACTOR | 直调 prisma.auditLog.create，无 traceId | 全部走 writeAuditLog，自生成 traceId，新增 streamBusAuditBatch | ✅ 已实施 |
| `src/lib/agent-audit-logger.ts` | COMPONENT | COMPONENT_REFACTOR | writeAuditLog 仅接受 AgentAuditPhase | phase 改为 string；未设 traceId 自动兜底 auto_{uuid} | ✅ 已实施 |
| `src/lib/farm-server-client.ts` | COMPONENT | COMPONENT_REFACTOR | writeFsClientAudit 直调 prisma.auditLog.create | 改为调 writeAuditLog | ✅ 已实施 |
| `src/lib/auth/credential-store.ts` | COMPONENT | COMPONENT_REFACTOR | writeCredentialAudit 直调 prisma.auditLog.create | 改为调 writeAuditLog | ✅ 已实施 |
| `src/lib/append-runtime-finding.ts` | COMPONENT | COMPONENT_REFACTOR | 直调 prisma.auditLog.create | 改为动态 import writeAuditLog；拆分为 light（零 I/O 入队）+ heavy（I/O）两层；instrumentation.ts 仅引用 light 模块 | ✅ 已实施 |
| `src/lib/append-runtime-finding-light.ts` | COMPONENT | COMPONENT_CREATED | 无 | 新建：类型定义 + 两级缓存队列(enqueueRuntimeFinding) + 背压常量化参数 | ✅ 已实施 |
| `src/app/api/agent/chat/stream/route.ts` | API_ROUTE | COMPONENT_REFACTOR | auditTraceEvent 直调 prisma.auditLog.create | 改为调 writeAuditLog | ✅ 已实施 |
| `src/lib/layer2-callback.ts` | COMPONENT | COMPONENT_REFACTOR | 直调 prisma.auditLog.create | 改为调 writeAuditLog | ✅ 已实施 |
| `src/lib/agent-gateway-audit.ts` | COMPONENT | COMPONENT_REFACTOR | 直调 prisma.auditLog.create（traceId 已修复） | 改为调 writeAuditLog，收口 L2 | ✅ 已实施 |
| `eslint.config.mjs` | INFRA | INFRA_UPDATED | 无强制规则 | 新增 3 条 no-restricted-syntax：禁止 prisma.auditLog.* / 禁止 userId 硬编码 / 新审计文件警告 + instrumentation 链静态导入拦截 | ✅ 已实施 |
| `src/caijuehub/caijue.toml` | INFRA | INFRA_UPDATED | 无 AuditLog 写入契约条目 | 新增 [[caijue]] id=audit-log-write-contract，status=active | ✅ 已实施 |

---

## 一、背景与目标

### 1.1 问题现状

生产环境 `AuditLog` 表（rfai, 2026-06-25）：

| 指标 | 数值 |
|:--|:--|
| 总行数 | 30,077 |
| traceId IS NULL | **29,622 (98.5%)** |
| STREAM_BUS_EMIT_TOKEN | **27,288 (90.7%)** — 逐字符垃圾 |
| 正常 traceId | **455 (1.5%)** — 仅走 agentAudit() 路径 |

**根因链**：Plan `streaming-event-bus-v1` 设计"三通道输出(console+file+DB)"，`streamBusAudit()` 对全部事件（含 token）无条件写 DB。token 事件每字符触发一次 → 500 字符 = 500 条 INSERT。同时 `streamBusAudit()` 绕过 `setAuditContext()` 从不设 traceId。同理 `farm-server-client`、`credential-store`、`append-runtime-finding` 各写各的。**7 个模块 10 处直调 `prisma.auditLog.create`，无一通过 `writeAuditLog` 统一入口。**

### 1.2 目标

1. **F1**: token 逐字符落库 → 内存累积 + response_end 单条落库（完整原文）
2. **F2**: 全部 AuditLog 写入自动带 traceId（`writeAuditLog` 兜底 `auto_{uuid}`）
3. **F3**: 禁止未来绕过 — ESLint 规则 + `writeAuditLog` 成为唯一合法入口

---

## 二、方案选型

### 2.1 Token 写入策略

| 方案 | DB 行/请求 | 原文 | 复杂度 | 结论 |
|------|:--:|:--:|:--:|:--|
| 跳过 DB | 0 | ❌ | 低 | 否决 |
| 采样 | ≈N/10 | ❌ | 中 | 否决 |
| 截断 200 字 | 1 | ❌ | 低 | 否决 |
| **内存累积 + response_end 单条** | **1** | **✅** | **低** | ✅ |

**选型理由**：用户要求原文完整输出，存储压力通过定期归档解决。

### 2.2 traceId 策略

| 方案 | 改动 | 结论 |
|------|:--:|:--|
| 逐个模块加 traceId | 7 文件 | ❌ |
| **writeAuditLog 自动兜底** | **1 文件** | ✅ |

---

## 三、架构设计

### 3.1 统一审计写入入口（Facade）

> `writeAuditLog()` 是所有 AuditLog 写入的唯一入口函数。调用方只需传 action/targetType/targetId，traceId 由入口内部统一兜底。

```
所有模块
  │
  ▼
writeAuditLog(action, targetType, targetId, extra?, reason?)
  │
  ├─ currentTraceId 已设 → 沿用
  └─ currentTraceId 未设 → 自动生成 auto_{uuid}
  │
  ▼
prisma.auditLog.create({ ..., traceId })  ← 唯一合法写入点
```

### 3.2 Token 内存累积管道

```
LLM.stream()
  │
  ├── token "你" → buffer.push("你")  [仅文件日志]
  ├── token "好" → buffer.push("好")
  │   ...
  └── response_end → flush buffer
        │
        ▼
      streamBusAuditBatch(traceId, fullContent, tokenCount, durationMs)
        │
        ▼
      writeAuditLog("STREAM_BUS_EMIT_TOKEN_BATCH", ...)
```

### 3.3 绕过点关闭

| 原调用 | 改为 |
|:--|:--|
| `prisma.auditLog.create(...)` (7 模块 10 处) | `writeAuditLog(action, targetType, targetId, ...)` |
| `streamBusAudit(phase, detail)` 内部 | `writeAuditLog(phase, "STREAM_TRACE", phase, ...)` |

### 3.4 运行时发现队列背压控制

> `enqueueRuntimeFinding()` 被 instrumentation.ts 在启动期调用，无调用频率限制。
> 攻击风暴或异常循环时可能瞬时涌入大量发现，需两级缓存 + 去重 + 并发上限。

**两级队列架构**：

```
请求入队
  │
  ├─ L1 有空位 → 去重检查(source+errorMsg) → 入 L1（工作区，待落盘）
  │
  └─ L1 满 → 去重检查 → 入 L2（等待区，L1 清空后晋升）
                    │
                    └─ L2 满 → 丢弃最旧，记 warning

flushRuntimeFindings() 清空 L1 后：L2 → splice(0, L1_CAP) 批量晋升（再经一次去重）
```

**可配置参数**（定义于 `append-runtime-finding-light.ts` 常量区，AI 可直接修改）：

| 参数 | 默认值 | 说明 |
|------|:--:|------|
| `L1_CAP` | 50 | L1 工作区上限，超出转入 L2 |
| `L2_CAP` | 500 | L2 等待区上限，超出丢弃最旧 |
| `DEDUP_WINDOW_MS` | 60_000 | source+errorMsg 去重窗口（60s） |
| `FLUSH_CONCURRENCY` | 5 | flush 时最大并发写入数 |

**去重门禁**：`{ source, errorMsg }` 在 L1 或 L2 中已存在且在去重窗口内 → 跳过入队。

**设计理由**：
- 不丢弃有效发现（L2 缓冲），只丢弃 L2 溢出（极端情况）
- 同源去重防止同一种合约断裂点刷屏
- flush 并发上限防止落盘打爆 DB 和文件系统
- 参数常量化在模块头部，后续 AI 可直接按需调整

---

## 四、实施步骤

### Task 依赖图

```
Task 1 (agent-audit-logger 改造)
  │
  ├──→ Task 2 (stream-bus F1+F2)  ──┐
  │                                  ├── 可并行（Task 1 完成后）
  └──→ Task 3 (其余 6 个绕过模块) ──┘
                                    │
                                    ▼
                                Task 4 (ESLint 3规则)
                                    │
                                    ▼
                                Task 5 (caijue.toml 注册)
                                    │
                                    ▼
                                Task 6 (验证)
```

### Task 1: writeAuditLog 改造为统一写入入口

- `phase` 参数类型 `AgentAuditPhase` → `string`（接受外部模块 phase 字符串）
- 未设 `currentTraceId` 时自动生成 `auto_{uuid}`
- 不做其他改动

### Task 2: stream-bus F1 + F2

- `stream-bus.ts`:
  - 新增 `tokenBuffer: Map<traceId, {tokens[], startTime}>`
  - `response_start` 事件：初始化 `tokenBuffer[traceId] = { tokens: [], startTime: Date.now() }`
  - `token` 事件：推入 buffer（仅写文件日志，不写 DB）
  - `response_end` 事件：flush buffer → `streamBusAuditBatch()` → `writeAuditLog()`；`tokenBuffer.delete(traceId)`
  - `done` 事件：兜底清理 `tokenBuffer.delete(traceId)`（防止 response_end 未触发）
  - `error` 事件：兜底清理 `tokenBuffer.delete(traceId)`（防止连接异常断开）
- `stream-bus-logger.ts`:
  - 3 个函数内部 `prisma.auditLog.create` → `writeAuditLog()`
  - `StreamBusAuditPhase` 新增 `STREAM_BUS_EMIT_TOKEN_BATCH`
  - 新增 `streamBusAuditBatch(traceId, content, tokenCount, durationMs)`

### Task 3: 其余 6 个绕过模块改为 writeAuditLog

- `farm-server-client.ts`: `prisma.auditLog.create(...)` → `writeAuditLog(action, "FS_CLIENT", ...)`
- `credential-store.ts`: 同上，targetType="CREDENTIAL"
- `append-runtime-finding.ts`: 同上，targetType="BOUNDARY"
- `chat/stream/route.ts` `auditTraceEvent()`: 同上, targetType="STREAM_TRACE"
- `layer2-callback.ts`: 同上
- `agent-gateway-audit.ts`: 同上, targetType="AGENT_GATEWAY"（traceId 已在之前修复，仅收口 L2）

### Task 4: ESLint 3 条强制规则

`eslint.config.mjs` 新增三条 `no-restricted-syntax` 规则：
1. **禁止直调 `prisma.auditLog.*`**（error）：非 `agent-audit-logger.ts` 中任何 `prisma.auditLog.create/findMany/deleteMany/...` 报错
2. **禁止 userId 硬编码**（error）：`userId: "system"` / `userId: "ai-assistant"` 必须改为 `getLogUserId()`
3. **新审计/日志文件提醒**（warn）：文件名为 `*-audit.ts` / `*-logger.ts` 时警告走裁决层注册

### Task 5: caijue.toml 注册裁决层契约

在 `src/caijuehub/caijue.toml` 新增 `[[caijue]]` 条目：
- `id = "audit-log-write-contract"`
- `type = "contract"`
- 治理来源指向 `《裁决层-AuditLog写入契约》.md`
- `implementation = "src/lib/agent-audit-logger.ts::writeAuditLog"`
- `status = "pending"`（待 Plan 完成后改为 `active`）

**裁决层三层互锁**（本条目在 caijue.toml 中注册后生效）：
| 层级 | 机制 | 时机 |
|:--|:--|:--|
| 文档契约 | caijue.toml 注册 → AI 检索时自动加载本规则 | 设计时 |
| 编译阻断 | ESLint `no-restricted-syntax` | 编码时 |
| CI 验证 | `grep -rn 'prisma\.auditLog\.create' src/ --include='*.ts' \| grep -v agent-audit-logger` → 有输出即失败 | PR 时 |

### Task 6: 验证

- `npx tsc --noEmit`
- `npx eslint src/`
- 本地发一条聊天 → AuditLog 中 `STREAM_BUS_EMIT_TOKEN` 消失，`STREAM_BUS_EMIT_TOKEN_BATCH` 出现 1 条

---

## 五、验收标准

- [x] `tsc --noEmit` 零类型错误
- [x] `npx eslint src/` 零新增错误
- [x] 所有 `prisma.auditLog.create` 仅存在于 `agent-audit-logger.ts`
- [ ] 发一条聊天后 AuditLog 无 `STREAM_BUS_EMIT_TOKEN` 新增行
- [ ] 发一条聊天后 AuditLog 有 1 条 `STREAM_BUS_EMIT_TOKEN_BATCH`（含完整原文 + tokenCount + durationMs）
- [ ] 所有新 AuditLog 行 traceId 非空
- [x] `caijue.toml` 已注册 `audit-log-write-contract` 条目

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/25/audit-log-bypass-governance-add-route-v1.md` |
| Handoff | `.qoder/plans/2026-06/25/audit-log-bypass-governance-handoff-v1.md` |
| Review (触发) | `.qoder/reviews/streaming-event-bus-runtime-review-v1.md` |
| 裁决层契约 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《裁决层-AuditLog写入契约》.md` |
| caijue.toml | `src/caijuehub/caijue.toml` (新增条目: `audit-log-write-contract`) |
| **联动 Plan** | `.qoder/plans/2026-06/09/farm-agent-review-and-evidence-hardening-plan-v1.md`（append-runtime-finding.ts L2 收口 + instrumentation.ts 全局边界） |
| **两级队列设计** | `src/lib/append-runtime-finding-light.ts`（L1_CAP=50 / L2_CAP=500 / DEDUP_WINDOW_MS=60s / FLUSH_CONCURRENCY=5） |
