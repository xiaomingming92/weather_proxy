# farm-agent-ruifengyun-h5-api-v2-add-route-v3

> **定位**：Plan → ADD 九阶段执行映射。绑定：Plan `farm-agent-ruifengyun-h5-api-plan-v2.md` · Runtime Review `farm-agent-ruifengyun-h5-api-v2-runtime-review-v1.md`
>
> **模式**：重型（Heavyweight）——强制 spec sync + DPS/RAHS 闸门。
>
> **触发来源**：Runtime Review 发现 P0×3（F1 单位标准化 / F2 LLM 做算术 / F3 精度缺失），需要立即修复。
>
> **2026-06-26 增量**：Runtime 纠正 §7（SSE Stream Bus 优雅结束）已追加至父 Plan §7 + 父 Handoff §10，本 add-route 不重复记录。
>
> **2026-06-26 增量**：Runtime 纠正 §8（H5 Agent interrupt 暂停修复）已追加至父 Plan §8 + 父 Handoff §11。

---

## 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: 成本核算端点（cost-accounting）算法可靠性修复——服务端计算确定值 + 精度控制 + 单位标准化

Task Groups:
  Group A（算法修复）: route.ts 服务端计算 expectedRevenue
  Group B（精度约束）: schemas.ts 金额字段精度校验
  Group C（单位契约）: prompt 硬约束 + 代码注释统一

逐组业务价值判定:
  Group A（算法修复）: 不能用 — 服务端算术 + 精度校验 + prompt 约束缺一不可，单独交付任一组用户仍可能看到错误数据
  Group B（精度约束）: 不能用 — 同上
  Group C（单位契约）: 不能用 — 同上

判定结论: 需要 1 轮（1 个原子闭包）

第1轮（原子闭包1）: Task A+B+C — 业务功能: 成本核算端点三重正向兜底（算法+精度+单位）完整可用
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## Step 0：文档先行（Documentation First）

**目的**：Runtime Review 已生成，回流到本 add-route 后进入代码实现。

**输入**：
- Runtime Review: `.qoder/reviews/farm-agent-ruifengyun-h5-api-v2-runtime-review-v1.md`（P0×3 + P1×2 + P2×1）

**动作**：
1. Specs 三元组无需新建（本次为 bugfix，直接按 Review 修复方向实施）
2. 项目文档无需更新（本次改动不改变 API 契约，仅改变内部实现方式）
3. Runtime Review 已包含完整 F1~F6 发现及修复方向

**产出**：
- [x] 验证并更新项目状态：Runtime Review 就绪，无需新建 Specs
- [x] 验证并更新项目状态：项目文档无需更新（API 契约不变）
- [x] 验证并更新项目状态：Handoff 路径预留

### §0.8 DPS 闸门（上游文档质量校验）

> **重型强制**：调用 `check_dps` 验证上游文档质量。

待调用 `check_dps({ planKeyword: "farm-agent-ruifengyun-h5-api-v2" })`。

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**目的**：本次修复不新增审计阶段，复用现有 `H5_COST_ACCOUNTING` phase。

**动作**：
1. 现有 `AgentAuditPhase` 已包含 `H5_COST_ACCOUNTING`，无需扩展
2. 服务端计算新增一条审计日志：`agentAudit("H5_COST_ACCOUNTING", "服务端计算完成", { expectedRevenue, ... })`

**产出**：
- [x] 验证并更新项目状态：无需新增 AgentAuditPhase，复用现有

| Phase | 使用场景 | Task |
|-------|---------|------|
| `H5_COST_ACCOUNTING`（已有） | 服务端计算完成 + 精度告警 | Task A |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用。

**动作**：
1. `agentAudit("H5_COST_ACCOUNTING", ...)` 已存在于 route.ts，确认通道正常

**产出**：
- [x] 验证并更新项目状态：审计通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Runtime Review F1~F3 修复方向，逐文件修改代码。

**输入**：
- Runtime Review §1 发现列表
- [route.ts](file:///home/xmm/ai/farm-agent/src/app/api/h5/production-plan/cost-accounting/route.ts)
- [schemas.ts](file:///home/xmm/ai/farm-agent/src/app/api/h5/types/schemas.ts)
- [cost-accounting.ts prompt](file:///home/xmm/ai/farm-agent/src/agents/prompts/experts/cost-accounting.ts)

### §3.0 前置守卫（重型强制）

先调用 `check_add_route_status` 确认本文件有效。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| A | F2 服务端算术 | `src/app/api/h5/production-plan/cost-accounting/route.ts` | `agentAudit("H5_COST_ACCOUNTING", "服务端计算完成", { expectedRevenue })` | — | 无 | ✅ |
| B | F3 精度约束 | `src/app/api/h5/types/schemas.ts` | 无（结构变更） | — | 无 | ✅ |
| C | F1 单位契约 | `src/agents/prompts/experts/cost-accounting.ts` + `route.ts` header | 无（prompt/注释变更） | — | 无 | ✅ |

### 依赖拓扑

```
Task A（路由层）──→ 可并行
Task B（Schema层）──→ 可并行
Task C（Prompt层）──→ 可并行
```

### Task A: route.ts 服务端计算 expectedRevenue（F2）

**改动点**：
1. 在 LLM 调用前，服务端计算 `expectedRevenue = Math.round(plantingArea * yieldPerMu * pricePerKg * 100) / 100`
2. 将 `expectedRevenue` 作为已知值传入 LLM 上下文（告知 LLM 不要重算）
3. 修改 prompt 输出约束，LLM 只输出 `costItems` 和推算依据
4. 服务端组装完整响应：`expectedRevenue` + `costItems` → `totalCost` → `expectedProfit`
5. 添加审计日志

### Task B: schemas.ts 精度约束（F3）

**改动点**：
1. 在 `costAccountingSchema` 中为金额字段添加精度约束
2. `expectedRevenue`/`totalCost`/`expectedProfit` → `z.number().multipleOf(0.01)`
3. `costItem.amount` → 同上
4. 可选：`roi` → `z.number().finite()`

### Task C: prompt 硬约束 + header 注释统一（F1 + F6）

**改动点**：
1. cost-accounting.ts prompt：将单位描述从"参考区间"升级为"硬约束"，明确"金额四舍五入到2位小数"
2. route.ts header 注释：`grainPrice→pricePerKg`、`seedPrice→seedCostPerMu`

### 每个 Task 完成后（重型强制执行）

1. 验证 checklist [T] 项
2. 调用 `record_dev_operation`
3. 更新 `tasks.md` 逐项勾选

**产出**：
- [x] 验证并更新项目状态：全部 Task [T] 项通过（tsc exit 0）
- [x] 验证并更新项目状态：每个文件有 record_dev_operation（3 条已落库）
- [x] 验证并更新项目状态：check_spec_sync 一致（无 spec 三元组，无需同步）

---

## Step 4：编译 + RAHS 闸门

**动作**：
1. `npx tsc --noEmit`
2. 调用 `check_rahs({ planKeyword: "farm-agent-ruifengyun-h5-api-v2" })`

- [x] tsc 通过（exit code 0）
- [x] RAHS = 100 ≥ 90 🟢

---

## Step 5：合规检查

调用 `check_add_compliance` 扫描修改文件。

- [ ] 合规报告通过

---

## Step 8：收敛判断 + devlog + handoff

**动作**：
1. 收敛判断：全部 Task 完成 + tsc 通过 + RAHS ≥ 90 ✅
2. 调用 `record_dev_operation`（devlog）✅ 3 条已落库
3. 更新 handoff 引用 ✅ 见下方

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/app/api/h5/production-plan/cost-accounting/route.ts` | MODIFY | A + C | API_ROUTE | ✅ |
| `src/app/api/h5/types/schemas.ts` | MODIFY | B | SCHEMA | ✅ |
| `src/agents/prompts/experts/cost-accounting.ts` | MODIFY | C | PROMPT | ✅ |
