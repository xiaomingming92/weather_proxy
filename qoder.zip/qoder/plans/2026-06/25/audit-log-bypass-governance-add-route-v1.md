# audit-log-bypass-governance-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"。
>
- **绑定**：Plan: `audit-log-bypass-governance-plan-v1.md` · Spec: `.qoder/specs/audit-log-bypass-governance/spec.md` · Tasks: `.qoder/specs/audit-log-bypass-governance/tasks.md` · Review: `.qoder/reviews/audit-log-bypass-governance-review-v1.md` · Handoff: `audit-log-bypass-governance-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全。

**输入**：
- 上游 Review: `.qoder/reviews/streaming-event-bus-runtime-review-v1.md`
- Plan: `audit-log-bypass-governance-plan-v1.md`

**动作**：
1. 确认 Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md` ✅
2. 调用 `find_related_docs` 检索受影响的架构/规范文档 ✅（已执行）
3. 项目文档更新：裁决层契约《AuditLog写入契约》已存在；`eslint.config.mjs` 已提前实施 3 条 ESLint 规则；无需更新其他项目文档
4. Handoff 就绪（`audit-log-bypass-governance-handoff-v1.md` — 待 Step 8 生成）

**产出**：
- [x] 验证并更新项目状态：Specs 三元组路径确认
- [x] 验证并更新项目状态：项目文档已更新（裁决层契约 + eslint 已就绪，其余无需更新）
- [x] 验证并更新项目状态：Plan Review（ADD-9）已生成 → `.qoder/reviews/audit-log-bypass-governance-review-v1.md`
- [x] 验证并更新项目状态：Handoff 就绪（Step 8 生成）

### §0.8 DPS 闸门（上游文档质量校验）

调用 `check_dps({ planKeyword: "audit-log-bypass-governance" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |
| 70–84 | 🟡 | 回退补齐短板 |
| < 70 | 🔴 | 回退细化 Plan |

- [x] DPS 已通过（88 ≥ 85），可进入 Step 1

### 原子闭包三可性判定

**业务功能**: 所有 AuditLog 写入收敛到 writeAuditLog 统一入口，token 改为内存累积+response_end 单条落库，ESLint + caijue.toml 禁止未来绕过。

**逐组业务价值判定**:

| Task Group | 描述 | 独立可用？ | 理由 |
|:--|:--|:--:|:--|
| Task 1 | writeAuditLog 改造 | ❌ | 仅改入口签名，无外部模块接入，用户无感知 |
| Task 2 | stream-bus F1+F2 | ❌ | 仅解决流式 token，其余 6 模块仍绕过，不完整 |
| Task 3 | 其余绕过模块 | ❌ | 依赖 Task 1 的签名兼容 |
| Task 4 | ESLint 规则 | ❌ | 检测工具，不产生功能 |
| Task 5 | caijue.toml 注册 | ❌ | 元数据，不产生功能 |
| Task 1+2+3+4+5 | **全部收敛** | ✅ | token 不再逐字落库 + 全部模块走统一入口 + 编译期阻断绕过 → 完整治理闭环 |

**判定结论**: 需要 **1 轮**（1 个原子闭包）

**第1轮（原子闭包1）**: Task 1+2+3+4+5 — 业务功能: AuditLog 写入全量收敛 + token 内存累积 + 编译期阻断绕过
- 可独立提交 ✅ 可独立验证 ✅ 可独立审计 ✅ 可独立恢复 ✅

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的所有审计阶段。

**动作**：
1. 列出本次涉及的业务阶段
2. 在 `AgentAuditPhase` 联合类型中新增字面量

| Phase | 使用场景 | Task |
|-------|---------|------|
| `STREAM_BUS_EMIT_TOKEN_BATCH` | stream-bus token 批量落库 | Task 2 |

> 注意：writeAuditLog 的 `phase` 参数改为 `string` 后不再限制为 `AgentAuditPhase`，但仍需在联合类型中声明以保持 IDE 提示。

**产出**：
- [x] 验证并更新项目状态：本次审计阶段清单已同步到 tasks.md Step 1 区域

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用。

**动作**：
1. 确认 `writeAuditLog()` 接受任意 phase 字符串
2. 确认三通道输出正常（console + file + AuditLog 表）

**产出**：
- [x] 验证并更新项目状态：`writeAuditLog()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan 的 Task 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

**输入**：
- Plan §4 实施步骤
- `tasks.md` 的 Task 清单
- Handoff 的 ADD-7 审计策略表

### §3.0 前置守卫

调用 `check_add_route_status` 确认 add-route 文件有效存在。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | writeAuditLog 改造 | `agent-audit-logger.ts` | 无（仅签名+兜底逻辑），traceId 自动兜底 | — | 无 | ⬜ |
| 2 | stream-bus F1+F2 | `stream-bus.ts`, `stream-bus-logger.ts` | `streamBusAuditBatch()` → `writeAuditLog("STREAM_BUS_EMIT_TOKEN_BATCH", ...)` | `STREAM_BUS_EMIT_TOKEN_BATCH` | Task 1 | ⬜ |
| 3 | 其余绕过模块 | `farm-server-client.ts`, `credential-store.ts`, `chat/stream/route.ts`, `layer2-callback.ts`, `agent-gateway-audit.ts` | `prisma.auditLog.create` → `writeAuditLog(...)` | — | Task 1 | ⬜ |
| 4 | ESLint 规则 | `eslint.config.mjs` | 无（配置文件） | — | Task 1,2,3 | ⬜ |
| 5 | caijue.toml 注册 | `caijue.toml` | 无（配置文件） | — | Task 4 | ⬜ |
| 6 | 验证 | — | 编译+ESLint+功能验证 | — | Task 1,2,3,4,5 | ⬜ |
| 7 | 运行时发现队列背压 | `append-runtime-finding-light.ts`, `append-runtime-finding.ts`, `instrumentation.ts`, `proxy.ts` | L1/L2 两级队列 + 同源去重 + flush 并发上限；溢出记 warning | — | Task 6 | ✅ |

### 依赖拓扑

```
Task 1 (agent-audit-logger 改造)
  │
  ├──→ Task 2 (stream-bus F1+F2)  ──┐
  │                                  ├── 可并行（Task 1 完成后）
  └──→ Task 3 (其余 5 个绕过模块) ──┘
                                    │
                                    ▼
                                Task 4 (ESLint 3规则)
                                    │
                                    ▼
                                Task 5 (caijue.toml 注册)
                                    │
                                    ▼
                                Task 6 (验证)
                                    │
                                    ▼
                                Task 7 (队列背压)
```

**产出**：
- [x] 验证并更新项目状态：全部 Task 的 `[T]` 项通过，`tasks.md` 已完成项已逐项勾选
- [x] 验证并更新项目状态：每个文件有 `record_dev_operation` 记录

---

## Step 3.5：实现审查

- [x] checklist.md 全部 [T] 项通过
- [x] review-implementation.md 已生成（Plan Review 已覆盖）

---

## Step 4：审计数据验证

- [x] `tsc --noEmit` 通过
- [x] `npm run lint` 通过（零 error）
- [x] 阶段对称性验证通过
- [x] 失败路径审计等价验证通过

### §4.6 RAHS 闸门

- [x] RAHS 已通过（100 ≥ 90），可进入 Step 5

---

## Step 5：AI 自动合规检查

- [x] 合规报告已生成，违规项处理决策已记录（tsc 零错误 + eslint 零 error + grep 零绕过 + caijue.toml active）

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

### 收敛判断

全部 `[T]` 项通过 + `[R]` 清单已生成 + RAHS ≥ 90 → 功能收敛。

**动作**：
1. 收敛判断
2. RAHS 最终核定
3. tasks.md + checklist.md 全部完成项勾选
4. check_spec_sync 四者一致确认
5. Handoff 更新
6. Step 0 第二阶段：架构文档校准
7. ADD-7 回查确认

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/lib/agent-audit-logger.ts` | MODIFY | 1 | COMPONENT | ⬜ |
| `src/agents/stream-bus.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/lib/stream-bus-logger.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/lib/farm-server-client.ts` | MODIFY | 3 | COMPONENT | ⬜ |
| `src/lib/auth/credential-store.ts` | MODIFY | 3 | COMPONENT | ⬜ |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY | 3 | API_ROUTE | ⬜ |
| `src/lib/layer2-callback.ts` | MODIFY | 3 | COMPONENT | ⬜ |
| `src/lib/agent-gateway-audit.ts` | MODIFY | 3 | COMPONENT | ⬜ |
| `eslint.config.mjs` | MODIFY | 4 | INFRA | ⬜ |
| `src/caijuehub/caijue.toml` | MODIFY | 5 | INFRA | ⬜ |
