# add-qoder-integration-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。不要写完整实现细节——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: add-qoder-integration-v1
- **启动时间**: 2026-06-25T12:00:00+08:00
- **修订时间**: 2026-06-25（初版）→ 2026-06-25（Review 回流 v1：§3.2 词汇表 9→6类45条 + P0-2 devlog 双触发）→ 2026-06-25（v2：词汇独立路径 `.qoder/vocabulary/`，project_rules.md 改为引用）
- **主导 AI**: Qoder
- **前置 Plan**: 无（独立基础设施改造，不阻塞其他 Plan）
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/25/add-qoder-integration-add-route-v1.md`（✅ 已创建）
  - Handoff: `.qoder/plans/2026-06/25/add-qoder-integration-handoff-v1.md`（✅ 已创建）
  - Review: `.qoder/reviews/add-qoder-integration-review-v1.md`（✅ 已创建，P0-1+P0-2 已回流）
  - Specs: `.qoder/specs/add-qoder-integration/`（✅ 已创建 spec + tasks + checklist）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `.qoder/rules/project_rules.md` | RULE | RULE_MODIFIED | 无 ADD 词汇→操作映射表 | 新增 ADD 词汇映射表 + index.md 优先查询行为规则 | 待实施 |
| `.qoder/skills/session-init/SKILL.md` | SKILL | SKILL_MODIFIED | 仅查 AuditLog 恢复历史上下文，不读 index.md | Step 2 新增 index.md 加载 + Step 3 新增 Plan 拓扑注入 | 待实施 |
| `AGENTS.md` | RULE | RULE_MODIFIED | 仅有 ADD 工作流入口 + 关键 MCP 工具表 | 新增 ADD 词汇速查表 + 操作惯例速记 | 待实施 |
| `.qoder/agents/add-orchestrator.md` (新建) | AGENT | AGENT_CREATED | 不存在 | ADD 编排 Agent：自动检测 ADD 阶段 + 门禁调度 + 上下文衔接 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

**P0 — ADD 范式术语不在 LLM 的"母语"里**：

当用户说 "devlog 记录下"、"看下这个功能依赖哪个 plan"、"handoff 更新下" 时，LLM 不知道这些词在 ADD 范式中的确切含义和标准操作。它需要：
1. 全局搜索 `devlog` 关键词（浪费 token）
2. 或者等用户补一句 "就是 ADD 范式的 devlog"（打断心流）
3. 或者被迫调 MCP 工具才意识到这是 ADD 操作（被动学习）

**P0 — "查依赖"不走捷径**：

用户说"看下xx功能依赖哪个plan"时，LLM 不会先去读 `.qoder/plans/index.md`（119 个 Plan 的完整索引），而是全局搜索浪费大量 token。

**P1 — 门禁 Subagent 靠人调度**：

`add-flow-guardian` Subagent 已实现了完整的入口/出口门禁逻辑，但主 Agent 不会主动调它。每次都需要 prompt 提醒"现在应该调 Guardian 了"——门禁的存在对 LLM 不透明。

**根因**：ADD 范式的词汇表（devlog、handoff、add-route、DPS、RAHS……）和操作惯例（看 index.md 找 plan、Step 入口先调 get_project_context、完成 Step 后调 Guardian……）散落在 skill 文件、MCP 工具描述、plan 文档中，LLM 要"主动去翻"才知道。这些知识没有预埋到 Qoder 的 always-on 上下文中。

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | L1 词汇预埋：ADD 触发词 → 操作自动映射 | LLM 听到 "devlog"、"handoff"、"看依赖" 等词时零额外 prompt 执行正确操作 |
| P0 | L2 操作惯性：index.md 优先查询 | "看下xx功能依赖哪个plan" → LLM 优先读 index.md 精确匹配，无匹配才全局搜索 |
| P1 | L2 操作惯性：session-init 预载 ADD 上下文 | session-init 启动时自动读 index.md + 调 get_project_context，将会话上下文注入 |
| P2 | L3 Agent 编排：ADD 编排 Subagent | 门禁在 Step 边界自动触发，主 Agent 不需要手动调度 |

> **非目标（本次不做的）**：
> - 修改 add-paradigm SKILL 的 Step 流程（那是执行细节，本次聚焦词汇+惯性+编排三层基础）
> - 修改 add-flow-guardian 的检查逻辑（Guardian 本身已成熟，本次只改进调度方式）
> - 用 Qoder SDK 写外部脚本（本次全部用 Qoder 原生机制：Rules + Skills + Subagents）

---

## 二、方案选型

### 2.1 词汇注入方案对比

| 方案 | 覆盖面 | LLM 消费方式 | 维护成本 | 结论 |
|------|--------|-------------|---------|------|
| A: 增强 `project_rules.md`，新增 ADD 词汇映射表 | 全覆盖（always-on 规则） | 每次对话自动加载 | 低（单文件增量更新） | ✅ 推荐 |
| B: 新建独立 rule 文件 | 全覆盖 | 每次对话自动加载 | 中（多文件维护） | ❌ 过度拆分 |
| C: 写入 `AGENTS.md` | 全覆盖 | 每次对话自动加载 | 低 | ✅ 补充（速查表放 AGENTS.md） |

**选择方案 A + C**：`project_rules.md` 作为权威定义（含完整触发词→操作映射表），`AGENTS.md` 作为快捷速查表（精选高频触发词）。

### 2.2 index.md 优先查询方案对比

| 方案 | 侵入性 | 效果 | 结论 |
|------|--------|------|------|
| A: 在 always-on 规则中定义"查依赖→先读 index.md"行为 | 无（纯规则） | LLM 本能执行 | ✅ 推荐 |
| B: 写 MCP 工具封装 index.md 查询 | 高（需新 MCP 工具） | 需主动调用 | ❌ 过度工程化 |
| C: 在 session-init 中自动加载 index.md 到上下文 | 中（改 skill） | 每次会话自动就绪 | ✅ 补充（配合 A） |

**选择方案 A + C**：规则定义行为直觉 + session-init 自动注入，双保险。

### 2.3 Agent 编排方案对比

| 方案 | 自动化程度 | 与 Qoder 原生衔接 | 结论 |
|------|-----------|-------------------|------|
| A: 增强现有 `add-flow-guardian` 为编排 Agent | 中（Guardian 仍是 passive） | 好（已有 Subagent 框架） | ❌ Guardian 职责是门禁，不适合做编排 |
| B: 新建 `add-orchestrator` Subagent | 高（主动检测+调度） | 好（Qoder Subagent 原生） | ✅ 推荐 |
| C: 用 Qoder Agent SDK 写外部编排脚本 | 最高 | 差（需额外运行时） | ❌ 引入外部依赖 |

**选择方案 B**：新建 `add-orchestrator` Subagent，职责是主动检测当前 ADD 阶段并在正确时机调起 Guardian 和其他门禁工具。Guardian 保持被动门禁角色不变。

---

## 三、架构设计

### 3.1 整体三层模型

```
┌─────────────────────────────────────────────────────┐
│                    L3: Agent 编排                    │
│  add-orchestrator Subagent                          │
│  主动检测 ADD 阶段 → 调度门禁 → 上下文衔接           │
├─────────────────────────────────────────────────────┤
│                    L2: 操作惯性                      │
│  session-init 增强 + AGENTS.md 行为规则              │
│  自动加载 index.md + Plan 拓扑注入 + Step 自检       │
├─────────────────────────────────────────────────────┤
│                    L1: 词汇预埋                      │
│  project_rules.md ADD 词汇映射表                     │
│  devlog→写 devlog日志(走mcp) / handoff→读写handoff / ...         │
└─────────────────────────────────────────────────────┘
```

### 3.2 L1 词汇映射表结构（独立路径 v2）

**单一真值源**：`.qoder/vocabulary/add-governance-vocabulary.md` — 六类分类表格（A-F，~45条），P0/P1/P2优先级。

`project_rules.md` 中仅保留一行引用指向该文件。`AGENTS.md` 速查表同步指向新路径。

> **路径设计原则**：词汇与规则分离——`project_rules.md` 管 ADD 规则，`.qoder/vocabulary/` 管触发词映射。类比 `prompts/` 与 `experts/configs/` 的分离。

### 3.3 L2 session-init 增强流程

```
当前 session-init 流程:
  Step 1: 扫描 runtime-review
  Step 2: query_audit_logs({})   ← 仅查审计日志
  Step 3: 分析审计日志推断上下文
  Step 4: 构建上下文摘要
  Step 5: 开始正常对话

增强后:
  Step 1: 扫描 runtime-review
  Step 2: query_audit_logs({})
  Step 2.5: ✨ 读取 .qoder/plans/index.md → 提取活跃 Plan 清单
  Step 2.6: ✨ 调用 get_project_context({ scope: "add-state" }) → 获取 ADD 状态快照
  Step 3: 分析审计日志 + index.md + ADD 状态 → 推断完整上下文
  Step 3.5: ✨ 将 index.md 摘要和 ADD 待办项注入会话上下文
  Step 4: 构建上下文摘要（含 Plan 拓扑 + 待办项）
  Step 5: 开始正常对话
```

### 3.4 L3 add-orchestrator 编排 Agent 设计

```
add-orchestrator Subagent
  ├─ 阶段 0: 状态感知
  │   ├─ 读 index.md 获取活跃 Plan
  │   ├─ 调 get_project_context({ scope: "add-state" })
  │   └─ 读 add-route 推断当前 Step
  │
  ├─ 阶段 1: 入口门禁调度
  │   └─ 当前 Step 边界时 → 自动调 add-flow-guardian (入口模式)
  │
  ├─ 阶段 2: 出口门禁调度
  │   └─ Step 完成时 → 自动调 add-flow-guardian (出口模式)
  │
  └─ 阶段 3: 上下文衔接
      └─ 将门禁报告摘要反馈给主 Agent
```

**与 add-flow-guardian 的关系**：orchestrator 是"调度者"，guardian 是"执行者"。orchestrator 不重复 guardian 的检查逻辑，只负责在正确时机调起 guardian 并传递上下文。

### 3.5 数据流

```
用户说 "devlog 记录下"
     │
     ▼
L1 词汇映射触发 → LLM 本能知道: 写 devlog日志(走mcp) 到 .qoder/plans/{today}/
     │
     ▼
L2 session-init 已注入 → LLM 知道当前活跃 Plan 的日期目录
     │
     ▼
LLM 直接写 devlog日志(走mcp)，零额外 prompt

---

用户说 "看下气候带功能依赖哪个plan"
     │
     ▼
L1 词汇映射触发 → LLM 本能知道: 先读 index.md
     │
     ▼
L2 session-init 已注入 → index.md 内容已在上下文中
     │
     ▼
LLM 直接在 index.md 中匹配 "气候带" → 找到 farm-agent-climate-zone-lookup-plan-v1.md
     │
     ▼
返回结果，零全局搜索

---

主 Agent 完成 Step 3 代码编写
     │
     ▼
L3 add-orchestrator 检测到 Step 边界
     │
     ▼
自动调 add-flow-guardian (出口模式) → 门禁报告
     │
     ▼
门禁通过 → 进入 Step 3.5
门禁 BLOCKED → 反馈主 Agent 修复
```

---

## 四、实施步骤 + 依赖图

```
第1轮 (L1 词汇预埋) ── 无依赖，可先行
       │
       ▼
第2轮 (L2 操作惯性) ── 依赖第1轮（词汇是操作的基础）
       │
       ▼
第3轮 (L3 Agent 编排) ── 依赖第1+2轮（编排需要词汇+惯性作为底座）
```

### 第1轮: L1 词汇预埋 — ADD 词汇→操作映射

**原子事务目标**：让 LLM 对 ADD 术语产生本能反应，零额外 prompt。

**改动文件**:

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `.qoder/rules/project_rules.md` | 修改 | 在"理论→实践映射"表之前新增"ADD 词汇→操作映射"章节（按 §3.2 映射表） |
| `AGENTS.md` | 修改 | 在 ADD 工作流入口之前新增"ADD 词汇速查"章节（高频触发词精选） |

**关键设计**：
- 映射表以表格形式呈现（触发词 / LLM 默认操作 / 涉及文件或工具）
- 每个触发词描述必须精确到"读哪个文件"、"调哪个工具"、"写到哪里"
- `index.md 优先查询` 规则必须显式声明为 P0 行为

**高风险误区**：
- 禁止泛泛描述（如"devlog→写开发日志"），必须精确到路径和格式
- 禁止遗漏 `index.md 优先查询` 规则
- 禁止把映射表写成"建议"——必须用 MUST 语言

**验证标准**：
- [ ] `project_rules.md` 中存在"ADD 词汇→操作映射"章节，覆盖 §3.2 全部触发词
- [ ] `AGENTS.md` 中存在"ADD 词汇速查"章节
- [ ] 每个触发词映射到具体的文件路径或 MCP 工具调用

### 第2轮: L2 操作惯性 — session-init 增强 + index.md 注入

**原子事务目标**：session-init 不再只是"恢复历史"，而是"预载完整 ADD 上下文"。

**上游已完成**：第1轮词汇映射已就位。

**改动文件**:

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `.qoder/skills/session-init/SKILL.md` | 修改 | Step 2 新增 2.4/2.5 子步骤（读 index.md + 调 get_project_context）；Step 3 新增 Plan 拓扑推断；Step 4 上下文摘要含 Plan 清单 |

**核心改动**：
- Step 2.4: 读取 `.qoder/plans/index.md`，提取按日期分组的活跃 Plan 清单
- Step 2.5: 调用 `get_project_context({ scope: "add-state" })` 获取 ADD 状态快照
- Step 3: 在分析审计日志的同时，交叉 index.md 和 ADD 状态，推断完整的 Plan 拓扑
- Step 4: 构建的上下文摘要必须包含：活跃 Plan 列表 + 当前 ADD 阶段 + 待办项

**关键契约**：
- index.md 内容注入到上下文后，LLM 在任何"查依赖"场景中优先使用已注入的索引
- 如果 index.md 中无匹配，才 fallback 到全局搜索
- 不改变 session-init 的 Step 1（runtime-review 扫描）流程

**高风险误区**：
- 禁止只读 index.md 但不注入上下文（读了不用 = 白读）
- 禁止跳过 get_project_context 调用（仅靠 index.md 不够）
- 禁止改变 session-init 原有 Steps 的顺序

**验证标准**：
- [ ] session-init 执行后，LLM 上下文中包含 index.md 摘要
- [ ] "看下xx功能依赖哪个plan" → LLM 先尝试在已注入的 index.md 中匹配
- [ ] 无匹配时才触发全局搜索

### 第3轮: L3 Agent 编排 — add-orchestrator Subagent

**原子事务目标**：门禁在 Step 边界自动触发，主 Agent 零手动调度。

**上游已完成**：第1轮词汇映射 + 第2轮 session-init 上下文注入。

**改动文件**:

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `.qoder/agents/add-orchestrator.md` | 新建 | ADD 编排 Subagent 定义：阶段感知 + 门禁调度 + 上下文衔接 |

**核心设计**：

```
add-orchestrator 的工作模式：

1. 被动触发（主 Agent 在关键节点调起）:
   - 主 Agent 进入新 Step 时 → 调 orchestrator（入口模式）
   - 主 Agent 完成 Step 时 → 调 orchestrator（出口模式）

2. 主动感知（orchestrator 内部逻辑）:
   - 读 index.md + add-route 推断当前 ADD 阶段
   - 判断是否需要调 Guardian
   - 如需要 → 自动调 add-flow-guardian 并传递正确参数
   - 如不需要 → 返回当前阶段状态摘要

3. 上下文衔接:
   - 将 Guardian 门禁报告摘要反馈给主 Agent
   - BLOCKED 时给出明确的回退路径
   - PASS 时确认可以继续
```

**与 add-flow-guardian 的分工**：

| | add-orchestrator | add-flow-guardian |
|------|------|------|
| 职责 | 感知阶段 + 调度门禁 | 执行门禁检查 |
| 触发 | 主 Agent 在 Step 边界主动调起 | orchestrator 调起 |
| 输出 | 阶段状态 + 门禁调度结果 | 门禁报告 (PASS/FAIL/BLOCKED) |
| 修改文件 | 否（只读） | 否（只读） |

**关键契约**：
- orchestrator 不重复 guardian 的检查逻辑
- orchestrator 不修改任何文件
- orchestrator 的入口/出口模式与 guardian 的入口/出口门禁一一对应
- BLOCKED 时必须告诉主 Agent 回退到哪个 Step、执行什么操作

**高风险误区**：
- 禁止把 orchestrator 做成 guardian 的替代品（两者互补，非替代）
- 禁止 orchestrator 跳过 guardian 直接做门禁判断
- 禁止在 orchestrator 中硬编码 Step 检查逻辑（应该委托给 guardian）

**验证标准**：
- [ ] `add-orchestrator.md` 文件存在且包含完整的三阶段设计
- [ ] orchestrator 正确识别当前 ADD 阶段并调起 guardian
- [ ] 门禁 BLOCKED 时主 Agent 收到明确的回退路径

---

## 五、验收标准

### 第1轮验收

- [ ] `project_rules.md` 含 ADD 词汇→操作映射表（≥10 个触发词）
- [ ] `AGENTS.md` 含 ADD 词汇速查表
- [ ] "devlog 记录下" → LLM 知道写到 `.qoder/plans/{date}/` 下
- [ ] "看下xx功能依赖哪个plan" → LLM 先读 `index.md`

### 第2轮验收

- [ ] session-init 执行后 LLM 上下文中含 index.md 摘要
- [ ] session-init 自动调用了 `get_project_context({ scope: "add-state" })`
- [ ] "看依赖"类问题优先匹配已注入的 index.md 内容，无匹配才全局搜索

### 第3轮验收

- [ ] `add-orchestrator.md` Subagent 定义完整
- [ ] 主 Agent 在 Step 边界能调起 orchestrator
- [ ] orchestrator 正确委托 guardian 做门禁检查
- [ ] 门禁 BLOCKED 时返回明确的回退路径

---

## 六、后续扩展（本次不实施）

| 扩展方向 | 说明 | 依赖本次的 |
|---------|------|----------|
| Qoder Agent SDK 外部编排 | 用 SDK 构建独立于 IDE 的 ADD 编排服务 | 第3轮 orchestrator 基础 |
| 自动生成 devlog 草稿 | 根据 git diff 自动填充 devlog 模板 | 第1轮词汇映射 |
| 跨项目 Plan 关联 | index.md 扩展为多项目 Plan 索引 | 第2轮 session-init 增强 |

---

## 七、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/25/add-qoder-integration-add-route-v1.md`（待创建） |
| Handoff | `.qoder/plans/2026-06/25/add-qoder-integration-handoff-v1.md`（待创建） |
| Review | `.qoder/reviews/add-qoder-integration-review-v1.md`（待创建） |
| Spec | `.qoder/specs/add-qoder-integration/spec.md`（待创建） |
| Tasks | `.qoder/specs/add-qoder-integration/tasks.md`（待创建） |
| Checklist | `.qoder/specs/add-qoder-integration/checklist.md`（待创建） |
