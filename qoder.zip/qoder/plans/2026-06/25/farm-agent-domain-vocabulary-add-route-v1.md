# farm-agent-domain-vocabulary-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节。
>
> **模式**：重型（Heavyweight）。
>
> **绑定**：Plan: `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-plan-v1.md` · Spec: `.qoder/specs/farm-agent-domain-vocabulary/spec.md` · Tasks: `.qoder/specs/farm-agent-domain-vocabulary/tasks.md` · Handoff: `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-handoff-v1.md`（待创建）

---

## Step 0：文档先行

**动作**：
1. ✅ Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
2. ✅ `find_related_docs` 已调用，架构文档和 SSE 协议文档已增量更新
3. ✅ Handoff 待生成（Step 8 后）

**产出**：
- [x] Specs 三元组路径确认
- [x] 项目文档已更新（决策管线架构说明书 §1.2 + SSE 协议文档 v1.2）
- [ ] Handoff 待生成

### §0.8 DPS 闸门

调用 `check_dps({ planKeyword: "farm-agent-domain-vocabulary" })`。

- [ ] DPS ≥ 85 → 进入 Step 1

---

## Step 1：功能分析与审计阶段定义

| Phase | 使用场景 | Task |
|-------|---------|------|
| `DOMAIN_VOCABULARY_INJECT` | intention / reasoning / factory 注入领域触发词 | Task 3-5 |
| `TOOL_CONTEXT_RENDER` | factory.ts category 分区渲染 | Task 2.5a |
| `TOOL_PARAM_RESOLVE` | caijuehub 裁决层动态参数判断 | Task 2.5b |
| `PARAM_MISSING_EMIT` | SSE param_missing 事件 | Task 6.5 |

---

## Step 2：审计基础设施确认

- [ ] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | 创建 domain-triggers.ts | `vocabulary/domain-triggers.ts` | 无（类型定义） | — | 无 | ⬜ |
| 2 | 填充 14 专家触发词 | `vocabulary/domain-triggers.ts` | 无（数据填充） | — | Task 1 | ⬜ |
| 2.5a | Category 扩展 + 去擦除 | `analysis-context.ts` `types.ts` `reasoning.ts` `factory.ts` | `agentAudit("TOOL_CONTEXT_RENDER", ...)` | `TOOL_CONTEXT_RENDER` | Task 2 | ⬜ |
| 2.5b | 裁决层 | `caijuehub/strategies/resolve-tool-params.ts` | `agentAudit("TOOL_PARAM_RESOLVE", ...)` | `TOOL_PARAM_RESOLVE` | Task 2.5a | ⬜ |
| 3 | intention.ts 注入 | `prompts/intention.ts` | 无（prompt 修改） | — | Task 2 | ⬜ |
| 4 | reasoning.ts 注入 | `prompts/reasoning.ts` | 无（prompt 修改） | — | Task 2 | ⬜ |
| 5 | factory.ts 注入 | `prompts/experts/factory.ts` | `agentAudit("DOMAIN_VOCABULARY_INJECT", ...)` | `DOMAIN_VOCABULARY_INJECT` | Task 2 | ⬜ |
| 6 | 编译验证 | — | — | — | Task 2.5a+3-5 | ⬜ |
| 6.5 | SSE param_missing | `stream-bus.ts` `agents/index.ts` | `agentAudit("PARAM_MISSING_EMIT", ...)` | `PARAM_MISSING_EMIT` | Task 2.5b | ⬜ |

### 依赖拓扑

```
Task 1 → Task 2 → Task 2.5a → Task 2.5b
                    │              │
                    ├→ Task 3 ─────┤
                    ├→ Task 4 ─────┤
                    └→ Task 5 ─────┤
                                   │
                    Task 6 ←───────┤ (Task 2.5a + 3-5)
                                   │
                    Task 6.5 ←─────┘ (Task 2.5b)
```

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/agents/vocabulary/domain-triggers.ts` | CREATE | Task 1 | COMPONENT | ⬜ |
| `src/agents/vocabulary/domain-triggers.ts` | MODIFY | Task 2 | COMPONENT | ⬜ |
| `src/services/analysis-context.ts` | MODIFY | Task 2.5a | COMPONENT | ⬜ |
| `src/agents/prompts/types.ts` | MODIFY | Task 2.5a | TYPE | ⬜ |
| `src/agents/nodes/reasoning.ts` | MODIFY | Task 2.5a | COMPONENT | ⬜ |
| `src/agents/prompts/experts/factory.ts` | MODIFY | Task 2.5a+5 | COMPONENT | ⬜ |
| `src/caijuehub/strategies/resolve-tool-params.ts` | CREATE | Task 2.5b | COMPONENT | ⬜ |
| `src/agents/prompts/intention.ts` | MODIFY | Task 3 | COMPONENT | ⬜ |
| `src/agents/prompts/reasoning.ts` | MODIFY | Task 4 | COMPONENT | ⬜ |
| `src/agents/stream-bus.ts` | MODIFY | Task 6.5 | COMPONENT | ⬜ |
| `src/agents/index.ts` | MODIFY | Task 6.5 | COMPONENT | ⬜ |
