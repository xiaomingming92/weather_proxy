# farm-agent — 3 轮原子事务交接手册

> **用途**：每个新对话开始时，把对应轮次章节粘贴给 LLM。它需要明确自己正在执行哪个原子工程事务、上游事务已经提交了什么、当前事务的文件边界是什么、验证标准是什么、完成后记录哪些 ADD-7 审计。

---

## 全局元信息

- **父 Plan**: [add-qoder-integration-plan-v1.md](./add-qoder-integration-plan-v1.md)
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 4 个（3 修改 + 1 新建）
- **轮次数**: 3 轮局部闭包
- **拆分原则**: 以功能层次为主——L1 词汇是 L2 惯性的语义基础，L2 惯性是 L3 编排的上下文基础。每轮可独立验证、独立交付业务价值。

```text
第1轮 (L1 词汇预埋) ── project_rules.md 六类词汇映射表 + AGENTS.md 速查表
       │
       ▼
第2轮 (L2 操作惯性) ── session-init SKILL 增强
       │
       ▼
第3轮 (L3 Agent 编排) ── add-orchestrator Subagent 创建
```

---

## 原子事务边界说明

本轮 Plan 为纯 Qoder 配置改造（`.qoder/` 下 Rules/Skills/Agents 文件），不涉及 `src/` 代码。三层各自独立：

- **第1轮（L1）** 独立交付后，LLM 能本能响应 devlog/handoff/DPS 等术语 → 独立业务价值
- **第2轮（L2）** 独立交付后，session-init 能自动注入 index.md + ADD 状态 → 独立业务价值（依赖 L1 词汇但可独立验证）
- **第3轮（L3）** 独立交付后，门禁在 Step 边界自动触发 → 独立业务价值（依赖 L1+L2 但可独立验证）

### 交接手册与 spec 的优先级

- 本 handoff 是新对话的入口索引，负责说明轮次位置、上下游依赖、文件边界、高风险误区、恢复关键词和审计闭环。
- 具体实现细节以对应 `.qoder/specs/add-qoder-integration/spec.md`、`tasks.md`、`checklist.md` 为准。
- 如果 handoff 摘要与 spec/tasks/checklist 存在颗粒度差异，以 spec/tasks/checklist 为准，不允许按 handoff 的简写自行简化实现。

---

## <第1轮> L1 词汇预埋 — 六类 ADD 词汇→操作映射

### 你当前的位置

你是第 1 轮。上游无依赖，从当前代码基线开始。

### 上游已完成

无（第1轮是起点）。

### 原子事务目标

将 ADD 范式的 85+ 个专有词汇按六类分类（文档类型/ADD阶段/门禁/MCP工具/Skills/核心概念），预埋到 always-on 规则中，使 LLM 听到触发词时零额外 prompt 执行正确操作。

### spec 文件

- `.qoder/specs/add-qoder-integration/spec.md`
- `.qoder/specs/add-qoder-integration/tasks.md`（Task 1 + Task 2）
- `.qoder/specs/add-qoder-integration/checklist.md`（Task 1 + Task 2 部分）

### 你要改的文件（2 个：0 新建 + 2 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `.qoder/rules/project_rules.md` | 修改 | 在"理论→实践映射"表之前新增"ADD 词汇→操作映射"六类分类表（~45条，P0/P1/P2优先级） |
| `AGENTS.md` | 修改 | 在 ADD 工作流入口之前新增"ADD 词汇速查"章节（13个P0高频词） |

### 核心设计

六类分类体系：
```
A. 文档类型（11个）— Plan/Spec/Review/Handoff/add-route/devlog/index.md...
B. ADD 阶段（11个）— Step 0~8/原子闭包/三可性
C. 门禁/闸门（6个）— DPS/RAHS/Guardian/BLOCKED/Review回流
D. MCP 工具（8个高频）— get_project_context/query_audit_logs/record_dev_operation...
E. Skills/Subagents（5个）— session-init/add-paradigm/add-flow-guardian...
F. 核心概念（13个）— 裁决层/agentAudit/ADD-3/ADD-4/ADD-5/收敛/阶段对称...
```

### 关键契约细化

- P0 词汇必须 ≥ 15 条，P1 ≥ 20 条
- devlog 条目必须含双触发说明（用户说 + Step 8 自动）
- Step 8 条目必须含三步序列（devlog→handoff→架构回看）
- 每类独立表格，含优先级列

### 高风险误区

- 禁止遗漏 devlog 的 Step 8 自动触发说明
- 禁止遗漏 Step 8 的三步闭环序列
- 禁止把 `agentAudit`（ADD-7 代码审计函数）与 `ADD-3`（最小可观测单元）/ `ADD-4`（三通道）/ `ADD-5`（业务日志metadata）混为一谈
- 禁止只写速查表不写完整映射表

### 验证标准

- [x] project_rules.md 六类词汇表完整（A-F 全覆盖）
- [x] 每类含独立表格，有优先级列（P0/P1/P2）
- [x] P0 词汇 ≥ 15 条，P1 词汇 ≥ 20 条
- [x] devlog 条目含双触发说明
- [x] Step 8 条目含三步序列
- [x] AGENTS.md 速查表含 ≥ 10 个 P0 高频词
- [x] 表格 Markdown 语法正确

---

## <第2轮> L2 操作惯性 — session-init 增强

### 你当前的位置

你是第 2 轮。上游第1轮已完成六类词汇映射表 + 速查表。

### 上游已完成

- `project_rules.md` 含六类 ADD 词汇→操作映射表
- `AGENTS.md` 含 ADD 词汇速查表

### 原子事务目标

增强 session-init SKILL，使其在新对话启动时自动加载 `.qoder/plans/index.md` 并调用 `get_project_context`，将 Plan 拓扑和 ADD 待办项注入会话上下文。

### spec 文件

- `.qoder/specs/add-qoder-integration/spec.md`
- `.qoder/specs/add-qoder-integration/tasks.md`（Task 3）
- `.qoder/specs/add-qoder-integration/checklist.md`（Task 3 部分）

### 你要改的文件（1 个：0 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `.qoder/skills/session-init/SKILL.md` | 修改 | Step 2 新增 2.4（读 index.md）+ 2.5（调 get_project_context）；Step 3 交叉分析增强；Step 4 上下文摘要含 Plan 拓扑 |

### 核心设计

```
session-init 增强后流程:
  Step 1: 扫描 runtime-review
  Step 2: query_audit_logs({})
  Step 2.4: ✨ 读取 .qoder/plans/index.md → 提取活跃 Plan 清单
  Step 2.5: ✨ 调用 get_project_context({ scope: "add-state" })
  Step 3: 审计日志 + index.md + ADD 状态 → 交叉推断上下文
  Step 4: 上下文摘要含 Plan 拓扑 + 待办项
  Step 5: 开始正常对话
```

### 关键契约细化

- 新增步骤不改变原有 Steps 编号顺序
- index.md 不存在 → 跳过，不阻断流程
- get_project_context 不可用 → 跳过，不阻断流程

### 高风险误区

- 禁止只读 index.md 但不把内容注入上下文摘要
- 禁止新增步骤编号与原有 Steps 冲突
- 禁止因为 index.md 缺失或 MCP 不可用而阻断 session-init

### 验证标准

- [x] Step 2.4: 读取 index.md 子步骤已添加
- [x] Step 2.5: 调用 get_project_context 子步骤已添加
- [x] Step 3: 交叉分析逻辑已增强
- [x] Step 4: 上下文摘要含 Plan 拓扑
- [x] 新增步骤编号不与原有 Steps 冲突

---

## <第3轮> L3 Agent 编排 — add-orchestrator Subagent

### 你当前的位置

你是第 3 轮。上游第1轮完成词汇映射，第2轮完成 session-init 增强。

### 上游已完成

- `project_rules.md` 含六类词汇映射表
- `AGENTS.md` 含词汇速查表
- `session-init/SKILL.md` 已增强（自动加载 index.md + get_project_context）

### 原子事务目标

创建 `add-orchestrator` Subagent，在 ADD 流程的 Step 边界自动感知阶段、调度门禁检查、衔接上下文。不重复 `add-flow-guardian` 的检查逻辑。

### spec 文件

- `.qoder/specs/add-qoder-integration/spec.md`
- `.qoder/specs/add-qoder-integration/tasks.md`（Task 4）
- `.qoder/specs/add-qoder-integration/checklist.md`（Task 4 部分）

### 你要改的文件（1 个：1 新建 + 0 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `.qoder/agents/add-orchestrator.md` | 新建 | ADD 编排 Subagent：阶段 0 状态感知 + 阶段 1 入口门禁调度 + 阶段 2 出口门禁调度 + 阶段 3 上下文衔接 |

### 核心设计

```
add-orchestrator 与 add-flow-guardian 的分工:

┌─ add-orchestrator ────────────────────────┐
│ 阶段 0: 读 index.md + get_project_context  │
│          + 读 add-route → 推断当前 Step    │
│ 阶段 1: Step 边界 → 判断是否需要入口门禁    │
│ 阶段 2: Step 完成 → 判断是否需要出口门禁    │
│ 阶段 3: Guardian 结果 → 摘要反馈主 Agent    │
│                                             │
│ Step 8 特殊提醒:                             │
│   验收通过 → 三步闭环                       │
│   ①写 devlog日志(走mcp) → ②更新 handoff               │
│   → ③架构文档回看                           │
└─────────────────────────────────────────────┘
         │ 调度
         ▼
┌─ add-flow-guardian ────────────────────────┐
│ 入口门禁: Step N 准入条件检查                │
│ 出口门禁: Step N 产出验证                    │
│ 返回: PASS / FAIL / BLOCKED                 │
└─────────────────────────────────────────────┘
```

### 关键契约细化

- orchestrator 不重复 guardian 的检查逻辑
- orchestrator 不修改任何文件
- 入口/出口门禁分别处理，主 Agent 必须明确告知是哪种
- Step 8 出口通过后必须提醒验收闭环三步（devlog + handoff + 架构回看）

### 高风险误区

- 禁止 orchestrator 直接做门禁判断（必须委托 Guardian）
- 禁止在 Step 8 出口通过后不提醒验收闭环三步
- 禁止跳过阶段 0 状态感知

### 验证标准

- [x] `.qoder/agents/add-orchestrator.md` 文件存在
- [x] YAML frontmatter 含正确的 tools 和 mcpServers 声明
- [x] 阶段 0-3 逻辑完整
- [x] 不重复 add-flow-guardian 的检查逻辑
- [x] Step 8 验收闭环提醒已内置

---

## 每轮收敛判定补充规则

### checklist 证据要求

每轮结束时，`checklist.md` 必须满足以下条件才算收敛：

- [ ] **全部项已勾选**（不得有空勾选、不得有"推测通过"）
- [ ] **每项勾选有可验证证据**：代码项附文件路径 + 行号引用
- [ ] **未执行项诚实保留**：无法在当前轮次验证的 [R] 项，保留为未勾选

### 收敛声明规则

当前轮次 AI 不得自行声明"本轮已收敛"并直接进入下一轮。收敛声明只能由开发者或 Review AI 做出。

---

## 附录：每轮启动模板

新对话开始时，直接把下面内容 + 对应轮次章节粘贴给 LLM：

```text
## 上下文

你在执行 farm-agent ADD-Qoder 集成的 [第N轮]。
上游 [第1轮~第N-1轮] 已完成。
先读 .qoder/plans/2026-06/25/add-qoder-integration-handoff-v1.md 的 <第N轮> 章节。

## 启动步骤（按顺序）

1. 执行 session-init SKILL
2. 执行 add-paradigm SKILL
3. 读 .qoder/specs/add-qoder-integration/spec.md
4. 读 .qoder/specs/add-qoder-integration/tasks.md
5. 读 .qoder/specs/add-qoder-integration/checklist.md
6. 按 tasks.md 顺序执行代码修改
7. 每完成一个 Task：读 checklist.md → 逐项验证 → 附可验证证据 → 勾选

## 关键提醒

- 当前执行的是 [第N轮]/3
- 当前轮次是一个原子工程事务，不允许拆到下一轮补齐
- 本轮仅修改 .qoder/ 下配置文件，不涉及 src/ 代码
- 禁止自行声明收敛
```
