# farm-agent-domain-vocabulary-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。不要写完整实现——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-domain-vocabulary-v1
- **启动时间**: 2026-06-25T12:00:00+08:00
- **修订时间**: 2026-06-25 v1.1 → v2 → v3 → v4 → **v5（最终方案：§3.5 三层职责边界 + caijuehub 裁决层动态参数决策）**
- **主导 AI**: Qoder
- **前置 Plan**: `add-qoder-integration-plan-v1.md`（L1 词汇预埋已完成，本次复用其方法论但面向不同消费者）
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-add-route-v1.md`（待创建）
  - Handoff: `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-handoff-v1.md`（待创建）
  - Review: `.qoder/reviews/farm-agent-domain-vocabulary-review-v1.md`（待创建）
  - Specs: `.qoder/specs/farm-agent-domain-vocabulary/`（待创建）

---

## 一、背景与目标

### 1.1 问题现状

**P0 — 面向用户的 LLM 缺乏领域"本能"**：

farm-agent 运行时管线（intention → reasoning → response → 14 专家）中的 LLM 目前靠**手写规则 + 注册表**做领域匹配：

- `intention.ts` 手工定义了 7 种 intent 类型的语义描述
- `ANALYSIS_EXPERTS` 注册表定义了 14 个专家的 `inputSchema`/`outputSections`/`evidenceFilter`
- `resolve-discipline-codes` 裁决器做 GB/T 13745 学科分类

但这些是**代码层匹配**，不是 LLM 的**语义本能**。当用户说"最近虫害严重，帮我分析下风险"，LLM 不知道"虫害"→ pest-risk 专家、"风险分析"→ 检索 pest_management collection。

**P1 — ADD 词汇不应注入用户 LLM**：

ADD 是治理 AI 的范式（caijue.toml、agentAudit、DPS/RAHS、PolicyUpdateLoop），面向用户的 LLM 不需要理解这些概念。把 ADD 词汇注入用户 LLM 是信息噪音。

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | 建立领域触发词汇表（4 类） | LLM 能根据用户自然语言本能匹配专家/RAG/Tool/学科 |
| P0 | 注入到运行时 LLM 的 system prompt | intention / reasoning / response / 16 专家共享同一份领域词汇上下文 |
| P1 | 与已有注册表双向同步 | 词汇表变化 → 注册表更新；注册表新增专家 → 词汇表自动补词 |
| P2 | 为未来治理 AI 接入预留接口 | 领域触发词汇表与 ADD 词汇表物理隔离，但共享六类分类框架 |

> **非目标**：不修改 ADD 治理词汇表（`project_rules.md` 中的六类映射）。ADD 词汇是给 IDE 侧 LLM + 未来治理 AI 用的，领域词汇是给用户侧 LLM 用的，两者物理隔离。

---

## 二、方案选型

### 2.1 词汇注入方案

| 方案 | 维护成本 | LLM 消费方式 | 与注册表同步 | 结论 |
|------|---------|-------------|------------|------|
| A: 集中词汇文件 `src/agents/vocabulary/domain-triggers.ts` | 低（单文件维护） | factory.ts 集中读取注入 | 无（独立于注册表，有意解耦） | ✅ 推荐 |
| B: 在每个 expert config 中加 `triggerKeywords` 字段 | 高（14 文件分散，改一个词要改多个 config） | expert 独立消费 | 天然同步（但触发词不是 config 私有属性—"虫害"同时映射 pest_risk + land-analysis） | ❌ 散落 14 个文件 + 触发词与 config 职责边界模糊 |
| C: 纯 LLM 推断（不做词汇表） | 零 | 全靠 LLM 猜 | 无 | ❌ 不可靠 |

### 2.2 选型理由

**选择方案 A**：`src/agents/vocabulary/domain-triggers.ts` 集中管理。

- **单一数据源**：一个文件维护 14 个专家的全部触发词 + collection 提示，改一个词只需改一处
- **与注册表解耦**：注册表 (`ANALYSIS_EXPERTS`) 只管 expert 的运行时配置（domain/label/schema），领域触发词独立管理。新增 expert 时注册表 + domain-triggers 各加一条，不互相依赖
- **职责清晰**：`factory.ts` 从 `DOMAIN_TRIGGERS.expertTriggers[config.id]` 读取，不要求每个 config 文件自行携带触发词字段
- **工具调用侧**：LLM 靠 `tool()` 的 `description` 做 tool calling 匹配，但匹配成功后需知道已有的上下文参数值（projectId / massifIds / 时间）来填充入参。这些值已存在于 AgentState → runtimeInputs，经 factory.ts 的 `【运行时参数】` 区块注入 prompt。本次类型修复：`Record<string, unknown>` → `Record<string, RuntimeInputEntry>`，不新增注入逻辑
- **与路径原则一致**：`.qoder/vocabulary/` 管 IDE 侧 ADD 治理词汇，`src/agents/vocabulary/` 管运行时侧领域触发词汇

### 2.3 四类词汇的归属

| 类别 | 已有基础设施 | 本次做什么 |
|------|------------|----------|
| **专家触发词** | `experts/configs/*.config.ts` 有 `description` | 新增 `triggerKeywords: string[]` 字段 |
| **RAG Collection 词** | `evidenceFilter` 字段已有过滤条件 | 从 `evidenceFilter` 自动提取 + 补充 `collectionHints` |
| **工具触发词** | `tool()` description 已足够匹配 | **类型修复**：`runtimeInputs: Record<string, unknown>` → `toolContext: Record<string, RuntimeInputEntry>`（Prompt 层重命名 + 去类型擦除）。工具调用上下文已存在于 AgentState，经 factory.ts `【运行时参数】` 区块注入 prompt，专家模式与触发词模式共享同一数据源，不新增注入逻辑。 |
| **工具参数缺失响应** | — | **新增** `param_missing` SSE 事件：`stream-bus.ts` 新增事件类型，`toolNode` 中 ZodError → emit `param_missing`，前端可渲染"需要补充信息"卡片。 |
| **GB/T 13745 学科词** | `discipline-resolver.ts` 已实现 | 不需要额外做（已有三路裁决器） |

---

## 三、架构设计

### 3.1 两类词汇的隔离

```
┌─────────────────────────────────────────────────────────┐
│                   L1 词汇预埋体系                         │
│                                                          │
│  ┌─ ADD 治理词汇（project_rules.md）────────────────┐   │
│  │ 消费者: IDE 侧 LLM + 未来治理 AI                  │   │
│  │ devlog/handoff/DPS/RAHS/caijue/agentAudit...      │   │
│  │ 六类: 文档/阶段/门禁/MCP/Skills/核心概念           │   │
│  └──────────────────────────────────────────────────┘   │
│                                                          │
│  ┌─ 领域触发词汇（experts/configs/*.config.ts）─────┐   │
│  │ 消费者: farm-agent 运行时用户 LLM                  │   │
│  │ "虫害风险"/"品种对比"/"成本核算"...                │   │
│  │ 注入点: intention / reasoning / response / 16专家  │   │
│  └──────────────────────────────────────────────────┘   │
│                                                          │
│  两者物理隔离，互不污染                                  │
└─────────────────────────────────────────────────────────┘
```

### 3.2 领域触发词汇文件（集中管理 v2）

**路径**: `src/agents/vocabulary/domain-triggers.ts`

```typescript
// domain-triggers.ts — 领域触发词集中管理

export interface DomainTriggerMap {
  /** expertId → 触发词列表 */
  expertTriggers: Record<string, string[]>
  /** expertId → RAG collection 提示 */
  collectionHints: Record<string, string[]>
}

export const DOMAIN_TRIGGERS: DomainTriggerMap = {
  expertTriggers: {
    pest_risk: ["虫害", "害虫", "病虫害", "虫情", "杀虫", "防治"],
    crop_compare: ["品种对比", "品种选择", "哪个品种好", "品种特性"],
    weather_impact: ["天气影响", "气象", "降雨", "干旱", "冻害"],
    // ... 其余 11 个专家
  },
  collectionHints: {
    pest_risk: ["pest_management", "crop_protection"],
    crop_compare: ["crop_science", "variety_trials"],
    // ...
  },
}
```

> **路径原则**：与 ADD 治理词汇对称——`.qoder/vocabulary/` 管 IDE 侧，`src/agents/vocabulary/` 管运行时侧。`factory.ts` 从 `DOMAIN_TRIGGERS` 读取注入，14 个 config 文件无需改动。

### 3.3 运行时注入点

```
intention.ts
  └─ buildContextBlock() 
       └─ 追加 triggerKeywords 汇总:
          "可用的专家分析域: 虫害(pest_risk) 品种(crop_compare) 成本(cost_accounting)..."

reasoning.ts
  └─ build() 
       └─ 追加领域词汇上下文:
          "你是农业分析助手，运行在农场智能决策系统中。以下是领域能力映射..."

experts/factory.ts
  └─ build() 
       └─ systemPrompt 之后追加该专家的 triggerKeywords + collectionHints
```

### 3.4 与已有注册表的同步

```
experts/registry.ts (ANALYSIS_EXPERTS)
  ├─ 已有: id / name / description / inputSchema / outputSections / evidenceFilter
  └─ 新增: triggerKeywords / collectionHints
       │
       ▼
experts/configs/*.config.ts (每个专家独立 config)
  └─ triggerKeywords 在此维护
       │
       ▼
intention.ts / reasoning.ts / factory.ts
  └─ 运行时读取 config → 注入到 LLM prompt
```

### 3.5 五层参数处理管线（v5 最终方案）

> **核心决策**：工具调用参数处理不应硬编码在 Zod schema 中（静态无法适应业务变化），也不应全凭 LLM 推断（不可靠）。需要在 Tool Context 和 Zod 之间插入裁决层（caijuehub），动态判断"当前场景下这个参数是否必须"。

#### 3.5.1 三层差异边界

不同层面有各自独立的参数需求定义，**不重合**：

```
专家层面 (expert config)              工具层面 (Zod schema)               Agent State 层面
┌────────────────────────┐    ┌──────────────────────────┐    ┌──────────────────────┐
│ pest_risk.inputSchema: │    │ query_insect_data:       │    │ AgentState:          │
│   crop     required    │ ←→ │   massifId    optional ✅ │ ←→ │   massifId = 42      │
│   stage    required    │    │   dataTime    optional   │    │   projectId = 1001   │
│   location required    │    │                          │    │                      │
│                        │    │ query_farm_weather:      │    │                      │
│ realtimeToolNames:     │    │   location    required ✅ │    │                      │
│   query_farm_weather   │    │   days        default 3  │    │                      │
│   query_insect_data    │    │                          │    │                      │
└────────────────────────┘    └──────────────────────────┘    └──────────────────────┘
      概念层需求                      工具调用参数                     运行时自动供应值
      (LLM 推理用)                   (Zod 校验用)                    (Tool Context 注入)
```

- **专家层面**：`inputSchema` 定义该专家推理所需的概念参数（crop/stage/location），与具体工具参数不是一一映射
- **工具层面**：Zod schema 定义工具调用的技术参数（massifId/location/days），`optional()` 保持技术容错
- **AgentState 层面**：`projectId`/`massifId` 等可从会话上下文自动供应，经 Tool Context 注入 prompt

#### 3.5.2 层次关系与 Category 语义分类（v4 保留）

> `RuntimeInputEntry` 是 Storage 全集，toolContext 是从中按 category 过滤的子集。runtimeInputs 本身不动，不新增字段到 ExpertPromptInput。

```
runtimeInputs: Record<string, RuntimeInputEntry>    ❌ Record<string, unknown>
  │
  ├─ RuntimeInputEntry (Storage 层 — 全集)
  │     value: string
  │     label: string
  │     category: RuntimeInputCategory              ← 必填，枚举型
  │
  │     type RuntimeInputCategory = "toolContext" | "analysis"
  │
  ├── category === "toolContext"  ──→ 【工具调用上下文】（factory.ts 新增区块）
  │     projectId, massifId, massifIds, now
  │
  └── category !== "toolContext"  ──→ 【运行时参数】（已有区块，不变）
        cropType, week_range, plantingArea, soilType, …
```

| category | 包含字段 | 渲染区块 | 用途 |
|----------|---------|---------|------|
| `"toolContext"` | `projectId`, `massifId`, `massifIds`, `now` | `【工具调用上下文】`（新增） | LLM 填参专用 |
| `"analysis"` | 其余全部（`cropType`, `week_range`, `plantingArea`…） | `【运行时参数】`（已有） | 分析上下文 |

> 不设第 3 个成员。`week_range` 虽语义为时间，但消费端仍是分析类 prompt，强行分类增加标注负担无渲染收益。枚举型确保编译期穷举检查。
>
> **TypeScript 类型层面无需子集定义**——子集是运行时按 category 过滤的，不是类型断言的。`ExpertPromptInput` 不新增 `toolContext` 字段。
>
> **P1-回流（Review #1）**: `RuntimeInputEntry.category` 为新增字段，`reasoning.ts` 构建时统一标注（`projectId`/`massifId`/`now` → `"toolContext"`，其余 → `"analysis"`），无需 DB migration。
>
> **P1-回流（Review #2）**: Specs Requirements 已扩展至 8 个 Requirement，覆盖全部 9 个 Task Group。

#### 3.5.3 裁决层引入（v5 新增 — caijuehub 动态参数必须性判断）

> **增量变更**：在已有 Tool Context → Zod 管线中插入裁决层。以下为新增内容，上方的 Category/层次关系/双通道传播均保留不变。

```
                       Tool Context 层（已有）
                    ┌─ AgentState.runtimeInputs ─┐
                    │  category: toolContext 子集  │
                    │  projectId / massifId / now │
                    └──────────┬─────────────────┘
                               │ 供应上下文值
                               ▼
                       裁决层 (caijuehub)  ★ v5 新增
                    ┌─ resolve-tool-params.ts ────┐
                    │  根据 expert / intent /      │
                    │  AgentState 可达性 动态判断  │
                    │  「当前场景下该参数是否必须」  │
                    └──────────┬──────────────────┘
                               │
                         ┌─────┴─────┐
                         │           │
                    必须且可供应    必须但不可供应
                         │           │
                         ▼           ▼
                    Zod 层         SSE 层
                    校验通过       emit param_missing
                    继续执行       → 前端提示用户补充
```

**裁决层职责**（单一）：
- 输入：Tool Context（AgentState 可达值）+ expert 上下文 + intent 上下文
- 输出：`{ missing: string[], hint: string } | null`
- 不负责：值转换、默认值填充、提示词注入（这些是 Tool Context 层的职责）

**Zod 层保持不变**：`massifId` 等参数保持 `optional()`。硬编码 required 会限制业务灵活性，裁决层提供动态决策能力。

#### 3.5.4 分层改动清单

**Storage 层**（Category 类型扩展）：

| 文件 | 改动 |
|------|------|
| `analysis-context.ts` | `RuntimeInputEntry` 新增 `category: RuntimeInputCategory`（必填） |
| `types.ts` | `Record<string, unknown>` → `Record<string, RuntimeInputEntry>`（2 处） |

**Prompt 层**（Category 驱动分区渲染）：

| 文件 | 改动 |
|------|------|
| `reasoning.ts` | 构建 `runtimeInputs` 时标注 category |
| `factory.ts` | 按 category 分两段渲染——`【运行时参数】` + 新增 `【工具调用上下文】` |

**裁决层**（v5 新增，caijuehub）：

| 文件 | 改动 |
|------|------|
| `src/caijuehub/strategies/resolve-tool-params.ts` | **新建**。输入 Tool Context + expert 上下文 + AgentState 可达性，动态判断参数是否必须，返回 `missing` + `hint` |

**SSE 层**（漏网通知）：

| 文件 | 改动 |
|------|------|
| `stream-bus.ts` | 新增 `ParamMissingEvent` |
| `agents/index.ts` (toolNode) | ZodError → emit `param_missing`（仅通知 Zod 层拦住的漏网之鱼） |

> **设计原则**：① 五层各司其职，不跨界；② Zod 不硬编码 required（裁决层动态决策）；③ category 用字段不用 key（标识与分类解耦）；④ LLM 流程不直接对接 HTTP 模块；⑤ **v4 → v5 增量：仅新增裁决层 ".3" 一节 + 改动清单裁决层行 + Task 2.5b，其余不改。**

---

## 四、实施步骤 + 依赖图

```
Task 1: 创建 domain-triggers.ts 集中词汇文件
       │
       ▼
Task 2: 为 14 个专家填充触发词（集中文件一次性）
       │
       ▼
Task 2.5a: Storage 层 Category 扩展 + types.ts 类型去擦除
       │
       ▼
Task 2.5b: caijuehub 裁决层（动态参数必须性判断）
       │
       ▼
Task 3: intention.ts 注入领域词汇上下文
       │
       ▼
Task 4: reasoning.ts 注入领域词汇上下文
       │
       ▼
Task 5: factory.ts 注入 per-expert 词汇上下文
       │
       ▼
Task 6: 编译验证 + 端到端测试
       │
       ▼
Task 6.5: SSE param_missing 事件新增（工具调用参数缺失通知）
```

### Task 1: 创建集中词汇文件

**文件**: `src/agents/vocabulary/domain-triggers.ts`（新建）

- [ ] 定义 `DomainTriggerMap` 接口（`expertTriggers` + `collectionHints`）
- [ ] 导出 `DOMAIN_TRIGGERS` 常量（`expertTriggers` 初值为空对象，`collectionHints` 初值为空对象）
- [ ] 确认 TypeScript 编译通过

### Task 2: 为全部 14 个专家填充触发词

**文件**: `src/agents/vocabulary/domain-triggers.ts`（修改）

- [ ] 全部 14 个专家一次性填充：pest-risk / crop-compare / weather-impact / variety-recommend / cost-accounting / roi-analysis / nutrition-diagnose / growth-report / planting-advice / work-plan / machinery-dispatch / daily-report / weekly-report / land-analysis
- [ ] 每个专家 ≥ 8 个 expertTriggers
- [ ] collectionHints 从该专家的 evidenceFilter 提取或从 expert description 推断

### Task 2.5a: Storage 层 Category 扩展 + types.ts 类型去擦除

> **背景**：`RuntimeInputEntry` 是运行时输入全集，需新增 category 字段支撑 Prompt 层分区渲染。同时清理 `Record<string, unknown>` 类型擦除。

**文件**: `analysis-context.ts` + `types.ts` + `reasoning.ts` + `factory.ts`

- [ ] `analysis-context.ts`：定义 `type RuntimeInputCategory = "toolContext" \| "analysis"`，`RuntimeInputEntry` 新增 `category: RuntimeInputCategory`（必填，非 optional）
- [ ] `types.ts`：`ExpertPromptInput.runtimeInputs: Record<string, unknown>` → `Record<string, RuntimeInputEntry>`
- [ ] `types.ts`：`ExpertReasoningPackage.runtimeInputs: Record<string, unknown>` → `Record<string, RuntimeInputEntry>`
- [ ] `reasoning.ts`：构建 `runtimeInputs` 时标注每个 entry 的 category（`projectId`/`massifId`/`massifIds`/`now` → `"toolContext"`，其余 → `"analysis"`）
- [ ] `factory.ts`：按 category 分两段渲染——① `【运行时参数】` 只渲染 `category !== "toolContext"` 的 entry；② 新增 `【工具调用上下文】` 只渲染 `category === "toolContext"` 的 entry
- [ ] `tsc --noEmit` 验证

### Task 2.5b: caijuehub 裁决层（动态参数必须性判断）

> **背景**：Zod schema 中 `massifId` 等参数保持 `optional()`。LLM 调工具时传不传这个参数，不由 Zod 静态决定，而由裁决层根据当前场景（expert / intent / AgentState 可达性）动态判断。

**文件**: `src/caijuehub/strategies/resolve-tool-params.ts`（新建）

- [ ] 定义 `ToolParamRule` 接口：`{ paramName, available(): boolean, requiredIn(context): boolean }`
- [ ] 实现 `resolveMissingToolParams(toolName, params, state)` 函数：输入 Tool Context + expert 上下文 + AgentState 可达性，输出 `{ missing: string[], hint: string } \| null`
- [ ] 规则表覆盖当前所有 `optional()` 的农情工具参数（`massifId` 等）
- [ ] toolNode 中调用裁决层，返回非 null 则 emit `param_missing` SSE 事件
- [ ] `tsc --noEmit` 验证

> **设计原则**：裁决层不供应值（Tool Context 层负责），不拦截校验（Zod 层负责），只做「该不该有」的动态判断。

### Task 3: intention.ts 注入领域词汇上下文

**文件**: `src/agents/prompts/intention.ts`

- [ ] 在 `buildContextBlock()` 或 `buildPrompt()` 中追加领域词汇摘要
- [ ] 格式：从 `ANALYSIS_EXPERTS` 注册表读取所有有 `triggerKeywords` 的专家，生成映射摘要
- [ ] 不影响原有 `INTENT_SEMANTICS` 和 `CROSS_DOMAIN_RULES`

### Task 4: reasoning.ts 注入领域词汇上下文

**文件**: `src/agents/prompts/reasoning.ts`

- [ ] 在 `build()` 方法中追加领域词汇系统上下文
- [ ] 包含：可用专家列表 + 每个专家的 triggerKeywords 摘要

### Task 5: factory.ts 注入 per-expert 词汇

**文件**: `src/agents/prompts/experts/factory.ts`

- [ ] 在 `build()` 方法中，systemPrompt 之后追加该专家的 `triggerKeywords` + `collectionHints`
- [ ] 格式简洁："你可以从以下领域触发词理解用户意图：虫害、病虫害、虫情..."

### Task 6: 编译验证 + 端到端测试

- [ ] `npx tsc --noEmit` 通过
- [ ] 14 个 expert config 不因新增可选字段而报错
- [ ] 端到端：用户说"最近虫害严重" → LLM 能关联到 pest_risk 专家

### Task 6.5: SSE param_missing 事件新增

> **背景**：当 LLM 调用工具时缺少必需参数（如 ZodError），当前仅在 `tool_result` 中静默返回 `success: false`。需要新增 SSE 事件类型，让前端感知参数缺失并提示用户补充。

**文件**: `src/agents/stream-bus.ts` + `src/agents/index.ts`（toolNode）

- [ ] `stream-bus.ts`：新增 `ParamMissingEvent { type: "param_missing", toolName: string, missing: string[], hint: string }`
- [ ] `stream-bus.ts`：`StreamEvent` union type 加入 `ParamMissingEvent`
- [ ] `agents/index.ts`（toolNode）：`tool.invoke()` 捕获异常时，检测是否为 ZodError → 提取 `missing required fields` → emit `param_missing`
- [ ] 非 ZodError 的失败仍走现有 `tool_result` error 逻辑
- [ ] `tsc --noEmit` 验证

---

## 五、验收标准

- [ ] `src/agents/vocabulary/domain-triggers.ts` 存在且导出 `DOMAIN_TRIGGERS`
- [ ] 全部 14 个专家有 expertTriggers（每个 ≥ 8 条）
- [ ] **Task 2.5a**: `RuntimeInputEntry.category: RuntimeInputCategory` 必填，`types.ts` `Record<string, unknown>` → `Record<string, RuntimeInputEntry>`
- [ ] **Task 2.5a**: `factory.ts` 按 category 分两段渲染——`【运行时参数】` + 新增 `【工具调用上下文】`
- [ ] **Task 2.5b**: `src/caijuehub/strategies/resolve-tool-params.ts` 存在，输入 Tool Context + expert 上下文 → 输出 `missing` + `hint`
- [ ] intention.ts 注入领域词汇上下文
- [ ] reasoning.ts 注入领域词汇上下文 + 构建时标注 category
- [ ] factory.ts 注入 per-expert 词汇
- [ ] **Task 6.5**: `stream-bus.ts` 包含 `ParamMissingEvent`，toolNode 在 ZodError 时 emit `param_missing`
- [ ] `npx tsc --noEmit` 通过
- [ ] 已有 14 个 expert config 不因新增可选字段而报错

---

## 六、后续扩展（本次不实施）

| 扩展方向 | 说明 |
|---------|------|
| 治理 AI 运行时 ADD 词汇注入 | 当 PolicyUpdateLoop 接入 LLM 推理时注入 ADD 词汇 |
| triggerKeywords 自动生成优化 | 用 LLM 从 expert description + systemPrompt 自动提取并扩充触发词 |
| RAG collection 触发词独立管理 | 如果 evidenceFilter 不够精确，建立独立的 collection ↔ keyword 映射 |

---

## 七、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-add-route-v1.md`（待创建） |
| Handoff | `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-handoff-v1.md`（待创建） |
| Review | `.qoder/reviews/farm-agent-domain-vocabulary-review-v1.md`（待创建） |
| Spec | `.qoder/specs/farm-agent-domain-vocabulary/spec.md`（待创建） |
| Tasks | `.qoder/specs/farm-agent-domain-vocabulary/tasks.md`（待创建） |
| Checklist | `.qoder/specs/farm-agent-domain-vocabulary/checklist.md`（待创建） |
