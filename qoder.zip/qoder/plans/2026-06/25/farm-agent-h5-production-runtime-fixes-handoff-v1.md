# farm-agent — 2 轮 Runtime Review 修复交接手册

> **适用场景**：两轮 runtime-review 驱动的 P0/P1 生产环境修复。
>
> **用途**：每个新对话开始时，把对应轮次章节粘贴给 LLM。

---

## 全局元信息

- **父 Plan 1**: [farm-agent-ruifengyun-h5-api-plan-v2.md](../../../.qoder/plans/2026-06/23/farm-agent-ruifengyun-h5-api-plan-v2.md)
- **父 Plan 2**: [farm-agent-nongqing-report-api-plan-v1.md](../../../.qoder/plans/2026-06/22/farm-agent-nongqing-report-api-plan-v1.md)
- **Runtime Review 1**: [farm-agent-ruifengyun-h5-api-v2-runtime-review-v1.md](../../../.qoder/reviews/farm-agent-ruifengyun-h5-api-v2-runtime-review-v1.md)
- **Runtime Review 2**: [farm-agent-nongqing-report-api-runtime-review-v1.md](../../../.qoder/reviews/farm-agent-nongqing-report-api-runtime-review-v1.md)
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 9 个（5 修改 + 4 新建）
- **轮次数**: 2 轮

```text
第1轮 ── 成本核算三重正向兜底（算法+精度+单位）
            │
            ▼
第2轮 ── 计划生命周期修复（cron自动完成 + cancelled状态）
```

---

## 原子事务边界说明

两轮修复由不同的 Runtime Review 触发，涉及不同的 Plan 和代码域，无代码依赖，可独立验证和部署。

- **第 1 轮**：修复 cost-accounting 端点 LLM 做算术导致过亿元问题
- **第 2 轮**：修复计划生命周期——cron 未安装 + 无取消路径

---

## <第1轮> 成本核算三重正向兜底

### 你当前的位置

你是第 1 轮。Runtime Review [farm-agent-ruifengyun-h5-api-v2-runtime-review-v1.md](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-ruifengyun-h5-api-v2-runtime-review-v1.md) 发现 6 个问题（P0×3 + P1×2 + P2×1），本轮修复全部 P0。

### 上游已完成

- 无上游依赖。本轮是 Runtime Review 触发的独立修复。

### 恢复上下文审计查询

#### 一键恢复
```text
query_audit_logs({ keyword: "ruifengyun-h5-api-v2" })
```
→ 返回全部本轮 ADD-7 审计记录（约 5 条）。

### 原子事务目标

修复 cost-accounting 端点 `expectedRevenue` 过亿元问题。核心策略：三重正向兜底——服务端做算术（算法）+ Zod 精度约束（精度）+ 单位标准化契约（单位）。

### 你要改的文件（8 个：3 新建 + 5 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/prompts/unit-contract.ts` | 新建 | 单位标准化单一真相源（中国亩/kg/元/2位小数） |
| `.qoder/reviews/farm-agent-ruifengyun-h5-api-v2-runtime-review-v1.md` | 新建 | Runtime Review（6 发现） |
| `.qoder/plans/2026-06/25/farm-agent-ruifengyun-h5-api-v2-add-route-v3.md` | 新建 | ADD 执行路线图 |
| `src/app/api/h5/production-plan/cost-accounting/route.ts` | 修改 | 服务端计算 expectedRevenue + LLM 只推 costItems |
| `src/app/api/h5/types/schemas.ts` | 修改 | Zod yuanAmount = .finite().multipleOf(0.01) |
| `src/agents/prompts/experts/cost-accounting.ts` | 修改 | 单位硬约束 + LLM 只输出 costItems |
| `src/caijuehub/caijue.toml` | 修改 | 注册 resolve-unit-contract 合约条目 |
| `.qoder/plans/2026-06/23/farm-agent-ruifengyun-h5-api-plan-v2.md` | 修改 | 更新 Runtime Review 状态 |

### 核心设计

```
算法兜底: expectedRevenue = roundYuan(area × yield × price)  // 服务端算，LLM 不碰
精度兜底: yuanAmount = z.number().finite().multipleOf(0.01)    // Zod 校验
单位兜底: unit-contract.ts 单一真相源 → caijue contract      // 改一处全局生效
```

### 关键契约细化

- `unit-contract.ts` 是单位标准化唯一真相源，`route.ts`/`schemas.ts`/`prompt` 均 import 自它
- `roundYuan(v)` 替代所有 `Math.round(v*100)/100`，精度常量 CURRENCY_DECIMALS=2
- `UNIT_AREA = "亩"` 用于 API 响应，`UNIT_AREA_FULL = "中国亩"` 用于内部契约描述
- LLM prompt 中 `expectedRevenue` 已由服务端传入，LLM **禁止重算**
- `caijue.toml` `id="resolve-unit-contract"` 为治理级合约

### 高风险误区

- 禁止在 LLM prompt 中让 LLM 计算任何乘法（`×` 运算符）
- 禁止 `Math.round(v)` 不乘 100 就直接用——会丢失精度
- 禁止在 API 响应中使用 "中国亩"——前端只认 "亩"

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_UPDATED` | API_ROUTE | route.ts | F2: 服务端计算+精度控制 | ✅ |
| `COMPONENT_UPDATED` | SCHEMA | schemas.ts | F3: Zod 精度约束 | ✅ |
| `COMPONENT_UPDATED` | PROMPT | cost-accounting.ts | F1: 单位硬约束+LLM职责简化 | ✅ |
| `DOC_CREATED` | PLAN | add-route-v3.md | ADD 执行路线图 | ✅ |

**恢复关键词**：
```text
query_audit_logs({ keyword: "ruifengyun-h5-api-v2" })
→ 返回全部 5 条本轮 ADD-7 审计记录
```

### 验证标准

#### 已完成验证

- tsc --noEmit: exit 0 ✅
- RAHS: 100 🟢 ✅
- roundYuan(1.23456) = 1.23 ✅
- 正常参数 100亩×600kg×1.6元 = 96000 元（非过亿）✅

---

## <第2轮> 计划生命周期修复

### 你当前的位置

你是第 2 轮。上游第 1 轮已完成成本核算三重兜底修复。本轮独立修复计划生命周期问题。Runtime Review [farm-agent-nongqing-report-api-runtime-review-v1.md](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-nongqing-report-api-runtime-review-v1.md) 发现 3 个问题（P0×1 + P1×1 + P2×1），本轮全部修复。

### 上游已完成

- 第 1 轮：成本核算三重兜底（unit-contract.ts 可用，roundYuan() 可 import）

### 恢复上下文审计查询

#### 一键恢复
```text
query_audit_logs({ keyword: "nongqing-report-api" })
```
→ 返回全部本轮 ADD-7 审计记录（约 4 条）。

### 原子事务目标

1. P0: crontab.prod.txt 加 auto-complete-plans.ts 定时任务 + 生产安装
2. P1: PATCH plans/[id] 支持 cancelled 状态
3. P2: Plan 审计表漂移修正

### 你要改的文件（5 个：1 新建 + 4 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `.qoder/reviews/farm-agent-nongqing-report-api-runtime-review-v1.md` | 新建 | Runtime Review（3 发现） |
| `scripts/crontab.prod.txt` | 修改 | 追加 auto-complete cron 行 |
| `prisma/nongqing.prisma` | 修改 | status 注释加 `cancelled` |
| `src/app/api/h5/production-plan/plans/[id]/route.ts` | 修改 | 新增 cancelled 分支 |
| `src/app/api/h5/production-plan/generate/route.ts` | 修改 | 冲突检查跳过 cancelled |

### 核心设计

```
计划状态机:
  active ──→ completed   (手动 PATCH / cron 到期)
  active ──→ cancelled   (手动 PATCH)
  cancelled ──→ active   (重新激活)
  completed ──→ active   (重新激活)

定时任务:
  30 2 * * * npx tsx scripts/auto-complete-plans.ts
  → 扫描 maturityDate 已过的 active 计划
  → 标记 completed + 自动完成所有 pending 任务 + 释放地块
```

### 关键契约细化

- `crontab.prod.txt` 是生产 crontab 唯一管理文件，`ensure-cron.sh` 不碰它
- cancelled 计划的 pending 任务标记为 `completed`（不设 `completedAt`）
- generate 端点冲突检查只拦 `active` 计划，`completed`/`cancelled` 均放行
- 同名计划检查跳过 `cancelled`（允许取消后重新创建同名计划）

### 高风险误区

- 禁止在 `crontab.txt`（dev）中加 auto-complete 行——那是开发环境用的
- 禁止用 `findUnique` 替代 `findFirst` 做同名检查（加了 status 过滤后不再匹配唯一约束）
- cancelled → completed 转换必须先激活为 active

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_UPDATED` | INFRA | crontab.prod.txt | F1: cron 追加+生产安装 | ✅ |
| `COMPONENT_UPDATED` | API_ROUTE | plans/[id]/route.ts | F2: cancelled 状态支持 | ✅ |
| `COMPONENT_UPDATED` | SCHEMA | nongqing.prisma | F2: status 注释更新 | ✅ |
| `COMPONENT_UPDATED` | API_ROUTE | generate/route.ts | F2: 跳过 cancelled | ✅ |

**恢复关键词**：
```text
query_audit_logs({ keyword: "nongqing-report-api" })
→ 返回全部 4 条本轮 ADD-7 审计记录
```

### 验证标准

#### 已完成验证

- tsc --noEmit: 本次改动文件零错误 ✅（预存 scripts 错误非本轮引入）
- 生产 crontab 已安装: `crontab -l | grep auto-complete` 有输出 ✅
- PATCH cancelled 分支: 标记取消 + 取消 pending 任务 + 释放地块 ✅
- generate 跳过 cancelled: 冲突检查 + 同名检查均过滤 ✅

#### 待生产验证

- [ ] PATCH /api/h5/production-plan/plans/{id}?projectId= → `{"status":"cancelled"}` 返回 200
- [ ] cancelled 后再 generate 同名计划应成功（不被同名检查拦截）
- [ ] 次日 2:30 检查 `cron-auto-complete.log` 有执行记录
