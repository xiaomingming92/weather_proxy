# Plan: LLM 全局可变状态隔离

> 来源: `.qoder/reports/code-review-combined-report.md` #10
> 创建: 2026-06-30
> 版本: v1

## 问题描述

`src/lib/llm/index.ts` 使用模块级变量 `llmInstance` 作为全局单例。`setLLMConfig()` 会调用 `resetLLM()` 将其置为 `null`，存在异步边界处全局状态被其他请求覆盖的风险。

### 现状

```
let llmInstance: AuditedLLM | null = null          // 模块级全局单例
let runtimeConfigOverride: Partial<LLMConfig> | null = null  // 全局配置覆盖

export function getLLM(): AuditedLLM {
  if (llmInstance) return llmInstance   // 复用全局单例
  // ... 用 runtimeConfigOverride + env 创建新实例
  llmInstance = new AuditedLLM(...)
  return llmInstance
}

export function setLLMConfig(config) {
  runtimeConfigOverride = { ...config }
  resetLLM()  // llmInstance = null
}
```

### 潜在风险场景

三个 route handler 都从请求中提取 `modelConfig` 后调用 `setLLMConfig()`：
- `src/app/api/agent/chat/route.ts:37`
- `src/app/api/agent/chat/stream/route.ts:133`
- `src/app/api/agent/[hash]/route.ts:456`

如果 agent 图执行过程中（跨多次 `await`）多次调用 `getLLM()`，且不同请求携带不同 `modelConfig`：

```
请求A: setLLMConfig(qwen-plus) → getLLM() → instance_A
请求A: agent 节点1 执行中...
请求B: setLLMConfig(qwen-max) → resetLLM() → llmInstance = null
请求A: 节点2 getLLM() → null → 新建 instance (qwen-max) ← 模型变了
```

### 待确认

1. agent 图各节点是否在同一请求内多次调用 `getLLM()`？
2. 生产环境是否真有不同用户使用不同模型的场景？
3. 如果不满足以上两条，则此为理论风险，无需修复。

---

## 方案

### Step 1: 调研（只读）

检查 LangGraph agent 节点中 `getLLM()` 的实际调用模式：

- 确认 `getLLM()` 在单次 `agent.invoke()` 中的调用次数和时机
- 确认是否可通过 LangGraph `config.configurable` 传递 LLM 实例，避免多次调用 `getLLM()`
- 确认生产环境中 modelConfig 是否确实因用户而异

### Step 2: 方案选型

根据调研结果选择：

| 场景 | 方案 |
|------|------|
| 各节点不重复调用 `getLLM()`，或所有用户同模型 | **无需修复**，关闭此 issue |
| 各节点重复调用 + 不同用户不同模型 | 二选一： |

**方案 A: 请求级实例缓存（最小改动）**

不改变全局 setLLMConfig 模式，但让同一请求内 `getLLM()` 返回稳定实例：

```typescript
// 利用 Node.js AsyncLocalStorage 实现请求级隔离
import { AsyncLocalStorage } from "async_hooks"

const llmStorage = new AsyncLocalStorage<{ instance: AuditedLLM; configHash: string }>()

export function getLLM(): AuditedLLM {
  const store = llmStorage.getStore()
  if (store) return store.instance  // 请求内复用

  // 回退到全局单例（兼容未设置 ALS 的调用路径）
  const config = getLLMConfig()
  const hash = hashConfig(config)
  if (llmInstance && llmConfigHash === hash) return llmInstance

  llmInstance = buildLLM(config)
  llmConfigHash = hash
  return llmInstance
}

export function withLLMContext<T>(config: Partial<LLMConfig>, fn: () => Promise<T>): Promise<T> {
  const instance = buildLLM({ ...getLLMConfig(), ...config })
  return llmStorage.run({ instance, configHash: "" }, fn)
}
```

调用方改为：
```typescript
// Before
setLLMConfig({ model: ... })
const result = await runAgent(input, config)

// After
const result = await withLLMContext({ model: ... }, () => runAgent(input, config))
```

**方案 B: 通过 LangGraph config 传递 LLM 实例**

在 `RunnableConfig.configurable` 中携带 LLM 实例，各节点从 config 读取而非调用 `getLLM()`。改动面更大，涉及所有节点。

---

## 执行步骤

1. **调研** `getLLM()` 调用链，确认风险是否真实存在
2. 如无需修复 → 写结论，关闭
3. 如需修复 → 选方案 A 或 B，实施

## 风险评估

| 风险 | 缓解 |
|------|------|
| AsyncLocalStorage 在某些 Node.js 版本不支持 | Node 14+ 已稳定支持；检查项目运行时版本 |
| 改动影响面大（3 个 route handler + 所有节点） | 方案 A 对非 route 调用路径完全兼容（fallback 到全局单例） |
