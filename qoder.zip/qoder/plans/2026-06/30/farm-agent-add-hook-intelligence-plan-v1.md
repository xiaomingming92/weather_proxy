# farm-agent-add-hook-intelligence-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。**不要**在 Plan 中写完整 shell 实现——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-add-hook-intelligence-v1
- **启动时间**: 2026-06-30T00:50:00+08:00
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/30/farm-agent-add-hook-intelligence-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-06/30/farm-agent-add-hook-intelligence-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-add-hook-intelligence-review-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `.qoder/hooks/add-enforce.sh` | SCRIPT | SCRIPT_REWRITTEN | 单层关键词匹配，~20 触发词 | 三层智能路由，覆盖全部 56 条触发词 | 待实施 |
| `.qoder/settings.json` | CONFIG | CONFIG_UPDATED | 含注释的无效 JSON | 合法 JSON + 超时配置 | ✅ 已修复 |

---

## 一、背景与目标

### 1.1 问题现状

当前 `.qoder/hooks/add-enforce.sh`（17 行）只能做一件事：检测到开发关键词 → `exit 2` 丢一句"请执行 add-paradigm SKILL"。与项目已有的 ADD 治理词汇表（`.qoder/vocabulary/add-governance-vocabulary.md`，6 类 56 条 P0/P1/P2 触发词）和 ADD 工作流 9 阶段（Step 0-8）相比，覆盖率极低：

| 维度 | 词汇表要求 | 当前 hook | 差距 |
|------|-----------|----------|------|
| 触发词覆盖 | 56 条（6 类） | ~20 条（仅开发关键词） | 36 条未覆盖 |
| 精准触发（P0） | "验收"→三步闭环、"DPS"→闸门、"Review回流"→0.6.5 | ❌ 无 | 全部缺失 |
| 状态感知 | 检测活跃 ADD 流程，区分钟"新任务"vs"继续当前" | ❌ 无 | 每次开发关键词都 exit 2 |
| 上下文注入 | 当前 Plan 路径、当前 Step、handoff 位置 | ❌ 无 | Agent 每次从零恢复 |
| Qoder CN 兼容 | settings.json 无注释、CN 环境变量适配 | settings.json 有 `//` 注释 | ✅ 已修复 |

### 1.2 目标

将 hook 从"粗粒度门禁"升级为"智能路由"——三层判断：

```
UserPromptSubmit
  │
  ├─ Layer 1: 精准触发词
  │   验收/DPS/RAHS/Review回流 → 注入对应操作指令 + 放行
  │
  ├─ Layer 2: 开发关键词 + 无活跃 ADD 流程
  │   → exit 2 强制启动 add-paradigm SKILL
  │
  └─ Layer 3: 开发关键词 + 有活跃 ADD 流程
      → 注入当前 Plan/Step/handoff 上下文 + 放行
```

---

## 二、方案选型

### 2.1 候选方案

| 方案 | 实现方式 | 优点 | 缺点 | 结论 |
|------|---------|------|------|------|
| A: 纯 shell 扩展 | 17 行→~120 行 bash，if-elif 链 | 零依赖，Qoder 原生支持 | 可维护性差，复杂逻辑难以测试 | ❌ |
| B: TypeScript 脚本 | `tsx` 执行，复用项目类型系统 | 可测试，可复用 vocabulary 解析 | Qoder hook 必须起 node 进程，冷启动慢 | ❌ |
| C: shell + 分层架构 | 主脚本分流→子脚本专业化，按 `prompt` 内容路由到对应处理函数 | 分层清晰，每层职责单一，纯 shell 兼容 | 需要设计内部通信协议 | ✅ |

### 2.2 选型理由

选 C——保持纯 shell（Qoder hook 原生支持，零冷启动），但内部按三层架构重构：

- **入口脚本** `add-enforce.sh`：提取 prompt → 按优先级路由到 Layer 1/2/3
- **状态检测**：内嵌于入口，检查 `plans/` 目录是否存在活跃 handoff
- **触发词匹配**：从 vocabulary 静态映射为 shell case 分支

---

## 三、架构设计

### 3.0 现有资产摸底（v2 新增）

当前 `.qoder/` 下已有完整的 ADD 基础设斻，hook 不应重复造轮子：

```
.qoder/vocabulary/add-governance-vocabulary.md  ← 单一真值源（56条触发词）
.qoder/agents/add-flow-guardian.md               ← 入口/出口门禁
.qoder/agents/add-orchestrator.md                ← Step 边界编排
.qoder/skills/add-paradigm/SKILL.md              ← ADD Step 0-8 完整流程
.qoder/skills/session-init/SKILL.md              ← 会话恢复
.qoder/scripts/mcp-server.ts                     ← MCP 工具（check_dps等）
AGENTS.md                                        ← P0 词汇速查（13条）
```

**核心设计原则**：hook 是薄层路由器，不是规则引擎。
- 触发词 → 从 vocabulary 文件解析，不硬编码
- 状态检测 → 通过 MCP 工具（query_audit_logs / check_add_route_status）
- 强制执行 → 委托给 Subagent（add-flow-guardian / add-orchestrator）
- 上下文注入 → stdout 文本注入 Agent 对话

### 3.1 三层路由架构（修正）

```
UserPromptSubmit
  │
  ├─ Step 0: 加载 vocabulary
  │   解析 add-governance-vocabulary.md → 构建触发词→响应映射表
  │
  ├─ Layer 1: 精准 P0 触发词
  │   "验收"/"DPS"/"Review回流"/"实施"
  │   → stdout 注入对应指令 → exit 0
  │
  ├─ Step 1: 状态检测（调用 MCP 工具）
  │   query_audit_logs({ planKeyword }) → 判断活跃 ADD 流程
  │   OR: 检查 plans/ 下 handoff 文件 mtime
  │
  ├─ Layer 2: 开发关键词 + 无活跃 ADD
  │   → exit 2 强制启动 add-paradigm SKILL
  │
  └─ Layer 3: 开发关键词 + 有活跃 ADD
      → stdout 注入当前 Plan/Step/handoff → exit 0
```

### 3.2 vocabulary 集成方式

**不**在 hook 中硬编码关键词。改为：

```bash
# 从 vocabulary 文件动态提取触发词
load_vocabulary() {
  # 解析 markdown 表格 "| 触发词 | LLM 默认操作 | 优先级 |"
  # 提取 P0 行 → 构建 grep 正则
  grep -E '^\|.*\|.*\|.*P0.*\|' "$VOCABULARY_FILE"
}
```

或更简单：vocabulary 文件维护一份纯文本的触发词清单供 hook grep。vocabulary 仍是单一真值源，hook 消费它。

---

## 四、实施步骤 + 依赖图

```
Task 1: vocabulary 机器可读化
  │  给 vocabulary 添加纯文本触发词区（hook 直接 grep）
  │
  ▼
Task 2: hook 消费 vocabulary
  │  从硬编码关键词 → 动态加载 vocabulary 触发词
  │
  ▼
Task 3: Layer 1 精准触发（P0 词 → 对应指令）
  │
  ▼
Task 4: Layer 2+3 开发关键词路由（含状态检测）
  │
  ▼
Task 5: 集成测试（CN + 国际版）
```

### Task 1: vocabulary 添加机器可读触发词区

- **文件**: `.qoder/vocabulary/add-governance-vocabulary.md`（修改）
- **内容**: 文件末尾新增 `## 附录: 触发词纯文本清单（hook 消费）`，每行一条触发词，格式 `优先级|触发词|响应文本`
- **理由**: hook 不需要解析 markdown 表格，直接 grep 纯文本
- **验收**: `grep -c '^P0|' vocabulary/add-governance-vocabulary.md` ≥ 10

### Task 2: hook 消费 vocabulary 替换硬编码

- **文件**: `.qoder/hooks/add-enforce.sh`（重写）
- **内容**: 删除 10 行硬编码关键词正则，改为 `load_triggers()` 函数解析 vocabulary 纯文本清单
- **验收**: hook 触发的关键词集 = vocabulary 文件内容（`diff <(vocabulary触发词) <(hook正则)`) 无差异

### Task 3: Layer 1 精准触发

- **文件**: `.qoder/hooks/add-enforce.sh`
- **内容**: 解析到 P0 行 → 按类别（验收/闸门/Review回流/实施）映射到对应响应文本
- **验收**: 模拟输入"验收"→stdout 含三步闭环；"DPS"→stdout 含 `check_dps` 指令

### Task 4: Layer 2+3 开发关键词路由（含活跃流程检测）

- **文件**: `.qoder/hooks/add-enforce.sh`
- **内容**: 
  - 状态检测：检查 `plans/` 下 handoff 文件 mtime（简单可靠，不依赖 MCP）
  - Layer 2：开发关键词 + 无活跃 handoff → exit 2
  - Layer 3：开发关键词 + 有活跃 handoff → stdout 注入 "当前 Plan: {keyword}, 轮次: N/M" → exit 0
- **验收**: 
  - 无 handoff + "修复bug"→exit 2
  - 有 handoff + "修复bug"→exit 0 + stdout 含 Plan 信息

### Task 5: 集成测试

- **内容**: CN 版和国际版分别验证
- **验收**: 
  - 非开发对话（"你好"）→exit 0
  - CN 版不报 parsing error
  - 开发关键词命中时路由正确

---

## 五、验收标准

- [ ] 覆盖全部 6 类（A-F）触发词，shell 脚本中每类至少 1 条 `grep` 规则
- [ ] Layer 1: "验收"→三步闭环、"DPS"→闸门指令、"Review回流"→0.6.5 指令
- [ ] Layer 2: 开发关键词 + 无活跃 handoff → exit 2
- [ ] Layer 3: 开发关键词 + 有活跃 handoff → 注入 context + exit 0
- [ ] `settings.json` 不含注释，CN 版和国际版均不报 parsing error
- [ ] Qoder CN 和国际版两端均不阻塞非开发对话（"你好"、"今天天气"→exit 0）

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/30/farm-agent-add-hook-intelligence-add-route-v1.md`（待生成） |
| Handoff | `.qoder/plans/2026-06/30/farm-agent-add-hook-intelligence-handoff-v1.md`（待生成） |
| Review | `.qoder/reviews/farm-agent-add-hook-intelligence-review-v1.md`（待生成） |
| 词汇表 | `.qoder/vocabulary/add-governance-vocabulary.md`（参考） |
| Hook 规范 | [Qoder CN Hook 文档](https://help.aliyun.com/en/lingma/qodercli-cn/user-guide/hook) |
