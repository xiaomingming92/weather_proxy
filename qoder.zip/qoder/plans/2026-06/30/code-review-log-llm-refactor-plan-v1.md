# Plan: 日志模块重复代码消除 + 审计通道统一 + agents/index.ts 拆分

> 来源: `.qoder/reports/code-review-combined-report.md` #6-#9
> 创建: 2026-06-30
> 版本: v1

## 问题摘要

| # | 问题 | 严重度 | 涉及文件 |
|---|------|--------|---------|
| 6 | 8+ 日志模块共享相同 `ensureLogDir/writeToFile/formatMessage` 代码模式 | P1 | 7 个 logger 文件 |
| 7 | `agent-gateway-dev-logger.ts` 与 `agent-gateway-audit.ts` 行为不一致 | P1 | 2 文件 |
| 8 | `audit-log.ts` 内存存储，与 DB 持久化方案不一致 | P2 | 1 文件 |
| 9 | `agents/index.ts` 职责过大 (564 行) | P1 | 1 文件 |

> Issue #10 (LLM 单例全局可变状态问题) 已独立为[单独 Plan](./code-review-llm-state-isolation-plan-v1.md)

---

## 原子事务拆分

### Atom 1: 提取公共日志基础设施 (`LogFileWriter`)

**目标**: 消除 7 个 logger 文件中的 `ensureLogDir()` + `writeToFile()` + `formatMessage()` 重复代码

**重复模块清单**:
- `src/lib/audit-logger.ts` (178 lines)
- `src/lib/chat-persistence-logger.ts` (99 lines)
- `src/lib/stream-bus-logger.ts` (118 lines)
- `src/lib/stream-chat-logger.ts` (81 lines)
- `src/lib/agent-gateway-dev-logger.ts` (90 lines)
- `src/lib/chat-stats-logger.ts` (93 lines)
- `src/lib/model-config-logger.ts` (107 lines)

**新增文件**: `src/lib/log/file-writer.ts`

**方案**:
```
interface LogFileWriterOptions {
  prefix: string           // "[KB-AUDIT]" / "[CHAT-PERSIST]" / ...
  logDir: string           // 日志目录
  logFile: string          // 日志文件名
  enableFileLog: boolean   // 是否启用文件日志
}

class LogFileWriter {
  constructor(options: LogFileWriterOptions)
  ensureLogDir(): Promise<void>
  writeToFile(message: string): Promise<void>
  formatMessage(phase: string, detail: string, extra?: Record<string, unknown>): string
  // 便捷输出组合: console.log + writeToFile
  log(phase: string, detail: string, extra?: Record<string, unknown>): void
  logPhaseStart(phase: string, description: string, count?: number): void
  logPhaseEnd(phase: string, detail: string): void
  readLogs(lines?: number): Promise<string[]>
  clearLogs(): Promise<void>
  getLogPath(): Promise<string>
}
```

> 注意: `chat-stats-logger.ts` 和 `model-config-logger.ts` 使用动态 `import("fs/promises")` (Next.js 同构兼容)，需在 `LogFileWriter` 中支持 `useDynamicImport: true` 选项。

**引用方更新**: 每个 logger 模块改为创建 `LogFileWriter` 实例，保留各模块的类型导出和语义包装函数不变，只替换内部实现。

**验证**:
- 所有 7 个模块编译通过
- 现有日志输出格式不变 (PREFIX / 时间戳 / phase)
- `audit.ts` 中的 `ensureLogDir/writeToFile/formatMessage` 也迁移使用 `LogFileWriter`

---

### Atom 2: 统一 Gateway 审计模块，消除行为不一致

**目标**: 合并 `agent-gateway-dev-logger.ts` (仅 IS_DEV) 和 `agent-gateway-audit.ts` (始终运行) 为一个统一模块

**问题详情**:
- `agent-gateway-dev-logger.ts`: `NODE_ENV === "development"` 时才输出，只写 console + file
- `agent-gateway-audit.ts`: 始终输出，写 console + AuditLog DB 表
- 两者的 `AgentGatewayAuditPhase` / `AgentGatewayAuditAction` 类型高度重叠
- 调用方 (`src/app/api/agent/[hash]/route.ts`) 同时导入两者

**方案**:
1. 将 `agent-gateway-audit.ts` 的 Layer 2 (DB 审计) 能力合并到 `agent-gateway-dev-logger.ts`
2. 统一接口:
   ```typescript
   export function agentGatewayAudit(phase, detail, extra?, options?: { dbAudit?: boolean }): void
   ```
   - `dbAudit: true` → 同时写 DB (用于运营审计场景)
   - 不传或 `false` → 仅 console + file (开发调试)
3. 删除 `agent-gateway-audit.ts`，引用方统一改为 `@/lib/agent-gateway-audit`（重命名后保留原路径或全部迁移后删旧文件）
4. 实际改名：`agent-gateway-dev-logger.ts` → `agent-gateway-audit.ts`（覆盖旧文件）

**引用方更新**:
- `src/app/api/agent/[hash]/route.ts`: 合并 import

**验证**:
- 生产环境 DB 审计写入正常
- 开发环境 console/file 日志 + DB 审计都正常工作
- 无重复类型定义

---

### Atom 3: `audit-log.ts` 内存存储 → DB 持久化

**目标**: 将 `src/services/audit-log.ts` 的 `auditLogs[]` 内存数组替换为 Prisma DB 读写

**当前状态**:
- `src/services/audit-log.ts`: 仅内存数组，进程重启丢失
- `src/lib/log/audit.ts` 中的 `writeAuditLog()`: 已使用 Prisma 写入 `AuditLog` 表
- 两者 schema 不同：`audit-log.ts` 有 `AuditLogEntry` (含 userId, action, targetType, targetId, beforeState, afterState) 而 `writeAuditLog` 写入 `auditLog` 表

**方案**:
1. 检查 Prisma schema 中是否已有 `AuditLog` 模型
2. 将 `createAuditLog()` 改为调用 Prisma `auditLog.create()`
3. 将 `getAuditLogs()` 改为调用 Prisma `auditLog.findMany()`
4. 保留 API 签名不变，内部切换为 DB 持久化

**风险**: `audit-log.ts` 目前只有 `src/app/api/audit/route.ts` 一个调用方。如果 AuditLog DB 表不存在或不可用，fallback 到内存 + 告警。

**验证**:
- `createAuditLog()` 写入后在 DB 中可查
- 进程重启后 `getAuditLogs()` 能查到历史数据

---

### Atom 4: `agents/index.ts` 职责拆分

**目标**: 将 564 行的单体文件拆分为职责清晰的模块

**拆分方案**:

| 新文件 | 职责 | 原代码行号 (approx) |
|--------|------|-------------------|
| `src/agents/graph.ts` | StateGraph 定义 (deep + professional) | L189-L300 |
| `src/agents/tool-node-wrapper.ts` | createToolNodeWrapper 函数 | L34-L187 |
| `src/agents/audit-wrapper.ts` | wrapNodeWithAudit 函数 | L325-L411 |
| `src/agents/agent-runner.ts` | runAgent + streamAgent + StreamAgentInput + buildPartialState | L413-L561 |
| `src/agents/tracer.ts` | activeTracers + startChainTrace + endChainTrace + cleanupExpiredTracers + getActiveTracer | L302-L435 |

**保留在 `index.ts`**:
- 重新导出上述模块的公共 API
- `setAgentTools(agentTools)` 调用
- `export { agentTools }`

**验证**:
- 所有引用 `@/agents` 的 25+ 处 import 无需修改（`index.ts` 保留 re-export）
- deep/professional graph 编译通过
- runAgent / streamAgent 调用正常

## 执行顺序

```
Atom 1 (LogFileWriter 基础设施)
  └─→ Atom 2 (Gateway 审计统一，依赖 Atom 1)
Atom 3 (audit-log DB 持久化，无依赖)
Atom 4 (agents/index.ts 拆分，无依赖)
```

Atom 1 → Atom 2 顺序依赖（Atom 2 使用 LogFileWriter）；Atom 3/4 可并行。

## 风险评估

| 风险 | 缓解 |
|------|------|
| LogFileWriter 改变日志格式，破坏下游解析 | 严格保持 PREFIX + timestamp + phase 格式不变 |
| agents/index.ts 拆分破坏 import 路径 | 保留 `index.ts` re-export，所有 `@/agents` 引用无需改 |
| audit-log.ts DB 迁移后 AuditLog 表字段不匹配 | 先检查 Prisma schema，按需对齐字段 |
