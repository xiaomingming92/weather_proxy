# farm-agent-api-zod-hardening-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。不要写完整 Zod schema 定义——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-api-zod-hardening-v1
- **启动时间**: 2026-06-30T04:30:00+08:00
- **主导 AI**: Qoder
- **触发来源**: 
  - 生产事故（June 29 16:30）：H5 中断流 `interrupt` 事件缺失 `threadId`，调用方无法 resume
  - Code Review 报告 [L120-121](file:///home/xmm/ai/farm-agent/code-review-combined-report.md#L120-L121)：请求体无 Zod 校验
  - Code Review 报告 [L134-139](file:///home/xmm/ai/farm-agent/code-review-combined-report.md#L134-L139)：119 处 `as any` 绕过类型检查
- **前置 Plan**: 无（独立基础设施改造）
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/30/farm-agent-api-zod-hardening-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-06/30/farm-agent-api-zod-hardening-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-api-zod-hardening-review-v1.md`
- **ADD-7 审计策略**:

| 文件范围 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/app/api/**/route.ts` | API_ROUTE | ZOD_SCHEMA_ADDED | 无运行时校验 | 请求体/SSE 事件 Zod 校验 | 待实施 |
| `src/caijuehub/strategies/sse-terminal-event.ts` | COMPONENT | ZOD_SSE_HARDENING | 裸 `any` 发送 interrupt | InterruptSSEPayloadSchema | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

**P0 — SSE 中断事件缺失 threadId，导致生产事故**：

```
event: interrupt\ndata: { type, description, options }  ← 无 threadId
                                                          ← 调用方不知调哪个 /resume
```

根因：`handleInterrupt()` L44 用 `JSON.stringify(intRecord.value ?? int)` 裸发，无 Zod 校验。如果有 `InterruptSSEPayloadSchema.required({ threadId })`，编译期或运行时 safeParse 就会报错，不会漏到生产。

**P1 — 全部 API 端点无运行时校验**：

`src/app/api/` 下 40+ 个路由文件，仅 `h5/types/schemas.ts` 有部分 Zod（生产计划/农情报告请求体），其余全部裸 `request.json()` + 类型断言。Code Review 报告指出：[L120-121](file:///home/xmm/ai/farm-agent/code-review-combined-report.md#L120-L121) 请求体无校验，[L139](file:///home/xmm/ai/farm-agent/code-review-combined-report.md#L134-L139) 119 处 `as any` 绕过类型检查。

**P1 — SSE 响应事件无 schema**：

`done`、`interrupt`、`error` 等 SSE 终端事件的数据结构全凭约定，无 Zod 约束。前端对接只能靠文档描述，无法在编译期验证。

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | `interrupt` SSE 事件含 `threadId` 且 Zod 校验 | `InterruptSSEPayloadSchema` 定义，`handleInterrupt` 使用 safeParse |
| P0 | `done` SSE 事件 Zod 校验 | `DoneSSEPayloadSchema` 定义 |
| P1 | H5 全部端点请求体 Zod 校验 | `h5/agent`、`h5/production-plan/*`、`h5/nongqing/*` 等 |
| P1 | Agent 全部端点请求体 Zod 校验 | `agent/chat/stream`、`agent/resume` 等 |
| P2 | Admin/Knowledge/Document 端点请求体 Zod 校验 | 低频端点，按需补 |
| P2 | SSE 所有终端事件 Zod 校验 | `error`、`response_end` 等 |

---

## 二、方案选型

### 2.1 方案

唯一方案——Zod schema 集中定义 + 端点内 `safeParse` 校验。

**Schema 文件布局**（扩展已有 `src/app/api/h5/types/schemas.ts`）：

```
src/app/api/
├── types/
│   └── schemas.ts          ← 统一 schema 定义（按端点分组）
├── h5/types/schemas.ts      ← 已有（H5 生产计划/农情报告）
└── */route.ts               ← 各端点 safeParse 调用点
```

**统一 Schema 文件内容结构**：

```typescript
// src/app/api/types/schemas.ts

// ─── SSE 事件 ───
export const InterruptSSEPayloadSchema = z.object({
  type: z.string(),
  description: z.string(),
  options: z.array(...),
  threadId: z.string(),   // ★ 必填 —— 修复 P0
  traceId: z.string().optional(),
})

export const DoneSSEPayloadSchema = z.object({
  type: z.literal("done"),
  threadId: z.string(),
  traceId: z.string(),
})

// ─── H5 Agent 请求体 ───
export const H5AgentRequestBodySchema = z.object({...})

// ─── Resume 请求体 ───
export const ResumeRequestBodySchema = z.object({...})
```

---

## 三、实施步骤 + 依赖图

```
轮次 1 (P0 — SSE 事件): 2 文件
  InterruptSSEPayloadSchema + DoneSSEPayloadSchema
  handleInterrupt 修复 + resolveStreamEnd Zod 校验
  │
  ▼
轮次 2 (P1 — H5 端点): ~5 文件
  h5/agent: 请求体 + 响应事件
  h5/agent/resume: 请求体
  h5/production-plan/*: 已有部分 schema，补齐
  h5/nongqing/*: 补齐
  │
  ▼
轮次 3 (P1 — Agent 端点): ~4 文件
  agent/chat/stream, agent/resume, agent/[hash]
  │
  ▼
轮次 4 (P2 — 其余端点): ~10 文件
  admin, knowledge, document, model 等
```

### 轮次 1: P0 SSE 事件 Zod 加固

- **文件**: `src/app/api/types/schemas.ts`（新建统一 schema 文件）
- **文件**: `src/caijuehub/strategies/sse-terminal-event.ts`（修改 handleInterrupt）
- **内容**:
  - 定义 `InterruptSSEPayloadSchema`（含 `threadId: z.string()` 必填）
  - 定义 `DoneSSEPayloadSchema`
  - `handleInterrupt` 增加 `meta: { threadId, traceId }` 参数
  - L44 替换为 `safeParse` + 降级 payload
- **验收**: curl 测试中断流包含 `threadId`

### 轮次 2: H5 端点请求体 Zod

- **文件**: `h5/agent/route.ts`、`h5/agent/[threadId]/resume/route.ts`、`h5/production-plan/*/route.ts`、`h5/nongqing/*/route.ts`
- **内容**: 每个端点 `request.json()` 后 → `safeParse` → 失败返回 400
- **验收**: 错误格式请求体返回 400（非 500）

### 轮次 3-4: 其余端点

- 按频率排序，agent 核心端点优先

---

## 四、验收标准

- [ ] `InterruptSSEPayloadSchema` 定义 + `threadId` 必填
- [ ] H5 中断流 curl 测试包含 `threadId`
- [ ] H5 agent 请求体非法格式返回 400（非 500）
- [ ] `handleInterrupt` 使用 `safeParse` 替代裸 `JSON.stringify`
- [ ] 新增 schema 文件路径统一在 `src/app/api/types/schemas.ts`

---

## 五、关联文档

| 文档 | 路径 |
|------|------|
| Code Review | `code-review-combined-report.md` §13, §15 |
| SSE 协议 | `docs/.../瑞丰耘H5小程序SSE流式聊天协议文档.md` §7 |
| 已有 schema | `src/app/api/h5/types/schemas.ts` |
