# farm-agent-log-folder-restructure-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。
> **模式**：重型（Heavyweight）
> **绑定**：Plan: `farm-agent-log-folder-restructure-plan-v1` · Spec: `.qoder/specs/farm-agent-log-folder-restructure/` · Tasks: `.qoder/specs/farm-agent-log-folder-restructure/tasks.md` · Handoff: `.qoder/plans/2026-06/30/farm-agent-log-folder-restructure-handoff-v1.md`

## Step 0：文档先行

- [ ] Specs 三元组路径确认（本次为纯重构，共享 Plan 目录）
- [x] `find_related_docs` 已调用（0 直接匹配，纯结构重构无行为变更）
- [x] 项目文档无需更新声明（纯结构调整，不改变任何接口契约。`《裁决层-AuditLog写入契约》.md` 中的 `agent-audit-logger.ts` 路径引用将在 Step 8 第二阶段校准）
- [ ] Handoff 就绪（Step 8 后生成）

### 0.8 DPS 闸门

> 纯结构重构：DPS ≥ 70 即可通过。Plan 已覆盖目标结构、依赖图、ADD-7 策略表。

- [ ] DPS 验证通过

## Step 1：功能分析与审计阶段定义

**本次变更**：纯结构重构，不新增业务阶段，不扩展 `AgentAuditPhase`。`AgentAuditPhase` 类型整体迁移至 `phase.ts`，内容不变。

- [x] 验证并更新项目状态：无需新增 AgentAuditPhase 字面量（纯重构）

## Step 2：审计基础设施确认

审计基础设施全部保留，仅变更文件位置。`agentAudit()` / `writeAuditLog()` / `sendAlert()` 所有公共 API 通过 `index.ts` 统一导出，外部调用方无感知。

- [x] 验证并更新项目状态：审计通道保留不变

## Step 3：业务逻辑实现与审计植入

### Task 映射表

| # | Task | 文件 | 审计植入点 | 状态 |
|---|------|------|-----------|------|
| 1 | 创建 phase.ts | src/lib/log/phase.ts | 无（纯类型文件） | ✅ |
| 2 | 创建 audit.ts | src/lib/log/audit.ts | 保留原有 agentAudit/writeAuditLog | ✅ |
| 3 | 创建 compat.ts | src/lib/log/compat.ts | 无（兼容层） | ✅ |
| 4 | 迁移 notify | src/lib/log/notify/* | 保留原有 channel 逻辑 | ✅ |
| 5 | 创建 index.ts | src/lib/log/index.ts | 无（纯 re-export） | ✅ |
| 6 | 更新外部 67 文件 | 各 src/agents/、src/lib/*、scripts/* 文件 | import 路径变更 | ✅ |
| 7 | 删除旧文件 | src/lib/agent-audit-logger.ts 等 | N/A | ✅ |
| 8 | 编译验证 | — | tsc --noEmit（重构相关零错误） | ✅ |

### 依赖拓扑

```
Task 1 → Task 2 (audit.ts import phase)
Task 3 → Task 4 (compat.ts re-export notify)
Task 2,4,5 → Task 6 (外部 import 需所有新文件就位)
Task 6 → Task 7 → Task 8
```

## 附录：文件清单

| 文件 | 操作 | Task | targetType | 状态 |
|------|------|------|-----------|------|
| src/lib/log/phase.ts | CREATE | 1 | COMPONENT | ✅ |
| src/lib/log/audit.ts | CREATE | 2 | COMPONENT | ✅ |
| src/lib/log/compat.ts | CREATE | 3 | COMPONENT | ✅ |
| src/lib/log/notify/* | CREATE | 4 | MODULE | ✅ |
| src/lib/log/index.ts | CREATE | 5 | COMPONENT | ✅ |
| 67 外部文件 | MODIFY | 6 | DEPENDENCY | ✅ |
| src/lib/agent-audit-logger.ts | DELETE | 7 | COMPONENT | ✅ |
| src/lib/notify/ | DELETE | 7 | MODULE | ✅ |
| src/lib/wecom-notify.ts | DELETE | 7 | COMPONENT | ✅ |
