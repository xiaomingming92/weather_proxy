# Plan: 日志模块重复代码消除 + 审计通道统一 + agents/index.ts 拆分

> 来源: `.qoder/reports/code-review-combined-report.md` #6-#9
> 创建: 2026-06-30 (v1) → 2026-07-01 (v2 修订)
> 版本: v2
> v2 修订: 修正 Atom 2 合并策略、Atom 3 Schema 对齐、Atom 4 行号，补充完整的依赖关系与实施细节

---

## 问题摘要

| # | 问题 | 严重度 | 涉及文件 |
|---|------|--------|---------|
| 6 | 7 个 logger + `audit.ts` 共 8 个文件共享相同 `ensureLogDir/writeToFile/formatMessage` 代码模式 | P1 | 8 文件 |
| 7 | `agent-gateway-dev-logger.ts` (仅 IS_DEV) 与 `agent-gateway-audit.ts` (始终运行) 行为/类型不一致 | P1 | 2 文件 |
| 8 | `audit-log.ts` 内存存储，与 DB 持久化方案不一致，且 `createAuditLog()` 无内部调用方 | P2 | 1 文件 |
| 9 | `agents/index.ts` 职责过大 (563 行) | P1 | 1 文件 |

> Issue #10 (LLM 单例全局可变状态问题) 已独立为[单独 Plan](./code-review-llm-state-isolation-plan-v1.md)

---

## 当前代码基线分析

### Atom 1 相关：重复模式清单

**模式 A — 静态 fs import (5 个文件，纯服务端)**:

```
                  ensureLogDir()  writeToFile()  formatMessage()  readLogs()  clearLogs()  PhaseStart/End
audit-logger.ts       ✅              ✅              ✅             ✅          ✅           ✅
chat-persistence-logger.ts ✅        ✅              ✅             ✅          ✅           ✅
stream-bus-logger.ts  ✅              ✅              ✅             ✅          ✅           ✅
stream-chat-logger.ts ✅              ✅              ✅             ✅          ✅           ✅
agent-gateway-dev-logger.ts ✅      ✅              ✅             ✅          ✅           ✅
```

**模式 B — 动态 import("fs/promises") (2 个文件，Next.js 同构兼容)**:

```
                  ensureLogDir()  writeToFile()  formatMessage()  readLogs()  clearLogs()  PhaseStart/End
chat-stats-logger.ts  ✅              ✅              ✅             ✅          ✅           ✅
model-config-logger.ts ✅             ✅              ✅             ✅          ✅           ✅
```

**模式 C — `src/lib/log/audit.ts` (383 行)**: 内联了 `ensureLogDir/writeToFile/formatMessage` (L107-146)，同时包含丰富的 Layer 2 DB 审计逻辑。也需要迁移到 LogFileWriter。

**特殊差异**:
- `stream-bus-logger.ts` 已额外调用 `writeAuditLog`（DB 双写），是唯一有 DB 审计的模块级 logger
- `chat-stats-logger.ts` / `model-config-logger.ts` 使用 `isServer = typeof window === "undefined"` 守卫 + `webpackIgnore: true` 动态 import

### Atom 2 相关：当前 Gateway 审计状态

| 文件 | 行数 | 触发条件 | 输出通道 | 类型定义 |
|------|------|---------|---------|---------|
| `agent-gateway-dev-logger.ts` | 90 | `NODE_ENV === "development"` | console + file | `AgentGatewayAuditPhase` (7 members) |
| `agent-gateway-audit.ts` | 67 | 始终运行 | console + AuditLog DB | `AgentGatewayAuditAction` (8 members) |

**类型差异**:
- dev-logger: `GATEWAY_DASHBOARD \| THREAD_QUERY \| THREADS_LIST \| REPORT_EXPORT \| HANDSHAKE \| CHAT \| ERROR`
- audit: 多了 `GATEWAY_HANDSHAKE_RESUME_NO_THREAD`，且 ERROR 不作为 phase 而是 `recordAgentGatewayError()` 中固定设置

**调用方**: 仅 `src/app/api/agent/[hash]/route.ts`，同时 import 两个文件

### Atom 3 相关：audit-log.ts 使用情况

- `createAuditLog()`: **无内部调用方**，仅通过 `src/services/index.ts` 对外导出
- `getAuditLogs()`: 被 `src/app/api/audit/route.ts` 调用（管理员查询审计日志 API）
- `getAuditLogsByTarget()`: 导出但无调用方
- Schema 差异:
  - `AuditLogEntry` 有 `ip`, `userAgent` → Prisma `AuditLog` 模型**没有这两个字段**
  - `AuditLogEntry.action` 类型 `AuditAction` (CREATE/UPDATE/DELETE/...) → Prisma `AuditLog.action` 是自由 `String`

### Atom 4 相关：agents/index.ts 精确行号

| 代码段 | 行号 | 目标文件 |
|--------|------|---------|
| `createToolNodeWrapper` 函数 | L34-L187 | `tool-node-wrapper.ts` |
| `workflow` (StateGraph deep 图) | L189-L242 | `graph.ts` |
| `professionalWorkflow` (StateGraph professional 图) | L245-L300 | `graph.ts` |
| `activeTracers` Map + `tracerCreateTimes` Map + `cleanupExpiredTracers` | L302-L323 | `tracer-store.ts` |
| `wrapNodeWithAudit` 函数 | L325-L411 | `audit-wrapper.ts` |
| `getActiveTracer` + `startChainTrace` + `endChainTrace` | L413-L435 | `tracer.ts` |
| `runAgent` 函数 | L437-L468 | `agent-runner.ts` |
| `StreamAgentInput` 接口 | L470-L483 | `agent-runner.ts` |
| `streamAgent` 函数 | L485-L542 | `agent-runner.ts` |
| `buildPartialState` 函数 | L544-L561 | `agent-runner.ts` |

**外部引用** (25+ 处 `import ... from "@/agents"` 或 `"@/agents/..."`):
- 直接 `@/agents`: 8 处（`streamAgent`, `startChainTrace`, `endChainTrace`, `runAgent`, `agent`, `StreamAgentInput`, `getActiveTracer`）
- `@/agents/experts/registry`: 5 处
- `@/agents/stream-bus`: 4 处
- `@/agents/sse-stream-state`: 2 处
- 其他子路径: 6 处

---

## 原子事务拆分

### Atom 1: 提取公共日志基础设施 (`LogFileWriter`)

**目标**: 消除 8 个文件中的 `ensureLogDir()` + `writeToFile()` + `formatMessage()` 重复代码

**方案**:

#### 1a. 核心类设计

```
src/lib/log/file-writer.ts

interface LogFileWriterOptions {
  prefix: LogPrefix        // 枚举值 LogPrefix.AGENT_AUDIT / LogPrefix.KB_AUDIT / ...
  logDir: string           // 日志目录
  logFile: string          // 日志文件名（不含日期后缀）
  enableFileLog: boolean   // 是否启用文件日志
  rotation? {              // 日志轮转策略（仅在 enableFileLog=true 时生效）
    type: "daily"          // 按天轮转（当前唯一策略）
    maxDays?: number       // 保留最近 N 天，默认 7
    maxSizeMB?: number     // 单文件最大 MB，默认 50，超过递增 index
  }
  format?: "plain" | "jsonl"  // 文件输出格式，默认 "jsonl"
}

class LogFileWriter {
  constructor(options: LogFileWriterOptions)
  ensureLogDir(): Promise<void>
  writeToFile(message: string): Promise<void>      // plain 模式使用
  writeJSONLEntry(entry: LogEntry): Promise<void>  // JSONL 模式使用
  formatMessage(phase: string, detail: string, extra?: Record<string, unknown>): string
  toJSONLEntry(phase: string, detail: string, extra?: Record<string, unknown>): LogEntry
  rotate(): Promise<void>          // 触发轮转检查（每次 write 前自动调用）
  cleanup(): Promise<void>         // 清理过期文件
  // 便捷方法
  log(phase: string, detail: string, extra?: Record<string, unknown>): void
  logPhaseStart(phase: string, description: string, count?: number): void
  logPhaseEnd(phase: string, detail: string): void
  readLogs(lines?: number): Promise<string[]>
  clearLogs(): Promise<void>
  getLogPath(): Promise<string>
}
```

#### 1b. 同构兼容方案

针对 `chat-stats-logger.ts` 和 `model-config-logger.ts` 的 Next.js 同构需求，提供 **`LazyLogFileWriter`** 子类：

```typescript
class LazyLogFileWriter extends LogFileWriter {
  // 重写 ensureLogDir/writeToFile，使用 await import("fs/promises")
  // 增加 isServer = typeof window === "undefined" 守卫
  // webpackIgnore: true 动态 import
  constructor(options: LogFileWriterOptions & { isServer?: boolean })
}
```

调用方只需创建不同的实例：
- 纯服务端模块 → `new LogFileWriter({...})`
- 同构模块 → `new LazyLogFileWriter({...})`

#### 1c. 迁移清单

| 文件 | 迁移方式 | 保留内容 |
|------|---------|---------|
| `src/lib/audit-logger.ts` | 创建 `LogFileWriter` 实例，替换 `ensureLogDir/writeToFile/formatMessage` | 所有 `audit*` 公共函数、`AuditPhase` 类型 |
| `src/lib/chat-persistence-logger.ts` | 同上 | `chatPersistAudit*` 函数、`ChatPersistencePhase` 类型 |
| `src/lib/stream-bus-logger.ts` | 同上 | `streamBusAudit*` 函数、DB 双写逻辑、`StreamBusAuditPhase` 类型 |
| `src/lib/stream-chat-logger.ts` | 同上 | `streamChatAudit*` 函数、`StreamChatAuditPhase` 类型 |
| `src/lib/agent-gateway-dev-logger.ts` | 同上 | `agentGatewayAudit*` 函数、`AgentGatewayAuditPhase` 类型（Atom 2 会进一步处理） |
| `src/lib/chat-stats-logger.ts` | 创建 `LazyLogFileWriter` 实例 | `chatStatsAudit*` 函数、`ChatStatsAuditPhase` 类型 |
| `src/lib/model-config-logger.ts` | 创建 `LazyLogFileWriter` 实例 | `modelConfigAudit*` 函数、`ModelConfigAuditPhase` 类型 |
| `src/lib/log/audit.ts` | 创建 `LogFileWriter` 实例，替换 L107-146 | 所有 `agentAudit*` 函数、`writeAuditLog`、失败计数器 |

**验证**:
- 所有 8 个模块编译通过
- 现有日志输出格式不变 (PREFIX / 时间戳 / phase)
- 同构模块在浏览器端不报错（动态 import 不触发）
- `audit.ts` 中的 DB 审计逻辑不受影响

---

### Atom 2: 统一 Gateway 审计模块

**目标**: 合并两个文件为一个统一模块，消除 IS_DEV 条件编译和类型不一致

**当前问题**:
- 两份代码互为补集：dev-logger 出 console+file（IS_DEV guard，生产静默），audit.ts 出 console+DB（始终运行）。开发环境实际收到两套格式不同的日志输出，排查反而混乱。
- 类型不一致：dev-logger 的 `AgentGatewayAuditPhase` 缺少 `GATEWAY_HANDSHAKE_RESUME_NO_THREAD`，两份 Phase 类型需要人工同步。

**Prod file 的代价与设计约束**:
- 无 rotation：当前所有 logger 均为无限追加，生产 file 日志必须先解决自动轮转（按大小或按天 + 保留最近 N 个），否则磁盘会打满。方案中需补充 rotation 策略。
- Dev 已有 AuditLog DB 覆盖：gateway 日志在 dev 下实际已通过 audit.ts 写入 AuditLog 表，file 的价值在于「无需连 DB 的快速 grep/tail」，而非填补 DB 空白。
- 格式不利于 debug：当前格式为 `[PREFIX] [ts] [phase] desc | {json}`，不是合法 JSON 行（非 JSONL），`jq` / 日志聚合器无法解析。方案中需改为 JSONL（每行一个合法 JSON 对象），至少包含 ts、prefix、phase、entityId、detail 字段。

**方案**:

1. **File 日志输出格式切换为 JSONL**：每行一个合法 JSON 对象，便于 `jq` 过滤和日志聚合器解析。
   ```json
   {"ts":"2026-07-01T00:00:00.000Z","prefix":"AGENT_GATEWAY","phase":"GATEWAY_CHAT","entityId":"xxx","detail":{"key":"value"}}
   ```
   Console 输出保持人类可读格式（`[PREFIX] [ts] [phase] desc`），file 输出使用 JSONL。

2. **以 `agent-gateway-audit.ts` 为基础**，注入 `LogFileWriter`（Atom 1 产物）：
   - Dev 环境：console + file（JSONL）+ DB（AuditLog 表，audit.ts 已在写），三通道统一到一个模块
   - Prod 环境：console + file（JSONL）+ DB，file 由 Atom 1 的 rotation 机制兜底大小

3. **File rotation 策略**（由 Atom 1 的 `LogFileWriter` 统一提供，非 Atom 2 独立实现）:
   - 按天轮转：`agent-gateway-2026-07-01.log` → 次日自动切换到新文件
   - 保留最近 N 天（默认 7 天），超期自动清理
   - 可选：同时限制单文件最大大小（默认 50MB），超过后 `agent-gateway-2026-07-01.1.log` 递增

4. **统一类型** `AgentGatewayAuditPhase`（保留 audit.ts 已有的 8 个 action + dev-logger 特有的 RESUME_NO_THREAD）：
   ```typescript
   type AgentGatewayAuditPhase =
     | "GATEWAY_DASHBOARD"
     | "GATEWAY_THREAD_QUERY"
     | "GATEWAY_THREADS_LIST"
     | "GATEWAY_REPORT_EXPORT"
     | "GATEWAY_HANDSHAKE"
     | "GATEWAY_HANDSHAKE_RESUME_NO_THREAD"  // 来自 audit
     | "GATEWAY_CHAT"
     | "GATEWAY_ERROR"
   ```

5. **统一函数签名**：
   ```typescript
   // 替代 agentGatewayAudit() + recordAgentGatewayAudit()
   export function agentGatewayAudit(
     phase: AgentGatewayAuditPhase,
     detail: string,
     extra?: Record<string, unknown>,
     options?: { dbAudit?: boolean }  // 默认 true
   ): void

   // 替代 agentGatewayAuditPhaseStart/End
   export function agentGatewayAuditPhaseStart(phase, description, count?): void
   export function agentGatewayAuditPhaseEnd(phase, detail): void

   // 替代 recordAgentGatewayError
   export function agentGatewayAuditError(action, entityId, error, extra?): void

   // 文件日志工具
   export async function readAgentGatewayLogs(lines?): Promise<string[]>
   export async function clearAgentGatewayLogs(): Promise<void>
   ```

6. **文件操作**:
   - 删除 `src/lib/agent-gateway-dev-logger.ts`
   - 重写 `src/lib/agent-gateway-audit.ts`（使用 `git mv` 保留 git 历史：`agent-gateway-dev-logger.ts` → 先备份关键代码，再删除旧 audit.ts，用新内容覆盖）

7. **调用方更新** (`src/app/api/agent/[hash]/route.ts`):
   - 删除 `agent-gateway-dev-logger` 的 import
   - 统一从 `@/lib/agent-gateway-audit` 导入
   - 将 `recordAgentGatewayAudit()` 调用改为 `agentGatewayAudit()`
   - 将 `recordAgentGatewayError()` 调用改为 `agentGatewayAuditError()`

**验证**:
- Dev/Prod 三通道（console 人类可读 + file JSONL + DB）均正常输出
- File 输出为合法 JSONL（每行 `JSON.parse` 成功）
- Rotation 按天生效：跨天后自动切换到新文件，旧文件保留
- Cleanup 自动清理超过 7 天的日志文件
- 不再有 IS_DEV 静默（行为一致）
- 无重复类型定义
- 调用方只有 1 个 import 而非 2 个

---

### Atom 3: `audit-log.ts` 内存存储 → DB 持久化

**目标**: 将 `src/services/audit-log.ts` 的内存数组替换为 Prisma 查询

**当前状态**:
- `createAuditLog()`: 无内部调用方（死代码），仅对外导出
- `getAuditLogs()`: 仅被 `src/app/api/audit/route.ts` 调用
- `getAuditLogsByTarget()`: 无调用方
- `AuditLogEntry` 类型有 `ip/userAgent` 字段 → Prisma `AuditLog` 模型没有

**方案**:

1. **Schema 对齐**: Prisma `AuditLog` 模型不增加 `ip/userAgent` 字段（当前无写入调用方，不需要）。`AuditLogEntry` 接口删除 `ip/userAgent`，与 DB 模型对齐。

2. **`getAuditLogs()` 迁移**: 改为直接调用 `prisma.auditLog.findMany()`：
   ```typescript
   export async function getAuditLogs(filters?: {...}): Promise<AuditLogEntry[]> {
     const where: Prisma.AuditLogWhereInput = {}
     if (filters?.userId) where.userId = filters.userId
     if (filters?.action) where.action = filters.action
     if (filters?.targetType) where.targetType = filters.targetType
     if (filters?.targetId) where.targetId = filters.targetId
     if (filters?.startDate) where.createdAt = { ...(where.createdAt as object), gte: new Date(filters.startDate) }
     if (filters?.endDate) where.createdAt = { ...(where.createdAt as object), lte: new Date(filters.endDate) }
     
     const logs = await prisma.auditLog.findMany({
       where,
       orderBy: { createdAt: "desc" },
     })
     return logs.map(mapToAuditLogEntry)
   }
   ```

3. **`createAuditLog()`**: 改为薄包装，调用 `writeAuditLog()`（复用 `src/lib/log/audit.ts` 已有的 DB 写入 + 失败告警）：
   ```typescript
   export async function createAuditLog(entry: Omit<AuditLogEntry, "id" | "createdAt">): Promise<void> {
     await writeAuditLog(entry.action, entry.targetType, entry.targetId, 
       { ...entry.beforeState, ...entry.afterState }, entry.reason)
   }
   ```

4. **`getAuditLogsByTarget()`**: 改为 Prisma 查询（保持 API 签名不变）

5. **删除内存数组** `auditLogs[]`，不再需要。

6. **保留 API 签名不变**，外部调用方（`src/app/api/audit/route.ts`、`src/services/index.ts`）无需修改。

**验证**:
- `getAuditLogs()` 返回 DB 中的历史数据
- 进程重启后数据不丢失
- `src/app/api/audit/route.ts` 的 GET 接口正常返回
- `AuditLogEntry` 类型与 Prisma 模型字段对齐

---

### Atom 4: `agents/index.ts` 职责拆分

**目标**: 将 563 行的单体文件拆分为 5 个职责清晰的模块

**拆分方案** (修正 v1 行号错误):

| 新文件 | 职责 | 原代码行号 | 导出 |
|--------|------|-----------|------|
| `src/agents/tracer-store.ts` | `activeTracers` Map + `tracerCreateTimes` Map + `cleanupExpiredTracers` | L302-L323 | `activeTracers`, `tracerCreateTimes`, `cleanupExpiredTracers`, `TRACER_TTL_MS` |
| `src/agents/tracer.ts` | `getActiveTracer` + `startChainTrace` + `endChainTrace` | L413-L435 | `getActiveTracer`, `startChainTrace`, `endChainTrace` |
| `src/agents/tool-node-wrapper.ts` | `createToolNodeWrapper` 函数 | L34-L187 | `createToolNodeWrapper` |
| `src/agents/audit-wrapper.ts` | `wrapNodeWithAudit` 函数 | L325-L411 | `wrapNodeWithAudit` |
| `src/agents/graph.ts` | `workflow` (deep) + `professionalWorkflow` + `agent` + `professionalGraph` | L189-L300 | `agent`, `professionalGraph` |
| `src/agents/agent-runner.ts` | `runAgent` + `streamAgent` + `StreamAgentInput` + `buildPartialState` | L437-L561 | `runAgent`, `streamAgent`, `StreamAgentInput` |

**保留在 `index.ts`**:
- 所有 import（节点、边、工具、审计等）
- `setAgentTools(agentTools)` 调用（L31）
- Re-export 上述 5 个模块的公共 API
- `export { agentTools }` (L563)

**依赖关系**:
```
tracer-store.ts (无依赖)
    ├─→ tracer.ts (import tracer-store)
    ├─→ audit-wrapper.ts (import log + tracer-store, optional import tracer)
    └─→ index.ts (import all)

tool-node-wrapper.ts (import tools + log + stream-controller + event-bus)
graph.ts (import nodes + edges + audit-wrapper + tool-node-wrapper)
agent-runner.ts (import graph + log + callback + checkpointer)
```

**关键修正**: v1 将 `wrapNodeWithAudit` (L325-L411) 错误地归入 `tracer.ts`。实际上它属于审计包装逻辑，应独立为 `audit-wrapper.ts`。而真正的 tracer 代码 (L413-L435) 才是 `tracer.ts`。两者之间的公共状态（`activeTracers` Map）提取到 `tracer-store.ts` 避免循环依赖。

**验证**:
- 所有 25+ 处 `import { ... } from "@/agents"` 无需修改（`index.ts` 保留 re-export）
- 子路径 import（`@/agents/experts/registry` 等）不受影响
- `agent` / `professionalGraph` 编译通过
- `runAgent` / `streamAgent` 调用正常
- `getActiveTracer` 在 `edges/conditional.ts` 和 `nodes/retrieval.ts` 中正常

---

## 执行顺序

```
Atom 1 (LogFileWriter 基础设施)
  ├─→ Atom 2 (Gateway 审计统一，依赖 Atom 1 的 LogFileWriter)
  └─→ Atom 4 的 audit-wrapper.ts (也使用 LogFileWriter 替代直接 fs import)
Atom 3 (audit-log DB 持久化，无依赖)
Atom 4 (agents/index.ts 拆分，无依赖，但 audit-wrapper.ts 可复用 Atom 1)
```

推荐执行顺序: **Atom 1 → Atom 2 → Atom 3 (可并行 Atom 4) → Atom 4 (可并行 Atom 3)**

---

## 风险评估

| 风险 | 严重度 | 缓解 |
|------|--------|------|
| LogFileWriter 改变日志格式，破坏下游解析 | P1 | 严格保持 `PREFIX [ISO时间戳] [phase] detail | {extra}` 格式不变 |
| `LazyLogFileWriter` 动态 import 在 Edge Runtime 下行为未知 | P2 | 仅 chat-stats/model-config 两个模块使用，它们在 server 端运行，增加 `typeof window === "undefined"` 守卫 |
| agents/index.ts 拆分破坏 import 路径 | P1 | 保留 `index.ts` re-export，所有 `@/agents` 引用无需改；`tracer-store.ts` 提取消除 audit-wrapper ↔ tracer 循环依赖 |
| audit-log.ts `ip/userAgent` 字段删除影响 API 响应格式 | P3 | 当前无内部写入调用方，API 调用方不依赖这两个字段（已验证 `audit/route.ts` 只遍历返回数组） |
| Atom 2 移除 IS_DEV guard 后生产日志量激增 | P2 | 生产环境默认 `ENABLE_FILE_LOG=false`（通过 env var 控制），不增加 I/O 负担 |
| Atom 3 schema 字段对齐遗漏 | P2 | 在迁移前运行 `npx prisma db pull` 确认 AuditLog 模型最新字段 |

---

## ADD 工作流衔接

- **Step 0**: 本 Plan 已包含 DPS 所需的问题定义 + 原子拆分 + 风险评估
- **Step 1-2**: 按 Atom 执行顺序逐个实现，每个 Atom 完成后运行 TypeScript 编译 + 现有测试
- **Step 3**: Atom 4 需要运行 `getActiveTracer` 的调用链路测试
- **Step 8**: 验收后写 devlog日志(走mcp) 至 `.qoder/plans/2026-07/01/` + 更新 handoff
