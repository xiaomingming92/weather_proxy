# farm-agent-api-zod-hardening-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"，包含 `check_spec_sync` 文档-代码交叉校验。
>
> **绑定**：Plan: `.qoder/plans/2026-06/30/farm-agent-api-zod-hardening-plan-v1.md` · Spec: `.qoder/specs/farm-agent-api-zod-hardening/` · Handoff: `.qoder/plans/2026-06/30/farm-agent-api-zod-hardening-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全，项目文档反映即将实现的变更。

**输入**：
- 上游 Review（`farm-agent-api-zod-hardening-review-v1.md`，3 P0 已回流）
- Plan v1（`.qoder/plans/2026-06/30/farm-agent-api-zod-hardening-plan-v1.md`）

**动作**：
1. 确认 Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
2. 调用 `find_related_docs` 检索受影响的 API 协议文档
3. 项目文档：本次变更涉及 4 份 SSE/API 协议文档，代码改动后同步更新
4. 确认 Handoff 就绪（5 轮多轮 handoff）

**产出**：
- [x] 验证并更新项目状态：Plan Review 已生成并回流（3 P0 → Plan §三/四/五 已修正）
- [ ] 验证并更新项目状态：Specs 三元组路径确认（Step 1 创建）
- [ ] 验证并更新项目状态：项目文档已更新（详见 Plan §2.3 双向锚定表）
- [ ] 验证并更新项目状态：Handoff 就绪

### §0.7 原子闭包判定

**业务功能**: src/app/api/ 下全部对内外接口的 Zod schema 校验覆盖

**逐组业务价值判定**:
- 轮次 1 (SSE Zod + H5 interrupt fix): **能用** — 修复生产 P0，中断流携带 threadId → curl 可验证
- 轮次 2 (H5 请求体 Zod): **能用** — H5 端点错误格式返回 400，独立完成 H5 路径校验
- 轮次 3 (hash 神经元 请求体 Zod): **能用** — 神经元端点独立校验，不影响 H5
- 轮次 4 (farm-agent 自有 请求体 Zod): **能用** — 内部端点校验
- 轮次 5 (其余端点): **能用** — 低频端点，可延后

**判定结论**: 需要 5 轮（5 个原子闭包，三路径并行不依赖）

### §0.8 DPS 闸门

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**输入**：
- Plan 的 5 轮 3 方向结构
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase` 联合类型

**动作**：
1. 新增 `ZOD_VALIDATE_FAIL` 审计阶段（Zod safeParse 失败时记录）
2. 新增 `ZOD_SCHEMA_ADDED` 审计阶段（每个端点 Zod schema 落成）

**产出**：
- [x] 验证并更新项目状态：AgentAuditPhase 已扩展（`ZOD_VALIDATE_FAIL`，src/lib/log/phase.ts L152）

| Phase | 使用场景 | 轮次 |
|-------|---------|:--:|
| `ZOD_VALIDATE_FAIL` | safeParse 失败返回 400 时记录 | 1-5 |
| `ZOD_SCHEMA_ADDED` | 每个端点 Zod schema 落成时记录 | 1-5 |

---

## Step 2：审计基础设施确认

**产出**：
- [ ] 验证并更新项目状态：`agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

### §3.0 前置守卫

调用 `check_add_route_status({ planKeyword: "api-zod-hardening" })`

### Task 映射表 — 轮次 1: P0 SSE 事件 Zod

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|:--:|
| 1.1 | 新建 SSE schema 文件 | `src/app/api/types/sse/schemas.ts` | `ZOD_SCHEMA_ADDED` | — | 无 | ⬜ |
| 1.2 | 新建 index.ts barrel | `src/app/api/types/index.ts` | 无（结构文件） | — | 1.1 | ⬜ |
| 1.3 | 修改 handleInterrupt + safeParse | `src/caijuehub/strategies/sse-terminal-event.ts` | `ZOD_VALIDATE_FAIL`（降级时） | — | 1.1 | ⬜ |
| 1.4 | H5 agent 调用方加 meta | `src/app/api/h5/agent/route.ts` | 无（参数变更） | — | 1.3 | ⬜ |
| 1.5 | H5 resume 调用方加 meta | `src/app/api/h5/agent/[threadId]/resume/route.ts` | 无（参数变更） | — | 1.3 | ⬜ |
| 1.6 | agent/chat/stream 调用方查+加 | `src/app/api/agent/chat/stream/route.ts` | 无（参数变更） | — | 1.3 | ⬜ |
| 1.7 | agent/resume 调用方查+加 | `src/app/api/agent/resume/route.ts` | 无（参数变更） | — | 1.3 | ⬜ |
| 1.8 | SSE 协议文档同步 | `docs/.../瑞丰耘H5小程序SSE流式聊天协议文档.md` | `DOC_UPDATED` | — | 1.3 | ⬜ |

### Task 映射表 — 轮次 2: P1 H5 端点 请求体 Zod

| # | Task | 文件 | 审计植入点 | 依赖 | 状态 |
|---|------|------|-----------|------|:--:|
| 2.1 | 迁移 h5/types/schemas.ts → api/types/h5/schemas.ts | `src/app/api/types/h5/schemas.ts` | `ZOD_SCHEMA_ADDED` | 1.2 | ⬜ |
| 2.2 | H5 agent chat 请求体 Zod | `src/app/api/h5/agent/route.ts` | `ZOD_VALIDATE_FAIL` | 2.1 | ⬜ |
| 2.3 | H5 resume 请求体 Zod | `src/app/api/h5/agent/[threadId]/resume/route.ts` | `ZOD_VALIDATE_FAIL` | 2.1 | ⬜ |
| 2.4 | H5 production-plan/land-analysis Zod | `src/app/api/h5/production-plan/land-analysis/route.ts` | `ZOD_VALIDATE_FAIL` | 2.1 | ⬜ |
| 2.5 | H5 production-plan/variety-recommend Zod | `src/app/api/h5/production-plan/variety-recommend/route.ts` | `ZOD_VALIDATE_FAIL` | 2.1 | ⬜ |
| 2.6 | H5 production-plan/cost-accounting Zod | `src/app/api/h5/production-plan/cost-accounting/route.ts` | `ZOD_VALIDATE_FAIL` | 2.1 | ⬜ |
| 2.7 | H5 production-plan/generate Zod | `src/app/api/h5/production-plan/generate/route.ts` | `ZOD_VALIDATE_FAIL` | 2.1 | ⬜ |
| 2.8 | H5 nongqing/overview Zod | `src/app/api/h5/nongqing/overview/route.ts` | `ZOD_VALIDATE_FAIL` | 2.1 | ⬜ |
| 2.9 | H5 nongqing/daily-report Zod | `src/app/api/h5/nongqing/daily-report/route.ts` | `ZOD_VALIDATE_FAIL` | 2.1 | ⬜ |
| 2.10 | 更新 11 处 import 路径 (h5/types/ → api/types/h5/) | 各 h5 route.ts | 无 | 2.1 | ⬜ |
| 2.11 | H5 API 文档同步 | `docs/.../瑞丰耘H5小程序API对接文档.md` | `DOC_UPDATED` | 2.2 | ⬜ |

### Task 映射表 — 轮次 3-5: P1/P2 其余端点

| # | 轮次 | Task | 文件 | 审计植入点 | 状态 |
|---|:--:|------|------|-----------|:--:|
| 3.1 | 3 | hash 端点 schema | `src/app/api/types/hash/schemas.ts` | `ZOD_SCHEMA_ADDED` | ⬜ |
| 3.2 | 3 | agent/[hash] 请求体 Zod | `src/app/api/agent/[hash]/route.ts` | `ZOD_VALIDATE_FAIL` | ⬜ |
| 3.3 | 3 | agent/chat/threads 请求体 Zod | `src/app/api/agent/chat/threads/route.ts` | `ZOD_VALIDATE_FAIL` | ⬜ |
| 3.4 | 3 | 神经元 SSE/API 文档同步 | `docs/.../神经元GUI-*.md` | `DOC_UPDATED` | ⬜ |
| 4.1 | 4 | farm-agent schema | `src/app/api/types/farm-agent/schemas.ts` | `ZOD_SCHEMA_ADDED` | ⬜ |
| 4.2 | 4 | agent/chat/stream 请求体 Zod | 同上文件 | `ZOD_VALIDATE_FAIL` | ⬜ |
| 4.3 | 4 | agent/resume 请求体 Zod | `src/app/api/agent/resume/route.ts` | `ZOD_VALIDATE_FAIL` | ⬜ |
| 5.1 | 5 | 其余 schema (admin/auth/knowledge/etc) | `src/app/api/types/farm-agent/schemas.ts` | `ZOD_SCHEMA_ADDED` | ⬜ |

### 依赖拓扑

```
1.1 ──→ 1.2 ──→ 1.3 ──→ 1.4,1.5,1.6,1.7 ──→ 1.8
                              │
2.1 ──→ 2.2~2.10 ──→ 2.11    (独立于 1.x，依赖 1.2 index.ts)
                              │
3.1 ──→ 3.2,3.3 ──→ 3.4      (独立于 2.x)
4.1 ──→ 4.2,4.3               (独立于 3.x)
5.1                           (独立于 4.x)
```

---

## Step 3.5：实现审查

每轮完成后执行：
1. `npx tsc --noEmit` 零错误
2. curl 测试对应的端点
3. 文档同步检查

---

## Step 4：审计数据验证

- [ ] `npx tsc --noEmit` 通过
- [ ] `npm run lint` 通过

### §4.6 RAHS 闸门

- [ ] RAHS 已通过（≥ 90）

---

## Step 5-8：合规检查 → 收敛

按重型模板逐 Step 执行，收归于 Handoff。

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/app/api/types/index.ts` | CREATE | 1.2 | TYPE | ⬜ |
| `src/app/api/types/sse/schemas.ts` | CREATE | 1.1 | TYPE | ⬜ |
| `src/app/api/types/h5/schemas.ts` | CREATE | 2.1 | TYPE | ⬜ |
| `src/app/api/types/hash/schemas.ts` | CREATE | 3.1 | TYPE | ⬜ |
| `src/app/api/types/farm-agent/schemas.ts` | CREATE | 4.1 | TYPE | ⬜ |
| `src/caijuehub/strategies/sse-terminal-event.ts` | MODIFY | 1.3 | COMPONENT | ⬜ |
| `src/app/api/h5/agent/route.ts` | MODIFY | 1.4,2.2 | API_ROUTE | ⬜ |
| `src/app/api/h5/agent/[threadId]/resume/route.ts` | MODIFY | 1.5,2.3 | API_ROUTE | ⬜ |
| `src/app/api/h5/types/schemas.ts` | DELETE | 2.1 | TYPE | ⬜ |
| 其余 6 个 h5 route.ts | MODIFY | 2.4~2.10 | API_ROUTE | ⬜ |
| agent/[hash]/route.ts | MODIFY | 3.2 | API_ROUTE | ⬜ |
| agent/chat/stream/route.ts | MODIFY | 1.6,4.2 | API_ROUTE | ⬜ |
| agent/resume/route.ts | MODIFY | 1.7,4.3 | API_ROUTE | ⬜ |
