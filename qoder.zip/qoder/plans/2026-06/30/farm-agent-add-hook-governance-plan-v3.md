# farm-agent-add-hook-governance-plan-v3

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。**不要**在 Plan 中写完整 shell 实现——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-add-hook-governance-v3
- **启动时间**: 2026-06-30T01:00:00+08:00
- **主导 AI**: Qoder
- **前置 Plan**: [v1](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/30/farm-agent-add-hook-intelligence-plan-v1.md)（仅 UserPromptSubmit，已废弃）
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-06/30/farm-agent-add-hook-governance-add-route-v3.md`
  - Handoff: `.qoder/plans/2026-06/30/farm-agent-add-hook-governance-handoff-v3.md`
  - Review: `.qoder/reviews/farm-agent-add-hook-governance-review-v3.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `.qoder/settings.json` | CONFIG | CONFIG_UPDATED | UserPromptSubmit ×1 | 11 事件全覆盖 | 待实施 |
| `.qoder/hooks/` 下全部脚本 | SCRIPT | SCRIPTS_CREATED | 1 个入口脚本 | 7 个专业脚本 | 待实施 |
| `.qoder/vocabulary/add-governance-vocabulary.md` | DOC | DOC_UPDATED | 无机器可读触发词清单 | 新增附录：纯文本触发词清单 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

当前仅 1 个 `UserPromptSubmit` hook，覆盖不足。而 **Qoder 11 个 Hook 事件与 ADD 9 步流程天然对应**——事件驱动是 ADD 流程从"文档约定"升级为"系统强制执行"的桥梁：

| Qoder Hook | ADD 映射 | 当前有？ |
|-----------|---------|:--:|
| `SessionStart` | session-init 会话恢复 | ❌ |
| `UserPromptSubmit` | 触发词路由（56 条→操作） | ⚠️ 仅 20 条 |
| `PreToolUse` (Write/Edit) | Step 3 前置守卫（check_add_route_status） | ❌ |
| `PostToolUse` (Write/Edit) | Step 3 ADD-7 自动落库（record_dev_operation） | ❌ |
| `PostToolUseFailure` | Step 6/7 错误定位 | ❌ |
| `Stop` | Step 8 收敛检查（devlog/handoff/架构回看闭环） | ❌ |
| `SubagentStart/Stop` | Guardian 门禁调度 | ❌ |
| `PreCompact` | ADD 状态快照持久化 | ❌ |
| `Notification` (result) | Step 3.5/8 人工 Review 提醒 | ❌ |
| `PermissionRequest` | Step 0.6.5/3.5 Review 卡位确认 | ❌ |

### 1.2 目标

11 个事件全覆盖，形成 ADD 治理全生命周期：

```
SessionStart      → 上下文恢复
UserPromptSubmit  → 触发词智能路由
PreToolUse        → 写操作前置守卫
PostToolUse       → 审计自动落库
PostToolUseFailure → 失败路径追踪
Stop              → 验收闭环检查
SubagentStart/Stop → 门禁编排
PreCompact        → 状态持久化
Notification      → Review 提醒
PermissionRequest → 人工卡位确认
```

---

## 二、方案选型

**唯一方案**: 纯 shell + settings.json 事件配置。每个事件一个独立脚本，共享 vocabulary 和状态检测公共函数。

理由：
- Qoder hook 原生支持纯 shell，零冷启动
- 11 个独立脚本职责清晰，可单独测试
- 共享库（`hooks/lib/`）避免重复代码
- settings.json 一次配置，11 事件全部激活

---

## 三、架构设计

### 3.1 文件布局

```
.qoder/
├── hooks/
│   ├── lib/
│   │   ├── vocabulary.sh       ← 加载触发词清单
│   │   ├── state-detect.sh     ← 活跃 ADD 流程检测
│   │   └── context-inject.sh   ← 上下文注入模板
│   ├── session-start.sh        ← SessionStart
│   ├── prompt-submit.sh        ← UserPromptSubmit（入口路由）
│   ├── pre-tool-use.sh         ← PreToolUse
│   ├── post-tool-use.sh        ← PostToolUse
│   ├── post-tool-failure.sh    ← PostToolUseFailure
│   ├── stop-check.sh           ← Stop
│   └── notification.sh         ← Notification
├── settings.json               ← 11 事件配置
└── vocabulary/
    └── add-governance-vocabulary.md  ← 新增机器可读触发词清单
```

### 3.2 11 事件完整映射

#### 1. SessionStart → session-init 上下文恢复（修正 P0-3 + P2-2）

```
Event: SessionStart
matcher: *（不区分 source，startup/resume/clear/compact/new 统一处理）
Action:
  - 检查 plans/ 是否有 7 天内 handoff
  - 无 → 静默 exit 0
  - 有 → stdout 输出 JSON（利用 hookSpecificOutput.additionalContext）:
    {
      "continue": true,
      "hookSpecificOutput": {
        "hookEventName": "SessionStart",
        "additionalContext": "上次 ADD 流程未完成:\n"
          "Plan: {plan_keyword}\n"
          "轮次: {round} / {totalRounds}\n"
          "当前 Step: {currentStep} (add-route)\n"
          "恢复命令: query_audit_logs({ planKeyword: '{keyword}' })\n"
          "handoff: {handoff_path}"
      }
    }
Exit: 0（不阻塞，仅注入结构化上下文）
```

#### 2. UserPromptSubmit → 触发词智能路由

```
Event: UserPromptSubmit
matcher: *
Input: { prompt: "..." }
Action:
  1. 加载 vocabulary 触发词清单
  2. 匹配 P0 精准触发词 → stdout 注入对应操作指令
  3. 匹配开发关键词 + 无活跃 ADD → exit 2 "请先执行 add-paradigm SKILL"
  4. 匹配开发关键词 + 有活跃 ADD → stdout 注入上下文，exit 0
Exit: 0(放行+注入) / 2(阻塞)
```

#### 3. PreToolUse → Step 3 写操作前置守卫（修正 P2-1: 路径收窄）

```
Event: PreToolUse
matcher: Write|Edit
Input: { tool_name: "Write", tool_input: { file_path: "..." } }
Action:
  - 文件路径匹配以下任一项时检查 Plan:
    · src/agents/**           ← Agent 管线核心
    · src/lib/agent-audit-logger.ts  ← 审计基础设施
    · src/types/**             ← 类型定义
    · prisma/schema.prisma     ← 数据库 Schema
  - 其他 src/lib/ 和 src/app/ → 放行（工具函数、UI、路由等非结构化变更无需 Plan）
  - 有活跃 Plan → stdout 注入 "当前 Plan: {keyword}, 本次改动应属于 Task N" → exit 0
  - 无 Plan → exit 2 "⚠️ 修改核心代码前请先生成 ADD Plan。执行 add-paradigm SKILL → Step 0。"
```

#### 4. PostToolUse → ADD-7 审计提醒（修正 P0-2: 不能阻断，配合 Stop 双重保障）

```
Event: PostToolUse
matcher: Write|Edit
Input: { tool_name: "Write", tool_input: { file_path: "..." } }
Action:
  - 文件在 ADD-7 策略表中 → stdout 注入 additionalContext "请执行 record_dev_operation({ targetId: ... })"
  - 不在策略表 → 静默放行
  - ★ PostToolUse 在工具执行后触发，不能阻断。审计完整性由 Stop 事件兜底检查。
Exit: 0（不阻塞，仅注入上下文提醒）
```

#### 5. PostToolUseFailure → 失败路径追踪

```
Event: PostToolUseFailure
matcher: Write|Edit|Bash
Action:
  - stdout 注入 "工具失败: {tool_name}。检查是否需要回退到上一 ADD Step 重新执行。"
Exit: 0（不阻塞，仅提示）
```

#### 6. Stop → Step 8 验收闭环检查（修正 P0-1: 四象限 + few-shot）

**四象限定义**：Stop 在"Agent 准备停止"时触发，用两个维度判断该不该让它停——

| 维度 | 含义 | 检测方式 |
|------|------|---------|
| A: 有活跃 ADD 流程？ | 是否存在进行中的 ADD Plan（有 handoff 表示 PLAN 已生成、流程已启动） | `plans/` 下 7 天内 handoff mtime |
| B: 本次有开发动作？ | 本次 session 是否修改了核心代码（有 dev action 表示已经进入 Step 3 代码实现） | PreToolUse Write/Edit 时写入标记文件 |

四象限语义：

| A | B | 语义 | ADD 视角 |
|:-:|:-:|------|---------|
| ❌ | ❌ | 纯聊天 | 无 Plan 无代码——Agent 可以随时停 |
| ❌ | ✅ | 无 Plan 写了代码 | **严重违规**——跳过了 Step 0-2 直接写代码。exit 2 阻止停止，强制补 ADD 流程 |
| ✅ | ❌ | 有 Plan 但没写代码 | Step 0-2 阶段（文档先行 / 审计准备）。注入状态作为下次会话的上下文锚点 |
| ✅ | ✅ | 有 Plan 且写了代码 | Step 3-8 阶段。按 add-route Step 定位，判断是否验收闭环 |

```
Event: Stop
matcher: *
Input: { stop_hook_active, last_assistant_message }

检测:
  A = 有活跃 ADD handoff (mtime 7天内)?
  B = 本次 session 有 Write/Edit 过 src/ 下文件?

┌────────┬────────┬──────────────────────────────────────────────────┐
│ A      │ B      │ Stop 行为                                         │
├────────┼────────┼──────────────────────────────────────────────────┤
│ ❌     │ ❌     │ exit 0 — 纯聊天，正常停                           │
│ ❌     │ ✅     │ exit 2 "⚠️ 本次修改了代码但未走 ADD 流程。        │
│        │        │          请先执行 add-paradigm SKILL。"            │
│ ✅     │ ❌     │ exit 0 + stdout 注入当前 Plan/轮次状态             │
│ ✅     │ ✅     │ → 按 Step 定位分流（见下）                         │
└────────┴────────┴──────────────────────────────────────────────────┘

第四象限内部分流（从 add-route + handoff + tasks.md 三层定位当前 Step）:

  优先级: add-route > handoff > tasks.md
  add-route 是 ADD Step 进度表（Step 0-8 勾选状态），handoff 是轮次索引。

  Step 定位规则:
    ① 读 add-route → 统计 [x] 的 Step 数 → 当前 Step = 第一个 [ ] 的 Step
       例: Step 0[x] 1[x] 2[x] 3[ ] → 当前在 Step 3
    ② 读 handoff → 匹配模式:
       多轮 handoff: grep '<第[0-9]轮>' → 统计 [x] 轮次数
       单轮 handoff: 检查 §验证标准 是否全部 [x]
    ③ 读 tasks.md → 统计 [x] 数 M / 总数 N
    ④ 检查 devlog 是否已记录: handoff 文件中是否含验收结果（关键词: 验收/收敛/闭环/本轮改了什么）

  Step 0-2 (add-route Step 0/1/2 任一项 [ ]):
    → exit 0 + stdout "ADD Step {N}: 文档先行/审计准备阶段。无需验收闭环。"
    → Few-shot: 告诉 LLM 下一步操作（生成 add-route / 扩展 AgentAuditPhase）

  Step 3 进行中 (add-route Step 3 [ ], 但 tasks.md 0 < M < N):
    → exit 0 + stdout "ADD Step 3: 代码实现进行中 (tasks M/N)。完成后进入 Step 3.5 审查。"
    → Few-shot: 提醒 LLM 还要写 spec checklist、生成 review-implementation

  Step 3 完成, 验收未闭环 (add-route Step 3 [x], Step 3.5/4/5/8 任一项 [ ], 或 devlog 缺失):
    → exit 2 "⚠️ 代码已完成但验收未闭环:\n"
      "  add-route 未闭环 Step: (列出所有 [ ] 的 Step)\n"
      "  ① devlog: 检查 handoff 是否含验收记录（关键词: 验收/收敛/本轮改了什么）\n"
      "  ② handoff: 更新 §验证标准\n"
      "  ③ 架构回看: docs/ 下相关文档\n"
      "  以上全部 [x] 后 Agent 才能停止。"
    → Few-shot: 告诉 LLM 三步闭环的具体操作 + add-route 勾选

  全部闭环 (add-route Step 0-8 全部 [x], devlog 存在):
    → exit 0 — 真正收敛

  stop_hook_active=true 时:
    → 上一轮已通过 exit 2 阻止过停止 → 本次不再阻止，exit 0
    → 避免无限循环
```

**Stop hook 的 few-shot 上下文（注入到 stderr/stdout 给 LLM 看）**：

```text
# 输入: 刚完成 Step 3 代码，验收未闭环
[ADD Stop] 代码实现已全部完成 (tasks.md 15/15 [x])。验收未闭环:
  ① devlog: handoff 无验收记录
  ② handoff: §验证标准 含 [ ] 未勾选项
  ③ 架构回看: 未执行
请依次执行: Write devlog → Edit handoff 验证标准 → Read docs/ 架构文档确认一致性

# 输入: Step 3 进行中
[ADD Stop] 代码实现进行中 (8/15 tasks)。进度: 轮次 2/4 完成，轮次 3 待开始。
下次继续时执行 session-init 恢复上下文。

# 输入: 无 ADD 但有代码改动
[ADD Stop] ⚠️ 检测到代码修改但无活跃 ADD Plan。请先执行 add-paradigm SKILL。
```

#### 7. SubagentStart/Stop → Guardian 门禁

```
Event: SubagentStart / SubagentStop
matcher: add-flow-guardian|add-orchestrator
Action: 记录 Guardian 调度日志，不做额外干预
Exit: 0
```

#### 8. PreCompact → ADD 状态持久化

```
Event: PreCompact
matcher: *
Action:
  - 有活跃 ADD → stdout 注入 "压缩前 ADD 状态: {plan}, 当前 Step N, 已完成 Task M/Total"
Exit: 0
```

#### 9. Notification → Review 提醒

```
Event: Notification
matcher: result
Action:
  - Agent 完成任务 → 检查是否有活跃 ADD 流程
  - 有 Review 未读 → stdout 注入 "请检查 Review 文档: {path}"
Exit: 0
```

#### 10. PermissionRequest → 人工卡位确认

```
Event: PermissionRequest
matcher: *
Action:
  - ADD Step 0.6.5/3.5 的 Review 卡位 → 不做额外干预（Qoder 本身弹确认）
Exit: 0
```

### 3.3 共享库设计

**`hooks/lib/vocabulary.sh`**：
```bash
# 从 vocabulary 文件加载 P0 触发词清单
# 格式: P0|验收|三步闭环: ①devlog ②handoff ③架构回看
load_triggers() { grep '^P0|' "$VOCABULARY_FILE"; }
match_trigger() { local prompt="$1"; load_triggers | while IFS='|' read -r prio trigger action; do ...; done; }
```

**`hooks/lib/state-detect.sh`**：
```bash
# 检测活跃 ADD 流程
# 返回: "plan_keyword|round_n|handoff_path" 或 ""
detect_active_add() {
  local today_dir="$PLANS_DIR/$(date +%Y-%m)"
  find "$today_dir" -name "*handoff*.md" -mtime -7 -type f 2>/dev/null | head -1
}
```

---

## 四、实施步骤

> **Review P1-1 决策**：11 个独立脚本成本相近，全部一次交付。测试覆盖部分（高频事件全测，低频 mock 验证）。

```
Task 0: settings.json 配置 11 事件
  │
  ▼
Task 1: 共享库（vocabulary.sh + state-detect.sh + context-inject.sh）
  │
  ▼
Task 2: 全部事件脚本（10 个，可并行）
  ├── session-start.sh       ✅ 全测
  ├── prompt-submit.sh       ✅ 全测（★入口路由）
  ├── pre-tool-use.sh        ✅ 全测
  ├── post-tool-use.sh       ✅ 全测
  ├── stop-check.sh          ✅ 全测
  ├── post-tool-failure.sh   mock
  ├── subagent-guard.sh      mock
  ├── pre-compact.sh         mock
  ├── notification.sh        mock
  └── permission-gate.sh     mock
  │
  ▼
Task 3: vocabulary 添加机器可读触发词清单
  │
  ▼
Task 4: 集成测试（5 全测 + 5 mock）
```

### Task 0: settings.json 11 事件配置

- **文件**: `.qoder/settings.json`
- **内容**: 为全部 11 个事件配置对应的 hook 脚本路径
- **验收**: JSON 合法，CN/国际版均不报错

### Task 1: 共享库

- **文件**: `hooks/lib/vocabulary.sh`, `hooks/lib/state-detect.sh`, `hooks/lib/context-inject.sh`
- **内容**: 触发词加载 + 活跃流程检测 + 上下文注入模板
- **验收**: `source hooks/lib/vocabulary.sh && load_triggers | wc -l` ≥ 10

### Task 2: 全部事件脚本（10 个，可并行）

| 脚本 | 事件 | 核心逻辑 | 测试 |
|------|------|---------|:--:|
| `session-start.sh` | SessionStart | 检测活跃 Plan → stdout 注入恢复上下文 | ✅ 全测 |
| `prompt-submit.sh` | UserPromptSubmit | 加载 vocabulary → 三层路由（★入口） | ✅ 全测 |
| `pre-tool-use.sh` | PreToolUse | Write/Edit src/agents/ → 检查是否有 Plan | ✅ 全测 |
| `post-tool-use.sh` | PostToolUse | 写完成 → additionalContext 提醒 record_dev_operation | ✅ 全测 |
| `stop-check.sh` | Stop | 验收未闭环 → exit 2 阻止停止 | ✅ 全测 |
| `post-tool-failure.sh` | PostToolUseFailure | 失败 → 提示回退到上一 Step | mock |
| `subagent-guard.sh` | SubagentStart/Stop | Guardian 门禁日志 | mock |
| `pre-compact.sh` | PreCompact | ADD 状态快照 → stdout 注入 | mock |
| `notification.sh` | Notification | Review 未读提醒 | mock |
| `permission-gate.sh` | PermissionRequest | Review 卡位确认（不干预） | mock |

### Task 3: vocabulary 机器可读化

- **文件**: `.qoder/vocabulary/add-governance-vocabulary.md`
- **内容**: 新增附录 `## 附录: 触发词纯文本清单（hook 消费）`
- **格式**: `P0|验收|三步闭环: ①devlog ②handoff ③架构回看`

### Task 4: 集成测试

- 高频事件 (5): stdin 模拟 → 验证 exit code + stdout/stderr
- 低频事件 (5): shell 语法检查 + 函数签名验证
- CN 版和国际版分别验证

---

## 五、验收标准

- [ ] settings.json 含 11 个事件配置，JSON 合法
- [ ] 共享库 `vocabulary.sh` 可从 vocabulary 文件加载触发词
- [ ] `prompt-submit.sh`：P0 精准触发词→对应操作指令
- [ ] `pre-tool-use.sh`：无 Plan 写 src/agents/ → exit 2
- [ ] `stop-check.sh`：ADD 未闭环 → stdout 提示
- [ ] Qoder CN 和国际版两端均不阻塞非开发对话

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-06/30/farm-agent-add-hook-governance-add-route-v3.md`（待生成） |
| Handoff | `.qoder/plans/2026-06/30/farm-agent-add-hook-governance-handoff-v3.md`（待生成） |
| Review | `.qoder/reviews/farm-agent-add-hook-governance-review-v3.md`（待生成） |
| 词汇表 | `.qoder/vocabulary/add-governance-vocabulary.md`（修改：新增机器可读清单） |
| Hook 规范 | [Qoder CN Hook 文档](https://help.aliyun.com/en/lingma/qodercli-cn/user-guide/hook) |
| Qoder Hook 国际版 | [Qoder Hook 文档](https://docs.qoder.com/zh/cli/hooks) |
