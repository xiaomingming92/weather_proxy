# farm-agent-notify-control-center-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对的程度。具体接口定义、WHEN-THEN 场景在 Spec。

## PLAN 元信息

- **Plan 名称**: farm-agent-notify-control-center-v1
- **启动时间**: 2026-06-30T01:00:00Z
- **主导 AI**: Qoder
- **关联文档**:
  - Spec: `.qoder/specs/notify-control-center/spec.md`
  - Tasks: `.qoder/specs/notify-control-center/tasks.md`
  - Checklist: `.qoder/specs/notify-control-center/checklist.md`
  - Handoff: `.qoder/plans/2026-06/29/code-review-fixes-handoff-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState |
|-----|-----------|--------|------------|-----------|
| src/lib/notify/types.ts | COMPONENT | FILE_CREATED | 不存在 | NotifyAlert + NotifyChannel 接口 |
| src/lib/notify/channels/wecom.ts | COMPONENT | FILE_CREATED | 不存在 | 企微 NotifyChannel 实现 |
| src/lib/notify/channels/dingtalk.ts | COMPONENT | FILE_CREATED | 不存在 | 钉钉骨架 (enabled=false) |
| src/lib/notify/channels/feishu.ts | COMPONENT | FILE_CREATED | 不存在 | 飞书骨架 (enabled=false) |
| src/lib/notify/control.ts | COMPONENT | FILE_CREATED | 不存在 | sendAlert() fan-out 控制中心 |
| src/lib/notify/index.ts | COMPONENT | FILE_CREATED | 不存在 | 统一 re-export |
| src/lib/wecom-notify.ts | COMPONENT | FILE_MODIFIED | 独立 sendWecomAlert 实现 | 兼容层 re-export |
| src/lib/agent-audit-logger.ts | COMPONENT | FILE_MODIFIED | import sendWecomAlert | import sendAlert |
| scripts/test-wecom-notify.ts | TEST | FILE_MODIFIED | sendWecomAlert 单 channel | sendAlert fan-out |
| .env.example | CONFIG | CONFIG_CHANGED | 仅 WECOM_WEBHOOK_KEY | + DINGTALK/FEISHU_URL |

---

## 一、背景与目标

### 1.1 问题现状

code-review-combined-report.md **#12** 指出：审计日志 DB 写入失败后无外部告警通道。上一轮修复已将告警硬编码到 `sendWecomAlert()`——企微是唯一通道。新增钉钉/飞书必须改动 `agent-audit-logger.ts` 调用方代码，违反开闭原则。

### 1.2 目标

建立**通知控制中心**（fan-out 模式），调用方只发送 `sendAlert({title, content, level})`，控制中心自动 fan-out 到所有已启用的通知渠道。新增渠道只需实现接口 + 注册，调用方零改动。

---

## 二、方案选型

| 方案 | 可扩展性 | 调用方侵入 | 实现成本 | 结论 |
|------|---------|-----------|---------|------|
| A: 在 agent-audit-logger.ts 写 if-else 链 | ❌ 每次加渠道改调用方 | 高 | 低 | 不可取 |
| B: NotifyChannel 接口 + 控制中心 fan-out | ✅ 新增渠道零侵入 | 零 | 中 | ✅ 选用 |

**选型理由**：B 方案以 ~200 行代码代价，消除调用方对具体渠道的硬编码耦合。`Promise.allSettled` 保证单 channel 失败不影响其他 channel。

---

## 三、架构设计

```
                    ┌─────────────────────┐
                    │  agent-audit-logger │  ← 调用方
                    │  sendAlert({...})    │
                    └────────┬────────────┘
                             │
                             ▼
                    ┌─────────────────────┐
                    │  control.ts          │  ← 控制中心
                    │  notifyChannels[]    │
                    │  Promise.allSettled  │
                    └──┬───────┬──────┬───┘
                       │       │      │
              ┌────────▼┐ ┌────▼──┐ ┌▼────────┐
              │ wecom   │ │ ding  │ │ feishu  │  ← channels
              │ (完整)  │ │(骨架) │ │ (骨架)  │
              └─────────┘ └───────┘ └─────────┘
```

**目录结构**：
```
src/lib/notify/
├── types.ts              ← NotifyAlert / NotifyChannel / ChannelSendResult
├── control.ts            ← sendAlert() + 注册表
├── channels/
│   ├── wecom.ts          ← 企微完整实现（从 wecom-notify.ts 迁移）
│   ├── dingtalk.ts       ← 钉钉骨架
│   └── feishu.ts         ← 飞书骨架
└── index.ts              ← 统一出口
```

**向后兼容**：`src/lib/wecom-notify.ts` 保留为兼容层，re-export 新接口。已有 `import { sendWecomAlert } from "@/lib/wecom-notify"` 的代码无需立即迁移。

---

## 四、实施步骤 + 依赖图

```
Phase 1: types.ts ──┐
                    ├──► Phase 2: wecom.ts + dingtalk.ts + feishu.ts
                    │              │
                    │              ▼
                    │     Phase 3: control.ts + index.ts
                    │              │
                    └──────────────┤
                                   ▼
                          Phase 4: 迁移调用点 (agent-audit-logger.ts + wecom-notify.ts 兼容层)
                                   │
                                   ▼
                          Phase 5: .env 更新 + tsc --noEmit
```

### Phase 1: 类型定义
- 创建 `src/lib/notify/types.ts`，定义 `NotifyAlert`、`NotifyChannel`、`ChannelSendResult`

### Phase 2: Channel 实现
- 创建 `src/lib/notify/channels/wecom.ts`，从 `wecom-notify.ts` 迁移 webhook 逻辑
- 创建 `src/lib/notify/channels/dingtalk.ts`，骨架（`enabled: false`）
- 创建 `src/lib/notify/channels/feishu.ts`，骨架（`enabled: false`）

### Phase 3: 控制中心
- 创建 `src/lib/notify/control.ts`，`sendAlert()` fan-out + 三 channel 注册
- 创建 `src/lib/notify/index.ts`，统一 re-export

### Phase 4: 迁移调用点
- `wecom-notify.ts` 改为兼容层：`export { sendAlert, getWecomSendFailCount } from "@/lib/notify"`
- `agent-audit-logger.ts`：`sendWecomAlert()` → `sendAlert()`
- `scripts/test-wecom-notify.ts`：适配新接口

### Phase 5: 环境变量 + 验证
- `.env.example` / `.env.development`：新增 `DINGTALK_WEBHOOK_URL`、`FEISHU_WEBHOOK_URL`
- `npx tsc --noEmit` 零新增错误

---

## 五、验收标准

- [ ] `npx tsc --noEmit` 零新增错误
- [ ] `agent-audit-logger.ts` 调用 `sendAlert()` 而非 `sendWecomAlert()`
- [ ] 企微 webhook 调用逻辑行为不变（迁移前后等价）
- [ ] 新增钉钉/飞书无需修改 `agent-audit-logger.ts`
- [ ] `wecom-notify.ts` 兼容层 re-export 可用，已有代码无需改动

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| Spec | `.qoder/specs/notify-control-center/spec.md` |
| Tasks | `.qoder/specs/notify-control-center/tasks.md` |
| Checklist | `.qoder/specs/notify-control-center/checklist.md` |
| Handoff | `.qoder/plans/2026-06/29/code-review-fixes-handoff-v1.md` |
| Devlog | `.qoder/plans/2026-06/29/devlog-code-review-fixes-v1.md` |
