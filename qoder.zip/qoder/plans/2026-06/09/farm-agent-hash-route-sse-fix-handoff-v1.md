# farm-agent — hash route SSE 流式修复 交接手册

> **适用场景**：单轮变更，修复 `[hash]/route.ts` 的 chat 响应从 JSON 改为 SSE 流式。
> **关联文档**：
> - Plan: [farm-agent-hash-route-sse-fix-plan-v1.md](./farm-agent-hash-route-sse-fix-plan-v1.md)
> - Specs: [.qoder/specs/hash-route-sse-fix/](../specs/hash-route-sse-fix/spec.md)
> - 上游: [review2 §5.1](../reviews/farm-agent-agrisynapse-integration-review2.md#51-发现-1-chat-响应格式契约断裂最严重)
> - 下游: [review-runtime.md](../reviews/farm-agent-review-runtime.md)

---

## 1. 交接前状态

- `handleChatPOST()` 使用 `runAgent()` → 等待完整 Agent 执行 → 返回 `NextResponse.json()`
- agrisynapse 客户端 `parseSSEStream` 期望 `data:` 行，永远收不到数据 → 前端卡死
- Agent 节点通过 `emitStreamEvent` 发送的事件因无人 `registerStreamBus` → 2393 条 `STREAM_BUS_EMIT_ERROR`
- 每次 ERROR 还写入 Prisma AuditLog，造成审计日志污染
- Agent 管线完整执行（~54s），生成 1667 字符，但因协议不匹配全部丢弃

---

## 2. 交接后状态（目标）

- `handleChatPOST()` 使用 `streamAgent()` → `ReadableStream` + `TextEncoder` → `Content-Type: text/event-stream`
- agrisynapse 神经元点击"农情日报" → 流式逐字显示回复
- `stream-bus.log` 有 `STREAM_BUS_REGISTER` 记录，无 `STREAM_BUS_EMIT_ERROR`
- AuditLog 不再被无效错误写满

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/app/api/agent/[hash]/route.ts` | 修改 | `handleChatPOST`：`runAgent()`→`streamAgent()`，JSON→SSE |
| 2 | `.qoder/plans/farm-agent-hash-route-sse-fix-plan-v1.md` | 修改 | 补充 PLAN 元信息 + ADD-7 审计策略表 + 关联文档链接 |
| 3 | `.qoder/specs/hash-route-sse-fix/spec.md` | 新建 | Why/What/Boundaries/Requirements |
| 4 | `.qoder/specs/hash-route-sse-fix/tasks.md` | 新建 | 3 Phase 7 Tasks |
| 5 | `.qoder/specs/hash-route-sse-fix/checklist.md` | 新建 | [T] 编译验证 + [R] 运行时验证 |
| 6 | `.qoder/plans/farm-agent-hash-route-sse-fix-handoff-v1.md` | 新建 | 本文档 |

---

## 4. 回滚方案

### 代码回滚

```bash
# handleChatPOST 改动回滚：恢复 runAgent() + NextResponse.json()
git checkout src/app/api/agent/[hash]/route.ts
```

### 日志回滚

无需数据回滚，改动不涉及数据库迁移。

---

## 5. 执行前置检查

- [ ] dev server 运行中（`npm run dev`）
- [ ] agrisynapse dev server 运行中
- [ ] `chat/stream/route.ts` SSE 模式可正常参考
- [ ] `npx tsc --noEmit` 当前无错误

---

## 6. 执行步骤摘要

```text
Phase 1: 函数替换
  ├── Task 1.1: 引入 SSE 依赖 (registerStreamBus/streamAgent/CognitiveEventBus)
  │       │
  │       ▼
  └── Task 1.2: runAgent() → streamAgent()
                │
                ▼
Phase 2: SSE 流式输出
  ├── Task 2.1: ReadableStream + registerStreamBus 桥接
  │       │
  │       ▼
  └── Task 2.2: 返回 Content-Type: text/event-stream
                │
                ▼
Phase 3: 验证
  ├── Task 3.1: npx tsc --noEmit
  ├── Task 3.2: curl 验证
  └── Task 3.3: 日志验证
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| `streamAgent()` 参数签名不匹配 | 编译失败 | 参照 `chat/stream/route.ts` 逐参数对齐 |
| SSE 编码错误导致 agrisynapse 仍无法解析 | 前端仍卡死 | curl 验证 `data:` 格式后再联调 |
| `CognitiveEventBus` 未正确初始化 | 节点事件丢失 | 确认 `eventBus` 实例与 `stream/route.ts` 一致 |
| `handleHandshakePOST` 被误改 | 握手功能损坏 | Forbidden 边界明确写在 tasks.md 中 |

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用，AI 助手在自己的对话中**直接复制粘贴这些参数调用工具即可**，不需要写 SQL。共 6 条审计记录可恢复完整开发上下文。

### 总体一键恢复

```text
query_audit_logs({ keyword: "SSE" })
```
→ 预期返回 ≥6 条记录（PLAN + SPEC + TASKS + CHECKLIST + HANDOFF + SKILL 改动）

### 逐任务/逐文件审计查询

```text
query_audit_logs({ targetId: ".qoder/plans/farm-agent-hash-route-sse-fix-plan-v1.md" })
→ 预期返回 MODIFY: 补充 PLAN 元信息 + ADD-7 审计策略表

query_audit_logs({ targetId: ".qoder/specs/hash-route-sse-fix/spec.md" })
→ 预期返回 CREATE: SSE 流式修复 Spec

query_audit_logs({ targetId: ".qoder/specs/hash-route-sse-fix/tasks.md" })
→ 预期返回 CREATE: 3 Phase 7 Tasks

query_audit_logs({ targetId: ".qoder/specs/hash-route-sse-fix/checklist.md" })
→ 预期返回 CREATE: [T]/[R] 双模式检查清单

query_audit_logs({ targetId: ".qoder/plans/farm-agent-hash-route-sse-fix-handoff-v1.md" })
→ 预期返回 CREATE: 交接手册

query_audit_logs({ keyword: "SKILL" })
→ 预期返回 ≥2 条: add-paradigm SKILL Step 8 handoff 生成步骤 + Step 0 模板重读约束
```

### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE action IN ('MODIFY', 'CREATE')
  AND (
    "targetId" LIKE '%.qoder/plans/%hash-route-sse-fix%'
    OR "targetId" LIKE '%.qoder/specs/hash-route-sse-fix%'
    OR "targetId" = '.qoder/skills/add-paradigm/SKILL.md'
  )
ORDER BY "createdAt" DESC;
```

### 恢复判定标准

- action 命中数 ≥ 8（6 文档 + 2 SKILL）
- grep 验证命令：

```bash
grep -R "hash-route-sse-fix" .qoder/plans/ .qoder/specs/
```

---

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过
- [x] 所有文件改动已记录 ADD-7 审计（`query_audit_logs` 可回查）
- [x] `curl` 返回 `Content-Type: text/event-stream` + 逐条 `data:` 行
- [R] agrisynapse 神经元点击"农情日报" → 流式显示回复（待两端联调）

### 修复验证截图

```text
# curl 结果（2026-06-09T06:54:32 UTC）
data: {"type":"streaming_node","nodeName":"intention","status":"started"}
data: {"type":"structured_update","data":{"intent":{"type":"chat",...}}}
data: {"type":"streaming_node","nodeName":"response","status":"started"}
data: {"type":"token","content":"您好"}

# stream-bus.log
[STREAM_BUS_REGISTER] traceId=935c9de5-c28f-4d06-aa59-f13c3213e418
[STREAM_BUS_UNREGISTER] traceId=935c9de5-c28f-4d06-aa59-f13c3213e418
```

---

### 脱敏要求

本文档不含硬编码凭据值。所有环境变量通过 `${ENV_VAR}` 引用，值见 `.env.development` / `.env.production`。
