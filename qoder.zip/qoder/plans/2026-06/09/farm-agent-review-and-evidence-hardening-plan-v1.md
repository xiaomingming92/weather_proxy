# farm-agent-review-and-evidence-hardening-plan-v1

## PLAN 元信息

- **Plan 名称**: review-and-evidence-hardening-v1
- **启动时间**: 2026-06-08
- **主导 AI**: Qoder
- **修订记录**:
  - 2026-06-25: 回流 audit-log-bypass-governance-plan 发现——append-runtime-finding.ts 需改用 writeAuditLog()（第 9 个绕过点）；新增 instrumentation.ts 全局边界捕获替代手动包裹；source 类型扩展
  - 2026-06-25: 实施 Step 3/4/5/6 — proxy.ts + route.ts 移除手动包裹，instrumentation.ts 创建，append-runtime-finding.ts L2 收口
- **触发源**: [farm-agent-agrisynapse-integration-review2.md §5 运行时验证增量发现](../reviews/farm-agent-agrisynapse-integration-review2.md) — 5 个运行时发现中 3 个本应在实现审查阶段拦截
- **上游 Plan**: [farm-agent-agrisynapse-integration-plan-v1](./farm-agent-agrisynapse-integration-plan-v1.md) — 上一轮对接流程（已收敛），本轮是其 review2 催生的 follow-up
- **关联文档**:
  - 方案审查: `.qoder/reviews/farm-agent-review-and-evidence-hardening-review-v1.md`
  - 运行时纠偏: `.qoder/reviews/farm-agent-review-runtime.md`（本次创建）
  - 交接: `.qoder/plans/farm-agent-review-and-evidence-hardening-handoff-v1.md`
  - **联动 Plan**: `.qoder/plans/2026-06/25/audit-log-bypass-governance-plan-v1.md`（append-runtime-finding.ts L2 绕过发现来源；writeAuditLog 收口 Task 3）

| 文件 | targetType | action | 状态 |
|-----|-----------|--------|------|
| .qoder/templates/checklist-template.md | RULE | RULE_MODIFIED | 待实施 |
| .qoder/templates/review-implementation-template.md | RULE | RULE_MODIFIED | 待实施 |
| src/lib/append-runtime-finding.ts | COMPONENT | COMPONENT_CREATED | 待实施 |
| scripts/check-runtime-review.ts | SCRIPT | SCRIPT_CREATED | 待实施 |
| package.json | CONFIG | CONFIG_MODIFIED | 待实施 |
| `src/instrumentation.ts` | INFRA | COMPONENT_CREATED | ✅ 已实施 |
| `src/lib/append-runtime-finding.ts` | COMPONENT | COMPONENT_REFACTOR | prisma.auditLog.create → writeAuditLog()；source 类型扩展 | ✅ 已实施 |
| `src/proxy.ts` | COMPONENT | COMPONENT_MODIFIED | 移除手动 try/catch | ✅ 已实施 |
| `src/app/api/agent/[hash]/route.ts` | API_ROUTE | API_ROUTE_MODIFIED | 移除 GET/POST 手动 try/catch | ✅ 已实施 |

> **2026-06-25 修订**：`instrumentation.ts` 替代手动 proxy/route 包裹，全局拦截未处理异常。`append-runtime-finding.ts` 收口到 `writeAuditLog()`。
> **2026-06-25 实施**：Step 3/4/5/6 已完成。proxy.ts + route.ts 手动 try/catch 已移除，统一由 instrumentation.ts 全局 unhandledRejection 捕获。

### 文档链

```
farm-agent-agrisynapse-integration-plan-v1.md（对接功能，已收敛）
    │ 修订记录 [2026-06-09]: review2 催生 follow-up plan
    │
    └── farm-agent-agrisynapse-integration-review2.md
            │ §5: 5 个运行时发现（Chat SSE断裂、middleware废弃、
            │     proxy不热更新、AuditLog外键、env混乱）
            │ §8: 后续跟进 → 指向本 plan
            │
            └── farm-agent-review-and-evidence-hardening-plan-v1.md（本轮）
                    │ 触发源: review2 §5
                    │ 上游: integration-plan-v1
                    │
                    ├── specs/review-and-evidence-hardening/
                    │   ├── spec.md     (WHEN-THEN 5 条需求)
                    │   ├── tasks.md    (3 Phase / 8 Task)
                    │   └── checklist.md ([T]/[R] 分拆)
                    │
                    ├── farm-agent-review-and-evidence-hardening-review-v1.md
                    │   （方案审查，待实施后填写）
                    │
                    ├── farm-agent-review-runtime.md
                    │   （运行时纠偏，由 appendRuntimeFinding 自动追加）
                    │
                    └── farm-agent-review-and-evidence-hardening-handoff-v1.md
                            §7: 上下游关联 + 执行步骤摘要
```

---

## 一、背景

review2 的 5 个运行时发现揭示了两根短板：

| 发现 | 本应在哪拦住 | 实际在哪暴露 |
|------|------------|------------|
| Chat SSE vs JSON 格式断裂 | checklist [T] 多 API 场景匹配 | curl dashboard 永远 pending |
| userId: "system" 外键违反 | checklist [T] 外键完整性 | AuditLog 全空，无声断裂 |
| env 文件加载链混乱 | checklist [T] 环境变量审计 | curl 打到错误 IP，10s 超时 |
| Next.js 16 middleware 废弃 | checklist [T] 框架版本 | dev server 直接报错 |
| proxy 不热更新 | 只能运行时发现 | 修改无效，误判为代码问题 |

前三条实现审查就能拦，但 checklist 和 review-implementation 模板没强制这些验证步骤。拦不住的（proxy 热更新），L2 AuditLog 和业务 metadata 也回答不了"什么格式不对"——你得手动跨仓库 grep、git blame、查版本号。

**结论**：实现审查能拦的靠 ADD-10 加强，拦不住的靠 ADD-11 边界证据捕获快速定位。

---

## 二、方案

### 2.1 柱子一：ADD-10 实现审查加强

#### checklist-template.md：[T] 项补三组验证方法

| 新增 [T] 项 | 验证方法 |
|------------|---------|
| 多 API 场景匹配 | 模块导出多个功能相似函数（`runAgent`/`streamAgent`）时，逐一验证调用方选的是场景匹配的 |
| 外键完整性 | `grep "create("` 搜出所有 Prisma 写入，验证每个外键字段在目标表有对应记录 |
| 环境变量加载链 | 列出 dev 命令 → `.env.*` 映射 → 每个变量的实际值 |

#### review-implementation-template.md：加逐项对照步骤

在 §3（数据模型）和 §5（环境变量）之间插入：
- **§x 多 API 场景匹配**：列出模块中导出的所有同名前缀函数，逐一标注调用方选的是哪个、为什么
- **§y 外键完整性**：列出所有 `create()` 调用的外键字段，验证目标表记录存在

### 2.2 柱子二：ADD-11 边界证据站

**核心约束**：`appendRuntimeFinding` 只驻扎在系统最外层边界，不渗入业务层。

```
┌─ instrumentation.ts ───────────────────────────────────────────┐
│ process.on('unhandledRejection')                               │
│   ├─ 调用栈含 /api/h5/*     → source: "h5-route"               │
│   ├─ 调用栈含 /api/agent/*  → source: "agent-route"            │
│   ├─ 调用栈含 /api/knowledge/* → source: "knowledge-route"     │
│   └─ 提取 file:line → trace                                   │
│                                                                │
│   → appendRuntimeFinding(err, { source, trace })  fire-and-forget│
└────────────────────────────────────────────────────────────────┘

proxy.ts / route.ts 不再需要手动 try/catch 包裹。

内部 catch 块不动：
  agentAudit(...)     L1 console+file
  writeAuditLog(...)  L2 AuditLog 表
  saveAuditData(...)  业务 metadata
  return NextResponse HTTP 响应
```

> **为什么是边界站——完整背景**
>
> ## 黑客帝国世界观
>
> 在《黑客帝国》三部曲中，存在三层世界：
>
> - **Matrix（矩阵）**：一个由机器创造的虚拟现实，99% 的人类生活在其中，对真实世界一无所知。Matrix 有自己的规则——物理定律、社会结构、因果逻辑——就像 agrisynapse 有自己的前端框架、状态管理、API 调用链。
>
> - **Machine City（机器城/01）**：机器文明的物理世界，是 Matrix 的源头和基础设施。机器有自己的语言、协议、能量管道——就像 farm-agent 有自己的 Next.js、Prisma、agent 管线。
>
> - **The Real World（锡安/Zion）**：觉醒人类的避难所，既不属于 Matrix 也不属于 Machine City。他们需要同时理解两个世界的规则才能生存——这就是跨系统 Debug 的人。
>
> 那么问题来了：**Matrix 和 Machine City 之间怎么通信？**
>
> ## Mobil Ave：两个世界之间唯一的过渡站
>
> Matrix 和 Machine City 之间不是直连的。它们中间隔着一层过渡区——**Mobil Ave**（法语 "Mobil" = 移动/过渡）。
>
> 这不是一个你可以随便进出的地方。它是一个火车站台，位于两个世界之间的裂缝里。火车从 Matrix 来，开往 Machine City；或者反过来。但**火车不等人，也不解释**——它来了就是来了，没来就是没来。如果你想搞清楚为什么没来，你必须站在站台上看。
>
> ## 站台上的法国人（The Trainman）
>
> 站台上有一个法国人——在电影里他是 Merovingian 的手下，控制着通往 Mobil Ave 的通道。但在我们的比喻里，他不是控制者，他是**见证者**。
>
> 他不属于 Matrix（他不写 Vue 组件），也不属于 Machine City（他不调 Prisma）。他哪一方都不是。他只做一件事：**站在边界上，看火车来来去去**。
>
> - 哪班火车该到但没到——他记下来。
> - 哪班火车来了但车厢是空的——他记下来。
> - 哪班火车到了但装着错误的货物——他记下来。
>
> 他不修火车。他不问火车为什么没来。他不替代任何一方的调度系统。他就是站台上的那个法国人，手里的本子上写着证据。
>
> ## 映射到 farm-agent ↔ agrisynapse
>
> ```
> agrisynapse (Matrix)                     farm-agent (Machine City)
> ┌─────────────────────┐                  ┌──────────────────────┐
> │ Vue 前端             │                  │ Next.js 后端          │
> │ agentChat store      │   HTTP/SSE      │ proxy.ts / route.ts  │
> │ parseSSEStream()     │ ←── 边界 ──→    │ handleChatPOST()     │
> │ 期望: data: {...}\n   │                  │ 实际: JSON Response   │  ← 合约断裂！
> └─────────────────────┘                  └──────────────────────┘
>                     │          │
>                     ▼          ▼
>               Mobil Ave（法国人的站台）
>               ┌─────────────────────────┐
>               │ appendRuntimeFinding()   │
>               │                          │
>               │ 法国人记下：              │
>               │ "火车 SSE 没来。          │
>               │  期望: text/event-stream  │
>               │  实际: application/json   │
>               │  commit: 17e1d0f          │
>               │  文件: route.ts L151"     │
>               └─────────────────────────┘
> ```
>
> L1/L2/业务 metadata 是 Matrix 和 Machine City **内部的**调度系统和车间日志——它们管自己地盘的事。法国人不管那些。他只站在边界上，看跨系统的火车。
>
> **这就是 ADD-11 的核心约束：`appendRuntimeFinding` 就是那个法国人。他不修火车，不进门，不替代任何一方的日志系统。他只在边界站台上，记下逃逸的证据。**

---

| 层 | 什么人 | 查什么 |
|----|-------|--------|
| L1 | 开发者 | 节点耗时、阶段标记 |
| L2 | AI/运维 | 操作事实（NODE_START, CHAT_ERROR） |
| 业务 metadata | 前端 UI | 业务指标（消息数、耗时） |
| **appendRuntimeFinding（新）** | **跨会话 Debug** | **合约断裂证据（期望什么、实际什么、定位线索）** |

四层各司其职，不交缠。

#### `src/lib/append-runtime-finding.ts`

新增。只做两件事：

1. 写入 AuditLog：`action: "RUNTIME_ERROR"`, `targetType: "BOUNDARY"`
2. 追加到 `.qoder/reviews/farm-agent-review-runtime.md`（不存在则从模板创建）

写入内容不是只存 error message，而是存诊断上下文：

```typescript
{
  source: "proxy" | "route" | "h5-route" | "agent-route" | "knowledge-route" | "api-route",
  error: string,
  contract?: { expected: string, actual: string },  // 合约断裂点
  trace?: { commit?: string, file?: string },         // 定位线索
}
```

所有写操作 fire-and-forget，自身异常不传播。

#### `scripts/check-runtime-review.ts`

predev 脚本。扫描 review-runtime.md，统计未关闭发现。有则 console.warn，不阻断启动。

#### `package.json`

```json
"predev": "tsx scripts/check-runtime-review.ts",
"dev": "cross-env NODE_ENV=development npm run predev && npm run db:ensure && next dev --webpack -p 3000"
```

### 2.3 不碰的

- `src/lib/agent-audit-logger.ts`：L1
- `src/lib/layer2-callback.ts`：L2
- `src/lib/agent-gateway-audit.ts`：网关审计
- `src/lib/farm-server-client.ts`：客户端审计
- 所有业务 catch 块内部：L1/L2/业务 metadata 三层不动

> **2026-06-25 例外**：`append-runtime-finding.ts` 需将 `prisma.auditLog.create` 改为 `writeAuditLog()`（audit-log-bypass-governance-plan Task 3），但功能语义不变。

---

## 三、实施步骤

| # | 步骤 | 产物 |
|---|------|------|
| 1 | 修改 `checklist-template.md`，补 3 组 [T] 验证方法 | 模板更新 |
| 2 | 修改 `review-implementation-template.md`，加多 API 场景匹配 + 外键完整性两个对照节 | 模板更新 |
| 3 | 创建 `src/lib/append-runtime-finding.ts` | 边界证据站 |
| 4 | 创建 `scripts/check-runtime-review.ts` | predev 扫描 |
| 5 | 修改 `package.json`，加 predev hook | 启动即检查 |
| 3 | 修改 `src/proxy.ts`：**移除**手动 try/catch 包裹（改为 instrumentation 全局捕获） | ✅ 已实施 |
| 4 | 修改 `src/app/api/agent/[hash]/route.ts`：**移除**手动 try/catch 包裹 | ✅ 已实施 |
| 5 | 创建 `src/instrumentation.ts` | ✅ 已实施 |
| 6 | 修改 `src/lib/append-runtime-finding.ts`：prisma.auditLog.create → writeAuditLog() | ✅ 已实施 |
| 7 | 验证：npx tsc + E2E curl 触发异常 → 确认 review-runtime.md 生成 | 验收 |

---

## 四、验收标准

- [ ] checklist [T] 项含多 API 场景匹配、外键完整性、env 加载链三组验证方法
- [ ] review-implementation 模板含多 API 场景匹配 + 外键完整性两个对照节
- [ ] `appendRuntimeFinding()` 写入 AuditLog (action: RUNTIME_ERROR) + review-runtime.md
- [ ] `appendRuntimeFinding()` 自身异常不传播
- [ ] `npm run dev` 启动时扫描 review-runtime.md，有未关闭发现时 console.warn（不阻断）
- [ ] L1/L2/业务 metadata 代码无改动
- [ ] `npx tsc --noEmit` 通过
