# Plan: hash route SSE 流式修复

> **来源**: [review2 §5.1](../reviews/farm-agent-agrisynapse-integration-review2.md#51-发现-1-chat-响应格式契约断裂最严重)
> **修订记录**
> - 2026-06-09: 初版，review2 运行时验证触发

## PLAN 元信息

- **启动时间**: 2026-06-09T06:30:00Z
- **关联文档**:
  - Specs: `.qoder/specs/hash-route-sse-fix/` (spec.md / tasks.md / checklist.md)
  - Handoff: `.qoder/plans/farm-agent-hash-route-sse-fix-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-agrisynapse-integration-review2.md` (上游触发)
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState |
|------|-----------|--------|------------|------------|
| `src/app/api/agent/[hash]/route.ts` | API_ROUTE | MODIFY | `handleChatPOST` 用 `runAgent()` 返回 JSON | `handleChatPOST` 用 `streamAgent()` 返回 SSE |

---

## 1. 问题概述

`[hash]/route.ts` 的 `handleChatPOST()` 使用了 `runAgent()`（非流式），导致：

1. **agrisynapse 前端无响应**：`parseSSEStream` 期望 `data:` 行，但收到 `NextResponse.json()` → 永远不 yield 事件 → GUI 卡死
2. **Stream-bus 洪水**：agent 节点调用 `emitStreamEvent()`，但无人 `registerStreamBus()` → 2393 条 `STREAM_BUS_EMIT_ERROR` → 每条还写 Prisma AuditLog
3. **数据浪费**：Agent 管线完整执行（~54s），生成了 1667 字符，但因为协议不匹配全部丢弃

## 2. 根因

```
commit 17e1d0f 从 /api/agent/chat/stream/route.ts 复制代码时，
面对 runAgent() vs streamAgent() 两个导出函数，随手选了名字更短的 runAgent()。
而 chat 场景必须用 streamAgent() 做 SSE 流式输出。
```

## 3. 修复方案

### 3.1 核心改动：`handleChatPOST` 从 JSON 模式改为 SSE 流式模式

参照 `/api/agent/chat/stream/route.ts` 的成熟模式：

| 步骤 | 当前（错误） | 目标 |
|------|------------|------|
| Agent 调用 | `runAgent()` → 等待完整结果 → JSON | `streamAgent()` → 逐 chunk 产出 |
| 事件总线 | ❌ 无 | `CognitiveEventBus` 收集节点事件 |
| Stream-bus | ❌ 未注册 | `registerStreamBus(traceId, cb)` → SSE `data:` 行 |
| 响应格式 | `NextResponse.json()` | `new Response(stream, { Content-Type: text/event-stream })` |
| Token 输出 | ❌ 一次性返回 | `emitStreamEvent({ type: "token", content })` → 逐字 SSE |

### 3.2 需引入的依赖

从 `chat/stream/route.ts` 对齐引入：
- `registerStreamBus` / `unregisterStreamBus` — 桥接 agent 节点事件 → SSE
- `CognitiveEventBus` — 节点间事件收集
- `ReadableStream` + `TextEncoder` — SSE 编码输出

### 3.3 保留不变的逻辑

以下逻辑已在 `handleChatPOST` 中正确实现，不动：
- 认证网关裁决 (`resolveAuthGateway`)
- 线程创建/恢复
- 用户消息持久化
- 链路追踪 (`startChainTrace` / `endChainTrace`)
- Farm-Server token provider
- AI 回复持久化
- 审计数据保存

## 4. 受影响文件

| 文件 | 改动类型 | 说明 |
|------|---------|------|
| `src/app/api/agent/[hash]/route.ts` | 重构 | `handleChatPOST` 从 JSON 改为 SSE 流式 |
| `.qoder/reviews/farm-agent-agrisynapse-integration-review2.md` | 文档链接 | §8 追加新 plan 链接 |
| `.qoder/reviews/farm-agent-review-runtime.md` | 更新 | 记录修复后的运行时验证结果 |

## 5. 验证方法

- [ ] `curl -X POST /api/agent/{hash} -d '{"type":"chat","messages":[...]}'` → 返回 `Content-Type: text/event-stream`，逐条 `data:` 行输出
- [ ] agrisynapse 神经元点击"农情日报" → 流式显示回复，不再卡死
- [ ] `stream-bus.log` 不再出现 `STREAM_BUS_EMIT_ERROR: 未注册`
- [ ] AuditLog 不再被无效日志写满

## 6. 关联文档

| 文档 | 路径 |
|------|------|
| Spec | `.qoder/specs/hash-route-sse-fix/spec.md` |
| Tasks | `.qoder/specs/hash-route-sse-fix/tasks.md` |
| Checklist | `.qoder/specs/hash-route-sse-fix/checklist.md` |
| Handoff | `.qoder/plans/farm-agent-hash-route-sse-fix-handoff-v1.md` |
| Review (上游) | `.qoder/reviews/farm-agent-agrisynapse-integration-review2.md` |

---

## 7. 与已有文档的关系

```
review2 §5.1 (发现契约断裂)
    │
    └── 触发本 plan ──→ 修复 handleChatPOST SSE 输出
                            │
                            └── 修复后运行时证据 → review-runtime.md
```

→ 本 plan 是 review2 的直接跟进项，修复 review2 发现的第 1 号问题。
