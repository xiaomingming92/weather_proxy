# farm-agent — 审查流程加固 + 边界证据站 交接手册

> **适用场景**：单轮变更。改进审查模板 + 新增边界证据站 + instrumentation 全局错误捕获。
> **最新修订**: 2026-06-25 — proxy/route 手动包裹改为 instrumentation.ts 全局 unhandledRejection；append-runtime-finding.ts L2 收口 writeAuditLog

---

## 1. 交接前状态

- `checklist-template.md`：跨项目联调检查含 [T]/[R] 分拆，但缺少多 API 场景匹配、外键完整性、env 加载链三组验证方法
- `review-implementation-template.md`：含 7 个节，但缺"多 API 场景匹配"和"外键完整性"对照
- proxy/route 最外层：无边界异常证据捕获，异常逃逸后只有 HTTP 状态码，诊断上下文丢失
- dev 启动：无 predev 检查，运行时发现的异常不会在新会话启动时被感知

## 2. 交接后状态（目标）

- `checklist-template.md`：[T] 项含 3 组新验证方法
- `review-implementation-template.md`：含 9 个节（+多 API 场景匹配 + 外键完整性）
- `src/lib/append-runtime-finding.ts`：~~边界异常证据写入（AuditLog + review-runtime.md），fire-and-forget~~ → 边界异常证据写入（AuditLog via writeAuditLog + review-runtime.md），fire-and-forget [2026-06-25: L2 收口]
- `src/instrumentation.ts`：全局 unhandledRejection 拦截器，覆盖 `/api/agent/*`、`/api/h5/*`、`/api/knowledge/*` [2026-06-25 新增]
- `scripts/check-runtime-review.ts`：dev 启动时扫描未关闭发现，console.warn 不阻断
- `package.json`：dev 链入 predev hook
- ~~proxy/route 最外层：try/catch → appendRuntimeFinding → re-throw~~ → proxy/route 手动 try/catch 已移除，统一由 instrumentation.ts 全局捕获 [2026-06-25: 架构升级]

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `.qoder/templates/checklist-template.md` | 修改 | [T] 项补 3 组验证方法 |
| 2 | `.qoder/templates/review-implementation-template.md` | 修改 | 插入多 API 场景匹配 + 外键完整性两个对照节 |
| 3 | `src/lib/append-runtime-finding.ts` | ~~新建~~ → 新建 + 修改 | ~~边界异常证据写入（AuditLog RUNTIME_ERROR + review-runtime.md）~~ → + L2 收口为 writeAuditLog()；source 类型扩展为 6 值 [2026-06-25] |
| 4 | `scripts/check-runtime-review.ts` | 新建 | predev 脚本，扫描未关闭运行时发现 |
| 5 | `package.json` | 修改 | 新增 predev script，dev 链入 |
| 6 | `src/proxy.ts` | 修改 | ~~proxy 函数体外层包 try/catch → appendRuntimeFinding~~ → 移除手动 try/catch（改为 instrumentation 全局捕获） [2026-06-25] |
| 7 | `src/app/api/agent/[hash]/route.ts` | 修改 | ~~handler 外层包 try/catch → appendRuntimeFinding~~ → 移除手动 try/catch [2026-06-25] |
| 8 | `src/instrumentation.ts` | **新建** | 全局 unhandledRejection 拦截器（替代手动包裹） [2026-06-25] |

## 4. 回滚方案

### 代码回滚

```bash
git reset --hard HEAD~1
```

### 数据回滚

无数据迁移。`AuditLog` 表新增的 RUNTIME_ERROR 记录不影响已有数据。

## 5. 执行前置检查

- [ ] ~~`src/proxy.ts` 和 `src/app/api/agent/[hash]/route.ts` 结构确认（确认 proxy 函数体 / handler dispatch 位置）~~ → 已实施移除，无需手动确认 [2026-06-25]
- [ ] `AuditLog` 表存在且可用
- [ ] `.qoder/reviews/` 目录可写
- [ ] `npx tsc --noEmit` 当前无错误（或已知错误与本变更无关）

## 6. 执行步骤摘要

```text
Phase 1: 模板层
  Task 1.1 (checklist 补 [T] 验证方法)
  Task 1.2 (review-implementation 加对照节)
            │
Phase 2: 代码层
  Task 2.1 (append-runtime-finding.ts) ──┐
  Task 2.2 (check-runtime-review.ts) ────┤ 可并行
  Task 2.3 (package.json) ───────────────┘
            │
            ▼
  ~~Task 2.4 (proxy.ts 接入)~~ → Task 2.4 (proxy.ts **移除**包裹) [2026-06-25]
  ~~Task 2.5 (route.ts 接入)~~ → Task 2.5 (route.ts **移除**包裹) [2026-06-25]
  **Task 2.6 (instrumentation.ts 新建)** [2026-06-25]
            │
Phase 3: 验证     ▼
  Task 3.1 (tsc)
  Task 3.2 (ADD 合规)
  Task 3.3 (E2E curl)
```

## 7. 上下游关联

```
                              上游（触发源）
                     farm-agent-agrisynapse-integration
                              -review2.md §5
                              5 个运行时发现
                                    │
                                    ▼
                     farm-agent-review-and-evidence-
                           hardening-plan-v1.md    ← 本交接对应的 plan
                                    │
                    ┌───────────────┼───────────────┐
                    ▼               ▼               ▼
              specs/           review-v1.md    review-runtime.md
              (spec/tasks/
               checklist)
                                    │
                                    ▼
                              本 handoff
                                    │
                                    ▼
                              下游（消费者）
                    session-init SKILL (扫描 review-runtime.md)
                    predev hook (每次 dev 启动检查)
```

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用，AI 助手在自己的对话中**直接复制粘贴这些参数调用工具即可**，不需要写 SQL。共 5 条审计记录可恢复完整开发上下文。

### 总体一键恢复

```text
query_audit_logs({ keyword: "boundary-evidence" })
query_audit_logs({ keyword: "appendRuntimeFinding" })
```
→ 预期返回 4-5 条记录

### 逐文件审计查询

```text
query_audit_logs({ targetId: "src/lib/append-runtime-finding.ts" })
→ CREATE: ADD-11边界证据站：跨系统合约断裂时自动落盘诊断上下文到AuditLog+review-runtime.md
→ REFACTOR (2026-06-25): L2 审计写入改 writeAuditLog()；source 类型扩展为 6 值

query_audit_logs({ targetId: "src/instrumentation.ts" })
→ CREATE (2026-06-25): 全局 unhandledRejection 拦截器，覆盖 /api/agent|h5|knowledge/*

query_audit_logs({ targetId: "scripts/check-runtime-review.ts" })
→ CREATE: predev脚本：扫描review-runtime.md未关闭发现，console.warn不阻断启动

query_audit_logs({ targetId: "package.json" })
→ MODIFY: 新增predev脚本（扫描review-runtime.md），dev命令链入predev hook

query_audit_logs({ targetId: "src/proxy.ts" })
→ MODIFY: ~~外层包 try/catch + appendRuntimeFinding~~ → 移除手动包裹，改为 instrumentation 全局捕获

query_audit_logs({ targetId: "src/app/api/agent/[hash]/route.ts" })
→ MODIFY: ~~GET/POST handler 外层包 try/catch + appendRuntimeFinding~~ → 移除手动包裹
```

### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE "targetId" IN (
  'src/lib/append-runtime-finding.ts',
  'scripts/check-runtime-review.ts',
  'package.json',
  'src/proxy.ts',
  'src/app/api/agent/[hash]/route.ts'
)
ORDER BY "createdAt" DESC;
```

### 恢复判定标准

- `query_audit_logs` 命中 ≥ 6 条（CREATE ×2 + MODIFY ×3 + INFRA ×1）
- `grep -R "appendRuntimeFinding" src/` 应在 append-runtime-finding.ts + instrumentation.ts 中有引用
- `grep -R "check-runtime-review" scripts/` 应有 1 个文件
- `grep "unhandledRejection" src/instrumentation.ts` 应有命中

---

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过（零错误）
- ~~[x] ADD 合规：`check_phase_symmetry` 全部对称~~
- ~~[x] ADD 合规：`check_failure_path` 通过（2 个 catch 块为 fire-and-forget 设计）~~
- ~~[x] 所有文件改动已记录 ADD-7 审计（5 条，`query_audit_logs` 可回查）~~ → 增量记录 4 条（`query_audit_logs` 可回查，共 9 条） [2026-06-25]
- ~~[x] `review-runtime.md` 已生成，[R] 项待运行时验证~~
- ~~[x] proxy/route 边界证据站就位：异常逃逸前 appendRuntimeFinding → re-throw~~ → proxy/route 手动 try/catch 已移除，统一由 instrumentation.ts 全局 unhandledRejection 捕获 [2026-06-25]
- [x] append-runtime-finding.ts L2 写入已收口到 writeAuditLog() [2026-06-25]
