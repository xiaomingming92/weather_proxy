# farm-agent — 流式中间态 UI 修复 交接手册

> **Plan**: farm-agent-intermediate-streaming-ui-fix-v1
> **轮次**: Phase 4（工具调用持久化架构重构：从 route 层补丁到 NodeStreamController 静态缓存统一路径）
> **完成时间**: 2026-06-17

---

## 1. 交接前状态（Phase 3 → Phase 4 过渡）

Phase 3 实现了 `toolCall`/`toolResult` SSE 事件推送，但持久化采用了**补丁方案**：
- `route.ts` SSE 闭包内声明临时 `toolCallsLog` 数组，监听 `tool_call`/`tool_result` 事件手动收集
- 前端从 `metaObj.toolCalls`（metadata 顶层）读取
- 而证据条（evidence）和 RAG 结果（ragResult）早已通过 `NodeStreamController` 静态 Map 模式统一收集到 `streamingTraces`
- `toolCall()` / `toolResult()` 方法只做了 emit，没有做静态缓存收集

Phase 4 将工具调用持久化路径统一到 `NodeStreamController._traceToolCalls` → `collectStreamingTraces()` → `streamingTraces.toolCalls`，与 evidence/ragResult 保持一致。

---

## 2. 交接后状态（目标）

- ✅ `stream-bus.ts` 新增 `ToolCallEvent` / `ToolResultEvent` + union + audit
- ✅ `NodeStreamController` 新增 `toolCall()` / `toolResult()` 方法 + `_traceToolCalls` 静态 Map
- ✅ `collectStreamingTraces()` 新增返回 `toolCalls`（与 evidence/ragResult 同路径）
- ✅ `retrieval.ts` isSummary expert 跳过 RAG（`EXPERT_SKIPPED` 审计）
- ✅ route.ts（stream + hash）删除补丁 `toolCallsLog`，`registerStreamBus` 恢复纯转发
- ✅ metadata 持久化走 `structuredResponse.streamingTraces.toolCalls`（不单独合并）
- ✅ 前端 `agentChat.ts` loadThread 从 `st?.toolCalls` 读取（与 evidence/ragResult 一致）
- ✅ 无数据显示 "暂无数据"（`#empty` 插槽），不 dump JSON
- ✅ 3 处原生 `<table>` 替换为 `<el-table>`
- ✅ 后端 5 个工具声明 `columns: [{prop, label}]`，返回拍扁为 `{success, total, list, columns}`
- ✅ 前端 `getTableColumns()` 直接读 `result.columns`，模板支持中文列名
- ✅ `npx tsc --noEmit` + `npx vue-tsc --noEmit` 零新增错误

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/agents/stream-bus.ts` | 修改 | 新增 ToolCallEvent / ToolResultEvent + union + audit |
| 2 | `src/agents/node-stream-controller.ts` | 修改 | 新增 `toolCall/toolResult` + `_traceToolCalls` 静态 Map + `collectStreamingTraces()` 返回 toolCalls |
| 3 | `src/agents/nodes/retrieval.ts` | 修改 | isSummary expert 跳过 RAG，审计 `EXPERT_SKIPPED` |
| 4 | `src/app/api/agent/chat/stream/route.ts` | 修改 | 删除补丁 `toolCallsLog`，`registerStreamBus` 纯转发，metadata 走 streamingTraces |
| 5 | `src/app/api/agent/[hash]/route.ts` | 修改 | 同 stream/route.ts |
| 6 | `src/agents/tools/impl/farm-data-tools.ts` | 修改 | 新增 ToolColumn 接口 + 5 套列常量 + unwrapPageResponse()，返回拍扁为 {success, total, list, columns} |
| 7 | agrisynapse `src/store/modules/agentChat.ts` | 修改 | loadThread 从 `st?.toolCalls` 读取（streamingTraces 内）|
| 8 | agrisynapse `src/views/llm/components/LlmChatView.vue` | 修改 | 3 处 el-table 替换 + 无数据友好提示 + getTableColumns/getDataRows + 中文列名 |

---

## 4. 数据流变更

### 工具返回格式（前后端契约）

**旧格式**（嵌套 3 层）:
```json
{ "success": true, "data": { "code": 200, "data": { "total": 5, "list": [...] } } }
```

**新格式**（扁平 1 层 + 列定义）:
```json
{
  "success": true,
  "total": 5,
  "list": [{ "dataTime": "2026-06-15", "temperature": 28.5, ... }],
  "columns": [
    { "prop": "dataTime", "label": "数据时间" },
    { "prop": "temperature", "label": "温度(℃)" }
  ]
}
```

### 前端函数映射

| 旧函数 | 新函数 | 变更 |
|--------|-------|------|
| `getToolResultCols(result, toolName)` | `getTableColumns(result)` | 直接读 `result.columns`，返回 `ToolColDef[]` |
| `getEvidenceCols(data, toolName)` | `getTableColumns(result)` | 统一为一个函数 |
| — | `getDataRows(data)` | 新增：从对象/数组统一提取行数据 |
| `TOOL_FALLBACK_COLS` 常量 | 移除 | 列定义权威来源移至后端 |

### 模板变更

```
旧: :prop="col" :label="col" (col 是 string)
新: :prop="col.prop" :label="col.label" (col 是 ToolColDef)

旧: :data="(ev as any).data" (证据链表格)
新: :data="getDataRows((ev as any).data)" (兼容新旧格式)
```

### 数据流统一路径（toolCalls 持久化，Phase 4 重构）

Phase 4 将 toolCalls 持久化路径统一到 NodeStreamController 静态缓存：

```
toolCall()/toolResult() → _traceToolCalls (静态 Map)
                                    ↓
                        collectStreamingTraces()
                                    ↓
                        streamingTraces: { evidence, ragResult, toolCalls }
                                    ↓
                        response.ts → structuredResponse
                                    ↓
                        route.ts → metadata → DB
                                    ↓
                        前端 rehydration: streamingTraces.toolCalls
```

**对比旧方案（Phase 3 补丁）**：

```
route.ts 闭包 toolCallsLog[] → 手动 push → metadata.toolCalls (顶层)
前端: metaObj.toolCalls
```

---

## 5. 工具列定义（5 套）

| 工具 | 列数 | 列名示例 |
|------|------|---------|
| `query_soil_moisture` | 6 | 数据时间 / 地块 / 10cm湿度(%) / 20cm湿度(%) / 土壤温度(℃) / pH值 |
| `query_farm_weather` | 6 | 数据时间 / 温度(℃) / 湿度(%) / 风速(m/s) / 降雨量(mm) / 地块 |
| `query_insect_data` | 5 | 数据时间 / 虫害名称 / 数量 / 危害等级 / 地块 |
| `query_insect_type` | 3 | 虫害名称 / 类别 / 描述 |
| `query_massif` | 4 | 地块名称 / 面积(亩) / 作物 / 位置 |

列定义位置: `src/agents/tools/impl/farm-data-tools.ts` L34-73（`SOIL_MOISTURE_COLUMNS` 等常量）

---

## 6. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| 刷新加载旧数据 | 旧持久化数据不含 columns，前端走 Object.keys 降级（无中文标签） | 降级路径已保留，teamplete 兼容 `{prop, label}` 对象 |
| 证据链旧数据 | evidence.data 为旧嵌套格式，`getDataRows` 不识别 → 表格为空 | `getDataRows` 兜底: 数组直接返回，对象取 `.list` |
| 列名与 API 实际字段不一致 | 后端 `columns.prop` 与 farm-server 返回的字段名不匹配 → 单元格空白 | 需运行时观察，必要时修正 column 常量 |
| 旧 metadata 含顶层 `toolCalls` 字段 | Phase 3 补丁持久化的旧数据在 `metadata.toolCalls` 顶层，Phase 4 读 `streamingTraces.toolCalls` | 前端同时兼容两处读取 或 旧数据自然过期（已被 THREAD_DELETE 清理） |

---

## 7. 恢复上下文审计查询

```text
# 总体
query_audit_logs({ keyword: "流式中间态" })
query_audit_logs({ keyword: "toolCalls" })

# 逐文件
query_audit_logs({ targetId: "src/agents/node-stream-controller.ts" })
→ CONTROLLER: _traceToolCalls 静态缓存 + collectStreamingTraces

query_audit_logs({ targetId: "src/agents/tools/impl/farm-data-tools.ts" })
→ TOOL_IMPL: 列定义标准化 + 响应拍扁

query_audit_logs({ targetId: "agrisynapse/src/views/llm/components/LlmChatView.vue" })
→ COMPONENT: getTableColumns/getDataRows + el-table 模板

query_audit_logs({ targetId: "src/app/api/agent/chat/stream/route.ts" })
→ API_ROUTE: 删除 toolCallsLog 补丁

query_audit_logs({ targetId: "src/app/api/agent/[hash]/route.ts" })
→ API_ROUTE: 删除 toolCallsLog 补丁

query_audit_logs({ targetId: "src/agents/nodes/retrieval.ts" })
→ NODE: isSummary 跳过 RAG
```

### 恢复判定标准

- `query_audit_logs` 命中 ≥ 6 条
- `grep "_traceToolCalls" src/agents/node-stream-controller.ts` 应有 3 处（声明 + toolCall 写入 + toolResult 更新）
- `grep "toolCalls" src/agents/node-stream-controller.ts` 应有 collectStreamingTraces 返回
- `grep "getTableColumns" agrisynapse/src/views/llm/components/LlmChatView.vue` 应有定义 + 3 处模板引用
- `grep "unwrapPageResponse" src/agents/tools/impl/farm-data-tools.ts` 应有 1 定义 + 5 调用
- `grep "columns:" src/agents/tools/impl/farm-data-tools.ts` 应有 5 处

---

## 8. 后置确认

- [x] `npx tsc --noEmit`（farm-agent）零新增错误
- [x] `npx vue-tsc --noEmit`（agrisynapse）零新增错误
- [x] 所有文件改动已记录 ADD-7 审计（3+ 条 devlog）
- [x] Plan `farm-agent-intermediate-streaming-ui-fix-plan-v1.md` 已更新 Section VII（架构重构）
- [x] `specs/.../tasks.md` 已更新 Task tc-r1~tc-r7
- [x] toolCalls 持久化路径统一到 NodeStreamController 静态缓存模式
