# farm-agent-deep-kb-dualpath-retrieval-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。将 Plan 的 Task 映射到 ADD 九阶段的每步具体动作。
>
> **模式**：重型（Heavyweight）——每步产出检查强制执行"验证并更新项目状态"，包含 check_spec_sync 文档-代码交叉校验。
>
> **绑定**：Plan: `farm-agent-deep-kb-dualpath-retrieval-plan-v1.md` · Spec: `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/spec.md` · Tasks: `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/tasks.md` · Handoff: `farm-agent-deep-kb-dualpath-retrieval-handoff-v1.md`

---

## 原子闭包判定

```
原子闭包三可性判定
══════════════════
业务功能: 项目知识库与全局知识库双路并行检索，矛盾时用户自主裁决
Task Groups: 0, 1, 2, 5, 6, 7, 8, 9（8 组；3/4 废弃）

逐组业务价值判定:
  Group 0 (裁决策略): 不能用 — 策略定义了但检索节点没消费，用户无感知
  Group 1 (projectId 链路): 不能用 — 数据有了但检索管道没切，用户无感知
  Group 2 (State 类型): 不能用 — 类型定义了但无数据填充
  Group 5 (retrieval 改造): 能用 ← 这里是业务价值的"出生点"，双路检索首次可用
  Group 6 (Graph 集成): 部分可用 — 条件边清理+向量信号消费在第1轮；interrupt 在第2轮
  Group 7 (stream/resume): 不能用 — 无 interrupt() 调用则无需检测
  Group 8 (前端): 部分可用 — customization 过滤在第1轮独立可用；交互卡片在第2轮
  Group 9 (编译验证): 不能独立 — 依附前序

判定结论: 需要 2 轮（2 个原子闭包）

第1轮（原子闭包1）: Groups 0+1+2+5+6(条件边)+8(过滤)+9 — 业务功能: 双路检索上线
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
第2轮（原子闭包2）: Groups 6(interrupt)+7+8(交互卡片)+9 — 业务功能: 矛盾裁决交互
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## Step 0：文档先行（Documentation First）

**输入**：
- 上游 Review: `farm-agent-deep-kb-dualpath-retrieval-review-v1.md`（13 问题全量闭环）
- Plan 文档: `farm-agent-deep-kb-dualpath-retrieval-plan-v1.md`

**动作**：
1. ✅ Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
2. ✅ `find_related_docs` 已执行（无精确匹配，架构文档已参阅）
3. ✅ Review 结论已回流至 Plan（13 个 P0/P1/P2 + 5 处残留 + 方案 B 延后）
4. ⬜ Handoff 就绪（使用多轮模板，2 轮独立章节）

**产出**：
- [x] Specs 三元组路径确认: `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/`
- [ ] Handoff 就绪（`farm-agent-deep-kb-dualpath-retrieval-handoff-v1.md`，Step 8 完成后生成）

### §0.8 DPS 闸门

调用 `check_dps({ planKeyword: "dualpath-retrieval" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |
| 70–84 | 🟡 | 回退补齐短板 |
| < 70 | 🔴 | 回退细化 Plan |

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**动作**：在 `AgentAuditPhase` 联合类型中新增字面量。

| Phase | 使用场景 | 所属轮次 |
|-------|---------|---------|
| `KB_DISAGREEMENT` | KB 矛盾检测触发时记录（severity: HIGH） | 第 2 轮 |

`RETRIEVAL_RESULT` 已有，本轮扩展其 metadata（expertId + distances[]），第 1 轮完成。

**产出**：
- [ ] AgentAuditPhase 新增 KB_DISAGREEMENT，扩展 RETRIEVAL_RESULT metadata

---

## Step 2：审计基础设施确认

**动作**：
1. 确认 `agentAudit()` 通道可用（三通道：console + file + AuditLog）
2. 确认 `writeAuditLog()` 可接受新增的 KB_DISAGREEMENT 事件

**产出**：
- [ ] agentAudit 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

### §3.0 前置守卫

调用 `check_add_route_status` 确认本 add-route 文件有效存在。

### Task 映射表（第 1 轮）

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 |
|---|------|------|-----------|-----------|------|
| 0.1 | RetrievalRoutingPlan | `caijuehub/strategies/retrieval-routing.ts` | — | — | 无 |
| 0.2 | resolveRetrievalRouting() | 同上 | — | — | 0.1 |
| 0.3 | retrieval-confidence.ts | `caijuehub/strategies/retrieval-confidence.ts` | — | — | 无 |
| 0.4 | retrieval-stats.ts | `src/services/retrieval-stats.ts` | — | — | 无 |
| 0.5 | agentAuditRetrieval 扩展 | `agent-audit-logger.ts` | RETRIEVAL_RESULT | — | 无 |
| 1.1 | ChromaDB metadata projectId | `knowledge-indexer.ts` | — | — | 无 |
| 1.2 | schema.projectId Int? | `prisma/schema.prisma` | — | — | 无 |
| 1.3 | upload route parseInt | `upload/route.ts` | — | — | 1.2 |
| 1.4 | backfill script | `scripts/backfill-projectId.ts` | — | — | 1.1+1.2 |
| 2.1 | evidence 向量信号类型 | `agents/state.ts` | — | — | 无 |
| 2.2 | interrupt payload 类型 | 同上 | — | — | 无 |
| 5.1 | retrieval 调 resolveRetrievalRouting | `nodes/retrieval.ts` | RETRIEVAL_RESULT | — | 0+1+2 |
| 5.2 | 并行检索 + 向量信号暴露 | 同上 | RETRIEVAL_RESULT | — | 5.1 |
| 6.1 | 移除废弃节点引用 | `index.ts` | — | — | 5 |
| 6.2 | reasoning 消费 promptHint | `nodes/reasoning.ts` | — | — | 0.3+5 |
| 8a | customization projectId 过滤 | `../agrisynapse/.../index.vue` | — | — | 1 |
| 8b | grounding API projectId | `../agrisynapse/.../grounding.ts` | — | — | 1 |
| 9.1 | farm-agent tsc | — | — | — | 全部 |

### Task 映射表（第 2 轮）

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 |
|---|------|------|-----------|-----------|------|
| 6.4 | reasoning interrupt() | `nodes/reasoning.ts` | KB_DISAGREEMENT | KB_DISAGREEMENT | 第1轮 |
| 6.5 | resume 上下文恢复 | 同上 | — | — | 6.4 |
| 7.1 | stream interrupt chunk 检测 | `stream/route.ts` | — | — | 6.4 |
| 7.2 | /api/agent/resume 端点 | `resume/route.ts` | — | — | 7.1 |
| 8c | 交互点卡片前端渲染 | `../agrisynapse/.../LlmChatView` | — | — | 7.1 |
| 9.2 | 集成测试 | — | — | — | 全部 |

### 依赖拓扑

```
第 1 轮:
  0, 2 → 5 → 6(条件边) → 9.1
  1 → 8(前端过滤)

第 2 轮（依赖第 1 轮 evidence 信号）:
  第1轮.5 → 6(interrupt) → 7 → 8(交互卡片) → 9.2
```

**产出**：
- [ ] 全部 Task [T] 项通过，tasks.md 已完成项逐项勾选
- [ ] 每个文件有 record_dev_operation 记录
- [ ] check_spec_sync 确认 spec 勾选状态与代码一致

---

## Step 3.5：实现审查

**动作**：
1. 执行 checklist.md 全部 [T] 编译期检查项
2. 生成 review-implementation.md
3. 生成 review-runtime.md（含 [R] 待验证清单）
4. check_spec_sync 确认一致性

---

## Step 4：审计数据验证

**动作**：
1. `npx tsc --noEmit`
2. `check_phase_symmetry`
3. `check_failure_path`
4. `check_spec_sync`

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "dualpath-retrieval" })`。

| RAHS | 判定 | 动作 |
|------|:--:|------|
| ≥ 90 | 🟢 | 进入 Step 5 |
| 70–89 | 🟡 | 自检范围扩散/审计漏记/类型错误 |
| < 70 | 🔴 | 返工 Step 3 |

---

## Step 5：AI 自动合规检查

调用 `check_add_compliance` 扫描全量修改文件。

---

## Step 6-7：问题定位与修复（异常时进入）

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**动作**：
1. 收敛判定：全部 [T] 通过 + [R] 清单生成 + RAHS ≥ 90
2. RAHS 最终核定
3. check_spec_sync 四者一致确认
4. Handoff 更新（多轮模板，每轮独立章节）
5. Step 0 第二阶段：回架构文档做最终校准
6. ADD-7 回查：query_audit_logs 确认全量记录落库

---

## 附录：文件清单

| 文件 | 操作 | 轮次 | targetType |
|------|------|:--:|-----------|
| `src/caijuehub/strategies/retrieval-routing.ts` | 新建 | 1 | STRATEGY |
| `src/caijuehub/strategies/retrieval-confidence.ts` | 新建 | 1 | STRATEGY |
| `src/services/retrieval-stats.ts` | 新建 | 1 | SERVICE |
| `src/services/knowledge-indexer.ts` | 修改 | 1 | SERVICE |
| `prisma/schema.prisma` | 修改 | 1 | SCHEMA |
| `src/app/api/knowledge/upload/route.ts` | 修改 | 1 | API_ROUTE |
| `scripts/backfill-projectId.ts` | 新建 | 1 | SCRIPT |
| `src/agents/state.ts` | 修改 | 1 | STATE |
| `src/agents/nodes/retrieval.ts` | 修改 | 1 | NODE |
| `src/agents/nodes/reasoning.ts` | 修改 | 1+2 | NODE |
| `src/agents/index.ts` | 修改 | 1 | GRAPH |
| `src/lib/agent-audit-logger.ts` | 修改 | 1 | LIB |
| `src/app/api/agent/stream/route.ts` | 修改 | 2 | API_ROUTE |
| `src/app/api/agent/resume/route.ts` | 新建 | 2 | API_ROUTE |
| `../agrisynapse/src/views/llm/customization/index.vue` | 修改 | 1 | VIEW |
| `../agrisynapse/src/api/knowledge/grounding.ts` | 修改 | 1 | API_CLIENT |
