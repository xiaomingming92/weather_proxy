# farm-agent-aca-framework-plan-v1

> **ACA 框架** = **A**rgumentation（论证框架）+ **C**onstraint Propagation（约束传播）+ **A**djudication（人工裁决）。这是 professional 图的推理范式命名——三位专家各自产出结构化论证（Argumentation），确定性冲突检测利用硬约束/软约束传播（Constraint），不可解冲突交由人工裁决点（Adjudication），而非 LLM 自由辩论。
>
> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度（文件路径 + Phase 验收标准 + 架构维度全覆盖）。**不要**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-aca-framework-v1
- **推理范式**: ACA（Argumentation + Constraint + Adjudication）
- **启动时间**: 2026-06-16T12:00:00+08:00
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/farm-agent-three-tier-reasoning-graph-add-route-v1.md`（待生成）
  - Handoff: `.qoder/plans/farm-agent-three-tier-reasoning-graph-handoff-v1.md`（待生成）
  - Review: `.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-v1.md`（待生成）
  - Spec: `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md`（待生成）
  - Tasks: `.qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md`（待生成）
  - Checklist: `.qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md`（待生成）
- **后继 Plan**: 本 Plan 已被 [v2](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-plan-v2.md)（2026-06-25）和 [v3](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md)（2026-06-29）取代。**当前权威版本为 v3**。
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/agents/edges/conditional.ts | COMPONENT | COMPONENT_MODIFIED | routeByIntent 仅 fast/deep 两路；无 evidenceSource 路由 | 新增 routeByEvidenceSource；routeByIntent 新增 professional 分支 | 待实施 |
| src/agents/nodes/reasoning.ts | COMPONENT | COMPONENT_MODIFIED | L67 因 evidenceChain 为空拒绝 isSummary 推理；L186 错误注入"RAG 0条结果" | isSummary 识别 + 工具数据一等公民 + prompt 按证据源差异化 | 待实施 |
| src/agents/prompts/experts/factory.ts | COMPONENT | COMPONENT_MODIFIED | 证据区块无条件优先于工具数据区块 | isSummary 时工具数据区块前置，去掉"RAG 0条结果"前缀 | 待实施 |
| src/agents/prompts/experts/weekly-report.ts | COMPONENT | COMPONENT_MODIFIED | prompt 说"引用核心专家独立报告" | 改为"基于以下实时监测数据" | 待实施 |
| src/agents/prompts/experts/daily-report.ts | COMPONENT | COMPONENT_MODIFIED | 同上歧义 prompt | 同上修正 | 待实施 |
| src/agents/index.ts | COMPONENT | COMPONENT_MODIFIED | 单一 workflow 编译为 agent | 拆为 fastGraph/deepGraph/professionalGraph 三个编译图；新增入口路由 | 待实施 |
| src/agents/nodes/structured-output.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 专家自由文本 → ExpertClaim 结构体转换 | 待实施 |
| src/agents/nodes/conflict-resolver.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 确定性冲突检测（前提互斥/资源冲突/时序矛盾） | 待实施 |
| src/agents/nodes/coordination-dialogue.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 定向提问协调 + 约束松弛求解 | 待实施 |
| src/agents/nodes/aggregation.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 多专家结论格式聚合 | 待实施 |
| src/agents/state.ts | COMPONENT | COMPONENT_MODIFIED | 单 massifId 标量；无 ExpertClaim[] / ConflictReport[] | 新增 multiMassifIds / expertClaims / conflictReports / aggregatedReport | 待实施 |
| src/types/evidence.ts | TYPE | TYPE_MODIFIED | ThinkingLevel = "fast" \| "deep" | ThinkingLevel = "fast" \| "deep" \| "professional" | 待实施 |
| src/agents/prompts/types.ts | TYPE | TYPE_MODIFIED | 无 ExpertClaim / ConflictReport 类型 | 新增 ExpertClaim / ConflictReport / CoordinationResult 类型 | 待实施 |
| src/agents/reports/weekly-report.template.ts | REPORT | REPORT_MODIFIED | 引用 displayContent 等已存在 section | 对齐工具数据优先的 evidence source 变更 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

当前 Agent 管线（deep graph）存在三个瓶颈：

| 瓶颈 | 现象 | 根因 |
|------|------|------|
| **汇总专家推理断裂** | weekly_report/daily_report（isSummary=true）跳过 RAG 后，reasoning 节点收到空 evidenceChain + warning 证据，prompt 误称"RAG 检索返回 0 条结果"，而工具数据（weather/soil/insect）实际已获取并可用 | retrieval.ts 对 isSummary 返回空数组 → reasoning.ts L67 逻辑不区分证据源 → factory.ts 证据区块无条件优先于工具数据区块 |
| **多专家协作缺失** | 当用户提问涉及 pest_risk + weather + soil 三个专家时，当前管线仅做 per-expert 并行 RAG 检索 + 合并推理，专家之间无互相审查、无冲突检测、无协调机制 | 单管线设计未考虑多专家联合场景 |
| **单地块架构限制** | AgentState.massifId 为标量，无法支持"分析农场全部 5 个地块本周趋势" | 状态模型未设计多地块并行查询 |

### 1.2 目标

1. **汇总专家在 deep 图内正常工作**：跳过 RAG 检索，工具数据升级为一等证据源，推理链路通畅
2. **新增 ACA Graph（professional 图）**：采用 **A**rgumentation + **C**onstraint + **A**djudication 范式，支持 2-N 个专家联合协作——每位专家产出结构化论证（Argumentation），确定性冲突检测利用约束传播（Constraint），不可解冲突交由人工裁决（Adjudication）
3. **thinkingLevel 从 2 级扩展为 3 级**：`fast` / `deep` / `professional`
4. **deep 图不动**：单专家推理的现有能力（证据链、四元置信度、推理路径）不受影响

---

## 二、方案选型

### 2.1 候选方案对比

| 维度 | A: 在现有管线上加 if-else | B: 独立子图 + 入口路由（选用） |
|------|--------------------------|-------------------------------|
| 实现复杂度 | 低（在 reasoning/retrieval 内部分支） | 中（新建 3 个编译图 + 4 个新节点） |
| deep 图稳定性 | 高风险——改动现有节点逻辑，可能引入回归 | 零风险——deep 图不动，仅 isSummary 证据路由修正 |
| professional 扩展性 | 差——后续新增专家协调逻辑需继续在单节点内堆积 if-else | 好——professional 图独立演化，节点职责清晰 |
| 行业对标 | 无（MAC 论文用的就是多 Agent 独立子图模式） | 对齐 LangGraph Subgraph + MAC 多 Agent 模式 |
| 审计干净度 | 差——同一个 reasoning 节点的审计日志混合两种业务模式 | 好——按图路由分离审计阶段 |

### 2.2 选型理由

**选用方案 B（独立子图 + 入口路由）**。理由：

- professional 图的节点序列（fan-out → crossReview → conflictResolver → coordinationDialogue → aggregation）与 deep 图（retrieval → reasoning → interactionPoint → verdict）拓扑完全不同，不应塞进同一管线
- deep 图已被验证为行业领先的单专家推理管线，不应为兼容新模式而污染其逻辑
- LangGraph Subgraph 模式原生支持多图编译 + 入口路由
- MAC 论文（Nature 2025）验证了多 Agent 独立子图 + Supervisor 聚合的有效性，本项目在此基础上进一步提出 **ACA 范式**：用结构化论证替代 LLM 自由辩论，用约束传播替代黑盒冲突解决，用人工裁决替代自动降级。

---

## 三、架构设计

### 3.1 三图总览

> **ACA 范式定义**：Argumentation（论证框架，每位专家输出结构化 ExpertClaim 而非自由文本）→ Constraint Propagation（约束传播，hard/soft 确定性检测而非 LLM 对话协商）→ Adjudication（人工裁决，冲突不可解时 interactionPoint 呈现结构化选项而非自动 fallback）。

```
                    ┌──────────────────┐
                    │   __start__       │
                    │   input: {query,  │
                    │     explicitIntent,│
                    │     thinkingLevel?,│
                    │     massifIds[] }  │
                    └────────┬─────────┘
                             │
                             ▼
                    ┌────────────────────┐
                    │    intention        │
                    │    (三段路由判定)    │
                    │thinkingLevel:       │
                    │ fast/deep/prof.     │
                    └────────┬───────────┘
                             │
              ┌──────────────┼──────────────┐
              │ fast         │ deep         │ professional
              ▼              ▼              ▼
        ┌──────────┐  ┌──────────┐  ┌──────────────────┐
        │fastGraph │  │deepGraph │  │ACA Graph (新图) │
        │(不动)    │  │(微调)    │  │professional 图    │
        │          │  │          │  │采用 ACA 范式     │
        └──────────┘  └──────────┘  └──────────────────┘
```

| 图 | 职责 | 专家数 | 拓扑 |
|----|------|--------|------|
| fastGraph | 问候/闲聊 | 0 | intention → response |
| deepGraph | 单专家分析（含汇总专家） | 1 | intention → [toolNode] → [retrieval] → reasoning → interactionPoint → verdict → response |
| professionalGraph | 多专家联合 + 冲突协调 | 2-N | intention → fan-out → per-expert(ACA 三阶段: retrieval+reasoning→Argumentation structuredOutput→Constraint conflictResolver→协调/裁决→Adjudication) → aggregation → verdict → response |

### 3.2 deepGraph 微调：汇总专家证据路由

```
deep graph 内新增 routeByEvidenceSource：

  intention
       │
       │ routeByEvidenceSource (new)
       │
  ┌────┴────────────────────┐
  │ RAG evidence expert     │ isSummary expert
  │ (pest_risk, growth...)  │ (weekly_report, daily_report)
  │                         │
  ▼                         ▼
┌──────────┐          ┌──────────────┐
│ toolNode │          │  toolNode    │
│ (可选)    │          │  (强制)       │
└────┬─────┘          └──────┬───────┘
     │                       │
     ▼                       │
┌──────────┐                 │  ← 跳过 retrieval
│retrieval │                 │
└────┬─────┘                 │
     │                       │
     ▼                       ▼
┌──────────────────────────────────┐
│           reasoning              │
│  RAG expert: evidence ← chunks  │
│  isSummary:   evidence ← tools  │
└──────────────────────────────────┘
```

关键改动：
- [src/agents/edges/conditional.ts](file:///home/xmm/ai/farm-agent/src/agents/edges/conditional.ts)：新增 `routeByEvidenceSource`，isSummary → 跳过 retrieval，直入 reasoning
- [src/agents/nodes/reasoning.ts](file:///home/xmm/ai/farm-agent/src/agents/nodes/reasoning.ts)：L67 不再因空 evidenceChain 拒绝 isSummary；L186 去掉误导性"RAG 0条结果"前缀
- [src/agents/prompts/experts/factory.ts](file:///home/xmm/ai/farm-agent/src/agents/prompts/experts/factory.ts)：isSummary 时工具数据区块升为一等证据位置
- [src/agents/prompts/experts/weekly-report.ts](file:///home/xmm/ai/farm-agent/src/agents/prompts/experts/weekly-report.ts)：prompt 从"引用核心专家报告"改为"基于实时监测数据"

### 3.3 ACA Graph 拓扑（professional 图）

> 本图为 ACA 范式的完整载体。每位专家走独立论证链路（retrieval → reasoning → structuredOutput），产出 ExpertClaim 结构体。汇聚后经 Constraint 层做确定性冲突检测，不可解冲突进入 Adjudication 层（人工裁决点 interactionPoint）。

```

```
                    ┌─────────────────────────────────────┐
                    │          __start__                   │
                    │  input: {query, massifId[], ...}     │
                    └───────────────┬─────────────────────┘
                                    │
                                    ▼
                    ┌───────────────────────────────┐
                    │      intention (意图解析)       │
                    │  产出: subIntents[],            │
                    │        expertPlan: Expert[]    │
                    │  例: [pest_risk, weather, soil]│
                    └───────────────┬───────────────┘
                                    │
                         ┌──────────┴──────────┐
                         │  thinkingLevel       │
                         │  deep → deepGraph     │  (已有管线，不动)
                         │  professional →       │
                         └──────────┬───────────┘
                                    │
                    ════════════════╧═══════════════
                    ║   professional fan-out 层    ║
                    ════════════════╤═══════════════
                                    │
              ┌─────────────────────┼─────────────────────┐
              │                     │                     │
              ▼                     ▼                     ▼
    ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
    │ Expert A         │ │ Expert B         │ │ Expert C         │
    │ (pest_risk)      │ │ (weather_impact) │ │ (nutrition)      │
    └────────┬─────────┘ └────────┬─────────┘ └────────┬─────────┘
             │                    │                    │
             │  ┌─────────────────┴─────────────────┐  │
             │  │       per-expert 并行执行          │  │
             │  │  (LangGraph Send API fan-out)     │  │
             │  └─────────────────┬─────────────────┘  │
             │                    │                    │
             ▼                    ▼                    ▼
    ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
    │ 1. retrieval     │ │ 1. retrieval     │ │ 1. retrieval     │
    │    RAG 证据检索   │ │    RAG 证据检索   │ │    RAG 证据检索   │
    │    + tool调用    │ │    + tool调用    │ │    + tool调用    │
    └────────┬─────────┘ └────────┬─────────┘ └────────┬─────────┘
             │                    │                    │
             ▼                    ▼                    ▼
    ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
    │ 2. reasoning     │ │ 2. reasoning     │ │ 2. reasoning     │
    │    独立深度推理   │ │    独立深度推理   │ │    独立深度推理   │
    │                  │ │                  │ │                  │
    │  输入: evidence  │ │  输入: evidence  │ │  输入: evidence  │
    │       toolResult │ │       toolResult │ │       toolResult │
    │       runtimeIn  │ │       runtimeIn  │ │       runtimeIn  │
    └────────┬─────────┘ └────────┬─────────┘ └────────┬─────────┘
             │                    │                    │
             ▼                    ▼                    ▼
    ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
    │ 3. structuredOutput││ 3. structuredOutput││ 3. structuredOutput│  // 前提是改成"专家直接输出结构化 Claim"而非"事后提取"。
    │  ★ 不再是自由文本  │ │  ★ 不再是自由文本  │ │  ★ 不再是自由文本  │
    └────────┬─────────┘ └────────┬─────────┘ └────────┬─────────┘
             │                    │                    │
             └────────────────────┼────────────────────┘
                                  │
                    ══════════════╧═══════════════
                    ║  结构体汇聚 (fan-in)       ║
                    ══════════════╤═══════════════
                                  │
                    ┌─────────────┴─────────────┐
                    │  ExpertClaims[]           │
                    │  每项: {                  │
                    │    expertId,              │
                    │    claim,                 │
                    │    evidence,              │
                    │    preconditions[],       │
                    │    hardConstraints[],     │
                    │    softConstraints[],     │
                    │    confidence,            │
                    │    recommendedActions[],  │
                    │    risks_if_ignored[]     │
                    │  }                        │
                    └─────────────┬─────────────┘
                                  │
                                  ▼
                    ══════════════╧═══════════════
                    ║   冲突检测层 (确定性逻辑)   ║
                    ══════════════╤═══════════════
                                  │
                    ┌─────────────┴─────────────┐
                    │  ConflictResolver         │
                    │                           │
                    │  检测三类冲突:              │
                    │                           │
                    │  1. 前提互斥               │
                    │     A.precondition         │
                    │     ∩ B.precondition = ∅   │
                    │     例: "无降雨" vs         │
                    │         "明天大雨"          │
                    │                           │
                    │  2. 资源冲突               │
                    │     A.action 所需资源       │
                    │     ∩ B.action 所需资源     │
                    │     > 可用上限              │
                    │     例: 同一天同一台机械     │
                    │                           │
                    │  3. 时序矛盾               │
                    │     A.action.deadline       │
                    │     < B.action.earliest     │
                    │     例: 打药窗口周五结束    │
                    │          降雨周五才开始  
                    │  4. 执行标准不一致
                    └─────────────┬─────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │  ConflictReport[]          │
                    │  每项: {                   │
                    │    type,                   │
                    │    involvedExperts[],      │
                    │    description,            │
                    │    severity: HARD | SOFT,  │
                    │    suggestedResolution     │
                    │  }                         │
                    └─────────────┬─────────────┘
                                  │
                         ┌────────┴────────┐
                         │                 │
                    无冲突/             有冲突
                    全软冲突            含硬冲突
                         │                 │
                         ▼                 ▼
              ┌───────────────┐  ┌───────────────────────┐
              │  直接聚合     │  │  CoordinationDialogue  │
              │               │  │  (协调对话轮)           │
              │  按权重合并   │  │                        │
              │  格式对齐     │  │  不是开放式辩论          │
              │  生成统一视图 │  │  是定向提问+约束松弛:    │
              └───────┬───────┘  │                        │
                      │          │  1. 识别冲突中的可变项   │
                      │          │  2. 向相关专家定向提问:   │
                      │          │     "weather: 后天有窗口?"│
                      │          │     "pest: 推迟24h风险?" │
                      │          │  3. 收集修订建议         │
                      │          │  4. 尝试约束松弛求解     │
                      │          └───────────┬───────────┘
                      │                      │
                      │             ┌────────┴────────┐
                      │             │                 │
                      │        冲突可解           冲突不可解
                      │         (松弛成功)         (硬冲突残留)
                      │             │                 │
                      │             ▼                 ▼
                      │  ┌───────────────┐  ┌──────────────────────┐
                      │  │ 协调结果合并   │  │ interactionPoint     │
                      │  └───────┬───────┘  │  (人工裁决点)          │
                      │          │          │                       │
                      │          │          │  生成结构化选项:        │
                      │          │          │  {                    │
                      │          │          │   conflict,           │
                      │          │          │   optionA: {          │
                      │          │          │    采纳pest建议,       │
                      │          │          │    风险: 药效降低      │
                      │          │          │   },                  │
                      │          │          │   optionB: {          │
                      │          │          │    等雨停再打,         │
                      │          │          │    风险: 虫害加重      │
                      │          │          │   }                   │
                      │          │          │  }                    │
                      │          │          │                       │
                      │          │          │  ★ interrupt()       │
                      │          │          │    图暂停，不结束       │
                      │          │          │    State 完整保留     │
                      │          │          │    (expertClaims[]    │
                      │          │          │     conflictReports[] │
                      │          │          │     全部在内存)        │
                      │          │          └──────────┬───────────┘
                      │          │                      │
                      │          │          ┌──────────┴───────────┐
                      │          │          │  用户选择后           │
                      │          │          │  Command(resume=     │
                      │          │          │    optionA/optionB)  │
                      │          │          │  图从 interrupt()    │
                      │          │          │  下一行继续执行       │
                      │          │          └──────────┬───────────┘
                      │          │                      │
                      │          │                      ▼
                      │          │          ┌──────────────────────┐
                      │          │          │  aggregation         │
                      │          │          │  (携带用户选择的      │
                      │          │          │   专家结论聚合)       │
                      │          │          └──────────┬───────────┘
                      │          │                      │
                      └──────────┼──────────────────────┘
                                 │
                                 ▼
                    ┌───────────────────────┐
                    │    aggregation         │
                    │   (格式聚合层)          │
                    │                        │
                    │  合并已协调的专家结论    │
                    │  + 冲突标记 (如有残留)  │
                    │  → AggregatedReport    │
                    └───────────┬───────────┘
                                │
                                ▼
                    ┌───────────────────────┐
                    │    verdict             │
                    │   (业务裁决)            │
                    │                        │
                    │  与 deep graph 共享    │
                    │  verdictNode           │
                    │  → VerdictResult       │
                    └───────────┬───────────┘
                                │
                                ▼
                    ┌───────────────────────┐
                    │    response            │
                    │   (回复生成)            │
                    │                        │
                    │  与 deep graph 共享    │
                    │  responseNode          │
                    └───────────┬───────────┘
                                │
                                ▼
                           __end__
```

### 3.3.1 ACA 三阶段对照

| ACA 阶段 | 对应节点 | 核心能力 | 关键数据结构 |
|---------|---------|---------|------------|
| **A**rgumentation | retrieval + reasoning + structuredOutput | 每位专家独立论证，产出结构化主张 | ExpertClaim（claim + evidence + confidence + preconditions） |
| **C**onstraint | conflictResolver + coordinationDialogue | 确定性冲突检测（前提互斥/资源冲突/时序矛盾），约束松弛求解 | ConflictReport（type + severity HARD/SOFT + suggestedResolution） |
| **A**djudication | interactionPoint + verdict | 硬冲突残留时向人类呈现结构化权衡选项 | 结构化选项（optionA/optionB 含风险标注） |

### 3.3.2 深图内部：汇总专家证据路由

```
deep graph 内部路由优化:

  intention (识别 isSummary expert)
       │
       │ routeByEvidenceSource
       │
  ┌────┴────────────────────┐
  │                         │
  │ RAG evidence expert     │ isSummary expert
  │ (pest_risk, ...)        │ (weekly_report, daily_report)
  │                         │
  ▼                         ▼
┌──────────┐          ┌──────────────┐
│ toolNode │          │  toolNode    │  ← 同样会调工具
│ (可选)    │          │  (强制)       │
└────┬─────┘          └──────┬───────┘
     │                       │
     ▼                       │
┌──────────┐                 │  ← 不回到 intention loop
│retrieval │                 │     工具数据够了，不需要 LLM 再决定
└────┬─────┘                 │
     │                       │
     ▼                       ▼
┌──────────────────────────────────┐
│           reasoning              │
│                                  │
│  RAG expert:                     │
│    evidence ← RAG chunks         │
│    toolResults ← 补充上下文        │
│                                  │
│  isSummary expert:               │
│    evidence ← toolResults        │  ← 工具数据升级为一等证据
│    RAG ← 不参与                   │
│    prompt 不再说"0条结果"          │
└──────────────┬───────────────────┘
               │
               ▼
     interactionPoint → verdict → response
```

### 3.4 新数据结构

**ExpertClaim** — 每位专家推理后的结构化输出（论证框架 + 约束传播）：

```typescript
interface ExpertClaim {
  expertId: string
  expertLabel: string

  // ── 论证框架 ──
  claim: string                     // 核心主张
  reasoningPath: ReasoningStep[]    // 推理链条（已有）
  confidence: ConfidenceBreakdown   // 四元置信度（已有）

  // ── 约束传播 ──
  preconditions: string[]           // 前提条件（如"无降雨"、"温度<35℃"）
  hardConstraints: {                // 硬约束（不可违反）
    type: "time" | "resource" | "dependency"
    description: string
  }[]
  softConstraints: {                // 软约束（可放松）
    type: "time" | "resource" | "dependency"
    description: string
    penalty: number                 // 违反代价
  }[]

  // ── 输出 ──
  recommendedActions: {
    action: string
    timing: string
    resources: string[]
    deadline?: string
  }[]
  risksIfIgnored: RiskItem[]        // 已有类型
}
```

**ConflictReport** — 冲突检测层输出：

```typescript
interface ConflictReport {
  type: "PRECONDITION_CONFLICT" | "RESOURCE_CONFLICT" | "TEMPORAL_CONFLICT"
  involvedExperts: string[]         // 涉及冲突的 expertId 列表
  description: string               // 人类可读的冲突描述
  severity: "HARD" | "SOFT"        // HARD = 不可自动解决，需人工裁决
  suggestedResolution?: string      // 建议的解决方向
}
```

**CoordinationResult** — 协调对话轮输出：

```typescript
interface CoordinationResult {
  resolved: boolean                 // true = 冲突已解，false = 仍有硬冲突残留
  revisedClaims: ExpertClaim[]      // 修订后的专家结论
  residualConflicts: ConflictReport[] // 未能解决的残留冲突
}
```

**冲突检测三类场景**（确定性逻辑，非 LLM）：

| 类型 | 检测逻辑 | 示例 |
|------|---------|------|
| 前提互斥 | `A.precondition ∩ B.precondition = ∅` | pest 假设"无降雨"，weather 预报"明天大雨" |
| 资源冲突 | `A.resources ∩ B.resources` 超过可用上限 | 同一天同一台机械被 pest 和 nutrition 同时需要 |
| 时序矛盾 | `A.deadline < B.earliest` | 打药窗口周五结束，降雨周五才开始 |

### 3.5 节点复用矩阵

| 节点 | fastGraph | deepGraph | professionalGraph |
|------|-----------|-----------|-------------------|
| intentionNode | ✅ | ✅ | ✅ |
| toolNode | - | ✅ | ✅（per-expert） |
| retrievalNode | - | ✅ | ✅（per-expert） |
| reasoningNode | - | ✅ | ✅（per-expert，增强结构化输出） |
| interactionPointDetectionNode | - | ✅ | ✅ |
| verdictNode | - | ✅ | ✅ |
| responseNode | ✅ | ✅ | ✅ |
| structuredOutputNode | - | - | ✅（新） | 
| conflictResolverNode | - | - | ✅（新） |
| coordinationDialogueNode | - | - | ✅（新） |
| aggregationNode | - | - | ✅（新） |

### 3.6 State 扩展

```
AgentState 新增字段:
  thinkingLevel: "fast" | "deep" | "professional"  ← 类型扩展
  massifIds: number[]       ← 多地块支持（标量 massifId 保留兼容）
  expertPlan: Expert[]      ← professional 图专家执行计划
  expertClaims: ExpertClaim[]   ← per-expert 结构化结论
  conflictReports: ConflictReport[]  ← 冲突检测结果
  coordinationResult: CoordinationResult | null  ← 协调对话结果
  aggregatedReport: AggregatedReport | null      ← 聚合后的统一报告
```

---

## 四、实施步骤 + 依赖图

```
Phase 1: deep graph 汇总专家修复 ──✅ 已完成（2026-06-17 前置交付）
Phase 2: 类型系统 + State 扩展 ────┤ 可并行
Phase 3: professional graph 新建 ──┘
                                    │
                                    ▼
Phase 4: 三图编译 + 入口路由 + 集成测试
```

### Phase 1: deep graph 汇总专家证据路由修正 ✅ 已完成

> 🟢 **2026-06-17 已前置完成**：分离为独立子任务，在 ACA 大图之前交付。
> 6 文件修改，`tsc --noEmit` 通过。

| # | 任务 | 文件 | 说明 | 状态 |
|---|------|------|------|:--:|
| 1.1 | 新增 routeByEvidenceSource | edges/conditional.ts | isSummary → 跳过 retrieval，直入 reasoning | [x] |
| 1.2 | reasoning 节点证据源识别 | nodes/reasoning.ts | L67 不拒绝 hasToolResults；isRagEmpty 仅非 isSummary 注入 | [x] |
| 1.3 | factory.ts 证据/工具数据区块排序 | prompts/experts/factory.ts | isSummary 时工具数据前置为一等证据 | [x] |
| 1.4 | weekly_report / daily_report prompt 重写 | prompts/experts/weekly-report.ts, daily-report.ts | "引用核心专家报告"→"基于实时监测数据" | [x] |
| 1.5 | 编译验证 | tsconfig | `npx tsc --noEmit` 通过 | [x] |

**验收**：weekly_report 工具调用后 reasoning 不再注入"RAG 0条结果"，prompt 正确使用工具数据作为一等证据。

### Phase 2: 类型系统 + State 扩展

| # | 任务 | 文件 | 说明 |
|---|------|------|------|
| 2.1 | ThinkingLevel 扩展 | types/evidence.ts | `"fast" \| "deep" \| "professional"` |
| 2.2 | ExpertClaim / ConflictReport 类型 | prompts/types.ts | 新数据结构 |
| 2.3 | AgentState 扩展 | agents/state.ts | massifIds / expertPlan / expertClaims / conflictReports / coordinationResult / aggregatedReport |
| 2.4 | 编译验证 | tsconfig | `npx tsc --noEmit` |

### Phase 3: ACA Graph 新建节点（Argumentation + Constraint + Adjudication）

| # | 任务 | 文件 | 说明 | ACA 阶段 |
|---|------|------|------|---------|
| 3.1 | structuredOutputNode | nodes/structured-output.ts | 调用 LLM 将专家自由文本转换为 ExpertClaim 结构体 | **A**rgumentation |
| 3.2 | conflictResolverNode | nodes/conflict-resolver.ts | 确定性逻辑：前提互斥/资源冲突/时序矛盾检测 | **C**onstraint |
| 3.3 | coordinationDialogueNode | nodes/coordination-dialogue.ts | 定向提问 + 约束松弛求解 | **C**onstraint |
| 3.4 | aggregationNode | nodes/aggregation.ts | 多 ExpertClaim 格式聚合 → AggregatedReport | - |
| 3.5 | ACA Graph 编译 | agents/index.ts | `new StateGraph(AgentState)` + fan-out Send API + 4 新节点 | - |
| 3.6 | 编译验证 | tsconfig | `npx tsc --noEmit` | - |

### Phase 4: 三图编译 + 入口路由 + 集成测试

| # | 任务 | 文件 | 说明 |
|---|------|------|------|
| 4.1 | 入口路由 | agents/index.ts | 根据 thinkingLevel 分发到三图 |
| 4.2 | routeByIntent 扩展 | edges/conditional.ts | 新增 professional 分支 |
| 4.3 | intention 节点增强 | nodes/intention.ts | ACA Graph 场景下产出 expertPlan |
| 4.4 | 集成验证 | - | 模拟单专家/汇总专家/多专家三种场景，验证路由正确性 |

---

## 五、验收标准

- [x] weekly_report 场景：工具数据作为一等证据被 reasoning 消费，输出含趋势分析 + 异常标注 + 建议（Phase 1 ✅）
- [ ] pest_risk 单专家场景：deep 图行为不变，RAG 证据链正常，回归零
- [ ] pest_risk + weather + soil 三专家场景：ACA Graph fan-out 并行推理 → 各自产出 ExpertClaim（**A**rgumentation）→ conflictResolver 检测冲突（**C**onstraint）→ coordinationDialogue 协调 → aggregation 聚合 → verdict → response，硬冲突残留时进入 interactionPoint（**A**djudication）
- [ ] 前提互斥冲突可被正确检测（如 pest 建议明天打药，weather 预报明天暴雨）
- [ ] 资源冲突可被正确检测（如同一时段同一机械被两个专家需要）
- [ ] 硬冲突残留 → interactionPoint 生成，用户可见结构化选项
- [ ] `npx tsc --noEmit` 零错误
- [ ] fast 图（问候/闲聊）不受影响
- [ ] 审计日志按图路由分离，ACA Graph 有独立 AgentAuditPhase

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| ADD Route | `.qoder/plans/farm-agent-three-tier-reasoning-graph-add-route-v1.md` | 待生成 |
| Handoff | `.qoder/plans/farm-agent-three-tier-reasoning-graph-handoff-v1.md` | 待生成 |
| Review | `.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-v1.md` | 待生成 |
| Spec | `.qoder/specs/farm-agent-three-tier-reasoning-graph/spec.md` | 待生成 |
| Tasks | `.qoder/specs/farm-agent-three-tier-reasoning-graph/tasks.md` | 待生成 |
| Checklist | `.qoder/specs/farm-agent-three-tier-reasoning-graph/checklist.md` | 待生成 |
| 决策管线架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` | 现有 |
| OS Kernel 架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/Agent-OS-Kernel-架构说明书.md` | 现有 |
