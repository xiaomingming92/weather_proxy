# farm-agent — 2 轮原子事务交接手册

> **适用场景**：KB 双路径检索 + 矛盾裁决，2 轮独立收敛。
>
> **用途**：新对话启动时粘贴对应轮次章节给 LLM。

---

## 全局元信息

- **父 Plan**: [farm-agent-deep-kb-dualpath-retrieval-plan-v1.md](./farm-agent-deep-kb-dualpath-retrieval-plan-v1.md)
- **执行路线图**: [farm-agent-deep-kb-dualpath-retrieval-add-route-v1.md](./farm-agent-deep-kb-dualpath-retrieval-add-route-v1.md)
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **跨仓库**: `/home/xmm/ai/agrisynapse`（前端部分）
- **总文件数**: 20（10 新建 + 10 修改）
- **轮次数**: 2
- **拆分原则**: 以业务原子闭包为边界——第 1 轮双路检索独立可用，第 2 轮矛盾裁决独立叠加

```text
第1轮 ── 双路检索上线（projectId 全链路 + 裁决策略 + retrieval 改造 + 向量信号 + 前端过滤）
            │
            ▼
第2轮 ── 矛盾裁决交互（reasoning interrupt + stream/resume + 交互卡片 + 审计 HIGH）
```

---

## 原子事务边界说明

- 第 1 轮交付后，用户即可获得"项目专属 + 全局通用"双路检索能力，evidence 携带向量距离信号在 GUI 展示。第 1 轮**不实现** interrupt()，矛盾由 LLM 自行融合。
- 第 2 轮依赖第 1 轮的 evidence 向量信号字段（vectorDistance/chunkMethod/kbSources），在此之上叠加 interrupt→卡片→resume 闭环。
- 第 1 轮禁止提前实现 interrupt() 调用。

### 交接手册与 spec 的优先级

- handoff 是入口索引，具体实现以 `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/spec.md`、`tasks.md`、`checklist.md` 为准。
- handoff 摘要与 spec 冲突时，以 spec 为准。

---

## 第1轮：双路检索上线

### 你当前的位置

你是第 1 轮。上游无（全新功能，Plan Review 已完成 13 问题全量回流）。

### 上游已完成

- Plan Review 闭环：P0/P1/P2 全量回流至 Plan
- Atomic closure 判定：2 轮拆分方案已写入 Plan §4
- Specs 三元组已生成：spec.md / tasks.md / checklist.md

### 恢复上下文审计查询（新 AI Session 首次启动必读）

#### 第一步：搜索本轮代码文件改动

```text
query_audit_logs({ targetId: "src/caijuehub/strategies/retrieval-routing.ts" })
query_audit_logs({ targetId: "src/agents/nodes/retrieval.ts" })
query_audit_logs({ targetId: "prisma/schema.prisma" })
```

#### 第二步：搜索文档变更

```text
query_audit_logs({ keyword: "SPEC" })
→ 返回 spec/tasks/checklist 创建记录
```

#### 第三步：一键恢复

```text
query_audit_logs({ keyword: "dualpath-retrieval" })
→ 返回全部本轮 ADD-7 审计记录
```

**恢复顺序**：
1. session-init SKILL
2. read `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/spec.md`（§第 1 轮 Requirements）
3. read `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/tasks.md`（Phase 1.1~1.7）
4. read `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/checklist.md`（Phase 1.1~1.7）

### 原子事务目标

交付"项目 KB + 全局 KB 双路并行检索"。覆盖 Plan Task 0/1/2/5/6(条件边)/8。

### spec 文件

- `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/spec.md` — Requirements R1.1~R1.9
- `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/tasks.md` — Phase 1.1~1.7
- `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/checklist.md` — Phase 1.1~1.7

### 你要改的文件（14 个：7 新建 + 7 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/caijuehub/strategies/retrieval-routing.ts` | 新建 | RetrievalRoutingPlan + resolveRetrievalRouting() |
| `src/caijuehub/strategies/retrieval-confidence.ts` | 新建 | promptHint 生成（方案 A） |
| `src/services/retrieval-stats.ts` | 新建 | 按 expertId 统计分位数（静默收集） |
| `scripts/backfill-projectId.ts` | 新建 | 存量 ChromaDB chunk 全量回填 projectId |
| `prisma/schema.prisma` | 修改 | Document.projectId String? → Int? |
| `src/services/knowledge-indexer.ts` | 修改 | metadata 新增 projectId（number） |
| `src/app/api/knowledge/upload/route.ts` | 修改 | FormData projectId parseInt → number |
| `src/lib/agent-audit-logger.ts` | 修改 | agentAuditRetrieval 扩展 expertId + distances[] |
| `src/agents/state.ts` | 修改 | evidence 新增 vectorDistance/chunkMethod/kbSources + KBDisagreementPayload 类型 |
| `src/agents/nodes/retrieval.ts` | 修改 | 移除三元判断，调用 resolveRetrievalRouting()，并行检索 + 信号暴露 |
| `src/agents/nodes/reasoning.ts` | 修改 | 消费 promptHint（不调用 interrupt） |
| `src/agents/index.ts` | 修改 | 移除 kbClaimExtractor/kbConflictResolver 节点引用 |
| `../agrisynapse/src/views/llm/customization/index.vue` | 修改 | 文档列表按 selectedProjectId 过滤 + 上传携带 projectId |
| `../agrisynapse/src/api/knowledge/grounding.ts` | 修改 | getDocuments/getGroundingStats 支持 projectId |

### 核心设计

```
retrieval 节点不再做 routing 决策:
  旧: groundingReady ? collectionSearch : fallbackSearch
  新: const plan = resolveRetrievalRouting(state)
       Promise.all(plan.searches.map(search)) → evidence[] + 向量信号
```

### 关键契约细化

- `retrieval-routing.ts` 必须输出 `RetrievalRoutingPlan`，所有 search 路径由 caijuehub 集中裁决
- `retrieval.ts` 内禁止出现任何三元判断或 if/else 路由逻辑
- evidence 的 vectorDistance/chunkMethod/kbSources 为只读附加字段，不改写 content
- ChromaDB metadata.projectId 类型为 number，与 Document.projectId Int 一致
- FormData projectId 必须 parseInt() 后再写入 Document

### 高风险误区

- 禁止在 retrieval.ts 内做路由决策
- 禁止跳过 record_dev_operation（每个 Task 完成后必须记录）
- **禁止本轮实现 reasoning 的 interrupt() 调用**
- 禁止在使用 parseInt 后忘记处理 NaN/null 边界

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| FILE_CREATED | STRATEGY | `src/caijuehub/strategies/retrieval-routing.ts` | 检索路由策略 | ⬜ |
| FILE_CREATED | STRATEGY | `src/caijuehub/strategies/retrieval-confidence.ts` | 置信度策略 | ⬜ |
| FILE_CREATED | SERVICE | `src/services/retrieval-stats.ts` | 统计收集器 | ⬜ |
| FILE_MODIFIED | SCHEMA | `prisma/schema.prisma` | projectId Int? | ⬜ |
| FILE_MODIFIED | SERVICE | `src/services/knowledge-indexer.ts` | metadata 加 projectId | ⬜ |
| FILE_MODIFIED | API_ROUTE | `src/app/api/knowledge/upload/route.ts` | parseInt projectId | ⬜ |
| FILE_MODIFIED | LIB | `src/lib/agent-audit-logger.ts` | distances 扩展 | ⬜ |
| FILE_MODIFIED | STATE | `src/agents/state.ts` | 向量信号类型 | ⬜ |
| FILE_MODIFIED | NODE | `src/agents/nodes/retrieval.ts` | 策略驱动检索 | ⬜ |
| FILE_MODIFIED | NODE | `src/agents/nodes/reasoning.ts` | promptHint 消费 | ⬜ |
| FILE_MODIFIED | GRAPH | `src/agents/index.ts` | 移除废弃节点 | ⬜ |
| FILE_CREATED | SCRIPT | `scripts/backfill-projectId.ts` | 存量回填 | ⬜ |
| FILE_MODIFIED | VIEW | `../agrisynapse/.../customization/index.vue` | projectId 过滤 | ⬜ |
| FILE_MODIFIED | API_CLIENT | `../agrisynapse/.../grounding.ts` | projectId 参数 | ⬜ |

**恢复关键词**：
```text
query_audit_logs({ keyword: "dualpath-retrieval-round1" })
→ 返回全部 14 条本轮 ADD-7 审计记录
```

### 验证标准

#### 已完成验证

- `npx tsc --noEmit` 通过（farm-agent）
- `cd ../agrisynapse && npx vue-tsc --noEmit` 通过
- checklist.md Phase 1.1~1.7 全部 [x]（依据代码证据逐项验证后勾选）
- tasks.md Phase 1.1~1.7 全部 Task 子项 [x]

#### 未执行的端到端验证（保留给运行时复测）

- [ ] 有 projectId 时双路检索返回两组 evidence（原因：需实际项目数据和 ChromaDB 环境）
- [ ] 无 projectId 时单路全局检索（原因：同上）
- [ ] evidence 向量字段在 GUI 白盒行正确展示（原因：需运行 dev server）

---

## 第2轮：矛盾裁决交互

### 你当前的位置

你是第 2 轮。上游第 1 轮已完成双路检索上线，evidence 向量信号（vectorDistance/chunkMethod/kbSources）已可用。

### 上游已完成

- 第 1 轮交付：
  - `retrieval-routing.ts` / `retrieval-confidence.ts` / `retrieval-stats.ts` 策略文件
  - projectId 全链路打通（Schema + Indexer + Upload + Backfill）
  - evidence 类型含 vectorDistance / chunkMethod / kbSources
  - retrieval 节点按 plan.searches 并行检索
  - reasoning 消费 promptHint（但不调 interrupt）
  - Graph 废弃节点已移除
  - customization 前端按 projectId 过滤

### 恢复上下文审计查询

#### 第一步：确认第 1 轮已收敛

```text
query_audit_logs({ keyword: "dualpath-retrieval-round1" })
→ 确认 14 条全部落库，第 1 轮已收敛
```

#### 第二步：搜索本轮代码文件

```text
query_audit_logs({ targetId: "src/agents/nodes/reasoning.ts" })
query_audit_logs({ targetId: "src/app/api/agent/stream/route.ts" })
query_audit_logs({ targetId: "src/app/api/agent/resume/route.ts" })
query_audit_logs({ targetId: "agrisynapse/src/api/llm/agent/types.ts" })
query_audit_logs({ targetId: "agrisynapse/src/api/llm/agent/index.ts" })
query_audit_logs({ targetId: "agrisynapse/src/store/modules/agentChat.ts" })
query_audit_logs({ targetId: "agrisynapse/src/views/llm/components/LlmChatView.vue" })
```

#### 第三步：一键恢复

```text
query_audit_logs({ keyword: "dualpath-retrieval-round2" })
```

**恢复顺序**：
1. session-init SKILL
2. 确认第 1 轮已收敛（query_audit_logs 回查）
3. read `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/spec.md`（§第 2 轮 Requirements）
4. read `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/tasks.md`（Phase 2.1~2.4，注意末尾 Spec 偏差记录）
5. read `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/checklist.md`（Phase 2.1~2.4）

### 原子事务目标

交付"KB 矛盾时用户自主裁决"。覆盖 Plan Task 6(interrupt)/7/8(交互卡片)。

### spec 文件

- `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/spec.md` — Requirements R2.1~R2.4
- `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/tasks.md` — Phase 2.1~2.4
- `.qoder/specs/farm-agent-deep-kb-dualpath-retrieval/checklist.md` — Phase 2.1~2.4

### 你要改的文件（8 个：1 新建 + 7 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/reasoning.ts` | 修改 | LLM 判定矛盾 → interrupt() + agentAuditKBDisagreement()；resume 后注入 userChoice + userNote |
| `src/lib/agent-audit-logger.ts` | 修改 | AgentAuditPhase 新增 KB_DISAGREEMENT + agentAuditKBDisagreement() 函数 |
| `src/app/api/agent/stream/route.ts` | 修改 | 检测 __interrupt__ chunk → SSE event: interrupt |
| `src/app/api/agent/resume/route.ts` | 新建 | POST 接收 Command({ resume: { choice, note } }) → 恢复 SSE 流 |
| `../agrisynapse/src/api/llm/agent/types.ts` | 修改 | KBDisagreementEvent + ParsedSSEEvent 正式类型 + StreamingMessage.kbDisagreement |
| `../agrisynapse/src/api/llm/agent/index.ts` | 修改 | resumeAgent() API 函数 + parseSSEStream event: 行解析 |
| `../agrisynapse/src/store/modules/agentChat.ts` | 修改 | _pausedForInterrupt 标志 + _dispatchEvent kb_disagreement + _consumeSSE 中断暂停逻辑 + resumeWithChoice/dismissInterrupt |
| `../agrisynapse/src/views/llm/components/LlmChatView.vue` | 修改 | KB 矛盾裁决交互卡片（双列对比 + 选项按钮 + 补充说明 + 提交/忽略） |

### 核心设计

```
reasoning 节点:
  收到 evidence（项目 + 全局，均带向量信号）
  LLM 判定结论:
    ├─ 一致/互补 → 正常融合输出
    └─ 相反 → agentAuditKBDisagreement() → interrupt({
                type: "kb_disagreement",
                projectEvidence: { chunkId, distance, content },
                globalEvidence: { chunkId, distance, content },
                options: ["采纳项目建议", "采纳通用建议", "暂不处理"],
                notePlaceholder: "补充说明（选填）"
              })
              → 图暂停
              → 前端卡片
              → 用户选择 + 提交
              → Command(resume) → reasoning 继续 → 输出
```

### 关键契约细化

- interrupt 前必须先调用 agentAuditKBDisagreement()（KB_DISAGREEMENT 事件，severity: HIGH）
- SSE interrupt event 格式：`{ type: "interrupt", payload: { type: "kb_disagreement", ... } }`
- resume Command 格式：`{ resume: { choice: string, note?: string } }`
- 结论相反一律 interrupt，不自动裁决，距离差仅展示参考
- MemorySaver 存 interrupt 状态，进程存活期间有效（重启后重新对话即可）

### 高风险误区

- 禁止在距离差达到某个阈值时自动裁决（结论相反一律等用户）
- 禁止在 interrupt 前遗漏 agentAuditKBDisagreement() 调用
- 禁止 resume 端点丢失 threadId 导致无法恢复 stream
- **禁止本轮修改第 1 轮的 retrieval/routing 逻辑**

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| FILE_MODIFIED | NODE | `src/agents/nodes/reasoning.ts` | interrupt() + audit | ✅ |
| FILE_MODIFIED | LIB | `src/lib/agent-audit-logger.ts` | KB_DISAGREEMENT phase + function | ✅ |
| FILE_MODIFIED | API_ROUTE | `src/app/api/agent/stream/route.ts` | interrupt chunk 检测 | ✅ |
| FILE_CREATED | API_ROUTE | `src/app/api/agent/resume/route.ts` | resume 端点 | ✅ |
| FILE_MODIFIED | TYPE_DEF | `../agrisynapse/.../agent/types.ts` | KBDisagreementEvent + ParsedSSEEvent | ✅ |
| FILE_MODIFIED | API_CLIENT | `../agrisynapse/.../agent/index.ts` | resumeAgent + SSE event: 解析 | ✅ |
| FILE_MODIFIED | STORE | `../agrisynapse/.../agentChat.ts` | 中断暂停 + resume/dismiss | ✅ |
| FILE_MODIFIED | VIEW | `../agrisynapse/.../LlmChatView.vue` | 交互卡片渲染 | ✅ |

**恢复关键词**：
```text
query_audit_logs({ keyword: "dualpath-retrieval-round2" })
→ 返回全部 5 条本轮 ADD-7 审计记录
```

### 验证标准

#### 已完成验证

- [x] `npx tsc --noEmit` 通过（farm-agent，0 错误）
- [x] `cd ../agrisynapse && npx vue-tsc --noEmit` 通过（仅预存错误，无本轮引入）
- [x] checklist.md Phase 2.1~2.4 全部 [x]（依据代码证据逐项验证后勾选）
- [x] tasks.md Phase 2.1~2.4 全部 Task 子项 [x]
- [x] CodeReview 通过（Critical 已修复，Warning 已处理）
- [x] RAHS 85 🟡（Spec 合规维度因 checklist 模板项扣分，非本轮引入）
- [x] ADD-7 审计记录 8 条全部落库（query_audit_logs 回查确认）

#### 未执行的端到端验证（保留给运行时复测）

- [ ] 模拟 KB 矛盾 → interrupt 触发 → SSE event 发送（原因：需实际 KB 数据和 LLM 推理）
- [ ] 前端渲染卡片 → 用户选择 → resume → 流继续（原因：需完整前后端联调环境）
- [ ] agentAuditKBDisagreement() 审计记录落库并 query_audit_logs 可回查（原因：需运行环境）

### CodeReview 修复记录（2026-06-17）

| 级别 | 问题 | 修复 |
|------|------|------|
| 🔴 Critical | `_consumeSSE` 中断分支清空 `_streamingMsgId` → `resumeWithChoice` 死路 | 中断分支保留 `_streamingMsgId`，不清理 |
| 🟡 Warning | resume route 缺少 `__interrupt__` 检测 | 复用主路由检测逻辑 |
| 🟡 Warning | resume route stream 缺少错误处理 | 添加 try/catch/finally |
| 🟡 Warning | `clearChat()` 不重置 `_pausedForInterrupt` | 添加重置 |
| 🔵 Suggestion | `as never` 类型断言不干净 | 改为 `as string[]` |
| 🔵 Suggestion | `kbDisagreementPayload` 死变量 | 已删除 |

---

## 每轮收敛判定补充规则

- checklist 每项勾选必须有可验证证据（编译输出/代码行号/日志）
- 未执行项诚实保留 `[ ]`，注明原因
- 执行 AI 不自行声明收敛——收敛由开发者或 Review AI 判定

---

## 附录：每轮启动模板

```text
## 上下文

你在执行 farm-agent KB 双路径检索的 [第N轮]。
上游 [第1轮~第N-1轮] 已完成。
先读 farm-agent-deep-kb-dualpath-retrieval-handoff-v1.md 的 <第N轮> 章节。

## 启动步骤

1. session-init SKILL
2. add-paradigm SKILL
3. read .qoder/specs/farm-agent-deep-kb-dualpath-retrieval/spec.md（对应轮次 Requirements）
4. read .qoder/specs/farm-agent-deep-kb-dualpath-retrieval/tasks.md（对应轮次 Phase）
5. read .qoder/specs/farm-agent-deep-kb-dualpath-retrieval/checklist.md（对应轮次 Phase）
6. 按 tasks.md 顺序执行代码修改
7. 每完成一个 Task：验证 checklist → 勾选 → record_dev_operation
8. 全部完成后：query_audit_logs 回查确认落库
```
