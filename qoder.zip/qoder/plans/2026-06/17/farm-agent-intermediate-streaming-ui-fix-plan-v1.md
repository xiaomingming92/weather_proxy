# farm-agent-tool-call-sse-events-v1

> Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。

## PLAN 元信息

- **Plan 名称**: farm-agent-intermediate-streaming-ui-fix-v1
- **启动时间**: 2026-06-16T08:30:00+08:00
- **范围**: farm-agent `NodeStreamController` + `retrieval.ts`（summary expert 跳过）+ agrisynapse 前端渲染
- **触发来源**: GUI 流式中间态渲染复查发现（工具调用无视觉反馈 + 证据条走通用 RAG 而非专家来源）
- **关联文档**:
  - 本 Plan: `.qoder/plans/farm-agent-intermediate-streaming-ui-fix-plan-v1.md`
  - ADD Route: `.qoder/plans/farm-agent-intermediate-streaming-ui-fix-add-route-v1.md`（待生成）
  - Handoff: `.qoder/plans/farm-agent-intermediate-streaming-ui-fix-handoff-v1.md`（✅ 已生成）
  - Review: `.qoder/reviews/farm-agent-intermediate-streaming-ui-fix-review-v1.md`（待生成）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-------|-----------|--------|------------|-----------|------|
| `src/agents/node-stream-controller.ts` | CONTROLLER | METHOD_ADDED + STATIC_CACHE_ADDED | 无 toolCall/toolResult 方法，无 _traceToolCalls | 新增 toolCall/toolResult + _traceToolCalls 静态 Map + collectStreamingTraces 返回 toolCalls | ✅ |
| `src/agents/stream-bus.ts` | TYPE_DEFINITION | TYPE_EXTENDED | StreamEvent union 无 tool_call/tool_result | 新增 ToolCallEvent + ToolResultEvent + union + audit | ✅ |
| `src/agents/nodes/retrieval.ts` | NODE | LOGIC_UPDATED | isSummary expert 参与检索，走通用 knowledge 库 | isSummary expert 跳过 RAG，summary 产出由 reasoning 合并 | ✅ |
| agrisynapse `LlmChatView.vue` | COMPONENT | RENDERING_UPDATED | evidence-bar 不管 source 差异都统一渲染 | evidence-bar 区分 knowledge/expert source 样式 | 待实施 |
| `src/app/api/agent/chat/stream/route.ts` | API_ROUTE | PATCH_REMOVED | SSE 闭包内 toolCallsLog 数组收集（补丁式） | 删除补丁，registerStreamBus 恢复为纯转发，toolCalls 走 streamingTraces | ✅ |
| `src/app/api/agent/[hash]/route.ts` | API_ROUTE | PATCH_REMOVED | SSE 闭包内 toolCallsLog 数组收集（补丁式） | 删除补丁，registerStreamBus 恢复为纯转发 | ✅ |
| agrisynapse `src/store/modules/agentChat.ts` | STORE | READ_PATH_FIXED | loadThread 从 `metaObj.toolCalls` 读 | 改为从 `st?.toolCalls`（streamingTraces 内）读，与 evidence/ragResult 一致 | ✅ |

---

## 一、背景与目标

### 1.1 问题现状

agrisynapse 神经元 GUI 点击"分析一周农场数据趋势"后，Agent 管线 0~24s 的流式中间态存在**两个缺口**：

**缺口 A：工具调用状态完全不可见**
- 3 个实时工具（`query_farm_weather`、`query_soil_moisture`、`query_insect_data`）在后台正常执行，但用户完全看不到工具执行状态——深度思考容器中无"工具调用中..."指示器、无工具执行完成标记。
- **根因**：`NodeStreamController` 缺少 `toolCall()` / `toolResult()` 方法，`stream-bus.ts` 虽然定义了 `"tool_call"` 和 `"tool_result"` 类型，但后端从未推送这些事件。

**缺口 B：证据条是通用 RAG 结果，非专家来源**
- 证据条显示 `source: "knowledge"`（通用知识库文档），如"32期-小麦一种就管田管意见.pdf"、"04期-小麦返青期.pdf"等，relevance 为 0%。这些是 `farm_agent` 默认 Collection 的通用文档，不是 Expert Grounding 专家专属知识。
- **根因**：`weekly_report` `isSummary: true` 但 `registry.ts` L420-437 既无 `grounding` 也无 `evidenceFilter`。`retrieval.ts` 的 per-expert 并行检索（L207-276）不判断 `isSummary`，对无 grounding 的 expert 回退到通用知识库搜索。

### 1.2 现有流式事件体系

```
NodeStreamController.method()  →  emit →  stream-bus →  SSE  →  前端 _dispatchEvent
─────────────────────────────────────────────────────────────────────────────────
ragSearch(query)               →  rag_search     →        →   msg.ragSearching = query
ragResult(count, sources)      →  rag_result     →        →   msg.ragResult = {...}
evidenceFound(evidence)        →  evidence_found  →        →   msg.evidence.push(ev)
structuredOutput(data)         →  structured_update →     →   msg.{evidenceChain,verdict,...}
token(content)                 →  token           →        →   msg.content += content
❌ toolCall(toolName, args)    →  ❌ 不存在       →        →   ❌ 前端处理器永远不触发
❌ toolResult(toolName, result)→  ❌ 不存在       →        →   ❌ 前端处理器永远不触发
```

### 1.3 目标

1. **补齐 `tool_call` / `tool_result` SSE 事件链路**：toolNode 执行工具时通过 `NodeStreamController` 推送工具执行状态，前端深度思考容器中实时显示工具调用进度。
2. **修复 summary expert 的 RAG 回退问题**：`isSummary: true` 的 expert（如 `weekly_report`）不参与 RAG 检索，其证据来源为各子专家报告合并，避免走通用知识库污染证据条。

两个修复合在一起的效果：流式中间态从"仅证据条（通用知识库文档）"变为"工具执行进度 + 专家 Grounding 证据条"。

---

## 二、方案选型

### 2.1 候选方案对比

| 方案 | 改动范围 | 事件粒度 | 复杂度 | 结论 |
|------|---------|---------|--------|------|
| A: NodeStreamController 新增方法 + toolNode 调用 | stream-bus.ts + node-stream-controller.ts + toolNode 执行处 | 粗粒度（批量 emit 3 个 tool_call 后等结果） | 低 | ✅ 推荐 |
| B: NodeStreamController 新增方法 + toolNode 逐工具 emit | 同上 | 细粒度（执行一个 emit 一个） | 中 | 前端 toolCall/toolResult 已支持逐条追加，方案 B 与前端契约一致 |
| C: 前端不新增 SSE 类型，复用 structured_update | 仅前端 | 混淆中间态/最终态语义 | 低 | ❌ 工具调用是中间态事件，不应走 structured_update 通道 |

### 2.2 选型理由

**选 B**：逐工具推送，与前端 `_dispatchEvent` 的逐条 push 语义完全一致，且用户能感知每个工具的启动和完成。

---

## 三、架构设计

### 3.1 事件类型定义

在 `stream-bus.ts` 中新增两个 SSE 事件类型：

```typescript
// 工具调用开始
export interface ToolCallEvent {
  type: "tool_call"
  toolName: string
  args: Record<string, unknown>
  toolCallId?: string
}

// 工具调用结果
export interface ToolResultEvent {
  type: "tool_result"
  toolName: string
  result: unknown
  toolCallId?: string
}
```

并加入 `StreamEvent` union type 和 `resolveAuditPhase`。

### 3.2 NodeStreamController 新增方法

```typescript
toolCall(toolName: string, args: Record<string, unknown>): void {
  this.emit({ type: "tool_call", toolName, args })
}

toolResult(toolName: string, result: unknown): void {
  this.emit({ type: "tool_result", toolName, result })
}
```

### 3.3 toolNode 调用

toolNode 在执行每个工具前调用 `stream.toolCall(toolName, args)`，执行后调用 `stream.toolResult(toolName, result)`。

### 3.4 数据流

```
toolNode
  ├─ async toolCall(toolName, args) ── SSE "tool_call" ── 前端渲染"执行中..."
  ├─ 执行工具
  ├─ async toolResult(toolName, result) ── SSE "tool_result" ── 前端渲染"完成"
  ├─ ... (下一个工具)
```

---

## 四、实施步骤

### 已完成（Done）

| Task | 内容 | 状态 |
|------|------|------|
| Task 1 | stream-bus.ts 新增 ToolCallEvent / ToolResultEvent 类型 + audit | ✅ |
| Task 2 | NodeStreamController 新增 toolCall() / toolResult() 方法 | ✅ |
| Task 3 | toolNode 执行前后调用 stream.toolCall/Result | ✅ |
| Task 5 | retrieval.ts isSummary expert 跳过 RAG | ✅ |
| Task a2 | 前端 LlmChatView.vue 工具渲染 7 个辅助函数 | ✅ |
| Task tc-b1 | route.ts SSE 闭包收集 toolCallsLog → metadata 持久化（补丁） | ✅ → 已重构 |
| Task tc-b2 | agentChat.ts loadThread 从 metadata.toolCalls 恢复 | ✅ → 已重构 |
| Task tsc | farm-agent tsc + agrisynapse vue-tsc 编译验证 | ✅ |

### 已完成（Done — 架构重构轮次，2026-06-17）

| Task | 内容 | 状态 |
|------|------|------|
| Task tc-r1 | NodeStreamController 新增 `_traceToolCalls` 静态 Map，与 `_traceEvidence`/`_traceRagResult` 同模式 | ✅ |
| Task tc-r2 | `toolCall()` / `toolResult()` 改为 push 到静态缓存 + emit（与 `evidenceFound()` 一致） | ✅ |
| Task tc-r3 | `collectStreamingTraces()` 新增返回 `toolCalls`，收集后清理 | ✅ |
| Task tc-r4 | stream/route.ts 删除补丁 `toolCallsLog`，registerStreamBus 恢复为纯转发 | ✅ |
| Task tc-r5 | [hash]/route.ts 删除补丁 `toolCallsLog`，registerStreamBus 恢复为纯转发 | ✅ |
| Task tc-r6 | agrisynapse agentChat.ts 从 `metaObj.toolCalls` 改为 `st?.toolCalls`，与 evidence/ragResult 一致 | ✅ |
| Task tc-r7 | farm-agent tsc --noEmit 零错误 | ✅ |

### 待完成（Todo）

```
- [x] Task a6 (工具结果表格 el-table + 暂无数据)
- [x] Task a7 (工具列定义后端声明化，前端解耦 Object.keys)
- [ ] Task a4 (reasoning.ts isRagEmpty) ──→ Task a5 (截图验收)
```

### 新增（2026-06-17 — 交互点选择持久化）

| Task | 内容 | 状态 |
|------|------|------|
| Task ip1 | 交互点选择持久化修复 | ✅ |

#### Task ip1: 交互点选择持久化修复

- **文件**: farm-agent `chat-persistence.ts` / `[hash]/route.ts` / `agent.dto.ts` + agrisynapse `types.ts` / `agentChat.ts` / `LlmChatView.vue`
- **问题**: 交互点选择结果仅作为普通文本消息发送，未持久化到 DB metadata。刷新页面后交互点重新显示为未选状态。
- **架构约束**: 遵循 §七 "Service 层封装所有 DB 操作、route 层零补丁" 原则。`resolveInteractionPoint` 放入 `ChatPersistenceService`。
- **改动**:
  - (a) `ChatPersistenceService.resolveInteractionPoint(threadId, selectedOption)` 新增方法
  - (b) route.ts 调用 Service 而非裸调 prisma
  - (c) 前端 `sendMessage` 新增 `interactionResponse` 参数 + 乐观 UI 更新
  - (d) 前端模板区分已选/未选渲染（高亮 + disabled + 勾号）
  - (e) 前后端 DTO 同步新增 `interactionResponse` 字段
- **数据流**: `handleInteractionSelect → 乐观 UI → POST interactionResponse → Service.update metadata → 刷新恢复`

#### Task a4: reasoning.ts 修复 isSummary expert 的 isRagEmpty 误判

- **文件**: `src/agents/nodes/reasoning.ts`
- **问题**: L186-188 当 `isRagEmpty=true` 时注入 "本轮RAG检索返回 0 条结果，基于模型知识回答，置信度较低"，但对 isSummary expert（依赖工具数据而非 RAG）这是误导
- **改动**: isSummary expert 在工具数据可用时跳过 isRagEmpty 降级提示

#### Task a6: 工具结果表格升级 ✅

- **文件**: agrisynapse `LlmChatView.vue`
- **问题1**: 无数据时 else 分支用 `formatToolResult()` dump 原始 JSON，用户看到大段 `{"success":true,"data":...}`
- **问题2**: 工具结果表格 + 证据链表格使用原生 `<table>`，应该用 `el-table` 与项目 UI 风格统一
- **改动**:
  - (a) ✅ 无数据行时显示 "暂无数据" 友好提示（`#empty` 插槽），不再 dump 原始 JSON
  - (b) ✅ 有数据时替换原生 `<table>` 为 `<el-table>`（项目已引入 Element Plus），自带 empty-text、列宽自适应
  - (c) ✅ 证据链处工具数据表格同步替换为 el-table

#### Task a7: 工具返回列定义标准化

- **文件**: `src/agents/tools/impl/farm-data-tools.ts` + agrisynapse `LlmChatView.vue`
- **问题**: 前端用 `Object.keys(first)` 从数据行提取列名，字段顺序不可控、无中文名、无数据时列名塌缩
- **改动**:
  - (a) ✅ 后端 5 个工具各自声明 `columns: [{prop, label}]` 常量（`ToolColumn` 接口）
  - (b) ✅ 后端新增 `unwrapPageResponse(raw)` 拍扁 farm-server 嵌套为 `{total, list}`
  - (c) ✅ 工具返回格式标准化为 `{success, total, list, columns}`
  - (d) ✅ 前端新增 `getTableColumns(result)` 直接读 `result.columns`（旧版兼容 Object.keys 降级）
  - (e) ✅ 前端新增 `getDataRows(data)` 统一提取表格行数据（用于证据链）
  - (f) ✅ 前端模板 `:prop="col.prop"` / `:label="col.label"` 支持中文列名
  - (g) ✅ 移除前端 `TOOL_FALLBACK_COLS` 常量（列定义权威来源移至后端）

#### Task a5: 截图验收

- 浏览器截图确认完整修复效果

---

## 五、验收标准

- [ ] `npx tsc --noEmit`（farm-agent）零错误
- [x] stream-bus 日志中出现 `tool_call`/`tool_result` 事件
- [ ] 前端深度思考容器中显示工具调用项（"执行中..."→"完成"），含数据表格
- [x] 流式结束后 `msg.toolCalls` 数组持久化到 metadata，刷新页面可恢复
- [ ] 证据条 source 区分 expert vs knowledge（颜色/标签不同）
- [x] `weekly_report` 对话的证据条不再含有通用 knowledge 文档
- [x] 纯闲聊不走 toolNode 时不影响现有行为
- [ ] 无数据时不 dump 原始 JSON，显示 "暂无数据" 友好提示
- [ ] 工具结果表格使用 el-table（非原生 table）

---

## 七、架构重构：工具调用持久化从补丁到统一路径（2026-06-17）

### 7.1 问题发现

原 Task tc-b1/tc-b2 在 route.ts 中用内联 `toolCallsLog` 数组收集工具调用数据：

```typescript
// ❌ 补丁：在 route 层声明临时数组
const toolCallsLog = []
registerStreamBus(traceId, (event) => {
  if (event.type === "tool_call") { toolCallsLog.push(...) }
  // ...
  controller.enqueue(...)
})
```

而同一 trace 的证据条（evidence）和 RAG 结果（ragResult）早已通过 `NodeStreamController` 静态 Map 模式统一收集。`toolCall()` / `toolResult()` 方法只做了 emit，没有做静态缓存收集——导致 route 层不得不自建数组来补。

### 7.2 根因

| 中间态 | NodeStreamController 静态缓存 | emit | 收集 |
|---|---|---|---|
| `evidenceFound` | `_traceEvidence` ✅ | ✅ | `collectStreamingTraces()` |
| `ragResult` | `_traceRagResult` ✅ | ✅ | `collectStreamingTraces()` |
| `toolCall` / `toolResult` | ❌ 无 | ✅ | ❌ route 层补丁 |

### 7.3 修复方案

统一走 `NodeStreamController` 静态缓存 + `collectStreamingTraces()` 路径：

```typescript
// ✅ NodeStreamController 新增
private static _traceToolCalls = new Map<string, Array<{...}>>()

toolCall(toolName, args) {
  push 到 _traceToolCalls  ← 新加
  this.emit(...)            ← 原有
}
toolResult(toolName, result) {
  逆序匹配更新 _traceToolCalls  ← 新加
  this.emit(...)               ← 原有
}
collectStreamingTraces() {
  return { evidence, ragResult, toolCalls }  ← 新增 toolCalls
}
```

### 7.4 数据流统一路径

```
toolCall()/toolResult() → _traceToolCalls (静态 Map)
                                    ↓
                        collectStreamingTraces()
                                    ↓
                        response.ts → streamingTraces.toolCalls
                                    ↓
                        structuredResponse → route.ts → metadata
                                    ↓
                        前端 rehydration: streamingTraces.toolCalls
```

### 7.5 涉及文件

| 文件 | 改动 |
|------|------|
| `src/agents/node-stream-controller.ts` | +`_traceToolCalls` Map, `toolCall/toolResult` 加静态收集, `collectStreamingTraces()` 返回 toolCalls |
| `src/app/api/agent/chat/stream/route.ts` | 删除 `toolCallsLog` 数组, `registerStreamBus` 恢复纯转发, metadata 不再单独合并 |
| `src/app/api/agent/[hash]/route.ts` | 同 stream/route.ts |
| agrisynapse `src/store/modules/agentChat.ts` | `metaObj.toolCalls` → `st?.toolCalls`（与 evidence/ragResult 一致）|

### 7.6 验收

- [x] `npx tsc --noEmit` 零错误
- [ ] 运行时：新请求中 toolCalls 出现在 DB `metadata.streamingTraces.toolCalls` 中
- [ ] 运行时：页面刷新后 toolCalls 可恢复（rehydration 走 streamingTraces.toolCalls）

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| ADD Route | `.qoder/plans/farm-agent-intermediate-streaming-ui-fix-add-route-v1.md` | ✅ 已生成 |
| Handoff | `.qoder/plans/farm-agent-intermediate-streaming-ui-fix-handoff-v1.md` | ✅ 已生成 |
| Review | `.qoder/reviews/farm-agent-intermediate-streaming-ui-fix-review-v1.md` | ✅ 已生成（P0：无，P1：无，可执行） |
