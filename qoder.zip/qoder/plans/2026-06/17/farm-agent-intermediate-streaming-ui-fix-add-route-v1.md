# farm-agent-中间态流式UI修复-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。
>
> **绑定**：Plan: `.qoder/plans/farm-agent-intermediate-streaming-ui-fix-plan-v1.md` · Spec: `.qoder/specs/farm-agent-intermediate-streaming-ui-fix/spec.md` · Tasks: `.qoder/specs/farm-agent-intermediate-streaming-ui-fix/tasks.md` · Checklist: `.qoder/specs/farm-agent-intermediate-streaming-ui-fix/checklist.md` · Handoff: `.qoder/plans/farm-agent-intermediate-streaming-ui-fix-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**输入**：Plan v1 + 截图诊断证据 + 用户确认

**动作**：
1. ✅ Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
2. ✅ `find_related_docs` 已调用（无匹配项目文档，纯路由修复无需架构文档变更）
3. ✅ 无需更新项目文档（理由：本次修复不改变接口合约、数据流或系统架构，仅补齐已有设计中的 SSE 事件缺口 + 纠正 retrieval 路由）
4. ⬜ Handoff 待 Task 完成后生成

**产出**：
- [x] Specs 三元组路径确认
- [x] 项目文档无需更新（已声明理由）
- [ ] Handoff 待生成

---

## Step 1：功能分析与审计阶段定义

**新增 Phase**：`EXPERT_SKIPPED`（isSummary expert 跳过 RAG 时记录）

| Phase | 使用场景 | Task |
|-------|---------|------|
| `STREAM_BUS_EMIT_TOOL_CALL` | stream-bus 推送 tool_call 事件 | Task 1 |
| `STREAM_BUS_EMIT_TOOL_RESULT` | stream-bus 推送 tool_result 事件 | Task 1 |
| `EXPERT_SKIPPED` | isSummary expert 跳过 RAG 检索 | Task 3 |
| `PERSIST_INTERACTION` | 交互点选择落库 | Task ip1 |

---

## Step 2：审计基础设施确认

- `agentAudit` 三通道可用 ✅
- `stream-bus` `resolveAuditPhase` 待扩展 `tool_call` / `tool_result` 分支 ✅

---

## Step 3：业务逻辑实现与审计植入

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | stream-bus 新增类型 | `src/agents/stream-bus.ts` | resolveAuditPhase → `tool_call`, `tool_result` | 无（expand） | 无 | ✅ |
| 2 | NodeStreamController 新增方法 | `src/agents/node-stream-controller.ts` | 无（纯 emit） | — | 无 | ✅ |
| 3 | retrieval isSummary 跳过 | `src/agents/nodes/retrieval.ts` | `agentAudit("EXPERT_SKIPPED", ...)` | `EXPERT_SKIPPED` | 无 | ✅ |
| 4 | 前端 evidence-bar source 区分 | agrisynapse `LlmChatView.vue` | 无（纯 UI） | — | 无 | ⬜ |
| 5 | tsc 编译验证 | — | — | — | Task 1-4 | ✅ |
| a2 | 前端工具渲染辅助函数 | agrisynapse `LlmChatView.vue` | 无（纯 UI） | — | 无 | ✅ |
| tc-b1 | route.ts toolCallsLog 持久化 | `src/app/api/agent/[hash]/route.ts` | 无（闭包收集） | — | 无 | ✅ |
| tc-b2 | agentChat.ts loadThread 恢复 | agrisynapse `agentChat.ts` | 无（纯前端） | — | tc-b1 | ✅ |
| a4 | reasoning.ts isRagEmpty 误判 | `src/agents/nodes/reasoning.ts` | 无（prompt 修复） | — | 无 | ⬜ |
| a6 | 工具结果 el-table + 无数据提示 | agrisynapse `LlmChatView.vue` | 无（纯 UI） | — | a2 | ⬜ |
| ip1 | 交互点选择持久化修复 | `chat-persistence.ts` + `[hash]/route.ts` + agrisynapse 3 文件 | `chatPersistAudit("MESSAGE_SAVE_CHUNK", ...)` + `agentGatewayAudit` | `PERSIST_INTERACTION` | 无 | ✅ |

### 依赖拓扑

```
已完成: Task 1 ── Task 2 ── Task 3 ── Task 5 ── tc-b1 ── tc-b2 ── a2 ── Task tsc ✅
待完成: Task a4 ── Task a6 ── Task a5 (截图验收)
         Task 4 (evidence-bar source 区分) ── Task a5
         Task ip1 (交互点选择持久化) ── 独立链路，无依赖
```

---

## Step 3.5：实现审查

待 Task 1-4 完成后执行。

---

## Step 4：审计数据验证

待 Task 5 完成后执行。

---

## Step 5：AI 自动合规检查

待 Task 5 完成后执行。

---

## Step 8：收敛判断 + Handoff 更新

待全部 Task 完成 + checklist 勾选后执行。

---

## 原子闭包判定

### 逐组业务价值判定

- Task Group A (Task 1-3 + retrieval.ts): 补齐 tool_call SSE + 纠正 RAG 路由 → **已完成交付**
- Task Group B (tc-b1 + tc-b2 + a2): toolCalls 持久化 + 前端渲染 → **已完成交付**
- Task Group C (a4 + a6): reasoning isRagEmpty 误判修复 + el-table 升级 → **下一轮交付**
- Task Group D (ip1): 交互点选择持久化 → **本交付**

### 判定结论

已完成 1 个原子闭包（流式中间态 tool_call SSE + 持久化 + 前端渲染）。
剩余 1 个原子闭包：Task a4（reasoning.ts 误判）+ Task a6（el-table 升级）。
新增 1 个原子闭包：Task ip1（交互点选择持久化）— 独立链路，无依赖，可单独交付。

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/agents/stream-bus.ts` | MODIFY | 1 | TYPE_DEFINITION | ✅ |
| `src/agents/node-stream-controller.ts` | MODIFY | 2 | CONTROLLER | ✅ |
| `src/agents/nodes/retrieval.ts` | MODIFY | 3 | NODE | ✅ |
| `src/agents/index.ts` | MODIFY | 3 | NODE | ✅ |
| `src/app/api/agent/[hash]/route.ts` | MODIFY | tc-b1 | ROUTE | ✅ |
| `src/lib/stream-bus-logger.ts` | MODIFY | 1 | UTILITY | ✅ |
| `src/lib/agent-audit-logger.ts` | MODIFY | 3 | UTILITY | ✅ |
| agrisynapse `LlmChatView.vue` | MODIFY | a2+a6 | COMPONENT | a2✅ a6⬜ |
| agrisynapse `agentChat.ts` | MODIFY | tc-b2 | STORE | ✅ |
| `src/agents/nodes/reasoning.ts` | MODIFY | a4 | NODE | ⬜ |
| `src/services/chat-persistence.ts` | MODIFY | ip1 | SERVICE | ✅ |
| `src/dto/agent.dto.ts` | MODIFY | ip1 | DTO | ✅ |
| agrisynapse `types.ts` | MODIFY | ip1 | DTO | ✅ |
