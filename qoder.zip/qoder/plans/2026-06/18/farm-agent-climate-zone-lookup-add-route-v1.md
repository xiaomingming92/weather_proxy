# farm-agent-climate-zone-lookup-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节。
> **模式**：重型（Heavyweight）
> **绑定**：Plan: `farm-agent-climate-zone-lookup-plan-v1.md` · Spec: `farm-agent-climate-zone-lookup/spec.md` · Tasks: `farm-agent-climate-zone-lookup/tasks.md` · Handoff: `farm-agent-climate-zone-lookup-handoff-v1.md`

---

## 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: farm-agent 支持离线气候带查询——输入坐标 → 返回柯本-盖格气候带代码 + 中国农业属性

Task Groups:
  Group A (Phase 1-2: 数据准备+网格生成): 元数据JSON + 网格数据JSON
  Group B (Phase 3-5: 工具实现+注册+验证): Schema + 查表引擎 + 工具注册 + 编译验证

逐组业务价值判定:
  Group A (数据准备): 不能用 — 仅有 JSON 数据文件，没有工具调用入口，用户无感知
  Group B (工具实现): 不能用 — 仅有工具代码，没有数据文件则查表引擎无法工作
  → 两个 Group 必须合并才能产生完整业务价值

判定结论: 需要 1 轮（1 个原子闭包）

第1轮（原子闭包1）: Task Groups A + B — 业务功能: 离线气候带查询完整功能
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## Step 0：文档先行（Documentation First）

**输入**：
- Plan: `farm-agent-climate-zone-lookup-plan-v1.md`（Review 已完成并回流）
- Review: `farm-agent-climate-zone-lookup-review-v1.md`

**动作**：
1. ✅ Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
2. ✅ `find_related_docs` 检索完成，无相关项目文档需更新（新工具，不涉及现有架构变更）
3. ✅ Plan Review 已完成，P1-1/P1-2/P2-1 已回流至 Plan §7
4. ✅ 原子闭包判定：单轮（1 个原子闭包），handoff 使用 single-round 模板

**产出**：
- [x] 验证并更新项目状态：Specs 三元组路径确认 → `.qoder/specs/farm-agent-climate-zone-lookup/`
- [x] 验证并更新项目状态：项目文档无需更新（新工具，加法型变更）
- [ ] 验证并更新项目状态：Handoff 就绪（待 Step 8 生成）

### §0.8 DPS 闸门

调用 `check_dps({ planKeyword: "climate-zone" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |
| 70–84 | 🟡 | 回退补齐短板 |
| < 70 | 🔴 | 回退细化 Plan |

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**动作**：
1. 新增审计阶段：`CLIMATE_ZONE_LOOKUP`（气候带查表）+ `CLIMATE_ZONE_METADATA`（元数据匹配）

**产出**：
- [ ] 验证并更新项目状态：本次审计阶段清单已同步到 tasks.md Step 1 区域

| Phase | 使用场景 | Task |
|-------|---------|------|
| `CLIMATE_ZONE_LOOKUP` | 网格查表 + 结果返回 | Task 3.2 |
| `CLIMATE_ZONE_METADATA` | 元数据匹配 + 属性查询 | Task 3.2 |

---

## Step 2：审计基础设施确认

**动作**：
1. 确认 `agentAudit("CLIMATE_ZONE_LOOKUP", ...)` + `writeAuditLog(...)` 可用
2. 确认 `agent-audit-logger.ts` 中 `AgentAuditPhase` 已扩展

**产出**：
- [ ] 验证并更新项目状态：`agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

### §3.0 前置守卫

调用 `check_add_route_status` 确认 add-route 有效存在。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1.1 | 气候带元数据 | `src/data/climate-zones/climate-zone-metadata.json` | 无（数据文件） | — | 无 | ⬜ |
| 1.2 | 网格生成脚本 | `scripts/generate-climate-grid.py` | 无（脚本） | — | 无 | ⬜ |
| 2.1 | 生成网格 JSON | `src/data/climate-zones/china-koppen-grid.json` | 无（数据文件） | — | Task 1.1, 1.2 | ⬜ |
| 3.1 | Zod Schema | `src/agents/tools/schemas/climate-zone-tools.ts` | 无（类型定义） | — | Task 1.1 | ⬜ |
| 3.2 | 查表引擎 | `src/agents/tools/impl/climate-zone-tools.ts` | `agentAudit("CLIMATE_ZONE_LOOKUP")` + `writeAuditLog` | `CLIMATE_ZONE_LOOKUP`, `CLIMATE_ZONE_METADATA` | Task 2.1, 3.1 | ⬜ |
| 3.2a| 坐标工具提取 | `src/agents/tools/utils/coordinate-utils.ts` | 无（工具函数） | — | 无 | ⬜ |
| 4.1 | 工具注册 | `src/agents/tools/index.ts` | 无（import + 数组追加） | — | Task 3.2 | ⬜ |
| 5.1 | 编译验证 | 全部文件 | `npx tsc --noEmit` | — | Task 4.1 | ⬜ |
| 5.2 | 回归验证 | `src/agents/tools/impl/weather-tools.ts` | 天气工具功能正常 | — | Task 3.2a | ⬜ |

### 依赖拓扑

```
Task 1.1 ──┐
           ├──→ Task 2.1 ──→ Task 3.2 ──→ Task 4.1 ──→ Task 5.1
Task 1.2 ──┘                    │                         │
                                │                   Task 5.2
Task 3.1 ───────────────────────┘
Task 3.2a ──────────────────────────────────────────→ Task 5.2
```

**产出**：
- [ ] 验证并更新项目状态：全部 Task 的 checklist 项通过
- [ ] 验证并更新项目状态：每个文件有 `record_dev_operation` 记录
- [ ] 验证并更新项目状态：`check_spec_sync` 通过

---

## Step 3.5：实现审查

**产出**：
- [ ] 验证并更新项目状态：`checklist.md` 全部 `[T]` 项通过并勾选
- [ ] 验证并更新项目状态：`review-implementation.md` 已生成
- [ ] 验证并更新项目状态：`review-runtime.md` 已生成

---

## Step 4：审计数据验证

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "climate-zone" })`。

| RAHS | 判定 | 动作 |
|------|:--:|------|
| ≥ 90 | 🟢 | 进入 Step 5 |

- [ ] RAHS 已通过（≥ 90），可进入 Step 5

---

## Step 5：AI 自动合规检查

- [ ] 验证并更新项目状态：合规报告已生成

---

## Step 8：收敛判断 + Handoff 更新

- [ ] 验证并更新项目状态：收敛判定结果
- [ ] 验证并更新项目状态：Handoff 已生成并更新

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/data/climate-zones/climate-zone-metadata.json` | CREATE | 1.1 | DATA | ⬜ |
| `scripts/generate-climate-grid.py` | CREATE | 1.2 | SCRIPT | ⬜ |
| `src/data/climate-zones/china-koppen-grid.json` | CREATE | 2.1 | DATA | ⬜ |
| `src/agents/tools/schemas/climate-zone-tools.ts` | CREATE | 3.1 | COMPONENT | ⬜ |
| `src/agents/tools/impl/climate-zone-tools.ts` | CREATE | 3.2 | COMPONENT | ⬜ |
| `src/agents/tools/utils/coordinate-utils.ts` | CREATE | 3.2a | COMPONENT | ⬜ |
| `src/agents/tools/impl/weather-tools.ts` | MODIFY | 3.2a | COMPONENT | ⬜ |
| `src/agents/tools/index.ts` | MODIFY | 4.1 | COMPONENT | ⬜ |
| `src/lib/agent-audit-logger.ts` | MODIFY | 1(Step1) | COMPONENT | ⬜ |
