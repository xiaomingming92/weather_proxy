# farm-agent-climate-zone-lookup-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度（文件路径 + Phase 验收标准 + 架构维度全覆盖）。**不要**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-climate-zone-lookup-v1
- **启动时间**: 2026-06-18T14:00:00+08:00
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/farm-agent-climate-zone-lookup-add-route-v1.md`
  - Handoff: `.qoder/plans/farm-agent-climate-zone-lookup-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-climate-zone-lookup-review-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/agents/tools/impl/climate-zone-tools.ts | COMPONENT | COMPONENT_CREATED | 无气候带查询工具 | 新增 query_climate_zone 工具实现 | 待实施 |
| src/agents/tools/schemas/climate-zone-tools.ts | COMPONENT | COMPONENT_CREATED | 无气候带 Schema | 新增 ClimateZoneSchema (Zod) | 待实施 |
| src/agents/tools/index.ts | COMPONENT | COMPONENT_MODIFIED | 工具列表无 climate_zone | 注册 query_climate_zone 到 agentTools | 待实施 |
| src/data/climate-zones/china-koppen-grid.json | DATA | DATA_CREATED | 无气候带栅格数据 | 中国 ~10km 柯本-盖格网格 JSON（约 2-3MB） | 待实施 |
| src/data/climate-zones/climate-zone-metadata.json | DATA | DATA_CREATED | 无气候带属性元数据 | 30 种柯本类型 + 中国农业属性 JSON | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

farm-agent 的 `weather-tools` 已支持天地图坐标查询天气（含 WGS-84 → GCJ-02 转换），但**缺乏气候带层面的宏观认知**：

- Agent 知道"今天 28°C 下雨"，但不知道"这个地块属于亚热带季风气候（Cfa）"
- 缺乏气候带信息导致专家在做**品种推荐、种植制度规划、积温带判定**时缺少气候背景上下文
- 和风天气历史数据 API 价格高昂（无免费额度），不适合从原始气象数据实时计算柯本分类

### 1.2 目标

为 farm-agent 增加**离线气候带查询能力**：

1. **柯本-盖格气候分类**：输入坐标 → 返回 Köppen-Geiger 气候带代码（如 Cwa、Dwa）
2. **中国农业气候属性**：积温带、干湿区、无霜期、适宜作物等农业决策属性
3. **与现有天气工具协同**：复用 weather-tools 的天地图坐标解析 + WGS-84→GCJ-02 转换链路
4. **纯离线查表**：无外部 API 依赖，JSON 数据文件 ~2-3MB，加载后内存常驻

---

## 二、方案选型

### 2.1 候选方案对比

| 方案 | 精度 | 离线可用 | 外部依赖 | 数据量 | 结论 |
|------|------|---------|---------|-------|------|
| A: GeoTIFF 栅格查表（1km） | 1km | 需 GeoTIFF 解析库 | `geotiff.js` 依赖 | ~100-200MB（中国区） | ❌ 依赖重、部署复杂 |
| B: 在线 API（MAPresso Climate API） | 高 | 否 | 外部 HTTP 服务 | 无 | ❌ 无 SLA、不可靠 |
| **C: 简化查表法（预处理网格 JSON）** | ~10km | 是 | 零 | ~2-3MB | ✅ 最佳平衡 |
| D: 从气象数据实时计算柯本分类 | 取决于气象站密度 | 否 | 和风天气历史 API（贵） | 无 | ❌ 成本过高 |

### 2.2 选型理由

采用方案 C：**预处理的 ~10km 分辨率网格化 JSON 查表**。

- **零外部依赖**：纯 JSON 文件，Next.js 进程内加载，farm-agent 弱网环境可用
- **数据源可靠**：从 Beck et al. (2023) 柯本-盖格 1km 栅格数据采样降采样，CC BY 4.0 授权
- **精度足够**：~10km 网格对农业地块尺度（通常 > 100 亩 ≈ 0.07 km²）完全足够
- **农业增强**：在柯本分类基础上叠加中国积温带、农业气候区划属性

---

## 三、架构设计

### 3.1 数据模型

```
china-koppen-grid.json（网格数据）
├── resolution: 0.1           // 约 10km 网格间距
├── bounds: { minLng, maxLng, minLat, maxLat }
├── grid: number[]            // 扁平化数组，每行从西到东、从南到北
│                              // 值为柯本分类代码编号 (1-30)
│                              // 0 = 水域/无效

climate-zone-metadata.json（属性元数据）
├── zones: Record<code, ClimateZoneMeta>
│   ├── code: "Cwa"           // 柯本代码
│   ├── name: "暖温带季风气候"
│   ├── category: "C"         // 主类（A/B/C/D/E）
│   ├── properties:
│   │   ├── avgTempRange      // 年均温范围
│   │   ├── annualPrecip      // 年降水量范围
│   │   ├── growingSeason     // 生长季天数
│   │   ├── accumulatedTemp   // ≥10°C 积温
│   │   ├── frostFreeDays     // 无霜期
│   │   ├── aridityIndex      // 干湿区
│   │   ├── suitableCrops     // 适宜作物列表
│   │   └── farmingSystem     // 种植制度（一年一熟/两熟等）
│   └── description           // 气候带描述文本
```

### 3.2 模块分布

```
farm-agent (Next.js 后端)
├── src/data/climate-zones/
│   ├── china-koppen-grid.json      → ~10km 网格数据（生成脚本产出）
│   └── climate-zone-metadata.json  → 30 种柯本类型 + 农业属性
├── src/agents/tools/schemas/
│   └── climate-zone-tools.ts       → Zod Schema 定义
├── src/agents/tools/impl/
│   └── climate-zone-tools.ts       → 查表引擎 + Agent 工具
├── src/agents/tools/index.ts       → 注册 query_climate_zone
└── scripts/
    └── generate-climate-grid.ts    → 从公开栅格数据生成网格 JSON（一次性）
```

### 3.3 数据流

```
[Agent 推理] 任意专家 / 决策层
     │ tool_call: query_climate_zone({ location: "119.5,32.5;119.6,32.6;..." })
     ▼
[climate-zone-tools.ts] resolveWeatherLocation()  ← 复用 weather-tools 坐标解析
     │ WGS-84 → GCJ-02（坐标转换）
     │ 注意：气候带查表用 WGS-84 原始坐标（非 GCJ-02）
     ▼
[china-koppen-grid.json] 最近邻网格查找
     │ lng/lat → 网格索引 → 柯本代码编号
     ▼
[climate-zone-metadata.json] 属性查询
     │ 代码编号 → ClimateZoneMeta（气候带名称 + 农业属性）
     ▼
[返回] { code, name, category, properties, wgs84 }
```

> **关键决策**：气候带查表使用 **WGS-84 原始坐标**（天地图坐标系），不走 GCJ-02 转换。
> 原因：柯本-盖格栅格数据基于真实地理坐标（WGS-84），GCJ-02 是火星坐标，偏移 ~500m 反而降低精度。
> 只有调用和风天气 API 时才需要 GCJ-02。

---

## 四、实施步骤 + 依赖图

```
Task 1.1: 气候带元数据 ──┐
                          │ 可并行
Task 1.2: 网格生成脚本 ──┘
                          │
                          ▼
Task 2.1: 生成网格 JSON 数据
                          │
                          ▼
Task 3.1: Zod Schema ──┐
                        │ 可并行
Task 3.2: 查表引擎 ────┘
                        │
                        ▼
Task 4.1: 工具注册
                        │
                        ▼
Task 5.1: 编译 + 验证
```

### Phase 1: 数据准备

- [ ] Task 1.1: `src/data/climate-zones/climate-zone-metadata.json` — 手工编制 30 种柯本-盖格气候类型的中国农业属性元数据
  - 验收: JSON 格式正确，覆盖中国常见气候带（Bwk、Cwa、Cfa、Dwa、Dwb 等）≥ 15 种
- [ ] Task 1.2: `scripts/generate-climate-grid.ts` — 从公开柯本-盖格栅格数据（Beck et al. 2023 / kgcpy 内置数据）采样降采样，生成中国区 ~0.1° 网格 JSON
  - 验收: 脚本可执行，输出 `china-koppen-grid.json`

### Phase 2: 网格数据生成

- [ ] Task 2.1: 执行网格生成脚本 → 生成 `src/data/climate-zones/china-koppen-grid.json`
  - **前置条件**: Python 3.8+ 已安装，`pip install kgcpy` 完成
  - 验收: JSON 文件大小 ≤ 5MB，`resolution` 字段 = 0.1，`grid` 数组长度 ≈ 行数 × 列数
  - 抽样验证: 北京(116.4,39.9)→Dwa、广州(113.3,23.1)→Cfa、拉萨(91.1,29.7)→Cwb、乌鲁木齐(87.6,43.8)→Bwk

### Phase 3: 工具实现

- [ ] Task 3.1: `src/agents/tools/schemas/climate-zone-tools.ts` — Zod Schema，location 参数描述复用 weather-tools 的三种格式
  - 验收: tsc 通过，Schema 可被 tool() 正确消费
- [ ] Task 3.2: `src/agents/tools/impl/climate-zone-tools.ts` — 查表引擎核心逻辑：
  - 从 weather-tools 提取/复用 `parseTiandituPath`、`calcCentroid`、`detectLocationType`（坐标解析部分）
  - **提取前** grep 全项目确认无其他文件直接 import weather-tools 中的这三个函数
  - 网格最近邻查找：`(lng - minLng) / resolution` → 列索引，`(lat - minLat) / resolution` → 行索引
  - 边界检查：坐标超出中国区范围时返回友好错误
  - 审计日志：同时调用 `agentAudit` + `writeAuditLog` 记录查表过程（坐标、网格索引、结果代码），与 weather-tools 审计模式一致
  - 验收: 单测 3 个以上坐标点返回正确气候带

### Phase 4: 注册与集成

- [ ] Task 4.1: `src/agents/tools/index.ts` — 注册 `queryClimateZoneTool` 到 `agentTools` 数组
  - 验收: tsc 通过，工具在 agentTools 数组中可见

### Phase 5: 编译验证

- [ ] Task 5.1: `npm run build` / `npx tsc --noEmit` 编译通过
  - 验收: 零编译错误
- [ ] Task 5.2: weather-tools 回归验证 — 确认坐标解析重构未破坏现有天气查询功能
  - 验收: weather-tools 的 query_weather_realtime / query_weather_forecast 功能正常
- [ ] Task 5.3: 端到端验证 — 通过 Agent 对话触发气候带查询，确认 tool_call + 返回数据完整
  - 验收: Agent 对话中可正确返回地块气候带信息

---

## 五、验收标准

### Phase 1: 数据准备
- [ ] `climate-zone-metadata.json` 覆盖中国常见柯本类型 ≥ 15 种
- [ ] 每种类型包含：code、name、category、avgTempRange、annualPrecip、growingSeason、accumulatedTemp、frostFreeDays、aridityIndex、suitableCrops、farmingSystem
- [ ] `generate-climate-grid.ts` 脚本可执行

### Phase 2: 网格数据
- [ ] `china-koppen-grid.json` 文件存在且 ≤ 5MB
- [ ] 网格 resolution = 0.1（约 10km）
- [ ] 抽样验证通过（北京→Dwa、广州→Cfa、拉萨→Cwb、乌鲁木齐→Bwk）

### Phase 3: 工具实现
- [ ] `query_climate_zone` 工具接受天地图坐标格式（城市名 / 单点 / 多边形路径）
- [ ] 多边形路径自动计算质心后查表
- [ ] 返回结果包含：code、name、category、properties 全属性
- [ ] 坐标超出中国区范围时返回友好错误而非崩溃

### Phase 4: 注册与集成
- [ ] `agentTools` 数组包含 `query_climate_zone`
- [ ] `npx tsc --noEmit` 零错误

### Phase 5: 端到端
- [ ] Agent 对话中可自然触发气候带查询
- [ ] 审计日志记录了查表过程

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/farm-agent-climate-zone-lookup-add-route-v1.md` |
| Handoff | `.qoder/plans/farm-agent-climate-zone-lookup-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-climate-zone-lookup-review-v1.md` |
| Spec | `.qoder/specs/farm-agent-climate-zone-lookup/spec.md` |
| Tasks | `.qoder/specs/farm-agent-climate-zone-lookup/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-climate-zone-lookup/checklist.md` |

---

## 七、Review 回流记录（0.6.5 卡位）

> Review: `.qoder/reviews/farm-agent-climate-zone-lookup-review-v1.md`
> 结论: 0 P0 + 2 P1 + 1 P2，方向正确，修正后可直接进入实施

| Review 问题 | 严重程度 | 回流位置 | 回流方式 |
|------------|---------|---------|---------|
| P1-1: 网格数据生成依赖外部 Python/GDAL 工具链 | P1 | §8.3 补充数据生成命令 + Phase 2 验收增加 Python 前置条件 | 已在 §8.3 和 §五 Phase 2 更新 |
| P1-2: 坐标工具提取改动 weather-tools import 路径，回归风险 | P1 | §四 Phase 3 Task 3.2 增加 grep 确认 + Phase 5 增加回归验证 | 已在 Task 3.2 和 §五 Phase 5 更新 |
| P2-1: 审计日志建议补充 DB 持久化（writeAuditLog） | P2 | §四 Phase 3 Task 3.2 审计日志要求明确 writeAuditLog | 已在 Task 3.2 审计日志描述中更新 |

---

## 八、设计决策备注

### 8.1 坐标解析复用 vs 提取

weather-tools.ts 中的 `parseTiandituPath`、`calcCentroid`、`detectLocationType` 三个函数需要在 climate-zone-tools.ts 中复用。两种方案：

| 方案 | 优点 | 缺点 |
|------|------|------|
| A: 提取到 `src/agents/tools/utils/coordinate-utils.ts` | DRY、清晰 | 改动 weather-tools 引用路径 |
| B: 在 climate-zone-tools 中直接重新 import | 零改动 weather-tools | 轻微重复 |

**建议采用 A**：提取公共坐标工具函数，同时更新 weather-tools 的 import 路径。改动量小，收益明确。

### 8.2 气候带查表不走 GCJ-02

柯本-盖格栅格数据基于 WGS-84 真实地理坐标，GCJ-02 偏移 ~500m 会降低查表精度。
因此 `query_climate_zone` 工具：
- 复用坐标解析（parseTiandituPath / calcCentroid / detectLocationType）
- **不调用** `wgs84ToGcj02`，直接使用 WGS-84 坐标查表

### 8.3 网格数据生成来源

优先级：
1. **kgcpy (PyPI)**：Python 包，内置 ~100 arc-sec 分辨率栅格，可用 Python 脚本采样导出
   - 前置条件：`pip install kgcpy`，Python ≥ 3.8
   - 导出命令：`python3 scripts/generate-climate-grid.py --region china --resolution 0.1 --output src/data/climate-zones/china-koppen-grid.json`
2. **GloH2O (gloh2o.org/koppen)**：1km GeoTIFF，CC BY 4.0，可用 GDAL 采样
3. **手工编制**：基于维基百科柯本-盖格中国区分布图，人工标注代表性网格点（精度最差，兜底方案）
