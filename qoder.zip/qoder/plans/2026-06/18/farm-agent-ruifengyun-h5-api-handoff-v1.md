# farm-agent — 瑞丰耘H5对接 交接手册

> **适用场景**：单轮变更（含 2 个原子闭包），为 H5 前端提供完整的 AI 能力接入。
>
> **绑定**：Plan: `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v1.md` · Spec: `.qoder/specs/farm-agent-ruifengyun-h5-api/spec.md` · Tasks: `.qoder/specs/farm-agent-ruifengyun-h5-api/tasks.md` · add-route: `.qoder/plans/farm-agent-ruifengyun-h5-api-add-route-v1.md`

---

## 1. 交接前状态

- farm-agent 仅有 agrisynapse 对接的 SSE 流式 agent 能力（`/api/agent/[hash]`）
- 无独立 REST API 端点，无 H5 握手机制
- token 管理硬编码绑定 Farm-Server（无 source 区分）
- 11 个专家（无 land_analysis / variety_recommend）
- 裁决策略仅 agrisynapse 专用（auth-gateway.ts / agrisynapse-handshake.ts）

---

## 2. 交接后状态（目标）

- H5 可通过 `/api/h5/handshake` 握手获取 sessionId
- H5 可通过 `/api/h5/agent` 进行 SSE 流式聊天（智慧农业助手）
- H5 可通过 3 个 REST API 获取新增生产计划的 AI 能力：
  - `/api/h5/land-analysis` — 地块分析
  - `/api/h5/variety-recommend` — 品种推荐
  - `/api/h5/cost-accounting` — 成本核算
- token 管理支持多端隔离（source="h5" vs source="agrisynapse"）
- 14 个专家（新增 land_analysis + variety_recommend + cost_accounting）
- 4 个裁决策略（新增 h5-auth-gateway.ts + h5-handshake-thread.ts）

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `prisma/schema.prisma` | 修改 | 新增 H5Session 模型 + farmServerCredential 加 source 字段 |
| 2 | `src/lib/auth/credential-store.ts` | 修改 | 所有函数加 source 参数，(userId,source) 复合唯一 |
| 3 | `src/lib/auth/token-manager.ts` | 修改 | RequestSource 加 "h5"，tryRefreshToken 按 source 路由 |
| 4 | `src/caijuehub/strategies/h5-auth-gateway.ts` | 新建 | sessionId → userId 认证裁决 |
| 5 | `src/caijuehub/strategies/h5-handshake-thread.ts` | 新建 | H5 线程 new/resume 裁决 |
| 6 | `src/app/api/h5/handshake/route.ts` | 新建 | H5 握手端点 |
| 7 | `src/app/api/h5/agent/route.ts` | 新建 | H5 SSE 流式聊天端点 |
| 8 | `src/agents/prompts/experts/land-analysis.ts` | 新建 | 地块分析专家 prompt（H5轻量，含传感器佐证语义） |
| 9 | `src/agents/reports/land-analysis.template.ts` | 新建 | 地块分析报告模板 |
| 10 | `src/agents/prompts/experts/variety-recommend.ts` | 新建 | 品种推荐专家 prompt（H5轻量，支持 search_web_cn） |
| 11 | `src/agents/reports/variety-recommend.template.ts` | 新建 | 品种推荐报告模板 |
| 12 | `src/agents/prompts/experts/cost-accounting.ts` | 新建 | 成本核算专家 prompt（H5轻量，支持 search_web_cn/global） |
| 13 | `src/agents/tools/impl/web-search.ts` | 新建 | WebSearch 双工具实现（Baidu/Bing/Google/DuckDuckGo + 降级链） |
| 14 | `src/agents/tools/schemas/web-search.ts` | 新建 | WebSearch 工具 Schema（engine/proxy/maxResults） |
| 15 | `src/lib/farm-api/massif.ts` | 新建 | Farm-Server 地块 API 封装（getById 含 projectId 必填） |
| 16 | `src/lib/farm-api/client.ts` | 新建 | Farm-Server HTTP 客户端（集中 token 管理） |
| 17 | `src/agents/prompts/experts/index.ts` | 修改 | 注册 3 个新 prompt（land_analysis + variety_recommend + cost_accounting） |
| 18 | `src/agents/experts/registry.ts` | 修改 | 新增 2 个专家 + 学科映射（land_analysis / variety_recommend） |
| 19 | `src/lib/agent-audit-logger.ts` | 修改 | 新增 6 个审计阶段（H5_AUTH_GATEWAY / H5_HANDSHAKE / H5_AGENT_CHAT / H5_LAND_ANALYSIS / H5_VARIETY_RECOMMEND / H5_COST_ACCOUNTING） |
| 20 | `src/app/api/h5/land-analysis/route.ts` | 新建 | 地块分析 REST API（projectId 必填 + 传感器预取 + setAuditContext/agentAudit） |
| 21 | `src/app/api/h5/variety-recommend/route.ts` | 新建 | 品种推荐 REST API（Prisma 直查种子库 + LangChain Tool Calling + data_confidence 降级） |
| 22 | `src/app/api/h5/cost-accounting/route.ts` | 新建 | 成本核算 REST API（LangChain Tool Calling + setAuditContext/agentAudit） |

---

## 4. 回滚方案

### 代码回滚

```bash
git reset --hard <pre-h5-commit>
```

### 数据回滚

```bash
npx prisma migrate reset  # 仅开发环境
# 生产环境：ALTER TABLE "farmServerCredential" DROP COLUMN "source"; DROP TABLE "H5Session";
```

---

## 5. 执行前置检查

- [x] Plan Review 已完成且全部 P0/P1/P2 问题已回流
- [x] `npx tsc --noEmit` 当前无错误
- [x] PostgreSQL 可用，Prisma 可连接
- [x] 环境变量 `H5_SERVER_BASE_URL` 已配置
- [N/A] ChromaDB 可用（Route A 不需要 Grounding collection）

---

## 6. 执行步骤摘要

```
第1轮（原子闭包1）: H5 基础设施
───────────────────────────────
Task 0: credential-store source 改造
  │
  ├──→ Task 0.1: token-manager source 路由
  │       │
  │       └──→ Task 0.4: /api/h5/handshake
  │
  ├──→ Task 0.2: h5-auth-gateway ──┐
  │                                 ├──→ Task 0.5: /api/h5/agent
  └──→ Task 0.3: h5-handshake-thread┘
                  │
                  ▼
            第1轮完成：握手+聊天可用+token隔离

第2轮（原子闭包2）: 专家 + REST API
───────────────────────────────────
Task 1/2/3/4: prompts + templates（可并行）
  │
  └──→ Task 5: index.ts 注册
         │
         └──→ Task 6: registry.ts 注册
                │
Task 7: agent-audit-logger.ts（可并行）
                │
                ├──→ Task 8: /api/h5/land-analysis ──┐
                ├──→ Task 9: /api/h5/variety-recommend ─┤ 可并行
                └──→ Task 10: /api/h5/cost-accounting ──┘
                          │
                          ├──→ Task 11: Grounding collection
                          ├──→ Task 12: Grounding collection
                          │
                          └──→ Task 13: tsc --noEmit
                                 │
                                 └──→ Task 14: curl 端到端验证
                                            │
                                            ▼
                                      第2轮完成：AI能力全部可用
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| credential-store source 改造破坏 agrisynapse token 管理 | agrisynapse 握手/刷新失败 | 所有现有调用方显式传 `source: "agrisynapse"`，编译期+curl 双验证 |
| H5 userId 与 agrisynapse userId 碰撞 | chatThread 表数据混乱 | h5-handshake-thread.ts 独立处理，userId 来自不同 sessionId 体系 |
| 直调 LLM（路线 A）输出格式不稳定 | H5 前端 JSON 解析失败 | prompt 注入目标 schema 约束 + API 层 schema 校验 + 缺失补 null |
| query_seed_catalog 无数据 | 品种推荐返回空 | 降级为 LLM 基于 KB 推理，输出标记 data_confidence: "low" |

---

## 8. 恢复上下文审计查询

> **给后续 AI 助手**：以下 `query_audit_logs(...)` 可恢复完整开发上下文。

### 总体一键恢复

```text
query_audit_logs({ keyword: "h5" })
```
→ 预期返回 20+ 条记录（含文档+源码，另有 ~9 条不含 h5 关键字，全量 ~29 条）

### 逐模块审计查询

```text
# 认证/Token 层
query_audit_logs({ targetId: "src/lib/auth/credential-store.ts" })
→ CREDENTIAL_SAVE/READ/REFRESH: source 参数扩展

query_audit_logs({ targetId: "src/lib/auth/token-manager.ts" })
→ RequestSource 加 h5，tryRefreshToken 按 source 路由

# 裁决层
query_audit_logs({ targetId: "src/caijuehub/strategies/h5-auth-gateway.ts" })
→ sessionId→userId 认证裁决

query_audit_logs({ targetId: "src/caijuehub/strategies/h5-handshake-thread.ts" })
→ H5 线程 new/resume 裁决

# API 路由
query_audit_logs({ targetId: "src/app/api/h5/handshake/route.ts" })
→ H5_HANDSHAKE: 握手端点创建

query_audit_logs({ targetId: "src/app/api/h5/agent/route.ts" })
→ H5_AGENT_CHAT: SSE 流式聊天端点创建

query_audit_logs({ targetId: "src/app/api/h5/land-analysis/route.ts" })
→ H5_LAND_ANALYSIS: setAuditContext+4agentAudit+clearAuditContext

query_audit_logs({ targetId: "src/app/api/h5/variety-recommend/route.ts" })
→ H5_VARIETY_RECOMMEND: 审计+data_confidence 降级注入

query_audit_logs({ targetId: "src/app/api/h5/cost-accounting/route.ts" })
→ H5_COST_ACCOUNTING: setAuditContext+3agentAudit+clearAuditContext

# 专家
query_audit_logs({ targetId: "src/agents/prompts/experts/land-analysis.ts" })
→ 地块分析专家 prompt，含传感器佐证语义

query_audit_logs({ targetId: "src/agents/prompts/experts/variety-recommend.ts" })
→ 品种推荐专家 prompt，支持 search_web_cn

query_audit_logs({ targetId: "src/agents/prompts/experts/cost-accounting.ts" })
→ 成本核算专家 prompt，支持 search_web_cn/global

query_audit_logs({ targetId: "src/agents/reports/land-analysis.template.ts" })
→ 地块分析报告模板

query_audit_logs({ targetId: "src/agents/reports/variety-recommend.template.ts" })
→ 品种推荐报告模板

# 注册表
query_audit_logs({ targetId: "src/agents/prompts/experts/index.ts" })
→ 注册 3 个 H5 专家 prompt

query_audit_logs({ targetId: "src/agents/experts/registry.ts" })
→ REGISTRY_UPDATED: 新增 land_analysis + variety_recommend

query_audit_logs({ targetId: "src/agents/tools/index.ts" })
→ 注册 searchWebCnTool + searchWebGlobalTool 双工具

# 工具
query_audit_logs({ targetId: "src/agents/tools/impl/web-search.ts" })
→ 双工具 4 引擎(Baidu/Bing/Google/DuckDuckGo)+降级链

query_audit_logs({ targetId: "src/agents/tools/schemas/web-search.ts" })
→ WebSearch 工具 Zod Schema

# Farm-API 客户端
query_audit_logs({ targetId: "src/lib/farm-api/client.ts" })
→ Farm-Server HTTP 客户端封装

query_audit_logs({ targetId: "src/lib/farm-api/massif.ts" })
→ 地块 API 封装，getById(id,projectId) 必填

# 审计基础设施
query_audit_logs({ targetId: "src/lib/agent-audit-logger.ts" })
→ AgentAuditPhase 新增 6 个 H5_ 阶段

# 数据模型
query_audit_logs({ targetId: "prisma/schema.prisma" })
→ 新增 H5Session 模型 + farmServerCredential 加 source 字段

# 按审计阶段关键字
query_audit_logs({ keyword: "H5_LAND_ANALYSIS" })
→ 地块分析 API 审计记录

query_audit_logs({ keyword: "H5_VARIETY_RECOMMEND" })
→ 品种推荐 API 审计记录（含降级场景）

query_audit_logs({ keyword: "H5_COST_ACCOUNTING" })
→ 成本核算 API 审计记录
```

### 恢复判定标准

- action 命中数 ≥ 17
- grep 验证命令：

```bash
grep -R "source.*h5" src/lib/auth/
grep -R "H5_" src/lib/agent-audit-logger.ts
grep -R "land_analysis\|variety_recommend" src/agents/experts/registry.ts
ls src/app/api/h5/
```

---

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过
- [T] `npx prisma migrate dev` 通过
- [T] 所有文件改动已记录 ADD-7 审计（`query_audit_logs` 可回查）
- [R] curl `/api/h5/handshake` → 200 + sessionId
- [R] curl `/api/h5/land-analysis` → 200 + land_plot_analysis JSON
- [R] curl `/api/h5/variety-recommend` → 200 + crop_variety_recommendation JSON
- [R] curl `/api/h5/cost-accounting` → 200 + cost_accounting JSON
- [R] H5 前端接入 API 文档已生成（§3.5.5 交付物）
