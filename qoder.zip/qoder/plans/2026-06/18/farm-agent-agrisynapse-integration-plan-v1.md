# agrisynapse ↔ farm-agent 前端对接 Plan v1

## PLAN 元信息

- **Plan 名称**: farm-agent-agrisynapse-integration-v1
- **启动时间**: 2026-06-06
- **修订时间**: 2026-06-08（review2 架构修正：hash-only 认证、auth-gateway 裁决层、lib/credential 凭证隔离） → 修订 [2026-06-08: review2]
- **修订时间**: 2026-06-09（review2 运行时验证发现 5 项遗漏 → 催生 follow-up plan：[farm-agent-review-and-evidence-hardening-plan-v1](./farm-agent-review-and-evidence-hardening-plan-v1.md)） → 修订 [2026-06-09: review2 §5]
- **修订时间**: 2026-06-18（§2.3 对接流程 + §2.6 鉴权流程增量对齐实际 handshake 实现：token 三元组透传、惰性握手、4 步后端处理、线程裁决） → 修订 [2026-06-18: 文档回流]
- **当前状态**: 代码实施完成，编译验证通过，待运行时联调验收 → 修订 [2026-06-08: ADD Step 4 验证]
- **主导 AI**: Qoder
- **参考文档**:
  - 《大田精准耕播智能决策系统技术架构说明书》— 7.7 流式事件总线架构、7.5 Agent 编译（含 toolNode）
  - farm-agent tools-calling-pipeline-plan-v1 — 已收敛，toolNode 回环已集成
- **关联 Spec**:
  - `.qoder/specs/agrisynapse-farm-agent-integration/spec.md`
  - `.qoder/specs/agrisynapse-farm-agent-integration/tasks.md`
  - `.qoder/specs/agrisynapse-farm-agent-integration/checklist.md`
- **依赖**: farm-agent tools-calling-pipeline-v1 已收敛（tsc + build pass）

## 一、现状分析

### agrisynapse 端（前端）

- LLM 模块 (`/llm/*`) UI 框架完整：侧边栏 + 仪表盘 + 技能中心 + 聊天界面
- 聊天界面完全静态：`LlmChatView` → `LlmChatWelcome`（硬编码 6 个 skillCards + 6 个 chips）+ `LlmChatInput`（textarea + button 空壳）
- **没有一行代码调用 farm-agent**
- 现有 Axios 层只对接 Java 后端 (`/system/`, `/farm/`)，含 JWT 刷新、加密、租户拦截器
- 认证 Token 存储在 `web-storage-cache`（localStorage），通过 `getAccessToken()` / `getRefreshToken()` 获取
- Pinia store 模式：`defineStore` + `store` 注入

### farm-agent 端（后端）

- 单端点 `/api/agent/{hash}` 已就绪：GET (dashboard/thread/report) + POST (handshake/chat)
- **SSE 流式事件总线已完整实现**（架构文档 7.7 节）：
  - Layer A 运行时流式：`token`（逐 token）、`rag_search`、`evidence_found`、`tool_call`
  - Layer B 节点结构化：`structured_update {evidenceChain|reasoningPath|verdict|displayContent}`
  - Layer C 完成：`done {threadId, traceId, chainTrace}`
- **toolNode 回环已集成**：`routeByIntent` 已含 `hasToolCalls` 检测 → 路由至 `toolNode` → 回环 `intention`
- 23 个工具注册完毕（14 内部 + 2 时间 + 2 天气 + 5 Farm-Server）
- proxy 支持 hash 校验 + Bearer token 认证

## 二、架构决策

### 2.1 API 客户端层：独立 fetch（不依赖 Axios）

```
agrisynapse/src/api/
  ├── agent/              ← 新增
  │   ├── types.ts        ← 对接类型定义（对齐 farm-agent DTO + SSE 事件协议）
  │   └── index.ts        ← fetch-based 客户端
  ├── farm/               ← 现有：Java 后端
  └── ...
```

**决策理由**：farm-agent 的 hash-path + SSE 协议与 Java 后端 RESTful 完全不同；原生 `fetch` 避免 Axios 拦截器污染；hash 路径需客户端自主管理 `nextHash`。

### 2.2 聊天状态：Pinia Store

```
agrisynapse/src/store/modules/
  └── agentChat.ts        ← 新增
```

核心状态：`threadId`, `nextHash`, `messages[]`, `isStreaming`, `error`, `skillCards[]`, `recommendedTopics[]`

### 2.3 对接流程 → 修订 [2026-06-18: handshake 增量对齐实际实现]

```
用户进入 /llm/dashboard
  │
  ├─ 1. GET /api/agent/{hash}?action=dashboard
  │     → skillCards + recommendedTopics + nextHash
  │     （仪表盘仅获取技能卡片，不触发 handshake）
  │
  ├─ 2. 用户发送首条消息 → 惰性握手（sendMessage 内部触发）
  │     POST /api/agent/{hash}
  │     {
  │       type: "handshake",
  │       userVO: { id, nickname, deptId, deptName, responsibleMassifIds, ... },
  │       action: "new" | "resume",
  │       accessToken?: string,      ← Farm-Server token（有则传）
  │       refreshToken?: string,     ← Farm-Server refreshToken（有则传）
  │       expiresTime?: string       ← token 过期时间 ISO 格式
  │     }
  │     后端 4 步处理:
  │       ① resolveAuthGateway(request)         → 认证模式裁决（jwt / hash-only）
  │       ② handleHandshakeToken({userId,...})  → token 三元组写入 credential-store（有 token 时）
  │       ③ prisma.userProfile.upsert(...)       → 机会性更新用户资料
  │       ④ resolveHandshakeThread({action, userId}) → 线程裁决
  │          - action="new"     → 无条件新建线程
  │          - action="resume"  → 查找最近活跃线程，无则返回 threadId: null
  │     → { threadId, nextHash }
  │
  └─ 3. 用户发送消息（handshake 已获得 threadId）
        POST /api/agent/{hash} { type: "chat", messages, threadId, modelConfig }
          → SSE 流式事件总线（三层事件）
```

**惰性握手说明**：handshake 不在页面加载时触发，而是由 `sendMessage()` 首次调用时内部执行 `initSession("new")`。仪表盘页面仅调用 dashboard API 获取技能卡片，不建立会话线程。

### 2.4 SSE 事件消费（直接对齐架构文档 7.7.5 GUI 消费端映射表）

| 事件 | 消费组件 | 渲染方式 |
|------|---------|---------|
| `rag_search` | StatusIndicator | "正在搜索知识库: {query}" |
| `evidence_found` | StreamingEvidenceBar | 消息气泡下方逐条出现证据卡片 |
| `token` | LlmChatMessage 气泡 | 逐字打字机效果 |
| `tool_call` | LlmToolCallDisplay | 工具名称 + 参数展示 |
| `tool_result` | LlmToolCallDisplay | 工具结果折叠/展开 |
| `structured_update {evidenceChain}` | EvidenceChainPanel | 节点结束后出现，可折叠 |
| `structured_update {reasoningPath}` | ReasoningPathPanel | 步骤逐条展开 |
| `structured_update {verdict}` | LlmVerdictDisplay | 置信度 + 风险详情 |
| `structured_update {displayContent}` | StructuredResponseRenderer | 流式结束后渲染 |
| `done` | 停止 streaming 状态 | 更新 nextHash + threadId |

**关键决策**：前端组件设计**不自主发明**，直接对齐 farm-agent 已有的 SSE 事件协议和各事件的数据结构。架构文档已给出完整的消费端映射，本次对接是"按照协议实现消费端"。

### 2.5 跨域策略：farm-agent 直连（不使用 proxy）

agrisynapse 直接请求 farm-agent 的完整 URL。farm-agent 侧通过 Next.js 推荐的 `headers()` 配置处理 CORS：

```ts
// next.config.ts
headers: async () => [
  {
    source: "/api/agent/:hash",
    headers: [
      { key: "Access-Control-Allow-Origin", value: "*" },
      { key: "Access-Control-Allow-Methods", value: "GET, POST, OPTIONS" },
      { key: "Access-Control-Allow-Headers", value: "Content-Type, Authorization" },
    ],
  },
]
```

- proxy：OPTIONS 请求跳过 hash 校验，直接放行（`NextResponse.next()`）
- agrisynapse 通过 `VITE_FARM_AGENT_BASE_URL` 配置地址，直接拼接 `/api/agent/{hash}`

### 2.6 鉴权流程（极简三层，修订于 2026-06-08 联调 review）

```
┌─────────────────────────────────────────────────────────┐
│                    认证体系拓扑（修订后）                 │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  agrisynapse                    farm-agent              │
│  (浏览器)                       (Next.js)               │
│     │                               │                   │
│     │ ① hash-path                   │                   │
│     │  SHA-256(seed + 10分钟窗口) ──► proxy hash 校验    │
│     │  URL: /api/agent/{hash}       │  seed 共享         │
│     │                               │  hash 通过 =       │
│     │                               │  调用方身份已验证   │
│     │                               │                   │
│     │ ② userVO (body)               │                   │
│     │  { userId, username,          │ hash 验证后信任    │
│     │    responsibleMassifIds } ────► 注入请求上下文     │
│     │                               │                   │
│     │                               │     ┌──────────┐  │
│     │                               │     │ lib/     │  │
│     │                               │     │ credential│  │
│     │                               │     │ (独立目录)│  │
│     │                               │     └────┬─────┘  │
│     │                               │          │         │
│     │                               │    ③ farm-agent   │
│     │                               │    自有 service   │
│     │                               │    账户登录        │
│     │                               │          │         │
│     │                               │          ▼         │
│     │                               │    ┌──────────┐   │
│     │                               │    │ Farm-    │   │
│     │                               │    │ Server   │   │
│     │                               │    └──────────┘   │
└─────────────────────────────────────────────────────────┘
```

**关键点**：

| 层级 | 证明什么 | 机制 | 放哪 | 生命周期 |
|------|---------|------|------|----------|
| L1: 调用方身份 | "你是 agrisynapse" | hash-path（SHA-256，seed + 10分钟滚动窗口） | URL path | 每 10 分钟自动滚动 |
| L2: 用户身份 | "当前用户是张三" | userVO（hash 验证后可信） | POST body | 随请求 |
| L3: 数据源凭证 | "有权查 Farm-Server" | agrisynapse handshake 透传 token 三元组 → farm-agent credential-store 存储 → 自动刷新 | `lib/credential/` + handshake body | handshake 写入，ensureValidToken 按请求读取+刷新 | → 修订 [2026-06-18: L3 实际由 agrisynapse 透传，非 service 账户闭环]

**保留的设计**：
- ✅ agrisynapse→farm-agent hash-path 认证（L1 调用方身份）
- ✅ handshake 透传 Farm-Server token 三元组（L3 数据源凭证，条件性传递） → 修订 [2026-06-18: token 透传已恢复，非砍掉项]

**砍掉的设计**（经联调验证不需要）：
- ❌ agrisynapse→farm-agent JWT Bearer 登录（hash-path 已证明调用方身份，不需要第二层）
- ❌ SERVICE_TOKEN（不需要 agrisynapse 登录 farm-agent）
- ❌ per-user credential-store（一个 credential-store 按 userId 存储所有用户的 token）

**代码隔离**：`src/lib/credential/` 独立目录，`src/agents/tools/` 禁止 import。LLM 通过 tool 调用只能走到 `farm-server-client.ts` 服务层，服务层内部闭环 token 获取，token 对 LLM 完全不可见。

**handshake 真实职责** → 修订 [2026-06-18: 对齐实际实现]：
1. **认证裁决**：`resolveAuthGateway(request)` 判定认证模式（jwt / hash-only）
2. **Token 持久化**：有 accessToken/refreshToken 时调用 `handleHandshakeToken()` 写入 credential-store（userId 加密存储）
3. **用户资料同步**：有 userVO 时 `prisma.userProfile.upsert()` 机会性更新
4. **线程裁决**：`resolveHandshakeThread({ action, userId })` → new=新建线程 / resume=查最近活跃线程（无则返回 null）
5. 返回 `{ threadId, nextHash }`

**handshake 传递 token 三元组**：`accessToken` + `refreshToken` + `expiresTime`，由 agrisynapse 前端从 `getAccessToken()`/`getRefreshToken()`/`getFarmTokenExpiresTime()` 获取，条件性附加到请求体（有 token 才传，首次登录未获取到 token 时不传）。farm-agent 端 `ensureValidToken()` 在后续工具调用时从 credential-store 读取并自动刷新过期 token。

### 2.7 Token 生命周期（L2: farm-agent → Farm-Server）

```
工具调用触发 getFarmToken()
  │
  ▼
ensureValidToken(userId, "agrisynapse")
  │
  ├─ getValidToken(userId)          ← credential-store 查询 + 过期检查
  │   └─ token 有效 → 返回 accessToken ✓（直接调用 Farm-Server）
  │
  ├─ token 过期 → tryRefreshToken()
  │   └─ POST Farm-Server /system/auth/refresh-token?refreshToken=...
  │       ├─ 200 → updateRefreshedToken() 更新 DB → 返回新 accessToken ✓
  │       └─ 失败 → deleteToken() + 返回 null
  │
  └─ refresh 失败 (source="agrisynapse")
      └─ getFarmToken() → null
          ├─ Farm-Server 数据工具：降级提示 "Farm-Server 凭据已过期"
          └─ 天气/时间工具：不受影响（不依赖 Farm-Server）
```

**关键实现文件**：

| 模块 | 职责 |
|------|------|
| `credential-store.ts` | AES-256-GCM 加密存储（`FarmServerCredential` 表），密钥来自 `CREDENTIAL_ENCRYPTION_KEY` 环境变量 |
| `token-manager.ts` | `ensureValidToken()` 过期自动刷新 + `tryRefreshToken()` 调 Farm-Server 刷新接口 + `handleHandshakeToken()` 握手存入 |
| `farm-token-context.ts` | 请求级 TokenProvider 注入（`setFarmTokenProvider` / `clearFarmTokenProvider`） |

**Farm-Server token 最终失效时的处理**：
- farm-agent 侧：`getFarmToken()` 返回 null → Farm-Server 工具降级返回提示文案
- agrisynapse 侧：当前版本静默降级（工具调用结果中显示"凭据过期"），后续版本通过 SSE `error` 事件推送通知

**Token 刷新 vs 业务请求：两条分离路径**  → 修订 [2026-06-08: 补充路径分离说明，避免误导为单一路径]

```
                    ┌─ Token 刷新路径 ─────────────────────┐
                    │  token-manager.ts                    │
                    │  └─ fetch() 直调                     │
                    │     Farm-Server /refresh-token       │
                    │  （不走 farm-server-client）          │
                    └──────────────────────────────────────┘

┌─ 业务请求路径 ──────────────────────────────────────────────┐
│  Agent tools → farm-server-client.ts → farm-token-context   │
│  → getFarmToken() → ensureValidToken() → Farm-Server       │
│  （土墒/虫情/气象/地块，走 credential-store 获取 token）     │
└─────────────────────────────────────────────────────────────┘
```

分离原因：`farm-token-context` 依赖 `ensureValidToken` 提供有效 token，若刷新也走 `farm-server-client` 形成循环依赖。刷新路径是最简 `fetch()` 直调，不经过 Agent 工具链。

## 三、实施步骤（8 Tasks） → 修订 [2026-06-08: review2 新增 Task 8-9，现有架构调整扩至 10 Tasks]

```
Task 0 (文档先行 ADD 0.1) ─┐
Task 1 (API 客户端层) ─────┤
Task 6 (跨域认证)  ────────┤ 可并行
Task 8 (裁决层实现) ───────┤ → 新增 [2026-06-08: review2]
Task 9 (凭证隔离)   ───────┤ → 新增 [2026-06-08: review2]
                            ▼
Task 2 (Store)      ───────┐
                            ▼
Task 3 (仪表盘)     ───────┤
Task 4 (消息组件)   ───────┤ 可部分并行
                            ▼
Task 5 (流式聊天)   ───────┘
                            ▼
Task 7 (编译验证)
```

### Task 0: 文档先行（ADD 0.1）
- 更新 `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统技术架构说明书》.md`
- 新增 7.7.8 节：agrisynapse 前端对接（对接拓扑、API 端点、双层认证、SSE 事件→组件映射、Token 生命周期、跨域策略）
- 内容参照 plan 2.3-2.7 已评审通过的设计

### Task 1: API 客户端层
- 新建 `src/api/agent/types.ts`：完整类型定义，对齐 farm-agent DTO + SSE 事件数据结构
- 新建 `src/api/agent/index.ts`：fetch-based 客户端，6 个 API 函数 + hash 生成
- 每个请求自动拼接 hash path + 携带 Authorization 头

### Task 2: Pinia Store
- 新建 `src/store/modules/agentChat.ts`
- Actions: `initSession`（dashboard→handshake）、`sendMessage`（SSE 流式）、`loadThread`、`clearChat`
- SSE 事件分发：按 2.4 映射表将各事件类型分派到对应消息字段

### Task 3: 仪表盘对接
- 修改 `dashboard/index.vue`：从 store 获取 skillCards + recommendedTopics 替代硬编码
- 修改 `LlmChatWelcome.vue`：props 改为动态数据
- 点击卡片/标签 → 触发 `store.sendMessage(对应 intent)`

### Task 4: 消息组件（对标架构文档 7.7.5 事件→组件映射表）
- 新建 `LlmChatMessage.vue`：消息气泡（user/assistant 双样式）+ 打字机效果渲染
- 新建 `LlmToolCallDisplay.vue`：工具调用过程（tool_call → 展示，tool_result → 折叠）
- 新建 `LlmVerdictDisplay.vue`：置信度 + 结论 + 风险 + 推理路径
- 新建 `StreamingEvidenceBar.vue`：检索证据逐条出现动画
- 修改 `LlmChatView.vue`：消息列表 + 输入框绑定 + 流式状态管理
- 修改 `LlmChatInput.vue`：v-model + send emit

### Task 5: 流式聊天对接
- 基于 farm-agent 已有 SSE 事件总线协议解析（非自行设计协议）
- `ReadableStream` → SSE parser → 按 `event:` / `data:` 行解析
- 每种事件类型按 2.4 映射表分发到对应组件/状态
- 断线重连 + 错误提示

### Task 6: 跨域与认证桥接（farm-agent 侧）
- farm-agent `next.config.ts` `headers()`：`/api/agent/:hash` 路由添加 CORS 响应头
- farm-agent proxy：OPTIONS 请求跳过 hash 校验直接放行
- agrisynapse `.env.dev`：`VITE_FARM_AGENT_BASE_URL=http://localhost:3000` + `VITE_HASH_SEED_TEXT`
- API 客户端使用完整 URL 直连（`${BASE_URL}/api/agent/{hash}`）
- 请求头注入 `Authorization: Bearer {jwt}`（agrisynapse 现有 JWT，由 Java 后端签发）
- handshake 传递 `userVO`（用户基本信息）用于 farm-agent 侧 upsert UserProfile + 创建 thread
- Farm-Server 凭据由 farm-agent 的 credential-store 独立管理，agrisynapse 不持有

### Task 7: 编译验证
- `cd agrisynapse && pnpm build` 通过
- `cd farm-agent && npm run build` 通过
- LSP 无新增报错

### Task 8: farm-agent 裁决层实现 → 新增 [2026-06-08: review2 决策]
- 新建 `src/caijuehub/strategies/agrisynapse-handshake.ts`：`resolveHandshakeThread({ action, userId })`
- 新建 `src/caijuehub/strategies/auth-gateway.ts`：`resolveAuthGateway(request)` → `{ mode, user }`
- 修改 `src/proxy.ts`：`requireRole` → `resolveAuthGateway()`
- 修改 `src/app/api/agent/[hash]/route.ts`：handshake 调 `resolveHandshakeThread`，chat userId 按 auth mode 判定

### Task 9: farm-agent lib/credential/ 凭证隔离 → 新增 [2026-06-08: review2 决策]
- 新建 `src/lib/credential/service-token.ts`：farm-agent 自有 service 账户登录 Farm-Server
- 一个 service token 服务所有用户，按 massifId 过滤数据
- 确保 `src/agents/tools/` 不 import `lib/credential/`（LLM 不可达）→ `grep -r` 验证通过

## 四、关键风险

| 风险 | 缓解 |
|------|------|
| ~~farm-agent SSE 可行性~~ | **非风险** — 架构文档 7.7 已确认完整的三层事件总线实现 |
| agrisynapse 与 farm-agent 跨域 | farm-agent `next.config.ts` `headers()` 配置 CORS + proxy OPTIONS 放行，agrisynapse 直连 |
| Farm-Server 凭据缺失 | handshake 容错处理，工具调用降级提示 |
| 现有 Axios 拦截器污染 agent 请求 | 独立 fetch，不经过 Axios 实例 |

## 五、验收标准 → 修订 [2026-06-08: ADD Step 4 验证]

- [x] agrisynapse 仪表盘显示 farm-agent 返回的真实技能卡片（不再硬编码） → 修订 [2026-06-08: 代码完成，待运行时验证]
- [x] 用户发送消息后 SSE 流式接收 AI 回复（对齐 stream-bus 协议，逐 token 打字机效果） → 修订 [2026-06-08: 代码完成，待运行时验证]
- [ ] 发送"查土壤湿度"时工具调用过程可视（`tool_call` + `tool_result` 事件渲染）
- [ ] 证据链、推理路径、裁决结果结构化展示（对齐 `structured_update` 事件协议）
- [x] agrisynapse + farm-agent 双端 build 通过
- [x] agrisynapse 无 JWT 请求 farm-agent 不返回 401 → 新增 [2026-06-08: review2 hash-only 认证]
- [x] farm-agent 自有 service 账户调 Farm-Server 成功，LLM 输出不含 token → 新增 [2026-06-08: review2 凭证隔离]
- [x] `src/middleware.ts` 正确注册 proxy.ts 为 Next.js 中间件 → 新增 [2026-06-08: 修复 CORS 问题]
