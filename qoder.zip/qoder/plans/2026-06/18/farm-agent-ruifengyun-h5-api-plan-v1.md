# farm-agent-ruifengyun-h5-api-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度。

## PLAN 元信息

- **Plan 名称**: farm-agent-ruifengyun-h5-api-v1
- **启动时间**: 2026-06-18T00:00:00Z
- **修订时间**: 2026-06-18（新增§3.5 H5握手与认证流程：无客户端认证、复用handleHandshakeToken+credential-store、Phase 0握手端点）
- **修订时间**: 2026-06-18（P0-1回流：地块分析输入从plots对象数组改为massifIds+region，API层先查Farm-Server再分析；§2.3+§3.1+§3.2+§3.3同步更新）
- **修订时间**: 2026-06-18（P0-2回流：§3.3采纳路线A轻量方案——绕过LangGraph，API Route内直调LLM+手动工具调用，不走agent内核）
- **修订时间**: 2026-06-18（P0-3回流：sessionId存储从内存Map改为Prisma H5Session表，支持多进程部署，无TTL（客户端自行控制会话生命周期））
- **修订时间**: 2026-06-18（P1-1~P1-4+P2-1~P2-3回流：varietyName注入方式、traceId生成策略、种子库降级策略、成本明细映射、错误响应格式、Grounding初始数据来源、关联文档标记）
- **修订时间**: 2026-06-18（H5聊天助手+token改造回流：§3.5 token管理改为source-aware多端隔离、新增h5-auth-gateway+h5-handshake-thread裁决策略、新增/api/h5/agent SSE流式端点、credential-store加source字段）
- **修订时间**: 2026-06-18（Step 0.5 完成：Specs三元组+add-route+Handoff已生成，原子闭包判定2轮，§六关联文档已更新）
- **修订时间**: 2026-06-18（实施同步：projectId 升为必填参数（项目级数据隔离）；新增 WebSearch 双工具+4引擎+降级链；cost-accounting/variety-recommend 升级为 LangChain Tool Calling 循环；land-analysis 路由层并行预取气象站+土壤传感器数据；传感器数据定性为佐证参考（气候带推理为主依据）；新增 H5轻量专家四层标识规范）
- **修订时间**: 2026-06-24（增量交付：nongqing 农情报告域 6 端点 + 任务/处方完成取消 + 计划状态化 active/completed + 地块原子冲突检查 + 图片上传 + 定时任务自动释放地块）
- **主导 AI**: Qoder
- **关联文档**:
  - 需求来源: `docs/大田精准耕播智能决策系统/knowledge/00-需求/对接瑞丰耘AI智能体小程序-v1.md`
  - ADD Route: `.qoder/plans/farm-agent-ruifengyun-h5-api-add-route-v1.md`
  - Handoff: `.qoder/plans/farm-agent-ruifengyun-h5-api-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-ruifengyun-h5-api-review-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/agents/experts/registry.ts | COMPONENT | COMPONENT_UPDATED | 11个专家注册（无land_analysis/variety_recommend） | 13个专家注册，新增2个专家+学科映射 | 待实施 |
| src/agents/prompts/experts/land-analysis.ts | COMPONENT | COMPONENT_CREATED | 不存在 | land_analysis专家prompt定义 | 待实施 |
| src/agents/prompts/experts/variety-recommend.ts | COMPONENT | COMPONENT_CREATED | 不存在 | variety_recommend专家prompt定义 | 待实施 |
| src/agents/prompts/experts/index.ts | COMPONENT | COMPONENT_UPDATED | 11个专家prompt注册 | 13个专家prompt注册 | 待实施 |
| src/agents/reports/land-analysis.template.ts | COMPONENT | COMPONENT_CREATED | 不存在 | land_analysis报告模板 | 待实施 |
| src/agents/reports/variety-recommend.template.ts | COMPONENT | COMPONENT_CREATED | 不存在 | variety_recommend报告模板 | 待实施 |
| src/app/api/h5/land-analysis/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 地块分析REST API端点 | 待实施 |
| src/app/api/h5/variety-recommend/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 品种推荐REST API端点 | 待实施 |
| src/app/api/h5/cost-accounting/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 成本核算REST API端点 | 待实施 |
| src/lib/agent-audit-logger.ts | COMPONENT | COMPONENT_UPDATED | AgentAuditPhase无H5相关阶段 | 新增H5_HANDSHAKE/H5_LAND_ANALYSIS/H5_VARIETY_RECOMMEND/H5_COST_ACCOUNTING阶段 | 待实施 |
| src/lib/auth/credential-store.ts | COMPONENT | COMPONENT_UPDATED | farmServerCredential 表 userId 唯一键 | 加 source 字段，(userId,source) 复合唯一，支持 Farm-Server/H5 多端 token 隔离 | 待实施 |
| src/lib/auth/token-manager.ts | COMPONENT | COMPONENT_UPDATED | RequestSource="agrisynapse"\|"own_ui"，tryRefreshToken 硬编码 Farm-Server URL | RequestSource 加 "h5"，tryRefreshToken 按 source 路由不同刷新端点 | 待实施 |
| src/caijuehub/strategies/h5-auth-gateway.ts | COMPONENT | COMPONENT_CREATED | 不存在 | H5 认证裁决（sessionId 校验 → 提取 userId） | 待实施 |
| src/caijuehub/strategies/h5-handshake-thread.ts | COMPONENT | COMPONENT_CREATED | 不存在 | H5 线程裁决（new/resume，source="h5"，用户体系独立） | 待实施 |
| src/app/api/h5/agent/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | H5 智慧农业助手 SSE 流式端点（复用 LangGraph agent.stream） | 待实施 |
| src/app/api/h5/handshake/route.ts | COMPONENT | COMPONENT_UPDATED | 握手 token 写 farmServerCredential（无 source 区分） | token 写 credential-store 时带 source="h5"，与 agrisynapse token 隔离 | 待实施 |
| prisma/nongqing.prisma | COMPONENT | COMPONENT_UPDATED | 无农情模型 | ProductionPlan+status/massifIds, FarmTask+completion, AlertPrescription | ✅ 已实施（2026-06-24） |
| src/app/api/h5/nongqing/tasks/[id]/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 任务详情 GET + PATCH 标记/取消完成 | ✅ 已实施（2026-06-24） |
| src/app/api/h5/nongqing/prescriptions/[id]/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 处方详情 GET + PATCH 填报/取消完成 | ✅ 已实施（2026-06-24） |
| src/app/api/h5/production-plan/plans/[id]/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 计划完成/重新激活 PATCH | ✅ 已实施（2026-06-24） |
| src/app/api/h5/upload/image/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 图片上传 multipart + 三级路径隔离 | ✅ 已实施（2026-06-24） |
| scripts/auto-complete-plans.ts | SCRIPT | COMPONENT_CREATED | 不存在 | 定时任务自动完成到期计划 | ✅ 已实施（2026-06-24） |

---

## 一、背景与目标

### 1.1 问题现状

瑞丰耘H5前端（`https://80retros.com/wrnc/06/`）"新增生产计划"功能是一个5步向导流程：
1. 地块选择 → 2. 地块分析 → 3. 品种选择 → 4. 成本核算 → 5. 计划生成

其中 Step 2~4 需要后端 AI 能力支撑，但当前 farm-agent 的所有能力均通过 SSE 流式 agent 链路暴露（`/api/agent/chat/stream`），不适合 H5 直接消费。H5 需要**独立的常规 REST API 端点**，返回结构化 JSON。

### 1.2 目标

1. **新增 `land_analysis` 专家**：地块分析能力（区域气候推理 + 多地块土壤综合判定 + 地块明细透传）
2. **新增 `variety_recommend` 专家**：品种推荐能力（基于种子库数据，输出 H5 `crop_variety_recommendation` JSON schema）
3. **3 个 REST API 端点**：地块分析、品种推荐、成本核算，供 H5 直接调用
4. 成本核算复用现有 `roi_analysis` 专家，适配输出 schema

**不在范围内**：Step 5"计划生成"API（H5 端本地聚合，不对接）

---

## 二、方案选型

### 2.1 候选方案对比

| 方案 | 专家复用度 | H5 适配成本 | 架构影响 | 结论 |
|------|-----------|------------|---------|------|
| A: 复用现有专家+API适配层 | 高（crop_compare+roi_analysis） | 中（schema转换） | 低 | 部分采纳 |
| B: 全部新建专家 | 低 | 低（专家直接输出目标schema） | 高 | 过度设计 |
| **C: 混合方案（采纳）** | 中（新建2+复用1） | 低 | 中 | **采纳** |

### 2.2 选型理由

- **地块分析**：现有专家无对应能力（planting_advice 职责不同），必须新建 `land_analysis`
- **品种推荐**：`crop_compare` 是"横向对比"，H5 需要"推荐+对比"且输出 schema 完全不同 → 新建 `variety_recommend`，职责清晰分离
- **成本核算**：`roi_analysis` 描述本身就是"投入产出比分析、成本收益核算"，天然匹配 → 复用 + API 层适配输出 schema

### 2.3 地块分析逻辑设计决策 → 修订 [2026-06-18: P0-1回流，massifIds替代plots] [2026-06-18: projectId必填+传感器预取]

**数据流设计**：

```
H5 → farm-agent:  { massifIds: [115, 116], region: { province, city, district }, projectId: 1 }
                        │
                        ▼
                farm-agent 用已有 token 查 Farm-Server（projectId 必传，项目级数据隔离）
                GET /farm/massif/get?id=115&projectId=1
                GET /farm/massif/get?id=116&projectId=1
                GET /farm/weather-data/page?massifId=115&projectId=1&pageSize=1
                GET /farm/moisture-data/page?massifId=115&projectId=1&pageSize=1
                ... (每个地块并行预取)
                        │
                        ▼
                拿到完整 Massif DTO + 气象站瞬时快照 + 土壤传感器瞬时快照
                        │
                        ▼
                一次 LLM 调用，整体分析
                ├─ 气候 → 基于 region 推断气候带特征（气候类型/年均温/年降雨量/≥10℃积温）
                │         weatherStationData（气象站瞬时读数）仅作佐证参考，不可替代多年平均统计值
                ├─ 土壤 → 基于多地块 moistureType 加权综合判定
                │         soilSensorData（土壤传感器瞬时读数）仅作佐证参考
                └─ 地块明细 → 从 Massif DTO 提取，拼入响应
                        │
                        ▼
                返回一份聚合的 land_plot_analysis JSON
```

**设计决策**：
- H5 只传 massifId 数组 + projectId，不传地块详情 → 避免两个 web 后端数据格式对齐的负担
- projectId 必填，项目级数据隔离（非可选、非租户级）→ 所有 Farm-Server 调用均需透传
- farm-agent 作为中间服务，用自有 token 从 Farm-Server 拉取权威数据 → 数据永远是最新的
- 字段映射只在 farm-agent 内部做（Massif DTO → 专家输入），可控

**推理方式**：一次 LLM 调用，整体分析
- 气候 → 基于 region 推断气候带特征（主依据），传感器瞬时数据仅佐证（不可替代）
- 土壤 → 基于多地块的 `moistureType`（土壤分类枚举）加权综合判定，传感器数据仅佐证
- 地块明细 → 从 Massif DTO 提取（name/area/moistureType/type），拼入响应

**否决方案**：
- per-plot 分析后拟合：气候同区域共享，分析 N 次结果一样
- H5 直传地块对象：两个 web 后端（H5后端 ≠ Farm-Server）字段不对齐，维护成本高

---

## 三、架构设计

### 3.1 专家注册（registry.ts）

#### land_analysis 专家

```
id: "land_analysis"
label: "地块分析"
domain: "耕"
inputSchema: [region(种植区域,必填), massifIds(地块ID列表,必填)]
realtimeToolNames: [] (纯知识库推理，不依赖实时工具)
grounding:
  collectionName: "expert_land_analysis"
  disciplineCodes: [
    "210.2020",  // 农业气象学与农业气候学
    "210.5020",  // 土壤地理学
    "210.5055",  // 土壤调查与评价
    "210.2050",  // 农业生态学
    "210.7045",  // 农业区划
  ]
```

#### variety_recommend 专家

```
id: "variety_recommend"
label: "品种推荐"
domain: "种"
inputSchema: [crop_type(作物类型,必填), location(种植区域,必填), climate(气候条件,选填), soil(土壤性状,选填), planting_area(种植面积,必填)]
realtimeToolNames: ["query_seed_catalog"]  // 复用种子库查询工具
grounding:
  collectionName: "expert_variety_recommend"
  disciplineCodes: [
    "210.3030",  // 种子学
    "210.3035",  // 作物育种学与良种繁育学
    "210.3050",  // 作物种质资源学
    "210.3025",  // 作物生态学
  ]
```

### 3.2 REST API 端点设计

统一路径前缀：`/api/h5/`

#### POST /api/h5/land-analysis → 修订 [2026-06-18: P0-1回流] [2026-06-18: projectId必填+传感器预取]

输入：
```json
{
  "massifIds": [115, 116],
  "region": { "province": "江苏省", "city": "扬州市", "district": "邗江区" },
  "projectId": 1
}
```
所有字段必填。projectId 用于项目级数据隔离，透传至所有 Farm-Server 调用。

API 层内部流程：
1. 用 massifIds 调 Farm-Server `GET /farm/massif/get?id={id}&projectId={projectId}` 批量拉取 Massif DTO
2. 并行预取每个地块的气象站瞬时快照 + 土壤传感器瞬时快照（`/farm/weather-data/page` + `/farm/moisture-data/page`）
3. 提取地块信息（name, area, moistureType, type）传入专家
4. 专家推理：区域气候（气候带推断为主依据，传感器数据仅佐证）+ 多地块土壤综合判定
5. API 层拼入地块明细数组到响应

输出：`land_plot_analysis` JSON schema（需求文档定义）+ 地块明细数组（从 Massif DTO 提取）

#### POST /api/h5/variety-recommend

输入：
```json
{
  "cropType": "水稻",
  "region": { "province": "江苏省", "city": "南通市", "district": "如东县" },
  "climateSummary": { ... },
  "soilSummary": { ... },
  "plantingArea": 100
}
```

LLM 可通过 `search_web_cn` 工具自主搜索品种实测数据（Tool Calling 循环，最多 5 轮/12s 超时）。

输出：`crop_variety_recommendation` JSON schema（需求文档定义）

#### POST /api/h5/cost-accounting → 修订 [2026-06-18: P1-1+P1-4回流] [2026-06-18: Tool Calling升级] [2026-06-24: grainPrice/seedPrice 替代 pricePerKg/seedCostPerMu，公式下沉至 formulas.ts]

输入：
```json
{
  "plantingArea": 250,
  "varietyName": "南粳9108",
  "cropType": "水稻",
  "yieldPerMu": 550,
  "grainPrice": 1.6,
  "seedPrice": 9.6
}
```

LLM 自行计算 `seedCostPerMu = seedPrice × 播种量`（按 cropType 查 formulas.ts 的 SEEDING_RATES 表），其余成本类目通过 web_search 获取实时农资价格。

LLM 可通过 `search_web_cn` / `search_web_global` 工具自主搜索实时农资价格（Tool Calling 循环，最多 5 轮/12s 超时）。

**varietyName 传递方式**（P1-1）：路线 A 下不扩展 roi_analysis 的 inputSchema——API 层在构建 LLM prompt 时将 `varietyName` 作为额外上下文注入，附在 `plantingArea` 和 `cropType` 之后。roi_analysis 专家本身不感知品种字段，品种信息仅作为 prompt 参数透传。

**5 类成本明细映射策略**（P1-4）：在 prompt 中注入 cost_accounting 目标 schema 约束，明确要求 LLM 输出以下 5 类成本明细（每类含 `formula` + `breakdown[]` + `subtotal`）：
1. 种子成本 / 2. 肥料成本 / 3. 病虫害防治成本 / 4. 人工成本 / 5. 其他成本
API 层对 LLM 输出做 schema 校验，缺失字段补 `null`，确保 H5 前端不会因字段缺失而渲染异常。

输出：`cost_accounting` JSON schema（需求文档定义）

### 3.3 API 内部调用链 → 修订 [2026-06-18: P0-2回流，采纳路线A轻量方案] [2026-06-18: Tool Calling+传感器]

**技术路线决策**：采用**路线 A（轻量）**——绕过 LangGraph，API Route 内直调 LLM + **LangChain Tool Calling 循环**。

**决策依据**：3 个 API 的核心任务是结构化数据匹配和公式计算，不需要 RAG 证据链和深度推理路径。但成本核算和品种推荐需要实时数据（农资价格/品种实测），采用 `llm.bindTools()` + 迭代循环让 LLM 自主决定搜索时机。

| API | LLM 做什么 | 需要 RAG？ | 需要工具？ |
|-----|-----------|-----------|----------|
| 地块分析 | 基于 region 推理气候带+土壤综合描述 | 可选 | 无（路由层预取传感器数据作为佐证） |
| 品种推荐 | 种子库数据匹配+排序+推荐理由 | 不需要 | search_web_cn（Tool Calling 循环）+ query_seed_catalog（DB查询） |
| 成本核算 | 公式计算+成本明细生成 | 不需要 | search_web_cn + search_web_global（Tool Calling 循环） |

**调用流程**：

```
H5 POST → API Route
  │
  ├─ 地块分析 /api/h5/land-analysis
  │    ① 用 massifIds + projectId 查 Farm-Server → Massif DTO
  │    ② 并行预取气象站快照 + 土壤传感器快照（PaginatedQuery）
  │    ③ loadExpertPrompt("land_analysis") → system prompt
  │    ④ 拼接 prompt + region + plots + weather/soil 佐证数据 → 构建消息
  │    ⑤ 直调 LLM API → 同步返回文本
  │    ⑥ JSON.parse 提取 → 映射为 land_plot_analysis schema
  │    ⑦ 从 Massif DTO 提取地块明细拼入响应
  │    ⑧ 返回
  │
  ├─ 品种推荐 /api/h5/variety-recommend
  │    ① loadExpertPrompt("variety_recommend") → system prompt
  │    ② Prisma 直查 seedCatalog（query_seed_catalog 等价）
  │       ├─ 成功有数据 → 正常流程
  │       └─ 失败/空 → **降级**：LLM 基于 expert_variety_recommend knowledge base
  │          纯知识推理，输出中 `data_confidence: "low"`，
  │          `remark: "种子库无匹配数据，以下推荐基于知识库推理"`
  │    ③ llm.bindTools([searchWebCnTool]) → Tool Calling 循环（最多 5 轮）
  │       LLM 自主决定是否搜索品种实测数据（产量/抗性/适应性）
  │    ④ JSON.parse 提取 → 映射为 crop_variety_recommendation schema
  │    ⑤ 返回
  │
  └─ 成本核算 /api/h5/cost-accounting
       ① loadExpertPrompt("cost_accounting") → system prompt
       ② 拼接 prompt + plantingArea + varietyName + cropType → 构建消息
       ③ llm.bindTools([searchWebCnTool, searchWebGlobalTool]) → Tool Calling 循环
          LLM 自主决定是否搜索实时农资价格（种子/肥料/农药）
       ④ JSON.parse 提取 → 映射为 cost_accounting schema
       ⑤ 返回
```

**关键设计点**：
- **不走 LangGraph**：绕过 streamAgent/intention/retrieval/reasoning 节点图，API Route 内直接调 LLM
- **LangChain Tool Calling 循环**：cost-accounting + variety-recommend 使用 `llm.bindTools()` 绑定搜索工具，LLM 自主决定是否需要搜索。最多 5 轮，单次工具调用 12s 超时
- **WebSearch 双工具**：search_web_cn（Bing→Baidu 降级）供国内搜索；search_web_global（Google→DuckDuckGo→Bing 降级）供国际搜索
- **种子库直查**：品种推荐时 API 层直接 Prisma 查 seedCatalog，不走 ToolNode
- **传感器预取**：地块分析路由层并行预取气象站+土壤传感器数据（`Promise.all`），作为 LLM 推理佐证
- **LLM 职责**：结构化数据匹配+排序+生成自然语言说明，不做深度推理
- **JSON schema 约束**：在 prompt 中注入 H5 目标 JSON schema，要求 LLM 严格按格式输出
- **每个 API 调用 `agentAudit()` 记录审计日志**
- **地块明细**在 API 层从 Massif DTO 提取后拼入响应，不经过 LLM
- **种子库降级**（P1-3）：`query_seed_catalog` 失败/空时，降级为基于 knowledge base 纯知识推理，输出标记 `data_confidence: "low"` + 降级 remark
- **成本明细 schema 约束**（P1-4）：cost-accounting API 在 prompt 中注入 5 类成本明细 schema 约束，API 层做 schema 校验 + 缺失字段补 null

#### 3.3.1 审计日志 traceId 生成策略 → 修订 [2026-06-18: P1-2回流]

H5 API 无对话线程概念，每个请求独立生成 traceId。

```
API Route 入口:
  ① traceId = `h5_${sessionId}_${Date.now()}_${randomHex(6)}`
  ② setAuditContext({ userId, traceId, phase: H5_XXX })
  ③ 执行业务逻辑 + agentAudit(...) 记录审计
  ④ clearAuditContext()

API Route 出口（finally 块）:
  clearAuditContext()  // 确保请求级上下文不泄漏到下一个请求
```

- traceId 格式：`h5_<sessionId>_<timestamp>_<random6>`，可读且全局唯一
- 审计阶段：`H5_LAND_ANALYSIS` / `H5_VARIETY_RECOMMEND` / `H5_COST_ACCOUNTING`（对应 Task 7）
- 每次 API 调用产生一条 `agentAudit` 记录，可通过 traceId 关联查询

### 3.4 学科代码映射（DISCIPLINECODE2EXPERTMAP）

新增两个映射：
```
land_analysis: [
  "210.2020",  // 农业气象学与农业气候学
  "210.5020",  // 土壤地理学
  "210.5055",  // 土壤调查与评价
  "210.2050",  // 农业生态学
  "210.7045",  // 农业区划
]

variety_recommend: [
  "210.3030",  // 种子学
  "210.3035",  // 作物育种学与良种繁育学
  "210.3050",  // 作物种质资源学
  "210.3025",  // 作物生态学
]
```

### 3.5 H5 握手与认证流程

H5 作为独立客户端（非 agrisynapse），需要在调用 3 个 API 前完成握手，建立会话上下文。

#### 3.5.1 认证体系 → 修订 [2026-06-18: token source-aware 改造]

```
┌──────────────────────────────────────────────────────────────┐
│                   H5 ↔ farm-agent 认证拓扑                     │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  瑞丰耘 H5                           farm-agent              │
│  (独立客户端)                         (Next.js)               │
│     │                                    │                   │
│     │ ① POST /api/h5/handshake           │                   │
│     │  { userVO,                         │                   │
│     │    accessToken?, refreshToken?,     │                   │
│     │    expiresTime? }                  │                   │
│     │ ──────────────────────────────────►│                   │
│     │                                    │                   │
│     │     后端处理:                       │                   │
│     │     ① handleHandshakeToken(         │                   │
│     │          {userId, ..., source:"h5"} │ ← source 区分    │
│     │        ) → token 写 credential-store│                   │
│     │        (farmServerCredential 表     │                   │
│     │         userId+source 复合唯一键)    │                   │
│     │     ② userProfile.upsert()          │                   │
│     │     ③ prisma.h5Session.create(...)  │                   │
│     │                                    │                   │
│     │ ◄──────────────────────────────────│                   │
│     │  { sessionId }                     │                   │
│     │                                    │                   │
│     │ ② 后续两类调用:                     │                   │
│     │                                    │                   │
│     │  [A] 智慧农业助手（SSE 流式聊天）     │                   │
│     │  POST /api/h5/agent                │                   │
│     │  Header: X-Session-Id              │                   │
│     │  ─────────────────────────────────►│                   │
│     │         ├─ h5-auth-gateway          │ ← 新增裁决策略   │
│     │         │   resolveH5AuthGateway()   │   sessionId→userId│
│     │         ├─ h5-handshake-thread      │ ← 新增裁决策略   │
│     │         │   resolveH5Thread()        │   new/resume裁决  │
│     │         └─ LangGraph agent.stream()  │   流式推 SSE     │
│     │                                    │                   │
│     │  [B] 新增生产计划（REST JSON）        │                   │
│     │  POST /api/h5/land-analysis         │                   │
│     │  ─────────────────────────────────►│                   │
│     │         sessionId 校验 → 直调 LLM   │                   │
│     │                                    │                   │
│     │                                    │     ┌───────────┐ │
│     │                                    │     │credential │ │
│     │                                    │     │ -store    │ │
│     │                                    │     │           │ │
│     │                                    │     │ source:   │ │
│     │                                    │     │ "h5"      │ │
│     │                                    │     │ "agri-"   │ │
│     │                                    │     │ synapse"  │ │
│     │                                    │     └─────┬─────┘ │
│     │                                    │           │        │
│     │                                    │  ensureValidToken │
│     │                                    │  (userId, source) │
│     │                                    │  ├─ source="h5"   │
│     │                                    │  │  → H5_BASE_URL │
│     │                                    │  │    /auth/refresh│
│     │                                    │  └─ source="agri-"│
│     │                                    │     → Farm-Server │
│     │                                    │       /auth/refresh│
└──────────────────────────────────────────────────────────────┘
```

#### 3.5.2 握手流程详细 → 修订 [2026-06-18: source-aware token 存储]

```
H5 端自行决定握手时机（如应用启动、用户登录后等）
  │
  ├─ 1. POST /api/h5/handshake
  │     请求体:
  │     {
  │       userVO: {                        ← 用户基本信息（H5 用户体系）
  │         id: 123,
  │         nickname: "张三",
  │         responsibleMassifIds: [1,2,3]
  │       },
  │       accessToken?: "xxx",             ← H5 后端 token（非 Farm-Server）
  │       refreshToken?: "xxx",            ← H5 后端 refreshToken
  │       expiresTime?: "2026-06-18T..."   ← token 过期时间
  │     }
  │
  │     后端 3 步处理:
  │       ① handleHandshakeToken({
  │            userId,
  │            accessToken,
  │            refreshToken,
  │            expiresAt,
  │            source: "h5"               ← 与 agrisynapse token 隔离
  │          })
  │          → credential-store 写 farmServerCredential
  │            WHERE (userId, source) = (123, "h5")，upsert
  │       ② prisma.userProfile.upsert(...)
  │       ③ prisma.h5Session.create({sessionId, userId})
  │
  │     响应: { sessionId: "sess_xxx" }
  │
  ├─ 2. H5 缓存 sessionId
  │     后续每次 API 调用携带 Header: X-Session-Id: sess_xxx
  │
  └─ 3. 调用业务 API（两类路径）
        [A] POST /api/h5/agent（SSE 流式聊天）
            → h5-auth-gateway 裁决 → h5-handshake-thread 裁决 → agent.stream()
        [B] POST /api/h5/land-analysis 等（REST JSON）
            → sessionId 校验 → 直调 LLM
```

#### 3.5.3 与 agrisynapse handshake 的关系 → 修订 [2026-06-18: token 隔离+裁决策略]

| 维度 | agrisynapse handshake | H5 handshake |
|------|----------------------|-------------|
| 认证层 | hash-path（SHA-256 滚动窗口） | sessionId 校验（h5-auth-gateway.ts） |
| 用户体系 | agrisynapse 用户 ID 命名空间 | H5 用户 ID 命名空间（独立） |
| token 存储 | credential-store source="agrisynapse" | credential-store source="h5"（同表不同行） |
| token 刷新 | Farm-Server /system/auth/refresh-token | H5 后端自有刷新端点（H5_BASE_URL） |
| 线程裁决 | agrisynapse-handshake.ts（source 隐式） | h5-handshake-thread.ts（source="h5" 显式） |
| 会话标识 | threadId（对话线程） | sessionId + threadId（session 关联 + 聊天线程） |
| 触发时机 | sendMessage 首次调用时（惰性握手） | H5 端自行决定 |
| 复用设施 | — | handleHandshakeToken(source) + credential-store(source) + userProfile.upsert |

**关键决策**：
- token 管理加 `source` 参数，`(userId, source)` 复合唯一键，H5 和 agrisynapse 的 token 互不覆盖
- `tryRefreshToken` 按 source 路由：source="h5" → `H5_BASE_URL/auth/refresh`，source="agrisynapse" → `FARM_SERVER_BASE_URL/system/auth/refresh-token`
- 线程裁决新建 `h5-handshake-thread.ts`（逻辑与 agrisynapse-handshake.ts 一致，但 userId 来自独立命名空间，chatThread 写入不冲突）

#### 3.5.4 新增文件 → 修订 [2026-06-18: token 改造+裁决策略+聊天端点]

| 文件 | 职责 |
|------|------|
| `src/app/api/h5/handshake/route.ts` | H5 握手端点（带 source="h5" 的 token 存储 + userProfile upsert + sessionId 写入 DB） |
| `src/app/api/h5/agent/route.ts` | H5 智慧农业助手 SSE 流式端点（复用 LangGraph agent.stream，前置 h5-auth-gateway + h5-handshake-thread 裁决） |
| `src/caijuehub/strategies/h5-auth-gateway.ts` | H5 认证裁决：从 X-Session-Id header 查 H5Session 表 → 提取 userId |
| `src/caijuehub/strategies/h5-handshake-thread.ts` | H5 线程裁决：new 创建 chatThread（source="h5"），resume 查找最近活跃线程 |
| `prisma/schema.prisma` | 新增 `H5Session` 模型（sessionId, userId，无TTL）；`farmServerCredential` 加 `source` 字段 |
| `src/lib/auth/credential-store.ts` | saveToken/getValidToken/updateRefreshedToken 加 source 参数 |
| `src/lib/auth/token-manager.ts` | RequestSource 加 "h5"；tryRefreshToken 按 source 路由刷新端点 |

#### 3.5.5 H5/小程序前端接入指南（API 文档交付物）

实施完成后需生成面向 H5/小程序前端的 API 接入文档，包含：

1. **握手调用示例**：`POST /api/h5/handshake` 请求体结构 + 响应结构
2. **sessionId 存储说明**：前端 handshake 后将 sessionId 存入 localStorage / wx.setStorageSync
3. **后续请求 header 注入**：所有 `/api/h5/*` 请求必须在 header 中携带 `X-Session-Id`
4. **前端 HTTP 工具层封装示例**：统一的请求拦截器代码片段（fetch / axios / wx.request 各一份）
5. **sessionId 刷新机制**：H5 每次进入需要 AI 能力的页面时重新 handshake，获取新 sessionId
6. **各 API 的请求/响应示例**：land-analysis、variety-recommend、cost-accounting 各一份完整 curl + JSON 示例

---

### 3.6 WebSearch 双工具与多引擎降级链 → 新增 [2026-06-18]

为支持 H5 API 的实时数据搜索能力（农资价格/品种实测数据），实现了双工具多引擎架构。

#### 3.6.1 工具定义

| 工具名 | 适用场景 | 主引擎 | 降级链 |
|--------|---------|--------|--------|
| `search_web_cn` | 国内农资价格、品种信息 | Bing (cn.bing.com) | Bing → Baidu |
| `search_web_global` | 国际农资行情、前沿品种 | Google | Google → DuckDuckGo → Bing |

**引擎自动降级**：仅网络层错误（DNS解析失败/连接超时）触发降级，HTTP 错误不触发（如 403/429/502 视为引擎正常响应）。

**Proxy 支持**：通过 `undici.ProxyAgent`（Node 18+ 内置）支持 HTTP 代理，适用于开发环境访问国际搜索引擎。生产环境通过专线访问，不依赖代理。

**默认 maxResults**: 30 条，可通过参数覆盖。H5 场景下 prompt 建议限制为 10 条。

#### 3.6.2 引擎实现

| 引擎 | 入口 URL | 解析方式 |
|------|---------|---------|
| Bing | `cn.bing.com/search` | HTML 解析：`#b_results .b_algo` → title/snippet/url |
| Baidu | `www.baidu.com/s` | HTML 解析：`.result.c-container` → title/snippet/url |
| Google | `www.google.com/search` | HTML 解析：`#search .g` → title/snippet/url |
| DuckDuckGo | `html.duckduckgo.com/html/` | HTML 解析：`.result__a` / `.result__snippet` |

文件位置：`src/agents/tools/impl/web-search.ts`（实现）+ `src/agents/tools/schemas/web-search.ts`（Schema）

### 3.7 H5 轻量专家标识规范 → 新增 [2026-06-18]

三个 H5 专家（land-analysis / variety-recommend / cost-accounting）在 prompt 文件中通过四层标识区分于 Agent 对话场景的深度专家：

| 层级 | 位置 | 内容 |
|------|------|------|
| 1. 文件头 JSDoc | 文件首行注释 | `/** H5 轻量推理专家：XXX */` |
| 2. name 字段 | `export const xxxPrompt: ExpertPrompt = { name: "..." }` | `"XXX（H5轻量）"` |
| 3. description 字段 | 同上 | `"【H5轻量】功能描述"` |
| 4. systemPrompt 首句 | systemPrompt 字符串第一行 | `你是 H5 轻量推理专家（XXX），专供小程序/H5 快捷响应。` |

涉及文件：
- `src/agents/prompts/experts/land-analysis.ts`
- `src/agents/prompts/experts/variety-recommend.ts`
- `src/agents/prompts/experts/cost-accounting.ts`

### 3.8 专家 Prompt 公式注入与结构化约束 → 新增 [2026-06-24]

为消除 cost-accounting 与 variety-recommend 之间公式定义重复、以及 LLM 自行编造公式的风险，引入**公式集中管理层**。

#### 3.8.1 公式真相源：`src/agents/prompts/formulas.ts`

```
formulas.ts
├── COST_FORMULAS        ← 成本核算六公式（种子/收入/总收/总成/利润/ROI）
├── VARIETY_FORMULAS     ← 品种推荐六公式（COST_FORMULAS + 评分配比）
└── SEEDING_RATES        ← 播种量表（水稻3/小麦15/玉米2/大豆5/油菜0.3 kg/亩）
```

**关键约束**：
- 公式文本为 TS `const`，编译时通过模板字面量 `${COST_FORMULAS.xxx}` 注入 prompt
- LLM 看到的是展开后的精确公式文本（如 `"种子成本(元/亩) = seedPrice(元/kg) × 播种量(kg/亩)"`），而非变量名
- SEEDING_RATES 以 JSON 格式注入（`JSON.stringify`），LLM 直接 parse
- prompt 中加入"严格按以下公式计算，不得使用其他公式"约束

#### 3.8.2 注入链路

```
formulas.ts (公式常量)
  │
  ├──→ cost-accounting.ts ──→ LLM 看到的 prompt（含展开公式+播种量JSON）
  │    ${COST_FORMULAS.seedCostPerMu}
  │    ${COST_FORMULAS.revenuePerMu}
  │    ...
  │
  └──→ variety-recommend.ts ──→ LLM 看到的 prompt（含展开公式+播种量JSON）
       ${VARIETY_FORMULAS.seedCostPerMu}
       ${VARIETY_FORMULAS.revenuePerMu}
       ${VARIETY_FORMULAS.profitPerMu}
       ${VARIETY_FORMULAS.comprehensiveScore}
```

#### 3.8.3 cost-accounting 输入参数变更

| 旧参数 | 新参数 | 原因 |
|--------|--------|------|
| `pricePerKg` | `grainPrice` | 统一命名，与 SeedCatalog.grainPrice 对齐 |
| `seedCostPerMu` | `seedPrice` | 改为种子单价，LLM 自行 × 播种量算成本 |

种子成本计算职责下沉到 cost-accounting LLM（而非上游 variety-recommend 预估），确保成本核算拥有完整的计算链路和追溯能力。

---

## 四、实施步骤 + 依赖图

```
Phase 0: H5 基础设施（token 改造 + 裁决层 + 握手 + 聊天端点）
  Task 0: credential-store + token-manager source-aware 改造 ──┐
  Task 0.1: token-manager.ts RequestSource 加 "h5" ─────────┤ 依赖 Task 0
  Task 0.2: h5-auth-gateway.ts（sessionId 裁决）────┐          │
  Task 0.3: h5-handshake-thread.ts（线程裁决）──────┤ 可并行   │
  Task 0.4: /api/h5/handshake/route.ts ────────────┤          │
  Task 0.5: /api/h5/agent/route.ts（SSE 聊天）──────┘          │
           │                                                   │
           ▼                                                   │
Phase 1: 专家基础设施（可并行）                                  │
  Task 1: land_analysis prompt ──┐                             │
  Task 2: land_analysis template ─┤                            │
  Task 3: variety_recommend prompt ─┤ 可并行                    │
  Task 4: variety_recommend template ─┤                        │
  Task 5: index.ts 注册 ──────────┘                             │
           │                                                   │
           ▼                                                   │
Phase 2: Registry 注册                                         │
  Task 6: registry.ts 新增 2 专家 + 学科映射                     │
  Task 7: agent-audit-logger.ts 新增审计阶段                     │
           │                                                   │
           ▼                                                   │
Phase 3: REST API 端点（可并行）                                 │
  Task 8: /api/h5/land-analysis/route.ts ──┐                    │
  Task 9: /api/h5/variety-recommend/route.ts ─┤ 可并行          │
  Task 10: /api/h5/cost-accounting/route.ts ──┘                 │
           │                                                   │
           ▼                                                   │
Phase 4: Grounding collection 初始化                            │
  Task 11: expert_land_analysis collection                      │
  Task 12: expert_variety_recommend collection                  │
           │                                                   │
           ▼                                                   │
Phase 5: 验证                                                   │
  Task 13: tsc --noEmit 编译通过                                 │
  Task 14: curl 端到端验证（handshake → 聊天 SSE → 3 个 REST API）│
```

### Phase 0: H5 握手基础设施 + 裁决层 + token 改造 → 修订 [2026-06-18]

- Task 0: 改造 `src/lib/auth/credential-store.ts`
  - `farmServerCredential` 表加 `source` 字段（`"agrisynapse" | "h5"`），`(userId, source)` 复合唯一
  - `saveToken/getValidToken/updateRefreshedToken/deleteToken` 全部加 `source` 参数
  - 新增环境变量 `H5_SERVER_BASE_URL`（H5 后端 token 刷新端点）
- Task 0.1: 改造 `src/lib/auth/token-manager.ts`
  - `RequestSource` 加 `"h5"`
  - `tryRefreshToken(userId, source)` 按 source 路由刷新端点
  - `ensureValidToken(userId, source)` 传递 source 给底层
- Task 0.2: 新建 `src/caijuehub/strategies/h5-auth-gateway.ts`
  - `resolveH5AuthGateway(sessionId)` → 查 H5Session 表 → 返回 userId
- Task 0.3: 新建 `src/caijuehub/strategies/h5-handshake-thread.ts`
  - `resolveH5Thread({ action, userId })` → new 建 chatThread / resume 查最近线程
  - userId 来自 H5 用户体系，与 agrisynapse 隔离
- Task 0.4: 新建 `src/app/api/h5/handshake/route.ts`
  - POST 端点，`handleHandshakeToken({..., source: "h5"})` + userProfile + sessionId
- Task 0.5: 新建 `src/app/api/h5/agent/route.ts`
  - POST 端点，调用 `resolveH5AuthGateway()` → `resolveH5Thread()` → LangGraph `agent.stream()`
  - SSE 流式推送，与 agrisynapse `/api/agent/[hash]` 一致的流式协议

### Phase 1: 专家基础设施

- Task 1: 新建 `src/agents/prompts/experts/land-analysis.ts`
  - 地块分析专家 prompt，聚焦区域气候推理+多地块土壤综合判定
- Task 2: 新建 `src/agents/reports/land-analysis.template.ts`
  - 报告模板：基础信息+土壤信息+气候环境+地块明细
- Task 3: 新建 `src/agents/prompts/experts/variety-recommend.ts`
  - 品种推荐专家 prompt，聚焦基于种子库的品种推荐
- Task 4: 新建 `src/agents/reports/variety-recommend.template.ts`
  - 报告模板：推荐品种列表+收益测算+风险提示
- Task 5: 更新 `src/agents/prompts/experts/index.ts`
  - 注册 land_analysis + variety_recommend 两个新 prompt

### Phase 2: Registry 注册

- Task 6: 更新 `src/agents/experts/registry.ts`
  - DISCIPLINECODE2EXPERTMAP 新增 land_analysis + variety_recommend
  - ANALYSIS_EXPERTS 新增两个专家完整注册
- Task 7: 更新 `src/lib/agent-audit-logger.ts`
  - AgentAuditPhase 新增 `H5_LAND_ANALYSIS`、`H5_VARIETY_RECOMMEND`、`H5_COST_ACCOUNTING`

### Phase 3: REST API 端点

- Task 8: 新建 `src/app/api/h5/land-analysis/route.ts`
  - POST 端点，调用 land_analysis 专家，返回 H5 JSON schema
  - 地块明细在 API 层拼入，不经 LLM
- Task 9: 新建 `src/app/api/h5/variety-recommend/route.ts`
  - POST 端点，调用 variety_recommend 专家 + query_seed_catalog 工具
- Task 10: 新建 `src/app/api/h5/cost-accounting/route.ts`
  - POST 端点，调用 roi_analysis 专家，适配输出为 cost_accounting schema

### Phase 4: Grounding collection 初始化 → 修订 [2026-06-18: P2-1回流]

- Task 11: 初始化 `expert_land_analysis` ChromaDB collection
  - 初始数据来源：从 `docs/大田精准耕播智能决策系统/knowledge/` 上传农业气象+土壤学相关文档
  - 如无现成文档，手动创建基础农业知识文档（区域气候/土壤分类/农业区划常识）后上传
- Task 12: 初始化 `expert_variety_recommend` ChromaDB collection
  - 初始数据来源：种子学+育种学+种质资源学基础文档上传

### Phase 5: 验证

- Task 13: `npx tsc --noEmit` 编译通过
- Task 14: curl 端到端验证（先 handshake 获取 sessionId → 带 X-Session-Id 调用 3 个 API）

---

## 五、验收标准

- [ ] `land_analysis` + `variety_recommend` 两个专家在 registry.ts 注册完整
- [ ] DISCIPLINECODE2EXPERTMAP 包含两个新专家的学科代码映射
- [ ] 3 个 REST API 端点可正常响应 POST 请求
- [ ] API 返回格式符合需求文档定义的 JSON schema
- [ ] AgentAuditPhase 包含 3 个新审计阶段
- [ ] Grounding collection 已初始化（expert_land_analysis + expert_variety_recommend）
- [ ] `npx tsc --noEmit` 编译通过
- [ ] 审计日志可查询（每个 API 调用可通过 traceId 关联审计记录）
- [ ] 错误响应统一格式：`{ error: { code, message }, requestId }`（P2-2）
- [ ] 种子库降级场景可正常响应（返回 data_confidence: "low" + remark）
- [ ] 成本明细 5 类字段完整，缺失字段以 null 填充

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| 需求来源 | `docs/大田精准耕播智能决策系统/knowledge/00-需求/对接瑞丰耘AI智能体小程序-v1.md` | ✅ 已存在 |
| ADD Route | `.qoder/plans/farm-agent-ruifengyun-h5-api-add-route-v1.md` | ✅ 已生成（Step 0.5） |
| Handoff | `.qoder/plans/farm-agent-ruifengyun-h5-api-handoff-v1.md` | ✅ 已生成（Step 0.5） |
| Review | `.qoder/reviews/farm-agent-ruifengyun-h5-api-review-v1.md` | ✅ 已存在 |
| Spec | `.qoder/specs/farm-agent-ruifengyun-h5-api/spec.md` | ✅ 已生成（Step 0.5） |
| Tasks | `.qoder/specs/farm-agent-ruifengyun-h5-api/tasks.md` | ✅ 已生成（Step 0.5） |
| Checklist | `.qoder/specs/farm-agent-ruifengyun-h5-api/checklist.md` | ✅ 已生成（Step 0.5） |
