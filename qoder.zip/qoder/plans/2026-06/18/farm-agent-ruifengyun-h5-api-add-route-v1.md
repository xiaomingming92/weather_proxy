# farm-agent-ruifengyun-h5-api-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"，包含 `check_spec_sync` 文档-代码交叉校验。
>
> **绑定**：Plan: `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v1.md` · Spec: `.qoder/specs/farm-agent-ruifengyun-h5-api/spec.md` · Tasks: `.qoder/specs/farm-agent-ruifengyun-h5-api/tasks.md` · Handoff: `.qoder/plans/farm-agent-ruifengyun-h5-api-handoff-v1.md`

---

## 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: 瑞丰耘H5对接——为H5前端提供握手、SSE流式聊天、3个REST API（地块分析/品种推荐/成本核算），新增2个专家+token管理多端隔离
Task Groups: Phase 0(6 Tasks) + Phase 1(5 Tasks) + Phase 2(2 Tasks) + Phase 3(3 Tasks) + Phase 4(2 Tasks) + Phase 5(2 Tasks)

逐组业务价值判定:
  Phase 0 (token改造+裁决+握手+聊天): 能用 — H5可独立完成握手+聊天，且token隔离生效。独立产生"智慧农业助手"可用态
  Phase 1 (专家基础设施): 不能用 — 仅prompt文件存在，无API入口，H5无感知
  Phase 2 (Registry注册): 不能用 — 仅注册生效，无API入口
  Phase 3 (REST API): 能用 — 3个API端点可独立被H5调用，独立产生"新增生产计划AI能力"可用态
  Phase 4 (Grounding): 不能用 — 仅collection初始化，无功能入口
  Phase 5 (验证): 不能用 — 仅验证步骤，无独立价值

合并: Phase 1+Phase 2 与 Phase 3 合并（无API入口的prompt/registry无法独立交付）
       Phase 4 与 Phase 3 合并（Grounding为API提供知识支撑）
       Phase 5 附着于各轮验证

判定结论: 需要 2 轮（2 个原子闭包）

第1轮（原子闭包1）: Phase 0 — 业务功能: H5握手+sessionId管理+SSE流式聊天+token多端隔离
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
第2轮（原子闭包2）: Phase 1+2+3+4 — 业务功能: 2个新专家+3个REST API+Grounding初始化
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全。

**输入**：
- Plan: `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v1.md`
- Review: `.qoder/reviews/farm-agent-ruifengyun-h5-api-plan-v1-review-v1.md`
- 需求文档: `docs/大田精准耕播智能决策系统/knowledge/00-需求/对接瑞丰耘AI智能体小程序-v1.md`

**动作**：
1. 确认 Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
2. 调用 `find_related_docs` 检索受影响的架构/规范/需求文档
3. 按检索结果更新项目文档（或声明无需更新）
4. 确认 Handoff 就绪

**产出**：
- [x] 验证并更新项目状态：Specs 三元组路径确认 → `specs/farm-agent-ruifengyun-h5-api/`
- [x] 验证并更新项目状态：项目文档已更新（或无需更新声明已记录）
- [x] 验证并更新项目状态：Handoff 就绪 → `farm-agent-ruifengyun-h5-api-handoff-v1.md`

### §0.8 DPS 闸门

调用 `check_dps({ planKeyword: "ruifengyun-h5-api" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |
| 70–84 | 🟡 | 回退补齐短板 |
| < 70 | 🔴 | 回退细化 Plan |

- [x] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**目的**：定义本次变更涉及的所有审计阶段，扩展 `AgentAuditPhase`。

**输入**：
- Plan §3 的 Task 列表
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase` 联合类型

**动作**：
1. 新增审计阶段：`H5_HANDSHAKE` / `H5_LAND_ANALYSIS` / `H5_VARIETY_RECOMMEND` / `H5_COST_ACCOUNTING` / `H5_AGENT_CHAT` / `H5_AUTH_GATEWAY`
2. 在 `AgentAuditPhase` 联合类型中新增字面量

**产出**：
- [x] 验证并更新项目状态：审计阶段已同步到 tasks.md Phase 2

| Phase | 使用场景 | Task |
|-------|---------|------|
| `H5_HANDSHAKE` | H5 握手端点 | Task 0.4 |
| `H5_AGENT_CHAT` | H5 SSE 流式聊天 | Task 0.5 |
| `H5_LAND_ANALYSIS` | 地块分析 API | Task 8 |
| `H5_VARIETY_RECOMMEND` | 品种推荐 API | Task 9 |
| `H5_COST_ACCOUNTING` | 成本核算 API | Task 10 |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用。

**动作**：确认三通道输出正常

**产出**：
- [x] 验证并更新项目状态：`agentAudit()` 通道确认可用（三通道：console + file + AuditLog）

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan 的 Task 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

### §3.0 前置守卫

调用 `check_add_route_status` 确认 add-route 文件有效存在。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 0 | credential-store source 改造 | `credential-store.ts` | credentialAudit | — | 无 | ✅ |
| 0.1 | token-manager source 路由 | `token-manager.ts` | tokenManagerAudit | — | Task 0 | ✅ |
| 0.2 | h5-auth-gateway | `h5-auth-gateway.ts` | agentAudit("H5_AUTH_GATEWAY") | — | Task 0 | ✅ |
| 0.3 | h5-handshake-thread | `h5-handshake-thread.ts` | agentAudit("H5_THREAD_NEW/RESUME") | — | Task 0 | ✅ |
| 0.4 | /api/h5/handshake | `handshake/route.ts` | agentAudit("H5_HANDSHAKE") | H5_HANDSHAKE | Task 0.1 | ✅ |
| 0.5 | /api/h5/agent | `agent/route.ts` | agentAudit("H5_AGENT_CHAT") | H5_AGENT_CHAT | Task 0.2+0.3 | ✅ |
| 1 | land-analysis prompt | `land-analysis.ts` | 无（静态文件） | — | 无 | ✅ |
| 2 | land-analysis template | `land-analysis.template.ts` | 无（静态文件） | — | 无 | ✅ |
| 3 | variety-recommend prompt | `variety-recommend.ts` | 无（静态文件） | — | 无 | ✅ |
| 4 | variety-recommend template | `variety-recommend.template.ts` | 无（静态文件） | — | 无 | ✅ |
| 4.1 | cost-accounting prompt | `cost-accounting.ts` | 无（静态文件） | — | 无 | ✅ |
| 4.2 | web-search 双工具实现 | `impl/web-search.ts` | 无（工具注册） | — | 无 | ✅ |
| 4.3 | web-search schema | `schemas/web-search.ts` | 无（类型定义） | — | 无 | ✅ |
| 4.4 | Farm-Server API 客户端 | `farm-api/massif.ts` + `client.ts` | 无（API封装） | — | 无 | ✅ |
| 5 | index.ts 注册 | `index.ts` | 无（结构变更） | — | Task 1-4 | ✅ |
| 6 | registry.ts | `registry.ts` | 无（注册表） | — | Task 5 | ✅ |
| 7 | agent-audit-logger.ts | `agent-audit-logger.ts` | 无（类型扩展） | — | 无 | ✅ |
| 8 | /api/h5/land-analysis | `land-analysis/route.ts` | agentAudit("H5_LAND_ANALYSIS") | H5_LAND_ANALYSIS | Phase 0+Phase 2 | ✅ |
| 9 | /api/h5/variety-recommend | `variety-recommend/route.ts` | agentAudit("H5_VARIETY_RECOMMEND") | H5_VARIETY_RECOMMEND | Phase 0+Phase 2 | ✅ |
| 10 | /api/h5/cost-accounting | `cost-accounting/route.ts` | agentAudit("H5_COST_ACCOUNTING") | H5_COST_ACCOUNTING | Phase 0+Phase 2 | ✅ |
| 11 | expert_land_analysis collection | ChromaDB | agentAudit("GROUNDING_INIT") | — | Task 1 | N/A |
| 12 | expert_variety_recommend collection | ChromaDB | agentAudit("GROUNDING_INIT") | — | Task 3 | N/A |
| 13 | tsc --noEmit | — | 无 | — | Phase 0-3 | ✅ |
| 14 | curl 端到端 | — | agentAudit("H5_E2E") | — | Task 13 | ⬜ |

### 依赖拓扑

```
Task 0 ──→ Task 0.1 ──→ Task 0.4
   │         │
   ├──→ Task 0.2 ──┐
   │               ├──→ Task 0.5
   └──→ Task 0.3 ──┘

Task 1/2/3/4 ──→ Task 5 ──→ Task 6

Task 7（独立，可并行）

Phase 0 + Phase 2 ──→ Task 8/9/10（可并行）

Task 8/9/10 + Task 11 + Task 12 ──→ Task 13 ──→ Task 14
```

---

## Step 4：审计数据验证

**动作**：
1. `npx tsc --noEmit`
2. `npm run lint`
3. 调用 `check_phase_symmetry`
4. 调用 `check_failure_path`

**产出**：
- [x] `tsc --noEmit` 通过
- [x] `npm run lint` 通过
- [x] 阶段对称性验证通过
- [x] 失败路径审计等价验证通过

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "ruifengyun-h5-api" })`。

- [ ] RAHS 已通过（≥ 90），可进入 Step 5

---

## Step 5：AI 自动合规检查

**动作**：对每个修改文件调用 `check_add_compliance`

**产出**：
- [ ] 合规报告已生成

---

## Step 8：收敛判断 + Handoff 更新

**动作**：
1. 收敛判断：全部 [T] 项通过 + RAHS ≥ 90
2. 更新 Handoff §7/§8/§9
3. Step 0 第二阶段：回架构文档校准
4. ADD-7 回查

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `prisma/schema.prisma` | MODIFY | 0 | DATA_MODEL | ✅ |
| `src/lib/auth/credential-store.ts` | MODIFY | 0 | COMPONENT | ✅ |
| `src/lib/auth/token-manager.ts` | MODIFY | 0.1 | COMPONENT | ✅ |
| `src/caijuehub/strategies/h5-auth-gateway.ts` | CREATE | 0.2 | COMPONENT | ✅ |
| `src/caijuehub/strategies/h5-handshake-thread.ts` | CREATE | 0.3 | COMPONENT | ✅ |
| `src/app/api/h5/handshake/route.ts` | CREATE | 0.4 | COMPONENT | ✅ |
| `src/app/api/h5/agent/route.ts` | CREATE | 0.5 | COMPONENT | ✅ |
| `src/agents/prompts/experts/land-analysis.ts` | CREATE | 1 | PROMPT | ✅ |
| `src/agents/reports/land-analysis.template.ts` | CREATE | 2 | REPORT_TEMPLATE | ✅ |
| `src/agents/prompts/experts/variety-recommend.ts` | CREATE | 3 | PROMPT | ✅ |
| `src/agents/reports/variety-recommend.template.ts` | CREATE | 4 | REPORT_TEMPLATE | ✅ |
| `src/agents/prompts/experts/cost-accounting.ts` | CREATE | 4.1 | PROMPT | ✅ |
| `src/agents/tools/impl/web-search.ts` | CREATE | 4.2 | TOOL | ✅ |
| `src/agents/tools/schemas/web-search.ts` | CREATE | 4.3 | TOOL_SCHEMA | ✅ |
| `src/lib/farm-api/massif.ts` | CREATE | 4.4 | API_CLIENT | ✅ |
| `src/lib/farm-api/client.ts` | CREATE | 4.4 | API_CLIENT | ✅ |
| `src/agents/prompts/experts/index.ts` | MODIFY | 5 | REGISTRY | ✅ |
| `src/agents/experts/registry.ts` | MODIFY | 6 | REGISTRY | ✅ |
| `src/lib/agent-audit-logger.ts` | MODIFY | 7 | AUDIT | ⬜ |
| `src/app/api/h5/land-analysis/route.ts` | CREATE | 8 | COMPONENT | ✅ |
| `src/app/api/h5/variety-recommend/route.ts` | CREATE | 9 | COMPONENT | ✅ |
| `src/app/api/h5/cost-accounting/route.ts` | CREATE | 10 | COMPONENT | ✅ |
