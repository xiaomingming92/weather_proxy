# farm-agent Expert Deep Pipeline 运行时修复 — 交接手册

> **适用场景**：单轮变更，Task 1-5 共同构成"专家技能卡片 deep pipeline 渲染修复"的最小业务闭包。

---

## 1. 交接前状态

- `resolveThinkingLevel(intent)` 仅检查 `intent === "chat"`，技能卡片触发时 `explicitExpertId` 被忽略，路由到 fast 路径
- `intentionNode` 两处 tool_calls 返回路径不携带 `currentTask.query`，导致 retrieval 节点 `searchQuery = undefined`，RAG 空查询
- agrisynapse `LlmChatView.vue` 10 个渲染元素平铺于单一 `llm-page__chat-bubble--assistant` 容器，中间态和最终态混排
- 证据来源未区分渲染（expert / knowledge / tool 显示相同样式）
- 无深度思考折叠容器

## 2. 交接后状态（目标）

- `resolveThinkingLevel(intent, explicitExpertId?)` 增加专家感知：`explicitExpertId` 非空时强制 `"deep"`
- `intentionNode` 4 处调用全部透传 `explicitExpertId`
- `intentionNode` 两处 tool_calls return 均携带 `currentTask.query`，第二轮 retrieval 查询非空
- agrisynapse GUI 三层语义容器：
  - `.chat-deep-thinking`: 深度思考折叠容器（RAG spinner + 证据条 + 工具调用）
  - `.chat-bubble-content`: 纯文本气泡（唯一 bubble 样式）
  - `.chat-bubble-final`: 最终态面板（证据链 + 推理 + 裁决 + 交互 + 工具按钮）
- 深度思考容器流式中自动展开，流式完自动收起为单行摘要
- 证据来源三源区分：expert（brain 图标 + summary + collectionName badge）；knowledge（文档图标 + documentName + summary + 相关度进度条）；tool（工具图标 + toolName + summary + 可展开数据表格）
- 工具结果以原生 `<table>` 全宽展示（点击展开/折叠）
- SSE `evidence_found` 事件携带 documentName, collectionName, toolName, data, expertIds 字段
- 流式中管线文本气泡可见（非 hidden），流式后无重复气泡
- 最终态 action-bar 按需展示"导出专家报告"按钮（检测 evidence 中 expertIds 存在性）
- farm-agent + agrisynapse 编译零错误

## 3. 改动清单

| # | 仓库 | 文件 | 操作 | 内容 | 状态 |
|---|------|------|------|------|------|
| 1 | farm-agent | `src/caijuehub/strategies/thinking-level.ts` | 修改 | 增加 `explicitExpertId` 参数，非空强制 deep | ✅ |
| 2 | farm-agent | `src/agents/nodes/intention.ts` | 修改 | 4 处透传 explicitExpertId + 2 处 tool_calls return 补充 currentTask.query | ✅ |
| 3 | agrisynapse | `src/views/llm/components/LlmChatView.vue` | 修改 | 三层语义容器 + 深度思考折叠 + 证据三源渲染 + 流式气泡修复 + 导出报告按钮 | ✅ |
| 4 | agrisynapse | scss (inline in .vue) | 修改 | 深度思考折叠动画 + 最终态面板排版 + 证据来源特定样式 + 原生表格 | ✅ |
| 5 | farm-agent | `src/agents/stream-bus.ts` | 修改 | EvidenceFoundEvent.evidence 增加 documentName/collectionName/toolName/data/expertIds | ✅ |
| 6 | farm-agent | `src/agents/node-stream-controller.ts` | 修改 | evidenceFound() 参数同步扩展 | ✅ |
| 7 | farm-agent | `src/agents/nodes/retrieval.ts` | 修改 | evidenceFound() 调用传入 documentName/collectionName/expertIds | ✅ |
| 8 | farm-agent | `src/stores/chat-store.ts` | 修改 | StreamingEvidence 接口同步扩展 | ✅ |
| 9 | farm-agent | `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md` | 新建 | Plan 文档 | ✅ |
| 10 | farm-agent | `.qoder/reviews/farm-agent-expert-deep-pipeline-runtime-fix-review-v1.md` | 新建 | Review 文档 | ✅ |
| 11 | farm-agent | `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-add-route-v1.md` | 新建 | ADD Route | ✅ |
| 12 | farm-agent | `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-handoff-v1.md` | 新建 | 本 Handoff | ✅ |
| 13 | farm-agent | `.qoder/specs/farm-agent-expert-deep-pipeline-runtime-fix/spec.md` | 新建 | 功能规格 | ✅ |
| 14 | farm-agent | `.qoder/specs/farm-agent-expert-deep-pipeline-runtime-fix/tasks.md` | 新建 | Task 清单 | ✅ |
| 15 | farm-agent | `.qoder/specs/farm-agent-expert-deep-pipeline-runtime-fix/checklist.md` | 新建 | 验收清单 | ✅ |

## 4. 回滚方案

### 代码回滚

```bash
# farm-agent 回滚 (Task 1-3)
cd /home/xmm/ai/farm-agent
git revert <commit-task-3> <commit-task-2> <commit-task-1>

# agrisynapse 回滚 (Task 4)
cd /home/xmm/ai/agrisynapse
git revert <commit-task-4>
```

### 文档清理

```bash
rm .qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md
rm .qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-add-route-v1.md
rm .qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-handoff-v1.md
rm .qoder/reviews/farm-agent-expert-deep-pipeline-runtime-fix-review-v1.md
rm -rf .qoder/specs/farm-agent-expert-deep-pipeline-runtime-fix/
```

### 回滚后状态

- `resolveThinkingLevel` 回退为仅检查 intent
- GUI 回退为单一容器平铺渲染
- 技能卡片对话回退为 fast 路径（仅纯文本）

## 5. 验证方式

### 已完成验证（编译期）

| 验证项 | 方式 | 结果 |
|--------|------|------|
| Farm-agent 编译 | `npx tsc --noEmit` | ✅ 零错误 |
| Agrisynapse 编译 | `npx vue-tsc --noEmit` | ✅ 零类型错误（仅 tsconfig 弃用警告） |
| ADD-2 阶段对称性 | `check_phase_symmetry` on intention.ts | ✅ 通过（event-based 模式，7 处 agentAudit） |
| ADD-6 失败路径 | `check_failure_path` on intention.ts | ✅ 通过（catch 块含 agentAudit 调用） |
| ADD-1/3 合规 | `check_add_compliance` on intention.ts | ✅ 4/4 通过（event-based 模式） |
| RAHS 健康度 | `check_rahs` | 🟡 87（编译期四维满分，E2E 项待运行时） |
| DOM 语义结构 | 代码审查 vs Plan DOM 图 | ✅ 三层容器对 Plan 100% |
| 证据来源图标 | 代码审查 | ✅ expert/knowledge/tool 三类图标 |
| 深度思考动画 | 代码审查 | ✅ spin + slide-down @keyframes |

### 待运行时验证（E2E）

| 验证项 | 方式 | 预期 |
|--------|------|------|
| 技能卡片 RAG 查询 | 检查 agent-audit.log | `RETRIEVAL_DECISION` 含非空查询 |
| fallbackFlags.ragEmpty | 检查 agent-audit.log | `fallbackFlags.ragEmpty` 不为 true |
| reasoning 无空跳过 | 检查 agent-audit.log | reasoning 不输出 "无证据, 跳过推理" |
| GUI 深度思考折叠 | 打开技能卡片对话 | 流式中看到 "深度思考中..." 展开；完成后自动收起 |
| GUI 最终态面板 | 对话完成后 | 看到证据链 + 推理 + 裁决 + 交互点 |
| GUI 证据来源区分 | 对话完成后 | expert 有 brain 图标 + collectionName badge；knowledge 有文档图标 + documentName + 相关度进度条；tool 有工具图标 + toolName + 可展开表格 |
| GUI 导出报告按钮 | 对话完成后 | 有 expertIds 时显示"导出专家报告"按钮，点击发送报告生成请求 |
| 闲聊不受影响 | 普通对话 | 无深度思考容器，仅文本气泡 |
| 技能卡片完整管线 | 技能卡片对话 | intention → toolNode → intention → retrieval → reasoning → verdict → response |

## 6. ADD-7 审计

| 文件 | 仓库 | targetType | action | 状态 |
|------|------|-----------|--------|------|
| `src/caijuehub/strategies/thinking-level.ts` | farm-agent | STRATEGY | MODIFY | ✅ |
| `src/agents/nodes/intention.ts` | farm-agent | AGENT_NODE | MODIFY | ✅ |
| `src/views/llm/components/LlmChatView.vue` | agrisynapse | COMPONENT | MODIFY | ✅（前端，非 farm-agent ADD-7 范围） |
| scss (inline in .vue) | agrisynapse | STYLE | MODIFY | ✅（前端，非 farm-agent ADD-7 范围） |
| `src/agents/stream-bus.ts` | farm-agent | INTERFACE | MODIFY | ✅ |
| `src/agents/node-stream-controller.ts` | farm-agent | AGENT_NODE | MODIFY | ✅ |
| `src/agents/nodes/retrieval.ts` | farm-agent | AGENT_NODE | MODIFY | ✅ |
| `src/stores/chat-store.ts` | farm-agent | STORE | MODIFY | ✅ |
| `.qoder/plans/` | farm-agent | DOC | NEW | ✅ |
| `.qoder/reviews/` | farm-agent | DOC | NEW | ✅ |
| `.qoder/specs/` | farm-agent | DOC | NEW | ✅ |

## 7. 恢复上下文审计查询（新 AI Session 首次启动必读）

- 第一步：按 targetId 搜索代码文件改动
  ```
  query_audit_logs({ targetId: "src/caijuehub/strategies/thinking-level.ts" })
  query_audit_logs({ targetId: "src/agents/nodes/intention.ts" })
  ```
- 第二步：搜索文档变更记录
  ```
  query_audit_logs({ action: "DOC_CREATED", keyword: "expert-deep-pipeline" })
  ```
- 第三步：一键恢复
  ```
  query_audit_logs({ keyword: "expert-deep-pipeline" })
  ```
