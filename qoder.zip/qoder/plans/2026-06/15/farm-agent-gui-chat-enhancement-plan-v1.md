# farm-agent-gui-chat-enhancement-plan-v1

> Plan 回答"改什么、为什么改、改哪里"。

## PLAN 元信息

- **Plan 名称**: farm-agent-gui-chat-enhancement-v1
- **启动时间**: 2026-06-15T10:30:00+08:00
- **范围**: 仅 agrisynapse 神经元 GUI + farm-agent 后端 API（不碰 farm-agent ChatPanel/ChatContainer）
- **关联文档**:
  - ADD Route: `.qoder/plans/farm-agent-gui-chat-enhancement-add-route-v1.md`
  - Handoff: `.qoder/plans/farm-agent-gui-chat-enhancement-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-gui-chat-enhancement-review-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState |
|-----|-----------|--------|------------|-----------|
| `src/stores/chat-store.ts` | COMPONENT | COMPONENT_UPDATED | updateThreadTitle 仅本地 | 调用 PATCH API 落库 |
| `src/app/api/agent/[hash]/route.ts` | API | API_UPDATED | handleThreadGET 不返回 metadata | 返回 metadata |
| `src/app/api/agent/[hash]/route.ts` | API | API_UPDATED | 无 threads 列表 action | 新增 action=threads |
| agrisynapse: `agentChat.ts` | COMPONENT | COMPONENT_UPDATED | 无 threads/interactionPoint | 新增三状态 + dispatch |
| agrisynapse: `LlmSidebar.vue` | COMPONENT | COMPONENT_UPDATED | 硬编码 3 条历史 | 动态 threads prop |
| agrisynapse: `LlmChatView.vue` | COMPONENT | COMPONENT_UPDATED | 无交互点渲染 | 新增交互点 section |
| agrisynapse: `index.vue` | COMPONENT | COMPONENT_UPDATED | navSections 静态 | 动态 computed |
| agrisynapse: `api/agent/index.ts` | COMPONENT | COMPONENT_UPDATED | 无 getThreads | 新增 getThreads |

---

## 一、背景与目标

### 1.1 问题现状

agrisynapse（神经元前端 GUI）存在四个缺陷 + 流式渲染空白：

1. **历史对话硬编码 3 条**：`LlmSidebar` navSections 写死 3 个 static entry，且 farm-agent `[hash]/route.ts` 缺少 `action=threads` 列表端点
2. **对话标题编辑不落库**：farm-agent `chat-store.ts` 的 `updateThreadTitle` 只改本地 state，不调 PATCH
3. **交互点从不渲染**：agrisynapse `agentChat._dispatchEvent` 不处理 `structured_update` 中的 `interactionPoint`，`LlmChatView` 无交互点模板
4. **历史消息结构化数据丢失**：`handleThreadGET` 返回 messages 时不带 `metadata`，导致 verdict/evidence 等历史数据丢失
5. **流式渲染只输出纯文本 token**：神经元 SSB 流式输出期间，RAG 搜索状态、证据链、推理路径、置信度等 GUI 元素从未渲染。`rag_search` 事件在 dispatch 中空转（只写注释），`evidenceChain`/`reasoningPath` 存进 state 却不渲染模板

### 1.2 目标

- agrisynapse 侧边栏「历史对话」动态拉取用户全部线程
- 对话标题编辑后持久化落库
- agrisynapse 流式输出时渲染：RAG 搜索状态、证据条、工具调用、推理路径、证据链、置信度、交互点
- 历史消息恢复时保留结构化数据（verdict/evidence/interaction）

---

## 二、方案选型

单方案——修复 agrisynapse 侧缺失功能 + farm-agent 后端补全 API。

| 维度 | 说明 |
|------|------|
| 不碰 farm-agent ChatPanel/ChatContainer | ✅ 用户明确要求 |
| 不改 SSE 协议 | ✅ 现有 StreamEvent 已包含 interactionPoint |
| 不改 Prisma | ✅ chatPersistence 已有 getThreadsByUser |

---

## 三、架构设计

### 3.1 流式渲染清单（LlmChatView 模板）

SSB 流式输出期间，消息气泡内需渲染以下结构化 GUI 元素（按出现顺序）：

| 序号 | GUI 元素 | 触发 SSE 事件 | 渲染时机 | 状态 |
|------|---------|-------------|---------|------|
| 1 | RAG 搜索状态 | `rag_search` | 检索节点开始 → 知识库搜索完成（`rag_result`） | ✅ 新增 |
| 2 | 证据条 | `evidence_found` | 检索节点逐条返回 | ✅ 已有 |
| 3 | 工具调用 | `tool_call` / `tool_result` | 推理/工具节点执行期间 | ✅ 已有 |
| 4 | 推理路径 | `structured_update.data.reasoningPath` | response 节点结束时一次性输出 | ✅ 新增 |
| 5 | 证据链 | `structured_update.data.evidenceChain` | response 节点结束时一次性输出 | ✅ 新增 |
| 6 | 置信度 | `structured_update.data.verdict.confidence` | response 节点结束时（含 final_confidence） | ✅ 已有 |
| 7 | 裁决结论 | `structured_update.data.verdict.conclusion` | response 节点结束时 | ✅ 已有 |
| 8 | 交互点 | `structured_update.data.interactionPoint` | response 节点结束时 | ✅ 已有 |

```
farm-agent response node
  │  structured_update { interactionPoint: {...} }
  ▼
[hash]/route.ts → SSE → agrisynapse
  │
  ▼
agentChat._dispatchEvent:
  case "structured_update":
    if (event.data.interactionPoint) msg.interactionPoint = event.data.interactionPoint
  │
  ▼
LlmChatView template:
  <div v-if="msg.interactionPoint" class="llm-page__interaction">
    <p>{{ msg.interactionPoint.description }}</p>
    <button v-for="opt in msg.interactionPoint.options" @click="handleInteractionSelect(opt.label)">
      {{ opt.label }} — {{ opt.reason }}
    </button>
  </div>
```

### 3.2 结构化数据流（修复后）

```
agrisynapse GET /api/agent/{hash}?action=threads&userId=...
  │
  ▼
[hash]/route.ts: handleThreadsGET → chatPersistence.getThreadsByUser(userId)
  │
  ▼
agrisynapse agentChat.fetchThreads → LlmSidebar.historyThreads
```

---

### 3.3 历史对话列表数据流

```
agrisynapse GET /api/agent/{hash}?action=threads&userId=...
  │
  ▼
[hash]/route.ts: handleThreadsGET → chatPersistence.getThreadsByUser(userId)
  │
  ▼
agrisynapse agentChat.fetchThreads → LlmSidebar.historyThreads
```

---

## 四、实施步骤 + 依赖图

> **2026-06-15 更新**：新增 Task 0 流式渲染（弥补 LlmChatView 只输出纯文本的缺陷）。
>
> RAG 搜索状态无 UI 的根本原因：`_dispatchEvent` 的 `case "rag_search"` 只有一行空注释，从未设置 `msg.ragSearching`。证据链/推理路径虽有 dispatch 存储但模板从不渲染。

```
Task 0 (流式渲染) ─── 独立，不阻塞后续
Task 1 (标题 PATCH) ──┐
Task 2 (threads API) ─┤ 可并行
Task 3 (metadata修复)─┘
    │
    ▼
Task 4 (agrisynapse store + API)
    │
    ▼
Task 5 (agrisynapse GUI 渲染)
    │
    ▼
Task 6 (tsc 验证)
```

### Task 0: 流式渲染 GUI 元素补全
- 文件：`agentChat.ts`、`LlmChatView.vue`、`api/agent/types.ts`
- 改动：
  (a) `StreamingMessage` 新增 `ragSearching?: string`
  (b) `_dispatchEvent` 修复 `rag_search`（set msg.ragSearching）+ 新增 `rag_result`（clear msg.ragSearching）
  (c) `LlmChatView` 模板新增 RAG 搜索状态、推理路径、证据链三个 section
  (d) 配套 CSS 动画（rag dots、reasoning steps、evidence chain items）

### Task 1: farm-agent updateThreadTitle PATCH 落库
- 文件：`src/stores/chat-store.ts`
- 改动：`updateThreadTitle` 内部 `fetch PATCH /api/agent/chat/threads`

### Task 2: farm-agent [hash] route 新增 threads 列表
- 文件：`src/app/api/agent/[hash]/route.ts`
- 改动：GET 新增 `action=threads` → `chatPersistence.getThreadsByUser(userId)`

### Task 3: farm-agent [hash] route handleThreadGET 带 metadata
- 文件：`src/app/api/agent/[hash]/route.ts`
- 改动：`handleThreadGET` 返回 messages 时包含 `metadata` 字段

### Task 4: agrisynapse store + API 对接
- 文件：`agentChat.ts`、`api/agent/index.ts`
- 改动：
  (a) `StreamingMessage` 类型新增 `interactionPoint?`
  (b) `_dispatchEvent` 新增 `interactionPoint` 处理
  (c) 新增 `threads`/`fetchThreads`/`switchThread` state+actions
  (d) API 新增 `getThreads(userId)`、`getThread` 解析 metadata

### Task 5: agrisynapse LlmSidebar + LlmChatView 渲染
- 文件：`LlmSidebar.vue`、`LlmChatView.vue`、`index.vue`
- 改动：
  (a) `LlmSidebar` 新增 `historyThreads` prop
  (b) `LlmChatView` 新增交互点 section 模板
  (c) `index.vue` navSections 历史对话部分改为 computed

### Task 6: tsc 编译 + 构建验证

---

## 五、验收标准

- [ ] 编辑对话标题后刷新页面，标题保持
- [ ] agrisynapse 侧边栏历史对话显示用户全部线程（动态加载）
- [ ] 流式输出期间渲染 **RAG 搜索状态**（检索知识库动画）
- [ ] 流式输出期间渲染 **证据条**（检索节点逐条返回）
- [ ] 流式输出期间渲染 **工具调用**（执行中/完成状态）
- [ ] 流式输出后渲染 **推理路径**（步骤编号 + 描述）
- [ ] 流式输出后渲染 **证据链**（来源 + 内容 + 相关度）
- [ ] 流式输出后渲染 **置信度**（final_confidence 百分比）
- [ ] 流式输出后渲染 **交互点**（选项按钮 + 确认）
- [ ] 加载历史对话时 verdict/evidence 数据恢复
- [ ] `npx tsc --noEmit` 零错误（两个项目各自）

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/farm-agent-gui-chat-enhancement-add-route-v1.md` |
| Handoff | `.qoder/plans/farm-agent-gui-chat-enhancement-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-gui-chat-enhancement-review-v1.md` |
| Spec | `.qoder/specs/farm-agent-gui-chat-enhancement/spec.md` |
| Tasks | `.qoder/specs/farm-agent-gui-chat-enhancement/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-gui-chat-enhancement/checklist.md` |
