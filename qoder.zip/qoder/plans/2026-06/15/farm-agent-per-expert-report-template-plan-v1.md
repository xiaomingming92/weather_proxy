# Plan: per-expert 报告模板体系

> **来源**: [runtime review §F6](../reviews/farm-agent-tools-pipeline-review-runtime-v1.md#f6-p1-报告生成无-per-expert-模板所有专家共用同一骨架且缺失-llm-对话回复)
> **类型**: 功能增强 | **修订**: 2026-06-15

## PLAN 元信息

- **关联文档**:
  - Review: `.qoder/reviews/farm-agent-tools-pipeline-review-runtime-v1.md` (F6)
  - 参考: `src/agents/experts/registry.ts`（专家定义）
  - 参考: `src/services/report-generator.ts`（报告生成管线）
  - 参考: `src/agents/types/structured-output.ts`（StructuredAgentResponse / DisplayContent）

---

## 1. 问题

`buildReportMarkdown` 对所有 12 个专家输出完全相同的骨架（裁决结论 → 激活专家 → 推理路径 → 证据链 → 交互点 → 运行时输入），且 `displayContent.summary`（LLM 对话回复正文）完全未写入报告。导出的是"骨架 dump"而非"可交付文档"。

## 2. 根因

```
1. report-generator.ts:43 是单一硬编码 switch，不感知 analysisContext.activeExperts
2. registry.ts AnalysisExpert 缺少 reportTemplate 字段
3. displayContent 有数据但 generator 从未引用
```

## 3. 修复方案

### 3.1 核心设计：`reportTemplate` 字段驱动模板分发

在 `AnalysisExpert` 类型中新增 `reportTemplate` 字段，在 `buildReportMarkdown` 中按 expertId 分发不同模板结构。未配置 `reportTemplate` 的专家走现有通用模板（向后兼容）。

### 3.2 类型扩展

```typescript
// registry.ts — AnalysisExpert 新增字段
export interface ReportSectionDef {
  /** displayContent.sections 中的 type，或固定文本标题 */
  title: string
  /** 数据来源 */
  source: "displayContent" | "verdict" | "reasoningPath" | "evidenceChain" | "interactionPoint" | "runtimeInputs" | "activeExperts" | "static"
  /** displayContent 场景下匹配的 section.type（conclusion/evidence/reasoning 等） */
  sectionType?: string
  /** 固定文本（source=static 时） */
  staticContent?: string
  /** 是否必需 */
  required?: boolean
}

export interface AnalysisExpert {
  // ... 现有字段 ...
  /** per-expert 报告模板：章节定义列表，按序渲染 */
  reportTemplate?: ReportSectionDef[]
}
```

### 3.3 各专家模板设计

#### weekly_report（周报）— 汇总型

| 章节 | 来源 | 说明 |
|------|------|------|
| 农情周报 | static | 标题页 |
| 农场气象综述 | displayContent → conclusion | LLM 输出的气象结论 |
| 土壤墒情趋势 | displayContent → evidence | LLM 中引用的墒情数据 |
| 虫情监测汇总 | displayContent → evidence | LLM 中引用的虫情数据 |
| 综合决策建议 | displayContent → action_steps | LLM 的建议行动 |
| 风险提示 | verdict → risks | 裁决层的风险评估 |
| 推理路径 | reasoningPath → steps | 系统推理过程 |
| 数据来源 | evidenceChain → evidences | 原始证据列表 |

#### daily_report（日报）— 汇总型

同上但窗口为 1 天。

#### pest_risk（虫害风险评估）

| 章节 | 来源 |
|------|------|
| 虫害风险评估报告 | static |
| 风险评估结论 | displayContent → conclusion |
| 气象条件分析 | displayContent → evidence |
| 虫情数据分析 | displayContent → evidence |
| 风险等级与概率 | verdict → conclusion + confidence |
| 防治建议 | displayContent → action_steps |
| 证据来源 | evidenceChain → evidences |

#### growth_report（生长报告）

| 章节 | 来源 |
|------|------|
| 作物生长报告 | static |
| 当前生长状态 | displayContent → conclusion |
| 气象影响分析 | displayContent → evidence |
| 土壤墒情评估 | displayContent → evidence |
| 产量趋势预测 | displayContent → reasoning |
| 管理建议 | displayContent → action_steps |

#### weather_impact（气象影响分析）

| 章节 | 来源 |
|------|------|
| 气象影响分析报告 | static |
| 气象条件总览 | displayContent → conclusion |
| 对作物影响评估 | displayContent → evidence |
| 风险预警 | verdict → risks |
| 应对建议 | displayContent → action_steps |

#### 其余 6 个核心专家（crop_compare / roi_analysis / nutrition_diagnose / planting_advice / work_plan / machinery_dispatch）

沿用通用模板（裁决结论 → 激活专家 → 推理路径 → 证据链 → 交互点 → 运行时输入），但新增 **LLM 对话回复** 章节（displayContent → summary）。

### 3.4 `buildReportMarkdown` 改造

```typescript
export function buildReportMarkdown(
  structured: StructuredAgentResponse,
  analysisContext: AnalysisContext | null,
): string {
  const primaryExpert = analysisContext?.activeExperts?.[0]
  const expert = primaryExpert ? ANALYSIS_EXPERTS[primaryExpert.expertId] : null
  const template = expert?.reportTemplate

  if (template && template.length > 0) {
    return buildTemplatedMarkdown(structured, analysisContext, template, expert!)
  }
  return buildGenericMarkdown(structured, analysisContext)
}
```

`buildTemplatedMarkdown` 按 `ReportSectionDef[]` 顺序渲染每个章节，根据 `source` 从对应结构化数据中提取内容。

### 3.5 `displayContent` 纳入报告

关键改动：`buildTemplatedMarkdown` 和 `buildGenericMarkdown` 都要在报告顶部输出 `displayContent.summary`（即 LLM 的对话回复正文），确保报告读者能看到完整的分析结论。

## 4. 受影响文件

| 文件 | 改动类型 | 说明 |
|------|---------|------|
| `src/agents/experts/registry.ts` | 类型扩展 + 数据填充 | 新增 `ReportSectionDef` 类型 + `reportTemplate` 字段；为 6 个专家定义模板 |
| `src/services/report-generator.ts` | 重构 | 拆分为 `buildTemplatedMarkdown` + `buildGenericMarkdown`；`buildGenericMarkdown` 新增 displayContent 章节 |
| `.qoder/reviews/farm-agent-tools-pipeline-review-runtime-v1.md` | F6 来源 | — |

## 5. 验证

- [ ] weekly_report 导出 md → 章节结构与模板一致（天气→墒情→虫情→建议→风险）
- [ ] pest_risk 导出 md → 虫害专题结构（结论→气象→虫情→防治→证据）
- [ ] 任意专家导出报告含 `displayContent.summary` 正文
- [ ] 无 `reportTemplate` 的专家（crop_compare 等）走通用模板，不崩溃
- [ ] `buildGenericMarkdown` 向后兼容，已有测试不挂

---

## 6. 实施记录

- [x] `src/agents/experts/registry.ts`: 新增 `ReportSectionDef` 类型 + `reportTemplate` 字段，6 专家模板数据
- [x] `src/services/report-generator.ts`: `buildReportMarkdown` → 模板分发器，新增 `buildTemplatedMarkdown` + `renderTemplateSection`；`buildGenericMarkdown` 纳入 `displayContent.summary`
- [x] `npx tsc --noEmit` 编译通过
- [x] 模板独立文件化：`src/agents/reports/*.template.ts` × 11（全量专家，一对一），registry.ts 内联数组已删除
