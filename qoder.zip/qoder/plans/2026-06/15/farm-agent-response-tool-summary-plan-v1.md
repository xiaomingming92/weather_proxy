# Plan: response 节点工具执行摘要人话化注入

> **来源**: [runtime review §F5](../reviews/farm-agent-tools-pipeline-review-runtime-v1.md#f5-p0-response-fallback-场景不包含工具执行信息llm-输出原始-api-字段)
> **类型**: 运行时缺陷修复 | **修订**: 2026-06-15

## PLAN 元信息

- **关联文档**:
  - Review: `.qoder/reviews/farm-agent-tools-pipeline-review-runtime-v1.md` (F5)
  - 参考: `src/agents/nodes/reasoning.ts:94-106` (toolResultsBlock 已有实现)

---

## 1. 问题

`response.ts` 的 `buildStreamingTextPrompt` 在 fallback 场景（无 evidence / 无 verdict / 无 interactionPoint）构建 LLM prompt 时，完全不包含工具执行信息。LLM 只能编造原始 JSON 片段（`code: 200, msg: ""`），用户无法理解。

## 2. 根因

```
response.ts:120-148 构建 ResponseInput 时，
retrievedDocuments 只从 evidenceChain 取 source==="knowledge" 的条目。
ragEmpty=true 时 retrievedDocuments 为空。

buildStreamingTextPrompt 只拼接：用户问题 + 意图类型 + 裁决（空）+ 文档（空）
本轮调用的 3 个工具及其结果完全不可见。

reasoning.ts:94-106 已有工具消息提取逻辑，但 fallback 下 reasoning 被跳过。
```

## 3. 修复

### 3.1 `responseNode` 新增工具消息提取

```typescript
// 从 state.messages 提取 ToolMessage
const toolMsgs = (state.messages as any[]).filter(
  (m) => m.role === "tool" || m.type === "tool"
)
```

### 3.2 构建人话工具摘要

| 工具英文名 | 中文显示名 |
|-----------|-----------|
| `query_farm_weather` | 农场气象站数据 |
| `query_soil_moisture` | 土壤墒情数据 |
| `query_insect_data` | 虫情监测数据 |
| `query_massif` | 地块信息 |
| `query_insect_type` | 虫害类别 |

对每条 ToolMessage 解析 content JSON，输出：`工具中文名(地块X, 时间范围): 查询成功，返回 N 条记录`

### 3.3 prompt 注入约束

在 `buildStreamingTextPrompt` 末尾追加：

```
[本轮工具调用摘要]
- 农场气象站数据(地块38, 06-08~06-15): 查询成功，返回 0 条记录
- 土壤墒情数据(地块38, 06-08~06-15): 查询成功，返回 0 条记录

要求：引用数据时使用以上中文名，不得输出原始 JSON 字段名（code/msg/total/list）。
若全部返回 0 条，如实告知"已查询XX等数据源，指定范围暂无记录"。
```

## 4. 受影响文件

| 文件 | 改动 |
|------|------|
| `src/agents/nodes/response.ts` | `responseNode` 新增工具消息提取 + `buildStreamingTextPrompt` 注入摘要 |
| `.qoder/reviews/farm-agent-tools-pipeline-review-runtime-v1.md` | F5 来源 |

## 5. 验证

- [ ] 相同 query 触发 fallback，回复不含 `code`/`msg`/`total`/`list`
- [ ] 回复引用工具中文名 + "返回0条记录"
- [ ] 正常数据路径不受影响
