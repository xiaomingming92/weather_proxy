# farm-agent-gui-chat-enhancement-add-route-v1

## ADD 阶段执行映射

| 阶段 | 内容 | 何时输出 |
|------|------|---------|
| Step 0 | Plan + Spec + Tasks + Checklist + Review + ADD-Route | ✅ 已完成 |

## Task 映射表

| # | Task | 原子闭包 | 输出文件 |
|---|------|---------|---------|
| 1 | updateThreadTitle PATCH | ✅ 单文件独立 | `src/stores/chat-store.ts` |
| 2 | [hash] threads list API | ✅ 单文件独立 | `src/app/api/agent/[hash]/route.ts` |
| 3 | handleThreadGET metadata | ✅ 单文件独立 | `src/app/api/agent/[hash]/route.ts` (同文件) |
| 4 | agrisynapse store + API | ✅ 自包含 | agrisynapse: `agentChat.ts`, `api/agent/index.ts` |
| 5 | agrisynapse GUI 渲染 | ✅ 纯 UI | agrisynapse: `LlmSidebar.vue`, `LlmChatView.vue`, `index.vue` |
| 6 | tsc 编译验证 | ✅ 审计 | 零文件 |

## 原子闭包判定

| 可独立提交 | ✅ Task 1-5 各独立提交 |
| 可独立验证 | ✅ 每个 Task 有对应验收条件 |
| 可独立审计 | ✅ 每个文件变更在 ADD-7 有一条记录 |
| 可独立恢复 | ✅ 每个 Task 一个 commit，revert 不回滚无关变更 |

## 依赖拓扑
```
Task 1 ──────────────── 可并行
Task 2 ─┤              可并行
Task 3 ─┘              可并行
    │
    ▼
Task 4 ──────── 依赖 Task 2/3 API
    │
    ▼
Task 5 ──────── 依赖 Task 4 store
    │
    ▼
Task 6 ──────── 全部验证
```

## 文件清单

### farm-agent
- `src/stores/chat-store.ts` — Task 1: PATCH call
- `src/app/api/agent/[hash]/route.ts` — Task 2: threads action, Task 3: metadata

### agrisynapse
- `src/store/modules/agentChat.ts` — Task 4: threads/interactionPoint/switchThread
- `src/api/agent/index.ts` — Task 4: getThreads, fix getThread metadata
- `src/components/LlmSidebar/LlmSidebar.vue` — Task 5: historyThreads prop
- `src/components/LlmChatView/LlmChatView.vue` — Task 5: interaction section
- `src/views/llm/index.vue` — Task 5: computed navSections
