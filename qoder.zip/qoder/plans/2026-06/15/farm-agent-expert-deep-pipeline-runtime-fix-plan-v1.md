# farm-agent-expert-deep-pipeline-runtime-fix-plan-v1

> Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。

## PLAN 元信息

- **Plan 名称**: farm-agent-expert-deep-pipeline-runtime-fix-v1
- **启动时间**: 2026-06-15T14:30:00+08:00
- **范围**: farm-agent Agent 管线（intentionNode + thinkingLevel 裁决层）
- **触发来源**: 运行时发现（GUI 对话验证）
- **关联文档**:
  - 本 Plan: `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md`
  - ADD Route: `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-add-route-v1.md`（已生成）
  - Handoff: `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-handoff-v1.md`（已生成）
  - Review: `.qoder/reviews/farm-agent-expert-deep-pipeline-runtime-fix-review-v1.md`（已生成）
  - Runtime Review: 本次 Plan 未关联独立 Runtime Review（根因来自 GUI 对话验证，非运行时审计日志发现）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/caijuehub/strategies/thinking-level.ts` | STRATEGY | STRATEGY_UPDATED | resolveThinkingLevel(intent) 仅检查 intent==="chat" | resolveThinkingLevel(intent, explicitExpertId?) 增加专家感知 | ✓ 已实施 |
| `src/agents/nodes/intention.ts` | AGENT_NODE | AGENT_NODE_UPDATED | 4 处调用不传 explicitExpertId；tool_calls 返回路径无 currentTask.query | 4 处透传 explicitExpertId；2 处 tool_calls 返回补充 currentTask.query | ✓ 已实施 |
| agrisynapse: `src/views/llm/components/LlmChatView.vue` | COMPONENT | COMPONENT_UPDATED | 中间态/最终态元素平铺在同一容器 | 新增 .chat-deep-thinking（折叠深度思考容器）+ .chat-bubble-final（最终产出面板）+ .chat-bubble-content（纯文本气泡）三层分离 | 已实施（存在 Review P1-6/P1-7/P1-8/P1-9/P1-10/P1-11/P1-12 缺口） |
| `src/agents/nodes/retrieval.ts` | AGENT_NODE | AGENT_NODE_ISSUE | Expert Grounding checkCollectionGrounding() 全部返回 empty → source 恒为 knowledge | 待修复：per-expert collection 同步 / metadata filter grounding | 🆕 P1-11 |
| `src/services/knowledge-indexer.ts` | SERVICE | SERVICE_ISSUE | 文档索引仅写入默认 collection farm_agent，expert 专有 collection 无数据 | 待修复：增加 per-expert collection 同步逻辑 | 🆕 P1-11 |

---

## 一、背景与目标

### 1.1 问题现状

agrisynapse 神经元 GUI 点击技能卡片（如 weekly_report、pest_detect）发起对话时，前端 `LlmChatView.vue` 只渲染纯文本 `llm-page__chat-bubble-content`，不渲染：

- RAG 搜索状态/结果
- 证据链（evidenceChain）
- 推理路径（reasoningPath）
- 置信度面板（verdict）
- 交互点（interactionPoint）
- 风险项

### 1.2 Agent 日志证据

```
[ROUTE] intention → retrieval | {"reason":"thinkingLevel=deep, intent=unknown"}
[RETRIEVAL_DECISION] 检索决策: (无查询) | {"activeExpertIds":"weekly_report","source":"analysisContext","mode":"per_expert_parallel","perExpertTopK":"{}"}
[NODE_END] ✔ retrieval (2ms) | {"durationMs":2}
[OS_KERNEL_FALLBACK_FLAG] fallbackFlags.ragEmpty=true (检索零命中) | {"evidenceCount":0,"newEvidenceCount":0}
[NODE_END] reasoning: 无证据, 跳过推理 | {"evidenceCount":0,"confidence":0}
[ROUTE] verdict → response | {"reason":"无裁决结果"}
[NODE_END] response: 回复生成完成 | {"hasVerdict":false,"hasInteractionPoint":false,"strategyId":"deep:fallback","thinkingLevel":"deep","hasNonPriorEvidence":false}
```

### 1.3 目标

修复 Agent 管线中两个导致证据链断流的缺陷，使技能卡片对话走完整 **intention → toolNode → intention → retrieval → reasoning → interactionPointDetection → verdict → response** 管线，前端能正确渲染全部 GUI 元素。

---

## 二、根因分析

### 根因 1：`currentTask.query` 在 tool_calls 返回路径丢失

**数据流断裂点**：

```
intention (首轮, explicitExpertId=weekly_report)
  → LLM 请求 tool_calls 或决策层强制注入 tool_calls
  → return { messages: [AIMessage], analysisContext }   ← ❌ 无 currentTask
  → ToolNode 执行 3 个实时工具
  → intention (第二轮, lastMessage.role === "tool")
  → return { currentTask: state.currentTask }             ← state.currentTask 为 undefined
  → retrieval:
      searchQuery = subIntentPlan.mergedSearchQuery ?? currentTask?.query
      → undefined → "(无查询)" → RAG 零命中
```

**关键代码位置**：`src/agents/nodes/intention.ts` L148-151 和 L175-178，两个 tool_calls 返回路径均未设置 `currentTask`。

### 根因 2：`resolveThinkingLevel` 裁决层不感知 `explicitExpertId`

```
intention → LLM 解析 intent="chat"
  → resolveThinkingLevel("chat") → "fast"
  → routeByIntent → 直接走 response
  → 跳过 retrieval/reasoning/verdict 全管线
```

**关键代码位置**：`src/caijuehub/strategies/thinking-level.ts` L16-18，裁决函数只检查 `intent === "chat"`，不感知 `explicitExpertId`。

> 注：根因 2 在上一轮已修复（`explicitExpertId` 非空强制 `"deep"`），但修复后暴露了根因 1——Agent 走了 deep 路径但 retrieval 空查询导致管线仍无产出。

### 根因 3：Expert Grounding collection 未初始化 → `source` 恒为 `"knowledge"`

**Runtime 发现**（2026-06-15T09:44 日志）：

```
[EXPERT_GROUNDING_DEGRADED] Expert pest_risk grounding 不可用: empty
[EXPERT_GROUNDING_DEGRADED] 无激活专家，回退全局检索 (expertCount=0)
[STREAM-BUS] EVIDENCE: knowledge/e_know_xxx | source="knowledge" | relevance=0
```

**数据流断裂点**：

```
retrieval → per-expert grounding check
  → checkCollectionGrounding("expert_pest_risk") → client.count() → 0
  → groundingReady = false, indexHealth = "empty"
  → fallback: searchKnowledgeDocuments(searchQuery, k, undefined, evidenceFilter)  // 全局检索
  → _grounded = false
  → stream.evidenceFound({ source: "knowledge" })   ← ❌ 永远不设 "expert"
  → 前端 evidence-bar 永远不命中 v-if source === 'expert' 分支
```

**根因**：知识库文档全量索引到默认 collection `farm_agent`，但 Expert Grounding 检查独立 collection（`expert_pest_risk`、`expert_crop_compare` 等 8 个），这些 collection 从未接收文档数据 → `client.count()` 返回 0。

**关键代码位置**：
- Grounding 就绪检查：`src/services/knowledge-indexer.ts` L49-53（`checkCollectionGrounding()`）
- source 赋值：`src/agents/nodes/retrieval.ts` L350 / L392（`result._grounded ? "expert" : "knowledge"`）
- 文档索引仅写入默认 collection：`src/services/knowledge-indexer.ts` L117（`getChromaCollection()` 无参 → DEFAULT_COLLECTION）

**影响**：证据条全部渲染为 knowledge 分支（📄 图标），relevance=0 进度条为空，用户视觉上认为"只有 RAG 结果栏有数据，证据条未渲染"。

---

## 三、方案设计

### 3.1 神经元 GUI 当前状态与改造计划

#### 3.1.1 GUI 当前状态

**问题：中间态与最终态 DOM 混排，无容器分离。**

当前 `LlmChatView.vue` 模板在 `llm-page__chat-bubble--assistant` 内按 DOM 顺序线性排列 10 个元素，中间态（RAG 搜索、证据条、工具调用、纯文本）和最终态（推理路径、证据链、裁决面板、交互点）混在同一层级：

```
llm-page__chat-bubble--assistant           ← 单一容器，无分层
  ├── .rag-status           (L36)  中间态 ← v-if="msg.ragSearching"
  ├── .rag-result           (L45)  中间态 ← v-else-if="msg.ragResult"
  ├── .evidence-bar         (L55)  中间态 ← v-if="msg.evidence?.length"
  ├── .tool-calls           (L66)  中间态 ← v-if="msg.toolCalls?.length"
  ├── .chat-bubble-content  (L79)  中间态 ← 文本 + cursor
  ├── .reasoning            (L84)  最终态 ← && !msg.isStreaming
  ├── .evidence-chain       (L124) 最终态 ← && !msg.isStreaming
  ├── .verdict              (L201) 最终态 ← && !msg.isStreaming
  ├── .interaction          (L283) 最终态 ← && !msg.isStreaming
  └── .action-bar           (L298) 最终态 ← && !msg.isStreaming
```

**缺陷分析**：
| 问题 | 说明 |
|------|------|
| **无中间态/最终态容器边界** | 所有元素平铺，CSS 无法区分流式进行中和已完成的渲染区域 |
| **文本气泡位置错误** | 纯文本在第 5 位（夹在工具调用和推理路径之间），而管线中文本是流式输出的最后一段中间态内容 |
| **中间态元素留在最终态区域** | RAG 搜索动画消失后其 DOM 收回，导致后续元素上跳，视觉割裂 |
| **无法做过渡动画** | 流式结束→最终态面板出现之间没有容器级 transition |
| **证据条不区分来源** | 专家知识库证据（source=`"expert"`，来自专属 ChromaDB collection）和非专家通用知识库证据（source=`"knowledge"`）渲染相同图标/样式，用户无法区分证据归属 |

**证据条来源差异（retrieval.ts L392）**：
```typescript
stream.evidenceFound({
  source: result._grounded ? "expert" : "knowledge",
  // ...
})
```

| source 值 | 含义 | ChromaDB 来源 | expertIds | GUI 当前渲染 | GUI 应渲染 |
|-----------|------|--------------|-----------|------------|-----------|
| `"expert"` | 专家专属知识库命中 | expert grounding collection | 有 (专家打标) | ❌ 永不命中（Grounding collection 为空） | 专家图标 + collection 名 + grounding badge |
| `"knowledge"` | 通用知识库命中 | 默认 collection / 降级 fallback | 无 | `mdi:file-document-outline` | 文档图标 + 文档名 + 相关度进度条 |
| 工具结果 | 实时数据工具返回值 | 无（不是 RAG） | 无 | 无独立渲染 | 工具图标 + 工具名 + 数据表格（完整字段×行数，可展开/折叠） |

#### 3.1.2 GUI 改造目标

**设计原则**：参考 DeepSeek 网页端模式。只有用户消息和 AI 最终总结文本使用 bubble 样式。中间态（RAG 搜索、证据条、工具调用、推理过程）整体作为可折叠的"深度思考"容器——流式进行中自动展开，流式结束后自动收起为单行摘要（"已深度思考（用时 X.Xs）"），用户可点击展开回看。最终态结构化面板（证据链、裁决、交互点、数据表格）无 border，扁平排列以最大化可用宽度。

将当前 `llm-page__chat-bubble--assistant` 的 bubble 样式移除，在 `llm-page__chat-row--assistant` 下拆为三个语义区域：

```
llm-page__chat-row--assistant
  ├── .chat-avatar
  │
  ├── .chat-content-column               ← 🆕 垂直布局包裹层 (flex-direction: column)
  │   │
  │   ├── .chat-deep-thinking               ← 🆕 "深度思考" `折叠容器`
  │   │   │   // 流式中: header="🧠 深度思考中..." + 自动展开
  │   │   │   // 流式完: header="✅ 已深度思考（用时 X.Xs）" + 自动收起
  │   │   │   // 用户可点击 header 展开/折叠
  │   │   │
  │   │   ├── .rag-status          (RAG 搜索 spinner)
  │   │   ├── .rag-result          (RAG 结束 badge)
  │   │   ├── .evidence-bar        (证据条列表，按 source 三源渲染)
  │   │   │   ├── [source="expert"]    → 🧠 专家图标 + summary + collectionName badge
  │   │   │   ├── [source="knowledge"] → 📄 文档图标 + documentName + summary + 相关度进度条
  │   │   │   └── [from tool]          → 🔧 工具图标 + toolName + summary + 可展开原生 `<table>`
  │   │   └── .tool-calls          (工具调用状态)
  │   │
  │   ├── .chat-bubble-content (文本 + cursor)   ← 无管线时的消息气泡（v-if="!hasPipelineOutput(msg)"）
  │   │
  │   └── .chat-bubble-final                ← 🆕 最终态面板区（无 border，管线产出）
  │       │   v-if="!msg.isStreaming && hasPipelineOutput(msg)"
  │       ├── .evidence-chain      (证据链，按 source/tool 区分展开 ← 管线产出，非思考过程)
  │       │   ├── [source="expert"]    → 🧠 专家图标 + collection 名 + grounding badge + 完整内容
  │       │   ├── [source="knowledge"] → 📄 文档图标 + 文档名 + 可靠度/相关度进度条 + 完整内容
  │       │   └── [from tool]          → 🔧 工具图标 + 工具名 + 原生 `<table>`（`.llm-page__data-table`，无 border，全宽展示）
  │       ├── .reasoning           (推理路径)
  │       ├── .verdict             (裁决面板)
  │       ├── .interaction         (交互点)
  │       ├── .chat-bubble-content (文本，靠在 action-bar 上方)   ← 管线消息的文本气泡
  │       └── .action-bar          (工具操作按钮 + 导出专家报告按钮)
```

> 职责划分：证据**条**（`msg.evidence`，流式实时推送）属于深度思考过程，在 `.chat-deep-thinking` 中展示。证据**链**（`msg.evidenceChain`，管线末端整理后批量输出）是管线结构化产出，纳入最终态面板直接可见，不折叠。

**深度思考容器行为**：

| 阶段 | header 文案 | 展开/折叠 | 触发 |
|------|-----------|----------|------|
| 流式开始 | "🧠 深度思考中..." + 旋转动画 | 自动展开 | `msg.isStreaming === true` |
| 流式进行 | "🧠 深度思考中..." + 旋转动画 | 保持展开 | 持续 streaming |
| 流式结束 | "✅ 已深度思考（用时 X.Xs）" | 自动收起 | `msg.isStreaming === false` |
| 用户点击 header | 不变 | toggle 展开/折叠 | 手动 |

**对比当前结构**：当前所有元素嵌套在 `llm-page__chat-bubble--assistant`（带 border-radius + padding + max-width）。改造后 bubble 样式仅保留在 `.chat-bubble-content`（AI 总结文本气泡），"深度思考"抽屉和最终态面板均无 border 约束，数据表格可全宽展示。

**改造要点**：

| 项 | 改动 | 位置 |
|----|------|------|
| 深度思考折叠容器 `.chat-deep-thinking` | 包裹中间态元素（RAG spinner + 证据条 + 工具调用），带 header 自动展开/收起 | `LlmChatView.vue` |
| 深度思考 header 状态切换 | 流式中："🧠 深度思考中..." + 旋转动画 + 自动展开；流式完："✅ 已深度思考（用时 X.Xs）" + 自动收起 | `LlmChatView.vue` |
| 新增 `.chat-bubble-final` 面板容器 | 包裹 5 个管线产出元素（证据链 + 推理路径 + 裁决 + 交互点 + 工具按钮），无 border | `LlmChatView.vue` |
| `hasPipelineOutput()` computed | 判断 `evidenceChain?.length \|\| reasoningPath?.length \|\| verdict \|\| interactionPoint` | `LlmChatView.vue` |
| 证据条按 source 区分渲染（深度思考内） | `"expert"` → 专家图标+collection badge；`"knowledge"` → 文档图标+文档名+相关度；工具 → 工具图标+工具名，点击展开数据表格 | `LlmChatView.vue` |
| `evidence_found` dispatch | 无需额外改动——`EvidenceFoundEvent` 类型已定义 `evidence.source`，dispatch 整对象推送即透传 | - |
| 深度思考折叠 CSS transition | 展开/折叠 slideDown/slideUp 动画 + header spinner 旋转 | scss |
| 纯文本气泡 | 保留原有 bubble 样式，仅此子元素有 border | 无需改动 |
| **流式中间态数据持久化** | `structuredResponse` 扩展 `streamingTraces.evidence[]`；`loadThread()` 恢复 `evidence`/`ragResult`/`ragSearching`/`toolCalls`（Review P1-6/P1-7） | `response.ts` + `stream/route.ts` + `agentChat.ts` |

#### 3.1.3 流式中间态数据持久化（Review 回流）

**问题**（Review P1-6/P1-7）：深度思考折叠容器在流式进行中正常展示证据条（`msg.evidence`）和 RAG 状态（`msg.ragResult`），但页面刷新后这些字段为空——因为：
1. `response.ts` 构建的 `structuredResponse` 仅包含最终态字段（evidenceChain/reasoningPath/verdict/interactionPoint），不包含流式中间态字段
2. `agentChat.ts` 的 `loadThread()` 从 metadata 恢复消息时只取了 verdict/evidenceChain/reasoningPath/interactionPoint 四个字段

**修复方案**：

**后端**（farm-agent `response.ts`）：
```typescript
// structuredResponse 新增 streamingTraces 字段
const streamingTraces = stream.collectStreamingTraces()
const structuredResponse: StructuredAgentResponse = {
  // ...existing fields
  streamingTraces: {
    evidence: streamingTraces.evidence,      // evidence_found 事件数组（含 expertIds）
    ragResult: streamingTraces.ragResult,     // RAG 结果数
  },
}
```
> ⚠️ `evidence` 数组中每条均含 `expertIds` 字段（SSE 流式已推送）。持久化 `streamingTraces.evidence` 后，`loadThread` 恢复的 evidence 即包含 expertIds → `hasExpertIds(msg)` 返回 true → 最终态面板正常展示"导出报告"按钮。

**后端**（farm-agent `node-stream-controller.ts`）：新增 `collectStreamingTraces()` 方法，收集当前节点已推送的 evidence 列表和 ragResult。

**前端**（agrisynapse `agentChat.ts`）：
```typescript
// loadThread 恢复流式中间态字段
this.messages = res.data.messages.map((m) => {
  const meta = m.metadata ?? {}
  const st = (meta as Record<string, unknown>).streamingTraces as Record<string, unknown> | undefined
  return {
    // ...existing fields
    evidence: Array.isArray(st?.evidence) ? st!.evidence : undefined,
    ragResult: (st?.ragResult as StreamingMessage["ragResult"]) ?? undefined,
    ragSearching: undefined,  // 历史回放不显示搜索中状态
    toolCalls: undefined,     // 工具调用状态不回溯
  }
})
```

#### 3.1.4 GUI 改造影响范围

| 文件 | 改动类型 | 行数估计 |
|------|---------|---------|
| `agrisynapse/src/views/llm/components/LlmChatView.vue` | 模板结构重组 + 证据来源区分 + computed | ~40 行 |
| `agrisynapse/src/views/llm/components/` (scss) | 新增容器级 CSS transition | ~15 行 |
| `agrisynapse/src/store/modules/agentChat.ts` | `evidence_found` dispatch 透传 `source` 字段 + `loadThread` 恢复流式字段 | ~15 行 |
| `farm-agent/src/agents/nodes/response.ts` | `structuredResponse` 扩展 `streamingTraces` | ~10 行 |
| `farm-agent/src/agents/node-stream-controller.ts` | 新增 `collectStreamingTraces()` 方法 | ~15 行 |
| `farm-agent/src/agents/nodes/intention.ts` | currentTask + 透参（根因修复） | ~12 行 |
| `farm-agent/src/caijuehub/strategies/thinking-level.ts` | strategy 增强 | ~8 行 |

**关键结论**：farm-agent 修复解决**数据源**问题（管线产不出事件），GUI 容器重构解决**渲染边界**问题（产出的事件没按语义容器组织）。两者缺一不可。

### 3.2 裁决层策略集中化（align 已有改动）✓

```typescript
// src/caijuehub/strategies/thinking-level.ts
export function resolveThinkingLevel(
  intent: string | undefined,
  explicitExpertId?: string | null,  // 新增参数
): ThinkingLevel {
  // GUI 直连专家：无论 LLM 解析出什么意图，都走完整管线
  if (explicitExpertId) return "deep"
  return intent === "chat" ? "fast" : "deep"
}
```

### 3.3 intentionNode 调用方透参（align 已有改动）✓

| 行号 | 场景 | 改动 |
|------|------|------|
| L79 | explicitIntent 路径 | `resolveThinkingLevel(explicitIntent, explicitExpertId)` |
| L193 | LLM 解析成功 | `resolveThinkingLevel(result.intent, explicitExpertId)` |
| L237 | 解析失败 fallback | `resolveThinkingLevel(parsed.intent, explicitExpertId)` |
| L241 | 最终落盘 | `resolveThinkingLevel(parsed.intent, explicitExpertId)` |

### 3.4 intentionNode tool_calls 返回路径补充 currentTask（待实施）⚠

```typescript
// 路径 1: LLM tool_calls (L148-155)
return {
  messages: [response],
  currentTask: {                           // ← 新增
    ...state.currentTask,
    query: queryText,
  },
  ...(preActivatedContext ? { analysisContext: preActivatedContext } : {}),
}

// 路径 2: 强制 tool_calls (L175-186)
return {
  messages: [new AIMessage({ content: "", tool_calls: forcedToolCalls as any })],
  currentTask: {                           // ← 新增
    ...state.currentTask,
    query: queryText,
  },
  ...(preActivatedContext ? { analysisContext: preActivatedContext } : {}),
}
```

### 3.5 流式中间态 vs 最终态渲染架构

Agent 管线中，SSE 事件分为两类：**流式中间态**（管线进行中渐进推送，GUI 即时渲染）和**最终态**（管线末端汇总输出，GUI 一次性渲染结构化面板）。

#### 3.5.1 完整渲染时序图

```
Agent 管线节点                        SSE 事件                     GUI 渲染
─────────────────                    ────────                     ────────
intention (首轮)
  → forced tool_calls ──────── (无 SSE，直接路由 toolNode)

intention (二轮, 透传 currentTask)
  → retrieval ───────────────── rag_search ──────────────── [中间态] RAG 搜索 spinner
               │                evidence_found ───────────── [中间态] 证据条逐条追加
               │                rag_result ───────────────── [中间态] RAG 结果数 badge
               ▼                structured_output
               │                  ├─ evidenceChain ───────── [中间态] 证据链预渲染
               │                  └─ ...
               ▼
  → reasoning ───────────────── (LLM 内部推理，无独立 SSE) ─ (内部)
               │                structured_output
               │                  └─ reasoningPath ───────── [中间态] 推理路径渲染
               │                      ├─ steps[]
               │                      └─ traces[]
               ▼
  → interactionPointDetection ─ structured_output
               │                  └─ interactionPoint ────── [中间态] 交互按钮渲染
               ▼
  → verdict ─────────────────── structured_output
               │                  └─ verdict ─────────────── [中间态] 置信度面板渲染
               │                      ├─ type
               │                      ├─ conclusion
               │                      └─ confidence
               ▼
  → response (LLM 文本生成) ──── token ──────────────────── [中间态] 文本逐 token 输出
               │
               │ (生成结束后汇总)
               │                structured_output ───────── [最终态] 全量结构化面板
               │                  ├─ evidenceChain               ├─ 证据链（完整）
               │                  ├─ reasoningPath               ├─ 推理路径（完整）
               │                  ├─ verdict                     ├─ 置信度 + 结论
               │                  ├─ interactionPoint            ├─ 交互按钮
               │                  └─ riskItems[]                 └─ 风险项列表
```

#### 3.5.2 中间态 vs 最终态职责划分

> **注意**: 当前 GUI 对所有 `structured_output` 事件均使用 `!isStreaming` 条件渲染（即流式完成后一次性展示），不存在按节点渐进的"中间态渲染"。本节描述的是 SSE 事件的实际发送时机，以及 GUI 当前的真实渲染策略。

| 类别 | 事件 | 来源节点 | 事件发送时机 | GUI 渲染时机 | GUI 元素 |
|------|------|---------|-------------|-------------|---------|
| **中间态** | `rag_search` | retrieval | 检索开始 | 立即（流式中） | RAG 搜索 spinner + 知识库名称 |
| **中间态** | `evidence_found` | retrieval | 逐条命中 | 立即（流式中） | 证据条（来源 + 摘要 + 相关度） |
| **中间态** | `rag_result` | retrieval | 检索结束 | 立即（流式中） | RAG 命中数 badge |
| **中间态** | `tool_call` / `tool_result` | toolNode | 工具执行时 | 立即（流式中） | 工具调用状态 + 结果 |
| **中间态** | `token` | response | LLM 流式生成 | 立即（流式中） | 纯文本 token 增量 |
| **最终态** | `structured_output` | retrieval / reasoning / verdict / interactionPointDetection / response | 各节点结束时发送 | `!isStreaming`（流式完成后一次性渲染） | evidenceChain + reasoningPath + verdict + interactionPoint + riskItems |

> 各节点 `structured_output` 在事件层面是分开发送的（retrieval→reasoning→verdict→response），但 GUI 统一等待 `isStreaming === false` 后批量渲染。渐进式逐节点展示属于后续优化，不在本次修复范围内。

#### 3.5.3 当前 Bug 如何阻断两级渲染

```
intention (首轮) → forced tool_calls
  → return { messages, analysisContext }              ← ❌ 无 currentTask.query
  → toolNode 执行 3 个工具
  → intention (二轮) → return { currentTask: {} }     ← query = undefined
  → retrieval:
      searchQuery = currentTask?.query → undefined
      → 无 rag_search / evidence_found / rag_result   ← ❌ 中间态 0 事件
      → 无 evidenceChain structured_output            ← ❌ 中间态 0 事件
  → reasoning:
      evidenceCount=0 → "无证据, 跳过推理"            ← ❌ 中间态 0 事件
      → 无 reasoningPath
  → verdict:
      无 reasoningResult → "无裁决结果"                ← ❌ 中间态 0 事件
      → 无 verdict
  → response:
      hasVerdict=false, hasInteractionPoint=false
      → structured_output 无 evidenceChain/推理/裁决   ← ❌ 最终态 0 渲染
      → 仅 token 纯文本输出
```

**结论**：`currentTask.query` 在 tool_calls 返回路径的丢失是整个渲染链路的单点断裂。修复后，用户原文注入 retrieval → RAG 命中 → reasoning 不跳过 → verdict 产出 → response 汇总 → 中间态 + 最终态两级渲染全部恢复。

---

## 四、实施步骤

```
Task 1 (裁决层策略) ──┐
                       │ 可并行 (farm-agent)
Task 2 (intention 透参) ┤
                       │
Task 3 (currentTask 补充) ┤
                       │
                       ▼
Task 4 (GUI 容器重构) ─── 可并行 (agrisynapse, 不依赖 farm-agent 编译)
                       │
                       ▼
Task 5 (tsc + E2E 验证)
```

### Task 1: 裁决层 thinking-level.ts 策略增强 ✓

- **项目**: farm-agent
- **文件**: `src/caijuehub/strategies/thinking-level.ts`
- **改动**: 函数签名增加 `explicitExpertId?: string | null` 参数，非空时强制返回 `"deep"`
- **验收**: `explicitExpertId="weekly_report"` 时 `resolveThinkingLevel("chat", "weekly_report")` 返回 `"deep"`

### Task 2: intentionNode 4 处调用透传 explicitExpertId ✓

- **项目**: farm-agent
- **文件**: `src/agents/nodes/intention.ts`
- **改动**: L79 / L193 / L237 / L241 四处 `resolveThinkingLevel(x)` → `resolveThinkingLevel(x, explicitExpertId)`
- **验收**: 编译通过，无类型错误

### Task 3: intentionNode tool_calls 返回路径补充 currentTask.query ✓

- **项目**: farm-agent
- **文件**: `src/agents/nodes/intention.ts`
- **改动**: L148-151 和 L175-186 两处 return 增加 `currentTask: { ...state.currentTask, query: queryText }`
- **验收**: 编译通过，第二轮 intention → retrieval 时 `currentTask?.query` 非空

### Task 4: agrisynapse GUI 深度思考折叠容器 + 最终态面板 ⚠

- **项目**: agrisynapse（前端仓库）
- **跨仓库依赖**:
  - agrisynapse 编译独立于 farm-agent，但运行时依赖 farm-agent SSE 事件正确发送
  - farm-agent 侧 Task 1-3 完成后，GUI 才能拿到正确的 `evidence_found`/`structured_output` 事件
  - 建议使用同一分支名 `fix/expert-deep-pipeline-runtime` 在两个仓库
  - 编译顺序: farm-agent 先 tsc 验证 → agrisynapse tsc + dev server
- **文件**: `src/views/llm/components/LlmChatView.vue`、`src/store/modules/agentChat.ts`
- **改动**:
  - (a) 移除 `llm-page__chat-bubble--assistant` 的 bubble 样式包裹，元素直接置于 `llm-page__chat-row--assistant`
  - (b) 新增 `.chat-deep-thinking` 折叠容器，包裹 RAG spinner + 证据条 + 工具调用
  - (c) 深度思考 header：流式中 "🧠 深度思考中..." + spinner 旋转 + 自动展开；流式完 "✅ 已深度思考（用时 X.Xs）" + 自动收起
  - (d) 新增 `.chat-bubble-final` 面板容器（无 border），包裹证据链 + 推理路径 + 裁决 + 交互点 + 工具按钮
  - (e) 新增 computed `hasPipelineOutput(msg)`: 判断 `evidenceChain?.length \|\| reasoningPath?.length \|\| verdict \|\| interactionPoint`
  - (f) 证据条按 `ev.source` 区分渲染：`"expert"` → 专家图标+collection badge；`"knowledge"` → 文档图标+文档名+相关度；工具 → 工具图标+数据表格
  - (g) CSS: 深度思考 slideDown/slideUp 动画 + spinner 旋转 + 最终态面板基础排版
- **验收**: 流式进行中深度思考自动展开；流式结束后深度思考自动收起为单行摘要；最终态面板无 border 展示证据链+推理路径+裁决+交互点；证据按来源显示不同图标
- **已知缺口**（Review P1-8/P1-9/P1-10 回流）:
  - (h) `.chat-bubble-final` 内元素按 Plan L165-174 排序：`evidence-chain → reasoning → verdict → interaction → action-bar`
  - (i) 移除 `.chat-bubble-final` 内部 L372-375 重复的 `.chat-bubble-content`
  - (j) `.evidence-chain`（最终态面板内）增加三源分支渲染（expert→🧠+collection badge；knowledge→📄+文档名+进度条；tool→🔧+工具名+原生table）

### Task 5: tsc 编译 + E2E 验证 ⚠
- **项目**: farm-agent + agrisynapse
- **文件**: 编译验证（无新文件变更）

- farm-agent: `npx tsc --noEmit` 零错误
- agrisynapse: `npx vue-tsc --noEmit` 零错误
- 运行时验证（需启动 dev server）:
  - 点击技能卡片后检查 `agent-audit.log`
  - `RETRIEVAL_DECISION` 不再显示 "(无查询)"
  - `fallbackFlags.ragEmpty` 不为 `true`
  - `reasoning` 节点不输出 "无证据, 跳过推理"
  - GUI 流式进行中渲染 RAG spinner + 证据条 + 工具调用
  - GUI 流式结束后渲染推理路径 + 裁决面板 + 交互点
  - GUI 最终态面板渲染证据链（管线产出），非折叠内
- **审计证据**: Task 1-3 已通过 `npx tsc --noEmit`（farm-agent）验证零类型错误

### Task 6: 流式中间态数据持久化 + 历史回放恢复 ⚠

> **来源**: Review P1-6/P1-7 回流。新增 Task。

- **项目**: farm-agent（后端持久化）+ agrisynapse（前端恢复）
- **文件**:
  - farm-agent: `response.ts`（structuredResponse 扩展）、`node-stream-controller.ts`（新增 collectStreamingTraces）
  - agrisynapse: `agentChat.ts`（loadThread 恢复 evidence/ragResult）
- **改动**:
  - (a) `node-stream-controller.ts` 新增 `collectStreamingTraces()` 方法，返回 `{ evidence: EvidenceFoundEvent[], ragResult: RagResultEvent | null }`
  - (b) `response.ts` `structuredResponse` 新增 `streamingTraces` 字段
  - (c) `agentChat.ts` `loadThread()` 从 `metadata.streamingTraces` 恢复 `evidence`、`ragResult`
- **数据保护**: 流式中间态不恢复 `ragSearching`（历史回放不显示搜索中状态）和 `toolCalls`（工具调用状态不回溯）
- **验收**:
  - 技能卡片对话完成 → 页面刷新 → 深度思考折叠容器展开后证据条和 RAG 状态栏可见
  - **页面刷新后 expertIds 恢复 → 最终态面板"导出报告"按钮正常展示**
  - 纯闲聊历史对话不受影响（streamingTraces 为空/null 时 evidence 为 undefined）


### Task 7: SSE evidence_found 事件字段扩展 ✓

> **来源**: Review P1-10 回流。前端证据条三源渲染需要完整字段。

- **项目**: farm-agent（后端 SSE）+ agrisynapse（前端类型同步）
- **文件**: farm-agent: `src/agents/stream-bus.ts`（EvidenceFoundEvent 扩展）、`src/agents/node-stream-controller.ts`（evidenceFound 参数）、`src/agents/nodes/retrieval.ts`（调用方传入完整字段）; agrisynapse: `src/api/agent/types.ts`（StreamingEvidence 接口同步）
- **改动**: `evidence_found` SSE 事件证据对象增加 `documentName?`, `collectionName?`, `toolName?`, `data?`, `expertIds?`
- **验收**: 前端 evidence-bar 三源渲染时有完整 badge 数据

### Task 8: 前端根据 expertIds 展示导出报告按钮 ✓

> **来源**: Review P1-6 回流子项。依赖 Task 6 streamingTraces 持久化 expertIds。

- **项目**: agrisynapse
- **文件**: `src/views/llm/components/LlmChatView.vue`
- **改动**: `getExpertIds(msg)` 从 evidence + evidenceChain 收集去重 expertIds；`hasActionButtons()` 增加 expertIds 存在性判断；`getActionButtons()` 追加导出报告按钮
- **验收**: 有 expertIds 时最终态面板显示"导出报告"按钮

### Task 9: Expert Grounding collection 初始化修复 🆕

> **来源**: Review P1-11/P1-12 回流。Runtime 发现 Expert Grounding 全部为空。
> **决策**: 方案 A（per-expert collection 同步）

- **项目**: farm-agent（后端）
- **文件**: `src/services/knowledge-indexer.ts`（修改）、`scripts/kb-import.ts`（修改）、`scripts/kb-sync-expert-collections.ts`（新建）
- **路由规则**（expert ↔ cateId 映射，来自 registry.ts evidenceFilter）：

| Expert Collection | 匹配 cateId |
|---|---|
| `expert_crop_compare` | `planting_technique` |
| `expert_roi_analysis` | `market_intel`, `economic_data` |
| `expert_pest_risk` | `plant_protection`, `agri_tech` |
| `expert_weather_impact` | `weather`, `agri_tech` |
| `expert_nutrition_diagnose` | `agri_tech`, `planting_technique` |
| `expert_growth_report` | `planting_technique`, `agri_tech` |
| `expert_planting_advice` | `planting_technique`, `agri_tech` |
| `expert_work_plan` | `planting_technique`, `agri_tech` |
| `expert_machinery_dispatch` | `agri_tech`, `weather` |

- **改动**:
  - (a) 新建 `scripts/kb-sync-expert-collections.ts`：读取 `farm_agent` collection 全部文档 → 按 `tags`/`fileName` 推断 cateId → 复制向量到匹配的 expert collection（去重）
  - (b) 修改 `src/services/knowledge-indexer.ts`：`indexKnowledgeDocumentWithProgress()` 增加 `expertCateIds?: string[]` 参数，索引后同步写入匹配的 expert collections
  - (c) 修改 `scripts/kb-import.ts`：增加 `--expert` flag，导入后调用 (a) 的同步逻辑
  - (d) 可选优化：若文档数量大，改为运行时 grounding 降级路径——expert collection 为空时，自动回退到 `farm_agent` + `evidenceFilter.cateId` 过滤（作为方案 A 的保险丝）
- **验收**:
  - `checkCollectionGrounding("expert_pest_risk")` 返回 `{ ready: true, documentCount > 0 }`
  - agent-audit.log 出现 `EXPERT_GROUNDING_READY`（非 DEGRADED）
  - stream-bus.log 中 `evidence_found` 出现 `source="expert"` 条目
  - 前端 evidence-bar 渲染 🧠 expert 分支（collectionName badge 可见）
  - relevance > 0（Expert collection 中文档与查询有真实相似度）

---

## 五、验收标准

- [ ] 点击技能卡片 → Agent 走完整 deep 管线（`intention → toolNode → intention → retrieval → reasoning → verdict → response`）
- [ ] `retrieval` 节点检索查询非空（`currentTask.query` 为用户原文）
- [ ] `reasoning` 节点产生推理路径（不跳过）
- [ ] `verdict` 节点产出裁决结果（包含 confidence + conclusion）
- [ ] 前端 `LlmChatView.vue` 渲染：深度思考（RAG 搜索状态 + 证据条 + 工具调用）→ 文本气泡 → 最终态面板（证据链 + 推理路径 + 裁决 + 交互点）
- [ ] 纯闲聊（无 expertId）仍走 fast 路径，不触发 retrieval
- [ ] `npx tsc --noEmit` 零错误
- [ ] **【P1-6/P1-7】** 页面刷新后深度思考折叠容器展开可见历史证据条和 RAG 状态（`loadThread` 恢复 `evidence` 和 `ragResult`）
- [ ] **【P1-6/P1-7】** 纯闲聊历史对话不受证据持久化影响（`streamingTraces` 为空时 `evidence` 为 undefined）
- [ ] **【P1-11/P1-12】** `EXPERT_GROUNDING_READY` 审计日志出现（Expert Grounding 就绪）
- [ ] **【P1-11/P1-12】** stream-bus.log 中 `evidence_found` 出现 `source="expert"` 条目（relevance > 0）
- [ ] **【P1-11/P1-12】** 前端 evidence-bar 渲染 expert 分支（🧠 图标 + collectionName badge）
- [ ] **【P1-6】** 页面刷新后 expertIds 恢复 → 最终态面板"导出报告"按钮正常展示

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| ADD Route | `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-add-route-v1.md` | ✅ |
| Handoff | `.qoder/plans/farm-agent-expert-deep-pipeline-runtime-fix-handoff-v1.md` | ✅ |
| Review | `.qoder/reviews/farm-agent-expert-deep-pipeline-runtime-fix-review-v1.md` | ✅ |
| Specs: tasks.md | `.qoder/specs/farm-agent-expert-deep-pipeline-runtime-fix/tasks.md` | ✅ |
| Specs: checklist.md | `.qoder/specs/farm-agent-expert-deep-pipeline-runtime-fix/checklist.md` | ✅ |
