# farm-agent-reasoning-structured-dataflow-handoff-v1

## <第1轮> reasoning 节点结构化数据流改造

### 你当前的位置
第1轮（单轮原子闭包）。本轮交付 reasoning 节点从字符串拼接模式到结构化 ExpertReasoningPackage 模式的完整改造。

### 你的 spec 文件
- Spec: `.qoder/specs/farm-agent-reasoning-structured-dataflow/spec.md`
- Tasks: `.qoder/specs/farm-agent-reasoning-structured-dataflow/tasks.md`
- Checklist: `.qoder/specs/farm-agent-reasoning-structured-dataflow/checklist.md`

### 你要改的文件

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/prompts/types.ts` | MODIFY | 新增 ExpertReasoningPackage / ExpertPromptInput / ExpertPromptOutput |
| `src/agents/state.ts` | MODIFY | AgentState 新增 expertPackages? 字段 |
| `src/agents/prompts/experts/index.ts` | CREATE | 专家 prompt 注册表 + loadExpertPrompt() |
| `src/agents/prompts/experts/*.ts` (x11) | CREATE | 各专家 PromptTemplate 文件 |
| `src/agents/experts/registry.ts` | MODIFY | promptTemplate → promptRef |
| `src/agents/nodes/retrieval.ts` | MODIFY | 额外输出 expertPackages |
| `src/agents/nodes/reasoning.ts` | MODIFY | 消费 expertPackages 替代字符串拼接 |

### 核心设计
- ExpertReasoningPackage = retrieval→reasoning 的节点间契约
- 专家 prompt 的 build() 内聚格式化证据和工具结果（P1-3）
- toolResults 两阶段填充：retrieval 初始化空 / reasoning 填充（P1-2）
- LLM 输出由 reasoningPrompt.parse() 统一解析，ExpertPromptOutput 仅用于 build 阶段（P1-1）

### 关键契约
- LLM 调用次数保持单次（不增加）
- buildAnalysisExpertContext() 保留 @deprecated（向后兼容）
- state.expertPackages 为 undefined 时回退旧路径

### 恢复上下文审计查询
```
query_audit_logs({ keyword: "reasoning-structured-dataflow" })
query_audit_logs({ targetId: "reasoning.ts" })
query_audit_logs({ action: "DOC_CREATED" })
```

### 验证标准
- 已完成：`npx tsc --noEmit` 零错误 ✅
- 未执行：回归测试

### 🔧 第1轮后续修正（2026-06-15）

本日对已交付代码做了两处架构修正：

| 修正 | 文件 | 变更 | 原因 |
|------|------|------|------|
| P3-1：base prompt 移除全局证据摘要 | `reasoning.ts` L170 | `evidenceList: []`（新路径） | 旧架构残留——字符串拼接模式下无 per-expert 分组，只能把全局证据塞进 base prompt 让 LLM 猜归属。新路径下 `expertPackages[i].evidences` 已按专家分组并注入各专家 block，base prompt 再塞全局证据是噪音 |
| C13 修复：证据不截断 | `retrieval.ts` L85 | `ev.content.slice(0,200)` → `ev.content` | Plan 明确写"不截断"，但代码实现遗漏了 |
| registry 清理 promptTemplate | `registry.ts` | 接口删 `promptTemplate` 字段，11 个专家条目删内联文本 | Task 3 遗留——`prompts/experts/` 就绪后，`promptTemplate` 内联文本是死代码。旧路径 `buildAnalysisExpertContext()` 改为调用 `loadExpertPrompt()` |

同步更新：
- Plan §3.4 prompt 结构图移除"全局证据摘要"行
- Plan §7 Review 回流表新增 P3-1 条目
- reasoning.ts `buildAnalysisExpertContext()` 改用 `loadExpertPrompt(expert.id)`
- registry.ts 接口和 11 个条目删除 `promptTemplate`（-153 行）

### ADD-7 审计记录
见 add-route 附录文件清单。
