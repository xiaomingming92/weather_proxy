# farm-agent-pagination-dry-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。精确函数签名和 WHEN-THEN 场景留给 Spec。

## PLAN 元信息

- **Plan 名称**: farm-agent-pagination-dry-plan-v1
- **启动时间**: 2026-06-15T00:00:00Z
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/farm-agent-pagination-dry-add-route-v1.md`
  - Handoff: `.qoder/plans/farm-agent-pagination-dry-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-pagination-dry-review-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/agents/tools/schemas/farm-data-tools.ts` | SCHEMA | SCHEMA_FIELD_ADDED | 仅有 SoilMoisturePageSchema/SoilMoistureGetSchema | 新增 BasePageParams 导出 | 待实施 |
| `src/agents/tools/impl/farm-data-tools.ts` | COMPONENT | COMPONENT_MODIFIED | 4 个内联 pageNo/pageSize 定义，InsectDataPageSchema 和 FarmWeatherPageSchema 无 dataTime | 引用 BasePageParams spread，补全 dataTime | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

1. **分页参数 DRY 违规**：`pageNo` + `pageSize` 的 zod 定义在 5 处重复：
   - `SoilMoisturePageSchema`（schemas/farm-data-tools.ts）
   - `InsectDataPageSchema`（farm-data-tools.ts 内联）
   - `FarmWeatherPageSchema`（farm-data-tools.ts 内联）
   - `MassifPageSchema`（farm-data-tools.ts 内联）
   - `InsectTypePageSchema`（farm-data-tools.ts 内联）

   所有 5 处的约束完全一致：`pageNo.min(1).default(1)` + `pageSize.min(1).max(200).default(20)`。修改 default 值需要改 5 个地方，极易遗漏。

2. **时间范围参数缺失**：Farm-Server API 的 `/insect-data/page` 和 `/weather-data/page` 均支持 `dataTime` 查询参数（`String[]`，格式 `["开始日期","结束日期"]`），但对应工具 schema 未定义该字段。后果：
   - 周报专家调用 `query_insect_data` / `query_farm_weather` 时拿不到本周数据，而是拿全量历史数据的前 20 条
   - LLM 无法通过时间范围过滤数据，分析结论偏离业务意图

   已有 `SoilMoisturePageSchema` 的 `dataTime: z.array(z.string()).optional()` 是正确的示范，其他工具应补齐。

### 1.2 目标

- 提取 `BasePageParams` 共享分页 zod 定义，一处修改全局生效
- 为 `InsectDataPageSchema`、`FarmWeatherPageSchema` 补全 `dataTime` 参数
- 同步更新工具函数入参解构，透传 `dataTime` 到 Farm-Server 调用

---

## 二、方案选型

| 方案 | 复用方式 | 类型安全 | 侵入性 | 结论 |
|------|---------|---------|--------|------|
| A: 提取 `BasePageParams` 对象 spread 引用 | `{...BasePageParams, massifId: ...}` | ✅ 类型自动推导 | 低（仅改 schema 定义处） | ✅ 采用 |
| B: 用 `z.object(BasePageParams).extend({...})` | `.extend()` | ✅ 但需构造 z.object | 中（需改调用链） | ❌ 过度 |
| C: 不提取，只在文档中约定 | 无 | ❌ 靠人记忆 | 无 | ❌ 治标不治本 |

**选型理由**：方案 A 改动最小、类型推导最直觉，与 `SoilMoisturePageSchema` 现有风格一致。方案 B 需要 `.extend()` 嵌套，对现有简单 schema 是过度工程。

---

## 三、架构设计

### 3.1 改动范围

```
src/agents/tools/
├── schemas/
│   └── farm-data-tools.ts          ← 新增 BasePageParams 导出
└── impl/
    └── farm-data-tools.ts          ← 引用 BasePageParams，补 dataTime，透传参数
```

### 3.2 数据流

```
LLM 调用 query_insect_data({ massifId:1, dataTime:["2026-06-08","2026-06-15"] })
  → InsectDataPageSchema (含 BasePageParams + dataTime)
    → farmServerPage("/insect-data/page", { pageNo, pageSize, massifId, dataTime })
      → Farm-Server GET /admin-api/farm/insect-data/page?...dataTime=2026-06-08,2026-06-15
```

### 3.3 BasePageParams 定义

```ts
// src/agents/tools/schemas/farm-data-tools.ts
export const BasePageParams = {
  pageNo: z.number().min(1).default(1).describe("页码"),
  pageSize: z.number().min(1).max(200).default(20).describe("每页条数"),
}
```

所有 PageSchema 改为 `{ ...BasePageParams, ...业务字段 }`。

`dataTime` 字段与 `SoilMoisturePageSchema` 已有定义一致：
```ts
dataTime: z.array(z.string()).optional().describe("数据时间范围 ['开始日期','结束日期']")
```

---

## 四、实施步骤 + 依赖图

```
Task 1 (提取 BasePageParams)
          │
          ▼
Task 2 (替换内联定义)
          │
          ▼
Task 3 (补 dataTime + 透传)
          │
          ▼
Task 4 (编译验证)
```

### Task 1: 提取 BasePageParams

**文件**: `src/agents/tools/schemas/farm-data-tools.ts`
- 新增 `BasePageParams` 导出对象
- `SoilMoisturePageSchema` 的 `pageNo`/`pageSize` 替换为 `...BasePageParams`

### Task 2: 内联定义替换

**文件**: `src/agents/tools/impl/farm-data-tools.ts`
- `import { BasePageParams, SoilMoisturePageSchema, SoilMoistureGetSchema }` 追加 `BasePageParams`
- `InsectDataPageSchema`、`FarmWeatherPageSchema`、`MassifPageSchema`、`InsectTypePageSchema` 中的 `pageNo`/`pageSize` 替换为 `...BasePageParams`

### Task 3: 补全 dataTime + 透传参数

**文件**: `src/agents/tools/impl/farm-data-tools.ts`
- `InsectDataPageSchema` 新增 `dataTime` 字段
- `FarmWeatherPageSchema` 新增 `dataTime` 字段
- `queryInsectDataTool` 的 `farmServerPage` 调用追加 `dataTime: params.dataTime`
- `queryFarmWeatherTool` 的 `farmServerPage` 调用追加 `dataTime: params.dataTime`

### Task 4: 编译验证

- `npx tsc --noEmit` 确认零错误
- 手动确认 zod schema 类型推断正确

---

## 五、验收标准

- [ ] `BasePageParams` 在 `schemas/farm-data-tools.ts` 中导出，`SoilMoisturePageSchema` 引用它
- [ ] 4 个内联 pageNo/pageSize 全部替换为 `...BasePageParams`
- [ ] `InsectDataPageSchema` 包含 `dataTime` 字段
- [ ] `FarmWeatherPageSchema` 包含 `dataTime` 字段
- [ ] `queryInsectDataTool` 透传 `dataTime` 到 Farm-Server
- [ ] `queryFarmWeatherTool` 透传 `dataTime` 到 Farm-Server
- [ ] `npx tsc --noEmit` 通过

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/farm-agent-pagination-dry-add-route-v1.md` |
| Handoff | `.qoder/plans/farm-agent-pagination-dry-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-pagination-dry-review-v1.md` |
| Spec | `.qoder/specs/farm-agent-pagination-dry/spec.md` |
| Tasks | `.qoder/specs/farm-agent-pagination-dry/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-pagination-dry/checklist.md` |
