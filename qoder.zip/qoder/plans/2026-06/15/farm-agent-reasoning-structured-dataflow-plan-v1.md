# farm-agent-reasoning-structured-dataflow-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。**不**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-reasoning-structured-dataflow-v1
- **启动时间**: 2026-06-15
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/farm-agent-reasoning-structured-dataflow-add-route-v1.md`
  - Handoff: `.qoder/plans/farm-agent-reasoning-structured-dataflow-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-reasoning-structured-dataflow-review-v1.md`
  - 前序 Plan: `.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-Prompt模板目录重构-plan-v1.md`（prompt 文本抽离，已完成）
  - 前序 Plan: `.qoder/plans/reasoning-chain-unification-plan-v1.md`（推理链统一，部分完成）

- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/agents/nodes/reasoning.ts` | COMPONENT | COMPONENT_MODIFIED | 字符串拼接模式，6段文本无序拼接 | 消费结构化 ExpertReasoningPackage，按专家分区调用 LLM | 待实施 |
| `src/agents/nodes/retrieval.ts` | COMPONENT | COMPONENT_MODIFIED | 返回 flat evidenceChain + retrievalContext | 额外返回 structured expertPackages（按 expertId 分组） | 待实施 |
| `src/agents/prompts/experts/*.ts` | COMPONENT | COMPONENT_CREATED | 不存在 | 每个核心专家独立 PromptTemplate 文件（build/parse/validate） | 待实施 |
| `src/agents/prompts/experts/index.ts` | COMPONENT | COMPONENT_CREATED | 不存在 | 专家 prompt 统一注册表 + loader | 待实施 |
| `src/agents/prompts/types.ts` | COMPONENT | COMPONENT_MODIFIED | 无 ExpertReasoningPackage 类型 | 新增 ExpertReasoningPackage / ExpertPromptInput / ExpertPromptOutput | 待实施 |
| `src/agents/experts/registry.ts` | COMPONENT | COMPONENT_MODIFIED | promptTemplate 为内联字符串 | promptRef 改为引用 prompts/experts/ 的 key，移除内联字符串 | 待实施 |
| `src/agents/state.ts` | COMPONENT | COMPONENT_MODIFIED | 无 expertPackages 字段 | AgentState 新增 expertPackages 字段 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

`reasoning` 节点当前采用**字符串拼接模式**，存在四个结构性缺陷：

**缺陷一：专家 Prompt 无结构化绑定**

`buildAnalysisExpertContext()` 将所有激活专家的 `promptTemplate` 拼成一个文本块追加到全局 prompt，LLM 无法区分"这段分析要求属于哪个专家"。

```
// 现状 — 所有专家信息拼成一个大文本块
const expertContextBlock = buildAnalysisExpertContext(...)
let finalPrompt = expertContextBlock ? `${prompt}\n\n${expertContextBlock}` : prompt
```

**缺陷二：工具结果无专家归属，粗暴截断 200 字符**

```
// 现状 — 工具结果按 toolName 字符串截断，无专家标注
toolResultsBlock = `[工具: ${tm.name}] ${contentStr.slice(0, 200)}`
```

`pest_risk` 声明了 `realtimeToolNames: ["query_farm_weather", "query_insect_data"]`，但工具结果进来后 reasoning 不知道归属，只能靠字符串猜。

**缺陷三：RAG 证据二次截断（300字符），浪费 retrieval 结构化成果**

retrieval 节点已做 per-expert grounding，证据已标注 `expertIds`，但 reasoning 节点重新拼字符串再截断，完全丢失 retrieval 的结构化成果。

**缺陷四：最终 Prompt 6段无序拼接**

```
basePrompt + expertContextBlock + perExpertBlock + reasoningContext + [RAG降级提示] + toolResultsBlock
```

LLM 要自己搞清楚哪些证据、工具结果、prompt 属于同一专家，极不可靠。

### 1.2 目标

将 reasoning 节点从"字符串拼接"改为"结构化 ExpertReasoningPackage"模式：

| 维度 | 现状 | 目标 |
|------|------|------|
| 专家 Prompt | 拼成文本块追加 | 每个专家独立 PromptTemplate，`build()` 接收专家专属输入 |
| RAG 证据 | 全局列表 + 事后分组（300字截断） | retrieval 直接传 `expertPackages[].evidences`，不二次截断 |
| 工具结果 | 200字截断，无专家归属 | 按 `realtimeToolNames` 归入对应 `expertPackages[].toolResults` |
| LLM 调用 | 单次全量调用，6段拼接 | 按专家分区构建 prompt，每次调用携带完整专家包 |
| registry 职责 | 元数据 + prompt 文本混合 | registry 只管元数据，prompt 文件管 build/parse/validate |

---

## 二、方案选型

### 2.1 候选方案对比

| 方案 | 专家隔离度 | LLM 调用次数 | Token 效率 | 改造成本 | 结论 |
|------|-----------|-------------|-----------|---------|------|
| A: 多专家并行调用（每专家一次 LLM） | 完全隔离 | N次（N=激活专家数） | 低（重复框架prompt） | 高（需并发控制） | 否决 |
| B: 单 LLM 调用 + 结构化分区 prompt | 语义分区 | 1次 | 高 | 中 | **选用** |
| C: 保持现状，只把字符串替换为 JSON | 无改善 | 1次 | 中 | 低 | 否决 |

### 2.2 选型理由

**方案 B** 的核心设计：单次 LLM 调用，但 prompt 按专家分区结构化组织，每个专家区块内完整包含该专家的 prompt要求 + RAG 证据 + 工具结果，LLM 在一个请求内按分区产出各专家结论。

- 不增加 LLM 调用次数（成本可控）
- 每个专家区块自包含（LLM 无需跨段推理归属）
- 与现有单次调用架构兼容（最小改动面）

---

## 三、架构设计

### 3.1 新数据流全貌

```
retrieval 节点
  ↓ 产出 evidenceChain（现有，不变）
  ↓ ★ 额外产出 expertPackages（按 expertId 分组）
  ↓   每个 package 含：evidences[] + promptRef + runtimeInputs

ToolNode（LangGraph 工具执行）
  ↓ state.messages 中 role="tool" 的消息

reasoning 节点
  ↓ ★ 从 state.expertPackages 读取专家包
  ↓ ★ 从 state.messages 过滤 tool messages，按 realtimeToolNames 归入对应包
  ↓ ★ 加载 prompts/experts/{expertId}.ts 的 PromptTemplate
  ↓ ★ 调用 expertPrompt.build({ evidences, toolResults, runtimeInputs })
  ↓ ★ 拼接分区 prompt（每专家一个完整区块）
  ↓ 单次 LLM 调用 → parse → validate
  ↓ 产出 verdictResult
```

### 3.2 `ExpertReasoningPackage` 数据结构

```
ExpertReasoningPackage {
  expertId: string           // e.g. "pest_risk"
  label: string              // e.g. "病虫害风险评估"
  promptRef: string          // 指向 prompts/experts/ 下的文件 key

  // 1. RAG 证据（retrieval 节点已分组，不截断）
  evidences: Array<{
    id: string
    content: string          // 完整内容
    source: string
    relevance: number
    grounded: boolean
  }>

  // 2. 工具结果（reasoning 节点按 realtimeToolNames 归集）
  toolResults: Array<{
    toolName: string
    content: string          // 不截断
    status: "success" | "error"
  }>

  // 3. 运行时输入（来自 analysisContext.runtimeInputs）
  runtimeInputs: Record<string, string>
}
```

### 3.3 专家 Prompt 文件结构（含 Review P1-1/P1-3 回流）

每个专家在 `src/agents/prompts/experts/` 下有独立文件，复用现有 `PromptTemplate<TInput, TOutput>` 接口：

**`ExpertPromptOutput` 的职责边界（P1-1 回流）**：
- `ExpertPromptOutput` 仅用于 `build()` 阶段，描述该专家期望的输出格式提示（注入到 prompt 文本中）
- LLM 最终输出由 `reasoningPrompt.parse()` 统一解析，各专家结论从 `conclusion.content` 中按专家分区提取
- 即：专家 prompt 文件的 `parse()/validate()` 不在主流程中调用，仅供独立测试使用

**`build()` 的内聚职责（P1-3 回流）**：
- `build()` 负责格式化证据列表和工具结果（内聚在专家 prompt 文件中）
- 不同专家可以有不同的证据展示方式（如 pest_risk 按风险等级排序，roi_analysis 用数值表格）
- reasoning 节点只需拼接各专家区块，无需关心格式化细节

```
src/agents/prompts/experts/
├── index.ts              ← 专家 prompt 注册表 + loadExpertPrompt() 函数
├── crop-compare.ts       ← PromptTemplate<CropCompareInput, ExpertPromptOutput>
├── pest-risk.ts
├── weather-impact.ts
├── roi-analysis.ts
├── nutrition-diagnose.ts
├── growth-report.ts
├── planting-advice.ts
├── work-plan.ts
├── machinery-dispatch.ts
├── daily-report.ts
└── weekly-report.ts
```

每个文件的 `build()` 接收结构化输入：
- `query`：用户问题
- `runtimeInputs`：运行时参数（作物、地块等）
- `evidences`：专家专属 RAG 证据（完整内容）
- `toolResults`：专家专属工具结果

### 3.4 reasoning 节点 prompt 结构（改造后）

新路径下证据由各专家 block 自携带，base prompt 只包含 query，不重复注入全局证据摘要：

```
[全局框架 prompt]
用户问题：{query}

[专家分区 — 每专家一个完整区块，由 expertPrompt.build() 生成]
═══ 专家1：pest_risk（病虫害风险评估）═══
{pest_risk_prompt}          ← pest-risk.ts build() 产出
【RAG证据】{完整内容，不截断}   ← 仅该专家相关的证据，非全局
【工具结果】query_farm_weather: {...}
           query_insect_data: {...}

═══ 专家2：weather_impact（气象影响分析）═══
{weather_impact_prompt}
【RAG证据】{完整内容}
【工具结果】query_farm_weather: {...}

[全局工具结果 — 无归属的工具消息]
[多子问题上下文 — 来自 subIntentPlan.reasoningContext]
[输出格式要求 — 按专家分区输出 JSON]
```

---

## 四、实施步骤 + 依赖图

```
Task 1（类型定义）
   ├──→ Task 2（专家prompt文件，依赖 Task 1 的类型）  ← 可并行
   ├──→ Task 3（registry解耦，依赖 Task 1 的类型）    ← 可并行
   └──→ Task 4（retrieval，依赖 Task 1 类型 + Task 3 promptRef）
                 │
Task 2 + Task 3 + Task 4 ──→ Task 5（reasoning 消费结构化包）
                                │
                                ▼
                             Task 6（编译验证 + 回归）
```

### Task 1：类型层改造

**改动文件**：`src/agents/prompts/types.ts`、`src/agents/state.ts`

- `types.ts` 新增 `ExpertReasoningPackage`、`ExpertPromptInput`、`ExpertPromptOutput` 接口
- `state.ts` 的 `AgentState` 新增 `expertPackages` 字段（可选，向后兼容）

### Task 2：专家 Prompt 文件创建

**新建目录**：`src/agents/prompts/experts/`

为每个在 `ANALYSIS_EXPERTS` 注册的专家创建独立 prompt 文件，实现 `PromptTemplate<ExpertPromptInput, ExpertPromptOutput>`：
- `build()` 接收结构化输入（query + evidences + toolResults + runtimeInputs），输出该专家区块的完整 prompt 文本
- `parse()` / `validate()` 复用标准输出格式（结论 + 行动建议 + 风险项）

同时实现 `index.ts`：
- `loadExpertPrompt(expertId)` 函数：从注册表加载对应 prompt 模块
- 专家 prompt 注册表（Map<string, PromptTemplate>）

### Task 3：registry 与 prompt 解耦

**改动文件**：`src/agents/experts/registry.ts`

- `AnalysisExpert.promptTemplate` 字段废弃，替换为 `promptRef: string`（指向 prompts/experts/ 的 key）
- 保留其他元数据字段（id、domain、inputSchema、grounding、realtimeToolNames 等）不变

### Task 4：retrieval 节点输出 expertPackages（含 Review P1-2 回流）

**改动文件**：`src/agents/nodes/retrieval.ts`

在现有 `evidenceChain` 产出基础上，额外构建 `expertPackages`：
- 遍历 per-expert 检索结果（已有 `_expertIds` 标注），按 expertId 分组
- 每个 package 填充 `evidences[]`（完整 content，不截断）
- `runtimeInputs` 从 `analysisContext.runtimeInputs` 读取
- `promptRef` 从 registry 读取
- **`toolResults` 初始化为空数组 `[]`**（P1-2 回流：tool 消息在 retrieval 阶段尚未产生，由 reasoning 节点填充）
- 返回时同时写 `state.expertPackages`

### Task 5：reasoning 节点消费结构化包（含 Review P1-2/P2-1 回流）

**改动文件**：`src/agents/nodes/reasoning.ts`

- 从 `state.expertPackages` 读取专家包列表
- **填充 `toolResults`（P1-2 回流）**：从 `state.messages` 过滤 `role="tool"` 消息，按各专家包的 `realtimeToolNames`（从 registry 读取）归入对应 `package.toolResults`
- 无归属的工具结果写入 `globalToolResults`
- 对每个 package 调用 `loadExpertPrompt(expertId).build(...)`，生成该专家的区块 prompt（build 内聚格式化，P1-3）
- 拼接全局 prompt：框架 prompt + 各专家区块 + subIntentContext + 全局工具结果 + 输出格式要求
- LLM 单次调用，`reasoningPrompt.parse()` 统一解析（P1-1）

**新增审计阶段字面量（P2-1 回流）**：
- `REASONING_EXPERT_PACKAGE_CONSUME`：开始消费专家包
- `REASONING_TOOL_ATTRIBUTION`：工具结果归属完成
- `REASONING_EXPERT_PROMPT_BUILD`：各专家区块 prompt 构建完成

### Task 6：编译验证 + 回归测试

- `npx tsc --noEmit` 零错误
- 回归：用现有对话触发分析，验证 LLM prompt 输出结构正确（各专家区块完整、工具结果归属正确）

---

## 五、验收标准

- [ ] `ExpertReasoningPackage` 类型定义完整，`AgentState` 已扩展
- [ ] `src/agents/prompts/experts/` 下每个专家有独立 PromptTemplate 文件
- [ ] `registry.ts` 的 `promptTemplate` 字段已替换为 `promptRef`
- [ ] `retrieval.ts` 额外输出 `expertPackages`（evidences 不截断）
- [ ] `reasoning.ts` 消费 `expertPackages`，不再拼接 expertContextBlock / perExpertBlock / toolResultsBlock
- [ ] 工具结果按 `realtimeToolNames` 归入对应专家包，不再 200 字符截断
- [ ] LLM 调用次数不变（单次调用），prompt 结构按专家分区
- [ ] `npx tsc --noEmit` 零错误
- [ ] 回归测试：分析对话触发后，各专家区块 prompt 完整、工具归属正确

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/farm-agent-reasoning-structured-dataflow-add-route-v1.md` |
| Handoff | `.qoder/plans/farm-agent-reasoning-structured-dataflow-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-reasoning-structured-dataflow-review-v1.md` |
| Spec | `.qoder/specs/farm-agent-reasoning-structured-dataflow/spec.md` |
| Tasks | `.qoder/specs/farm-agent-reasoning-structured-dataflow/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-reasoning-structured-dataflow/checklist.md` |
| 前序 Plan（Prompt重构） | `.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-Prompt模板目录重构-plan-v1.md` |
| 前序 Plan（推理链统一） | `.qoder/plans/reasoning-chain-unification-plan-v1.md` |
| reasoning 节点现状 | `src/agents/nodes/reasoning.ts` |
| retrieval 节点现状 | `src/agents/nodes/retrieval.ts` |
| 专家注册表现状 | `src/agents/experts/registry.ts` |
| 裁决预算现状 | `src/caijuehub/strategies/sub-intent.ts` |

---

## 七、Review 回流记录（Step 0.6.5）

> 回流时间：2026-06-15，来源：`farm-agent-reasoning-structured-dataflow-review-v1.md`

| Review 问题 | 回流位置 | 回流内容 |
|------------|---------|----------|
| P1-1：ExpertPromptOutput 与 ReasoningOutput 关系未明确 | Plan §3.3 + Task 5 | 明确 ExpertPromptOutput 仅用于 build 阶段，LLM 输出由 reasoningPrompt.parse() 统一解析 |
| P1-2：toolResults 两阶段填充未说明 | Plan §4 Task 4 + Task 5 | retrieval 初始化空数组，reasoning 填充 toolResults |
| P1-3：build() 格式化职责归属未明确 | Plan §3.3 + Task 5 | build() 内聚格式化证据和工具结果，reasoning 只拼接区块 |
| P2-1：审计阶段字面量未列出 | Plan Task 5 | 补充三个新增审计阶段字面量 |
| P2-2：汇总专家 build() 扩展参数 | Plan Task 2 + §七回流表 | 汇总专家（daily/weekly-report）的 `ExpertPromptInput` 需额外字段 `coreExpertConclusions?: string`，当前版本用空字符串占位，具体实现推迟至汇总专家功能落地 |
| P3-1：新路径 base prompt 移除全局证据摘要 | Plan §3.4 + reasoning.ts L170 | 旧架构的 `全局证据摘要：{globalEvidences}` 是字符串拼接模式的残留——当时没有 per-expert 分组，只能把全部证据塞进 base prompt 让 LLM 猜归属。新路径下 `expertPackages[i].evidences` 已按专家分组并注入各专家 block，base prompt 的 `evidenceList` 设为空数组，避免全局证据噪音干扰专家推理 |
