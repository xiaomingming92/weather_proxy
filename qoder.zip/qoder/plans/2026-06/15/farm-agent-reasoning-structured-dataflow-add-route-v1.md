# farm-agent-reasoning-structured-dataflow-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。
> **模式**：重型（Heavyweight）
> **绑定**：Plan: `.qoder/plans/farm-agent-reasoning-structured-dataflow-plan-v1.md` · Spec: `.qoder/specs/farm-agent-reasoning-structured-dataflow/spec.md` · Tasks: `.qoder/specs/farm-agent-reasoning-structured-dataflow/tasks.md` · Handoff: `.qoder/plans/farm-agent-reasoning-structured-dataflow-handoff-v1.md`

---

## Step 0：文档先行 ✅ 进行中

- [x] Specs 三元组就绪：spec.md + tasks.md + checklist.md
- [x] Review 已生成（P1-1/P1-2/P1-3 已回流至 Plan）
- [x] Plan 依赖图已对齐 tasks.md（F1 修复）
- [x] add-route 本文件已生成
- [x] handoff 骨架已创建

### §0.8 DPS 闸门

- [x] DPS ≥ 85（Specs 25/25，Review 5/5，Plan 80/100）

---

## Step 1：功能分析与审计阶段定义

**新增审计阶段**：

| Phase | 使用场景 | Task |
|-------|---------|------|
| `REASONING_EXPERT_PACKAGE_CONSUME` | reasoning 节点开始消费 expertPackages | Task 5 |
| `REASONING_TOOL_ATTRIBUTION` | 工具结果归属到各专家包完成 | Task 5 |
| `REASONING_EXPERT_PROMPT_BUILD` | 各专家区块 prompt 构建完成 | Task 5 |

- [x] `AgentAuditPhase` 联合类型已扩展

---

## Step 2：审计基础设施确认

- [x] `agentAudit()` 接受新增字面量（复用现有通道，无需新建 logger）

---

## Step 3：业务逻辑实现与审计植入

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | 类型层改造 | `prompts/types.ts`、`state.ts` | 无（纯类型） | — | 无 | ✅ |
| 2 | 专家 Prompt 文件 | `prompts/experts/*.ts` | 无（新建文件） | — | Task 1 | ✅ |
| 3 | registry 解耦 | `experts/registry.ts` | 无（结构变更） | — | Task 1 | ✅ |
| 4 | retrieval expertPackages | `nodes/retrieval.ts` | `agentAudit("EXPERT_PACKAGES_BUILT", ...)` | `EXPERT_PACKAGES_BUILT` | Task 1+3 | ✅ |
| 5 | reasoning 消费结构化包 | `nodes/reasoning.ts` | 3个新 Phase | 见 Step 1 | Task 2+3+4 | ✅ |
| 6 | 编译验证 | — | — | — | Task 5 | ✅ |

### 依赖拓扑

```
Task 1（类型定义）
   ├──→ Task 2（专家prompt文件）← 可并行
   ├──→ Task 3（registry解耦）  ← 可并行
   └──→ Task 4（retrieval）
                 │
Task 2 + 3 + 4 ──→ Task 5（reasoning）
                       │
                       ▼
                    Task 6（验证）
```

---

## Step 4：审计数据验证

- [x] `tsc --noEmit` 通过
- [ ] `check_phase_symmetry` 通过
- [ ] `check_failure_path` 通过
- [ ] `check_spec_sync` 通过
- [ ] RAHS ≥ 90

---

## Step 5：AI 自动合规检查

- [ ] `check_add_compliance` 对 reasoning.ts、retrieval.ts、registry.ts 扫描通过

---

## Step 8：收敛判断 + Handoff 更新

- [ ] 功能收敛判定
- [x] Handoff 已更新
- [ ] ADD-7 审计记录已落库

---

## 附录：ADD-7 文件清单

| 文件 | 操作 | Task | targetType | beforeState | afterState | 状态 |
|------|------|------|-----------|-------------|------------|------|
| `src/agents/prompts/types.ts` | MODIFY | 1 | TYPE | 无 ExpertReasoningPackage | 新增 ExpertReasoningPackage/ExpertPromptInput/ExpertPromptOutput | ✅ |
| `src/agents/state.ts` | MODIFY | 1 | STATE | 无 expertPackages | AgentState 新增 expertPackages? | ✅ |
| `src/agents/prompts/experts/index.ts` | CREATE | 2 | COMPONENT | 不存在 | 专家 prompt 注册表 + loadExpertPrompt() | ✅ |
| `src/agents/prompts/experts/*.ts` (x11) | CREATE | 2 | COMPONENT | 不存在 | 各专家 PromptTemplate 文件 | ✅ |
| `src/agents/experts/registry.ts` | MODIFY | 3 | COMPONENT | promptTemplate 内联字符串 | 新增 promptRef + @deprecated promptTemplate | ✅ |
| `src/agents/nodes/retrieval.ts` | MODIFY | 4 | COMPONENT | 返回 flat evidenceChain | 额外返回 expertPackages | ✅ |
| `src/agents/nodes/reasoning.ts` | MODIFY | 5 | COMPONENT | 字符串拼接模式 | 消费 expertPackages 结构化包 | ✅ |
