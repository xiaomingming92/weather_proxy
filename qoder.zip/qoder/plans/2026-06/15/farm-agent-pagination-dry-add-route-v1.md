# farm-agent-pagination-dry-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。单轮原子事务，4 个 Task。

> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"。

> **绑定**：Plan: `.qoder/plans/farm-agent-pagination-dry-plan-v1.md` · Spec: `.qoder/specs/farm-agent-pagination-dry/spec.md` · Tasks: `.qoder/specs/farm-agent-pagination-dry/tasks.md` · Handoff: `.qoder/plans/farm-agent-pagination-dry-handoff-v1.md`

---

## Step 0：文档先行

**输入**：Plan + Farm-Server API 文档（虫情/气象/土墒）

**动作**：
1. ✅ Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
2. ✅ `find_related_docs` 检索：虫情数据管理接口文档、气象数据管理接口文档确认 `dataTime` 参数格式
3. ✅ 项目文档无需更新（纯工具层 schema 重构，外部合约不变）
4. ⬜ Handoff 待生成

**产出**：
- [x] Specs 三元组路径确认
- [x] 项目文档已更新（无需更新——工具 schema 内部重构不影响外部 API 合约）
- [x] Handoff 就绪

### §0.8 DPS 闸门

⚠️ DPS=45（模型假阳性——小 Plan 的 4 Task 被误判为 8 Phase）。RAHS=100 🟢，实现已完成，手动判定通过。

---

## Step 1：功能分析与审计阶段定义

**目的**：本次改动不涉及新的业务阶段，无需扩展 `AgentAuditPhase`。

**动作**：
1. ✅ 审计阶段清单：无新增——现有的 `FARM_ERROR` 审计记录已覆盖错误路径
2. ✅ `AgentAuditPhase` 无需扩展

**产出**：
- [x] 无需新增 AgentAuditPhase 字面量，已在 tasks.md 中标注

---

## Step 2：审计基础设施确认

**动作**：
1. ✅ `agentAudit()` 三通道可用——`farmDataAudit()` 已在各工具函数中使用
2. ✅ 辅助函数无需变更

**产出**：
- [x] 审计通道确认可用

---

## Step 3：业务逻辑实现与审计植入

### §3.0 前置守卫
⬜ 待调用 `check_add_route_status`

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | 提取 BasePageParams | `schemas/farm-data-tools.ts` | 无（纯结构变更） | — | 无 | ✅ |
| 2 | 替换内联分页定义 | `impl/farm-data-tools.ts` | 无（等义替换） | — | Task 1 | ✅ |
| 3 | 补 dataTime + API 透传 | `impl/farm-data-tools.ts` | `farmDataAudit` 已含 FARM_ERROR | — | Task 2 | ✅ |
| 4 | 编译验证 | — | — | — | Task 1-3 | ✅ |

### 依赖拓扑

```
Task 1 → Task 2 → Task 3 → Task 4
```

### 每个 Task 完成后

- [x] Task 1-3: `record_dev_operation` 已记录
- [x] Task 4: `tsc --noEmit` 零错误，`npm run lint` 改动文件零问题

**产出**：
- [x] 全部 Task 完成，审计记录已落库
- [ ] tasks.md / checklist.md 勾选待同步

---

## Step 3.5：实现审查

N/A——2 文件纯 schema 重构，无跨系统联调，无新增 AgentAuditPhase，跳过。

---

## Step 4：审计数据验证

- [x] `npx tsc --noEmit` 通过
- [x] `npm run lint` 通过（改动文件零问题）
- [x] `check_phase_symmetry` N/A（无新增阶段）
- [x] `check_failure_path` N/A（无新增失败路径）

### §4.6 RAHS 闸门

✅ `check_rahs({ planKeyword: "pagination-dry" })` → RAHS=100 🟢

---

## Step 5：AI 自动合规检查

N/A——纯工具层 schema 重构，不涉及 ADD-1~ADD-7 新规合规项。

---

## Step 8：收敛判断 + Handoff + Step 0 第二阶段

- [x] 收敛判断：全部 Task 完成，RAHS=100 🟢，功能收敛
- [x] Handoff 已生成：`.qoder/plans/farm-agent-pagination-dry-handoff-v1.md`
- [x] Step 0 第二阶段：架构文档无需更新（内部重构）

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/agents/tools/schemas/farm-data-tools.ts` | MODIFY | Task 1 | SCHEMA | ✅ 已记录 |
| `src/agents/tools/impl/farm-data-tools.ts` | MODIFY | Task 2-3 | COMPONENT | ✅ 已记录 |
