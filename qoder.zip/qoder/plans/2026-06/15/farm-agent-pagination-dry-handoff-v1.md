# farm-agent — 分页参数 DRY 抽取 + 时间参数补全 交接手册

> **适用场景**：单轮变更，2 个文件，4 个 Task。

---

## 1. 交接前状态

- `pageNo`/`pageSize` zod 定义在 5 处重复（schemas 1 处 + impl 4 处内联）
- `InsectDataPageSchema` 和 `FarmWeatherPageSchema` 无 `dataTime` 参数
- 周报/日报专家调用 `query_insect_data` / `query_farm_weather` 时无法按时间窗口过滤

---

## 2. 交接后状态（目标）

- `BasePageParams` 统一导出自 `schemas/farm-data-tools.ts`，所有 PageSchema 通过 `...BasePageParams` 引用
- `InsectDataPageSchema` + `FarmWeatherPageSchema` 支持 `dataTime` 可选参数
- 工具函数透传 `dataTime` 到 Farm-Server API
- `tsc --noEmit` 零错误

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/agents/tools/schemas/farm-data-tools.ts` | 修改 | 新增 `BasePageParams` 导出，`SoilMoisturePageSchema` 引用它 |
| 2 | `src/agents/tools/impl/farm-data-tools.ts` | 修改 | 4 处内联 → `...BasePageParams`；`InsectDataPageSchema` + `FarmWeatherPageSchema` 补 `dataTime`；透传参数 |

---

## 4. 回滚方案

```bash
git checkout -- src/agents/tools/schemas/farm-data-tools.ts src/agents/tools/impl/farm-data-tools.ts
```

无数据迁移，纯代码回滚即可。

---

## 5. 执行前置检查

- [x] `npx tsc --noEmit` 零错误
- [x] `npm run lint` 改动文件零问题
- [x] ADD-7 审计记录已落库

---

## 6. 执行步骤摘要

```
Task 1: 提取 BasePageParams → schemas/farm-data-tools.ts
            │
            ▼
Task 2: 替换 4 处内联定义 → impl/farm-data-tools.ts
            │
            ▼
Task 3: 补 dataTime + API 透传 → impl/farm-data-tools.ts
            │
            ▼
Task 4: npx tsc --noEmit ✅
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| `InsectTypePageSchema` / `MassifPageSchema` 的 `pageSize` default 为 200（非 20） | spread 后又覆盖了 default | ✅ 已处理——spread 后显式声明 `pageSize: ...default(200)` |
| `dataTime` 为 optional，LLM 可能不传 | 仍查全量数据（向后兼容） | 可接受——option 语义正确 |

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

> 共 2 条 `record_dev_operation` 记录可恢复完整开发上下文。

### 总体一键恢复

```text
query_audit_logs({ keyword: "pagination-dry" })
```
→ 预期返回 2+ 条记录

### 逐文件审计查询

```text
query_audit_logs({ targetId: "src/agents/tools/schemas/farm-data-tools.ts" })
→ 预期返回 SCHEMA_FIELD_ADDED: 新增 BasePageParams 导出

query_audit_logs({ targetId: "src/agents/tools/impl/farm-data-tools.ts" })
→ 预期返回 COMPONENT_MODIFIED: 替换内联定义 + 补 dataTime + 透传
```

### 恢复判定标准

- action 命中数 ≥ 2
- grep 验证命令：

```bash
grep -R "BasePageParams" src/agents/tools/
```

---

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过
- [x] 所有文件改动已记录 ADD-7 审计
- [x] checklist.md 全部项已勾选
- [x] tasks.md 全部 Task 已勾选
- [x] RAHS = 100 🟢
