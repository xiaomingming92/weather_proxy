# farm-agent — 瑞丰耘H5 API v2（服务账户认证 + 生产计划路径重构 + 农情报告 + 完成/取消 + 地块释放）交接手册

> **适用场景**：多轮变更。Plan: `farm-agent-ruifengyun-h5-api-plan-v2.md`
> **最新修订**: 2026-06-24 — 新增 nongqing 任务/处方完成取消、计划状态化、图片上传、定时任务自动释放地块

---

## 1. 交接前状态

- H5 API v1 已上线：5 个端点（handshake + agent SSE + land-analysis + variety-recommend + cost-accounting）
- 认证方式：per-user 握手（`X-Session-Id` → `H5Session` 表 → userId），token 加密存储于 `FarmServerCredential(userId, source="h5")`
- 路径：`/api/h5/land-analysis`、`/api/h5/variety-recommend`、`/api/h5/cost-accounting`
- 缺失 Step 5 计划生成端点（v1 Spec 禁止实现）

---

## 2. 交接后状态（目标）

- **认证**：新增服务账户认证通道（API Key / JWT 可切换），与旧 sessionId 通道并存
- **路径**：3 个业务端点迁移至 `/api/h5/production-plan/*`
- **新增**：`POST /api/h5/production-plan/generate`（阶段1：假数据，含地块原子冲突检查）
- **新增**：`PATCH /api/h5/production-plan/plans/{id}` — 计划完成/重新激活
- **新增**：`GET / PATCH /api/h5/nongqing/tasks/{id}` — 任务详情+标记/取消完成
- **新增**：`GET / PATCH /api/h5/nongqing/prescriptions/{id}` — 处方详情+填报/取消完成
- **新增**：`POST /api/h5/upload/image` — 图片上传
- **新增**：`scripts/auto-complete-plans.ts` — 定时任务自动释放到期地块
- **Agent 改造**：`/api/h5/agent` 移除 handshake type，改为 `body.userId` 直通线程
- **废弃**：`/api/h5/handshake` 已删除

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `prisma/schema.prisma` | 新增 | `ServiceAccount` 模型（apiKey 可选，支持 apikey/jwt） |
| 2 | `scripts/seed-service-account.ts` | 新建 | 服务账户种子脚本，输出明文 API Key |
| 3 | `src/caijuehub/strategies/service-auth-resolver.ts` | 新建 | 策略模式：`ApiKeyResolver` + `JwtResolver`，`H5_SERVICE_AUTH_MODE` 切换 |
| 4 | `src/caijuehub/strategies/h5-auth-gateway.ts` | 修改 | 双模式裁决：`service`（ApiKey/JWT）+ `session`（sessionId） |
| 5 | `src/lib/agent-audit-logger.ts` | 修改 | 新增 `SERVICE_AUTH` + `H5_PLAN_GENERATE` 审计阶段 |
| 6 | `src/lib/auth/token-manager.ts` | 修改 | `RequestSource` 加 `"service"` |
| 7 | `src/app/api/h5/production-plan/land-analysis/route.ts` | 迁移+修改 | 路径迁移 + `X-Api-Key` 认证 |
| 8 | `src/app/api/h5/production-plan/variety-recommend/route.ts` | 迁移+修改 | 路径迁移 + `X-Api-Key` 认证 |
| 9 | `src/app/api/h5/production-plan/cost-accounting/route.ts` | 迁移+修改 | 路径迁移 + `X-Api-Key` 认证 |
| 10 | `src/app/api/h5/production-plan/generate/route.ts` | 新建 | 计划生成端点（阶段1：假数据） |
| 11 | `src/app/api/h5/agent/route.ts` | 修改 | 去 handshake + `body.userId` 线程隔离 + 服务认证 |
| 12 | `src/app/api/h5/handshake/route.ts` | 删除 | 废弃 per-user 握手 |
| 13 | `src/app/api/h5/land-analysis/` | 删除 | 旧路径 |
| 14 | `src/app/api/h5/variety-recommend/` | 删除 | 旧路径 |
| 15 | `src/app/api/h5/cost-accounting/` | 删除 | 旧路径 |
| 16 | `docs/.../02-规范/瑞丰耘H5小程序API对接文档.md` | 更新 | v4.2：计划状态化 + 任务/处方完成取消 + 图片上传 + 自动完成 |
| 17 | `prisma/nongqing.prisma` | 修改 | ProductionPlan +status/massifIds，FarmTask +completion |
| 18 | `prisma/migrations/*` | 新建 | 3个迁移：status + massifIds + completion |
| 19 | `src/app/api/h5/nongqing/overview/route.ts` | 修改 | 支持 planId 精确查询 |
| 20 | `src/app/api/h5/nongqing/tasks/[id]/route.ts` | 修改 | PATCH 标记/取消完成（快速标记+表单填报+软撤销） |
| 21 | `src/app/api/h5/nongqing/prescriptions/[id]/route.ts` | 修改 | PATCH 填报/取消完成（软撤销） |
| 22 | `src/app/api/h5/production-plan/plans/[id]/route.ts` | 新建 | PATCH 计划完成/重新激活 |
| 23 | `src/app/api/h5/upload/image/route.ts` | 新建 | 图片上传（multipart, 三级路径隔离） |
| 24 | `scripts/auto-complete-plans.ts` | 新建 | 定时任务：每天02:30自动完成到期计划 |

---

## 4. 回滚方案

### 代码回滚
```bash
git checkout src/app/api/h5/agent/route.ts        # 恢复 agent v1
git checkout src/caijuehub/strategies/h5-auth-gateway.ts  # 恢复网关 v1
rm -rf src/app/api/h5/production-plan             # 删除新路径
# 恢复旧路径需从 git 历史还原
```

### 数据回滚
```bash
# ServiceAccount 表无破坏性，可保留或删除
DROP TABLE IF EXISTS "ServiceAccount";
```

---

## 5. 执行前置检查

- [x] `npx tsc --noEmit` 通过
- [x] Prisma migrate/dev push 已执行（ServiceAccount 表存在）
- [x] 种子脚本已运行（API Key 已生成：`svc_daee6d48-...`）
- [ ] Farm-Server token 已配置（`FarmServerCredential(userId=0, source="service")`）

---

## 6. 执行步骤摘要

```
Task 1 ── ServiceAccount 模型 + migrate
            │
            ▼
Task 2 ── service-auth-resolver + h5-auth-gateway 双模式
            │
            ├──────────────┬──────────────┐
            ▼              ▼              ▼
Task 3 ── 路径迁移     Task 4 ── generate  Task 5 ── agent 改造
  (3端点→production-plan)  (假数据)        (去 handshake)
            │              │              │
            └──────┬───────┴──────┬───────┘
                   ▼              ▼
            Task 6 ── 废弃 handshake
                   │
                   ▼
            Task 7 ── tsc --noEmit ✅
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| Farm-Server token 未配置 | 3 个业务端点调 Farm-Server 失败 | 实施前确认 `ensureValidToken(0, "service")` 可用 |
| 旧路径 404 无重定向 | 缓存/书签指向旧路径的用户看到 404 | 无兼容负担（小程序后台从未对接旧路径） |
| API Key 泄露 | 第三方可调用生产计划 API | 脚本输出后立即销毁明文，定期轮换 |

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

### 总体一键恢复

```text
query_audit_logs({ keyword: "H5 API v2" })
```
→ 预期返回 8+ 条记录（Plan + Spec + 代码改动）

```text
query_audit_logs({ keyword: "sse-stream-graceful-shutdown" })
```
→ Runtime 纠正 §7+§8 全量恢复：SSE 优雅结束 + H5 interrupt 暂停修复（约 12 条，含 4 代码 + 8 文档）

```text
query_audit_logs({ keyword: "h5-agent-route-code-quality" })
```
→ §9 子 Plan 全量恢复：审计函数替换 + SSE 流状态机（8 条，含 3 代码 + 4 文档）

### 逐任务查询

```text
query_audit_logs({ targetId: "prisma/schema.prisma" })
→ 预期返回 COMPONENT_CREATED: ServiceAccount 模型

query_audit_logs({ targetId: "src/caijuehub/strategies/service-auth-resolver.ts" })
→ 预期返回 COMPONENT_CREATED: 策略模式

query_audit_logs({ targetId: "src/caijuehub/strategies/h5-auth-gateway.ts" })
→ 预期返回 COMPONENT_UPDATED: 双模式裁决

query_audit_logs({ targetId: "src/app/api/h5/production-plan/generate/route.ts" })
→ 预期返回 COMPONENT_CREATED: 计划生成端点

query_audit_logs({ targetId: "src/app/api/h5/agent/route.ts" })
→ 预期返回 3 条 MODIFY: streamClosed 防护（§7）+ interrupt break 修复（§8）+ console→agentAudit + 状态机（§9）

query_audit_logs({ targetId: "src/agents/sse-stream-state.ts" })
→ 预期返回 2 条: CREATE（初始）+ MODIFY（enum 迁移）

query_audit_logs({ targetId: "src/app/api/h5/handshake/route.ts" })
→ 预期返回 COMPONENT_DELETED: 废弃握手
```

### 恢复判定标准

- action 命中数 ≥ 8
- `npx tsc --noEmit` 零错误

---

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过
- [x] 所有文件改动已记录 ADD-7 审计（`query_audit_logs` 可回查）
- [x] API 对接文档 v4.2 已更新（计划状态化 + 完成取消 + 图片上传 + 自动完成）
- [x] Plan Review 已生成并回流至 Plan
- [x] Specs 三元组就绪（spec.md + tasks.md + checklist.md）
- [x] add-route v2 就绪（原子闭包 1 轮判定）
- [x] nongqing 6 端点 + generate 冲突检查 + 计划完成/取消 全部 curl 验证通过 (2026-06-24)
- [x] 图片上传端点 curl 验证通过 (2026-06-24)
- [x] 定时任务 auto-complete-plans.ts 验证通过 (2026-06-24)

---

## 10. Runtime 纠正 §7 — SSE Stream Bus 优雅结束（2026-06-26）

> 父 Plan §7 的交接内容。完整方案由 [`streaming-event-bus-plan-v1.md` §6](../../2026-05/18/streaming-event-bus-plan-v1.md) 主责。

### 10.1 本 Plan 涉及的关联变更

| 文件 | 改动 |
|------|------|
| `src/app/api/h5/agent/route.ts` | 回调增加 `streamClosed` + try/catch 防护 |

其余变更（`stream-bus.ts` / `chat/stream/route.ts` / `agent/[hash]/route.ts`）归属 `streaming-event-bus-plan-v1.md`。

### 10.2 部署

```bash
pm2 restart farm-agent
# 观察日志 5 分钟确认无 STREAM_BUS_EMIT_ERROR
tail -f ~/farm-agent/logs/pm2-out.log | grep STREAM_BUS_EMIT_ERROR
```
