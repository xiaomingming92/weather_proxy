# farm-agent-crop-plan-model-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对。

## PLAN 元信息

- **Plan 名称**: farm-agent-crop-plan-model-v1
- **启动时间**: 2026-06-22
- **主导 AI**: Qoder
- **关联文档**:
  - 父 Plan: `.qoder/plans/farm-agent-nongqing-report-api-plan-v1.md`（农情 API 阶段1已交付）
  - 作物周期权威来源: 扬州农技所
  - 需求文档: `docs/.../农场管理软件小程序端 需求文档v2.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| prisma/schema/ (重构) → main.prisma + nongqing.prisma | SCHEMA | SCHEMA_REFACTORED | 单文件 374行 | 拆分：main.prisma（原模型）+ nongqing.prisma（ProductionPlan/GrowthStage/FarmTask 三表） | ✅ 已实施 |
| src/data/crop-growth-templates.ts | DATA | DATA_CREATED | 不存在 | 小麦9阶段 + 水稻8阶段 + 完整tasks模板 | ✅ 已实施 |
| src/app/api/h5/production-plan/generate/route.ts | COMPONENT | COMPONENT_UPDATED | 返回假数据不落库 | 生成plan后写入DB三表 + AlertPrescription种子注入 | ✅ 已实施 |
| src/app/api/h5/nongqing/overview/route.ts | COMPONENT | COMPONENT_UPDATED | 硬编码growthStages | 从DB查询plan→读growthStages | ✅ 已实施 |
| src/app/api/h5/nongqing/daily-report/route.ts | COMPONENT | COMPONENT_UPDATED | 硬编码crop/growthStage | 从DB查询plan→读当前生育期 | ✅ 已实施 |

---

## 十、预警处方模型（增量决议 2026-06-22）

> **触发**：小程序后端反馈预警处方缺少截止时间、作业范围、触发原因（demo: `/wrnc/06/alert-prescription/p1`）。

### 10.1 不合表论证

| 维度 | 生育期任务 FarmTask | 预警处方 AlertPrescription |
|------|:--|:--|
| 触发机制 | 预计划（作物模板） | 事件驱动（传感器/巡检异常） |
| 创建时机 | generate 计划时一次性创建 | 巡检发现异常时 runtime 创建 |
| 特有字段 | FK→GrowthStage | triggerReason/triggerType/prescriptionSource/inspectorName/inspectorRole/inspectionFindings |
| 生命周期 | 跟随种植计划 | 独立于种植计划 |
| 关联关系 | GrowthStage → ProductionPlan | 巡检报告记录 |

若合表，FarmTask 将出现 6+ 个 null 字段（triggerReason/prescriptionSource/inspector 等），违反第三范式。

### 10.2 独立 AlertPrescription 模型

```prisma
model AlertPrescription {
  id                Int      @id @default(autoincrement())
  projectId         Int
  name              String                   // "蚜虫预警防治"
  description       String?
  scope             String?                  // 作业范围
  deadline          String?                  // 截止时间
  steps             Json?                    // 执行步骤
  status            String   @default("pending")
  completedAt       DateTime?
  // 预警专属字段
  triggerReason     String?                  // 触发原因
  triggerType       String?                  // pest | weather | soil
  prescriptionSource String?                // "日常巡检报告"
  sourceReportDate  String?
  inspectorName     String?
  inspectorRole     String?
  inspectionFindings Json?                   // 巡检发现明细
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  @@index([projectId])
  @@index([triggerType])
}
```

### 10.3 FarmTask vs AlertPrescription 对照

```
FarmTask                           AlertPrescription
├── name ✓                         ├── name ✓
├── description ✓                  ├── description ✓
├── scope ✓                        ├── scope ✓
├── deadline ✓                     ├── deadline ✓
├── steps ✓                        ├── steps ✓
├── status ✓                       ├── status ✓
├── growthStageId (FK→生育期)       ├── projectId
│                                  ├── triggerReason ★ 独有
│                                  ├── triggerType ★ 独有
│                                  ├── prescriptionSource ★ 独有
│                                  ├── sourceReportDate ★ 独有
│                                  ├── inspectorName ★ 独有
│                                  ├── inspectorRole ★ 独有
│                                  └── inspectionFindings ★ 独有
```

### 10.4 状态：已实施 ✅

`AlertPrescription` 表已创建，`triggerReason` 改为必填 `String`，`npx tsc --noEmit` 零错误。

### 10.5 completion 字段建模决策（增量决议 2026-06-22）

> **触发**：`completion Json` 是否行业标准做法？

**决策**：保持 `completion Json`。理由：
- 1:1 关系，不独立查询
- `photos[]` 数组在 JSON 中更自然
- 后续若需"统计本月某人完成处方数"再拆独立表（迁移成本低：5 字段 + FK）

---

## 一、背景与问题

### 1.1 当前缺陷

1. **生育周期硬编码且不同**：`generate/route.ts` 只硬编码了水稻7阶段，换小麦要改代码
2. **没有落库**：generate 返回数据不持久化，overview 和 daily-report 无从查询生长阶段（**已修复**）
3. **作物间不可切换**：小麦 9 阶段 vs 水稻 8 阶段，没有作物→周期映射表
4. **overview 自己算 stages**：`computeGrowthProgress()` 用硬编码的 `DEMO_PLAN` + 硬编码 `stages` 数组，与 generate 的输出完全独立

### 1.2 权威作物周期定义（扬州农技所）

| 作物 | 生育阶段（按时间顺序） | 阶段数 |
|------|------|:--:|
| **小麦** | 出苗期 → 分蘖期 → 越冬期 → 返青期 → 拔节孕穗期 → 开花期 → 抽穗期 → 乳熟期 → 成熟期 | 9 |
| **水稻** | 育秧期 → 移栽返青期 → 分蘖期 → 拔节期 → 孕穗期 → 开花期 → 灌浆结实期 → 成熟期 | 8 |

---

## 二、方案选型

已在前期确定为方案 B（双表规范化），不再重新选型。

### 数据流

```
generate/route (POST)                     overview/route (POST)
  │                                          │
  │ 1. 根据 cropType 查模板                     │ 3. 根据 projectId 查最新 ProductionPlan
  │    cropGrowthTemplates["水稻"] ──→ 8阶段    │    ──→ include growthStages
  │ 2. 构建 PlanGenerateData               │
  │ 3. upsert ProductionPlan │ 4. createMany GrowthStage              ──→ 6. 组装 OverviewData
```

**关键设计**：
- `ProductionPlan` 的 `cropType` 决定用哪个作物周期模板
- `GrowthStage` 通过 `planId` 外键关联，按 `stageOrder` 排序
- 每次 generate 对同一 `(projectId, planName)` 做 upsert（幂等，允许重新生成覆盖旧计划）
- nongqing 端点查询时取该 project 下最新的 plan

---

## 三、Prisma Schema 设计

### 3.1 ProductionPlan

```prisma
model ProductionPlan {
  id            Int      @id @default(autoincrement())
  projectId     Int      // 项目ID（与 Project 表关联，非外键约束）
  planName      String
  cropType      String                     // "水稻" | "小麦"
  varietyName   String
  targetYield   Float
  sowingDate    String                     // "5月15日"（当前阶段用字符串，后续可改 Date）
  maturityDate  String
  coreMetrics   Json?                      // {estimatedYield, estimatedProfit, growthDays, plantingScale}
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  growthStages  GrowthStage[]
  @@index([projectId])
  @@unique([projectId, planName])          // 同一项目下计划名唯一，支持 upsert
}
```

### 3.2 GrowthStage

```prisma
model GrowthStage {
  id           Int    @id @default(autoincrement())
  planId       Int
  plan         ProductionPlan @relation(fields: [planId], references: [id], onDelete: Cascade)
  stageOrder   Int                          // 1=出苗期, 2=分蘖期, ...
  name         String                       // "出苗期"
  dateRange    String                       // "5月26日-6月5日"
  durationDays Int
  keyPoints    String                       // 技术要点
  
  farmTasks    FarmTask[]                   // 该阶段下的农事任务列表（一对多）
}
```
> **[增量决议 2026-06-22]**: `tasks: String[]` 字段废除，改为独立 `FarmTask` 模型（§八），支持完整任务详情（description/scope/deadline/steps/status）。

---

## 四、作物周期模板常量表

文件: `src/data/crop-growth-templates.ts`

```typescript
// 权威来源：扬州农技所，2026-06-22
type CropStageTemplate = Omit<GrowthStageCreateInput, 'planId'>;

const RICE_STAGES: CropStageTemplate[] = [
  { stageOrder: 1, name: "育秧期",   dateRange: "", durationDays: 25, tasks: [...], keyPoints: "..." },
  { stageOrder: 2, name: "移栽返青期", ... },
  // ... 8阶段
];

const WHEAT_STAGES: CropStageTemplate[] = [
  { stageOrder: 1, name: "出苗期",   ... },
  { stageOrder: 2, name: "分蘖期",   ... },
  { stageOrder: 3, name: "越冬期",   ... },
  { stageOrder: 4, name: "返青期",   ... },
  { stageOrder: 5, name: "拔节孕穗期", ... },
  { stageOrder: 6, name: "开花期",   ... },
  { stageOrder: 7, name: "抽穗期",   ... },
  { stageOrder: 8, name: "乳熟期",   ... },
  { stageOrder: 9, name: "成熟期",   ... },
];

export const CROP_GROWTH_TEMPLATES: Record<string, CropStageTemplate[]> = {
  "水稻": RICE_STAGES,
  "小麦": WHEAT_STAGES,
};
```

---

## 五、Route 改造要点

### 5.1 generate/route.ts

改动：在返回响应之前，额外执行 upsert 操作。

```typescript
// 现：直接 return NextResponse.json({ code: 200, data: planResponse, ... })
// 改为：

const plan = await prisma.productionPlan.upsert({
  where: { projectId_planName: { projectId, planName: planResponse.planName } },
  update: { varietyName, targetYield, ... },
  create: { projectId, planName: planResponse.planName, cropType, varietyName, ... },
});

// 删除旧 stages，重新插入（upsert 策略：先删后插）
await prisma.growthStage.deleteMany({ where: { planId: plan.id } });
await prisma.growthStage.createMany({
  data: planResponse.growthSchedule.map((s, i) => ({
    planId: plan.id,
    stageOrder: i + 1,
    name: s.name,
    dateRange: s.dateRange,
    durationDays: s.durationDays,
    tasks: s.tasks,
    keyPoints: s.keyPoints,
  })),
});

return NextResponse.json({ code: 200, data: { ...planResponse, planId: plan.id }, ... })
```

### 5.2 overview/route.ts

改动：从 DB 读取 plan，替换 `DEMO_PLAN` + 硬编码 stages。

```typescript
function computeOverviewData(projectId: number, _planId?: number): OverviewData {
  // ── 新逻辑：查DB ──
  const plan = await prisma.productionPlan.findFirst({
    where: { projectId },
    orderBy: { createdAt: "desc" },
    include: { growthStages: { orderBy: { stageOrder: "asc" } } },
  });

  const planContext: PlanContext = {
    projectId, farmName: "邗江无人农场", // 阶段3 从 Farm-Server 查
    planName: plan.planName,
    variety: plan.varietyName,
    targetYield: plan.targetYield,
    sowingDate: plan.sowingDate,
    maturityDate: plan.maturityDate,
    totalDays: plan.growthStages.reduce((sum, s) => sum + s.durationDays, 0),
  };

  // growthProgress 的 stages 从 DB 读取，不再硬编码
  const growthProgress = computeGrowthProgressFromDB(planContext, plan.growthStages);
  // ...
}
```

### 5.3 daily-report/route.ts

改动：从 DB 读取当前生育期信息。

```typescript
function computeDailyReportData(projectId: number, _planId?: number): DailyReportData {
  const plan = await prisma.productionPlan.findFirst({ ... });
  const currentStage = computeCurrentStageFromDB(plan); // 按日期匹配
  
  return {
    crop: plan.cropType,
    growthStage: currentStage.name,
    growthProgress: `${computePercentage(plan)}%`,
    // ...
  };
}
```

---

## 六、实施步骤 + 依赖图

```
Task 1: Prisma Schema 双表模型      ──┐
Task 2: 作物周期模板常量表(crop-growth-templates.ts) ──┤ 可并行
                                        │
                                        ▼
Task 3: generate/route 改造（落库 + upsert）
Task 4: overview/route 改造（从DB读growthStages）
Task 5: daily-report/route 改造（从DB读crop/growthStage）
                                        │
                                        ▼
Task 6: npx prisma migrate dev + tsc --noEmit
Task 7: curl 验证全链路（generate→overview→daily-report）
```

### 验证标准

- [ ] `npx prisma migrate dev` 成功建表
- [ ] `npx tsc --noEmit` 零错误
- [ ] generate 接口调后 `SELECT * FROM "ProductionPlan"` 有数据
- [ ] generate 接口调后 `SELECT * FROM "GrowthStage"` 有 8 条（水稻）或 9 条（小麦）
- [ ] overview 接口返回的 `growthProgress.stages` 与 DB 一致
- [ ] daily-report 接口返回的 `crop`/`growthStage` 与 DB 一致
- [ ] 再次调 generate（同 projectId+planName）→ upsert 成功，旧 stages 被替换

---

## 七、关联文档

| 文档 | 路径 |
|------|------|
| 本 Plan | `.qoder/plans/farm-agent-crop-plan-model-plan-v1.md` |
| 父 Plan | `.qoder/plans/farm-agent-nongqing-report-api-plan-v1.md` |
| 需求 v2 | `docs/.../农场管理软件小程序端 需求文档v2.md` |
| H5 API 对接文档 v3 | `docs/.../瑞丰耘H5小程序API对接文档.md` |
| 作物周期权威来源 | 扬州农技所（2026-06-22 查询） |

---

## 八、任务与处方联动（增量更新 2026-06-22）

> **决议来源**：分析 demo `/wrnc/06/prescriptions` 页面 → 点击"灌浆期叶面追肥"详情页 → 发现当前 `tasks: string[]` 不足以支撑完整UI。

### 8.1 Demo 详情页数据结构

点击 prescriptions 页面的任务卡片进入详情页，展示：

```typescript
// Demo 详情页实际展示的数据结构
interface TaskDetail {
  name: string                      // "灌浆期叶面追肥"
  growthStage: string               // 所属生育期 "灌浆期"
  scope: string                     // 作业范围 "北区地块"
  deadline: string                  // 建议完成时间 "2026-05-15前"
  description: string               // 任务描述
  steps: Array<{
    order: number
    content: string                 // "配置 0.2% 磷酸二氢钾 + 1% 尿素混合溶液"
  }>
  status: "pending" | "completed"   // 完成状态
}
```

当前 `GrowthStage.tasks = string[]` 只存了名称，缺失 **description/scope/deadline/steps/status** 5个字段。

### 8.2 三层数据关系

```
ProductionPlan (1)
  └── GrowthStage (N)        ← 当前 Plan 已设计
        └── FarmTask (M)      ← 本次增量新增
```

| 层 | 模型 | 说明 |
|------|------|------|
| L1 | `ProductionPlan` | 一个种植计划 |
| L2 | `GrowthStage` | 一个生育期，有 startDateRange/durationDays/keyPoints |
| L3 | `FarmTask` | 一个农事任务，有 name/description/scope/deadline/steps[]/status |

`generate/route.ts` 当前输出 `growthSchedule[].tasks[]` 只有名称。改造后：
- L2 `GrowthStage` 不再存 `tasks: String[]`
- L3 `FarmTask` 通过 `growthStageId` 外键关联，承载完整任务详情

### 8.3 FarmTask Prisma 模型

```prisma
model FarmTask {
  id             Int      @id @default(autoincrement())
  growthStageId  Int
  growthStage    GrowthStage @relation(fields: [growthStageId], references: [id], onDelete: Cascade)
  name           String                     // "灌浆期叶面追肥"
  description    String?                    // 任务描述
  scope          String?                    // 作业范围 "北区地块"
  deadline       String?                    // "2026-05-15前"
  steps          Json?                      // [{order:1, content:"配置溶液"}, ...]
  status         String   @default("pending")  // pending | completed
  completedAt    DateTime?
  createdAt      DateTime @default(now())
  updatedAt      DateTime @updatedAt
}
```

### 8.4 作物周期模板扩展

`src/data/crop-growth-templates.ts` 中每个阶段的 tasks 也需要扩展为完整模板：

```typescript
// 阶段1: tasks 仍为 string[]（generate 兼容）
// 阶段2: tasks 扩展为 FarmTaskCreateInput[]
interface CropStageTemplate {
  stageOrder: number
  name: string
  dateRange: string
  durationDays: number
  tasks: StageTaskTemplate[]       // ← 从 string[] 升级
  keyPoints: string
}

interface StageTaskTemplate {
  name: string
  description: string
  scope?: string
  deadline?: string
  steps: Array<{ order: number; content: string }>
}

// 示例：小麦灌浆期任务模板
const WHEAT_STAGES: CropStageTemplate[] = [
  // ...
  {
    stageOrder: 8, name: "灌浆期", dateRange: "", durationDays: 25,
    tasks: [{
      name: "灌浆期叶面追肥",
      description: "叶面喷施磷酸二氢钾和尿素混合液，提高千粒重、预防干热风。",
      scope: "全区",
      steps: [
        { order: 1, content: "配置 0.2% 磷酸二氢钾 + 1% 尿素混合溶液" },
        { order: 2, content: "选择晴天上午 9 点前或下午 5 点后喷施" },
        { order: 3, content: "采用植保无人机均匀喷施叶面" },
        { order: 4, content: "间隔 7 天可补喷一次" },
      ],
    }],
    keyPoints: "间歇灌溉，养根保叶，防止倒伏和早衰",
  },
];
```

### 8.5 generate/route 改造影响

```diff
- growthSchedule 中 tasks: string[]
+ growthSchedule 中 tasks: StageTaskTemplate[]

- 落库: GrowthStage.tasks = []   (旧字段废弃)
+ 落库: FarmTask.createMany({ data: stage.tasks.map(t => ({...t, growthStageId: stage.id})) })
```

### 8.6 prescriptions API 预留 → **已交付**

✅ 阶段2 4 个端点已提前交付：
- `GET /api/h5/nongqing/tasks?projectId=&planId=` — 按生育期分组返回任务列表
- `GET /api/h5/nongqing/tasks/:id` — 任务详情（含 steps + 生育期信息）
- `GET /api/h5/nongqing/prescriptions?projectId=&triggerType=` — 预警处方列表 + 按类型统计
- `GET /api/h5/nongqing/prescriptions/:id` — 预警处方详情
- `PUT /api/h5/nongqing/tasks/:id/complete` — 标记任务完成（待实施）

**generate 联动**：generate 时若项目无预警处方数据，自动注入 4 条 demo 处方（蚜虫/白粉病/干热风/孕穗期补灌），与 demo `/wrnc/06/alert-prescription/p1` 对齐。

### 8.7 LLM 场景的任务查询优化（增量决议 2026-06-22）

> **触发场景**："基于当前农场状态，制定最优作业计划" → LLM 需要一次性拿到当前生育期 + 全部任务 + 相邻阶段上下文。

**一次查询返回完整任务树**：

```typescript
// 一条 Prisma 查询拿到 plan + 所有 stages + 所有 tasks
const plan = await prisma.productionPlan.findFirst({
  where: { projectId },
  orderBy: { createdAt: "desc" },
  include: {
    growthStages: {
      orderBy: { stageOrder: "asc" },
      include: {
        farmTasks: { orderBy: { id: "asc" } }
      }
    }
  }
})

// 内存中定位当前生育期
const currentStage = findCurrentStage(
  plan.growthStages,
  computeDayNumber(plan.sowingDate)
)

// 组装 LLM prompt 上下文
const llmContext = {
  planName: plan.planName,
  cropType: plan.cropType,
  currentStage: {
    name: currentStage.name,
    progress: `${computePercentage(plan)}%`,
    tasks: currentStage.farmTasks,              // 当前阶段全部任务
  },
  nextStage: plan.growthStages[currentStage.stageOrder] ?? null,  // 下一阶段（前瞻建议）
  allStages: plan.growthStages.map(s => ({      // 全阶段摘要（供跨阶段规划）
    name: s.name, taskCount: s.farmTasks.length, isCurrent: s.id === currentStage.id,
  })),
}
```

**LLM prompt 组装**（`nongqing_tasks` 专家）：

```
你是一个农业作业计划专家。当前农场种植计划如下：

作物：${cropType} | 品种：${varietyName}
当前生育期：${currentStage.name}（进度 ${progress}%）

【当前阶段任务】
${currentStage.tasks.map(t => `- ${t.name}: ${t.description}`).join('\n')}

【下一阶段预览】
${nextStage.name}: ${nextStage.tasks.map(t => t.name).join('、')}

【全阶段概览】
${allStages.map(s => `${s.isCurrent ? '→ ' : '  '}${s.name} (${s.taskCount}项)`).join('\n')}

请基于以上信息，制定最优作业计划：
1. 优先完成当前阶段待办任务
2. 关注下一阶段需要的准备工作
3. 考虑气象/墒情/病虫情风险调整作业优先级
```

**性能优势**：1 次 DB 查询 → 6 表 JOIN（Plan + 9 stages × 2 tasks ≈ 20 行）→ 内存计算 currentStage → 组装 prompt。无需多次往返。

---

## 九、实施计划更新

### 阶段拆分

| 阶段 | 内容 | 本次 |
|------|------|:--:|
| **阶段1** | Prisma 三表模型 + 作物模板 + generate 落库 + overview/daily-report 读库 + AlertPrescription 种子数据注入 | **✅ 已交付** |
| **阶段2** | tasks/prescriptions 4 个读端点 + API 对接文档 v4.0 | **✅ 已交付** |
| **阶段3** | 小程序后端对接 prescriptions 页面 + PUT complete 端点 | 远期 |

### 更新的实施步骤

```
Task 1: Prisma Schema 拆分（预览功能 prismaSchemaFolder）   ──┐
Task 2: nongqing.prisma（三表模型）                           ──┤ 必须串行
Task 3: crop-growth-templates.ts (完整tasks模板)               ──┤ 可并行
Task 4: generate/route 改造（upsert Plan + replace stages + createMany tasks）  ──┤
Task 5: overview/route 改造（从 DB 读 plan → growthStages + farmTasks）         ──┤
Task 6: daily-report/route 改造（从 DB 读 crop/growthStage）                    ──┘
                                                    │
                                                    ▼
Task 7: npx prisma generate + tsc --noEmit
Task 8: curl 验证全链路（generate→overview→daily-report + DB 查询 tasks）
```

### Task 1: Prisma Schema 拆分

> **决议**：Prisma 6.19.0 支持 `prismaSchemaFolder` 预览功能，允许多文件 schema。在膨胀前趁早拆分。

**操作**：
1. 在 `prisma/schema.prisma` 的 `generator client` 块中启用预览功能：
   ```prisma
   generator client {
     provider        = "prisma-client-js"
     previewFeatures = ["prismaSchemaFolder"]
   }
   ```
2. 创建 `prisma/schema/` 目录
3. 将现有 `schema.prisma` 中的 model 拆分到 `prisma/schema/main.prisma`
4. 新建 `prisma/schema/nongqing.prisma`，放入 3 个新 model（`ProductionPlan` / `GrowthStage` / `FarmTask`）
5. `prisma/schema/main.prisma` 顶部保留 `datasource` 和 `generator`，底部用 `// 业务域模型见同目录其他 .prisma 文件` 注释
6. 更新所有脚本中的 schema 路径引用（`package.json` 的 `migrate`/`generate`/`push` 命令，如有 `--schema` 参数需改为 `--schema=prisma/schema`）

**验证**：`npx prisma generate` 不变，生成的 Prisma Client 包含所有模型。

### Task 2: nongqing.prisma（三表模型） + Task 3: crop-growth-templates.ts

与 §三、§四 设计一致，不再赘述。

### 文件结构变更

```
prisma/
├── migrations/        # 不变
├── schema.prisma      # → 变为入口文件（仅 datasource + generator + 说明注释）
└── schema/
    ├── main.prisma    # 现有所有 model（user/chat/rag/knowledge 等域）
    └── nongqing.prisma # 新增：ProductionPlan + GrowthStage + FarmTask
```

### 更新的 ADD-7 审计策略

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| prisma/schema/nongqing.prisma | SCHEMA | SCHEMA_CREATED | 不存在 | ProductionPlan + GrowthStage + FarmTask + AlertPrescription | ✅ 已实施 |
| prisma/schema/ (重构) | SCHEMA | SCHEMA_REFACTORED | 单文件 374 行 | 拆分：main.prisma（原模型）+ nongqing.prisma（4新模型） | ✅ 已实施 |
| src/data/crop-growth-templates.ts | DATA | DATA_CREATED | 不存在 | 小麦9阶段 + 水稻8阶段 + 完整tasks模板 | ✅ 已实施 |
| src/app/api/h5/production-plan/generate/route.ts | COMPONENT | COMPONENT_UPDATED | 返回假数据不落库 | 生成plan后写入DB三表 + AlertPrescription种子注入 | ✅ 已实施 |
| src/app/api/h5/nongqing/overview/route.ts | COMPONENT | COMPONENT_UPDATED | 硬编码growthStages | 从DB查询plan→include growthStages | ✅ 已实施 |
| src/app/api/h5/nongqing/daily-report/route.ts | COMPONENT | COMPONENT_UPDATED | 硬编码crop/growthStage | 从DB查询plan→读当前生育期 | ✅ 已实施 |
| src/app/api/h5/nongqing/tasks/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 生育期任务列表（按阶段分组） | ✅ 已实施 |
| src/app/api/h5/nongqing/tasks/[id]/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 生育期任务详情 | ✅ 已实施 |
| src/app/api/h5/nongqing/prescriptions/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 预警处方列表 + 按类型统计 | ✅ 已实施 |
| src/app/api/h5/nongqing/prescriptions/[id]/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 预警处方详情 | ✅ 已实施 |
| docs/.../瑞丰耘H5小程序API对接文档.md | DOC | DOC_UPDATED | v3.0 (7端点) | v4.0 (11端点) | ✅ 已实施 |