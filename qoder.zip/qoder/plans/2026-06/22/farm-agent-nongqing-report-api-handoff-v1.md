# farm-agent — 农情报告 API（总体态势概览 + 日常巡检报告 + 任务/处方 + generate 地块绑定）交接手册

> **适用场景**：多轮变更，新增 6 个 H5 REST API 端点 + 1 个 generate 端点增强。
> **最新修订**: 2026-06-24 — 新增计划状态化 + 到期自动释放地块

---

## 1. 交接前状态

- H5 API 仅有 `production-plan/*` 域（地块分析/品种推荐/成本核算/计划生成）+ agent 聊天端点
- IoT 物联感知页面的"农情态势概览"和"日常巡检报告"数据硬编码在前端 demo 中
- 无 `nongqing` 业务域 API
- generate 端点无地块绑定校验，同一地块可被多个计划引用

---

## 2. 交接后状态（目标）

- 新增 `POST /api/h5/nongqing/overview` — 返回总体态势概览完整 JSON（planHeader + growthProgress + productionEvaluation + keyFindings + trendAnalysis + riskReview）
- 新增 `POST /api/h5/nongqing/daily-report` — 返回日常巡检报告 JSON（normal/warning 双状态模板）
- 新增 `GET /api/h5/nongqing/tasks` — 生育期任务列表（按阶段分组）
- 新增 `GET / PATCH /api/h5/nongqing/tasks/{id}` — 生育期任务详情 + 标记/取消完成（快速标记 / 表单填报）
- 新增 `GET /api/h5/nongqing/prescriptions` — 预警处方列表 + 按类型统计
- 新增 `GET / PATCH /api/h5/nongqing/prescriptions/{id}` — 预警处方详情 + 填报/取消完成
- 增强 `POST /api/h5/production-plan/generate` — 地块绑定原子冲突检查 + massifIds 落库（2026-06-24），仅检查 active 计划
- 新增 `PATCH /api/h5/production-plan/plans/{id}` — 标记计划完成 + 自动完成所有 pending 任务 + 释放地块
- 新增 `scripts/auto-complete-plans.ts` — 定时任务（crontab 02:30）：自动完成到期计划
- DTO 类型集中在 `types/dto.ts` + `types/schemas.ts`
- 审计阶段 `H5_NONGQING_OVERVIEW` + `H5_NONGQING_DAILY_REPORT` + `H5_NONGQING_TASKS` + `H5_NONGQING_PRESCRIPTIONS` 已注册

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `prisma/nongqing.prisma` | 修改 | ProductionPlan 新增 `massifIds Json?` + 新增 GrowthStage / FarmTask / AlertPrescription 三表 |
| 2 | `src/lib/agent-audit-logger.ts` | 修改 | AgentAuditPhase 新增 `H5_NONGQING_OVERVIEW` + `H5_NONGQING_DAILY_REPORT` + `H5_NONGQING_TASKS` + `H5_NONGQING_PRESCRIPTIONS` |
| 3 | `src/app/api/h5/types/dto.ts` | 修改 | 新增 nongqing 域 DTO（OverviewData/DailyReportData 及相关嵌套类型） |
| 4 | `src/app/api/h5/types/schemas.ts` | 修改 | 新增 overviewSchema + dailyReportSchema Zod 校验 |
| 5 | `src/app/api/h5/nongqing/overview/route.ts` | 新建 | 总体态势概览 POST 端点（认证+审计+Zod） |
| 6 | `src/app/api/h5/nongqing/daily-report/route.ts` | 新建 | 日常巡检报告 POST 端点（认证+审计+Zod+预警处方联动） |
| 7 | `src/app/api/h5/nongqing/tasks/route.ts` | 新建 | 生育期任务列表 GET 端点 |
| 8 | `src/app/api/h5/nongqing/tasks/[id]/route.ts` | 修改 | 生育期任务详情 GET + **PATCH 标记/取消完成**（快速标记 / 表单填报） |
| 9 | `src/app/api/h5/nongqing/prescriptions/route.ts` | 新建 | 预警处方列表 GET 端点 |
| 10 | `src/app/api/h5/nongqing/prescriptions/[id]/route.ts` | 修改 | 预警处方详情 GET + **PATCH 填报/取消完成** |
| 11 | `src/app/api/h5/production-plan/generate/route.ts` | **修改** | **新增地块绑定原子冲突检查 + massifIds 落库**（2026-06-24），仅检查 active 计划 |
| 12 | `src/app/api/h5/production-plan/plans/[id]/route.ts` | **新建** | **PATCH 标记计划完成 + 联动自动完成 pending 任务**（2026-06-24） |
| 13 | `scripts/auto-complete-plans.ts` | **新建** | **定时任务：每天 02:30 扫描到期计划自动标记 completed**（2026-06-24） |
| 12 | `src/data/crop-growth-templates.ts` | 新建 | 作物生育期模板数据（水稻8阶段/小麦9阶段） |

---

## 4. 回滚方案

### 代码回滚

```bash
git checkout -- src/lib/agent-audit-logger.ts src/app/api/h5/types/dto.ts src/app/api/h5/types/schemas.ts
rm -rf src/app/api/h5/nongqing/
```

### 数据回滚

无数据库变更，无需回滚。

---

## 5. 执行前置检查

- [x] `npx tsc --noEmit` 零错误
- [x] H5 认证基础设施可用（h5-auth-gateway + ServiceAccount 表）
- [ ] 服务端运行中（`npm run dev` 或生产部署）
- [ ] 有效 X-Api-Key 可用（查询 ServiceAccount 表或种子脚本生成）

---

## 6. 执行步骤摘要

```text
Step 1 ── 扩展 AgentAuditPhase（新增 2 个阶段字面量）
            │
            ▼
Step 2 ── 追加 DTO 类型（OverviewData + DailyReportData）
            ├──────────────────────────────┐
            ▼                              ▼
Step 3 ── 追加 Zod Schema              Step 4 ── 创建 2 个 API 路由文件
            │                              │
            └──────────────┬───────────────┘
                           ▼
Step 5 ── tsc --noEmit + RAHS 验证
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| 假数据与实际业务不符 | 明天对接时前端渲染异常 | Demo 数据来自 80retros.com 及需求文档，结构完全对齐 |
| 认证不通过 | 端点返回 401 | 确认 ServiceAccount 表已有有效记录，或运行管理脚本创建 |
| Zod 校验失败 | 返回降级原始数据 | 软校验策略：safeParse 失败不阻断，仅记录 audit |
| 阶段2 LLM 接入时 DTO 需扩展 | 类型不兼容 | DTO 已预留阶段2/3 扩展空间，新增字段用 optional |

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用。共 6 条审计记录可恢复完整开发上下文。

### 总体一键恢复

```text
query_audit_logs({ keyword: "nongqing" })
```
→ 预期返回 3+ 条记录（DOC_CREATED + 2x COMPONENT_CREATED），其余文件以 targetId 查

### 逐文件审计查询

```text
query_audit_logs({ targetId: "agent-audit-logger.ts" })
→ 预期返回 COMPONENT_UPDATED: 新增 H5_NONGQING_OVERVIEW + H5_NONGQING_DAILY_REPORT

query_audit_logs({ targetId: "types/dto.ts" })
→ 预期返回 COMPONENT_UPDATED: 新增 OverviewData + DailyReportData

query_audit_logs({ targetId: "types/schemas.ts" })
→ 预期返回 COMPONENT_UPDATED: 新增 overviewSchema + dailyReportSchema

query_audit_logs({ targetId: "nongqing/overview/route.ts" })
→ 预期返回 COMPONENT_CREATED: 总体态势概览端点

query_audit_logs({ targetId: "nongqing/daily-report/route.ts" })
→ 预期返回 COMPONENT_CREATED: 日常巡检报告端点
```

### 恢复判定标准

- action 命中数 ≥ 8
- grep 验证命令：

```bash
grep -R "H5_NONGQING_OVERVIEW\|H5_NONGQING_DAILY_REPORT\|H5_NONGQING_TASKS\|H5_NONGQING_PRESCRIPTIONS" src/
grep -R "OverviewData\|DailyReportData" src/app/api/h5/types/
grep -c "massifIds" prisma/nongqing.prisma
```

---

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过
- [x] 所有文件改动已记录 ADD-7 审计（`query_audit_logs` 可回查，共 8+ 条）
- [x] RAHS = 100（范围保真度/类型安全/审计完整度/Spec合规/阶段对称性 全通过）
- [x] 6 个 nongqing 端点全部 200（overview + daily-report + tasks + tasks/{id} + prescriptions + prescriptions/{id}）
- [x] generate 端点地块绑定原子冲突检查通过（4/4 测试场景）
- [x] 无 X-Api-Key 返回 401
- [x] projectId 缺失返回 400

---

## 10. 关联文档

| 文档 | 路径 |
|------|------|
| Plan | `.qoder/plans/farm-agent-nongqing-report-api-plan-v1.md` |
| add-route | `.qoder/plans/farm-agent-nongqing-report-add-route-v1.md` |
| Spec | `.qoder/specs/farm-agent-nongqing-report-api/spec.md` |
| Tasks | `.qoder/specs/farm-agent-nongqing-report-api/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-nongqing-report-api/checklist.md` |
| 需求文档 | `docs/大田精准耕播智能决策系统/knowledge/00-需求/农场管理软件小程序端 需求文档.md` |
| H5 API 对接文档 | `docs/大田精准耕播智能决策系统/knowledge/02-规范/瑞丰耘H5小程序API对接文档.md` |

---

### 脱敏要求

所有凭据值通过环境变量引用，值见 `.env.development` / `.env.production`。Handoff 中不含硬编码密码。
