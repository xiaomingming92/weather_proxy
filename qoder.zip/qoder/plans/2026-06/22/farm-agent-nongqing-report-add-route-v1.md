# farm-agent-nongqing-report-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **绑定**：Plan: `.qoder/plans/farm-agent-nongqing-report-api-plan-v1.md` · Spec: `.qoder/specs/farm-agent-nongqing-report-api/spec.md` · Tasks: `.qoder/specs/farm-agent-nongqing-report-api/tasks.md` · Handoff: `.qoder/plans/farm-agent-nongqing-report-api-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**状态**: ✅ 完成

**动作**：
1. 调用 `find_related_docs` — 未找到精确匹配的农情文档（新功能），已读取相关 H5 API 文档和需求文档
2. 需求文档 `docs/.../00-需求/农场管理软件小程序端 需求文档.md` 已读取并理解
3. 项目文档更新声明：本次新增 2 个 API 端点为全新功能，不修改现有接口合约，无需更新现有项目文档。H5 API 对接文档将在阶段2（LLM 智能分析）接入时同步更新
4. Specs 三元组已生成

**产出**：
- [x] Specs 三元组: `.qoder/specs/farm-agent-nongqing-report-api/{spec,tasks,checklist}.md`
- [x] 项目文档：无需更新（新功能，不影响现有合约）
- [x] Handoff: 待 Step 8 生成

### 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: 为小程序 IoT 物联感知页面提供农情报告后端 API（总体态势概览 + 日常巡检报告）
Task Groups: Phase 1 (审计+DTO) + Phase 2 (端点实现) + Phase 3 (编译验证)

逐组业务价值判定:
  Phase 1 (审计+DTO): 不能用 — 类型定义和审计阶段不是独立业务功能
  Phase 2 (端点实现): 不能用 — 没有 DTO 和审计阶段，端点无法编译
  Phase 3 (编译验证): 不能用 — 验证步骤不产生业务功能

判定结论: 需要 1 轮（1 个原子闭包）

第1轮（唯一原子闭包）: Phase 1 + Phase 2 + Phase 3 — 业务功能: 农情报告 API 双端点可用
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
  理由: 两个端点共同构成"农情报告"完整业务能力，缺少任一都不完整
```

---

## Step 1：功能分析与审计阶段定义

**状态**: ⬜ 待执行

**动作**：
1. 本次审计阶段: `H5_NONGQING_OVERVIEW`, `H5_NONGQING_DAILY_REPORT`
2. 在 `AgentAuditPhase` 联合类型中新增这 2 个字面量

**产出**：
- [ ] 审计阶段清单

| Phase | 使用场景 | Task |
|-------|---------|------|
| `H5_NONGQING_OVERVIEW` | overview 端点请求处理 | Task 2.1 |
| `H5_NONGQING_DAILY_REPORT` | daily-report 端点请求处理 | Task 2.2 |

---

## Step 2：审计基础设施确认

**状态**: ⬜ 待执行

**动作**：确认 `agentAudit()` 通道可用，新增字面量兼容

**产出**：
- [ ] agentAudit() 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**状态**: ⬜ 待执行

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1.1 | AgentAuditPhase 扩展 | `agent-audit-logger.ts` | 无（类型定义） | 2个Phase | 无 | ⬜ |
| 1.2 | DTO 类型追加 | `types/dto.ts` | 无（类型定义） | — | 无 | ⬜ |
| 1.3 | Zod Schema 追加 | `types/schemas.ts` | 无（类型定义） | — | 无 | ⬜ |
| 2.1 | overview 端点 | `nongqing/overview/route.ts` | `agentAudit("H5_NONGQING_OVERVIEW", ...)` | H5_NONGQING_OVERVIEW | 1.1+1.2+1.3 | ⬜ |
| 2.2 | daily-report 端点 | `nongqing/daily-report/route.ts` | `agentAudit("H5_NONGQING_DAILY_REPORT", ...)` | H5_NONGQING_DAILY_REPORT | 1.1+1.2+1.3 | ⬜ |
| 3.1 | 编译验证 | — | — | — | 2.1+2.2 | ⬜ |

### 依赖拓扑

```
Task 1.1 ─┐
Task 1.2 ─┤──→ Task 2.1 ─┐
Task 1.3 ─┘   Task 2.2 ─┤──→ Task 3.1
```

---

## Step 3.5：实现审查

**状态**: ⬜ 待执行

**动作**：
1. 执行 checklist 全部 [T] 项
2. 生成 review-implementation.md

---

## Step 4：审计数据验证

**状态**: ⬜ 待执行

**动作**：
1. `npx tsc --noEmit`
2. `check_phase_symmetry`
3. `check_failure_path`

---

## Step 5：AI 自动合规检查

**状态**: ⬜ 待执行

**动作**：
1. 对每个修改文件调用 `check_add_compliance`

---

## Step 6/7：条件执行（仅当 Step 4/5 发现异常）

---

## Step 8：收敛判断 + Handoff

**状态**: ⬜ 待执行

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/lib/agent-audit-logger.ts` | MODIFY | 1.1 | COMPONENT | ⬜ |
| `src/app/api/h5/types/dto.ts` | MODIFY | 1.2 | COMPONENT | ⬜ |
| `src/app/api/h5/types/schemas.ts` | MODIFY | 1.3 | COMPONENT | ⬜ |
| `src/app/api/h5/nongqing/overview/route.ts` | CREATE | 2.1 | COMPONENT | ⬜ |
| `src/app/api/h5/nongqing/daily-report/route.ts` | CREATE | 2.2 | COMPONENT | ⬜ |

## ADD-7 审计策略

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/app/api/h5/types/dto.ts | COMPONENT | COMPONENT_UPDATED | 仅 production-plan + agent 类型 | 新增 nongqing 域 DTO（OverviewData + DailyReportData） | 待实施 |
| src/app/api/h5/types/schemas.ts | COMPONENT | COMPONENT_UPDATED | 仅 production-plan Zod schema | 新增 overviewSchema + dailyReportSchema | 待实施 |
| src/app/api/h5/nongqing/overview/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 总体态势概览端点（阶段1：demo 假数据） | 待实施 |
| src/app/api/h5/nongqing/daily-report/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 日常巡检报告端点（阶段1：demo 假数据） | 待实施 |
| src/lib/agent-audit-logger.ts | COMPONENT | COMPONENT_UPDATED | AgentAuditPhase 不含农情阶段 | 新增 H5_NONGQING_OVERVIEW + H5_NONGQING_DAILY_REPORT | 待实施 |
