# farm-agent-ruifengyun-h5-api-add-route-v2

> **定位**：Plan → ADD 九阶段执行映射。绑定：Plan `farm-agent-ruifengyun-h5-api-plan-v2.md` · Spec `farm-agent-ruifengyun-h5-api-v2/spec.md` · Tasks `farm-agent-ruifengyun-h5-api-v2/tasks.md`

---

## 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: 小程序后台通过服务账户对接 farm-agent 生产计划 API + 补全计划生成端点

Task Groups:
  Phase 1 基础设施: Task 1(ServiceAccount) + Task 2(auth-gateway)
  Phase 2 端点: Task 3(路径迁移) + Task 4(generate) + Task 5(agent改造) + Task 6(废弃handshake)
  Phase 3 验证: Task 7(curl验证)

逐组业务价值判定:
  Phase 1+2 合并: 能用 — 只交付基础设施和端点，小程序后台即可对接调用完整链路
  Phase 3 单独: 不能用 — 纯验证阶段，无独立业务价值

判定结论: 需要 1 轮（1 个原子闭包）

第1轮（原子闭包1）: Task 1-7 — 业务功能: 服务账户认证 + 生产计划 API 完整可用
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## Step 0：文档先行

**状态**: ✅ 已完成

- [x] Plan v2 已生成
- [x] Specs 三元组已就绪
- [x] API 对接文档 v2.0 已更新
- [x] 原子闭包判定 1 轮

---

## Step 1：功能分析与审计阶段定义

**状态**: ⬜ 待执行

| Phase | 使用场景 | Task |
|-------|---------|------|
| `SERVICE_AUTH` | API Key 认证校验 | Task 2 |
| `H5_PLAN_GENERATE` | 计划生成端点 | Task 4 |

---

## Step 2：审计基础设施确认

**状态**: ⬜ 待执行

- [ ] 确认 `agentAudit("SERVICE_AUTH", ...)` 可用
- [ ] 确认 `agentAudit("H5_PLAN_GENERATE", ...)` 可用

---

## Step 3：业务逻辑实现与审计植入

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | ServiceAccount 模型 | `prisma/schema.prisma` | 无（结构变更） | — | 无 | ⬜ |
| 2 | auth-gateway 双模式 | `src/caijuehub/strategies/h5-auth-gateway.ts` | `agentAudit("SERVICE_AUTH", ...)` | SERVICE_AUTH | Task 1 | ⬜ |
| 3 | 路径迁移 | `src/app/api/h5/production-plan/*/route.ts` | 复用现有 H5_LAND_ANALYSIS 等 | — | Task 2 | ⬜ |
| 4 | generate 端点 | `production-plan/generate/route.ts` | `agentAudit("H5_PLAN_GENERATE", ...)` | H5_PLAN_GENERATE | Task 2 | ⬜ |
| 5 | agent 改造 | `src/app/api/h5/agent/route.ts` | 复用现有 | — | Task 2 | ⬜ |
| 6 | 废弃 handshake | 删除 `handshake/route.ts` | 无 | — | 无 | ⬜ |
| 7 | 编译+curl | — | 无（验证阶段） | — | Task 1-6 | ⬜ |

### 依赖拓扑

```
Task 1 ──→ Task 2 ──→ Task 3 ──┐
                    ├─→ Task 4 ──┤
                    ├─→ Task 5 ──┼──→ Task 7
                    └─→ Task 6 ──┘
```

---

## Step 4-8：待执行

（代码实现完成后依次执行）

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType |
|------|------|------|-----------|
| `prisma/schema.prisma` | MODIFY | 1 | COMPONENT |
| `src/caijuehub/strategies/h5-auth-gateway.ts` | MODIFY | 2 | COMPONENT |
| `src/lib/agent-audit-logger.ts` | MODIFY | 2+4 | COMPONENT |
| `src/app/api/h5/production-plan/land-analysis/route.ts` | MOVE+MODIFY | 3 | COMPONENT |
| `src/app/api/h5/production-plan/variety-recommend/route.ts` | MOVE+MODIFY | 3 | COMPONENT |
| `src/app/api/h5/production-plan/cost-accounting/route.ts` | MOVE+MODIFY | 3 | COMPONENT |
| `src/app/api/h5/production-plan/generate/route.ts` | CREATE | 4 | COMPONENT |
| `src/app/api/h5/agent/route.ts` | MODIFY | 5 | COMPONENT |
| `src/app/api/h5/handshake/route.ts` | DELETE | 6 | COMPONENT |
