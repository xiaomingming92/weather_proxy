# farm-agent-nongqing-report-api-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。不写完整 TS 类型定义——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-nongqing-report-api-v1
- **启动时间**: 2026-06-22T00:00:00Z
- **修订时间**: 2026-06-22（v2 需求对齐：作物→水稻、补 yieldPrediction、衔接 grounding plan 架构）
- **主导 AI**: Qoder
- **修订记录**:
  - 2026-06-24: 新增 generate 端点地块绑定原子冲突检查（massifIds），关联 nongqing 域数据一致性
  - 2026-06-24: 新增任务/处方标记完成与取消端点（PATCH），支持快速标记和表单填报两种模式
  - 2026-06-24: 新增计划 status 字段（active/completed），generate 冲突检查仅拦 active 计划；定时任务自动释放到期地块
  - 2026-06-24: generate 同名校验：upsert 改为 findUnique 预检 + create，同名返回 400 拒绝
- **子 Plan**: `.qoder/plans/farm-agent-crop-plan-model-plan-v1.md`（基础设施改造：Prisma三表 + 作物周期模板 + route落库改造，本 Plan 阶段2/3 依赖其完成）
- **关联文档**:
  - 需求文档 v2: `docs/大田精准耕播智能决策系统/knowledge/02-规范/农场管理软件小程序端 需求文档v2.md`
  - H5 API v2 Plan: `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v2.md`（已实施，复用其认证+DTO模式）
  - Grounding Plan: `.qoder/plans/farm-agent-grounding-customization-plan-v3.md`（阶段2/3 的 Expert Registry + Discipline Resolver 底座）
  - Demo 参考: `https://80retros.com/wrnc/06/iot`（IoT 页面）、`https://80retros.com/wrnc/06/overall`（Overall 详情页）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/app/api/h5/types/dto.ts | COMPONENT | COMPONENT_UPDATED | 仅 production-plan + agent 类型 | 新增 nongqing 域 DTO（OverviewData + DailyReportData + yieldPrediction） | ✅ 已实施 |
| src/app/api/h5/types/schemas.ts | COMPONENT | COMPONENT_UPDATED | 仅 production-plan Zod schema | 新增 overviewSchema + dailyReportSchema + yieldPrediction | ✅ 已实施 |
| src/app/api/h5/nongqing/overview/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 总体态势概览端点（阶段1：水稻/出苗期 demo 假数据） | ✅ 已实施 |
| src/app/api/h5/nongqing/daily-report/route.ts | COMPONENT | COMPONENT_CREATED | 不存在 | 日常巡检报告端点（阶段1：水稻/出苗期 demo 假数据） | ✅ 已实施 |
| src/app/api/h5/production-plan/generate/route.ts | COMPONENT | COMPONENT_UPDATED | 无地块冲突检查 | 新增原子冲突检查 + 同名校验拒绝 + massifIds 落库 | ✅ 已实施（2026-06-24） |
| prisma/nongqing.prisma | SCHEMA | COMPONENT_UPDATED | ProductionPlan 无 massifIds 字段，FarmTask 无 completion 字段 | 新增 massifIds JSONB + FarmTask completion JSONB | ✅ 已实施（2026-06-24） |
| src/app/api/h5/nongqing/tasks/[id]/route.ts | COMPONENT | COMPONENT_UPDATED | 仅 GET 详情 | 新增 PATCH：标记完成（快速/表单）+ 取消完成（软撤销） | ✅ 已实施（2026-06-24） |
| src/app/api/h5/nongqing/prescriptions/[id]/route.ts | COMPONENT | COMPONENT_UPDATED | 仅 GET 详情 | 新增 PATCH：填报完成 + 取消完成（软撤销） | ✅ 已实施（2026-06-24） |
| src/app/api/h5/production-plan/plans/[id]/route.ts | COMPONENT | COMPONENT_CREATED | 无计划完成端点 | 新增 PATCH：标记计划完成 + 联动自动完成所有 pending 任务 + 释放地块 | ✅ 已实施（2026-06-24） |
| scripts/auto-complete-plans.ts | SCRIPT | COMPONENT_CREATED | 无定时完成机制 | 新增定时任务：每天 02:30 扫描到期计划自动标记 completed | ✅ 已实施（2026-06-24） |
| crontab | INFRA | COMPONENT_UPDATED | 无计划自动完成调度 | 新增 30 2 * * * 定时执行 auto-complete-plans.ts | ✅ 已实施（2026-06-24） |

---

## 一、背景与目标

### 1.1 问题现状

IoT 物联感知页面（`/wrnc/06/iot`）是小程序端的核心看板，其中包含两大模块：

1. **总体态势概览**（"农情态势概览"模块下的 section）：展示种植计划摘要 + 总体生产评价 + 关键发现 + 四情趋势分析 + 风险复盘。点击"详情"跳转到 Overall 页面（`/wrnc/06/overall`）展示完整数据。
2. **日常巡检报告**：每日06:00自动生成，分析过去24小时四情数据，输出正常/异常两种状态的报告。

当前这两个模块的数据均硬编码在前端 demo 页面中，**没有后端 API 支撑**。需要新建 API 端点，先以 demo 假数据跑通链路，后续接入真实数据源。

### 1.2 目标

1. **新建 2 个 API 端点**，路径归入 `nongqing`（农情）业务域
2. **阶段1（本次交付）**：返回与 demo 页面 1:1 对齐的假数据，跑通 API 链路
3. **DTO 集中管理**：类型定义和 Zod 校验追加到现有 `src/app/api/h5/types/` 目录
4. **复用现有基础设施**：认证（`h5-auth-gateway`）、审计（`agent-audit-logger`）、响应格式（`H5ApiResponse<T>`）

---

## 二、方案选型

### 2.1 路径命名方案

| 方案 | 路径 | 说明 | 结论 |
|------|------|------|------|
| A: `nongqing` | `/api/h5/nongqing/overview` + `/api/h5/nongqing/daily-report` | "农情"拼音，语义精准 | **采纳** |
| B: `situation` | `/api/h5/situation/overview` + `/api/h5/situation/daily-report` | 英文直译 | 不够领域化 |
| C: `iot` | `/api/h5/iot/overview` + `/api/h5/iot/daily-report` | 与 tab 名对齐 | "物联感知"是 UI 概念非业务域 |

选型理由：`nongqing`（农情）与 `production-plan`（生产计划）平级，都是 H5 业务域。后续若增加"农事任务"、"消息预警"等接口，也可归入 `nongqing/tasks`、`nongqing/alerts`。

### 2.2 数据来源方案（阶段1）

| 方案 | 说明 | 结论 |
|------|------|------|
| A: 硬编码假数据 | route.ts 内直接返回 JSON 常量 | **采纳（阶段1）** |
| B: LLM 生成 | 调用专家 prompt 生成分析文本 | 后续阶段2 |
| C: Farm-Server 聚合 | 从传感器/气象站实时取数 | 后续阶段3 |

选型理由：与 `production-plan/generate` 端点一致——阶段1 先跑通链路，验证 DTO + Zod + 认证全链路；真实数据源接入作为后续迭代。

### 2.3 阶段路线图（API 打通逻辑 + grounding 架构衔接）

**v2 需求文档明确了完整数据管道**（§1.3 逻辑架构）：

```
生产计划 → IoT原始数据(6维) → 系统先统计 → 全周期统计指标 → 农业大模型分析 → 总体态势概览
                                                                         ↘
                                                        (异常) → 生成专项处置方案
```

**与 Grounding Plan（farm-agent-grounding-customization-plan-v3）的衔接点**：

| Grounding Plan 能力 | Nongqing API 消费方式 | 阶段 |
|:--|:--|:--|
| GB/T 13745 学科分类体系 | AI 输入模板的 discipline context（气象学→210.20xx、植物保护学→210.60xx 等） | 阶段2 |
| Discipline Resolver 裁决器 | 四情数据自动按学科归类，辅助 LLM prompt 上下文组装 | 阶段2 |
| Expert Registry（grounding.disciplineCodes） | 农情分析专家路由：weather_analysis / soil_analysis / seedling_analysis / pest_analysis | 阶段2 |
| knowledge-sync 数据链路 | IoT 统计数据 → ChromaDB expert collection → LLM 检索增强 | 阶段2-3 |
| per-collection 语义缓存 | 四情趋势分析结果缓存（每周一 06:00 失效重建） | 阶段3 |

```
阶段1（✅ 已交付）: Demo 假数据 → 跑通 API 链路
  ├─ overview: 水稻/出苗期假数据（与 v2 需求 §1.3 AI输出示例对齐）
  │   含：planHeader / growthProgress / productionEvaluation / keyFindings(5条)
  │        trendAnalysis(4类) / riskReview / **yieldPrediction** ← v2 新增
  └─ daily-report: 水稻/出苗期 normal 状态假数据（与 v2 需求 §1.2 对齐）

阶段2（后续 Plan — 衔接 Grounding Step 1-2）: LLM 智能分析
  ├─ overview: 加载 nongqing_overview 专家 prompt
  │   → 输入: 6 维统计指标（weather/soil/seedling/pest/operation/risk）
  │   → 输出: overall_assessment + key_findings + 四情分析 + risk_review + yield_prediction
  │   → Expert Registry: grounding.disciplineCodes → 路由到对应农情专家
  └─ daily-report: 加载 daily_inspection 专家 prompt
      → 输入: 过去24h 四情数据 + 7天天气预报
      → 输出: normal（当前情况+今日建议+判断依据）| warning（+风险预警+处置方案）
      → tracking: Discipline Resolver 自动归类风险类型

阶段3（远期 — 衔接 Grounding Step 3-5）: Farm-Server 真实数据
  ├─ 气象站 API + 天气预报 API → weather stats ↓
  ├─ 土壤传感器 → moisture stats    ↓ 系统先统计聚合
  ├─ 苗情监测(无人机/遥感) → seedling stats ↓ （match v2 §1.3 统计输出格式）
  ├─ 病虫害预警 → pest stats        ↓
  ├─ 农事执行记录 → operation stats ↓
  └─ AI巡检记录 → risk stats        ↓
       ↓
  ChromaDB per-expert collection 存储 → LLM 检索增强
  per-collection 缓存失效策略：每周一 06:00 bumpCollectionGeneration()
```

---

## 三、架构设计

### 3.1 端点总览

| HTTP | 路径 | 功能 | 输入 |
|------|------|------|------|
| POST | `/api/h5/nongqing/overview` | 总体态势概览 | `{ projectId: number, planId?: number }` |
| POST | `/api/h5/nongqing/daily-report` | 日常巡检报告 | `{ projectId: number, planId?: number }` |

### 3.2 DTO 类型追加（dto.ts）

新增 2 个域的类型定义，追加到 `src/app/api/h5/types/dto.ts` 末尾：

**总体态势概览** — `OverviewData`：

```
OverviewData
├── planHeader: { farmName, planName, dayNumber, variety, targetYield, sowingDate, maturityDate }
├── growthProgress: { currentStage, percentage, daysToMaturity, stages[] (timeline节点) }
├── productionEvaluation: { summary (评价文本), predictedYieldRange, aboveRegionalPercent }
├── keyFindings: Array<{ index, title, detail }>  (5条关键发现)
├── trendAnalysis:
│   ├── weather: { summary, metrics{accumulatedTemp, sunshineHours, rainfall}, conclusion }
│   ├── soilMoisture: { summary, riskStats{light, moderate, flood, irrigationCount, timelyRate}, conclusion }
│   ├── seedling: { metrics{area, emergenceRate, ...9项}, conclusion }
│   └── pestDisease: { insect{type, warningCount, ...}, disease{type, warningCount, ...}, conclusion }
├── riskReview: Array<{ type, dateRange, duration, impactLevel, action, result }>
└── yieldPrediction: { predictedYield, targetYield, achievementRate, confidence }  ← v2 新增
```

**日常巡检报告** — `DailyReportData`（与需求文档 JSON 模板 1:1 对齐）：

```
DailyReportData
├── status: "normal" | "warning"
├── reportDate: string
├── crop: string
├── growthStage: string
├── growthProgress: string
├── currentStatus: { title, content }
├── todayAdvice?: { title, items[] }          // normal 时存在
├── riskWarning?: { title, riskType, riskLevel, description }  // warning 时存在
├── solutionPrescription?: { title, target, actions[], expectedEffect }  // warning 时存在
└── analysisBasis: { title, iotData, weatherData, growthStageAnalysis, aiAnalysis, agronomyRules }
```

### 3.3 Zod Schema 追加（schemas.ts）

与 DTO 对应的 Zod Schema，追加到 `src/app/api/h5/types/schemas.ts` 末尾。采用与现有 `planGenerateSchema` 相同的软校验策略（`safeParse` 失败不阻断，记录 audit + 降级原始输出）。

### 3.4 Route 实现模式

每个 route.ts 遵循现有 `production-plan/generate` 的标准骨架：

```
1. extractServiceCredential + resolveH5AuthGateway → 认证裁决
2. 解析 body (projectId 必填, planId 可选)
3. 构建假数据 JSON
4. Zod safeParse 校验
5. 返回 H5ApiResponse<T> { code, data, meta: { traceId, durationMs, projectId } }
```

### 3.5 Audit 阶段

新增 2 个审计阶段到 `agent-audit-logger.ts`（如该文件用 enum/union 管理阶段名）：
- `H5_NONGQING_OVERVIEW`
- `H5_NONGQING_DAILY_REPORT`

### 3.6 生产计划 generate 端点增强（2026-06-24 新增）

为确保 nongqing 域任务/处方数据的计划归属唯一性，对 `generate` 端点增加地块绑定与原子冲突检查：

| 维度 | 内容 |
|:--|:--|
| **Schema 变更** | `ProductionPlan` 新增 `massifIds Json?` 列（JSONB，存储 `[massifId, ...]`） |
| **冲突检查** | 生成前查询同 `projectId` 下所有已有计划的 `massifIds`，任一地块重叠 → **400 拒绝**（全量原子性，不部分写入） |
| **落库** | `upsert` 后通过 `$executeRawUnsafe` 写入 `massifIds` |
| **错误消息** | `地块 {ids} 已绑定计划「{planName}」(planId={id})，不能重复生成新计划` |
| **数据回填** | 历史计划 `B-多地块003+青虾` 已回填 `[3,4,5]` |

```
请求 selectedPlots=[10,11,12]
  → 查 ProductionPlan WHERE projectId=1 AND massifIds IS NOT NULL
    → 计划A massifIds=[3,4,5] → 10,11,12 无重叠 ✅
    → 计划B massifIds=[10,20]  → 10 重叠 ❌ → 400 拒绝
  → 全部不重叠 → 正常生成 + 写入 massifIds=[10,11,12]
```

### 3.7 Demo 假数据内容来源（v2 对齐）

**overview 端点**：数据内容与 v2 需求文档 §1.3 "AI输出示例" 对齐：
- 作物: 水稻，品种: 南粳9108，目标: 650kg/亩，播期: 5月15日，成熟: 10月15日
- 生育期: 出苗期，进度: 10%，距成熟: 138天
- 5条关键发现（出苗率95.6%、播种期气象有利、墒情适宜、苗期零病虫害、农事执行率100%）
- 四情趋势（气象/墒情/苗情/病虫情）含详细指标
- 风险复盘: 空（出苗期暂无风险事件）
- **yieldPrediction**: 预测产量 650-700公斤/亩，达成率 100%+，置信度: 高

**daily-report 端点**：数据内容与 v2 需求文档 §1.2 的正常情况 JSON 示例对齐（作物/生育期已切换为水稻/出苗期）：
- status: "normal"
- 当前情况 + 今日建议(3条) + 判断依据(5维度)

---

## 四、实施步骤 + 依赖图

```
Task 1: DTO 类型追加 (dto.ts)  ──┐
                                  ├── 可并行
Task 2: Zod Schema 追加 (schemas.ts) ──┘
                                  │
                                  ▼
Task 3: overview/route.ts (总体态势概览)
Task 4: daily-report/route.ts (日常巡检报告)
                                  │
                                  ▼
Task 5: tsc --noEmit + curl 验证
```

### Task 详细

#### Task 1: DTO 类型追加
- 文件: `src/app/api/h5/types/dto.ts`
- 操作: 末尾追加 `// ──── 农情态势 ────` 分区，新增 OverviewData + DailyReportData 及相关嵌套类型
- **验证**: `tsc --noEmit` 通过

#### Task 2: Zod Schema 追加
- 文件: `src/app/api/h5/types/schemas.ts`
- 操作: 末尾追加 `// ──── 农情态势 ────` 分区，新增 overviewSchema + dailyReportSchema
- **验证**: `tsc --noEmit` 通过

#### Task 3: 总体态势概览端点
- 新建: `src/app/api/h5/nongqing/overview/route.ts`
- PREFIX: `[H5-NONGQING-OVERVIEW]`
- traceId: `h5_nq_overview_<uuid>`
- 认证: X-Api-Key (service) / X-Session-Id (session)
- 输入: `{ projectId, planId? }`
- 输出: 与 demo overall 页面对齐的完整 OverviewData JSON
- **验证**: curl 返回正确 JSON

#### Task 4: 日常巡检报告端点
- 新建: `src/app/api/h5/nongqing/daily-report/route.ts`
- PREFIX: `[H5-NONGQING-DAILY-REPORT]`
- traceId: `h5_nq_report_<uuid>`
- 认证: 同 Task 3
- 输入: `{ projectId, planId? }`
- 输出: 与需求文档 normal 模板对齐的 DailyReportData JSON
- **验证**: curl 返回正确 JSON

#### Task 5: 编译 + curl 验证
- `npx tsc --noEmit` 零错误
- curl 验证 2 个端点：
  ```
  curl -X POST http://localhost:3000/api/h5/nongqing/overview \
    -H "X-Api-Key: svc_xxx" -H "Content-Type: application/json" \
    -d '{"projectId":1}'
  
  curl -X POST http://localhost:3000/api/h5/nongqing/daily-report \
    -H "X-Api-Key: svc_xxx" -H "Content-Type: application/json" \
    -d '{"projectId":1}'
  ```
- 确认无 Key 返回 401
- 确认 Zod 校验通过（响应 data 结构完整）

---

## 五、验收标准

- [ ] `POST /api/h5/nongqing/overview` 返回完整 OverviewData JSON（结构与 demo overall 页面 1:1 对齐）
- [ ] `POST /api/h5/nongqing/daily-report` 返回 DailyReportData JSON（结构与需求文档 normal 模板对齐）
- [ ] 无 X-Api-Key 时两个端点均返回 401
- [ ] `projectId` 缺失时返回 400
- [ ] DTO 类型集中在 `types/dto.ts`，Zod Schema 集中在 `types/schemas.ts`
- [ ] Zod safeParse 校验通过（日志无 Schema 校验失败）
- [ ] 审计日志可查（H5_NONGQING_OVERVIEW + H5_NONGQING_DAILY_REPORT）
- [ ] `npx tsc --noEmit` 编译零错误

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| H5 API v2 Plan | `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v2.md` | ✅ 已实施 |
| Grounding Plan | `.qoder/plans/farm-agent-grounding-customization-plan-v3.md` | ✅ 已存在 |
| **子 Plan** | `.qoder/plans/farm-agent-crop-plan-model-plan-v1.md` | 📋 Plan 已生成，待实施 |
| 需求文档 v2 | `docs/.../农场管理软件小程序端 需求文档v2.md` | ✅ 已存在 |
| Demo 页面 | `https://80retros.com/wrnc/06/overall` | ✅ 可访问 |
| ADD Route | `.qoder/plans/farm-agent-nongqing-report-api-add-route-v1.md` | ✅ 已生成 |
| Handoff | `.qoder/plans/farm-agent-nongqing-report-api-handoff-v1.md` | ✅ 已生成 |
| Review | `.qoder/reviews/farm-agent-nongqing-report-api-plan-v1-review-v1.md` | ⬜ 待生成 |
