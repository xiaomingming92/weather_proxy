# 计划：架构文档修正、按钮激活态与模型钩子集成

## 问题诊断

经过对项目当前代码的全面审查，识别出以下待完成项：

### 问题一：架构文档与实现严重不一致（Task 5.1 未完成）

当前 [团队协同智能体_技术架构.md](file:///home/xmm/ai/农业智能体/team-coordinator-agent/.trae/documents/团队协同智能体_技术架构.md) 与实际代码存在多处不一致：

| 维度 | 架构文档描述 | 实际代码实现 |
|------|-----------|-----------|
| Agent 图结构 | intention→retrieval→reasoning→verdict→response | intention→retrieval→reasoning→interactionPointDetection→(routeByInteractionPoint)→verdict/response |
| 路由逻辑 | `routeByIntent` 多分支路由 | `routeByIntent` 始终返回 "retrieval" |
| 路由逻辑 | `routeByVerdictType` 多分支(task_assignment/risk_handling/cost_optimization) | `routeByVerdictType` 始终返回 "response" |
| 新增节点 | 无 interactionPointDetection | 已实现 interactionPointDetectionNode |
| State 定义 | 无 explicitIntent/structuredResponse/conversationContext/pendingInteraction | 已实现全部字段 |
| Prompt 模板 | 内联字符串拼接 | 已实现结构化 PromptTemplate 体系 |
| 输出格式 | 纯文本拼接 | 已实现 StructuredAgentResponse 结构化输出 |
| 按钮层级 | 未定义 | 已实现一级(分析/规划) + 二级(文档/图片) |
| 链路追踪 | 仅节点级审计 | 已实现链路级 ChainTrace |

### 问题二：一级按钮缺少激活态和业务保护

当前 [quick-action-bar.tsx](file:///home/xmm/ai/农业智能体/team-coordinator-agent/src/components/chat/quick-action-bar.tsx) 的一级按钮（分析/规划）：
- 点击后无视觉反馈表明"当前正在执行该业务"
- 无法再次点击取消/恢复
- 业务进行中（streaming）时无保护，用户可能误操作中断

用户需求：
1. **激活态样式**：点击后按钮变为激活样式（如高亮、不同背景色），表示"正在执行分析/规划"
2. **切换行为**：再次点击恢复默认样式（取消激活）
3. **业务保护**：如果业务正在进行中（isStreaming=true），点击激活态按钮应提示"业务进行中，不可关闭"

### 问题三：文档一致性

---

## 实施计划

### 步骤 1：一级按钮激活态与业务保护

**目标**：分析/规划按钮支持激活态样式、切换行为、业务进行中保护

**设计**：

```typescript
// quick-action-bar.tsx 新增状态

interface QuickActionBarProps {
  onPrimaryAction?: (action: PrimaryAction) => void
  onFileSelect?: (files: FileList) => void
  activeIntent?: string | null          // 当前激活的意图
  isStreaming?: boolean                  // 业务是否进行中
  onToggleIntent?: (intent: string | null) => void  // 切换意图激活状态
  className?: string
}
```

**UI 行为**：

```
默认状态：
[🎯 分析]  [📋 规划]     ← variant="secondary", 正常样式

点击"分析"后（激活态）：
[🎯 分析 ✓]  [📋 规划]   ← variant="default", 背景高亮, 带激活标记

业务进行中时点击激活态按钮：
→ 弹出提示："分析正在进行中，无法取消"
→ 按钮保持激活态

业务完成后：
→ 按钮自动恢复默认态（或用户手动点击恢复）
```

**样式区分**：
- 默认态：`variant="secondary"`, `bg-secondary text-secondary-foreground`
- 激活态：`variant="default"`, `bg-primary text-primary-foreground`, 右下角小圆点指示器
- 进行中：激活态 + 脉冲动画 `animate-pulse`

**操作**：
- 修改 `src/components/chat/quick-action-bar.tsx` — 增加 activeIntent/isStreaming/onToggleIntent props，按钮样式根据状态变化
- 修改 `src/components/chat/chat-container.tsx` — 传递 activeIntent 和 isStreaming 状态
- 修改 `src/components/chat/chat-panel.tsx` — 管理 activeIntent 状态，与 streaming 状态联动

### 步骤 2：文档更新


### 步骤 3：架构文档全面修正

**目标**：让架构文档准确反映当前实现，补充所有新增体系

**改动清单**：

1. **修正 7.1 项目结构** — 补充 prompts/ 目录（types.ts, intention.ts, reasoning.ts, verdict.ts, interaction-point-detection.ts, response.ts）、types/ 目录（structured-output.ts）、新增节点（interaction-point-detection.ts）

2. **修正 7.2 State 定义** — 增加 explicitIntent、structuredResponse、conversationContext、pendingInteraction 字段

3. **修正 7.3 节点实现** — 更新为使用结构化 Prompt 模板的代码示例

4. **修正 7.4 边定义** — 更新 routeByIntent（所有意图→retrieval）、新增 routeByInteractionPoint、修正 routeByVerdictType（始终→response）

5. **修正 7.5 Agent 编译** — 更新图结构（含 interactionPointDetection 节点）

6. **新增章节：按钮层级与 Agent 流程映射** — 一级按钮（分析/规划）→ 显式意图 → Agent 路径，二级按钮（文档/图片）→ 辅助功能

7. **新增章节：结构化 Prompt 模板体系** — PromptTemplate 接口、各 Prompt 的 Input/Output Schema

8. **新增章节：结构化输出体系** — StructuredAgentResponse 完整类型定义

9. **新增章节：链路级可审计追踪** — ChainTrace 接口、追踪器实现

10. **新增章节：交互点自动检测** — interactionPointDetectionNode 工作原理

11. **新增章节：按钮激活态与业务保护** — 激活态样式、切换行为、业务进行中保护

**操作**：
- 修改 `.qoder/documents/团队协同智能体_技术架构.md` — 全面修正和补充

---

## 文件变更清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/components/chat/quick-action-bar.tsx` | 修改 | 增加激活态样式、切换行为、业务保护 |
| `src/components/chat/chat-container.tsx` | 修改 | 传递 activeIntent/isStreaming 状态 |
| `src/components/chat/chat-panel.tsx` | 修改 | 管理 activeIntent 状态 |
| `.qoder/documents/团队协同智能体_技术架构.md` | 修改 | 全面修正和补充 |

---

## 实施优先级

1. **步骤 1** — 按钮激活态与业务保护（用户可见，体验提升）
2. **步骤 3** — 架构文档修正（收尾，确保文档与实现一致）

---

## 验收标准

1. 分析/规划按钮点击后显示激活态样式（高亮+激活标记）
2. 再次点击激活态按钮恢复默认样式
3. 业务进行中（isStreaming=true）点击激活态按钮弹出提示
4. 链路追踪记录模型参数影响
5. 架构文档与代码实现完全一致
6. TypeScript 编译通过
