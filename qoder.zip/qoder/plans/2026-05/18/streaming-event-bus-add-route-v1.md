# streaming-event-bus-add-route-v1

> **定位**：Runtime 纠正 §6 → ADD 九阶段执行映射。绑定：Plan `streaming-event-bus-plan-v1.md` §6。
>
> **模式**：轻量（Lightweight）——改动范围小，无需 spec sync + DPS/RAHS 闸门。
>
> **触发来源**：VPS 生产日志 `STREAM_BUS_EMIT_ERROR` 持续出现。

---

## 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: SSE Stream Bus 优雅结束——消除客户端断连时的 ERROR 日志噪音 + 回调异常防护

Task Groups:
  Group A（stream-bus 核心）: emitStreamEvent 对 response_end/structured_update 静默降级
  Group B（端点回调防护）: chat/stream + agent/[hash] 回调 streamClosed 防护

逐组业务价值判定:
  Group A: 可用 — stream-bus 独立改动能独立验证
  Group B: 可用 — 每个端点独立改动可分别验证

判定结论: 1 轮（1 个原子闭包）

第1轮（原子闭包1）: Task A+B — 业务功能: 三条端点断连时不再产生 STREAM_BUS_EMIT_ERROR
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## Step 0：文档先行

- Plan §6 Runtime 纠正已追加 ✅
- §2.2 推送语义更新 ✅
- §3.4 用户视角时间线更新 ✅
- Handoff 已创建 ✅

---

## Step 1-8：执行（轻量模式）

| Step | 操作 | 产出 |
|------|------|------|
| 1 | 实施 `stream-bus.ts` 改动 | `response_end`/`structured_update` 独立处理（✅ 已改） |
| 2 | 实施 `chat/stream/route.ts` 回调改动 | 去掉 `unregisterStreamBus` |
| 3 | 实施 `agent/[hash]/route.ts` 回调改动 | 增加 `streamClosed` 防护 |
| 4 | tsc 编译验证 | `npx tsc --noEmit` 通过 |
| 5 | VPS 部署 | `pm2 restart farm-agent` |
| 6 | 日志验证 | 5 分钟无 `STREAM_BUS_EMIT_ERROR ... 未注册` |
| 7 | devlog | `record_dev_operation` |
| 8 | 验收闭环 | 更新 handoff + Plan 修订时间 |

> Step 2-3 的 `h5/agent/route.ts` 变更归属 `farm-agent-ruifengyun-h5-api-plan-v2.md` §7，对应 add-route 为 `farm-agent-ruifengyun-h5-api-v2-add-route-v3.md`。

---

## 附录：文件清单

| 文件 | 操作 | Task | ADD-7 状态 |
|------|------|------|------------|
| `src/agents/stream-bus.ts` | MODIFY | A | ✅ |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY | B | ⬜ |
| `src/app/api/agent/[hash]/route.ts` | MODIFY | B | ⬜ |
