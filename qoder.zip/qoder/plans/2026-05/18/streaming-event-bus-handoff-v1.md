# streaming-event-bus — 1 轮 Runtime 纠正 交接手册

> **适用场景**：SSE Stream Bus 优雅结束 — Runtime 纠正。
>
> **用途**：每个新对话开始时，把对应轮次章节粘贴给 LLM。

---

## 全局元信息

- **父 Plan 1（主责）**: [streaming-event-bus-plan-v1.md](./streaming-event-bus-plan-v1.md)
- **父 Plan 2（关联）**: [farm-agent-ruifengyun-h5-api-plan-v2.md](../../2026-06/23/farm-agent-ruifengyun-h5-api-plan-v2.md)
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 4 个（4 修改）
- **轮次数**: 1 轮
- **最新修订**: 2026-06-26（补充 H5 Interrupt 暂停修复 §8 的认知同步）

```text
第1轮 ── SSE Stream Bus 优雅结束（4 文件回调防护 + 收尾事件静默降级）
```

---

## 原子事务边界说明

本轮是一个原子闭包：`stream-bus.ts` 的收尾事件降级 + 三条 SSE 端点的回调防护必须共同交付，缺一不可。

- `stream-bus.ts` 的 `response_end`/`structured_update` 独立处理后，若端点回调无 `streamClosed` 防护，`controller.enqueue` 异常仍会冒泡
- 端点回调的 `streamClosed` 防护若无 `stream-bus.ts` 的静默降级配合，bus 未注册时仍会记录 ERROR

两父 Plan 职责边界：
- `streaming-event-bus-plan-v1.md` 主责：`stream-bus.ts` + `chat/stream/route.ts` + `agent/[hash]/route.ts`
- `farm-agent-ruifengyun-h5-api-plan-v2.md` 关联：`h5/agent/route.ts`（§7 streamClosed 防护 + §8 interrupt break 修复）

---

## <第1轮> SSE Stream Bus 优雅结束

### 你当前的位置

你是第 1 轮（共 1 轮）。Runtime 纠正 — VPS 生产日志 `STREAM_BUS_EMIT_ERROR` 持续出现需修复。

### 上游已完成

- `streaming-event-bus-plan-v1` 已交付 stream-bus 基础设施（`registerStreamBus`/`unregisterStreamBus`/`emitStreamEvent`）
- `farm-agent-ruifengyun-h5-api-plan-v2` 已交付 H5 agent 端点（`/api/h5/agent`）及相关联端点

### 恢复上下文审计查询（新 AI Session 首次启动必读）

#### 第一步：搜索代码文件改动

```text
query_audit_logs({ targetId: "src/agents/stream-bus.ts" })
```
→ 返回 1 条：MODIFY。beforeState: response_end/structured_update fall-through, logs ERROR when unregistered。afterState: response_end/structured_update independent, best-effort, silent skip。

```text
query_audit_logs({ targetId: "src/app/api/agent/chat/stream/route.ts" })
```
→ 返回 1 条：MODIFY。beforeState: callback catch calls unregisterStreamBus prematurely。afterState: callback only sets streamClosed, unregister deferred to finally。

```text
query_audit_logs({ targetId: "src/app/api/agent/[hash]/route.ts" })
```
→ 返回 1 条：MODIFY。beforeState: callback without try/catch。afterState: callback with streamClosed guard and try/catch。

```text
query_audit_logs({ targetId: "src/app/api/h5/agent/route.ts" })
```
→ 返回 2 条：MODIFY（§7 streamClosed 防护）+ MODIFY（§8 interrupt break 修复）。beforeState: callback without try/catch or streamClosed, __interrupt__ handler uses continue。afterState: streamClosed guard, interrupt break + early return。

#### 第二步：搜索文档变更记录

```text
query_audit_logs({ keyword: "DOC_UPDATED" })
```
→ 返回 4+ 条：`streaming-event-bus-plan-v1.md` §2.2/§3.4/§6，`ruifengyun-h5-api-plan-v2.md` §7+§8，`决策管线架构说明书.md` §4.4，`ruifengyun-h5-api-handoff-v2.md` §8 恢复区。

```text
query_audit_logs({ keyword: "sse-stream-graceful-shutdown" })
```
→ 返回全部约 12 条本轮 ADD-7 审计记录（4 代码 + 8 文档）。

#### 恢复顺序建议

```
1. session-init SKILL
2. query_audit_logs({ keyword: "sse-stream-graceful-shutdown" })  → 全部 10 条
3. read stream-bus.ts / chat/stream/route.ts / agent/[hash]/route.ts / h5/agent/route.ts
4. read streaming-event-bus-plan-v1.md §6
```

### 原子事务目标

消除客户端断连时 `STREAM_BUS_EMIT_ERROR` 日志噪音 + 三条 SSE 端点回调异常防护。

### 你要改的文件（4 个：4 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/stream-bus.ts` | 修改 | `response_end`/`structured_update` 独立处理，bus 不在时静默跳过 |
| `src/app/api/agent/chat/stream/route.ts` | 修改 | 回调 catch 中去掉 `unregisterStreamBus`，仅保留 `streamClosed` |
| `src/app/api/agent/[hash]/route.ts` | 修改 | 回调增加 `streamClosed` + try/catch 防护 |
| `src/app/api/h5/agent/route.ts` | 修改 | 回调加 `streamClosed`（§7）+ `__interrupt__` 处理 `continue`→`break`（§8，归属 ruifengyun-h5-api-v2） |

### 关键契约

- `src/agents/stream-bus.ts` 其余事件（`done`/`error`/`tool_call`）ERROR 日志保留，不改
- `chat/stream/route.ts:315` 缓存命中时的 `unregisterStreamBus` 保留（正常提前结束）
- H5 resume 端点（未使用 stream bus）不在范围

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| MODIFY | COMPONENT | `src/agents/stream-bus.ts` | `response_end`/`structured_update` 独立处理 | ✅ |
| MODIFY | API_ROUTE | `src/app/api/agent/chat/stream/route.ts` | 去 `unregisterStreamBus`，仅 `streamClosed` | ✅ |
| MODIFY | API_ROUTE | `src/app/api/agent/[hash]/route.ts` | 加 `streamClosed` + try/catch | ✅ |
| MODIFY | API_ROUTE | `src/app/api/h5/agent/route.ts` | 加 `streamClosed` + try/catch（归属 ruifengyun-h5-api-v2 §7+§8） | ✅ |
| CREATE | HANDOFF | `.qoder/plans/2026-05/18/streaming-event-bus-handoff-v1.md` | 本交接手册 | ✅ |
| CREATE | HANDOFF | `.qoder/plans/2026-05/18/streaming-event-bus-add-route-v1.md` | add-route 执行映射 | ✅ |
| DOC_UPDATED | PLAN | `.qoder/plans/2026-05/18/streaming-event-bus-plan-v1.md` | §2.2/§3.4/§6 增量更新 | ✅ |
| DOC_UPDATED | PLAN | `.qoder/plans/2026-06/23/farm-agent-ruifengyun-h5-api-plan-v2.md` | §7 轻量引用 + §8 interrupt 修复 | ✅ |
| DOC_UPDATED | HANDOFF | `.qoder/plans/2026-06/22/farm-agent-ruifengyun-h5-api-handoff-v2.md` | §10 精简引用 + §8 恢复区登记 | ✅ |
| DOC_UPDATED | HANDOFF | `.qoder/plans/2026-06/25/farm-agent-ruifengyun-h5-api-v2-add-route-v3.md` | §7+§8 标记行 | ✅ |
| DOC_UPDATED | DOC | `docs/.../决策管线架构说明书.md` | §4.4 管线行为更新为 interrupt + resume 三段式 | ✅ |
| MODIFY | COMPONENT | `src/agents/sse-stream-state.ts` | 回退Idle→Interrupted hack，3路由显式transition(Idle,Streaming) | ✅ |
| MODIFY | API_ROUTE | `src/app/api/agent/resume/route.ts` | await agent.stream + handleInterrupt/handleError 统一 | ✅ |
| MODIFY | API_ROUTE | `src/app/api/h5/agent/[threadId]/resume/route.ts` | await agent.stream + handleInterrupt/handleError 统一 | ✅ |

**恢复关键词**：
```text
query_audit_logs({ keyword: "sse-stream-graceful-shutdown" })
→ 返回全部约 12 条本轮 ADD-7 审计记录
```

### 验证标准

#### 已完成验证

- `npx tsc --noEmit` 通过（零错误）
- 4 个代码文件改动已就位（含 h5/agent/route.ts 双改：§7 streamClosed + §8 interrupt break）
- 9 个文档增量更新已就位（Plan × 2 + Handoff × 3 + Add-Route × 1 + 本 Handoff × 2 + 架构 Doc × 1）

#### 未执行的端到端验证（保留给运行时复测）

- [ ] VPS 部署后 `tail -f ~/farm-agent/logs/pm2-out.log | grep STREAM_BUS_EMIT_ERROR`，5 分钟内无输出（原因：需部署后验证）
- [ ] 发送"小麦在夏天如何养护" → 接收 `event: interrupt` → 无 `done` → POST resume 正常恢复 SSE 流（原因：需部署后验证）

### 完成后记录 ADD-7 审计

每改完一个文件，调用 `record_dev_operation`：

| 文件 | action |
|------|--------|
| `src/agents/stream-bus.ts` | MODIFY |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY |
| `src/app/api/agent/[hash]/route.ts` | MODIFY |
| `src/app/api/h5/agent/route.ts` | MODIFY（§7 streamClosed + §8 interrupt break） |

完成后一键验证：
```text
query_audit_logs({ keyword: "sse-stream-graceful-shutdown" })
→ 确认 12 条全部落库
```

---

## 附录：每轮启动模板

```text
## 上下文

你在执行 streaming-event-bus Runtime 纠正 [第1轮/共1轮]。
上游 streaming-event-bus-plan-v1 和 ruifengyun-h5-api-plan-v2 已完成。
先读 streaming-event-bus-handoff-v1.md 的 <第1轮> 章节。

## 启动步骤

1. 执行 session-init SKILL
2. query_audit_logs({ keyword: "sse-stream-graceful-shutdown" }) → 恢复全部上下文
3. 读 streaming-event-bus-plan-v1.md §6
4. 按 ADD-7 审计记录表逐文件实施
5. 每完成一个文件：record_dev_operation
6. tsc --noEmit 验证
7. 记录 devlog 后回查确认落库
```
