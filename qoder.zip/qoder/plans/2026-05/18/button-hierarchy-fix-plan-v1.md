# 计划：按钮层级体系梳理、结构化管线与可审计链路

## 问题诊断

经过对以下文件的全面分析：
- [quick-action-bar.tsx](file:///home/xmm/ai/农业智能体/team-coordinator-agent/src/components/chat/quick-action-bar.tsx) — UI 按钮定义
- [conditional.ts](file:///home/xmm/ai/农业智能体/team-coordinator-agent/src/agents/edges/conditional.ts) — Agent 路由逻辑
- [retrieval.ts](file:///home/xmm/ai/农业智能体/team-coordinator-agent/src/agents/nodes/retrieval.ts) — 检索节点
- [intention.ts](file:///home/xmm/ai/农业智能体/team-coordinator-agent/src/agents/nodes/intention.ts) — 意图解析节点
- [reasoning.ts](file:///home/xmm/ai/农业智能体/team-coordinator-agent/src/agents/nodes/reasoning.ts) — 推理节点
- [verdict.ts](file:///home/xmm/ai/农业智能体/team-coordinator-agent/src/agents/nodes/verdict.ts) — 裁决节点
- [response.ts](file:///home/xmm/ai/农业智能体/team-coordinator-agent/src/agents/nodes/response.ts) — 响应节点
- [index.ts](file:///home/xmm/ai/农业智能体/team-coordinator-agent/src/agents/index.ts) — Agent 图定义
- [state.ts](file:///home/xmm/ai/农业智能体/team-coordinator-agent/src/agents/state.ts) — State 定义
- [团队协同智能体_技术架构.md](file:///home/xmm/ai/农业智能体/team-coordinator-agent/.trae/documents/团队协同智能体_技术架构.md) — 架构文档

发现 **五个核心问题**：

### 问题一：按钮层级缺失，UI 无法区分

当前 QuickActionBar 的按钮是**扁平结构**，所有按钮视觉权重相同：

```
[📎文档] [🖼图片] | [⚡推理] [✨模板] | [🎯分析] [💡决策] [💬规划]
```

- 文件上传按钮、分类切换按钮、快捷操作按钮 — 全部使用 `h-7 px-2 text-xs` 相同尺寸
- 没有一级/二级的视觉区分
- 分类系统（reasoning/template）是**显示过滤器**，不是**语义层级**

### 问题二：按钮 → 意图 → Agent 流程的映射断裂

快捷按钮的 `category` 与 Agent 的 `intent` 是两套独立体系，没有映射关系：

| 快捷按钮 | 按钮 category | 预填 prompt | Agent 实际 intent | Agent 实际路径 |
|---------|-------------|------------|-----------------|-------------|
| 分析 | reasoning | "请帮我分析当前情况" | question/decision | retrieval→reasoning→verdict→response |
| 决策 | reasoning | "请帮我做出决策" | decision | retrieval→reasoning→verdict→response |
| 规划 | template | "请帮我制定执行计划" | creation | **直接 response（跳过推理）** |

**关键矛盾**："规划"按钮归类为"模板"，但用户期望点击"规划"也能走推理链路，而实际它跳过了整个推理管线。

### 问题三：Prompt 模板非结构化，无法验证和组合

当前所有 prompt 都是**字符串拼接**，散落在各节点文件中：

```typescript
// intention.ts 第42-86行 — 纯字符串拼接
const prompt = `
你是一个意图解析助手...
用户消息：${textContent}
请分析并返回以下格式的 JSON...
`
```

**问题**：
- 没有 input schema — 不知道 prompt 需要哪些变量
- 没有 output schema — 不知道 LLM 应该返回什么结构
- 无法单元测试 — prompt 变更无法验证输出格式是否正确
- 无法组合 — 不同 prompt 之间无法复用公共片段

### 问题四：聊天输出非结构化，证据链无法放大

当前 response 节点输出的是**纯文本字符串**：

```typescript
// response.ts — 拼接纯文本
let response = `${conclusion}\n\n置信度: ${confidence}%\n\n`
response += `建议行动:\n${actions.map(...).join("\n")}\n\n`
```

**问题**：
- 证据链的每条证据无法单独点击展开查看详情
- 推理路径的每一步无法单独放大查看中间结果
- 置信度分解无法可视化展示折扣来源

### 问题五：发送→响应链路不可审计

当前审计日志只记录了节点级别的开始/结束：

```typescript
agentAuditNodeStart("intention")
agentAuditNodeEnd("intention", durationMs)
```

**缺失**：
- 没有链路级 trace ID — 无法将一次用户操作的所有节点串联
- 没有记录每个节点的输入/输出快照 — 无法回放推理过程
- 没有记录条件路由的决策依据 — 不知道为什么走了 retrieval 而不是 response
- 证据链的来源、评分、权重变化没有完整记录

### 问题六：架构文档与实现不一致

| 维度 | 架构文档描述 | 实际代码实现 |
|------|-----------|-----------|
| 路由逻辑 | `decision → verdict` | `decision → retrieval` |
| 路由逻辑 | `creation → creation` 节点 | `creation → response` 节点（无 creation 节点） |
| routeByVerdictType | 多分支：task_assignment/risk_handling/cost_optimization | **永远返回 "response"** |
| prompts 目录 | `src/agents/prompts/intention.ts` 等 | **目录不存在**，prompt 全部内联 |
| 按钮层级 | 未定义 | 未定义 |
| 结构化输出 | 未定义 | 纯文本拼接 |
| 链路审计 | 仅节点级 | 无链路级 trace |

---

## 实施计划

### 步骤 1：创建结构化 Prompt 模板体系

**目标**：每个 prompt 模板都有明确的 input schema 和 output schema，可验证、可测试、可组合

**设计**：

```typescript
// src/agents/prompts/types.ts

interface PromptTemplate<TInput, TOutput> {
  id: string
  name: string
  description: string
  inputSchema: TInput          // 输入结构定义
  outputSchema: TOutput        // 输出结构定义
  build: (input: TInput) => string   // 构建 prompt 字符串
  parse: (raw: string) => TOutput    // 解析 LLM 输出为结构化数据
  validate: (output: TOutput) => boolean  // 验证输出是否符合 schema
}

// 示例：意图解析 Prompt
interface IntentionInput {
  userMessage: string
  hasImage: boolean
  hasAudio: boolean
  textContent: string
}

interface IntentionOutput {
  intent: "question" | "decision" | "creation" | "modification" | "chat"
  entities: {
    projectId?: string
    taskId?: string
    keywords: string[]
  }
  multimodal?: {
    hasImage: boolean
    hasAudio: boolean
  }
}
```

**操作**：
- 创建 `src/agents/prompts/types.ts` — PromptTemplate 接口定义
- 创建 `src/agents/prompts/intention.ts` — 结构化意图解析 prompt
- 创建 `src/agents/prompts/reasoning.ts` — 结构化推理 prompt
- 创建 `src/agents/prompts/verdict.ts` — 结构化裁决 prompt
- 创建 `src/agents/prompts/response.ts` — 结构化回复生成 prompt
- 创建 `src/agents/prompts/index.ts` — 统一导出

### 步骤 2：定义结构化输出体系

**目标**：聊天输出不再是纯文本，而是结构化数据，支持证据链节点的放大细节探索

**设计**：

```typescript
// src/agents/types/structured-output.ts

interface StructuredAgentResponse {
  traceId: string                    // 链路追踪 ID
  intent: ResolvedIntent             // 解析后的意图
  evidenceChain: StructuredEvidenceChain  // 结构化证据链
  reasoningPath: StructuredReasoningPath  // 结构化推理路径
  verdict: StructuredVerdict         // 结构化裁决结果
  displayContent: DisplayContent     // 渲染用的展示内容
}

interface StructuredEvidenceChain {
  evidences: Array<{
    id: string
    source: EvidenceSource
    type: string
    content: string
    reliability: number
    relevance: number
    timestamp: string
    metadata: Record<string, unknown>
    expandable: boolean              // 是否可展开查看详情
    detailUrl?: string               // 详情数据来源
  }>
  totalScore: number
  sourceBreakdown: Record<EvidenceSource, number>
}

interface StructuredReasoningPath {
  steps: Array<{
    step: number
    action: string
    inputEvidenceIds: string[]
    intermediateResult: unknown
    description: string
    expandable: boolean              // 可展开查看中间计算过程
  }>
  traces: string[]
}

interface StructuredVerdict {
  type: string
  conclusion: {
    content: string
    actions: string[]
    risks: Array<{
      level: "low" | "medium" | "high"
      description: string
      probability: number
      impact: string
      expandable: boolean            // 可展开查看风险详情
    }>
  }
  confidence: {
    baseConfidence: number
    reliabilityDiscount: number
    conflictDiscount: number
    finalConfidence: number
    breakdown: Array<{               // 置信度分解明细
      factor: string
      value: number
      reason: string
    }>
  }
}

interface DisplayContent {
  summary: string                    // 一句话摘要
  sections: Array<{
    type: "conclusion" | "evidence" | "reasoning" | "confidence" | "risk"
    title: string
    content: string
    expandable: boolean
    dataRef: string                  // 指向结构化数据的引用 ID
  }>
}
```

**操作**：
- 创建 `src/agents/types/structured-output.ts` — 结构化输出类型定义
- 创建 `src/agents/types/index.ts` — 统一导出
- 修改 `src/agents/state.ts` — 增加 structuredResponse 字段

### 步骤 3：实现链路级可审计追踪

**目标**：从用户点击发送到最终响应，每一步都可追溯、可回放

**设计**：

```typescript
// src/lib/agent-chain-tracer.ts

interface ChainTrace {
  traceId: string                    // 唯一链路 ID
  threadId: string                   // 会话 ID
  startTime: number
  endTime?: number
  totalDurationMs?: number

  trigger: {
    type: "button_click" | "manual_send" | "file_upload"
    buttonId?: string                // 如果是一级按钮触发
    explicitIntent?: string          // 显式意图
    userInput: string
  }

  nodes: Array<{
    nodeName: string
    startTime: number
    endTime: number
    durationMs: number
    inputSnapshot: Record<string, unknown>   // 节点输入快照
    outputSnapshot: Record<string, unknown>  // 节点输出快照
    routeDecision?: {                         // 条件路由决策
      from: string
      to: string
      reason: string
      conditionValue: unknown
    }
  }>

  evidenceChainSnapshot: {
    before: Evidence[]                // 节点执行前的证据链
    after: Evidence[]                 // 节点执行后的证据链
    diff: Array<{                     // 证据变化
      action: "added" | "removed" | "modified"
      evidenceId: string
      details: string
    }>
  }

  worldLineSnapshots: Array<{
    timestamp: number
    weights: Record<string, number>
    verdictType: string
    confidence: number
  }>
}
```

**操作**：
- 创建 `src/lib/agent-chain-tracer.ts` — 链路追踪器实现
- 修改 `src/agents/index.ts` — 在 wrapNodeWithAudit 中集成链路追踪
- 修改 `src/agents/edges/conditional.ts` — 记录路由决策
- 修改 API route — 返回 traceId

### 步骤 4：定义按钮层级体系

**目标**：建立清晰的一级/二级按钮语义模型，将决策点融入分析/规划的自然流程

**层级定义**：

```
一级按钮（Primary Actions）— 对应 Agent 的核心推理路径，点击直接发送
  ├── 分析 → intent: analysis → 完整推理链路（retrieval→reasoning→[自动识别决策点]→response）
  │   └── 分析完毕后，如LLM识别到关键决策点 → 主动提示用户"是否需要我帮你做个决策？"
  │       └── 用户同意 → 进入决策对话（verdict节点）→ 更新结论
  │
  └── 规划 → intent: planning → 完整推理链路（retrieval→reasoning→[自动识别权衡点]→response）
      └── 规划过程中，如LLM识别到多个方案需要权衡 → 主动提示"这里涉及成本/时间的权衡，你倾向于...？"
          └── 用户选择 → 进入决策对话（verdict节点）→ 调整规划方案

二级按钮（Secondary Actions）— 辅助功能，不触发推理
  ├── 文档上传（📎）
  └── 图片上传（🖼）
```

**关键设计决策**：
- 取消当前的"推理/模板"分类切换机制，改为直接展示一级按钮
- 一级按钮直接映射到 Agent intent，不再依赖 LLM 二次解析
- 一级按钮点击后**直接发送**（不再仅填入输入框），因为意图已明确
- **决策不是一个独立按钮**，而是在分析/规划的自然流程中，由 LLM 识别决策点并主动询问用户
- 这样的好处：用户体验更顺畅（不中断流程），决策时机更精准（由LLM识别），可实现链式推理（分析→决策→规划的自然流程）

### 步骤 5：重新设计 QuickActionBar UI

**目标**：视觉上明确区分一级/二级按钮，简化决策流程

**UI 设计**：

```
一级按钮区域（左侧，视觉突出）：
[🎯 分析]  [📋 规划]                ← variant="secondary", h-8 px-3 text-sm

分隔线 |

二级按钮区域（右侧，视觉弱化）：
[📎 文档]  [🖼 图片]                ← variant="ghost", h-7 px-2 text-xs
```

**具体改动**：
- 一级按钮：`variant="secondary"`, `size="default"`, `h-8 px-3 text-sm`，带描述 tooltip
  - "分析" → "全面分析当前情况，提出建议"
  - "规划" → "为目标制定执行计划和方案"
- 二级按钮：`variant="ghost"`, `size="sm"`, `h-7 px-2 text-xs`
- 移除分类切换按钮（推理/模板），因为一级按钮已经直接表达了意图
- 移除"决策"按钮，决策由 LLM 在对话过程中主动识别并询问
- 一级按钮点击后**直接发送**（不再仅填入输入框），因为意图已明确
- 二级按钮保持原有行为

### 步骤 6：修改 Agent 路由逻辑，支持显式意图 + 上下文决策

**目标**：让一级按钮的意图能直接传递到 Agent；在分析/规划中主动识别决策点并询问用户

**改动**：
- 修改 `QuickAction` 接口，增加 `intent` 字段（'analysis' | 'planning'）
- 修改 `ChatPanel.handleSend`，支持传递 `explicitIntent`
- 修改 API route，接收 `intent` 参数
- 修改 `intentionNode`，当已有显式意图时跳过 LLM 解析，直接使用显式意图
- 修改 `routeByIntent`：
  - `analysis` → retrieval → reasoning → [**新节点：决策点检测**] → response
  - `planning` → retrieval → reasoning → [**新节点：权衡点检测**] → response
- 新增 `decisionPointDetectionNode`，识别分析结果中的关键决策点，生成主动询问的 prompt
- 新增 `tradeoffDetectionNode`，识别规划中的权衡点（成本vs效率、时间vs质量等），生成选择题
- 修改 `responseNode`，输出结构化数据而非纯文本
- 修改 `state.ts`，增加 `conversationContext` 字段以支持决策点识别

### 步骤 7：新增决策点/权衡点自动识别与询问逻辑

**目标**：在分析/规划过程中，由 LLM 自动识别关键决策点和权衡点，生成结构化的用户询问

**新增两个节点**：

**a) decisionPointDetectionNode**
- 输入：分析结果（evidence chain + reasoning + initial verdict）
- 逻辑：
  ```
  使用 prompt 分析："分析结果中是否包含需要用户做决策的关键点？"
  返回结构：{
    hasDecisionPoint: boolean
    decision?: {
      type: "task_prioritization" | "resource_allocation" | "risk_acceptance" | ...
      description: string         // "根据分析，你需要决策：X还是Y？"
      options: Array<{
        label: string
        reason: string
        impact: string
      }>
    }
  }
  ```
- 输出：若检测到决策点，返回询问；否则直接进入 response

**b) tradeoffDetectionNode**
- 输入：规划结果（multiple plans with cost/time/quality tradeoffs）
- 逻辑：
  ```
  使用 prompt 分析："规划中是否包含需要权衡的多个方案？"
  返回结构：{
    hasTradeoff: boolean
    tradeoff?: {
      dimension: "cost_vs_time" | "cost_vs_quality" | "safety_vs_efficiency" | ...
      plans: Array<{
        planId: string
        name: string
        cost: number
        time: number
        quality: number
        description: string
      }>
      question: string            // "你更倾向于降低成本还是加快进度？"
    }
  }
  ```
- 输出：若检测到权衡点，返回选择题；否则直接进入 response

**路由修改**：

```typescript
// 新的路由逻辑
routeByIntent: {
  'analysis': 'retrieval',
  'planning': 'retrieval'
}

// 新的条件路由（在 reasoning 之后）
routeByAnalysisType: {
  'analysis' → 'decisionPointDetection' → (hasDecisionPoint ? 持续对话 : 'response')
  'planning' → 'tradeoffDetection' → (hasTradeoff ? 持续对话 : 'response')
}

// 当用户在决策/权衡询问后回复时
'decisionPointDetection' + userChoice → 'verdictNode' → 'response'
'tradeoffDetection' + userChoice → 'verdictNode' → 'response'
```

### 步骤 8：实现证据链节点的放大细节探索

**目标**：用户可以点击任何证据、推理步骤，展开查看完整细节

**这是最核心的创新点 — 历史上没有人做过**

**UI 交互设计**：

```
┌─────────────────────────────────────────────────────────────┐
│  AI 回复（结构化渲染）                                       │
│                                                              │
│  📋 结论：建议优先推进收割机维修任务                          │
│                                                              │
│  🔗 证据链（3条）                          [展开全部]        │
│  ├── [E1] 项目计划书 — deadline 3月底    [▸ 详情]           │
│  ├── [E2] 任务T1状态 — blocked          [▸ 详情]           │
│  └── [E3] 成本分析 — 日损5000元          [▸ 详情]           │
│                                                              │
│  🧠 推理路径（3步）                        [展开全部]        │
│  ├── Step1: 证据整合 → 综合得分 0.765    [▸ 详情]           │
│  ├── Step2: 假设验证 → 时间窗口足够      [▸ 详情]           │
│  └── Step3: 路径推导 → 延误成本计算      [▸ 详情]           │
│                                                              │
│  📊 置信度：78%                            [▸ 分解]          │
│  ├── 基础置信度：85%                                         │
│  ├── 可靠性折扣：-5%                                         │
│  └── 冲突折扣：-2%                                           │
│                                                              │
│  ⚠️ 风险提示（2项）                                          │
│  ├── [MEDIUM] 维修延期1天 (概率20%)       [▸ 详情]           │
│  └── [LOW] 备用设备不可用 (概率10%)       [▸ 详情]           │
└─────────────────────────────────────────────────────────────┘
```

**点击 [▸ 详情] 后展开**：

```
┌─────────────────────────────────────────────────────────────┐
│  [E1] 证据详情                                    [收起]    │
│                                                              │
│  来源：项目计划书_v3.md                                      │
│  类型：deadline                                              │
│  内容：葡萄园项目需要在3月底前完成收割，否则产值下降30%       │
│  可靠性：0.9 ██████████░                                     │
│  关联性：0.95 ██████████                                     │
│  时效性：有效（截止 2026-03-31）                             │
│  权重贡献：25%                                               │
│                                                              │
│  [查看原始文档]  [调整权重]  [排除此证据重新推理]            │
└─────────────────────────────────────────────────────────────┘
```

**操作**：
- 创建 `src/components/chat/structured-response-renderer.tsx` — 结构化回复渲染器
- 创建 `src/components/chat/evidence-chain-panel.tsx` — 证据链可展开面板
- 创建 `src/components/chat/reasoning-path-panel.tsx` — 推理路径可展开面板
- 创建 `src/components/chat/confidence-breakdown.tsx` — 置信度分解组件
- 创建 `src/components/chat/risk-detail-panel.tsx` — 风险详情面板
- 修改 `src/components/chat/chat-container.tsx` — 使用结构化渲染器替代纯文本

### 步骤 9：修正架构文档

**目标**：让架构文档准确反映实际实现，并补充所有新增体系

**改动**：
- 修正 7.4 节路由逻辑，与实际代码一致
- 修正 routeByVerdictType 描述
- 补充"按钮层级与 Agent 流程映射"章节（分析/规划，决策是上下文触发）
- 补充"结构化 Prompt 模板体系"章节
- 补充"结构化输出体系"章节
- 补充"链路级可审计追踪"章节
- 补充"证据链放大细节探索"章节
- 补充"决策点/权衡点自动识别"章节（新增功能）
- 补充 prompts 目录结构说明
- 补充显式意图传递机制说明
- 修正 7.3 节节点实现代码示例

---

## 文件变更清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/agents/prompts/types.ts` | 新建 | PromptTemplate 接口 + input/output schema 定义 |
| `src/agents/prompts/intention.ts` | 新建 | 结构化意图解析 prompt |
| `src/agents/prompts/reasoning.ts` | 新建 | 结构化推理 prompt |
| `src/agents/prompts/decision-point-detection.ts` | 新建 | 决策点识别 prompt |
| `src/agents/prompts/tradeoff-detection.ts` | 新建 | 权衡点识别 prompt |
| `src/agents/prompts/verdict.ts` | 新建 | 结构化裁决 prompt |
| `src/agents/prompts/response.ts` | 新建 | 结构化回复生成 prompt |
| `src/agents/prompts/index.ts` | 新建 | 统一导出 |
| `src/agents/types/structured-output.ts` | 新建 | 结构化输出类型定义 |
| `src/agents/types/index.ts` | 新建 | 类型统一导出 |
| `src/lib/agent-chain-tracer.ts` | 新建 | 链路追踪器实现 |
| `src/components/chat/structured-response-renderer.tsx` | 新建 | 结构化回复渲染器 |
| `src/components/chat/evidence-chain-panel.tsx` | 新建 | 证据链可展开面板 |
| `src/components/chat/reasoning-path-panel.tsx` | 新建 | 推理路径可展开面板 |
| `src/components/chat/confidence-breakdown.tsx` | 新建 | 置信度分解组件 |
| `src/components/chat/risk-detail-panel.tsx` | 新建 | 风险详情面板 |
| `src/agents/nodes/intention.ts` | 修改 | 改为从 prompts 导入 + 支持显式意图 |
| `src/agents/nodes/reasoning.ts` | 修改 | 改为从 prompts 导入 + 输出结构化数据 |
| `src/agents/nodes/verdict.ts` | 修改 | 改为从 prompts 导入 + 输出结构化数据 |
| `src/agents/nodes/response.ts` | 修改 | 改为从 prompts 导入 + 输出结构化数据 |
| `src/agents/nodes/retrieval.ts` | 修改 | 输出结构化证据链 |
| `src/agents/nodes/decision-point-detection.ts` | 新建 | 分析中的决策点自动识别 |
| `src/agents/nodes/tradeoff-detection.ts` | 新建 | 规划中的权衡点自动识别 |
| `src/agents/edges/conditional.ts` | 修改 | 新增 routeByAnalysisType：检测后的路由逻辑 |
| `src/agents/state.ts` | 修改 | 增加 explicitIntent + structuredResponse + conversationContext 字段 |
| `src/agents/index.ts` | 修改 | 集成链路追踪 |
| `src/components/chat/quick-action-bar.tsx` | 修改 | 重构为一级/二级按钮体系 |
| `src/components/chat/chat-container.tsx` | 修改 | 适配结构化渲染 + 新按钮回调 |
| `src/components/chat/chat-panel.tsx` | 修改 | 支持显式意图传递 + 结构化响应处理 |
| `src/app/api/agent/chat/route.ts` | 修改 | 接收 intent 参数 + 返回结构化数据 + traceId |
| `.qoder/documents/团队协同智能体_技术架构.md` | 修改 | 全面修正 + 补充新体系 |

---

## 实施优先级

1. **步骤 1** — 结构化 Prompt 模板（基础设施，后续步骤依赖）
2. **步骤 2** — 结构化输出类型定义（基础设施，后续步骤依赖）
3. **步骤 3** — 链路级可审计追踪（基础设施，后续步骤依赖）
4. **步骤 4** — 按钮层级定义（语义模型）
5. **步骤 5** — QuickActionBar UI 重设计（用户可见）
6. **步骤 6** — Agent 路由修改 + 显式意图（核心逻辑）
7. **步骤 7** — 决策点/权衡点自动识别（核心功能，提升用户体验）
8. **步骤 8** — 证据链放大细节探索
9. **步骤 9** — 架构文档修正（收尾）
