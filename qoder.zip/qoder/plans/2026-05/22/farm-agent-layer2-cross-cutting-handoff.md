# farm-agent-layer2-cross-cutting-handoff

## Handoff 元信息

- 交接时间: 2026-05-29T09:00:00.000Z
- 思想来源: milktea 在 Node RuoYi 项目中首次证明了"Layer 2 运行时审计可以完全自动记录"（Express 中间件覆盖 `res.json()` 自动写入审计日志）
- 本次任务: 在 farm-agent Next.js 架构上独立实现函数级横切关注点（高阶函数包装器），延续"自动记录"洞见，适配不同的技术栈
- 关联文档:
  - Plan: `.qoder/plans/farm-agent-layer2-cross-cutting-plan-v1.md`
  - Review: `.qoder/reviews/farm-agent-layer2-cross-cutting-review-v1.md`
  - Spec: `.qoder/specs/farm-agent-layer2-cross-cutting/spec.md`
  - Tasks: `.qoder/specs/farm-agent-layer2-cross-cutting/tasks.md`
  - Checklist: `.qoder/specs/farm-agent-layer2-cross-cutting/checklist.md`

---

## 1. 交接前状态

### 1.1 代码分布

| 文件 | 状态 |
|------|------|
| `src/app/api/knowledge/upload/route.ts` | POST 有 Layer 1 dev-logger（audit-logger.ts），无 Layer 2 AuditLog 写入 |
| `src/app/api/knowledge/documents/[id]/route.ts` | DELETE 完全无审计 |
| `src/app/api/knowledge/sync/route.ts` | POST 返回 SSE stream，完全无审计 |
| `src/lib/audit-logger.ts` | Layer 1 dev-logger，仅 console + file，无 DB 写入 |
| `src/lib/agent-audit-logger.ts` | Layer 1 + Layer 2 混合，有 `writeAuditLog()` 但仅限 Agent 域 |
| `src/middlewares/audit.js` | milktea 的 Express 中间件（CommonJS），在当前 Next.js 项目中不可运行 |
| `prisma/schema.prisma` | `AuditLog` 表已存在，userId/action/targetType/targetId/traceId/detail 字段齐全 |

### 1.2 已知问题

- 知识库 API Route（upload/delete/sync）不具备 Layer 2 运行时审计能力
- milktea 的 Express 中间件代码证实了"自动记录"可能性，但本身是 HTTP 过滤器（绑定 req/res 管线、CommonJS），在 Next.js 上无法运行也不应直接移植
- 现有 Agent 域的 `writeAuditLog()` 不适用于知识库域

---

## 2. 交接后状态（目标）

### 2.1 文件布局

```
src/lib/
├── layer2-audit-wrapper.ts    ← 新建：withRuntimeAudit() 通用包装器
├── layer2-path-registry.ts    ← 新建：PATH_TARGET_MAP + SKIP_PATHS
├── layer2-sanitize.ts         ← 新建：sanitizeSensitiveFields() 脱敏
├── audit-logger.ts            ← 保持不变（Layer 1）
├── agent-audit-logger.ts      ← 保持不变（Layer 1+2，Agent 域专用）
└── ...

src/app/api/knowledge/
├── upload/route.ts            ← 修改：POST 用 withRuntimeAudit 包装
├── documents/[id]/route.ts    ← 修改：DELETE 用 withRuntimeAudit 包装
├── sync/route.ts              ← 修改：POST 用 withRuntimeAudit 包装（SSE 特殊处理）
└── ...

src/middlewares/
├── audit.js                   ← milktea 原始实现，保留作为"可能性证明"参考，不执行
└── ...
```

### 2.2 数据流

```
API Route                     Layer 1 (dev-logger)              Layer 2 (AuditLog)
─────────                     ─────────────────────              ──────────────────

withRuntimeAudit(config)      ← 继承 milktea "自动记录"洞见
  └─ handler(req)               但实现为函数级横切
       └─ auditPhaseStart()  → console + file                   (dev only)
       └─ businessLogic()                                      
       └─ auditPhaseEnd()    → console + file                   (dev only)
       └─ return NextResponse
  └─ clone response                                             
  └─ read body                                                 
  └─ prisma.auditLog.create() →                                ✅ AuditLog 表
                                                               (随时可查)
```

---

## 3. 改动清单

| # | 文件 | 操作 | 说明 |
|---|------|------|------|
| 1 | `src/lib/layer2-sanitize.ts` | CREATE | 脱敏工具函数 |
| 2 | `src/lib/layer2-path-registry.ts` | CREATE | 路径→业务域注册表 |
| 3 | `src/lib/layer2-audit-wrapper.ts` | CREATE | 核心：`withRuntimeAudit()` 包装器 |
| 4 | `src/app/api/knowledge/upload/route.ts` | MODIFY | POST 从 `export async function` 改为 `export const POST = withRuntimeAudit({...}, async ...)` |
| 5 | `src/app/api/knowledge/documents/[id]/route.ts` | MODIFY | DELETE 用 `withRuntimeAudit` 包装 |
| 6 | `src/app/api/knowledge/sync/route.ts` | MODIFY | POST 用 `withRuntimeAudit` 包装（SSE 兼容） |

---

## 4. 回滚方案

### 4.1 代码回滚

```bash
# 删除新建文件
rm src/lib/layer2-audit-wrapper.ts
rm src/lib/layer2-path-registry.ts
rm src/lib/layer2-sanitize.ts

# 恢复改动的 Route 文件（git revert 或手动改回 export async function）
git checkout -- src/app/api/knowledge/upload/route.ts
git checkout -- src/app/api/knowledge/documents/\[id\]/route.ts
git checkout -- src/app/api/knowledge/sync/route.ts
```

### 4.2 数据回滚

```sql
-- 删除本轮产生的 AuditLog 记录
DELETE FROM "AuditLog" WHERE "action" LIKE 'DOCUMENT_%';
DELETE FROM "AuditLog" WHERE "action" LIKE 'KNOWLEDGE_SYNC_%';
```

---

## 5. 执行前置检查

- [ ] 数据库正在运行（`docker compose ps` 确认）
- [ ] `npx tsc --noEmit` 当前通过
- [ ] milktea 中间件代码已阅读并理解其核心洞见（`src/middlewares/audit.js`）——**理解的是"为什么能自动记录"，而非"代码怎么跑"**
- [ ] `prisma/schema.prisma` 中 `AuditLog` 模型存在且已迁移
- [ ] 理解 `response.clone()` 机制：克隆后原始响应不受影响

---

## 6. 执行步骤摘要

```
Task 1 (脱敏) ──┐
                │ 可并行
Task 2 (注册表) ─┘
                │
                ▼
            Task 3 (包装器)  ← 核心文件，依赖 1+2
                │
                ▼
        Task 4/5/6 (改造 Route)  ← 3 个 Route 可并行
                │
                ▼
            Task 7 (编译检查)
```

**推荐试点顺序**：先做 Task 4（upload POST）→ 验证 `query_audit_logs` → 再做 Task 5/6

---

## 7. 关键风险点

| 风险 | 概率 | 影响 | 缓解 |
|------|------|------|------|
| `response.clone().json()` 在 SSE 场景失败 | 高 | 中 | Task 6 判断 Content-Type，非 JSON 跳过 body 读取 |
| 包装器影响 TypeScript 类型推断 | 低 | 中 | 使用泛型约束 |
| 克隆大响应体内存开销 | 低 | 低 | Phase 1 仅拦截知识库域，JSON 响应体通常 < 100KB |
| `prisma.auditLog.create()` 异步写入丢失 | 低 | 低 | `.catch(err => console.error)` 兜底，不抛异常 |
| 包装器改变了模块导出方式 | 低 | 高 | Next.js 兼容 `export const` 和 `export async function` |

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

### 8.1 总体一键恢复

```
query_audit_logs({ keyword: "layer2-cross-cutting" })
query_audit_logs({ targetType: "DOCUMENT" })
query_audit_logs({ targetType: "KNOWLEDGE_SYNC" })
```

### 8.2 逐任务审计查询

| 任务 | query_audit_logs 调用 | 预期命中 |
|------|----------------------|---------|
| Task 3: 创建包装器 | `query_audit_logs({ targetType: "COMPONENT", keyword: "layer2-audit-wrapper" })` | action=COMPONENT_CREATED |
| Task 4: upload Route | `query_audit_logs({ targetType: "API_ROUTE", keyword: "upload" })` | action=API_ENDPOINT_MODIFIED |
| Task 5: documents delete | `query_audit_logs({ targetType: "API_ROUTE", keyword: "documents" })` | action=API_ENDPOINT_MODIFIED |
| Task 6: sync Route | `query_audit_logs({ targetType: "API_ROUTE", keyword: "sync" })` | action=API_ENDPOINT_MODIFIED |
| 运行时验证 | `query_audit_logs({ targetType: "DOCUMENT" })` | DOCUMENT_CREATE / DOCUMENT_DELETE |
| 运行时验证 | `query_audit_logs({ targetType: "KNOWLEDGE_SYNC" })` | KNOWLEDGE_SYNC_CREATE |

### 8.3 SQL 直接查询（管理员验证）

```sql
-- 验证包装器文件已创建
SELECT * FROM "AuditLog" WHERE "targetType" = 'COMPONENT' AND "action" LIKE '%layer2%' ORDER BY "createdAt" DESC;

-- 验证 Route 已改造
SELECT * FROM "AuditLog" WHERE "targetType" = 'API_ROUTE' AND "action" = 'API_ENDPOINT_MODIFIED' ORDER BY "createdAt" DESC;

-- 验证运行时审计记录
SELECT * FROM "AuditLog" WHERE "targetType" IN ('DOCUMENT', 'KNOWLEDGE_SYNC') ORDER BY "createdAt" DESC LIMIT 20;
```

### 8.4 恢复判定标准

| 判定项 | 方法 | 通过标准 |
|--------|------|---------|
| 包装器文件存在 | `grep` | `ls src/lib/layer2-audit-wrapper.ts` 有输出 |
| 包装器文件存在 | `grep` | `ls src/lib/layer2-path-registry.ts` 有输出 |
| upload Route 已改造 | `grep "withRuntimeAudit" src/app/api/knowledge/upload/route.ts` | 有输出 |
| documents Route 已改造 | `grep "withRuntimeAudit" src/app/api/knowledge/documents/\[id\]/route.ts` | 有输出 |
| 编译通过 | `npx tsc --noEmit` | 无错误 |
| Layer 2 审计生效 | `query_audit_logs({ targetType: "DOCUMENT" })` | 返回 DOCUMENT_CREATE/DELETE 记录 |

---

## 9. 后置确认

- [ ] `npx tsc --noEmit` 编译通过
- [ ] 上传文档后 `query_audit_logs({ targetType: "DOCUMENT" })` 返回 DOCUMENT_CREATE 记录
- [ ] 删除文档后 `query_audit_logs({ targetType: "DOCUMENT" })` 返回 DOCUMENT_DELETE 记录
- [ ] 触发同步后 `query_audit_logs({ targetType: "KNOWLEDGE_SYNC" })` 返回记录
- [ ] 登录请求不产生 AuditLog（SKIP_PATHS 生效）
- [ ] 失败路径：模拟异常后 AuditLog 有 `_FAILED` 后缀记录
- [ ] `query_audit_logs({ keyword: "layer2-cross-cutting" })` MCP 查询可恢复完整上下文
