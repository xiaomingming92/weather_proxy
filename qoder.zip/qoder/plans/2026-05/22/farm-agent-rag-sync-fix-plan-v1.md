# RAG 同步修复计划（farm-agent 移植）

## PLAN 元信息

- **Plan 名称**: farm-agent-rag-sync-fix-v1
- **启动时间**: 2026-05-28T10:00:00+08:00
- **主导 AI**: Trae AI
- **父 Plan**: co-agent-rag-sync-fix-v1（参考实现）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| plan + spec 三件套 | DOC | DOC_CREATED | 无 plan/spec | .qoder/plans/ + .qoder/specs/ 三件套 | 待记录 |
| podman-compose.yml | CONFIG | CONFIG_MODIFIED | team-coordinator-* 容器名 + team_* 凭证 | farm-agent-* 容器名 + farm_* 凭证 + 端口隔离 | 待记录 |
| .env.development | CONFIG | CONFIG_MODIFIED | team_* DATABASE_URL + team-coordinator CHROMA_AUTH_TOKEN | farm_* DATABASE_URL:5433 + farm-agent CHROMA_AUTH_TOKEN | 待记录 |
| document-parser.ts | COMPONENT | COMPONENT_REFACTOR | require("pdf-parse") + parseImage空内容 + parseCsv JSON + parseDocumentFromBuffer csv JSON | import pdfjs-dist + skipVectorize标记 + 可读文本 | 待记录 |
| document-indexer.ts | COMPONENT | COMPONENT_REFACTOR | 硬编码 text-embedding-3-small + 无分块 + 硬编码 COLLECTION_NAME | getEmbeddings() + RecursiveCharacterTextSplitter + CHROMA_COLLECTION env | 待记录 |
| chroma.ts | COMPONENT | COMPONENT_REFACTOR | 硬编码 text-embedding-3-small | getEmbeddings() | 待记录 |
| knowledge-sync.ts | COMPONENT | COMPONENT_REFACTOR | parseDocument + fs.readFile 双重读盘 + 无 skipVectorize 检查 | parseDocumentFromBuffer 一次读盘 + skipVectorize 检查 | 待记录 |
| package.json | DEPENDENCY | DEPENDENCY_REPLACED | pdf-parse | pdfjs-dist | 待记录 |

---

## 背景

farm-agent 的 RAG 代码是从 co-agent 早期版本 fork 的，存在与 [co-agent-rag-sync-fix-plan-v1.md](file:///home/xmm/ai/co-agent/.qoder/plans/co-agent-rag-sync-fix-plan-v1.md) 相同的问题。co-agent 已完成修复，farm-agent 需要移植相同修复。

同时，farm-agent 和 co-agent 共用同一台机器运行，需要容器名和端口隔离避免冲突。

## 架构约束（不可破坏）

静态文档（PROJECT_DOC）和用户上传文档（KNOWLEDGE_UPDATE）是**两套独立的索引系统**。

## 修复步骤

### Step 1: 基础设施隔离（容器名 + 凭证 + 端口）

- podman-compose.yml: 容器名 `team-coordinator-*` → `farm-agent-*`
- Postgres 端口从 5432 → 5433（避免与 co-agent 冲突）
- 凭证从 `team_*` → `farm_*`
- CHROMA_AUTH_TOKEN 更新
- .env.development DATABASE_URL 端口和凭证同步更新

### Step 2: 修复 `document-parser.ts`

**2a. 替换 `pdf-parse` → `pdfjs-dist`**
- `npm uninstall pdf-parse && npm install pdfjs-dist`
- 移除 `const pdfParse = require("pdf-parse")`
- 改用 `import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs"`
- 改写 `parsePdf()` 和 `parseDocumentFromBuffer()` 中的 pdf 分支

**2b. 修复 `parseImage()`**
- 设置 `metadata.skipVectorize = true`
- 调用方检查此标记后跳过向量化

**2c. 修复 `parseCsv()`**
- `parseDocument()` 和 `parseDocumentFromBuffer()` 中的 csv 分支都改为可读文本格式

### Step 3: 修复 `document-indexer.ts`

- 硬编码 `OpenAIEmbeddings({ model: "text-embedding-3-small" })` → `getEmbeddings()`
- 硬编码 `COLLECTION_NAME = "team-coordinator-docs"` → `CHROMA_COLLECTION` env 变量
- `chroma.addDocuments([doc])`（无分块）→ `RecursiveCharacterTextSplitter` + 逐块写入
- 引入 `RecursiveCharacterTextSplitter`（与 knowledge-indexer.ts 相同参数）

### Step 4: 修复 `chroma.ts`

- 硬编码 `text-embedding-3-small` → `getEmbeddings()`

### Step 5: 修复 `knowledge-sync.ts`

- 修改文件处理：`parseDocument(file.absolutePath)` 改为 `parseDocumentFromBuffer(buffer, ...)`
- 先读 buffer 一次，同时用于解析和向量化
- 新增文件处理：同样改为 buffer 复用
- 检查 `parsed.metadata.skipVectorize`，为 true 时跳过向量化

### Step 6: 验证

1. `npx tsc --noEmit` — 零错误
2. `grep -r "require.*pdf-parse" src/` — 返回空
3. `grep -r "text-embedding-3-small" src/` — 返回空
4. `grep -r "new OpenAIEmbeddings" src/` — 只在 `embeddings/index.ts` 中出现
