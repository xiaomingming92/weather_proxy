# ChromaDB 导入导出客户端统一计划（farm-agent 移植）

## PLAN 元信息

- **Plan 名称**: farm-agent-kb-export-unify-client-v1
- **启动时间**: 2026-05-28T10:30:00+08:00
- **主导 AI**: Trae AI
- **父 Plan**: co-agent-kb-export-unify-client-v1（参考实现）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| plan + spec 三件套 | DOC | DOC_CREATED | 无 plan/spec | .qoder/plans/ + .qoder/specs/ 三件套 | 待记录 |
| scripts/kb-export.ts | COMPONENT | COMPONENT_REFACTOR | LangChain Chroma + 硬编码 text-embedding-3-small + v1 无 embeddings | DirectChromaClient + v2 含 embeddings | 待记录 |
| scripts/kb-import.ts | COMPONENT | COMPONENT_REFACTOR | LangChain Chroma + re-embed | DirectChromaClient + 直接写入预计算 embeddings | 待记录 |
| src/lib/chroma-client.ts | COMPONENT | COMPONENT_CREATED | DirectChromaClient 内嵌在 knowledge-indexer.ts + chroma-direct-client.ts | 提取为独立共享模块 | 待记录 |
| src/services/knowledge-indexer.ts | COMPONENT | COMPONENT_REFACTOR | 内联 DirectChromaClient（无 get()） | 从 @/lib/chroma-client 导入（含 get()） | 待记录 |

---

## 背景

farm-agent 的 `knowledge-indexer.ts` 已经有内联 `DirectChromaClient`，但 `kb-export.ts` 和 `kb-import.ts` 仍使用 LangChain Chroma 封装 + 硬编码 `text-embedding-3-small`。需要将 co-agent 的 [co-agent-kb-export-unify-client-v1](file:///home/xmm/ai/co-agent/.qoder/plans/co-agent-kb-export-unify-client-plan-v1.md) 改造移植过来。

## 问题诊断

| 组件 | 客户端 | 问题 |
|------|--------|------|
| `knowledge-indexer.ts` | **DirectChromaClient**（内联） | 功能正常，但无 `get()` 方法 |
| `scripts/kb-export.ts` | **LangChain Chroma** | `similaritySearchVectorWithScore` 变通导出 + 硬编码嵌入模型 |
| `scripts/kb-import.ts` | **LangChain Chroma** | `addDocuments()` 强制重新 embedding |

farm-agent 还存在 `chroma-direct-client.ts`（另一个 DirectChromaClient 副本），两个内联实现需要统一。

## 修复方案

### Step 1: 创建 `src/lib/chroma-client.ts` 共享模块

从 co-agent 移植 `DirectChromaClient`（含 `get()` 方法），作为独立共享模块：
- 不依赖 `@/` 路径别名，只依赖标准库和 `fetch`
- `scripts/` 目录下的 `tsx` 脚本通过相对路径导入

### Step 2: 重写 `kb-export.ts`

参考 co-agent 的 [kb-export.ts](file:///home/xmm/ai/co-agent/scripts/kb-export.ts)：
- 移除 LangChain 依赖
- 使用 `DirectChromaClient.get()` 分页拉取全量向量（含 embeddings）
- 导出格式升级为 v2（`embeddingModel` + `embeddingDim` + `embeddings`）

### Step 3: 重写 `kb-import.ts`

参考 co-agent 的 [kb-import.ts](file:///home/xmm/ai/co-agent/scripts/kb-import.ts)：
- 移除 LangChain 依赖
- 使用 `DirectChromaClient.add()` 直接写入预计算 embeddings
- v1 兼容 fallback（重新嵌入）

### Step 4: 重构 `knowledge-indexer.ts`
- 内联 `DirectChromaClient` → `import { DirectChromaClient } from "@/lib/chroma-client"`
- `searchKnowledgeDocuments()` 增强（参照 co-agent 版本）

### Step 5: 清理 `chroma-direct-client.ts`
- 确认调用方后决定：合并到 chroma-client.ts 或删除

### Step 6: 验证

1. `npx tsc --noEmit` 零错误
2. `grep -r "langchain/community/vectorstores/chroma" scripts/` 返回空
3. `npm run kb:export` 导出成功，含 embeddings 数组
4. `npm run kb:import` 导入成功
