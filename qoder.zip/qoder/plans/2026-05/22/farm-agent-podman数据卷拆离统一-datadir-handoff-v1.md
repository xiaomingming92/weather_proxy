# HANDOFF：farm-agent Podman 数据卷拆离 — 轮间交接手册

> 关联 Plan: `farm-agent-podman数据卷拆离统一-datadir-plan-v1.md`
> 关联 Execution: `farm-agent-podman数据卷拆离统一-datadir-execution-v1.md`
> 参考 precedent: co-agent 已完成同类改造（`co-agent-podman数据卷拆离统一-datadir-v1`）

---

## 1. 交接前状态

### 1.1 当前数据布局

```
~/farm-agent/
├── data/                          ← ⚠️ 容器挂载点（项目内）
│   ├── postgres/    (owner: 容器用户)
│   └── chroma/      (owner: 容器用户)
├── podman-compose.yml             ← volumes 硬编码: ./data/postgres, ./data/chroma
├── docker-compose.yml             ← ⚠️ co-agent 遗留副本（team-coordinator 命名 + 旧 Chroma 0.4.24）
├── scripts/db-ensure.sh           ← ⚠️ 引用 team-coordinator-postgres/chroma, team_admin, team_coordinator, team-coordinator-secret-token-2026
├── scripts/db-ensure.bat          ← ⚠️ 同上
├── scripts/start-db.sh            ← ⚠️ 引用 team-coordinator-postgres + mkdir -p data/postgres
├── scripts/start-db.bat           ← ⚠️ 同上
├── scripts/stop-db.sh             ← ⚠️ 引用 team-coordinator-postgres, team-coordinator-chroma
├── scripts/stop-db.bat            ← ⚠️ 同上
├── scripts/start-infrastructure.sh ← ⚠️ 引用 chroma collection team_coordinator + token team-coordinator-secret-token-2026
├── scripts/db-status.sh           ← ⚠️ 引用 team-coordinator-postgres
└── scripts/db-wait.sh             ← ⚠️ 引用 team-coordinator-postgres

$HOME/data/farm-agent/            ← ❌ 不存在（尚未创建）
```

### 1.2 问题

1. **podman-compose.yml 使用项目内路径** `./data/`，未采用 co-agent 已实现的 `${DATA_DIR}` 模式
2. **docker-compose.yml 是 co-agent 遗留副本**，全部使用 team-coordinator 命名 + 旧 Chroma 0.4.24 + 旧 auth API，与 farm-agent 的 podman-compose.yml 不一致
3. **全部 9 个脚本引用 co-agent 容器名/凭据**（25 处引用），而非 farm-agent 对应名称
4. **凭据未完全隔离**：db-ensure.sh 硬编码 `team-coordinator-secret-token-2026` 作为 chroma fallback token
5. **数据集未隔离**：项目内 `./data/` 和外部 `$HOME/data/farm-agent/` 两个位置都可能存在数据

### 1.3 与 co-agent 的数据隔离现状

| 项目 | 容器名 | 端口 | DB 名 | 用户 | 数据路径（目标） |
|------|--------|------|-------|------|----------------|
| co-agent | co-agent-postgres | 5432:5432 | team_coordinator | team_admin | `$HOME/data/co-agent/` |
| farm-agent | farm-agent-postgres | 5433:5432 | farm_agent | farm_admin | `$HOME/data/farm-agent/` |

两个项目共享**同一个 PostgreSQL 容器镜像**但使用**独立的容器实例、端口、数据库、数据目录**，天然隔离。

---

## 2. 交接后状态（目标）

### 2.1 数据布局

```
~/farm-agent/
├── data/                          ← ✅ chmod a+rX 保留历史，不再作为挂载点
│   ├── postgres/    (历史，仅可读)
│   └── chroma/      (历史，仅可读)
├── podman-compose.yml             ← volumes: ${DATA_DIR}/postgres, ${DATA_DIR}/chroma
├── docker-compose.yml             ← ✅ 全面 farm 化：容器名/DB/用户/密码/网络/Chroma 1.5.9/auth/端口全部对齐 podman-compose.yml
├── scripts/db-ensure.sh           ← 引用 farm-agent-postgres/chroma + DATA_DIR 动态推导 + chroma token/collection 修正
├── scripts/db-ensure.bat          ← 引用 farm-agent-postgres
├── scripts/start-db.sh            ← 引用 farm-agent-postgres + export DATA_DIR
├── scripts/start-db.bat           ← 引用 farm-agent-postgres
├── scripts/stop-db.sh             ← 引用 farm-agent-postgres, farm-agent-chroma
├── scripts/stop-db.bat            ← 引用 farm-agent-postgres, farm-agent-chroma
├── scripts/start-infrastructure.sh ← chroma collection farm_agent + ${CHROMA_AUTH_TOKEN} + 端口 5433/8001
├── scripts/db-status.sh           ← 引用 farm-agent-postgres + 端口 8001
└── scripts/db-wait.sh             ← 引用 farm-agent-postgres

$HOME/data/farm-agent/             ← 新数据目录（项目外）
├── postgres/        (活跃数据)
└── chroma/          (活跃数据)
```

### 2.2 各环境路径

| 环境 | 用户 | 数据路径 | 来源 |
|------|------|---------|------|
| 本地开发 | xmm | `/home/xmm/data/farm-agent/` | `$HOME` 自动推导 |
| 任何机器 | $USER | `/home/$USER/data/farm-agent/` | `$HOME` 自动推导 |

### 2.3 改动的文件（最终形态）

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `podman-compose.yml` | MODIFY | `volumes:` `./data/` → `${DATA_DIR}/` |
| 2 | `docker-compose.yml` | MODIFY | 全面 farm 化（容器名/DB/Chroma/端口） + `${DATA_DIR}` + `${POSTGRES_PASSWORD}`/`${CHROMA_AUTH_TOKEN}`（值见 `.env.development`/`.env.production`） |
| 3 | `db-ensure.sh` | MODIFY | 修正容器/chroma collection/token 引用（→ `${CHROMA_AUTH_TOKEN}`）+ 添加 `DATA_DIR` + CHROMA_PORT 8001 |
| 4 | `db-ensure.bat` | MODIFY | 修正容器/DB 引用 + CHROMA_PORT 8001 |
| 5 | `start-db.sh` | MODIFY | 修正容器/DB 引用 + 删除 `mkdir -p data/postgres` + 添加 `export DATA_DIR` + 端口 5433 |
| 6 | `start-db.bat` | MODIFY | 修正容器/DB 引用 + 删除 `mkdir data\postgres` + 端口 5433 |
| 7 | `stop-db.sh` | MODIFY | 修正容器引用 |
| 8 | `stop-db.bat` | MODIFY | 修正容器引用 |
| 9 | `start-infrastructure.sh` | MODIFY | 修正 chroma collection/token 引用（→ `${CHROMA_AUTH_TOKEN}`） + 端口 5433/8001 |
| 10 | `db-status.sh` | MODIFY | 修正容器引用 + 端口 8001 |
| 11 | `db-wait.sh` | MODIFY | 修正容器/DB 引用 |
| 12 | `podman-compose.yml` | MODIFY | 凭据 `${POSTGRES_PASSWORD}` / `${CHROMA_AUTH_TOKEN}` 化 |
| 13 | `docker-compose.yml` | MODIFY | 同上 |
| 14 | `.env.development` | CREATE | 新建，集中管理敏感凭据（已 gitignored） |
| 15 | `.env.production` | CREATE | 同上 |

**关键约束**: `/home/xmm/ai/farm-agent/data` 文件夹不可删除（与 co-agent 一致，保留为历史记录）

---

## 3. 回滚方案

### 3.1 回滚条件

- 本地容器启动失败，挂载路径不正确
- 数据丢失（数据应始终保留在 `$HOME/data/farm-agent/` 和 `./data/` 两处）
- `docker-compose.yml` 改造后 Docker 用户启动失败

### 3.2 代码回滚

```bash
cd ~/ai/farm-agent
git reset --hard <回滚到的 commit>
# 本地重新创建容器
podman stop farm-agent-postgres farm-agent-chroma
podman rm farm-agent-postgres farm-agent-chroma
podman-compose up -d   # 用旧版 compose（./data/ 路径）
```

### 3.3 数据回滚

```bash
# 数据安全：$HOME/data/farm-agent/ 和 ./data/ 两处都有数据
# 最坏情况：$HOME/data/farm-agent/ 清空了，从 ./data/ 恢复
cp -a ./data/postgres/* $HOME/data/farm-agent/postgres/
cp -a ./data/chroma/* $HOME/data/farm-agent/chroma/
```

### 3.4 回滚风险

- **低风险**：代码回滚仅影响 compose + 脚本文件，数据始终在磁盘上
- **回滚后验证**：`podman inspect` 确认挂载路径 + 服务 HTTP 200

---

## 4. 执行前置检查

- [ ] 本地无运行中的 farm-agent 容器（`podman ps --filter name=farm-agent` 为空）
- [ ] 本地无运行中的 co-agent 容器干扰（端口 5433 和 8001 未占用）
- [ ] Git 工作区干净（或已 stash）
- [ ] 已阅读 execution.md 全部 18 个任务
- [ ] 已阅读 plan.md Step 0-6

---

## 5. 执行步骤摘要（参考 execution.md）

```
Step 1-13: 代码修改（compose ×2 + 9 个脚本 + .env ×2）    —— 并行
Step 14-16: 本地文件系统（mkdir + cp + chmod）            —— 串行
Step 17:   本地验证（启动容器 + 服务访问）                  —— 取决于 1-16
Step 18:   提交推送                                         —— 取决于 17
```

---

## 6. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| `$HOME` 在非交互式脚本中未设置 | DATA_DIR 为空，compose 失败 | `${DATA_DIR:-$HOME/...}` 默认值 |
| Podman 容器重建时数据丢失 | 数据不可恢复 | 挂载路径指向已有数据目录，cp -a 保留原数据 |
| docker-compose.yml 改造遗漏 | Docker 用户启动失败 | 按 checklist 逐项对照验证 |
| `./data/` chmod 后新容器误用 | 容器挂载外部路径，不受影响 | `podman inspect` 确认挂载路径 |
| 旧容器名 team-coordinator-* 残留 | podman stop/rm 失败 | 手动清理：`podman rm -f team-coordinator-postgres team-coordinator-chroma` |
| ChromaDB 端口从 8000 改为 8001 | 脚本中 CHROMA_PORT 默认值与 compose 不一致 | 统一为 8001（与 podman-compose.yml 映射一致） |
| Chroma auth token 硬编码残留 | 启动失败或认证错误 | 全局 grep 确认无 `team-coordinator-secret-token-2026` 残留 |

---

## 7. 恢复上下文审计查询（新 AI Session 首次启动必读）

### 一键恢复（traceId 全量拉取）

```text
query_audit_logs({ traceId: "farm-podman-migration-20260529" })
```

返回全部 23 条操作记录，覆盖计划→代码变更→迁移→healthcheck→规范同步→MCP server 就绪。

### MCP 工具查询（推荐，AI 直接用）

```text
# 总体恢复
query_audit_logs({ traceId: "farm-podman-migration-20260529" })

# 按 action 分查
query_audit_logs({ keyword: "PLAN_CREATED" })                → 计划创建
query_audit_logs({ keyword: "CONFIG_PATH_VAR_FARM" })        → podman-compose.yml
query_audit_logs({ keyword: "CONFIG_DOCKER_FARM_NAMING" })   → docker-compose.yml
query_audit_logs({ keyword: "SCRIPT_FIX_CONTAINER_REF" })    → 9 个脚本
query_audit_logs({ keyword: "ENV_FILE_CREATED" })            → .env.development/.production
query_audit_logs({ keyword: "DATA_MIGRATE_FARM" })           → 数据库迁移
query_audit_logs({ keyword: "DB_MIGRATE_" })                 → 详细迁移步骤（11条）
query_audit_logs({ keyword: "CONFIG_HEALTHCHECK_FIX" })      → healthcheck 修复
query_audit_logs({ keyword: "RULE_ADD8_SYNCED" })            → ADD-8 规则同步
query_audit_logs({ keyword: "DB_PORT_RESTORED" })            → co-agent 5432 端口恢复
query_audit_logs({ keyword: "FARM_MCP_SERVER_READY" })       → MCP server 就绪
```

### SQL 直接查询（管理员/手动验证用）

```sql
-- farm-agent DB (localhost:5433, db=farm_agent, user=farm_admin)
SELECT action, "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE "traceId" = 'farm-podman-migration-20260529'
ORDER BY "createdAt" ASC;
```

全部 23 条 action：

```
PLAN_CREATED                 — 计划创建
CONFIG_PATH_VAR_FARM         — podman-compose.yml
CONFIG_DOCKER_FARM_NAMING    — docker-compose.yml
SCRIPT_FIX_CONTAINER_REF     — 9 scripts
ENV_FILE_CREATED             — .env 文件
DATA_MIGRATE_FARM            — 迁移概述
CONFIG_HEALTHCHECK_FIX       — healthcheck
RULE_ADD8_SYNCED             — ADD-8
DB_PORT_RESTORED             — co-agent 5432
FARM_MCP_SERVER_READY        — MCP server
DB_MIGRATE_CHMOD_LEGACY      — ./data/ 权限
DB_MIGRATE_COMPLETE          — 迁移汇总
DB_MIGRATE_PREREQ_CHECK      — 前置检查
DB_MIGRATE_STOP_CONTAINERS   — 停容器
DB_MIGRATE_COPY_PG           — PG 数据复制
DB_MIGRATE_COPY_CHROMA       — Chroma 检查
DB_MIGRATE_START_NEW_COMPOSE — 启动新 compose
DB_MIGRATE_VERIFY_MOUNTS     — 挂载验证
DB_MIGRATE_PRISMA_GENERATE   — prisma generate
DB_MIGRATE_PRISMA_BASELINE   — 6 迁移 baseline
DB_MIGRATE_PRISMA_DEPLOY     — prisma migrate deploy
DB_MIGRATE_TABLES_VERIFY     — 14 表验证
DB_MIGRATE_INIT_DB           — init-db
```

### 逐文件审计查询（新 AI Session 按文件定位）

```text
# compose 文件
query_audit_logs({ keyword: "CONFIG_PATH_VAR_FARM" })              → podman-compose.yml volumes
query_audit_logs({ keyword: "CONFIG_DOCKER_FARM_NAMING" })          → docker-compose.yml farm 化
query_audit_logs({ keyword: "ENV_FILE_CREATED" })                   → .env 凭据文件
query_audit_logs({ keyword: "CONFIG_HEALTHCHECK_FIX" })             → healthcheck 修复

# 9 个脚本
query_audit_logs({ keyword: "SCRIPT_FIX_CONTAINER_REF" })           → 全部脚本

# 数据库迁移（11 条详细步骤）
query_audit_logs({ keyword: "DB_MIGRATE_" })                        → 迁移全部步骤
query_audit_logs({ keyword: "DB_MIGRATE_PRISMA_BASELINE" })         → 6 迁移 baseline
query_audit_logs({ keyword: "DB_MIGRATE_START_NEW_COMPOSE" })      → 容器就绪状态

# 跨项目规范 + 基础设施
query_audit_logs({ keyword: "RULE_ADD8_SYNCED" })                   → ADD-8 三项目同步
query_audit_logs({ keyword: "DB_PORT_RESTORED" })                   → co-agent 5432 恢复
query_audit_logs({ keyword: "FARM_MCP_SERVER_READY" })              → farm-agent MCP 就绪
```

### 恢复判定标准

- `traceId: "farm-podman-migration-20260529"` 命中 23 条
- `DB_MIGRATE_COMPLETE` 的 afterState 包含 `"git_commits": ["c5c33ce", "507cc9c"]`
- `DB_MIGRATE_START_NEW_COMPOSE` 的 afterState 包含 `"postgres": "healthy"` + `"chroma": "healthy"`
- `grep -rn "team-coordinator\|team_admin\|team_coordinator" scripts/` 返回空（除 test-mcp-server.sh）
- `grep -rn "\.\/data" podman-compose.yml docker-compose.yml` 返回空
- `grep -rn '\${DATA_DIR}' podman-compose.yml docker-compose.yml` 存在 4 处
- `ls .env.development .env.production` 两个文件均存在且已 gitignored
- compose 文件中无硬编码凭据残留

---

## 8. 后置确认

- [ ] `ls -la ~/farm-agent/data/` 历史记录目录存在且可读
- [ ] `ls -la $HOME/data/farm-agent/` 新数据目录存在
- [ ] `podman inspect farm-agent-postgres` 挂载路径 = `/home/$USER/data/farm-agent/postgres`
- [ ] `podman inspect farm-agent-chroma` 挂载路径 = `/home/$USER/data/farm-agent/chroma`
- [ ] `.env.development` 和 `.env.production` 已创建，敏感凭据已填写
- [ ] compose 文件中无硬编码凭据残留
- [ ] `docker-compose.yml` 已全面 farm 化（`grep -rn "team-coordinator\|team_admin\|team_coordinator" docker-compose.yml` 返回空）
- [ ] `grep -rn "team-coordinator" scripts/` 返回空
- [ ] 服务 HTTP 200
