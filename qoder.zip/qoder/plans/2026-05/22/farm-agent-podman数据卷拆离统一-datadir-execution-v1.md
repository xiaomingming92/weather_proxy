# EXECUTION：farm-agent Podman 数据卷拆离 — 原子任务拆分

> 关联 Plan: `farm-agent-podman数据卷拆离统一-datadir-plan-v1.md`

## 任务拆分

### 任务 1：podman-compose.yml — 路径变量化

**目标**：`volumes` 从项目内相对路径改为 `${DATA_DIR}` 变量

**改动**：
```yaml
# before
volumes:
  - ./data/postgres:/var/lib/postgresql/data:Z
  - ./data/chroma:/chroma/chroma:Z

# after
volumes:
  - ${DATA_DIR}/postgres:/var/lib/postgresql/data:Z
  - ${DATA_DIR}/chroma:/chroma/chroma:Z
```

**验证**：`grep -n "\.\/data" podman-compose.yml` 返回空

---

### 任务 2：docker-compose.yml — 改造为 farm-agent 命名 + DATA_DIR

**目标**：docker-compose.yml 全面改造，与 podman-compose.yml 对齐，支持 Docker 用户

**改动清单**：

| 维度 | 当前（co-agent 遗留） | 改为（farm-agent） |
|------|----------------------|-------------------|
| 容器名 postgres | `team-coordinator-postgres` | `farm-agent-postgres` |
| 容器名 chroma | `team-coordinator-chroma` | `farm-agent-chroma` |
| 端口 postgres | `5432:5432` | `5433:5432` |
| 端口 chroma | `8000:8000` | `8001:8000` |
| 数据卷 postgres | `./data/postgres:/var/lib/postgresql/data` | `${DATA_DIR}/postgres:/var/lib/postgresql/data` |
| 数据卷 chroma | `./data/chroma:/chroma/chroma` | `${DATA_DIR}/chroma:/chroma/chroma` |
| DB 名 | `team_coordinator` | `farm_agent` |
| 用户 | `team_admin` | `farm_admin` |
| 密码 | 硬编码 `team_secure_pass_2024` | `${POSTGRES_PASSWORD}`（值见 `.env.development`/`.env.production`） |
| 网络 | `team-network` | `farm-agent-network` |
| Chroma 镜像 | `chromadb/chroma:0.4.24` | `chromadb/chroma:1.5.9` |
| Chroma auth provider | 旧 `TokenAuthServerProvider` | 新 `chromadb.auth.token_authn.TokenAuthnProvider` |
| Chroma auth token | 硬编码 | `${CHROMA_AUTH_TOKEN}`（值见 `.env.development`/`.env.production`） |
| Healthcheck 格式 | `CMD-SHELL` | `CMD`（与 podman-compose.yml 统一） |
| Volumes SELinux | 无 `:Z` | 保持无 `:Z`（Docker 不需要） |

**验证**：
```bash
grep -n "team-coordinator\|team_admin\|team_coordinator" docker-compose.yml  # 应返回空
grep -n "\.\/data" docker-compose.yml  # 应返回空
grep -n '${DATA_DIR}' docker-compose.yml  # 应存在 2 处（postgres + chroma）
```

---

### 任务 3：db-ensure.sh — 全面修正引用 + DATA_DIR 动态推导

**目标**：所有 co-agent 引用 → farm-agent 引用；添加 DATA_DIR 动态推导

**需要改的行**：

| 行号 | 当前 | 改为 |
|------|------|------|
| L26-27 | `team-coordinator-postgres` | `farm-agent-postgres` |
| L34 | `team-coordinator-postgres` `team_admin` `team_coordinator` | `farm-agent-postgres` `farm_admin` `farm_agent` |
| L47-48 | `team-coordinator-chroma` | `farm-agent-chroma` |
| L58 | `team-coordinator-chroma` | `farm-agent-chroma` |
| L75 | `team-coordinator-chroma` | `farm-agent-chroma` |
| L80 | 硬编码 chroma token（`team-coordinator-*-token`） | `${CHROMA_AUTH_TOKEN}` |
| L81 | 硬编码 chroma token（同上） | `${CHROMA_AUTH_TOKEN}` |
| L111 | `team_coordinator` (chroma collection) | `farm_agent` |

另外，在 `ENV_FILE` 加载后、容器检查前，添加：
```bash
DATA_DIR="${DATA_DIR:-$HOME/data/farm-agent}"
```

ChromaDB 端口引用也要修正：`CHROMA_PORT` 默认值 `8000` → `8001`（按 podman-compose.yml 端口映射）。

**验证**：
```bash
grep -n "team-coordinator\|team_admin\|team_coordinator" scripts/db-ensure.sh  # 应返回空
grep "DATA_DIR" scripts/db-ensure.sh  # 应存在
bash -n scripts/db-ensure.sh  # 语法检查通过
```

---

### 任务 4：db-ensure.bat — 修正容器引用

**目标**：修正所有 co-agent 引用为 farm-agent 命名

**需要改的行**：

| 行号 | 当前 | 改为 |
|------|------|------|
| L24 | `team-coordinator-postgres` | `farm-agent-postgres` |
| L34 | `team-coordinator-postgres` `team_admin` `team_coordinator` | `farm-agent-postgres` `farm_admin` `farm_agent` |

ChromaDB 端口：`CHROMA_PORT=8000` → `CHROMA_PORT=8001`

**验证**：
```bash
grep -n "team-coordinator\|team_admin\|team_coordinator" scripts/db-ensure.bat  # 应返回空
```

---

### 任务 5：start-db.sh — 修正引用 + export DATA_DIR + 删除 mkdir

**目标**：
1. 修正容器引用
2. 删除 L16 `mkdir -p data/postgres`（容器会在挂载点自动创建目录）
3. 在 compose up 前添加 `export DATA_DIR`

**改动**：

改动 1：L16 `mkdir -p "$PROJECT_DIR/data/postgres"` → 删除

改动 2：在 compose 调用前添加：
```bash
export DATA_DIR="${DATA_DIR:-$HOME/data/farm-agent}"
```

改动 3：L29 修改容器引用：
```bash
# before
until $CONTAINER_EXEC team-coordinator-postgres pg_isready -U team_admin -d team_coordinator 2>/dev/null; do

# after
until $CONTAINER_EXEC farm-agent-postgres pg_isready -U farm_admin -d farm_agent 2>/dev/null; do
```

改动 4：L37-40 输出信息修改：
```bash
echo "数据库名: farm_agent"
echo "用户名:   farm_admin"
```

改动 5：L37 端口号：`localhost:5432` → `localhost:5433`（按 podman-compose.yml）

**验证**：
```bash
grep 'export DATA_DIR' scripts/start-db.sh
grep -n 'mkdir -p data/postgres' scripts/start-db.sh  # 应返回空
grep -n "team-coordinator\|team_admin\|team_coordinator" scripts/start-db.sh  # 应返回空
bash -n scripts/start-db.sh
```

---

### 任务 6：start-db.bat — 修正容器引用

**目标**：修正所有 co-agent 引用

**需要改的行**：

| 行号 | 当前 | 改为 |
|------|------|------|
| L13 | `mkdir "%PROJECT_DIR%\data\postgres"` | 删除整行（与 start-db.sh 一致） |
| L25 | `team-coordinator-postgres` `team_admin` `team_coordinator` | `farm-agent-postgres` `farm_admin` `farm_agent` |
| L35-36 | 端口 `5432` / 数据库 `team_coordinator` / 用户 `team_admin` | 端口 `5433` / 数据库 `farm_agent` / 用户 `farm_admin` |

**验证**：
```bash
grep -n "team-coordinator\|team_admin\|team_coordinator" scripts/start-db.bat  # 应返回空
```

---

### 任务 7：stop-db.sh — 修正容器引用

**目标**：`team-coordinator-postgres` → `farm-agent-postgres`，`team-coordinator-chroma` → `farm-agent-chroma`

**改动**：L19-20

```bash
# before
$CONTAINER_RUNTIME stop team-coordinator-postgres team-coordinator-chroma 2>/dev/null || true
$CONTAINER_RUNTIME rm team-coordinator-postgres team-coordinator-chroma 2>/dev/null || true

# after
$CONTAINER_RUNTIME stop farm-agent-postgres farm-agent-chroma 2>/dev/null || true
$CONTAINER_RUNTIME rm farm-agent-postgres farm-agent-chroma 2>/dev/null || true
```

**验证**：
```bash
grep -n "team-coordinator" scripts/stop-db.sh  # 应返回空
bash -n scripts/stop-db.sh
```

---

### 任务 8：stop-db.bat — 修正容器引用

**目标**：同 stop-db.sh

**改动**：L16-17

```batch
REM before
%CONTAINER_RUNTIME% stop team-coordinator-postgres team-coordinator-chroma 2>nul
%CONTAINER_RUNTIME% rm team-coordinator-postgres team-coordinator-chroma 2>nul

REM after
%CONTAINER_RUNTIME% stop farm-agent-postgres farm-agent-chroma 2>nul
%CONTAINER_RUNTIME% rm farm-agent-postgres farm-agent-chroma 2>nul
```

**验证**：
```bash
grep -n "team-coordinator" scripts/stop-db.bat  # 应返回空
```

---

### 任务 9：start-infrastructure.sh — 修正 chroma 引用 + 端口

**目标**：chroma collection/token 引用修正 + 端口对齐 farm-agent 配置

**需要改的行**：

| 行号 | 当前 | 改为 |
|------|------|------|
| L39 | `localhost:5432` | `localhost:5433` |
| L45 | `localhost:8000` | `localhost:8001` |
| L49 | chroma collection `team_coordinator` | `farm_agent` |
| L50 | 硬编码 chroma token | `${CHROMA_AUTH_TOKEN}`（值见 `.env.development`/`.env.production`） |
| L51 | 数据目录 `./data/chroma` | `$DATA_DIR/chroma` |

**验证**：
```bash
grep -n "team-coordinator\|team_admin\|team_coordinator" scripts/start-infrastructure.sh  # 应返回空
bash -n scripts/start-infrastructure.sh
```

---

### 任务 10：db-status.sh — 修正容器引用 + 端口

**目标**：容器名 + 端口修正

**需要改的行**：

| 行号 | 当前 | 改为 |
|------|------|------|
| L14 | `team-coordinator-postgres` | `farm-agent-postgres` |
| L19 | `localhost:8000` | `localhost:8001` |

**验证**：
```bash
grep -n "team-coordinator" scripts/db-status.sh  # 应返回空
bash -n scripts/db-status.sh
```

---

### 任务 11：db-wait.sh — 修正容器引用

**目标**：修正所有 co-agent 引用

**需要改的行**：

| 行号 | 当前 | 改为 |
|------|------|------|
| L15 | `team-coordinator-postgres` `team_admin` `team_coordinator` | `farm-agent-postgres` `farm_admin` `farm_agent` |

**验证**：
```bash
grep -n "team-coordinator\|team_admin\|team_coordinator" scripts/db-wait.sh  # 应返回空
bash -n scripts/db-wait.sh
```

---

### 任务 12：podman-compose.yml — 凭据 ${ENV_VAR} 化

**目标**：将硬编码的密码和 token 改为环境变量引用，与 co-agent 模式一致

**改动**：
```yaml
# before（硬编码凭据，不提交到仓库的敏感信息）
POSTGRES_PASSWORD: <硬编码值>
CHROMA_SERVER_AUTHN_CREDENTIALS: "<硬编码值>"

# after（环境变量引用，凭据值在 .env.xxx 中）
POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
CHROMA_SERVER_AUTHN_CREDENTIALS: ${CHROMA_AUTH_TOKEN}
```

**验证**：
```bash
grep -n '${POSTGRES_PASSWORD}' podman-compose.yml  # 应存在
grep -n '${CHROMA_AUTH_TOKEN}' podman-compose.yml  # 应存在
```

---

### 任务 13：.env.development / .env.production — 创建凭据文件

**目标**：创建 `.env.development` 和 `.env.production`，集中管理敏感凭据。
文件已在 `.gitignore` 中保护（`.env*` 规则），不会提交到仓库。

文件内容参考（实际值为示意，请替换为真实生产凭据）：

```bash
# .env.development
POSTGRES_DB=farm_agent
POSTGRES_USER=farm_admin
POSTGRES_PASSWORD=<请填写开发环境密码>
CHROMA_HOST=localhost
CHROMA_PORT=8001
CHROMA_AUTH_TOKEN=<请填写开发环境 token>
CHROMA_COLLECTION=farm_agent
NODE_ENV=development
```

```bash
# .env.production
POSTGRES_DB=farm_agent
POSTGRES_USER=farm_admin
POSTGRES_PASSWORD=<请填写生产环境密码>
CHROMA_HOST=localhost
CHROMA_PORT=8001
CHROMA_AUTH_TOKEN=<请填写生产环境 token>
CHROMA_COLLECTION=farm_agent
NODE_ENV=production
```

**验证**：
```bash
ls -la .env.development .env.production  # 两个文件均存在
grep POSTGRES_PASSWORD .env.development  # 应包含
grep CHROMA_AUTH_TOKEN .env.production   # 应包含
git check-ignore .env.development        # 应输出 .env.development（说明已被 gitignore）
```

---

### 任务 14：本地文件系统 — 创建 $HOME/data/farm-agent/

**目标**：本地创建外部数据目录

```bash
mkdir -p $HOME/data/farm-agent/postgres
mkdir -p $HOME/data/farm-agent/chroma
```

**验证**：`ls -la $HOME/data/farm-agent/` 存在 `postgres/` 和 `chroma/`

---

### 任务 15：本地文件系统 — 迁移 Podman 数据（如有）

**目标**：如果本地 `./data/` 下有 Podman 产生的数据，迁移到外部目录

```bash
# postgres
if [ -f ./data/postgres/PG_VERSION ]; then
  cp -a ./data/postgres/* $HOME/data/farm-agent/postgres/
fi
# chroma
if [ -f ./data/chroma/chroma.sqlite3 ]; then
  cp -a ./data/chroma/* $HOME/data/farm-agent/chroma/
fi
```

**验证**：`du -sh $HOME/data/farm-agent/*/` 显示合理大小（容器启动后）

---

### 任务 16：本地文件系统 — 项目 data/ 改权限

**目标**：与 co-agent 一致，项目内 `./data/` 改权限保留历史，不删除

```bash
chmod -R a+rX ./data/
```

**验证**：
- `ls -la ./data/` 目录仍在，其他用户可读
- 新容器启动后数据写入 `$HOME/data/farm-agent/`，不写入 `./data/`

---

### 任务 17：本地验证 — 启动容器 + 服务

**目标**：验证本地完整流程

```bash
export DATA_DIR="$HOME/data/farm-agent"
podman-compose up -d
podman inspect farm-agent-postgres --format '{{range .Mounts}}{{.Source}}{{end}}'
# 应输出: /home/xmm/data/farm-agent/postgres

npm run dev
# 等待启动 → curl http://localhost:3000 → 应返回 200
```

**验证**：
- 挂载路径正确
- 服务可访问
- `./data/` 未被修改（容器不再使用此路径）
- `podman ps` 显示 `farm-agent-postgres` 和 `farm-agent-chroma`
- `grep -rn "team-coordinator\|team_admin\|team_coordinator" scripts/` 返回空

---

### 任务 18：提交推送

**目标**：提交所有改动

```bash
git add -A
git status
git commit -m "refactor: podman 数据卷路径改为 $HOME 动态推导，docker-compose.yml 全面 farm 化，全部 9 个脚本容器引用从 co-agent 修正为 farm-agent，项目 data/ 保留历史"
git push origin main
```

**验证**：`git status` 干净

---

## 任务依赖图

```
Task1 (podman-compose) ──┐
Task2 (docker-compose) ──┤
Task3-11 (9 个脚本) ─────┤
Task12 (compose 凭据化) ─┤
Task13 (.env 创建) ──────┼──→ Task17 (本地验证) ──→ Task18 (push)
                         │         ↑
                         │    Task14 (mkdir)
                         │    Task15 (cp)
                         │    Task16 (chmod)
                         └────┘
```

Task1-11 独立可并行，Task12-14 在本机执行无需依赖代码改动。Task15 依赖 1-14 全部完成。
