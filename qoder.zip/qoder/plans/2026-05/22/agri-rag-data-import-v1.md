# PLAN: 农业 RAG 数据增量导入

## PLAN 元信息
- **Plan 名称**: agri-rag-data-import-v1
- **启动时间**: 2026-05-29T05:43:00+08:00
- **主导 AI**: AI 助手
- **目标仓库**: `/home/xmm/ai/farm-agent`

## 审计阶段定义

```
DATA_IMPORT_START         — 数据导入流程开始
DATA_IMPORT_SOURCE        — 数据来源确认（Desktop exports + Desktop farm-agent/uploads）
DATA_IMPORT_PREPARE       — 数据准备（文件复制到 uplads/knowledge/ + JSON 合并）
DATA_IMPORT_VECTOR        — 向量导入执行（kb-import.ts 批量导入 ChromaDB）
DATA_IMPORT_VERIFY        — 导入后验证（文档数 + 向量数）
DATA_IMPORT_DONE          — 导入完成
DATA_IMPORT_FAIL          — 导入失败
```

## 数据来源

| 来源 | 路径 | 内容 |
|------|------|------|
| Desktop farm-agent uploads | `/home/xmm/Desktop/farm-agent/uploads/knowledge/` | 69 个农业原始文件（邗江农业技术信息） |
| Desktop exports | `/home/xmm/Desktop/exports/` | chromadb-metadata.json + chromadb-vectors.json → farm-agent-import.json |

## 操作步骤

1. 文件复制: 48 个新文件 → farm-agent/uploads/knowledge/ ✅
2. 向量合并: chromadb-metadata.json + chromadb-vectors.json → farm-agent-import.json ✅
3. 向量导入: `npm run kb:import` → ChromaDB `farm_agent` 集合

## ADD-7 审计策略

| 操作 | targetType | action |
|------|-----------|--------|
| 文档更新 | DOC | DOC_UPDATED |
| 数据导入 | DATA_IMPORT | DATA_RAG_IMPORT |
| 文件复制 | DATA_IMPORT | FILE_COPY |
| 向量导入 | DATA_IMPORT | VECTOR_IMPORT |
