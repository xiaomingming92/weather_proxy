# 团队协同智能体 - 实施计划

## 项目概述

基于已确定的技术架构文档，实现完整的团队协同智能体系统。

**技术栈：**

* 推理框架：**ReAct** (LangGraph 原生支持)

* 记忆框架：**Memory-Augmented** (项目状态持久化)

* Web 后端：**Next.js** (Spring Boot 风格分层)

- 前端：**Next.js 内置 React** + TypeScript + TailwindCSS

* LLM：langgraph\_core.openai（可插拔）

* 向量库：Chroma

* 数据库：PostgreSQL + Prisma ORM

* 工程化：volta (Node 24 LTS) + dotenv

***

## 第一阶段：项目初始化

### 1.1 初始化 Next.js 项目

```bash
# 1. Git 初始化
git init

# 2. 创建项目（如果需要在当前目录创建，用 .）
npx create-next-app@latest team-coordinator-agent --typescript --tailwind --app --no-git
cd team-coordinator-agent

# 3. 或者在当前目录初始化（推荐用于新项目）
npx create-next-app@latest . --typescript --tailwind --app --no-git
```

**创建目录结构（Spring Boot 风格分层）：**

```
team-coordinator-agent/
├── src/
│   ├── app/                      # Next.js App Router
│   │   ├── api/                  # API Routes（Controller 层）
│   │   │   ├── agent/
│   │   │   ├── task/
│   │   │   ├── document/
│   │   │   └── project/
│   │   ├── (auth)/               # 认证页面组
│   │   └── (main)/               # 主应用页面组
│   ├── components/               # 组件层
│   │   ├── ui/                   # 基础 UI 组件
│   │   ├── chat/                 # 聊天相关
│   │   ├── task/                 # 任务相关
│   │   ├── document/             # 文档相关
│   ├── services/                 # Service 层（业务逻辑）
│   ├── repositories/             # Repository 层（数据访问）
│   ├── entities/                 # Entity 层（领域模型）
│   ├── dto/                      # DTO 层（数据传输对象）
│   ├── agents/                   # LangGraph Agents（推理端）
│   │   ├── nodes/               # 节点实现
│   │   ├── edges/               # 边定义
│   │   └── prompts/             # Prompt 模板
│   ├── resolvers/               # 业务裁决层
│   ├── lib/                     # 工具函数
│   └── stores/                  # 状态管理（Zustand）
├── prisma/
│   └── schema.prisma            # 数据库 Schema
├── chroma/                      # Chroma 数据目录
└── ...
```

### 1.2 安装依赖

```bash
# 核心依赖
npm install @langchain/langgraph @langchain/openai @langchain/community
npm install chroma-js @prisma/client
npm install prisma --save-dev

# 前端依赖
npm install @radix-ui/react-* lucide-react
npm install zustand @tanstack/react-query

# 工具依赖
npm install bcryptjs jsonwebtoken zod
npm install dotenv
```

### 1.3 工程化配置

**volta 配置（Node 24 LTS）：**

```bash
volta pin node@24
```

**.node-version 文件：**

```
24.x.x
```

**dotenv 文件：**

* `.env.local` - 本地开发

* `.env.development` - 开发环境

* `.env.production` - 生产环境

***

## 第二阶段：数据库设计

### 2.1 Prisma Schema

按照技术架构文档创建完整的 Schema：

* User / Role (ROOT/STAFF)

* Project

* Task / TaskType / TaskStatus

* TaskDependency

* Milestone

* Document / DocStatus

* ChatMessage / MessageRole

* Verdict / VerdictType

* AuditLog

* EconomicFactor

### 2.2 数据库迁移

```bash
npx prisma migrate dev --name init
npx prisma generate
```

***

## 第三阶段：LangGraph 核心实现

### 3.1 State 定义

创建 `src/agents/state.ts`：

* messages: Annotation\<Message\[]>

* user: Annotation\<User | null>

* project: Annotation\<Project | null>

* currentTask: Annotation\<Task | null>

* evidenceChain: Annotation\<Evidence\[] | null>

* verdict: Annotation\<VerdictResult | null>

* economicFactors: Annotation\<EconomicFactor\[] | null>

* retrievalContext: Annotation\<RetrievalContext | null>

### 3.2 节点实现（ReAct 模式）

**src/agents/nodes/intention.ts**

* 意图解析节点：ReAct Reason - 解析用户消息意图

**src/agents/nodes/retrieval.ts**

* 向量检索节点：ReAct Act - 并行检索文档/任务/经济数据

**src/agents/nodes/reasoning.ts**

* 推理节点：ReAct Reason - 证据链推理

**src/agents/nodes/verdict.ts**

* 裁决节点：ReAct Act - 基于证据链的业务裁决

**src/agents/nodes/response.ts**

* 响应节点：ReAct Act - 生成最终响应

### 3.3 边定义

**src/agents/edges/conditional.ts**

* `routeByIntent`: 根据意图路由

* `routeByVerdictType`: 根据裁决类型路由

### 3.4 Agent 编译

创建 `src/agents/index.ts`：

* StateGraph 组合（ReAct 循环）

* Checkpointer 配置（Memory-Augmented）

* MemorySaver (dev) / PostgresSaver (prod)

***

## 第四阶段：证据链推理引擎

### 4.1 类型定义

创建 `src/types/evidence.ts`：

* Evidence / EvidenceSource

* EvidenceChain

* ReasoningStep

* Conclusion

* ConfidenceBreakdown

* RiskItem

### 4.2 推理引擎实现

创建 `src/services/reasoning-engine.ts`：

* EvidenceChainReasoningEngine 类

* collectEvidences()

* evaluateEvidences()

* multiStepReasoning()

* generateConclusion()

* reason() / reasonWithWeights()

### 4.3 Prompt 模板

创建 `src/agents/prompts/`：

* intention.ts - 意图解析

* reasoning.ts - 推理

* verdict.ts - 裁决

***

## 第五阶段：业务裁决层

### 5.1 裁决类型定义

* PriorityVerdict

* RiskVerdict

* ResourceVerdict

* CostBenefitVerdict

### 5.2 裁决器实现

创建 `src/resolvers/`：

* verdict-resolver.ts - 裁决器接口

* priority-resolver.ts - 优先级裁决

* risk-resolver.ts - 风险评估裁决

* resource-resolver.ts - 资源分配裁决

* cost-benefit-resolver.ts - 成本收益裁决

### 5.3 状态迁移规则

创建 `src/lib/transitions.ts`：

* 集中管理状态迁移规则

* canTransition() 函数

* AbilityResult 类型

***

***

## 第七阶段：API 路由（Controller 层）

### 7.1 Agent API

* `POST /api/agent/chat` - 聊天消息

* `POST /api/agent/stream` - 流式响应

* `POST /api/agent/verdict` - 裁决请求

### 7.2 任务 API

* `GET/POST /api/tasks` - 任务列表/创建

* `GET/PUT/DELETE /api/tasks/[id]` - 任务 CRUD

* `PUT /api/tasks/[id]/status` - 状态更新

### 7.3 文档 API

* `GET/POST /api/documents` - 文档列表/上传

* `GET /api/documents/[id]` - 文档详情

* `POST /api/documents/[id]/vectorize` - 向量化

* `DELETE /api/documents/[id]` - 删除文档

### 7.4 项目 API

* `GET/POST /api/projects`

* `GET/PUT/DELETE /api/projects/[id]`

### 7.5 用户 API

* `POST /api/auth/login` - 登录

* `POST /api/auth/register` - 注册

* `GET /api/users/me` - 当前用户

***

## 第八阶段：前端组件

### 8.1 基础 UI 组件

* Button / Input / Card / Badge

* Dialog / DropdownMenu

* Tabs / Accordion

* Table

### 8.2 聊天界面

* ChatContainer - 聊天容器

* ChatMessage - 消息展示

* ChatInput - 输入框

* StreamingMessage - 流式消息

### 8.3 任务面板

* TaskPanel - 任务面板

* TaskList - 任务列表

* TaskCard - 任务卡片

* TaskForm - 任务表单

* MilestoneTimeline - 里程碑时间线

### 8.4 文档管理

* DocumentUploader - 文档上传

* DocumentList - 文档列表

* DocumentViewer - 文档预览

* VectorStatus - 向量化状态

### 8.5 裁决展示

* VerdictPanel - 裁决结果展示

* ReasoningPathAccordion - 推理路径

* ConfidenceBreakdown - 置信度分解

* RiskAlert - 风险提示

***

## 第九阶段：认证与权限

### 9.1 认证

* JWT token 生成/验证

* 登录/注册接口

* 中间件验证

### 9.2 权限

* Role-based access control

* 裁决层集中权限检查

* 审计日志记录

***

## 第十阶段：测试

### 10.1 单元测试

* Resolver 单元测试

* Transition 规则测试

* Evidence chain 测试

### 10.2 集成测试

* API 路由测试

* Agent 流程测试

### 10.3 E2E 测试

* Playwright 配置

* 核心流程测试

***

## 实施顺序

```
1. 项目初始化（Next.js + 依赖 + Spring Boot 风格目录结构）
     ↓
2. 数据库设计（Prisma Schema + 迁移）
     ↓
3. LangGraph 核心（State + Nodes + Edges + 编译 + ReAct）
     ↓
4. 证据链推理引擎（类型 + 引擎 + Prompts）
     ↓
5. 业务裁决层（类型 + Resolver + 规则）
     ↓
6. API 路由（Agent + Task + Document + Project）
     ↓
7. 前端组件（UI + 聊天 + 任务 + 文档）
     ↓
8. 认证与权限
     ↓
9. 测试 + 部署配置
```

***

## Agent 框架架构总结

| 层级        | 框架               | 说明                   |
| --------- | ---------------- | -------------------- |
| **推理核心**  | ReAct            | LangGraph 原生支持，状态流转  |
| **记忆持久化** | Memory-Augmented | Checkpointer 持久化项目状态 |
| **图探索**   | ❌ 不需要            | 推理路径已知，无需探索          |

***

## 验证标准

* [ ] 项目可正常启动 `npm run dev`

* [ ] Prisma 数据库迁移成功

* [ ] LangGraph Agent 可正常推理（ReAct 模式）

* [ ] 证据链推理返回完整结构

* [ ] 裁决层返回带置信度的结论

* [ ] API 路由正常响应

* [ ] 前端页面可正常渲染

* [ ] 认证流程正常工作

* [ ] 单元测试通过

