# 知识库文档标签系统 — ADD 范式实施计划

---

## Step 0：定义审计阶段

```typescript
type DocumentTagPhase =
  | "DOC_TAG_START"
  | "SYNC_TAG_IMPLANT"          // 同步服务植入标签逻辑
  | "UPLOAD_TAG_IMPLANT"        // 上传服务植入默认标签
  | "API_TAGS_RETURN"           // GET API 返回 tags 字段
  | "API_PATCH_TAGS"            // PATCH 标签编辑端点
  | "UI_TAGS_DISPLAY"           // 前端展示标签
  | "UI_TAGS_ADD"               // 前端添加标签
  | "UI_TAGS_REMOVE"            // 前端删除标签
  | "DOC_TAG_DONE"
  | "DOC_TAG_FAIL"
  | "DOC_TAG_VERIFY"            // 验证阶段
  | "DOC_TAG_CONVERGE"          // 收敛阶段
```

---

## Step 1：审计基础设施

已有 KB 审计日志器 `src/lib/audit-logger.ts`，本功能直接复用，无需新建 logger。

已有格式：
```
[KB-AUDIT] [ISO时间] [阶段] 详情 | {JSON extra}
```

需要新增的审计阶段枚举值（追加到 KB 审计日志中即可）：
- `DOC_TAG_SYNC` — 同步时标签写入日志
- `DOC_TAG_PATCH` — 标签编辑 API 日志
- `DOC_TAG_UI` — 前端操作日志

---

## Step 2：逐模块植入审计点，完成后立即审计验证

### 2.1 knowledge-sync.ts — 同步时打标签

**植入位置**：`PHASE_ADDED` 和 `PHASE_MODIFIED` 的 `document.create()` 处

**修改内容**：
```typescript
// 从 relativePath 推断标签
const pathSegments = file.relativePath.split(path.sep)
const projectDirIdx = pathSegments.findIndex(s => s === 'docs') + 1
const projectName = pathSegments[projectDirIdx] || ""
const categoryDir = pathSegments[projectDirIdx + 2] || ""
const lockedTags = [...new Set([projectName, categoryDir].filter(Boolean))]

// data 对象中增加
tags: lockedTags,
metadata: {
  ...existingMetadata,
  path: file.relativePath,
  lockedTags,
} as Prisma.InputJsonValue,
```

**审计点植入**：
```typescript
auditDoc("DOC_TAG_SYNC", file.relativePath, doc.id, `标签: ${lockedTags.join(", ")}`, { lockedTags })
```

**完成后验证**：运行 `npm run kb:sync` → `grep "DOC_TAG_SYNC" logs/knowledge-base/kb-audit.log`

### 2.2 upload/route.ts — 上传时加默认标签

**植入位置**：`prisma.document.create()` 处

**修改内容**：
```typescript
tags: ["用户上传"],
metadata: {
  originalSize: file.size,
  uploadedFilename: filename,
  previousVersion: existingByName?.version,
  lockedTags: ["用户上传"],
} as Prisma.InputJsonValue,
```

**审计点植入**：
```typescript
// 在 create 成功后审计
agentAudit("DOC_TAG_SYNC", `上传文档标签: ["用户上传"]`, { docId: doc.id, name: doc.name })
```

**完成后验证**：上传一个文件 → 检查数据库 `tags` 字段包含 `["用户上传"]`

### 2.3 GET /api/knowledge/documents — 返回 tags 字段

**植入位置**：`documentsWithSize` map 回调中

**修改内容**：
```typescript
return {
  id: doc.id,
  // ... 原有字段
  tags: doc.tags || [],
  lockedTags: (meta.lockedTags as string[]) || [],
}
```

**完成后验证**：`curl http://localhost:3000/api/knowledge/documents | jq '.data[0].tags'`

### 2.4 新增 PATCH /api/knowledge/documents/[id]/tags

**文件路径**：`src/app/api/knowledge/documents/[id]/tags/route.ts`

**逻辑**：
```typescript
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const body = await request.json()
  const { action, tag } = body

  const doc = await prisma.document.findUnique({ where: { id: params.id } })
  if (!doc) {
    return NextResponse.json({ success: false, error: "文档不存在" }, { status: 404 })
  }

  // 校验 lockedTags
  const meta = (doc.metadata as Record<string, unknown>) || {}
  const lockedTags = (meta.lockedTags as string[]) || []
  if (action === "remove" && lockedTags.includes(tag)) {
    return NextResponse.json({ success: false, error: "系统标签不可删除" }, { status: 400 })
  }

  let newTags = [...(doc.tags || [])]
  if (action === "add" && !newTags.includes(tag)) {
    newTags.push(tag)
  } else if (action === "remove") {
    newTags = newTags.filter(t => t !== tag)
  }

  await prisma.document.update({ where: { id: params.id }, data: { tags: newTags } })

  return NextResponse.json({ success: true, data: { tags: newTags } })
}
```

**审计点植入**：
```typescript
audit("DOC_TAG_PATCH", `action=${action} tag=${tag} docId=${params.id}`, {
  docId: params.id, action, tag, newTags, lockedTags: Boolean(lockedTags.includes(tag))
})
```

**完成后验证**：
```bash
curl -X PATCH http://localhost:3000/api/knowledge/documents/{id}/tags \
  -H "Content-Type: application/json" \
  -d '{"action":"add","tag":"测试标签"}'
```

### 2.5 knowledge-base-panel.tsx — 前端展示标签 + 编辑 UI

**修改点**：
- `KnowledgeDocument` 接口增加 `tags: string[]` 和 `lockedTags: string[]`
- `fetchDocuments` 收到 tags 和 lockedTags 后存入 state
- 每个文档行渲染标签行 + + 标签按钮
- 输入框 Enter 提交 → 调用 PATCH API
- 自定义标签显示 × 按钮 → 调用 PATCH API delete

**审计点植入**：
```typescript
// 成功添加标签后
console.log("[DOC_TAG_UI] add tag:", { docId, tag })

// 成功删除标签后
console.log("[DOC_TAG_UI] remove tag:", { docId, tag })
```

**完成后验证**：在知识库面板中看到标签，可添加/删除

---

## Step 3：运行 — 收集审计数据

```bash
# 1. 重新同步知识库，打标签
npm run kb:sync
grep "DOC_TAG_SYNC" logs/knowledge-base/kb-audit.log

# 2. 检查 GET API 返回是否包含 tags
curl http://localhost:3000/api/knowledge/documents | jq '.data[] | {name, tags, lockedTags}'

# 3. 上传一个文件测试默认标签
# 4. 添加标签、删除标签测试
# 5. 检查审计日志
grep "DOC_TAG_PATCH\|DOC_TAG_UI" logs/knowledge-base/kb-audit.log
```

---

## Step 4：分析审计数据 — 查找异常

| 可能的问题 | 审计证据 | 处置 |
|-----------|---------|------|
| 同步时部分文档未打上标签 | `DOC_TAG_SYNC` 缺失某些文档 | 检查路径解析逻辑 |
| 上传文档 lockedTags 不存在 | 数据库查询 lockedTags 为空 | 检查 metadata 写入 |
| 前端无法删除标签 | 后端返回 400，审计日志中无 PATCH 记录 | 检查 API 调用 |
| 标签重复 | 数据库出现重复标签 | 后端 add 时做去重检查 |

---

## Step 5：修复 — 基于审计结果迭代

如 Step 4 发现任何问题，定位根因后修复，然后回到 Step 3 重新运行验证。

---

## Step 6：收敛验证

最终验收条件：

| 条件 | 验证方式 |
|------|---------|
| 知识库面板每个文档展示标签 | 视觉检查 |
| 系统标签（目录派生/"用户上传"）不可删除 | 前端无 × 按钮，后端 API 返回 400 |
| 自定义标签可添加/删除 | 前端操作正常 |
| PATCH API 拒绝删除 lockedTags | `curl -X PATCH -d '{"action":"remove","tag":"团队协作智能体"}'` 返回 400 |
| 审计日志完整 | `grep -c "DOC_TAG_SYNC\|DOC_TAG_PATCH"` > 0 |
| 阶段标记对称 | `grep -c "DOC_TAG_START"` == `grep -c "DOC_TAG_DONE"` |
| TypeScript 编译通过 | `npm run build` 或 `npx tsc --noEmit` |

---

## 修改文件清单

| 文件 | 操作 | 所属 Step |
|------|------|-----------|
| `src/services/knowledge-sync.ts` | 修改 | Step 2.1 |
| `src/app/api/knowledge/upload/route.ts` | 修改 | Step 2.2 |
| `src/app/api/knowledge/documents/route.ts` | 修改 | Step 2.3 |
| `src/app/api/knowledge/documents/[id]/tags/route.ts` | 新增 | Step 2.4 |
| `src/components/knowledge/knowledge-base-panel.tsx` | 修改 | Step 2.5 |
