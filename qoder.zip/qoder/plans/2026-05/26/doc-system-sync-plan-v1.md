# 计划：参照 codein2027 规范重组 farm-agent / co-agent 文档体系

## 📋 Plan 元信息

- **Plan 名称**: doc-system-reorganize-v2
- **启动时间**: 2026-05-27T09:30:00+08:00
- **主导 AI**: Trae Agent
- **目标仓库**: `/home/xmm/ai/farm-agent` `/home/xmm/ai/co-agent`
- **参照基准**: `/home/xmm/ai/农业智能体/codein2027` 的文档组织规范
- **核心原则**: **不复制文件，而是参照规范重组已有文档**
- **时间约束**: ⚠️ 下午需部署，高效完成

---

## 〇、现状诊断

### farm-agent 文档规范性问题

| 问题 | 严重度 | 影响文件数 |
|------|--------|-----------|
| `.qoder/documents/` 不是标准目录 | 🔴 结构错误 | 17个 |
| review 文件散落在 documents 中 | 🔴 结构错误 | 7个 |
| plan 文件散落在 documents 中 | 🔴 结构错误 | 4个 |
| 文件命名缺版本号 `-v{N}` | 🟡 命名错误 | 20+个 |
| 产物类型关键词为前缀非后缀 | 🟡 命名错误 | 3个 |
| 全中文/中英混合命名 | 🟡 命名错误 | 7个 |
| 使用 `_` 下划线 | 🟡 命名错误 | 3个 |
| 缺 `docs/哲学理论/` | 🟠 结构缺失 | — |
| 缺 `TODO/` | 🟠 结构缺失 | — |
| 原子事务三件套不完整 | 🟠 结构缺失 | — |

### co-agent 文档规范性问题

与 farm-agent 结构基本一致，因为 co-agent 是 farm-agent 的早期版本，存在相同的 `documents/` 目录问题。

---

## 一、执行策略

### 核心原则

```
不复制 codein2027 的文件 → 而是用其规范重组已有文档：
  ✅ 重命名已有文件（补版本号、修正产物类型位置）
  ✅ 移动文件到正确目录（review → reviews/、plan → plans/）
  ✅ 清理不合规目录（documents/ 按产物类型拆散）
  ✅ 补充缺失结构（docs/哲学理论/、TODO/）
  ❌ 不直接复制 codein2027 的 review/plan 文件过来
```

### 唯一例外（可同步的内容）

以下内容在 farm-agent/co-agent 中完全缺失，属于**基础设施**而非业务文档，可以从 codein2027 同步：

| 内容 | 理由 |
|------|------|
| `docs/哲学理论/` (6个文件) | 哲学理论基础，跨仓库共享 |
| `TODO/add-compliance-automation.md` | 公开协作 TODO，跨仓库共享 |
| 《ADD开发工作路径与文档协同规范》 | 范式规范文档，跨仓库共享 |
| `farm-agent-audit-pipeline-v1/` spec | 审计管线 spec，co-agent 可参考 |

---

## 二、详细执行步骤

### 🔵 Phase 1：farm-agent 文档重组（核心，~60分钟）

#### Step 1.1：创建 `.qoder/reviews/` 目录 + 迁移 review 文件

**操作**：

```
mkdir /home/xmm/ai/farm-agent/.qoder/reviews/
```

**迁移规则**（从 `.qoder/documents/` → `.qoder/reviews/`，同时规范化命名）：

| 当前路径（documents/） | → | 目标路径（reviews/） |
|---|---|---|
| `REVIEW-response-intelligence-optimization-v1.md` | → | `response-intelligence-optimization-review-v1.md` |
| `co-agent-simplified-v1-review.md` | → | `co-agent-simplified-review-v1.md` |
| `farm-agent-round1-spec-review.md` | → | `farm-agent-round1-type-convergence-spec-review-v1.md` |
| `farm-agent-round1.5-spec-review.md` | → | `farm-agent-round1.5-type-enhance-spec-review-v1.md` |
| `farm-agent-round2-spec-review.md` | → | `farm-agent-round2-response-strategy-spec-review-v1.md` |
| `farm-agent-round3-spec-review.md` | → | `farm-agent-round3-expert-registry-spec-review-v1.md` |
| `farm-agent-round4-spec-review.md` | → | `farm-agent-round4-spec-review-v1.md` |
| `farm-agent-round4-spec-review2.md` | → | `farm-agent-round4-spec-review-v2.md` |

**命名修正说明**：
- `REVIEW-` 前缀 → `-review-` 后缀
- 补充需求域名前缀（`farmer-agent-` 或 `co-agent-`）
- 补充版本号 `-v{N}`
- 产物类型 `-spec-review-` 放在版本号之前

**验证标准**：
- [ ] `.qoder/reviews/` 目录已创建
- [ ] 8 个 review 文件已迁移并重命名
- [ ] `.qoder/documents/` 中无 review 文件残留

---

#### Step 1.2：迁移 documents/ 中的 plan/handoff 文件到 plans/

**操作**：从 `.qoder/documents/` → `.qoder/plans/`，同时规范化命名：

| 当前路径（documents/） | → | 目标路径（plans/） |
|---|---|---|
| `co-agent-conversation-handoff.md` | → | `co-agent-conversation-handoff-v1.md` |
| `co-agent-simplified-v1-execution-plan.md` | → | `co-agent-simplified-execution-v1.md` |
| `co-agent-simplified-v1.md` | → | `co-agent-simplified-plan-v1.md` |
| `reasoning-chain-unification-plan.md` | → | `reasoning-chain-unification-plan-v1.md` |
| `fix-streaming-structured-data-dom-style.md` | → | `fix-streaming-structured-data-plan-v1.md` |

**额外处理**：
- `团队协同智能体_规划.md` → `team-coordinator-agent-plan-v1.md`
- `知识库文档标签系统实施计划.md` → `knowledge-doc-tag-system-plan-v1.md`
- `doc-system-sync-codein2027-v1.md` → `doc-system-sync-plan-v1.md`
- `add-paradigm-case-study.md` → 移至 `docs/哲学理论/`（它是案例研究，非 plan/review）

**命名修正说明**：
- `-execution-plan` → `-execution-`（去掉 plan 重复）
- 补版本号 `-v{N}`
- 中文文件名 → 英文拼音命名

**验证标准**：
- [ ] 9 个文件已迁移并重命名
- [ ] `add-paradigm-case-study.md` 已移至 `docs/哲学理论/`

---

#### Step 1.3：规范化 plans/ 中已有的文件命名

**操作**：对 `.qoder/plans/` 中 18 个已有文件进行重命名：

**前缀修正**（`PLAN-` 前缀 → `-plan-` 后缀）：
| 当前 | → | 目标 |
|---|---|---|
| `PLAN-personnel-management-v1.md` | → | `personnel-management-plan-v1.md` |
| `PLAN-streaming-event-bus-v1.md` | → | `streaming-event-bus-plan-v1.md` |
| `PLAN-workspace-pmo-v1.md` | → | `workspace-pmo-plan-v1.md` |

**版本号补充**（已有产物类型但缺版本号）：
| 当前 | → | 目标 |
|---|---|---|
| `chat-audit-plan.md` | → | `chat-audit-plan-v1.md` |
| `chat-panel-enhancement-plan.md` | → | `chat-panel-enhancement-plan-v1.md` |
| `chat-thread-tab-plan.md` | → | `chat-thread-tab-plan-v1.md` |
| `document-list-pagination-plan.md` | → | `document-list-pagination-plan-v1.md` |
| `fix-chat-structured-data-plan.md` | → | `fix-chat-structured-data-plan-v1.md` |
| `kb-audit-log-plan.md` | → | `kb-audit-log-plan-v1.md` |
| `knowledge-base-fix-plan.md` | → | `knowledge-base-fix-plan-v1.md` |
| `mcp-server-plan.md` | → | `mcp-server-plan-v1.md` |
| `mcp-test-plan.md` | → | `mcp-test-plan-v1.md` |

**产物类型缺失 + 版本号缺失**：
| 当前 | → | 目标 |
|---|---|---|
| `fix-loading-deadlock.md` | → | `fix-loading-deadlock-plan-v1.md` |

**中文命名转换**：
| 当前 | → | 目标 |
|---|---|---|
| `Agent-Tools-实现计划.md` | → | `agent-tools-plan-v1.md` |
| `ChainTracer接入与RAG检索修复计划.md` | → | `chain-tracer-rag-fix-plan-v1.md` |
| `团队协同智能体_实施计划.md` | → | `team-coordinator-agent-plan-v1.md` |
| `按钮层级体系梳理与架构修正计划.md` | → | `button-hierarchy-fix-plan-v1.md` |
| `架构文档修正_按钮激活态与模型钩子集成计划.md` | → | `architecture-doc-button-hook-fix-plan-v1.md` |

**冲突处理**：如果 `团队协同智能体_实施计划.md` 与 documents/ 迁移过来的 `team-coordinator-agent-plan-v1.md` 内容不同，保留两者分别命名：
- `team-coordinator-agent-plan-v1.md`（来自 documents/）
- `team-coordinator-agent-implementation-plan-v1.md`（来自 plans/）

**验证标准**：
- [ ] 18 个 plans/ 文件已全部重命名
- [ ] 所有文件名符合 `{内容}-{产物类型}-v{版本号}` 格式
- [ ] 无 `_` 下划线、无全中文、无 PLAN- 前缀

---

#### Step 1.4：清理 `.qoder/documents/` 目录

**操作**：完成 Step 1.1-1.2 后，检查 documents/ 剩余文件：

**预期残留**：
- `doc-system-sync-codein2027-v1.md` → 已迁移至 plans/
- `add-paradigm-case-study.md` → 已迁移至 docs/哲学理论/

**清理操作**：如果 documents/ 为空，删除该目录。

**验证标准**：
- [ ] documents/ 中无 review / plan / handoff 文件残留
- [ ] documents/ 目录清空或已删除

---

#### Step 1.5：同步缺失的基础设施文档

**操作**：以下文件 farm-agent 完全缺失，从 codein2027 同步（这些是跨仓库共享的基础设施，非业务文档）：

````
# 哲学理论基础层（6个文件）
cp -r /home/xmm/ai/农业智能体/codein2027/docs/哲学理论 /home/xmm/ai/farm-agent/docs/哲学理论

# 公开 TODO
mkdir /home/xmm/ai/farm-agent/TODO
cp /home/xmm/ai/农业智能体/codein2027/TODO/add-compliance-automation.md /home/xmm/ai/farm-agent/TODO/

# ADD 工作流规范文档
cp /home/xmm/ai/农业智能体/codein2027/docs/大田精准耕播智能决策系统/knowledge/01-架构/《ADD开发工作路径与文档协同规范》.md \
   /home/xmm/ai/farm-agent/docs/大田精准耕播智能决策系统/knowledge/01-架构/

# Spec 模块（审计管线）
cp -r /home/xmm/ai/农业智能体/codein2027/.qoder/specs/farm-agent-audit-pipeline-v1 \
      /home/xmm/ai/farm-agent/.qoder/specs/

# 原子事务三件套（plan + execution + handoff）
cp /home/xmm/ai/农业智能体/codein2027/.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-plan-v1.md \
   /home/xmm/ai/farm-agent/.qoder/plans/
cp /home/xmm/ai/农业智能体/codein2027/.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-7轮原子事务拆分-execution-v1.md \
   /home/xmm/ai/farm-agent/.qoder/plans/
cp /home/xmm/ai/农业智能体/codein2027/.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-7轮原子事务交接-handoff-v1.md \
   /home/xmm/ai/farm-agent/.qoder/plans/
````

**验证标准**：
- [ ] `docs/哲学理论/` 包含 6 个文件
- [ ] `TODO/add-compliance-automation.md` 存在
- [ ] 《ADD开发工作路径与文档协同规范》在架构目录下
- [ ] `farm-agent-audit-pipeline-v1/` spec 三件套完整
- [ ] 原子事务三件套齐全

---

### 🔵 Phase 2：co-agent 文档重组（~40分钟）

#### Step 2.1-2.5：对 co-agent 执行与 farm-agent 相同的重组

**操作**：对 `/home/xmm/ai/co-agent/` 执行 Phase 1 的全部步骤：
1. 创建 `.qoder/reviews/` + 迁移 review 文件
2. 迁移 documents/ 中的 plan/handoff 到 plans/
3. 规范化 plans/ 已有文件名
4. 清理 documents/
5. 同步基础设施文档

**路径差异**：
- co-agent 的业务文档路径是 `docs/团队协作智能体/`
- 《ADD开发工作路径与文档协同规范》放入 `docs/团队协作智能体/knowledge/01-架构/`

**验证标准**：
- [ ] co-agent 完成所有与 farm-agent 相同的重组操作

---

### 🔵 Phase 3：README 改写（~30分钟）

#### Step 3.1：改写 farm-agent README

**原则**：
- 不能照搬 codein2027 的开源风格
- 表述为"本项目源自开源项目 [codein2027]"
- 保留技术实用性内容

#### Step 3.2：改写 co-agent README

**原则**：同 farm-agent，定位改为"团队内部协作工具"

**验证标准**：
- [ ] 无"开源"、"Stars"、"License"、"AGPL"等字样
- [ ] 明确标注"源自 codein2027"
- [ ] 各仓库定位描述正确

---

### 🔵 Phase 4：最终验证（~15分钟）

#### Step 4.1：命名规范抽检

```bash
# farm-agent plans/ 全部文件
ls /home/xmm/ai/farm-agent/.qoder/plans/

# farm-agent reviews/ 全部文件
ls /home/xmm/ai/farm-agent/.qoder/reviews/

# co-agent 同样检查
ls /home/xmm/ai/co-agent/.qoder/plans/
ls /home/xmm/ai/co-agent/.qoder/reviews/
```

**验证标准**：
- [ ] 所有文件遵循 `{内容}-{产物类型}-v{版本号}`
- [ ] 无 `_` 下划线
- [ ] 无 `PLAN-` / `REVIEW-` 前缀

#### Step 4.2：目录结构验证

```
farm-agent/
├── docs/
│   └── 哲学理论/                    ✅ 6个文件
├── TODO/                            ✅ 1个文件
├── .qoder/
│   ├── reviews/                     ✅ 无 documents/
│   └── plans/                       ✅ 无散落 review
```

#### Step 4.3：README 关键词检查

```bash
grep -i "开源\|github.*star\|AGPL\|license" /home/xmm/ai/farm-agent/README.md
grep -i "开源\|github.*star\|AGPL\|license" /home/xmm/ai/co-agent/README.md
```

**验证标准**：
- [ ] 上述 grep 无命中（无开源相关表述）

#### Step 4.4：功能验证

```bash
cd /home/xmm/ai/farm-agent && npx tsc --noEmit  # 文档变更不影响编译
cd /home/xmm/ai/co-agent && npx tsc --noEmit
```

---

## 三、操作量统计

| 仓库 | 新建目录 | 重命名文件 | 迁移文件 | 新增文件（从 codein2027）|
|------|---------|-----------|---------|----------------------|
| farm-agent | `.qoder/reviews/` | ~28个 | ~13个 | 哲学理论(6) + TODO(1) + 架构文档(1) + Spec(3) + 三件套(3) |
| co-agent | `.qoder/reviews/` | ~18个 | ~10个 | 同上 |
| **合计** | 2个 | **~46个** | **~23个** | **~28个** |

---

## 四、时间估算

| Phase | 内容 | 预估 |
|-------|------|------|
| Phase 1 | farm-agent 重组 | 60分钟 |
| Phase 2 | co-agent 重组 | 40分钟 |
| Phase 3 | README 改写 | 30分钟 |
| Phase 4 | 验证 | 15分钟 |
| **合计** | | **~2.5小时** |

---

## 五、风险

| 风险 | 应对 |
|------|------|
| 文件名冲突（迁移后与已有文件重名） | 检查后再迁移，冲突时人工判断合并/区分 |
| .qoder/specs/ 中引用旧文件路径 | spec 文件中的路径引用不修改（spec 是历史快照） |
| 下午部署时间紧张 | Phase 1-2 为纯文件操作，机械化执行 |
