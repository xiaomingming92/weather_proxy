# farm-agent Prompt 模板集中管理 Plan v1

## PLAN 元信息

- **Plan 名称**: farm-agent-prompt-template-restructuring-v1
- **启动时间**: 2026-06-04
- **前置依赖**: 无硬依赖。仅抽离 prompt 文本为独立 .txt 文件，不改动 parse/validate 逻辑和目录结构
- **目标仓库**: `/home/xmm/ai/farm-agent`

---

## 1. 背景

当前 9 个 LLM prompt 的文本直接写在 ts 代码的 `build()` 方法里，改 prompt 措辞需要进 ts 文件，diff 里 prompt 文本和代码逻辑混在一起。

**目标**：把 prompt 文本抽成独立 `.txt` 文件，`prompts/{name}.ts` 的 `build()` 改为从 txt 文件加载。其余不动。

## 2. 目标

| 维度 | 当前 | 目标 |
|------|------|------|
| 管线 prompt 文本 | 内联在 `prompts/{name}.ts` 的 `build()` 中 | `templates/{name}.txt` |
| 专家 prompt 文本 | 内联在 `experts/registry.ts` 的 `promptTemplate` 字段 | `templates/experts/{name}.txt` |
| 流式 reply prompt | 内联在 `nodes/response.ts` `buildStreamingTextPrompt()` | `templates/response-streaming.txt` |
| parse/validate 逻辑 | `prompts/{name}.ts` 中 | **不动** |
| 类型定义 | `prompts/types.ts` | **不动** |

## 3. 目录结构

```
src/agents/prompts/
├── templates/                    ← 唯一新增
│   ├── intention.txt
│   ├── reasoning.txt
│   ├── verdict.txt
│   ├── interaction-point-detection.txt
│   ├── response.txt
│   ├── response-streaming.txt
│   └── experts/
│       ├── crop_compare.txt
│       ├── roi_analysis.txt
│       └── pest_risk.txt
├── load-template.ts              ← loadTemplate() + fillSlots()（~30 行）
├── intention.ts                  ← build() 改用 loadTemplate()，其余不动
├── reasoning.ts
├── verdict.ts
├── interaction-point-detection.ts
├── response.ts
└── types.ts                      ← 不动
```

## 4. load-template.ts

```typescript
// src/agents/prompts/load-template.ts
import fs from "fs"
import path from "path"

const cache = new Map<string, string>()

export function loadTemplate(name: string): string {
  const cached = cache.get(name)
  if (cached) return cached
  const filePath = path.join(__dirname, "templates", `${name}.txt`)
  const text = fs.readFileSync(filePath, "utf-8")
  cache.set(name, text)
  return text
}

export function fillSlots(template: string, vars: Record<string, string>): string {
  let result = template
  for (const [key, value] of Object.entries(vars)) {
    result = result.replace(new RegExp(`\\{\\{${key}\\}\\}`, "g"), value)
  }
  return result
}
```

## 5. 模板占位符

| 占位符 | 运行时来源 |
|--------|-----------|
| `{{USER_MESSAGE}}` | 用户输入 |
| `{{EXPERT_DOMAIN_LIST}}` | `Object.keys(ANALYSIS_EXPERTS)` |
| `{{PREVIOUS_TURN_SUMMARY}}` | `AnalysisContext.turnHistory` |
| `{{INTENT_LABEL}}` | 当前 intent |
| `{{EVIDENCE_CONTEXT}}` | retrieval 结果 |
| `{{VERDICT_CONTEXT}}` | verdict 结果 |
| `{{STRATEGY_PROMPT_HINT}}` | response-strategy.promptHint |
| `{{SUB_INTENTS_CONTEXT}}` | currentTask.subIntents |

## 6. 实施步骤

### Phase 1: 基础设施

| 步骤 | 内容 |
|------|------|
| 1.1 | 创建 `templates/`、`templates/experts/` 目录 |
| 1.2 | 实现 `load-template.ts`：`loadTemplate()` + `fillSlots()` |

### Phase 2: 提取 prompt 模板文本

| 步骤 | 源 | 目标 |
|------|----|------|
| 2.1 | `prompts/intention.ts` `build()` | `templates/intention.txt` |
| 2.2 | `prompts/reasoning.ts` `build()` | `templates/reasoning.txt` |
| 2.3 | `prompts/verdict.ts` `build()` | `templates/verdict.txt` |
| 2.4 | `prompts/interaction-point-detection.ts` `build()` | `templates/interaction-point-detection.txt` |
| 2.5 | `prompts/response.ts` `build()` | `templates/response.txt` |
| 2.6 | `nodes/response.ts` `buildStreamingTextPrompt()` | `templates/response-streaming.txt` |
| 2.7 | `experts/registry.ts` crop_compare.promptTemplate | `templates/experts/crop_compare.txt` |
| 2.8 | `experts/registry.ts` roi_analysis.promptTemplate | `templates/experts/roi_analysis.txt` |
| 2.9 | `experts/registry.ts` pest_risk.promptTemplate | `templates/experts/pest_risk.txt` |

### Phase 3: 重构 `build()` 方法

| 步骤 | 内容 |
|------|------|
| 3.1 | `prompts/intention.ts` — `build()` 内联字符串替换为 `loadTemplate("intention")` + `fillSlots()` |
| 3.2 | `prompts/reasoning.ts` |
| 3.3 | `prompts/verdict.ts` |
| 3.4 | `prompts/interaction-point-detection.ts` |
| 3.5 | `prompts/response.ts` |
| 3.6 | `nodes/response.ts` `buildStreamingTextPrompt()` |

### Phase 4: 适配外部引用

| 步骤 | 内容 | 文件 |
|------|------|------|
| 4.1 | `AnalysisExpert.promptTemplate` 改为路径字符串（如 `"experts/crop_compare"`），推理节点通过 `loadTemplate()` 加载 | `experts/registry.ts` + `nodes/reasoning.ts` |

## 7. 不变部分

- `prompts/{name}.ts` 的 `parse()` / `validate()` 逻辑不动
- `prompts/types.ts` 类型定义不动
- 5 个 `prompts/{name}.ts` 文件保留原路径，仅 `build()` 内部实现从内联字符串改为 `loadTemplate()` + `fillSlots()`
- response-strategy promptHint（8 条）、path-metrics promptFragment（4 条）、quick-action-bar（2 条）属于运行时动态参数或前端默认值，不在模板目录管理范围

## 8. 零破坏性保障

- `PromptTemplate.build()/parse()/validate()` 接口签名不变——外部调用方无感知
- 所有 `.txt` 模板中的 prompt 文本与重构前 `build()` 中的字符串逐字一致
- `npx tsc --noEmit` 每 Phase 后验证零错误

## 9. 验收标准

- [ ] `templates/` 目录下 9 个 .txt 文件创建完成（6 管线 + 3 专家）
- [ ] `load-template.ts` 实现完成
- [ ] 5 个 `prompts/{name}.ts` 的 `build()` 已切换为 `loadTemplate()` + `fillSlots()`
- [ ] `nodes/response.ts` 的 `buildStreamingTextPrompt()` 已切换
- [ ] `experts/registry.ts` 的 `promptTemplate` 字段已改为路径字符串
- [ ] 运行时 LLM prompt 输出与重构前一致
- [ ] `npx tsc --noEmit` 零错误

## 10. 关联文档

- [架构说明书 §十一 Prompt 模板管理](file:///home/xmm/ai/farm-agent/docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md)
- `src/agents/prompts/` — 当前 prompt 目录
- `src/agents/experts/registry.ts` — ANALYSIS_EXPERTS 定义
- `src/agents/nodes/response.ts` — `buildStreamingTextPrompt()`
