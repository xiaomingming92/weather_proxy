# farm-agent-caijuehub-transcription-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。**不要**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-caijuehub-transcription-v1
- **启动时间**: 2026-07-09T00:00:00+08:00
- **主导 AI**: Qoder (Claude 4)
- **关联文档**:
  - 无上游依赖（独立实现）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/caijuehub/strategies/ | STRATEGY | STRATEGY_REFACTORED | 18 个手写策略文件 | caijue.toml 驱动 + 转录生成 | 待实施 |
| src/caijuehub/caijue.toml | CAIJUE_CONFIG | CONFIG_CREATED | 无统一规则索引 | 完整 caijue.toml 映射 18 个策略 | 待实施 |
| src/caijuehub/extractors/ | EXTRACTOR | EXTRACTOR_CREATED | 无提取函数 | 产品文档 → TOML 规则提取器 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

farm-agent 的 `src/caijuehub/strategies/` 有 18 个策略文件（2034 行），全部手写。问题：

1. **规则散落代码中**：`thinking-level.ts` 的裁决逻辑、`retrieval-routing.ts` 的路由规则、`auth-gateway.ts` 的权限检查——修改需要改 TS 代码
2. **产品文档无法驱动代码**：产品经理定义的业务规则（如"用户等级 ≥ VIP3 跳过权限检查"）需要开发手动翻译为代码
3. **caijue.toml 只有索引功能**：当前 `caijue.toml` 只注册策略名称，不包含规则逻辑，没有转录能力
4. **无提取函数**：没有从产品文档到 caijue.toml 的自动化通道

### 1.2 目标

实现完整的三段式裁决生成管线（farm-agent 独立实现全部 4 阶段）：

```
产品文档 → 提取函数 → caijue.toml → 转录引擎 → strategies/*.ts → tsup → dist/
（全部由 farm-agent 独立实现）
```

1. **caijue.toml 完整化**：将 18 个策略文件的规则逻辑转录到 caijue.toml，每个策略段包含完整的规则定义
2. **提取函数实现**：产品文档（结构化格式）→ caijue.toml 规则段，AI 辅助提取
3. **转录引擎实现**：caijue.toml → strategies/*.ts，编译时生成，GENERATED + USER CODE 双区块模式
4. **策略文件迁移**：18 个手写策略逐步迁移到"GENERATED 区块 + USER CODE 区块"模式

---

## 二、方案选型

### 2.1 三段式管线分工

| 阶段 | 输入 | 输出 | 工具 |
|:--:|------|------|------|
| ① | 产品需求文档 | 结构化业务规则 | AI 提取函数 |
| ② | 结构化规则 | `caijue.toml` | 规则引擎 |
| ③ | `caijue.toml` | `strategies/*.ts` | 转录引擎（`src/caijuehub/transcribe.ts`） |
| ④ | `strategies/*.ts` | `dist/` | `tsup` |

### 2.2 策略文件分类

18 个策略文件按可转录度分三类：

| 类型 | 文件 | 行数 | 转录方式 |
|------|------|:--:|------|
| **规则驱动**（完整转录） | `thinking-level.ts`、`sub-intent.ts`、`retrieval-routing.ts`、`retrieval-confidence.ts`、`discipline-resolver.ts`、`event-consumer-strategies.ts`、`evidence-source.ts`、`sse-terminal-event.ts`、`resolve-tool-params.ts` | ~1200 | TOML 规则 → 100% 生成 |
| **混合型**（规则骨架 + 手写逻辑） | `auth-gateway.ts`、`h5-auth-gateway.ts`、`service-auth-resolver.ts`、`agrisynapse-handshake.ts`、`h5-handshake-thread.ts`、`interaction.ts`、`response.ts` | ~650 | TOML 生成骨架，保留 USER CODE 区块 |
| **逻辑驱动**（保留手写） | `policy-updateLoop-decisions.ts`、`response.test.ts` | ~180 | 暂不转录，仅注册到 caijue.toml 索引 |

### 2.3 caijue.toml 扩展结构

```toml
# farm-agent caijue.toml — 完整规则索引

[meta]
project = "farm-agent"

# ──── 规则驱动段 ────

[thinking_level]
# 裁决逻辑：根据 intent + subIntents 决定图类型
transcribe = "full"  # 100% 转录
[[thinking_level.rules]]
intent = "chat"
sub_intents_min = 0
graph = "fast"

[[thinking_level.rules]]
intent = "multi"
sub_intents_min = 2
graph = "professional"

[retrieval_routing]
transcribe = "full"
[[retrieval_routing.rules]]
source = "knowledge_base"
priority = 1
collection = "expert_{domain}"

[sub_intent]
transcribe = "full"
[[sub_intent.rules]]
pattern = "天气|气象|降水|温度"
category = "weather"

# ──── 混合型段 ────

[auth_gateway]
transcribe = "partial"  # 生成骨架，保留 USER CODE
[[auth_gateway.rules]]
condition = "!request.headers.authorization"
action = "reject"
reason = "缺少认证头"

# ──── 逻辑驱动段（仅索引） ────

[policy_update_loop]
transcribe = "none"  # 不转录，仅注册
file = "strategies/policy-updateLoop-decisions.ts"

[response]
transcribe = "none"
file = "strategies/response.ts"
```

### 2.4 提取函数设计

产品文档 → caijue.toml 的提取流程：

```
产品文档（Markdown 表格）         提取函数                  caijue.toml 规则段
─────────────────────────    →    ────────    →    ─────────────────────
| 条件              | 动作    |   解析表格行   |    [[auth_gateway.rules]]
| user.level >= 3   | skip   |   映射到 TOML   |    condition = "user.level >= 3"
| user.level < 3    | check  |   输出规则段    |    action = "skip"
```

提取函数实现为 `src/caijuehub/extractors/` 目录下的模块，每个策略域一个提取器。AI 辅助解析产品文档中的结构化表格，输出对应的 caijue.toml 规则段。

---

## 三、架构设计

### 3.1 数据流转

```
产品经理更新需求文档
        │
        ▼
① AI 提取函数（src/caijuehub/extractors/）
   → 解析产品文档中的结构化业务规则
   → 输出 caijue.toml 规则段
        │
        ▼
② caijue.toml（统一规则索引）
   → 18 个策略域的完整规则定义
   → 标记 transcribe 模式（full/partial/none）
        │
        ▼
③ 转录引擎（src/caijuehub/transcribe.ts）
   → 读取 caijue.toml
   → 遍历规则段，生成 TypeScript 策略文件
   → GENERATED 区块覆盖，USER CODE 区块保留
        │
        ▼
④ tsup 编译
   → strategies/*.ts → dist/
```

### 3.2 目录结构增量

```
farm-agent/
├── src/
│   └── caijuehub/
│       ├── caijue.toml              # ★ 完整规则索引（替代当前仅索引版本）
│       ├── strategies/              # 现有 18 个手写策略（逐步迁移）
│       │   ├── detect.strategy.ts   # ← 转录生成（GENERATED 区块）
│       │   ├── auth.strategy.ts     # ← 转录生成 + USER CODE 区块
│       │   └── ...
│       └── extractors/              # ★ 新增：产品文档提取器
│           ├── auth-extractor.ts    # 权限规则提取
│           ├── routing-extractor.ts # 路由规则提取
│           └── thinking-extractor.ts # 裁决规则提取
├── docs/
│   └── 大田精准耕播智能决策系统/
│       └── knowledge/
│           └── 03-规范/
│               └── caijue-rules/    # ★ 产品文档中的结构化规则
│                   ├── auth-rules.md
│                   ├── routing-rules.md
│                   └── thinking-rules.md
```

### 3.3 策略文件迁移模式

```typescript
// strategies/thinking-level.strategy.ts（转录后）
// ⚠️ 自动生成，不要手动编辑！改 caijue.toml 后重新运行转录引擎

import type { ThinkingLevelInput, ThinkingLevelOutput } from "./types";

export function resolveThinkingLevel(input: ThinkingLevelInput): ThinkingLevelOutput {
  // >>> CAIJUE GENERATED START >>>
  // 以下代码由转录引擎从 caijue.toml [thinking_level] 段生成
  if (input.intent === "chat" && input.subIntents.length === 0) {
    return { graph: "fast" };
  }
  if (input.intent === "multi" && input.subIntents.length >= 2) {
    return { graph: "professional" };
  }
  // <<< CAIJUE GENERATED END <<<

  // >>> USER CODE: 自定义复杂逻辑 >>>
  // 以下代码不会在 generate 时被覆盖
  if (input.context?.forceDeep) {
    return { graph: "deep" };
  }
  return { graph: "fast" };
  // <<< USER CODE END <<<
}
```

---

## 四、实施 Task + 依赖图

```
Task 0: caijue.toml 完整化（规则驱动段）
           │
           ▼
Task 1: caijue.toml 完整化（混合型 + 逻辑驱动段）
           │
           ▼
Task 2: 提取函数实现（auth-extractor + routing-extractor）
           │
           ▼
Task 3: 提取函数实现（thinking-extractor + 其余）
           │
           ▼
Task 4: 转录引擎实现（src/caijuehub/transcribe.ts）
           │
           ▼
Task 5: 策略文件迁移（GENERATED + USER CODE 区块）
           │
           ▼
Task 6: 测试 + 文档 + devlog
```

### Task 0: caijue.toml 完整化 — 规则驱动段

**范围**：`src/caijuehub/caijue.toml`

- 映射 `thinking-level.ts`（53 行）→ `[thinking_level]` 段
- 映射 `sub-intent.ts`（233 行）→ `[sub_intent]` 段
- 映射 `retrieval-routing.ts` → `[retrieval_routing]` 段
- 映射 `retrieval-confidence.ts` → `[retrieval_confidence]` 段
- 映射 `discipline-resolver.ts` → `[discipline_resolver]` 段
- 映射 `event-consumer-strategies.ts` → `[event_consumer]` 段
- 映射 `evidence-source.ts` → `[evidence_source]` 段
- 映射 `sse-terminal-event.ts` → `[sse_terminal]` 段
- 映射 `resolve-tool-params.ts` → `[resolve_tool_params]` 段
- 每个段标记 `transcribe = "full"`

**验收**：`caijue.toml` 包含 9 个规则驱动段，每个段至少 1 条规则

### Task 1: caijue.toml 完整化 — 混合型 + 逻辑驱动段

**范围**：`src/caijuehub/caijue.toml`（续）

- 映射 `auth-gateway.ts` → `[auth_gateway]` 段（`transcribe = "partial"`）
- 映射 `h5-auth-gateway.ts` → `[h5_auth_gateway]` 段
- 映射 `service-auth-resolver.ts` → `[service_auth]` 段
- 映射 `agrisynapse-handshake.ts` → `[agrisynapse_handshake]` 段
- 映射 `h5-handshake-thread.ts` → `[h5_handshake]` 段
- 映射 `interaction.ts` → `[interaction]` 段
- 映射 `response.ts` → `[response]` 段
- 映射 `policy-updateLoop-decisions.ts` → `[policy_update_loop]` 段（`transcribe = "none"`）
- 映射 `response.test.ts` → 不转录（测试文件）

**验收**：`caijue.toml` 包含全部 18 个策略域的索引，每个段标记正确的 transcribe 模式

### Task 2: 提取函数实现 — auth + routing

**范围**：`src/caijuehub/extractors/`

- 创建 `src/caijuehub/extractors/auth-extractor.ts`：解析 `docs/.../caijue-rules/auth-rules.md` → `[auth_gateway]` + `[h5_auth_gateway]` + `[service_auth]` 段
- 创建 `src/caijuehub/extractors/routing-extractor.ts`：解析 `docs/.../caijue-rules/routing-rules.md` → `[retrieval_routing]` + `[retrieval_confidence]` 段
- 创建产品文档模板 `docs/.../caijue-rules/auth-rules.md`（结构化表格格式）

**验收**：提取器能正确解析产品文档表格，输出合法的 caijue.toml 规则段

### Task 3: 提取函数实现 — thinking + 其余

**范围**：`src/caijuehub/extractors/`（续）

- 创建 `thinking-extractor.ts`：解析 `thinking-rules.md` → `[thinking_level]` + `[sub_intent]` + `[discipline_resolver]` 段
- 创建 `handshake-extractor.ts`：解析 `handshake-rules.md` → `[agrisynapse_handshake]` + `[h5_handshake]` 段
- 创建 `event-extractor.ts`：解析 `event-rules.md` → `[event_consumer]` + `[sse_terminal]` 段
- 创建其余产品文档模板

**验收**：全部提取器可独立运行，输出合法 caijue.toml 规则段

### Task 4: 转录引擎实现

**范围**：`src/caijuehub/transcribe.ts`

- 依赖 `smol-toml`（~2KB，零依赖，纯 ESM）
- 实现 TOML 读取 → 规则遍历 → TS 代码生成
- 生成逻辑：`[detect]` 段 → `if-else` 链，`[routing]` 段 → `switch` 语句
- 支持 `transcribe` 模式：`full`（100% 生成）、`partial`（骨架 + 保留 USER CODE）、`none`（仅索引）
- 集成到 `tsup` build 前：`"prebuild": "tsx src/caijuehub/transcribe.ts"`

**验收**：`tsx src/caijuehub/transcribe.ts` 从 caijue.toml 生成正确的 strategies/*.ts

### Task 5: 策略文件迁移

**范围**：`src/caijuehub/strategies/`

- 规则驱动类（9 个）：全部替换为 GENERATED 区块，删除手写实现
- 混合型（7 个）：提取规则逻辑到 caijue.toml，保留复杂逻辑在 USER CODE 区块
- 逻辑驱动类（2 个）：保留手写，不做迁移
- 验证：`tsc --noEmit` 通过，现有测试全部通过

**验收**：`grep -r "CAIJUE GENERATED" strategies/` 返回 ≥ 9 个匹配

### Task 6: 测试 + 文档 + devlog

- 测试：提取函数单元测试 + 转录引擎集成测试
- 更新 `docs/.../caijue-rules/` 目录下的产品文档模板
- 更新架构文档反映 caijuehub 三段式管线
- 调用 MCP `record_dev_operation` 落库 ADD 开发日志

---

## 五、验收标准

- [ ] `caijue.toml` 包含全部 18 个策略域的完整规则定义
- [ ] 提取函数能正确解析产品文档，输出合法 caijue.toml 规则段
- [ ] 转录引擎能从 caijue.toml 生成正确的 strategies/*.ts
- [ ] 规则驱动类策略文件 100% 由转录生成，不含手写 if-else
- [ ] 混合型策略文件正确保留 USER CODE 区块
- [ ] `tsc --noEmit` 通过
- [ ] 现有测试全部通过（策略行为不变）
- [ ] 修改 caijue.toml 规则 → 重新 generate → 策略行为随之改变

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|:--:|
| 转录引擎 | `src/caijuehub/transcribe.ts` | 待实施 |
| ADD Route | 待创建 | ⬜ |
| Handoff | 待创建 | ⬜ |
| Review | 待创建 | ⬜ |
| Spec | 待创建 | ⬜ |
| Tasks | 待创建 | ⬜ |
| Checklist | 待创建 | ⬜ |