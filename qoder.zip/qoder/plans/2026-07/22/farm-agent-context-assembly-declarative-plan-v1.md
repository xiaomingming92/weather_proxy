# Context Assembly 声明式化 — 从硬编码到配置驱动

> **Plan ID**: farm-agent-context-assembly-declarative-plan-v1
> **创建日期**: 2026-07-22
> **状态**: Draft（Review v1 回流后）
> **Review**: `.qoder/reviews/farm-agent-context-assembly-declarative-review-v1.md`

---

## §1. 背景与动机

### 1.1 问题现状

farm-agent 的 AgentState 字段定义是声明式的（Annotation），但**上下文装配逻辑**（哪些字段在什么时机、以什么形式注入 LLM prompt）散落在多个节点文件中硬编码。这导致：

1. **可扩展性差**：新增上下文层（如 Episodic Memory）需要修改多个节点文件
2. **职责不清**：同一个 `state.toolResults` 被 reasoning.ts、response.ts、summary-reasoning.ts 等 6 个节点各自读取和转换
3. **测试困难**：上下文装配逻辑与节点推理逻辑耦合，无法独立测试

### 1.2 目标

将上下文装配从"节点内硬编码"改为"声明式配置 + 运行时解析"：

- 在 `caijue.toml` 中声明每个上下文层的来源、转换规则、注入条件
- 运行时由 `ContextAssemblyProvider` 统一解析配置、读取 AgentState、构建上下文
- 节点只需调用 `provider.buildLayer("tool_summary", context)` 获取预制上下文

### 1.3 与 Agent 系统演进路线图的对齐

本 Plan 对应路线图 **Phase 1（当前阶段）：上下文工程化——从硬编码到声明式配置**。

路线图明确指出：
> "当前系统的上下文装配逻辑高度硬编码。agent-runner.ts 中的 prebuiltThinkingLevel、prebuiltMassifIds 等字段是临时性设计，缺乏声明式配置。这导致新增上下文来源（如长期记忆、跨会话事实）需要修改核心代码。"

### 1.4 范围界定

| 模块 | 本 Plan 是否涉及 | 说明 |
|------|:---:|------|
| `StreamAgentInput` 预构建字段 | ✅ | 将 `prebuilt*` 字段纳入声明式配置 |
| `AgentState` Annotation 定义 | ✅ | 新增 `contextLayers` Annotation |
| Context Layer Provider 模块 | ✅ | 新建 `src/agents/context-assembly/` 目录 |
| `caijue.toml` 配置段 | ✅ | 新增 `[context-assembly]` 声明式配置段 |
| 节点层 `state.*` 消费重构 | ✅ | 6 个节点的 `state.toolResults` / `state.messages` / `state.expertPackages` 等直接访问改为通过 `ContextAssemblyProvider` 获取 |
| Prompt Engine 模板层 | ❌ | 由 prompt-engine-structured-output-plan 负责 |
| 长期记忆存储层 | ❌ | 由后续 Episodic Memory Plan 负责 |
| 评测框架 | ❌ | 由后续 Evaluation Plan 负责 |

### 1.5 核心设计原则

1. **声明式优先**：上下文层的来源、转换、注入条件均通过 `caijue.toml` 的 `[context-assembly]` 段配置，不硬编码
2. **运行时解析**：`resolveContextConfig()` 读取 caijue.toml，与现有 `resolveToolResultFreshness()` 等策略函数同构
3. **向后兼容**：现有 `prebuilt*` 字段保留，新增 `contextLayers` 作为统一入口
4. **分层隔离**：每个上下文层（LLM 输入 / Agent 执行 / 记忆）独立注册、独立构建、独立降级

---

## §2. 现状基线

### 2.1 当前 AgentState 字段清单

```typescript
// src/agents/state.ts
export const AgentState = Annotation.Root({
  // ──── 预构建字段（StreamAgentInput 透传）────
  prebuiltThinkingLevel: Annotation<ThinkingLevel | null>(),     // L125
  prebuiltSubIntents: Annotation<SubIntent[] | null>(),           // L127
  prebuiltExpertPlan: Annotation<Expert[] | null>(),              // L129
  prebuiltMassifIds: Annotation<number[] | null>(),               // L135

  // ──── 工具结果字段（ToolNode 写入，多节点消费）────
  toolResults: Annotation<Array<{ toolName, success, ... }>>(),   // L151

  // ──── 空间推理字段（spatialPreprocessing 写入）────
  spatialRegions: Annotation<VoronoiRegion[] | null>(),           // L161
  managementZones: Annotation<ManagementZone[] | null>(),         // L166

  // ──── 专家推理字段（retrieval/reasoning 写入）────
  expertPackages: Annotation<ExpertReasoningPackage[] | null>(),  // L149
  expertClaims: Annotation<ExpertClaim[] | null>(),               // L179
  evidenceChain: Annotation<Evidence[] | null>(),                 // L110

  // ──── 基础字段 ────
  messages: MessagesAnnotation,                                    // L106
  // ... 其余字段省略
})
```

### 2.2 硬编码位置清单（已核验）

硬编码散布在**两层**：Annotation 定义层（`state.ts`）和节点消费层（6 个节点文件）。

#### 层一：Annotation 定义层（`state.ts`）

| 文件 | 行号 | 字段 | 当前类型 | 问题 |
|------|------|------|---------|------|
| `state.ts` | L125 | `prebuiltThinkingLevel` | `ThinkingLevel \| null` | Annotation 类型正确 |
| `state.ts` | L127 | `prebuiltSubIntents` | `SubIntent[] \| null` | 无 |
| `state.ts` | L129 | `prebuiltExpertPlan` | `Expert[] \| null` | 无 |
| `state.ts` | L135 | `prebuiltMassifIds` | `number[] \| null` | 无 |
| `state.ts` | L149 | `expertPackages` | `ExpertReasoningPackage[] \| null` | 无 |
| `state.ts` | L151 | `toolResults` | `Array<{...}>` | 无 |
| `state.ts` | L161 | `spatialRegions` | `VoronoiRegion[] \| null` | 无 |
| `state.ts` | L166 | `managementZones` | `ManagementZone[] \| null` | 无 |
| `state.ts` | L179 | `expertClaims` | `ExpertClaim[] \| null` | 无 |

#### 层一附：StreamAgentInput 接口层（`agent-runner.ts`）

| 文件 | 行号 | 字段 | 当前类型 | 问题 |
|------|------|------|---------|------|
| `agent-runner.ts` | L87 | `prebuiltThinkingLevel` | `string \| null` | **类型不一致**：state.ts 是 `ThinkingLevel`，这里是 `string`，需统一 |
| `agent-runner.ts` | L89 | `prebuiltSubIntents` | `Array<{...}> \| null` | 无 |
| `agent-runner.ts` | L91 | `prebuiltExpertPlan` | `Array<{...}> \| null` | 无 |
| `agent-runner.ts` | L93 | `prebuiltMassifIds` | `number[] \| null` | 无 |

#### 层二：节点消费层（6 个节点文件，真正的硬编码重灾区）

| 文件 | 行号 | 硬编码内容 | 改造目标 |
|------|------|-----------|---------|
| `reasoning.ts` | L130 | `state.toolResults ?? []` 直接读取 | 改为 `provider.buildLayer("tool_summary")` |
| `reasoning.ts` | L204 | `state.expertPackages as ExpertReasoningPackage[]` | 改为 `provider.buildLayer("expert_context")` |
| `reasoning.ts` | L236 | 从 `state.messages` 按 realtimeToolNames 归集 | 改为 `provider.buildLayer("tool_summary")` |
| `reasoning.ts` | L525 | `state.toolResults` 构建快速查找表 | 改为 `provider.buildLayer("tool_summary")` |
| `response.ts` | L128 | `state.messages as Array<...>` 传给 buildToolExecutionSummary | 改为 `provider.buildLayer("tool_summary")` |
| `response.ts` | L132 | `state.toolResults as Array<...>` 类型断言 | 改为 `provider.buildLayer("tool_summary")` |
| `response.ts` | L146 | `state.managementZones` 直接读取 | 改为 `provider.buildLayer("spatial")` |
| `response.ts` | L147 | `state.toolResults` 直接读取（isSummary 分支） | 改为 `provider.buildLayer("tool_summary")` |
| `summary-reasoning.ts` | L61-63 | `state.spatialRegions` + `state.managementZones` + `state.toolResults` | 改为 `provider.buildLayer("spatial")` + `provider.buildLayer("tool_summary")` |
| `summary-reasoning.ts` | L96 | `state.evidenceChain?.length` | 改为 `provider.buildLayer("evidence")` |
| `intention.ts` | L105 | `state.messages` 遍历查找最后用户消息 | 改为 `provider.buildLayer("llm_input")` |
| `coordination-dialogue.ts` | L64 | `state.expertClaims` 直接读取 | 改为 `provider.buildLayer("expert_context")` |
| `spatial-preprocessing.ts` | L59-60 | `state.spatialRegions` + `state.toolResults` | 改为 `provider.buildLayer("spatial")` + `provider.buildLayer("tool_summary")` |

### 2.3 当前上下文装配模式

```
API Route → agent-runner.runAgent()
  → agent.invoke(input, config)
    → intention 节点：硬编码读取 state.messages 查找用户意图
    → reasoning 节点：硬编码读取 state.toolResults + state.expertPackages + state.messages
    → response 节点：硬编码读取 state.messages + state.toolResults + state.managementZones
    → summary-reasoning 节点：硬编码读取 state.spatialRegions + state.managementZones + state.toolResults + state.evidenceChain
    → coordination-dialogue 节点：硬编码读取 state.expertClaims
```

**问题**：每个节点各自从 AgentState 读取字段、各自转换格式、各自处理降级。无统一管理。

### 2.4 数据流图（完整版）

```
API Route
  │  构造 StreamAgentInput（prebuilt* 字段）
  ▼
agent-runner.runAgent()
  │  input → agent.invoke()
  ▼
StateGraph 节点执行
  │
  ├── intention.ts
  │     硬编码: state.messages 遍历查找最后用户消息
  │
  ├── reasoning.ts
  │     硬编码: state.toolResults + state.expertPackages + state.messages
  │
  ├── response.ts
  │     硬编码: state.messages + state.toolResults + state.managementZones
  │
  ├── summary-reasoning.ts
  │     硬编码: state.spatialRegions + state.managementZones + state.toolResults + state.evidenceChain
  │
  ├── coordination-dialogue.ts
  │     硬编码: state.expertClaims
  │
  └── spatial-preprocessing.ts
        硬编码: state.spatialRegions + state.toolResults
```

**改造后数据流**：

```
API Route
  │  构造 StreamAgentInput（prebuilt* 字段）
  ▼
agent-runner.runAgent()
  │  初始化 ContextAssemblyProvider（读取 caijue.toml [context-assembly] 段）
  │  注入 config.configurable.contextAssemblyProvider
  ▼
StateGraph 节点执行
  │
  ├── intention.ts
  │     const llmInput = await provider.buildLayer("llm_input", context)
  │
  ├── reasoning.ts
  │     const toolSummary = await provider.buildLayer("tool_summary", context)
  │     const expertCtx = await provider.buildLayer("expert_context", context)
  │
  ├── response.ts
  │     const toolSummary = await provider.buildLayer("tool_summary", context)
  │     const spatialCtx = await provider.buildLayer("spatial", context)
  │
  ├── summary-reasoning.ts
  │     const spatialCtx = await provider.buildLayer("spatial", context)
  │     const toolSummary = await provider.buildLayer("tool_summary", context)
  │     const evidence = await provider.buildLayer("evidence", context)
  │
  ├── coordination-dialogue.ts
  │     const expertCtx = await provider.buildLayer("expert_context", context)
  │
  └── spatial-preprocessing.ts
        const spatialCtx = await provider.buildLayer("spatial", context)
        const toolSummary = await provider.buildLayer("tool_summary", context)
```

---

## §3. 方案设计

### 3.1 核心抽象：ContextLayerProvider

```typescript
// src/agents/context-assembly/provider.ts

export interface ContextLayerConfig {
  /** 层 ID（唯一标识） */
  id: string
  /** 数据来源：AgentState 字段名列表 */
  source: Array<keyof AgentStateType>
  /** 转换器：将原始字段值转为 LLM 可消费的上下文 */
  transform: "passthrough" | "tool_summary" | "spatial_digest" | "evidence_chain" | "expert_package"
  /** 降级策略：数据缺失时的行为 */
  fallback: "skip" | "empty_array" | "null"
  /** 可选：最大 token 预算（裁剪用） */
  maxTokens?: number
}

export interface ContextAssemblyConfig {
  layers: ContextLayerConfig[]
}

export class ContextAssemblyProvider {
  private config: ContextAssemblyConfig

  constructor(config: ContextAssemblyConfig) {
    this.config = config
  }

  /** 构建指定层的上下文 */
  async buildLayer(layerId: string, context: AgentAssemblyContext): Promise<ContextLayer | null> {
    const layerConfig = this.config.layers.find(l => l.id === layerId)
    if (!layerConfig) return null

    // 从 AgentState 读取源数据
    const rawData = this.extractSourceData(layerConfig, context.state)

    // 降级检查
    if (this.isDataMissing(rawData)) {
      return this.applyFallback(layerConfig)
    }

    // 转换
    const transformed = await this.applyTransform(layerConfig.transform, rawData, context)

    return {
      id: layerConfig.id,
      data: transformed,
      tokenEstimate: estimateTokens(transformed),
    }
  }

  /** 批量构建所有层 */
  async buildAllLayers(context: AgentAssemblyContext): Promise<ContextLayer[]> {
    const results = await Promise.all(
      this.config.layers.map(l => this.buildLayer(l.id, context))
    )
    return results.filter((l): l is ContextLayer => l !== null)
  }
}
```

### 3.2 caijue.toml 配置段设计

```toml
# src/caijuehub/caijue.toml 新增段

[context-assembly]

# ──── LLM 输入上下文层 ────
[[context-assembly.layers]]
id = "llm_input"
source = ["messages"]
transform = "passthrough"
fallback = "skip"

# ──── Agent 执行上下文层 ────
[[context-assembly.layers]]
id = "tool_summary"
source = ["toolResults", "spatialRegions"]
transform = "tool_summary"
fallback = "empty_array"

[[context-assembly.layers]]
id = "expert_context"
source = ["expertPackages", "expertClaims"]
transform = "expert_package"
fallback = "skip"

[[context-assembly.layers]]
id = "spatial"
source = ["spatialRegions", "managementZones"]
transform = "spatial_digest"
fallback = "null"

[[context-assembly.layers]]
id = "evidence"
source = ["evidenceChain"]
transform = "evidence_chain"
fallback = "empty_array"
```

### 3.3 声明式配置解析：resolveContextConfig()

```typescript
// src/caijuehub/strategies/context-assembly.ts
// 与现有 resolveToolResultFreshness() / resolveAwareness() 同构

import { readCaijueToml } from "@/caijuehub/config"
import type { ContextAssemblyConfig } from "@/agents/context-assembly/provider"

export function resolveContextConfig(): ContextAssemblyConfig {
  const toml = readCaijueToml()
  const layers = toml["context-assembly"]?.layers ?? []

  return {
    layers: layers.map((l: Record<string, unknown>) => ({
      id: l.id as string,
      source: l.source as Array<keyof AgentStateType>,
      transform: l.transform as ContextLayerConfig["transform"],
      fallback: l.fallback as ContextLayerConfig["fallback"],
      maxTokens: l.maxTokens as number | undefined,
    })),
  }
}
```

### 3.4 与现有模块的集成点

```
caijue.toml [context-assembly]
  │  resolveContextConfig() 读取
  ▼
ContextAssemblyProvider
  │  注入 config.configurable.contextAssemblyProvider
  ▼
StateGraph 节点
  │  provider.buildLayer("tool_summary", context)
  │
  ├── tool_summary 层内部调用：
  │     import { aggregateToolResults } from "@/agents/prompts/tool-result-aggregator"
  │     → 消费 state.toolResults + state.spatialRegions
  │     → 产出 AggregationResult（区域汇总/趋势/异常）
  │
  ├── spatial 层内部调用：
  │     import { buildSpatialDigest } from "@/agents/prompts/awareness"
  │     → 消费 state.spatialRegions + state.managementZones
  │
  └── expert_context 层内部调用：
        import { buildAnalysisExpertContext } from "@/agents/nodes/reasoning"（迁移）
        → 消费 state.expertPackages + state.expertClaims
```

### 3.5 依赖图

```
farm-agent-spatial-reasoning-plan-v3
  │  产出 aggregateToolResults（轮次1）
  │  产出 buildSpatialDigest（轮次5）
  ▼
farm-agent-context-assembly-declarative-plan-v1（本 Plan）
  │  产出 ContextAssemblyProvider
  │  产出 caijue.toml [context-assembly] 段
  │  产出 resolveContextConfig()
  ▼
farm-agent-prompt-engine-structured-output-plan-v1
  │  消费 ContextAssemblyProvider.buildLayer() 的产出
  │  注入到 PromptTemplate.build() 中
```

### 3.6 向后兼容策略

1. **`prebuilt*` 字段保留**：不删除现有 `prebuiltThinkingLevel` 等字段，新增 `contextLayers` 作为统一入口
2. **渐进式迁移**：节点可逐步从 `state.toolResults` 迁移到 `provider.buildLayer("tool_summary")`，迁移期间两者并存
3. **降级路径**：如果 caijue.toml 缺少 `[context-assembly]` 段，`resolveContextConfig()` 返回空配置，节点回退到硬编码路径

---

## §4. 实施任务清单

### Task 4.1: 统一 `prebuiltThinkingLevel` 类型

**目标**：修复 `agent-runner.ts` 与 `state.ts` 之间的类型不一致。

**改动文件**：
- `src/agents/agent-runner.ts` L87 — `prebuiltThinkingLevel?: string | null` 改为 `ThinkingLevel | null`

**验收**：`tsc --noEmit` 零错误

---

### Task 4.2: caijue.toml 新增 `[context-assembly]` 段 + resolveContextConfig()

**目标**：在 caijue.toml 中声明 5 个上下文层的配置，新建策略解析函数。

**改动文件**：
- `src/caijuehub/caijue.toml` — 新增 `[context-assembly]` 段（5 个 layers 定义）
- `src/caijuehub/strategies/context-assembly.ts`（新增）— `resolveContextConfig()`
- `src/caijuehub/caijue.toml` — `[[caijue]]` 表新增 `resolve-context-assembly` 条目

**验收**：
- `resolveContextConfig()` 返回 5 个 layer 配置
- caijue.toml 的 `[[caijue]]` 表包含 context-assembly 裁决登记

---

### Task 4.3: 新建 ContextLayerProvider 模块

**目标**：实现核心抽象——Provider + Config + Layer 类型。

**改动文件**：
- `src/agents/context-assembly/provider.ts`（新增）— `ContextAssemblyProvider` 类
- `src/agents/context-assembly/types.ts`（新增）— `ContextLayerConfig` / `ContextLayer` / `AgentAssemblyContext` 类型
- `src/agents/context-assembly/transforms.ts`（新增）— 5 个 transform 函数

**关键集成**：
- `tool_summary` transform 内部调用 `aggregateToolResults()`（来自 `src/agents/prompts/tool-result-aggregator/`，由 spatial-reasoning-plan 轮次1 产出）
- `spatial` transform 内部调用 `buildSpatialDigest()`（来自 `src/agents/prompts/awareness.ts`，由 spatial-reasoning-plan 轮次5 产出）

**验收**：
- `provider.buildLayer("tool_summary", context)` 返回正确的 AggregationResult
- `provider.buildLayer("spatial", context)` 返回正确的 SpatialDigest
- 单元测试覆盖 5 个 transform

---

### Task 4.4: AgentState 新增 `contextLayers` Annotation

**目标**：在 AgentState 中新增统一的上下文层入口字段。

**改动文件**：
- `src/agents/state.ts` — 新增 `contextLayers: Annotation<ContextLayer[] | null>()`

**验收**：`tsc --noEmit` 零错误

---

### Task 4.5: agent-runner.ts 注入 ContextAssemblyProvider

**目标**：在 Agent 入口处初始化 Provider 并注入 config.configurable。

**改动文件**：
- `src/agents/agent-runner.ts` — `runAgent()` / `streamAgent()` 中初始化 Provider

**改动逻辑**：
```typescript
// agent-runner.ts runAgent() 中新增
const contextConfig = resolveContextConfig()
const contextAssemblyProvider = new ContextAssemblyProvider(contextConfig)

return await agent.invoke(input, {
  ...config,
  configurable: {
    ...config?.configurable,
    contextAssemblyProvider,
  },
  callbacks: [new AuditCallback(traceId, userId)],
})
```

**验收**：`config.configurable.contextAssemblyProvider` 在节点中可访问

---

### Task 4.6: 节点层 state.* 消费重构（按风险从低到高）

**目标**：逐步将 6 个节点的 `state.*` 直接访问改为 `provider.buildLayer()` 调用。

**改造顺序**（按风险和复杂度从低到高）：

#### 4.6.1 coordination-dialogue.ts（最简单）

- L64: `state.expertClaims` → `provider.buildLayer("expert_context", context)`
- 影响行数：~5 行

#### 4.6.2 intention.ts（简单）

- L105: `state.messages` 遍历 → `provider.buildLayer("llm_input", context)`
- 影响行数：~10 行

#### 4.6.3 response.ts（中等）

- L128: `state.messages` → `provider.buildLayer("llm_input", context)`
- L132: `state.toolResults` → `provider.buildLayer("tool_summary", context)`
- L146: `state.managementZones` → `provider.buildLayer("spatial", context)`
- L147: `state.toolResults` → `provider.buildLayer("tool_summary", context)`
- 影响行数：~20 行

#### 4.6.4 reasoning.ts（最复杂）

- L130: `state.toolResults ?? []` → `provider.buildLayer("tool_summary", context)`
- L204: `state.expertPackages` → `provider.buildLayer("expert_context", context)`
- L236: `state.messages` 归集 → `provider.buildLayer("tool_summary", context)`
- L525: `state.toolResults` 查找表 → `provider.buildLayer("tool_summary", context)`
- 影响行数：~40 行

#### 4.6.5 summary-reasoning.ts（需与 spatial-reasoning 对齐）

- L61-63: `state.spatialRegions` + `state.managementZones` + `state.toolResults` → `provider.buildLayer("spatial")` + `provider.buildLayer("tool_summary")`
- L96: `state.evidenceChain?.length` → `provider.buildLayer("evidence", context)`
- 影响行数：~15 行

#### 4.6.6 spatial-preprocessing.ts（需与 spatial-reasoning 对齐）

- L59-60: `state.spatialRegions` + `state.toolResults` → `provider.buildLayer("spatial")` + `provider.buildLayer("tool_summary")`
- 影响行数：~10 行

**验收**：
- 每个节点改造后独立运行 `tsc --noEmit`
- 端到端测试：用户发送消息 → Agent 正常响应 → 上下文内容与改造前一致

---

### Task 4.7: 单元测试

**目标**：为 ContextAssemblyProvider 和 resolveContextConfig() 编写单元测试。

**改动文件**：
- `tests/context-assembly.test.ts`（新增）

**测试用例**：
1. `resolveContextConfig()` 正确解析 caijue.toml 的 `[context-assembly]` 段
2. `provider.buildLayer("tool_summary")` 正确调用 `aggregateToolResults()`
3. `provider.buildLayer("spatial")` 正确调用 `buildSpatialDigest()`
4. 降级策略：`source` 字段缺失时按 `fallback` 配置处理
5. `buildAllLayers()` 批量构建所有层

**验收**：`vitest run tests/context-assembly.test.ts` 全部通过

---

## §5. 验收标准

- [ ] Task 4.1: `prebuiltThinkingLevel` 类型统一为 `ThinkingLevel | null`
- [ ] Task 4.2: caijue.toml 包含 `[context-assembly]` 段（5 个 layers），`resolveContextConfig()` 可解析
- [ ] Task 4.3: `ContextAssemblyProvider` 可构建 5 个层，单元测试通过
- [ ] Task 4.4: `AgentState.contextLayers` Annotation 存在
- [ ] Task 4.5: `agent-runner.ts` 注入 Provider，节点可访问
- [ ] Task 4.6: 6 个节点的 `state.*` 直接访问改为 `provider.buildLayer()`
- [ ] Task 4.7: 单元测试全部通过
- [ ] 端到端：用户发送消息 → Agent 正常响应 → 上下文内容与改造前一致

---

## §6. 恢复上下文审计查询

### 6.1 总体一键恢复

```
keyword: context-assembly-declarative
```

### 6.2 逐任务审计查询

| 任务 | targetId | keyword |
|------|----------|---------|
| caijue.toml 配置段 | caijue.toml | context-assembly |
| resolveContextConfig | context-assembly.ts | resolve-context-config |
| ContextAssemblyProvider | provider.ts | context-layer-provider |
| 节点重构 | reasoning.ts, response.ts 等 | provider.buildLayer |

### 6.3 恢复判定标准

- `grep -r "context-assembly" src/caijuehub/caijue.toml` 命中 ≥ 1 → 配置段已就位
- `grep -r "resolveContextConfig" src/caijuehub/strategies/` 命中 ≥ 1 → 解析函数已就位
- `grep -r "buildLayer" src/agents/nodes/` 命中 ≥ 6 → 节点重构完成
- `grep -r "state\.toolResults" src/agents/nodes/reasoning.ts` 命中 = 0 → reasoning.ts 硬编码已清除

---

## §7. 风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| 节点改造期间功能回归 | 上下文内容变化导致 LLM 输出异常 | 逐节点改造 + 每个节点改造后端到端验证 |
| caijue.toml 配置错误 | Provider 构建失败 | `resolveContextConfig()` 缺省返回空配置，节点回退硬编码 |
| `aggregateToolResults()` 接口变化 | tool_summary 层构建失败 | 依赖 spatial-reasoning-plan 轮次1 先完成并稳定 |
| `prebuiltThinkingLevel` 类型统一 | API Route 调用方需同步修改 | 先在 agent-runner.ts 内部做类型断言兼容，后续统一 |

---

## §8. 关联文档

| 文档 | 路径 |
|------|------|
| Agent 系统演进架构路线图 | `docs/Agent系统演进架构路线图-v1.md` |
| 空间推理 Plan（上游依赖） | `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-plan-v3.md` |
| Prompt Engine 结构化输出 Plan（下游消费） | `.qoder/plans/2026-07/22/farm-agent-prompt-engine-structured-output-plan-v1.md` |
| 差距 Review | `.qoder/reviews/farm-agent-vs-industry-gap-review-v1.md` |
| 本 Plan Review | `.qoder/reviews/farm-agent-context-assembly-declarative-review-v1.md` |
