# Prompt Engine 结构化输出演进 Plan

> **Plan ID**: `farm-agent-prompt-engine-structured-output-plan-v1`
> **创建日期**: 2026-07-22
> **状态**: Draft
> **作者**: AI Agent

---

## §1. 背景与动机

当前 farm-agent 的 Prompt Engine 已完成框架级演进（Android 9 类比），但 LLM 输出约束仍停留在 **prompt 级软约束 + 后置 parse/validate/retry** 模式。随着 Constrained Decoding 技术成熟，存在两条明确的演进路径：

- **云端 API**：利用厂商 Structured Outputs（`response_format: json_schema`）能力
- **本地模型**：利用 vLLM/Ollama + Outlines/XGrammar 实现 token 级约束解码

本 Plan 目标：在不破坏现有 PromptTemplate 架构的前提下，分两条路径逐步引入结构化输出能力。

---

## §2. 现状基线

### 2.1 当前 Prompt Engine 架构

```
PromptTemplate<I,O> 接口
  ├── build(input) → prompt string
  ├── parse(raw) → typed output
  └── validate(output) → boolean

专家注册表（14 专家）
  ├── createExpertPrompt() 工厂函数
  └── expertPromptRegistry Map

Schema 系统
  ├── INTENTION_SCHEMA（schemas/intention.ts）
  └── EXPERT_CLAIM_SCHEMA（structured-output.ts）
```

### 2.2 当前 LLM 调用点（8 个节点，7 个要求 JSON 输出）

| 节点 | 文件 | 输出类型 | 当前约束方式 |
|------|------|----------|-------------|
| `intention` | intention.ts | IntentionOutput | JSON prompt + parse + validate + 重试 |
| `intention_async` | intention_async.ts | IntentionOutput | 同上 |
| `reasoning` | reasoning.ts | ReasoningOutput | JSON prompt + parse + validate |
| `perExpertReasoning` | per-expert-reasoning.ts | ReasoningOutput | JSON prompt + parse + validate |
| `verdict` | verdict.ts | VerdictOutput | JSON prompt + parse + validate |
| `interactionPointDetection` | interaction-point-detection.ts | InteractionPointOutput | JSON prompt + parse + validate |
| `structuredOutput` | structured-output.ts | ExpertClaim | JSON prompt + 重试循环（MAX_RETRIES=2）+ 降级提取 |
| `coordinationDialogue` | coordination-dialogue.ts | ConflictReport[] | regex 提取 JSON 数组 + JSON.parse |
| `response` | response.ts | 自然语言流式 | stream()，**无结构化要求** |

### 2.3 当前痛点

1. **每个节点独立实现 markdown 剥离**：`raw.replace(/```json\n?/g, "").replace(/```\n?/g, "")` 重复 **9 处**（含 `router/llm-fallback.ts`、`nodes/intention.ts`、`nodes/intention-async.ts`）
2. **无 API 层结构化输出**：未使用 OpenAI `response_format` 或 `with_structured_output()`
3. **重试成本高**：`structuredOutputNode` 最多 3 次 LLM 调用（1 次正常 + 2 次重试），每次失败都浪费 tokens
4. **Schema 定义分散**：`INTENTION_SCHEMA` 和 `EXPERT_CLAIM_SCHEMA` 在不同文件，格式不同
5. **validate() 手写**：每个 prompt 模板手写字段校验，无法利用 Zod schema 自动生成

---

## §3. 演进目标

### 3.1 短期（云端 API 路径）

- 接入 `response_format: json_schema`（OpenAI 兼容 API），消除 markdown 剥离和大部分重试
- 统一 Schema 定义为 Zod schema，自动生成 JSON Schema 和 TypeScript 类型
- 抽取公共 JSON 解析层，消除重复代码

### 3.2 中期（本地模型路径）

- Ollama 后端接入 Outlines/lm-format-enforcer，实现 token 级约束解码
- 或部署 vLLM + XGrammar 作为独立推理服务，farm-agent 通过 HTTP 调用
- 推理层约束对 Prompt Engine 层透明，通过统一接口暴露

### 3.3 长期

- DSPy 式自动 prompt 优化（few-shot 自动选择 + prompt 模板自动调优）
- 跨模型 prompt 可迁移性（换模型无需重写 prompt）

---

## §4. 云端 API 路径（当前实施）

### 4.1 Schema 统一：从分散定义到 Zod-first

**现状**：
- `INTENTION_SCHEMA` 是 TS 对象，手动维护 JSON 字符串
- `EXPERT_CLAIM_SCHEMA` 是手写 JSON Schema 对象
- 每个 `PromptTemplate.parse()` 手写字段校验

**改造**：
```typescript
// schemas/intention.zod.ts — Zod-first 定义
import { z } from "zod"

export const IntentionSchema = z.object({
  intent: z.enum(["analysis", "planning", "question", "decision", "creation", "modification", "chat"]),
  entities: z.object({
    projectId: z.string().optional(),
    taskId: z.string().optional(),
    keywords: z.array(z.string()),
  }),
  subIntents: z.array(z.object({
    expertId: z.string(),
    subQuery: z.string(),
  })).optional(),
  thinkingLevel: z.enum(["deep", "professional"]).optional(),
  constraints: z.array(z.string()).optional(),
  contextHints: z.array(z.object({
    type: z.enum(["history", "constraint"]),
    domain: z.string(),
    fact: z.string(),
  })).optional(),
})

export type IntentionOutput = z.infer<typeof IntentionSchema>
```

**收益**：
- `IntentionSchema.parse(raw)` 替代手写 validate()
- `zodToJsonSchema(IntentionSchema)` 自动生成 JSON Schema 供 `response_format` 使用
- 类型定义 `z.infer<>` 替代手写 interface

### 4.2 接入 `response_format: json_schema`

**LangChain.js ChatOpenAI 支持**：
```typescript
const llmWithSchema = new ChatOpenAI({ ... }).withStructuredOutput(IntentionSchema)
const result = await llmWithSchema.invoke(prompt)
// result 直接是 IntentionOutput 类型，无需 parse()
```

**改造点**：
1. 在 `AuditedLLM` 中新增 `withStructuredOutput(schema)` 方法
2. 每个 JSON 输出节点改用 `getLLM().withStructuredOutput( zodSchema )` 调用
3. `PromptTemplate.parse()` 保留作为降级路径（`response_format` 不可用时）

**兼容性**：
- 阿里云百炼（DashScope）兼容 OpenAI API，已支持 `response_format: json_schema`
- Ollama ChatOllama 的 `withStructuredOutput()` 依赖模型是否支持 JSON mode

**Ollama 降级策略**：`AuditedLLM` 内部持有 `ChatOpenAI | ChatOllama` 联合类型。当 provider=ollama 时：
```typescript
if (llm.underlying instanceof ChatOllama) {
  // Ollama: 仅 JSON mode, 无 schema 约束 → 始终走 prompt-parse 降级路径
  // structuredInvoke() 内部自动降级，调用方无需感知
}
```

### 4.3 公共 JSON 解析层

抽取 `src/lib/llm/structured-invoke.ts`：

```typescript
/**
 * 结构化 LLM 调用统一入口
 * 
 * 优先使用 withStructuredOutput（云端 API 层约束）
 * 降级到 prompt 级 JSON 约束 + parse + validate + 重试
 */
export async function structuredInvoke<T>(
  llm: AuditedLLM,
  prompt: string,
  schema: z.ZodSchema<T>,
  options?: { maxRetries?: number; degradeFn?: (raw: string) => T }
): Promise<{ result: T; method: "structured_output" | "prompt_parse" | "degraded" }>
```

**数组 schema 支持**：`z.ZodSchema<T>` 天然支持 `z.array()` 类型，因此 `ConflictReport[]` 等数组输出可直接使用 `z.array(ConflictReportSchema)` 作为 schema 参数，无需特殊处理。LangChain.js `withStructuredOutput()` 接受任意 Zod schema，包括数组类型。

### 4.4 改造优先级

| 优先级 | 节点 | 理由 |
|--------|------|------|
| P0 | `structuredOutput` | 重试成本最高（最多 3 次 LLM 调用），收益最大 |
| P1 | `intention` / `intention_async` | 调用频率最高（每次对话必经） |
| P2 | `reasoning` / `perExpertReasoning` | 推理路径结构化，但 reasoning_path 是数组，schema 较复杂 |
| P3 | `verdict` | 调用频率中等，type 枚举约束明确 |
| P4 | `interactionPointDetection` | 调用频率低，且 hasInteractionPoint=false 时无需解析 |

---

## §5. 本地模型路径（远期规划）

### 5.1 Ollama + JSON Mode（轻量级）

**现状**：
- `ChatOllama` 已支持 `format: "json"` 参数
- 但不支持 `response_format: json_schema`（无法约束具体 schema）

**改造**：
```typescript
// ChatOllama 的 JSON mode（仅保证合法 JSON，不约束 schema）
const ollamaLLM = new ChatOllama({
  baseUrl: config.baseURL,
  model: config.model,
  format: "json",  // ← 启用 JSON mode
})
```

**局限**：Ollama 的 JSON mode 只保证输出是合法 JSON，不保证字段完整。仍需后置 Zod parse + 重试。

### 5.2 vLLM + XGrammar（生产级 Constrained Decoding）

**架构**：
```
farm-agent (TS) → HTTP → vLLM 推理服务 (Python) → GPU
                           └── XGrammar LogitsProcessor（token 级约束）
```

**部署**：
```bash
# vLLM 启动（支持 guided decoding）
python -m vllm.entrypoints.openai.api_server \
  --model Qwen/Qwen2.5-14B-Instruct \
  --guided-decoding-backend xgrammar \
  --port 8000
```

**接入方式**：
- vLLM 暴露 OpenAI 兼容 API
- farm-agent 的 `ChatOpenAI` 配置 `baseURL: "http://localhost:8000/v1"`
- `response_format: json_schema` 自动启用 XGrammar 约束解码
- **对 farm-agent 代码零改动**（§4 云端路径的改造直接复用）

**关键优势**：
- token 级约束，100% 输出合法
- 无重试，无 markdown 剥离，无 parse 失败
- 支持任意开源模型（Qwen、Llama、Mistral）

### 5.3 Outlines 微服务（备选）

如果不想部署 vLLM，可用 Outlines 包装任意 HuggingFace 模型：

```python
# outlines_server.py
import outlines
from fastapi import FastAPI

model = outlines.models.transformers("Qwen/Qwen2.5-14B-Instruct")
app = FastAPI()

@app.post("/generate")
async def generate(prompt: str, schema: dict):
    generator = outlines.generate.json(model, schema)
    result = generator(prompt)
    return result
```

---

## §6. 双路径统一接口设计

### 6.1 核心抽象：`StructuredLLMBackend`

```typescript
export interface StructuredLLMBackend {
  /** 结构化调用：保证输出符合 schema */
  invoke<T>(prompt: string, schema: z.ZodSchema<T>): Promise<T>
  
  /** 流式调用：自然语言回复（无需结构化） */
  stream(prompt: string): AsyncIterable<string>
  
  /** 后端能力描述 */
  capabilities: {
    constrainedDecoding: boolean   // token 级约束
    jsonSchemaEnforced: boolean    // API 层 schema 强制
    supportsRetryHint: boolean     // 支持重试提示注入
  }
}
```

### 6.2 三种后端实现

| 后端 | constrainedDecoding | jsonSchemaEnforced | 适用场景 |
|------|--------------------|--------------------|---------|
| `CloudStructuredBackend` | false | true | 云端 API（DashScope/OpenAI） |
| `OllamaBackend` | false | false | 本地 Ollama（仅 JSON mode） |
| `VLLMXGrammarBackend` | true | true | 本地 vLLM + XGrammar |

### 6.3 路由策略

```typescript
function resolveBackend(config: LLMConfig): StructuredLLMBackend {
  if (config.provider === "cloud") {
    return new CloudStructuredBackend(config)
  }
  if (config.structuredDecoding) {
    return new VLLMXGrammarBackend(config)
  }
  return new OllamaBackend(config)
}
```

---

## §7. 实施路线

> **当前仅实施短期目标**（§3.1 云端 API 路径）。中期/远期目标为远期规划，待短期目标验收通过后再决策。

### 短期目标：云端 API 结构化（2-3 周）⭐ 当前实施

- [ ] Task 1.1: 引入 `zod-to-json-schema` 依赖（`package.json`）— 验收: `pnpm install` 成功
- [ ] Task 1.2: IntentionOutput 迁移为 Zod schema（`schemas/intention.zod.ts` 新建）— 验收: `tsc --noEmit`
- [ ] Task 1.3: ReasoningOutput 迁移为 Zod schema（`schemas/reasoning.zod.ts` 新建）— 验收: `tsc --noEmit`
- [ ] Task 1.4: ExpertClaim 迁移为 Zod schema（`schemas/expert-claim.zod.ts` 新建）— 验收: `tsc --noEmit`
- [ ] Task 1.5: 抽取公共 JSON 解析层（`lib/llm/structured-invoke.ts` 新建）— 验收: `tsc --noEmit` + 单测
- [ ] Task 1.6: AuditedLLM 增加 withStructuredOutput()（`lib/llm/index.ts`）— 验收: `tsc --noEmit`，不修改现有 invoke/stream
- [ ] Task 1.7: P0 structuredOutputNode 接入（`nodes/structured-output.ts`）— 验收: 零重试成功率 ≥ 95%
- [ ] Task 1.8: P1 intentionNode 接入（`nodes/intention.ts`）— 验收: 解析失败率 = 0%，tool_calls 分支不动
- [ ] Task 1.9: P2 reasoningNode 接入（`nodes/reasoning.ts`）— 验收: 端到端推理通过
- [ ] Task 1.10: P3-P4 其余节点接入（`verdict.ts`, `interaction-point-detection.ts`, `coordination-dialogue.ts`）— 验收: 端到端通过
- [ ] Task 1.11: 清理 markdown 剥离代码（`prompts/*.ts` + `router/llm-fallback.ts`）— 验收: `grep` 命中 = 0

### 中期目标：本地 Constrained Decoding（按需启动）

| # | 任务 | 文件 | 说明 | 前置 |
|---|------|------|------|------|
| 2.1 | 部署 vLLM + XGrammar 推理服务 | — | GPU 服务器 | — |
| 2.2 | 新增 VLLMXGrammarBackend | `lib/llm/` | 后端实现 | 短期目标完成 |
| 2.3 | model.toml 新增 `structuredDecoding` 配置 | `src/config/model.toml` | 配置驱动 | — |
| 2.4 | 验证 token 级约束效果 | — | ExpertClaim schema 验证 | 2.1 + 2.2 |

### 远期目标：自动优化（中期目标后决策）

| # | 任务 | 文件 | 说明 | 前置 |
|---|------|------|------|------|
| 3.1 | Few-shot 样本自动注入 | — | 历史对话质量标注 | 标注数据 |
| 3.2 | Prompt 模板 A/B 测试框架 | — | 可观测性基础设施 | — |
| 3.3 | DSPy 式自动 prompt 优化 | — | Python 微服务 | 中期目标完成 |

---

## §8. 影响文件与逻辑清单

### 8.1 新建文件（4 个，短期目标）

| 文件 | 职责 |
|------|------|
| `src/lib/llm/structured-invoke.ts` | 公共结构化 LLM 调用入口（withStructuredOutput + 降级） |
| `src/agents/prompts/schemas/intention.zod.ts` | IntentionOutput 的 Zod schema 定义 |
| `src/agents/prompts/schemas/reasoning.zod.ts` | ReasoningOutput 的 Zod schema 定义 |
| `src/agents/prompts/schemas/expert-claim.zod.ts` | ExpertClaim 的 Zod schema 定义 |

### 8.2 修改文件 — 基础设施层（3 个，不影响专家能力并行开发）

| 文件 | 当前逻辑 | 改动内容 | 影响行数 |
|------|---------|---------|----------|
| `package.json` | 无 `zod-to-json-schema` | 新增 `zod-to-json-schema` 依赖 | +1 行 |
| `src/lib/llm/index.ts` (303行) | `AuditedLLM` 仅暴露 `invoke/stream/bindTools` | 新增 `withStructuredOutput(schema)` 方法，内部调用 `ChatOpenAI.withStructuredOutput()` 或降级到 `invoke + parse` | +30~50 行 |
| `src/agents/prompts/types.ts` (334行) | 7 个 `interface` 手写定义输出类型 | 改为 `z.infer<typeof XxxSchema>` 引用 Zod schema（类型兼容，不改下游） | ~15 处替换 |

### 8.3 修改文件 — Schema 统一层（2 个）

| 文件 | 当前逻辑 | 改动内容 | 影响行数 |
|------|---------|---------|----------|
| `src/agents/prompts/schemas/intention.ts` (125行) | 手写 `INTENTION_SCHEMA` TS 对象 + 手写 `validateIntentionFields()` + 手写 `buildRetryHint()` | 改为 Zod schema → `zodToJsonSchema()` 自动生成 JSON Schema；`validateIntentionFields` 由 `IntentionSchema.safeParse()` 替代；`buildRetryHint` 保留（Zod 错误转 LLM 提示） | ~60 行重写 |
| `src/agents/nodes/structured-output.ts` (207行) | 手写 `EXPERT_CLAIM_SCHEMA` JSON Schema 对象 + 手写字段检查 + 2 次重试循环 + `degradeExtract()` 降级 | `EXPERT_CLAIM_SCHEMA` 迁移到 Zod；重试循环改为 `structuredInvoke()` 统一入口；`degradeExtract()` 作为 `options.degradeFn` 保留 | ~80 行重写 |

### 8.4 修改文件 — Prompt 模板层（6 个，每个移除 markdown 剥离 + parse/validate 逻辑）

| 文件 | 当前 parse() 逻辑 | 改动内容 | 影响行数 |
|------|------------------|---------|----------|
| `src/agents/prompts/intention.ts` (190行) | `replace(/\`\`\`json/g)` + `JSON.parse` + 手写类型转换 (L112-178) | `parse()` 简化为 `IntentionSchema.parse(JSON.parse(raw))`；`validate()` 删除；`build()` 不变 | ~50 行简化 |
| `src/agents/prompts/intention_async.ts` (115行) | 同上 (L83-110) | 同上 | ~25 行简化 |
| `src/agents/prompts/reasoning.ts` (100行) | `replace(/\`\`\`json/g)` + `JSON.parse` + 手写映射 (L65-90) | `parse()` 简化为 `ReasoningSchema.parse(JSON.parse(raw))`；`validate()` 删除 | ~25 行简化 |
| `src/agents/prompts/verdict.ts` (87行) | `replace(/\`\`\`json/g)` + `JSON.parse` + 手写映射 (L44-74) | 同上 | ~30 行简化 |
| `src/agents/prompts/interaction-point-detection.ts` (90行) | `replace(/\`\`\`json/g)` + `JSON.parse` + 手写映射 (L47-75) | 同上 | ~25 行简化 |
| `src/agents/prompts/response.ts` (108行) | `replace(/\`\`\`json/g)` + `JSON.parse` (L73-105) | **死代码**：`responsePrompt` 已导出但从未被任何节点调用（response 节点走 `stream()`），标记 `@deprecated` | 标记废弃 |
| `src/agents/router/llm-fallback.ts` | `replace(/\`\`\`json/g)` + `JSON.parse` (L62) | 移除 markdown 剥离代码 | ~5 行 |

### 8.5 修改文件 — 节点调用层（8 个，每个节点 LLM 调用方式改为 `structuredInvoke()`）

| 文件 | 当前 LLM 调用 | 改动逻辑 | 影响行数 |
|------|-------------|---------|----------|
| `src/agents/nodes/intention.ts` (402行) | `llmWithTools.invoke(prompt)` + `replace` + `JSON.parse` + `validateIntentionFields` + 重试循环 (L240-262) | 调用 `structuredInvoke(llm, prompt, IntentionSchema, { degradeFn })` 替代手写重试 | ~20 行替换 |
| `src/agents/nodes/intention-async.ts` (224行) | 同上 (L140-161) | 同上 | ~20 行替换 |
| `src/agents/nodes/reasoning.ts` (527行) | `getLLM().invoke(finalPrompt)` + `reasoningPrompt.parse()` + `reasoningPrompt.validate()` (L300-318, L396-418) | 2 处 `invoke` 改为 `structuredInvoke()`；用户裁决恢复路径 (L396) 同步改造 | ~30 行替换 |
| `src/agents/nodes/per-expert-reasoning.ts` (129行) | `getLLM().invoke(prompt)` + `reasoningPrompt.parse()` + `validate()` (L91-96) | 改为 `structuredInvoke()` | ~10 行替换 |
| `src/agents/nodes/verdict.ts` (105行) | `getLLM().invoke(prompt)` + `verdictPrompt.parse()` + `validate()` (L26-77) | 改为 `structuredInvoke()`；catch 块的降级逻辑保留 | ~15 行替换 |
| `src/agents/nodes/interaction-point-detection.ts` (107行) | `getLLM().invoke(prompt)` + `parse()` + `validate()` (L52-63) | 改为 `structuredInvoke()` | ~10 行替换 |
| `src/agents/nodes/structured-output.ts` (207行) | `llm.invoke(prompt)` + `JSON.parse` + 手写字段检查 + 2 次重试 (L128-202) | 整个重试循环改为 `structuredInvoke()` 单次调用 | ~40 行替换 |
| `src/agents/nodes/coordination-dialogue.ts` (186行) | `llm.invoke(prompt)` + `text.match(/\[[\s\S]*\]/)` + `JSON.parse` (L44-57) | 语义冲突检测改为 `structuredInvoke(llm, prompt, ConflictReportArraySchema)` | ~15 行替换 |

### 8.6 不动的文件

| 文件 | 理由 |
|------|------|
| `src/agents/prompts/experts/factory.ts` | 专家 prompt 工厂只负责 `build()` 生成文本，不涉及 parse/validate |
| `src/agents/prompts/experts/index.ts` | 注册表只做 register + load，不变 |
| `src/agents/prompts/experts/*.ts`（14 个专家文件） | 每个专家的 `build()` 不变；`parse()/validate()` 返回 `ExpertPromptOutput` 是透传，实际解析在 reasoning.ts |
| `src/agents/agent-graph.ts` | 图结构和边不变，只改节点内部实现 |
| `src/agents/state.ts` | AgentState 类型不变 |
| `src/agents/nodes/response.ts` | 走 `stream()` 自然语言，无结构化输出需求 |
| `src/agents/nodes/retrieval.ts` | 不调 LLM（RAG 检索） |
| `src/agents/nodes/per-expert-retrieval.ts` | 不调 LLM |
| `src/agents/nodes/spatial-preprocessing.ts` | 不调 LLM |
| `src/agents/nodes/conflict-resolver.ts` | 纯函数，零 LLM |
| `src/agents/nodes/aggregation.ts` | 纯函数，零 LLM |
| `src/config/model.toml` | 短期目标不改配置（中期目标才加 `structuredDecoding` 字段） |
| `src/agents/prompts/awareness.ts` | 觉知注入层，只生成 prompt 文本，不调 LLM |
| `src/agents/router/llm-fallback.ts`（parse/validate） | markdown 剥离在 §8.4 单独处理，LLM 调用逻辑不变 |

### 8.7 影响逻辑汇总

| 逻辑 | 改动性质 | 风险等级 |
|------|---------|----------|
| `AuditedLLM` 新增 `withStructuredOutput()` | **新增方法**，不修改现有 invoke/stream | 低（向后兼容） |
| `PromptTemplate<I,O>.parse()` 语义变更 | 从"手写 JSON 解析+类型映射"改为"Zod schema parse" | **中**（输出类型需兼容） |
| `PromptTemplate<I,O>.validate()` 废弃 | Zod `safeParse()` 自带校验，`validate()` 冗余 | 低（逐步移除） |
| `intentionNode` / `intentionAsyncNode` 重试逻辑 | 从手写 for 循环重试改为 `structuredInvoke()` | **中**（需确保 tool_calls 路径不受影响） |
| `structuredOutputNode` 重试循环 | 从 3 次 LLM 调用改为 1 次 `withStructuredOutput` | 低（收益最大） |
| `coordinationDialoguNode` 语义冲突检测 | 从 regex 提取 JSON 改为 schema 约束 | 低 |
| `reasoningNode` 用户裁决恢复路径 (L396) | `interrupt()` 后的 re-invoke 也需要结构化 | 低 |
| `response.ts` 的 `parse/validate` | 死代码，无影响 | 无 |

### 8.8 当前实施范围

> **当前仅实施 §7 短期目标**（§3.1 云端 API 路径）。
> 中期/远期目标为远期规划，不纳入当前实施范围。
>
> 实施顺序详见 §7 Task 列表（Task 1.1→1.11），前六项零破坏性（纯新增文件/方法），可与专家能力开发完全并行。

---

## §9. 风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| DashScope `response_format` 兼容性不完全 | 部分模型不支持 | 保留 prompt-parse 降级路径 |
| Zod schema 与现有 interface 不一致 | 类型断裂 | 渐进迁移，先用 `z.infer` 验证类型兼容 |
| vLLM 部署运维成本 | GPU 资源 + 运维人力 | 中期目标按需启动，不强制 |
| `withStructuredOutput()` LangChain.js 版本限制 | API 变更 | 锁定 `@langchain/openai ^1.5.3`，测试覆盖 |
| `intentionNode` 的 tool_calls 路径受影响 | 工具调用链路中断 | `structuredInvoke()` 仅在 JSON 解析分支生效，tool_calls 分支不动 |

---

## §10. 验收标准

### 短期目标验收

- [ ] `structuredOutputNode` 零重试成功率 ≥ 95%（当前约 70-80%）
- [ ] `intentionNode` 解析失败率降至 0%（当前偶发 JSON 格式错误）
- [ ] 所有 `parse()` 中的 `replace(/```json/g, "")` 已移除
- [ ] `EXPERT_CLAIM_SCHEMA` 和 `INTENTION_SCHEMA` 统一为 Zod schema 定义

### 中期目标验收

- [ ] vLLM 服务可用，farm-agent 可通过 HTTP 调用
- [ ] ExpertClaim 输出 token 级约束验证通过（非法 token 被 mask）
- [ ] 端到端延迟不高于云端 API（含网络 RTT）

---

## §11. 依赖关系

```
轮次 1: 基础设施（零破坏性，纯新增）
  ├── Task 1.1: zod-to-json-schema 依赖（package.json）
  └── Task 1.2-1.4: Zod schema 新建（intention.zod.ts, reasoning.zod.ts, expert-claim.zod.ts）
        │  产出 → 被 1.5-1.6 消费
        ▼
轮次 2: 公共层（零破坏性，纯新增）
  ├── Task 1.5: structuredInvoke.ts 新建
  │     │  消费 1.2-1.4 的 Zod schema
  │     ▼
  └── Task 1.6: AuditedLLM.withStructuredOutput()（lib/llm/index.ts）
        │  消费 1.5 的 structuredInvoke
        ▼
轮次 3: 节点接入（逐节点独立改造，可并行）
  ├── Task 1.7: structuredOutputNode（P0，消费 1.5+1.6）
  ├── Task 1.8: intentionNode（P1，消费 1.5+1.6）
  ├── Task 1.9: reasoningNode（P2，消费 1.5+1.6）
  └── Task 1.10: verdict + interactionPoint + coordinationDialogue（P3-P4，消费 1.5+1.6）
        │
        ▼
轮次 4: 清理（全部节点接入完成后）
  └── Task 1.11: 移除 markdown 剥离（prompts/*.ts + router/llm-fallback.ts）+ 废弃 validate()
```

---

## §12. 技术选型对比

| 方案 | 约束强度 | 实施成本 | 运维成本 | 适用定位 |
|------|---------|---------|---------|----------|
| 当前（prompt 级） | 软约束 | 0 | 0 | 已完成 |
| Ollama JSON mode | JSON 合法 | 低 | 低 | 短期目标附带 |
| `response_format: json_schema` | Schema 强制 | 中 | 低 | **短期目标主推** |
| vLLM + XGrammar | Token 级硬约束 | 高 | 高 | 远期规划 |
| Outlines 微服务 | Token 级硬约束 | 高 | 中 | 远期备选 |
| DSPy | 自动优化 | 极高 | 高 | 远期探索 |

---

## §13. 恢复上下文审计查询

### 13.1 总体一键恢复

```
keyword: prompt-engine-structured-output
```

### 13.2 逐任务审计查询

| 任务 | targetId | keyword |
|------|----------|---------|
| Zod schema 迁移 | schemas/intention.zod.ts | zod-intention-schema |
| ExpertClaim schema | schemas/expert-claim.zod.ts | zod-expert-claim-schema |
| 公共解析层 | lib/llm/structured-invoke.ts | structured-invoke |
| AuditedLLM 扩展 | lib/llm/index.ts | with-structured-output |
| structuredOutput 接入 | nodes/structured-output.ts | structured-output-cd |

### 13.3 恢复判定标准

- `grep -r "zod-to-json-schema" src/` 命中 ≥ 1 → Zod 迁移已启动
- `grep -r "withStructuredOutput" src/lib/llm/` 命中 ≥ 1 → 公共层已就位
- `grep -r "replace.*\`\`\`json" src/agents/prompts/` 命中 = 0 → 代码清理完成

---

## §14. 关联 Plan：Prompt Engine 输入侧

> **关联文档**：`farm-agent-spatial-reasoning-plan-v4.md` §六
>
> 本 Plan 聚焦 Prompt Engine 的**输出侧**（结构化约束），输入侧由 spatial-reasoning plan 的 tool-result-aggregator 模块负责。

### 14.1 Prompt Engine 完整闭环

```
┌─────────────────────────────────────────────────┐
│  Prompt Engine                                   │
│  ├── 输入侧（数据准备）                          │
│  │   ├── tool-result-aggregator/                │
│  │   │   → 原始 toolResults 变结构化摘要         │
│  │   │   → 参见 spatial-reasoning-plan-v4.md §六 │
│  │   ├── awareness.ts（觉知注入）                 │
│  │   └── buildSpatialContextSection()            │
│  │                                               │
│  └── 输出侧（结构化约束）— 本 Plan                │
│      ├── structured-invoke.ts                    │
│      ├── intention.zod.ts                        │
│      └── expert-claim.zod.ts                     │
│                                                   │
│  空间计算层（spatial-reasoning v3 独占）          │
│  ├── voronoi.ts（几何计算）                       │
│  ├── fcm.ts（聚类算法）                           │
│  └── coordinate-transform.ts                     │
└─────────────────────────────────────────────────┘
```

### 14.2 并行开发策略

两个 Plan 改的是同一个文件的**不同位置**，可以完全并行：

```
per-expert-reasoning.ts 改动:
  // 第 59-72 行（输入侧）— spatial-reasoning plan §六
  - const toolResults = stateToolResults.filter(...).map(tr => JSON.stringify(tr.list))
  + const toolResults = aggregateToolResults(stateToolResults, undefined, "compact")

  // 第 91 行（输出侧）— 本 Plan
  - const response = await getLLM().invoke(prompt)
  + const { result } = await structuredInvoke(llm, prompt, ReasoningSchema)
```

### 14.3 依赖关系

| 本 Plan 任务 | 关联输入侧任务 | 依赖类型 |
|-------------|---------------|---------|
| Task 1.9: reasoningNode 接入 | tool-result-aggregator 接入 | 无（改不同位置） |
| Task 1.7: structuredOutputNode 接入 | summary-reasoning 接入聚合 | 无（改不同位置） |
| Task 1.10: perExpertReasoning 接入 | per-expert-reasoning 接入聚合 | 无（改不同位置） |

**结论**：两个 Plan 零耦合，可独立推进。
