# add-template-standardization-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。不要写完整实现。

## PLAN 元信息

- **Plan 名称**: add-template-standardization-v1
- **启动时间**: 2026-07-04T12:30:00+08:00
- **主导 AI**: Qoder
- **前置依赖**: PreToolUse Hook 阻断机制已就绪（2026-07-04）
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-07/04/farm-agent-add-template-standardization-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-07/04/farm-agent-add-template-standardization-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-add-template-standardization-review-v1.md`
- **ADD-7 审计策略**:

| 文件/目录 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `.qoder/templates/*.md` (15 个模板 + standard-plan 重命名) | DOC | MODIFY | 术语分裂、层级不统一 | 术语/层级统一，含 schema.json | 待实施 |
| `.qoder/templates/*.schema.json` (16 个) | SCHEMA | CREATE | 不存在 | JSON Schema 驱动结构校验 | 待实施 |
| `.qoder/vocabulary/TERMINOLOGY.md` | DOC | CREATE | 不存在 | 16 模板统一术语表 | 待实施 |
| `.qoder/hooks/doc-format-guard.sh` | RULE | MODIFY | 仅覆盖 simple-plan-template | 覆盖全部 16 模板 + 占位符检测 | 待实施 |
| `AGENTS.md` | DOC | MODIFY | `Step` `Phase` 混用 | 术语对齐术语表 | 待实施 |
| `.qoder/vocabulary/add-governance-vocabulary.md` | DOC | MODIFY | 旧术语 | 术语对齐术语表 | 待实施 |
| `.qoder/vocabulary/vocabulary.sh` | RULE | MODIFY | 旧触发词 | 术语对齐术语表 | 待实施 |
| 历史 `.qoder/plans/` 下 Plan（抽样） | DOC | (选择) | 旧术语 | 无需回写，守卫不阻断已生成文档 | 待实施 |

> 审计关键时间点: Task 1 定稿后记录术语表 → Task 3 每改一个模板记录一条 → Task 4 guard.sh 修改记录 → Task 5 消费方同步各一条 → Task 6 验证记录。

---

## 一、背景与目标

### 1.1 问题现状

项目有 16 个 ADD 模板，但存在以下结构性问题：

**术语分裂**：同一概念在三个模板中用三个词：

| 概念 | standard-plan-template | simple-plan-template | tasks-template | AGENTS.md |
|------|:--:|:--:|:--:|:--:|
| 实施阶段 | `Step` | `Phase` | `Phase` | `Step` |
| 工作单元 | `Task` | `Task` | `Task` | — |
| 里程碑 | `四、实施步骤` | `三、Tasks` | `Phase X: ...` | `Step 0-9` |

**层级混乱**：同一级标题在不同模板中层级不同：

| 模板 | 一级章节 | 二级子节 | 三级子节 |
|------|:--:|:--:|:--:|
| standard-plan-template | `## 一、...` | `### 1.1` | — |
| simple-plan-template | `## 一、...` | `### 2.1` / `### 4.1` | `#### 总体一键恢复` |
| handoff-template | `## 1.` / `## 4.` | `### 4.1` | `#### 总体一键恢复` |

**守卫缺口**：`doc-format-guard.sh` 只覆盖 simple-plan-template，其余 15 个模板全漏。缺章节的文档直接落盘。

**占位符未替换**：LLM 经常直接使用 `{需求名}` `{描述}` 等模板占位符而不替换。

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | 术语统一 | 16 个模板中同一概念用同一个词 |
| P0 | 层级统一 | 同一级标题在所有模板中同级 |
| P0 | 守卫全覆盖 | `doc-format-guard.sh` 覆盖全部 16 个模板的章节校验 |
| P1 | 占位符检测 | 守卫阻断含未替换占位符的文档 |
| P1 | 模板联动修正 | 术语修正后，AGENTS.md、vocabulary.sh 等消费方同步更新 |

---

## 二、方案选型

### 2.1 术语统一方案

| 方案 | 做法 | 影响面 |
|------|------|--------|
| A: 以 AGENTS.md 为准 | 所有模板统一用 `Step` | AGENTS.md 零改，16 模板改 |
| B: 以 standard-plan-template 为准 | 所有模板统一用 `Step` + `Task` | plan-template 零改，15 模板改 |
| C: 重新定义 | 新词表，全部模板改 | 16 模板全改 |

**选 B**：standard-plan-template 是使用最频繁的模板（`find .qoder/plans -name "*plan*" | wc -l` = 102），以它为准最少改动。

### 2.2 守卫架构

| 方案 | 做法 | 维护成本 |
|------|------|------|
| A: 单脚本硬编码 | 一个 shell 脚本内嵌 16 套章节清单 | 高（加模板需改代码） |
| B: 结构定义文件 | 每个模板配一个 `.schema.json`，守卫读定义校验 | 低（加模板只需加定义） |
| C: MCP 工具 | 把校验逻辑做成 MCP tool，hook 调 MCP | 需运行 MCP server |

**选 B**：`.qoder/templates/` 下每个模板配一个 `.schema.json`，`doc-format-guard.sh` 读定义驱动校验。加模板不需要改 Shell 脚本。

### 2.3 选型理由

- 术语选 standard-plan-template 减改动面
- 结构定义文件解耦模板和校验逻辑
- 后续要支持新模板（如 fix-verification-template）只需加一个 JSON 文件

---

## 三、架构设计

### 3.1 术语规范表（终版）

```
ADD 范式层（纵向，全局）:
  Step        — 大写 S，ADD 工作流的 Step 0-9（如 "Step 3: 代码实现"）

实施层（横向，Plan 内）:
  Round       — 大写 R，多轮 Plan 中的原子事务（如 "第1轮 ── 类型收敛"）
  Task        — 大写 T，单文件/单模块的工作单元（如 "Task 1: 抽取 BaseChatSchema"）

文件类型:
  Plan / Spec / Tasks / Checklist / Handoff / Review / ADD Route

全局禁止词:
  轮次 → Step 或 Round（视上下文）
  步骤 → Task
  阶段 → 无替代 — Phase 概念已全局废弃，15 个 schema 中均设为 forbidden
  Phase → 适用于全部模板，写入即阻断
```

**为什么 Round 和 Step 可以共存**：

```
Step 0: 文档先行
Step 1-2: 审计准备          第1轮 ── 类型收敛
Step 3: 代码实现 ─────────→ 第2轮 ── safeParse 补全     ← Round 是 Step 3 内部的事务拆分
Step 4: 审查                第3轮 ── DTO 删除             只出现在 handoff-multi-round-template 中
Step 5-8: ...               第4轮 ── 响应类型 Dto 后缀
```

- Step 是纵向流程（所有 Plan 都有 Step 0-9）
- Round 是横向事务（只有多轮 Plan 才有，单轮 Plan 不出现 Round 这个词）
- 两者不冲突，但禁止在 single-round 场景中说 "第X轮"（应说 "Step X"）

### 3.2 标题层级规范

```
##   → 一级章节（如 "一、背景与目标"）
###  → 二级章节（如 "1.1 问题现状"、"§A 源码关联"）
#### → 三级章节（如 "总体一键恢复"、"SQL 管理员验证"）
```

- 所有模板的 `§A`/`§B` 字母分区改用数字（`### 3.1`）
- Handoff 的 `4.1~4.10` 保持不变（与 simple-plan-template 已对齐）

### 3.3 结构定义文件格式

每个模板配一个 `{name}.schema.json`：

```json
{
  "template": "simple-plan-template.md",
  "sections": [
    { "id": "overview",          "heading": "## 一、Plan 概述",           "required": true },
    { "id": "changes",           "heading": "## 二、变更范围",           "required": true },
    { "id": "tasks",             "heading": "## 三、Tasks",              "required": true },
    { "id": "handoff",           "heading": "## 四、Handoff",            "required": true,
      "subsections": [
        { "id": "4.1", "heading": "### 4.1 交接前状态" },
        ...
        { "id": "4.10", "heading": "### 4.10 脱敏要求" }
      ]
    },
    { "id": "acceptance",        "heading": "## 五、验收标准",           "required": true },
    { "id": "references",        "heading": "## 六、关联",               "required": true }
  ],
  "placeholders": ["{需求名}", "{核心内容}", "{版本号}", "{ISO 时间戳}", "{N}", "{描述}"],
  "forbidden_terms": ["轮次", "步骤X", "阶段X"]
}
```

### 3.4 守卫执行流程

```
PreToolUse → file_path 匹配 .qoder/(plans|specs)/
  → 识别模板类型（从文件名推断：*plan* / *spec* / *handoff* / ...）
    → 读取对应 .schema.json
      → 逐 sections 检查 heading 是否存在
        → 缺 required → exit 2 阻断
        → 检查 placeholders 是否残留 → 有则 exit 2
        → 检查 forbidden_terms → 有则 warning
```

---

## 四、实施步骤 + 依赖图

```
Task 1: 术语表定稿 + 层级规范
          │
          ▼
Task 2: 16 schema.json
          │
          ▼
Task 3: 16 模板修正
          │
          ▼
Task 4: doc-format-guard.sh 重构
          │
          ▼
Task 5: 消费方同步（AGENTS.md / vocabulary.sh）
          │
          ▼
Task 6: 全部 16 模板回写样本验证
```

### Task 1: 术语表定稿 + 层级规范

- [ ] 输出最终术语表（`Step` / `Task` / `Phase` 定义 + 禁止词清单）
- [ ] 输出最终层级规范（`##` → `###` → `####` 使用规则）
- [ ] 术语表写入 `.qoder/templates/TERMINOLOGY.md` 作为权威源

### Task 2: 16 个 schema.json 结构定义

- [ ] standard-plan-template.schema.json
- [ ] simple-plan-template.schema.json
- [ ] spec-template.schema.json
- [ ] tasks-template.schema.json
- [ ] checklist-template.schema.json
- [ ] handoff-single-round-template.schema.json
- [ ] handoff-multi-round-template.schema.json
- [ ] add-route-template.schema.json
- [ ] add-route-template-heavyweight.schema.json
- [ ] review-template.schema.json
- [ ] review-implementation-template.schema.json
- [ ] review-runtime-template.schema.json
- [ ] handoff-template.schema.json
- [ ] fix-verification-template.schema.json
- [ ] report-template.schema.json
- [ ] runtime-report-template.schema.json

### Task 3: 16 个模板按术语表 + 层级规范修正

- [ ] 替换禁止词
- [ ] 统一标题层级
- [ ] 统一占位符格式

### Task 4: doc-format-guard.sh 重构

- [ ] 改为读 `.schema.json` 驱动的校验逻辑
- [ ] 支持 placeholders 检测
- [ ] 支持 forbidden_terms 检测
- [ ] `exit 2` + `permissionDecision: deny` 阻断不完整文档

### Task 5: 消费方同步

- [ ] AGENTS.md 中术语对齐
- [ ] `.qoder/hooks/lib/vocabulary.sh` 中触发词对齐
- [ ] `.qoder/vocabulary/add-governance-vocabulary.md` 对齐

### Task 6: 全量回写验证

- [ ] 对现有 102 个 Plan 做抽样检查
- [ ] 对新生成的 Plan 做阻断测试

---


## 四-A、风险矩阵

| 风险 | 概率 | 影响 | 缓解措施 |
|------|:--:|------|---------|
| 历史 102 个 Plan 使用旧术语（`Phase`/`阶段`/`步骤`） | 高—所有存量文档 | 中—守卫误阻断历史文档生成 | 守卫**只校验新生成的文档**，不对已存在的 `.qoder/plans/` 下文件做回验。新旧术语暂时共存，后续按需迁移 |
| 16 模板术语统一后，LLM 可能仍产出旧术语 | 中—LLM 训练数据含旧术语 | 中—新文档含禁止词被守卫阻断 | `forbidden_terms` 支持模糊匹配（中英文同义词表），阻断时给出替换建议 |
| `doc-format-guard.sh` 由所有 Write/Edit 工具触发，频繁执行 | 低—脚本开头路径过滤，不匹配即 `exit 0` | 低—仅 `.qoder/plans/`、`.qoder/specs/` 下文件被校验 | 内部按目标路径过滤：只拦截 `.qoder/plans/` 和 `.qoder/specs/`，跳过其他路径） |
| schema.json 定义过严导致合法文档被误断 | 中—边界 case | 中—AI 无法生成文档 | 每个 schema.json 的 `required` 字段只列 Plan 模板的最少必需章节，保留 `additionalProperties: true` 允许扩展 |

## 五、验收标准

- [ ] `doc-format-guard.sh` 覆盖全部 16 个模板
- [ ] 缺章节 → `exit 2` 阻断写入
- [ ] 含未替换占位符 → `exit 2` 阻断写入
- [ ] 16 个模板中无禁止词
- [ ] AGENTS.md 术语与模板一致
- [ ] `.qoder/templates/TERMINOLOGY.md` 存在且为权威源
- [ ] 误阻断率 < 5%：从 102 个历史 Plan 中随机抽样 20 个，守卫判断为缺章节而阻断的 ≤1 个
- [ ] 漏检率 = 0：人为构造 5 个缺必填章节或含未替换占位符的文档，全部被 `exit 2` 阻断
- [ ] 性能：`doc-format-guard.sh` 单次 JSON 解析耗时增量 < 50ms

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| Handoff | `.qoder/plans/2026-07/04/farm-agent-add-template-standardization-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-add-template-standardization-review-v1.md` |
| 术语权威源 | `.qoder/templates/TERMINOLOGY.md` |
| 守卫脚本 | `.qoder/hooks/doc-format-guard.sh` |
| PreToolUse 配置 | `.qoder/settings.json` |
