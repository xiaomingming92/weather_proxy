# llm-config-centralization-plan-v1

> 精简版 Plan：LLM 模型配置收敛至 model.toml + API Key 分拆 + 零硬编码兜底。Tasks 与 Handoff 合并于本文。

**创建时间**: 2026-07-04T12:00:00+08:00
**主导 AI**: Qoder

---

## 一、Plan 概述

- **现状**: LLM / Embedding / H5 三组模型共用一个 `OPENAI_API_KEY_DASHSCOPE`；temperature / maxTokens / baseURL 在 `llm/index.ts`、`model-config.ts`、`model-config-store.ts` 三处各写一套硬编码兜底；H5 模型参数散落在 `.env` 和代码中。
- **目标**: 模型参数唯一数据源为 `model.toml`（cloud / h5 / ollama 三段 defaults），API Key 按用途拆为三个独立变量。代码层不做任何数值兜底——配置缺失即启抛错。
- **核心原则**:
  1. 单一真相源：所有模型默认参数归于 `model.toml`
  2. 零硬编码兜底：`?? 0` / `?? 0.1` / `?? 4000` / `|| "qwen2.5"` 等全部移除，缺失抛错
  3. 确定性输出：`temperature = 0`（贪婪解码）

---

## 二、变更范围

### 2.1 涉及文件

| 文件 | 改动类型 | 说明 |
|------|---------|------|
| `.env.development` | 修改 | `OPENAI_API_KEY_DASHSCOPE` 拆为 `LLM_API_KEY` / `H5_LLM_API_KEY` / `EMBEDDING_API_KEY` |
| `.env.example` | 修改 | 同上 + 删除 `H5_LLM_TEMPERATURE` / `H5_LLM_MAX_TOKENS`（不应在 .env 中） |
| `.env.production` | 修改 | 同 `.env.development` |
| `src/config/model.toml` | 修改 | 新增 `[defaults.h5]` 段；三段 `temperature` 改为 0 |
| `src/config/model-config.ts` | 修改 | `buildCloudModels` 前置校验；`OLLAMA_DEFAULTS` 强校验；`buildFallbackCloudModels` 抛错；`TomlDefaults` 补 `h5` 类型 |
| `src/lib/llm/index.ts` | 修改 | 新增 `readDefaults()` 统一入口；`getLLMConfig()` 三段读 toml；`h5Llm` 读 `[defaults.h5]`；去掉 model 名硬编码 |
| `src/lib/embeddings/index.ts` | 修改 | `resolveCloudApiKey()` 新增 `EMBEDDING_API_KEY` 优先 |
| `src/stores/model-config-store.ts` | 修改 | `ollamaDefaults` 导入自 `model-config.ts` 而非硬编码 |

### 2.2 关键设计决策

1. **`readDefaults(section)` 统一入口**: 三处 LLM 初始化（cloud / ollama / h5）通过同一函数读 toml，参数缺失即抛错，零重复逻辑
2. **API Key 分拆 + 向后兼容**: 每个 resolve 函数优先读新 key（`LLM_API_KEY` / `H5_LLM_API_KEY` / `EMBEDDING_API_KEY`），fallback 链保留旧变量 `OPENAI_API_KEY_DASHSCOPE` 确保过渡期兼容
3. **H5 参数从 .env 撤离**: `H5_LLM_TEMPERATURE` / `H5_LLM_MAX_TOKENS` 归属于 `model.toml [defaults.h5]`，不在 .env 中定义

---

## 三、Tasks（合并在 Plan 中，无需独立 spec/tasks.md）

### Phase 1: API Key 分拆（.env + resolve 逻辑）

- [x] Task 1.1: 三个 .env 文件拆分 API Key
  - [x] SubTask 1.1.1: `.env.development` 新增 `LLM_API_KEY` / `H5_LLM_API_KEY` / `EMBEDDING_API_KEY`，删除 `OPENAI_API_KEY_DASHSCOPE`
  - [x] SubTask 1.1.2: `.env.example` 同步拆分 + 删除 `H5_LLM_TEMPERATURE` / `H5_LLM_MAX_TOKENS`
  - [x] SubTask 1.1.3: `.env.production` 同步拆分
- [x] Task 1.2: resolve 函数适配新 key
  - [x] SubTask 1.2.1: `llm/index.ts` `resolveLLMApiKey()` 新增 `LLM_API_KEY` 优先
  - [x] SubTask 1.2.2: `llm/index.ts` `h5Llm` 仅用 `H5_LLM_API_KEY`
  - [x] SubTask 1.2.3: `embeddings/index.ts` `resolveCloudApiKey()` 新增 `EMBEDDING_API_KEY` 优先

### Phase 2: model.toml 结构与接口

- [x] Task 2.1: 新增 `[defaults.h5]` 段（baseURL / temperature / maxTokens）
- [x] Task 2.2: `TomlDefaults` 接口补上 `h5` 类型定义
- [x] Task 2.3: 三段 `temperature` 改为 0（贪婪解码）

### Phase 3: 零硬编码兜底

- [x] Task 3.1: `llm/index.ts` 消除硬编码
  - [x] SubTask 3.1.1: 新增 `readDefaults()` 统一入口
  - [x] SubTask 3.1.2: `getLLMConfig()` cloud/ollama 改为 `readDefaults()`
  - [x] SubTask 3.1.3: `h5Llm` 改为 `readDefaults("h5")`
  - [x] SubTask 3.1.4: 删除 model 名硬编码（`"qwen2.5"` / `"qwen-vl-plus"`）
- [x] Task 3.2: `model-config.ts` 消除硬编码
  - [x] SubTask 3.2.1: `buildCloudModels` 前置校验 `[defaults.cloud]`
  - [x] SubTask 3.2.2: `OLLAMA_DEFAULTS` 改为 `readOllamaDefaults()` 强校验
  - [x] SubTask 3.2.3: `buildFallbackCloudModels` 改为抛错（不复用 env 兜底）
  - [x] SubTask 3.2.4: `getDefaultModelId` 删除 `"cloud-qwen-vl-plus"` 兜底
- [x] Task 3.3: `model-config-store.ts` 导入 `OLLAMA_DEFAULTS` 替代自维护硬编码

---

## 四、Handoff

### 4.1 交接前状态

- 一个 `OPENAI_API_KEY_DASHSCOPE` 被主 LLM / H5 轻量 / Embedding 三路共用
- `llm/index.ts` 有多处 `temperature: 0.1` / `maxTokens: 4000` / `model: "qwen2.5"` 硬编码
- `model-config.ts` 有多处 `?? 0.3` / `?? 4000` / `|| "https://dashscope..."` 硬编码兜底
- `model-config-store.ts` 有两处独立维护的 ollama 默认值（与 toml 不同步）
- `.env.example` 存在不应在此定义的 `H5_LLM_TEMPERATURE` / `H5_LLM_MAX_TOKENS`

### 4.2 交接后状态（目标）

- 三个独立 API Key 变量：`LLM_API_KEY` / `H5_LLM_API_KEY` / `EMBEDDING_API_KEY`，旧 `OPENAI_API_KEY_DASHSCOPE` 仅作 resolve 链 fallback
- 所有模型默认参数（temperature / maxTokens / baseURL）只存在于 `model.toml` 三段 defaults
- 代码中无任何数值兜底：配置缺失 → 抛明确错误
- `model.toml` 接口类型完整覆盖 cloud / h5 / ollama 三段
- `model-config-store.ts` 唯一引用 `model-config.ts` 的 `OLLAMA_DEFAULTS`

### 4.3 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `.env.development` | 修改 | API Key 一分三 + 注释 |
| 2 | `.env.example` | 修改 | API Key 一分三 + 删除 H5_LLM_TEMPERATURE / H5_LLM_MAX_TOKENS |
| 3 | `.env.production` | 修改 | API Key 一分三 |
| 4 | `src/config/model.toml` | 修改 | 新增 `[defaults.h5]`；temperature 改为 0 |
| 5 | `src/config/model-config.ts` | 修改 | 三段强校验 + 去兜底 + 补接口 |
| 6 | `src/lib/llm/index.ts` | 修改 | `readDefaults()` + `getLLMConfig()` / `h5Llm` 重构 |
| 7 | `src/lib/embeddings/index.ts` | 修改 | `resolveCloudApiKey()` 新增 key |
| 8 | `src/stores/model-config-store.ts` | 修改 | 导入 `OLLAMA_DEFAULTS` |

### 4.4 回滚方案

```bash
git checkout -- .env.development .env.example .env.production
git checkout -- src/config/model.toml src/config/model-config.ts
git checkout -- src/lib/llm/index.ts src/lib/embeddings/index.ts src/stores/model-config-store.ts
```

### 4.5 执行前置检查

- [x] `.env.development` 已有各 API Key 值
- [x] `model.toml` 三段 defaults 完整
- [x] `npx tsc --noEmit` 无本变更引入的新错误

### 4.6 执行步骤摘要

```text
Phase 1: .env 分拆 ─────────────────────┐
                                         │
Phase 2: model.toml + 接口 ─────────────┤ 可并行
                                         │
Phase 3: 代码零兜底 ─────────────────────┘
            │
            ├── Task 3.1 llm/index.ts ──┐
            ├── Task 3.2 model-config ──┤ 可并行
            └── Task 3.3 store ─────────┘
                        │
                        ▼
                 全部 Task 完成
```

### 4.7 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| `model.toml` 缺少 `[defaults.h5]` 段 | `h5Llm` 初始化抛错，H5 功能不可用 | `.env.development` / `.env.production` 已预置完整 toml |
| 旧部署未设置新 API Key | `getLLMConfig()` resolve 返回空 key，LLM 调用失败 | resolve 链保留 `OPENAI_API_KEY_DASHSCOPE` fallback |
| `buildFallbackCloudModels` 改为抛错 | 若 toml 不存在则整个模型列表初始化失败 | toml 作为代码资产一同部署，不存在缺失场景 |
| temperature = 0 导致输出过于僵化 | 部分需要创造性的回答质量下降 | 农业决策场景要求确定性；如后续需要可调回 |

### 4.8 恢复上下文审计查询（新 AI Session 首次启动必读）

> 以下 `query_audit_logs(...)` 均为 MCP 工具调用，后续 AI 助手直接复制粘贴调用即可。

#### 总体一键恢复

```text
query_audit_logs({ keyword: "llm-config-centralization" })
```
→ 预期返回 10 条记录（8 文件改动 + 1 plan + 1 template）

#### 逐文件审计查询

```text
query_audit_logs({ targetId: ".env.development" })
→ MODIFY: API Key 一分三

query_audit_logs({ targetId: ".env.example" })
→ MODIFY: 同步拆分 + 删除 H5_LLM_TEMPERATURE

query_audit_logs({ targetId: ".env.production" })
→ MODIFY: 同步拆分

query_audit_logs({ targetId: "src/config/model.toml" })
→ MODIFY: 新增 [defaults.h5]，temperature→0

query_audit_logs({ targetId: "src/config/model-config.ts" })
→ MODIFY: 三段强校验 + 去兜底 + 补接口

query_audit_logs({ targetId: "src/lib/llm/index.ts" })
→ MODIFY: readDefaults() + 零硬编码

query_audit_logs({ targetId: "src/lib/embeddings/index.ts" })
→ MODIFY: EMBEDDING_API_KEY 优先

query_audit_logs({ targetId: "src/stores/model-config-store.ts" })
→ MODIFY: 导入 OLLAMA_DEFAULTS

query_audit_logs({ targetId: ".qoder/plans/2026-07/04/llm-config-centralization-plan-v1.md" })
→ CREATE: Plan 文档

query_audit_logs({ targetId: ".qoder/templates/simple-plan-template.md" })
→ CREATE: 精简模板
```

#### 恢复判定标准

- action 命中数 ≥ 10
- grep 验证：

```bash
grep -R "readDefaults" src/lib/llm/
grep -R "EMBEDDING_API_KEY" src/lib/embeddings/
grep "temperature = 0" src/config/model.toml
```

### 4.9 后置确认

- [x] `.env` 不再存在 `OPENAI_API_KEY_DASHSCOPE`
- [x] `model.toml` 三段 defaults 完整且独立
- [x] 代码中无 `?? 0.1` / `?? 4000` / `?? 0.3` / `\|\| "qwen2.5"` 等硬编码数值兜底
- [x] 配置缺失时抛明确错误信息而非静默降级

### 4.9 脱敏要求

本 Handoff 中所有 API Key 值已通过 `${LLM_API_KEY}` / `${H5_LLM_API_KEY}` / `${EMBEDDING_API_KEY}` 引用，实际值见 `.env.development`。

---

## 五、验收标准

- [x] `.env` 不再存在 `OPENAI_API_KEY_DASHSCOPE`
- [x] `model.toml` 三段 defaults 完整且独立（cloud / h5 / ollama）
- [x] 代码中无 `temperature: 0.1` / `maxTokens: 4000` 等硬编码模型参数
- [x] 配置缺失时抛明确错误信息而非静默降级
- [x] API Key 按 LLM / H5 / Embedding 三路独立
- [x] `temperature = 0` 三段统一

---

## 六、关联

| 类型 | 路径 |
|------|------|
| Handoff | 见本文第四部分 |
| Review | 不适用（Plan 逻辑简单，用户授权跳过） |
