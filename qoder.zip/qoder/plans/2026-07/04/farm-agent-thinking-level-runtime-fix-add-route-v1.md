# farm-agent-thinking-level-runtime-fix-add-route-v1

> **定位**：Plan → ADD Step 执行映射。不重复 Plan 的架构设计和任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）
>
> **绑定**：Plan: `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md` · Specs: `.qoder/specs/farm-agent-thinking-level-runtime-fix/` · Review: `.qoder/reviews/farm-agent-thinking-level-runtime-fix-review-v1.md`

---

## Step 0：文档先行（Documentation First）

**输入**：
- 上游 Review：`farm-agent-three-tier-reasoning-graph-review-runtime.md` 发现 #1
- Plan：`farm-agent-thinking-level-runtime-fix-plan-v1.md`
- Review：`farm-agent-thinking-level-runtime-fix-review-v1.md`（8 条，已全部回流至 Plan）

**动作**：
1. Specs 三元组已就绪：`spec.md` + `tasks.md` + `checklist.md`
2. `find_related_docs({ query: "thinkingLevel resolveThinkingLevel 路由裁决" })` → 0 匹配；已手动确认关联文档
3. 项目文档更新：需更新 API 文档（expertId → expertIds）
4. Review 回流已完成：8 条问题全部回流至 Plan §二~§四

**产出**：
- [x] Specs 三元组就绪
- [x] Review 回流已完成

---

## Step 1：功能分析与审计打点定义

| 字面量 | 使用场景 | 轮次 |
|-------|---------|:--:|
| `THINKING_LEVEL_RESOLVED` | `resolveThinkingLevel` 返回时记录裁决来源 | 第2轮 |

**产出**：
- [x] 审计打点清单已记录

---

## Step 2：审计基础设施确认

**产出**：
- [x] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

### §3.0 前置守卫

- [ ] `check_add_route_status` 通过

### Task 映射表（按 Plan 5 轮）

| # | 轮次 | 文件 | 操作 | 审计植入点 | 状态 |
|---|:--:|------|:--:|-----------|:--:|
| 0 | 1 | `src/agents/types/sub-intent.ts` | MODIFY | 无 | ⬜ |
| 1 | 1 | `src/agents/prompts/intent-constants.ts` | MODIFY | 无 | ⬜ |
| 2 | 1 | `src/agents/prompts/intention.ts` | MODIFY | 无 | ⬜ |
| 3 | 1 | `src/agents/prompts/intention_async.ts` | MODIFY | 无 | ⬜ |
| 4 | 1 | `src/agents/nodes/intention.ts` | MODIFY | rename | ⬜ |
| 5 | 1 | `src/agents/nodes/intention-async.ts` | MODIFY | rename | ⬜ |
| 6 | 1 | `src/caijuehub/strategies/sub-intent.ts` | MODIFY | rename | ⬜ |
| 7 | 1 | `src/app/api/agent/chat/stream/route.ts` | MODIFY | rename | ⬜ |
| 8 | 1 | `src/api/agent/contracts/dashboard-contract.ts` | MODIFY | 预计算决策表 | ⬜ |
| 9 | 1 | `src/agents/prompts/schemas/intention.ts` | CREATE | 无 | ⬜ |
| 10 | 2 | `src/caijuehub/strategies/thinking-level.ts` | MODIFY | 无 | ⬜ |
| 11 | 2 | `src/lib/log/phase.ts` | MODIFY | THINKING_LEVEL_RESOLVED | ⬜ |
| 12 | 3 | `src/agents/state.ts` | MODIFY | explicitExpertIds | ⬜ |
| 13 | 3 | `src/agents/agent-runner.ts` | MODIFY | 接口适配 | ⬜ |
| 14 | 3 | `src/app/api/agent/chat/stream/route.ts` | MODIFY | API 契约 | ⬜ |
| 15 | 3 | `src/app/api/types/farm-agent/schemas.ts` | MODIFY | Zod schema | ⬜ |
| 16 | 3 | `src/agents/nodes/intention.ts` | MODIFY | scope fix | ⬜ |
| 17 | 4 | `src/agents/nodes/intention-async.ts` | MODIFY | scope fix | ⬜ |
| 18 | 4 | `src/agents/nodes/reasoning.ts` | MODIFY | 适配 | ⬜ |
| 19 | 4 | `src/agents/edges/conditional.ts` | MODIFY | 适配 | ⬜ |
| 20 | 5 | API 文档（2 份） | MODIFY | expertIds | ⬜ |
| 21 | 5 | `tests/thinking-level.test.ts` | CREATE | 无 | ⬜ |

### 依赖拓扑

```
第1轮: SubIntent双字段+C增强（类型+模板+parse）
    │  10文件
    ▼
第2轮: thinking-level.ts（策略函数）
    │  2文件
    ▼
第3轮: intention.ts调用方（state+route+scope fix）
    │  5文件
    ▼
第4轮: intention-async.ts调用方（scope fix+reasoning+conditional）
    │  4文件
    ▼
第5轮: 全量验证（tsc+eslint+vitest+API文档）
    │  3文件
```

**产出**：
- [ ] 全部 Task 完成
- [ ] 每个文件有 `record_dev_operation` 记录

---

## Step 3.5：实现审查

- [ ] `checklist.md` 全部 `[T]` 项已通过
- [ ] `review-implementation.md` 已生成

---

## Step 4：审计数据验证

- [ ] `tsc --noEmit` 通过
- [ ] `npm run lint` 通过
- [ ] 对称性验证通过

### §4.6 RAHS 闸门

- [ ] RAHS 已通过（≥ 90）

---

## Step 8：收敛判断 + Handoff 更新

- [ ] 收敛判定通过
- [ ] Handoff 已更新
- [ ] 架构文档已校准

---

## 附录：文件清单

| 文件 | 操作 | 轮次 | targetType | 状态 |
|------|:--:|:--:|-----------|:--:|
| `src/agents/types/sub-intent.ts` | MODIFY | 1 | TYPE | ⬜ |
| `src/agents/prompts/intent-constants.ts` | MODIFY | 1 | PROMPT | ⬜ |
| `src/agents/prompts/intention.ts` | MODIFY | 1 | PROMPT | ⬜ |
| `src/agents/prompts/intention_async.ts` | MODIFY | 1 | PROMPT | ⬜ |
| `src/agents/prompts/schemas/intention.ts` | CREATE | 1 | SCHEMA | ⬜ |
| `src/agents/nodes/intention.ts` | MODIFY | 1 | NODE | ⬜ |
| `src/agents/nodes/intention-async.ts` | MODIFY | 1 | NODE | ⬜ |
| `src/caijuehub/strategies/sub-intent.ts` | MODIFY | 1 | STRATEGY | ⬜ |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY | 1 | API | ⬜ |
| `src/api/agent/contracts/dashboard-contract.ts` | MODIFY | 1 | CONTRACT | ⬜ |
| `src/caijuehub/strategies/thinking-level.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/lib/log/phase.ts` | MODIFY | 2 | INFRA | ⬜ |
| `src/agents/state.ts` | MODIFY | 3 | STATE | ⬜ |
| `src/agents/agent-runner.ts` | MODIFY | 3 | INTERFACE | ⬜ |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY | 3 | API | ⬜ |
| `src/app/api/types/farm-agent/schemas.ts` | MODIFY | 3 | SCHEMA | ⬜ |
| `src/agents/nodes/intention.ts` | MODIFY | 3 | NODE | ⬜ |
| `src/agents/nodes/intention-async.ts` | MODIFY | 4 | NODE | ⬜ |
| `src/agents/nodes/reasoning.ts` | MODIFY | 4 | NODE | ⬜ |
| `src/agents/edges/conditional.ts` | MODIFY | 4 | EDGE | ⬜ |
| `神经元GUI-SSE流式聊天协议文档.md` | MODIFY | 5 | DOC | ⬜ |
| `神经元GUI-API对接文档.md` | MODIFY | 5 | DOC | ⬜ |
| `tests/thinking-level.test.ts` | CREATE | 5 | TEST | ⬜ |
# farm-agent-thinking-level-runtime-fix-add-route-v1

> **定位**：Plan → ADD Step 执行映射。不重复 Plan 的架构设计和任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"，包含 `check_spec_sync` 文档-代码交叉校验。
>
> **绑定**：Plan: `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md` · Specs: `.qoder/specs/farm-agent-thinking-level-runtime-fix/` · Review: `.qoder/reviews/farm-agent-thinking-level-runtime-fix-review-v1.md`

---

## Step 0：文档先行（Documentation First）

**输入**：
- 上游 Review：`farm-agent-three-tier-reasoning-graph-review-runtime.md` 发现 #1
- Plan：`farm-agent-thinking-level-runtime-fix-plan-v1.md`
- Review：`farm-agent-thinking-level-runtime-fix-review-v1.md`（8 条，已全部回流至 Plan）

**动作**：
1. Specs 三元组已就绪：`spec.md` + `tasks.md` + `checklist.md`
2. `find_related_docs({ query: "thinkingLevel resolveThinkingLevel 路由裁决" })` → 0 匹配；已手动确认关联文档
3. 项目文档更新：需更新 API 文档（`神经元GUI-SSE流式聊天协议文档.md` + `神经元GUI-API对接文档.md`：expertId → expertIds）
4. Review 回流已完成：8 条问题（2 P0 + 3 P1 + 3 P2）全部回流至 Plan §二~§四

**产出**：
- [ ] 验证并更新项目状态：Specs 三元组就绪
- [ ] 验证并更新项目状态：API 文档待 Task 2.4 更新
- [ ] 验证并更新项目状态：Review 回流已完成

### §0.7 原子闭包三可性判定

```
原子闭包三可性判定
══════════════════
业务功能: resolveThinkingLevel 支持跨域/语义冲突路由到 professional 图
         + SkillCard 预计算决策表（零运行时成本）

逐轮业务价值判定:
  第1轮 (SubIntent双字段 + C增强 + dashboard-contract + thinking-level.ts):
    类型+模板+parse+预计算决策表+新裁决逻辑 全部对齐
    → 单独交付后: thinking-level.ts 可编译，但调用方尚未接入
    → 不能用，等待调用方接入

  第2轮 (State + API 契约 + intention.ts + intention-async.ts + reasoning.ts):
    state 扩展 + API 适配 + 所有 consumer 修复
    → 单独交付后: professional 路由可达 + SkillCard 路径可用
    → 能用，产生了独立业务价值

  第3轮 (API 文档 + 全量验证):
    文档更新 + tsc + eslint + vitest
    → 验证轮，不产生新业务价值

判定结论: 需要 2 轮原子闭包（第1+2轮分别不可用→合并；第3轮为验证轮，依附于第2闭包）

第1轮（原子闭包1）: 第1轮 + 第2轮 — 业务功能: professional 路由可达 + SkillCard 决策表生效
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅

第2轮（原子闭包2）: 第3轮 — 业务功能: 全部验收通过 + API 文档更新
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

### §0.8 DPS 闸门

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计打点定义

**动作**：
1. 本次为 runtime-fix，涉及文件已有审计打点基础设施
2. 新增审计字面量：`THINKING_LEVEL_RESOLVED`（记录裁决来源：A 规则 / C 升权 / prebuilt / deep）

| 字面量 | 使用场景 | 轮次 |
|-------|---------|:--:|
| `THINKING_LEVEL_RESOLVED` | `resolveThinkingLevel` 返回时记录裁决来源；L147 prebuilt 路径记录 "prebuilt" | 第1轮 |

**产出**：
- [ ] 验证并更新项目状态：审计打点清单已记录

---

## Step 2：审计基础设施确认

**动作**：
1. 确认 `agentAudit()` 通道可用
2. 裁决来源记录在调用方（intention.ts L147 / intention-async.ts）

**产出**：
- [ ] 验证并更新项目状态：`agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

### §3.0 前置守卫

- [ ] `check_add_route_status` 通过

### Task 映射表

| # | 轮次 | 文件 | 操作 | 审计植入点 | 新增字面量 | 状态 |
|---|:--:|------|:--:|-----------|-----------|:--:|
| 0 | 1 | `src/agents/types/sub-intent.ts` | MODIFY | 无（类型定义） | — | ⬜ |
| 1 | 1 | `src/agents/prompts/intent-constants.ts` | MODIFY | 无（常量文案） | — | ⬜ |
| 2 | 1 | `src/agents/prompts/intention.ts` | MODIFY | 无（prompt+parse） | — | ⬜ |
| 3 | 1 | `src/agents/prompts/intention_async.ts` | MODIFY | 无（prompt+parse） | — | ⬜ |
| 4 | 1 | `src/agents/nodes/intention.ts` | MODIFY | si.domain→si.expertId（纯 rename） | — | ⬜ |
| 5 | 1 | `src/agents/nodes/intention-async.ts` | MODIFY | 同上 | — | ⬜ |
| 6 | 1 | `src/caijuehub/strategies/sub-intent.ts` | MODIFY | 同上 | — | ⬜ |
| 7 | 1 | `src/app/api/agent/chat/stream/route.ts` | MODIFY | si.domain→si.expertId（纯 rename） | — | ⬜ |
| 8 | 1 | `src/api/agent/contracts/dashboard-contract.ts` | MODIFY | 预计算决策表扩展 | — | ⬜ |
| 9 | 1 | `src/caijuehub/strategies/thinking-level.ts` | MODIFY | 无（策略纯函数） | — | ⬜ |
| 10 | 1 | `src/lib/agent-audit-logger.ts` | MODIFY | 新增 `THINKING_LEVEL_RESOLVED` | THINKING_LEVEL_RESOLVED | ⬜ |
| 11 | 2 | `src/agents/state.ts` | MODIFY | explicitExpertId→explicitExpertIds + 3 prebuilt 字段 | — | ⬜ |
| 12 | 2 | `src/app/api/agent/chat/stream/route.ts` | MODIFY | L119/270 API 契约 + prebuilt 传递 | — | ⬜ |
| 13 | 2 | `src/agents/nodes/intention.ts` | MODIFY | thinkingLevel 外部 let + 传 subIntents + prebuilt 优先 | THINKING_LEVEL_RESOLVED | ⬜ |
| 14 | 2 | `src/agents/nodes/intention-async.ts` | MODIFY | explicitExpertIds 适配 + thinkingLevel 外部 let | — | ⬜ |
| 15 | 2 | `src/agents/nodes/reasoning.ts` | MODIFY | explicitExpertId→explicitExpertIds?.[0] | — | ⬜ |
| 16 | 2 | API 文档（2 份） | MODIFY | expertId→expertIds | — | ⬜ |

### 依赖拓扑

```
第1轮: SubIntent双字段+C增强+dashboard-contract+thinking-level.ts
    │  10文件类型对齐 + 1文件新逻辑
    ▼
第2轮: state.ts + route.ts + intention.ts + intention-async.ts + reasoning.ts + API文档
    │  6文件结构性修复 + 2文档更新
    ▼
验证: tsc + eslint + vitest 全量验证
```

**产出**：
- [ ] 验证并更新项目状态：全部 Task 完成
- [ ] 验证并更新项目状态：每个文件有 `record_dev_operation` 记录
- [ ] 验证并更新项目状态：`check_spec_sync` 通过

---

## Step 3.5：实现审查

- [ ] 验证并更新项目状态：`checklist.md` 全部 `[T]` 项已通过
- [ ] 验证并更新项目状态：`review-implementation.md` 已生成
- [ ] 验证并更新项目状态：`check_spec_sync` 通过

---

## Step 4：审计数据验证

- [ ] `tsc --noEmit` 通过
- [ ] `npm run lint` 通过
- [ ] 对称性验证通过
- [ ] 失败路径审计等价验证通过

### §4.6 RAHS 闸门

- [ ] RAHS 已通过（≥ 90）

---

## Step 8：收敛判断 + Handoff 更新

- [ ] 验证并更新项目状态：收敛判定通过
- [ ] 验证并更新项目状态：Handoff 已更新
- [ ] 验证并更新项目状态：架构文档已校准（API 文档已更新）

---

## 附录：文件清单

| 文件 | 操作 | 轮次 | targetType | 状态 |
|------|:--:|:--:|-----------|:--:|
| `src/agents/types/sub-intent.ts` | MODIFY | 1 | TYPE | ⬜ |
| `src/agents/prompts/intent-constants.ts` | MODIFY | 1 | PROMPT | ⬜ |
| `src/agents/prompts/intention.ts` | MODIFY | 1 | PROMPT | ⬜ |
| `src/agents/prompts/intention_async.ts` | MODIFY | 1 | PROMPT | ⬜ |
| `src/agents/nodes/intention.ts` | MODIFY | 1 | NODE | ⬜ |
| `src/agents/nodes/intention-async.ts` | MODIFY | 1 | NODE | ⬜ |
| `src/caijuehub/strategies/sub-intent.ts` | MODIFY | 1 | STRATEGY | ⬜ |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY | 1 | API | ⬜ |
| `src/api/agent/contracts/dashboard-contract.ts` | MODIFY | 1 | CONTRACT | ⬜ |
| `src/caijuehub/strategies/thinking-level.ts` | MODIFY | 1 | COMPONENT | ⬜ |
| `src/lib/agent-audit-logger.ts` | MODIFY | 1 | INFRA | ⬜ |
| `src/agents/state.ts` | MODIFY | 2 | STATE | ⬜ |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY | 2 | API | ⬜ |
| `src/agents/nodes/intention.ts` | MODIFY | 2 | NODE | ⬜ |
| `src/agents/nodes/intention-async.ts` | MODIFY | 2 | NODE | ⬜ |
| `src/agents/nodes/reasoning.ts` | MODIFY | 2 | NODE | ⬜ |
| `神经元GUI-SSE流式聊天协议文档.md` | MODIFY | 2 | DOC | ⬜ |
| `神经元GUI-API对接文档.md` | MODIFY | 2 | DOC | ⬜ |
