# farm-agent-thinking-level-runtime-fix-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。Spec 负责完整类型定义、精确函数签名。详见 [ADD 文档协同规范 §8.1.1](file:///home/xmm/ai/farm-agent/docs/大田精准耕播智能决策系统/knowledge/01-架构/《ADD开发工作路径与文档协同规范》.md)。

## PLAN 元信息

- **Plan 名称**: farm-agent-thinking-level-runtime-fix-v1
- **启动时间**: 2026-07-04T12:00:00+08:00
- **主导 AI**: Qoder
- **触发来源**: `.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-runtime.md` 发现 #1
- **关联文档**:
  - Handoff: `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-thinking-level-runtime-fix-review-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/caijuehub/strategies/thinking-level.ts` | COMPONENT | COMPONENT_MODIFIED | 仅 fast/deep 二值 | A 规则 (≥2域→professional) + C 升权 | 待实施 |
| `src/agents/types/sub-intent.ts` | TYPE | TYPE_MODIFIED | domain: string | expertId: string + domain: ExpertDomain | 待实施 |
| `src/agents/nodes/intention.ts` | NODE | NODE_MODIFIED | 无 subIntents 传递 | thinkingLevel 外部作用域 + 传 subIntents | 待实施 |
| `src/agents/nodes/intention-async.ts` | NODE | NODE_MODIFIED | 同上 | 同上 + L82 传 subIntents | 待实施 |
| `src/agents/prompts/intention.ts` | PROMPT | PROMPT_MODIFIED | 不含 thinkingLevel | LLM 产出 thinkingLevel | 待实施 |
| `src/agents/prompts/intention_async.ts` | PROMPT | PROMPT_MODIFIED | 同上 | 同上 | 待实施 |
| `src/agents/prompts/intent-constants.ts` | PROMPT | PROMPT_MODIFIED | domain→域标识 | expertId→专家标识 | 待实施 |
| `src/caijuehub/strategies/sub-intent.ts` | STRATEGY | STRATEGY_MODIFIED | si.domain | si.expertId | 待实施 |
| `src/app/api/agent/chat/stream/route.ts` | API | API_MODIFIED | si.domain | si.expertId + si.domain | 待实施 |
| `src/agents/state.ts` | STATE | STATE_MODIFIED | explicitExpertId: string \| null | explicitExpertIds: string[] | 待实施 |
| `src/app/api/agent/chat/stream/route.ts` | API | API_MODIFIED | 收 expertId 单值 | 收 expertIds 数组 + si.expertId + si.domain + explicitExpertIds | 待实施 |
| `src/api/agent/contracts/dashboard-contract.ts` | CONTRACT | CONTRACT_MODIFIED | SkillCard: id 单值 | 预计算决策表：expertIds[] + thinkingLevel + subIntents[] + expertPlan[] + 新增多专家卡片 | 待实施 |

- **原子事务结构**: 5 轮
  - 第1轮：SubIntent 双字段 + C 增强（类型定义 + LLM 模板 + parse 逻辑，一次性对齐）
  - 第2轮：thinking-level.ts 新逻辑（依赖第1轮类型定义 + llmSuggestedLevel 参数）
  - 第3轮：intention.ts 调用方结构性修复（state + route 契约 + scope fix，依赖第2轮函数签名）
  - 第4轮：intention-async.ts 调用方结构性修复（scope fix + reasoning/conditional 适配，依赖第2轮函数签名）
  - 第5轮：tsc + eslint + vitest + API 文档（全量验证）

---

## 一、背景与目标

### 1.1 问题现状

`resolveThinkingLevel` (src/caijuehub/strategies/thinking-level.ts) 当前仅返回 `"fast"` | `"deep"`，从未返回 `"professional"`。原因：

1. **未消费 subIntents**：函数只看 `intent` 和 `explicitExpertId`，LLM 拆解出的 `subIntents` 在 `resolveSubIntentPlan` 中用完后就被遗弃，没有传递到路由层
2. **scope bug**：`intention.ts` L271 和 `intention-async.ts` L160 在 try/catch 外部重算 `resolveThinkingLevel` 但没传 `subIntents`，会覆写 try 块内的 professional 裁决
3. **字段语义错误**：`SubIntent.domain` 实际存 expertId（如 "pest_risk"），不是 ExpertDomain（如 "种"），导致 getDomains 需要额外映射

后果：跨域多专家场景永远走 deep 图，professional 图（intentionAsyncNode / Router）全线未触发。Router 模块（domain-vocabulary-v2 核心交付物）的 Tier 1 路径永不可达。

涉及上游 Plan：
- `farm-agent-three-tier-reasoning-graph-plan-v3.md`（ACA professional 图——ThinkingLevel 已定义但裁决未实现）
- `farm-agent-domain-vocabulary-plan-v2.md`（Router 模块——wiring 完成但无入口触发）

**professional 图当前状态**：即使修复路由，当前 professionalWorkflow 是串行赝品（全 `.addEdge`，零 Send API fan-out），ACA v3 Plan 要求的 per-expert 并行推理未实现。本 Plan 只修路由，ACA v3 Plan 轮次 4 负责重建图为 Send API fan-out。两者职责不重叠。

**领域分类体系**（ANALYSIS_EXPERTS，`registry.ts`）：

| 领域 | 专家 | 汇总专家？ |
|------|------|:--:|
| 种 | crop_compare, land_analysis, planting_advice, variety_recommend | ❌ |
| 管 | growth_report, nutrition_diagnose, pest_risk, weather_impact | ❌ |
| 跨域 | cost_accounting, machinery_dispatch, roi_analysis, work_plan, daily_report, weekly_report | daily/weekly: ✅ |

> `ExpertDomain` 共 6 个值，当前仅 3 个有专家填充。`daily_report` / `weekly_report` 标记 `isSummary: true`，不参与跨域冲突检测。

### 1.2 目标

- `resolveThinkingLevel` 在跨域 ≥2 或 LLM 判断语义冲突时返回 `"professional"`
- professional 图入口可达（路由正确即可，不保证节点全部就绪）
- `SubIntent` 类型语义修正（双字段，消除 expertId/domain 混淆）
- 零 tsc 错误，零 eslint error，现有 deep 图不受影响

---

## 二、方案选型

### 2.1 候选方案对比

| 维度 | A: 纯代码规则 | B: 纯 LLM 裁决 | A+C: 代码规则 + LLM 兜底（选择） |
|------|:--:|:--:|:--:|
| 触发机制 | `getDomains() ≥ 2` → professional | LLM 每次产出 `thinkingLevel` | A 先判；A 不触发时 C 可升权为 professional |
| 成本 | 零 LLM | 每次 1 次 LLM token | A 零成本；C 复用 intention 调用（A 已判 professional 时跳过 C） |
| 覆盖面 | 仅跨域 ≥2（同域冲突捕获不到） | 全场景 | A 覆盖确定场景 + C 覆盖边缘，A 不触发时 C 可升权 |
| 稳定性 | 确定性，零漂移 | LLM 有概率漂移 | A 部分确定性，C 有概率但频率低 |
| 新增领域 | 需更新 config 域分类 | LLM 自动识别 | A 依赖 config；演进时 C 升权兜底 |

### 2.2 方案 A（纯代码规则，被淘汰）

仅通过 `getDomains()` 判断跨域 ExpertDomain 数量：≥2 → professional。

**淘汰理由**：同域语义冲突（如 "抗病品种 vs 产量优先"——两个 "种" 域 expert）无法捕获；新领域演进时 config 未更新则永久降级为 deep。

### 2.3 方案 B（纯 LLM 裁决，被淘汰）

完全依赖 LLM 在 intention prompt 中产出 `thinkingLevel`，代码不做任何域分类裁决。

**淘汰理由**：每次加入额外 LLM token，增加延迟；无确定性保障——LLM 可能漏判跨域冲突。专业农业场景的域分类是已知的确定性知识，不应交出给 LLM。

### 2.4 选型理由（A+C）

- A 覆盖 90% 确定性场景（零 LLM 成本，注册表映射保证准确性）
- C 覆盖剩余边缘场景（复用已有 intention LLM 调用，无额外延迟）
- 互补：A 先判，C 可推翻 A 的 negative 裁决（deep → professional），但 C 不能降级 A 的 professional
- 原子事务：一轮完成，A 和 C 同时上线，不留预留参数

### 2.5 SubIntent 双字段方案

当前 `domain: string` 存的是 expertId，与 ExpertDomain 类型名冲突。改为双字段：

```typescript
interface SubIntent {
  expertId: string       // 来自 LLM/Router，ANALYSIS_EXPERTS key
  domain: ExpertDomain   // 代码推导，ANALYSIS_EXPERTS[id]?.domain ?? "跨域"
  subQuery: string
}
```

`domain` 在 parse 后由代码填充（LLM prompt 改输出 `expertId`），不再依赖 LLM 产出的字段名。getDomains 简化为 `si.domain` 直读。

### 2.6 SkillCard 预计算决策表（dashboard-contract.ts）

当前 `SkillCard` 只含展示字段（id/label/description/icon），专家图需要的数据由 API 侧运行时组装。

**方案**：SkillCard 作为"预计算决策表"——静态定义 thinkingLevel + subIntents + expertPlan，点击后 API 直接透传，跳过 resolveThinkingLevel 和所有运行时组装。

```typescript
interface SkillCard {
  id: string
  category: "report_analysis" | "diagnostic" | "planning"
  label: string
  description: string
  icon: string
  expertIds: string[]                    // 始终是数组，单专家：[id]
  /** 预计算：A+C 裁决结果。deep = 单专家，professional = 多专家跨域 */
  thinkingLevel: ThinkingLevel           // 写死在卡片定义里
  /** 预计算：LLM/Router 产物。单专家 1 元素，多专家 N 元素 */
  subIntents: SubIntent[]                // 预构建
  /** 预计算：intentionNode expertPlan 产物。null = 由代码构建 */
  expertPlan?: Expert[]                  // 预构建，professional 图直接消费
}
```

**数据来源对比**：

| 路径 | thinkingLevel | subIntents | expertPlan | 成本 |
|------|:--:|:--:|:--:|:--:|
| 自由对话（LLM） | resolveThinkingLevel A+C 裁决 | LLM 拆解 | intentionNode 构建 | 1 次 LLM |
| GUI 单专家卡片 | 预计算 = deep | 预计算 = [{ expertId, domain, ... }] | 预计算 = null（deep 图自建） | 零 |
| GUI 多专家卡片 | 预计算 = professional | 预计算 = [{...}, {...}, {...}] | 预计算 = expertPlan | 零 |

> **A+C 不退场**：仅服务自由对话路径（用户打字，不走技能卡片）。预计算决策表覆盖所有卡片点击场景。

**现有 8 个单专家卡片适配**：每个加 `expertIds: [id]` + `thinkingLevel: "deep"` + `subIntents: [{ expertId: id, domain: ..., subQuery: ... }]`。`resolveKeywordExperts()` 无需改——它只用 `card.description` 和 `card.id`，新字段不影响。

**新增多专家卡片示例**：

```typescript
{
  id: "crop_decision",
  category: "planning",
  label: "作物决策",
  description: "综合考虑品种、病虫害、成本，制定最优种植决策",
  icon: "decision",
  expertIds: ["variety_recommend", "pest_risk", "roi_analysis"],
  thinkingLevel: "professional",
  subIntents: [
    { expertId: "variety_recommend", domain: "种", subQuery: "推荐适合本地的作物品种" },
    { expertId: "pest_risk", domain: "管", subQuery: "评估当前病虫害风险" },
    { expertId: "roi_analysis", domain: "跨域", subQuery: "分析各方案成本收益" },
  ],
  expertPlan: [ /* 预构建，同上 */ ],
}
```

---

## 三、架构设计

```
                    resolveThinkingLevel (新增 subIntents + llmSuggestedLevel)
                        │
        ┌───────────────┼───────────────┐
        ▼               ▼               ▼
   A 规则 (getDomains)       C 升权 (llmSuggestedLevel)
   跨域 ≥2 → professional  → professional
        │
        ▼
   routeByIntent → professionalGraph / deepGraph / fastGraph
```

**`getDomains` 数据来源**：

```
14 个 expert config（configs/*.config.ts）
  → registry.ts ANALYSIS_EXPERTS[expertId].domain
  → getDomains(SubIntent[]) → Set<ExpertDomain>
```

新增专家只需在 config 中填对 `domain`（"种/管/耕/收/巡检/跨域"），自动纳入裁决。

**`llmSuggestedLevel` 数据来源**：

```
intention prompt（intention.ts / intention_async.ts LLM JSON 模板）
  → LLM 产出 thinkingLevel 字段
  → parse 提取 → 传给 resolveThinkingLevel
```

LLM 不需要知道 ExpertDomain 分类——它凭语义判断子问题间是否存在冲突。

**数据模型变更**：

| 变更 | 层级 | 影响 |
|------|------|------|
| `SubIntent.domain: string` → `expertId: string` + `domain: ExpertDomain` | TypeScript 类型 | 所有 SubIntent 消费者（21 处引用） |
| LLM JSON 输出字段 `"domain"` → `"expertId"` | LLM 输出契约 | intention / intention_async prompt 模板 |
| LLM JSON 输出新增 `"thinkingLevel"` 字段 | LLM 输出契约 | parse 逻辑需同步提取 |
| `explicitExpertId: string \| null` → `explicitExpertIds: string[]` | LangGraph State + API 契约 | route.ts 收 `expertIds[]`；所有 consumer 适配；agrisynapse 同步改 |
| State 新增 `prebuiltSubIntents?: SubIntent[]` | LangGraph State | GUI 多专家卡片透传，跳过 API 侧组装 |
| State 新增 `prebuiltThinkingLevel?: ThinkingLevel` | LangGraph State | SkillCard 预计算，L147 跳过 resolveThinkingLevel |
| State 新增 `prebuiltExpertPlan?: Expert[]` | LangGraph State | SkillCard 预计算，professional 图直接消费 |
| `SkillCard` 扩展 `expertIds[]` + `subIntents?` | dashboard-contract | API zero-assembly，GUI 直传 professional 图入参 |

### 3.1 两条路径对比

```
路径一：自由对话（用户打字）
  intentionNode → LLM parse subIntents → resolveThinkingLevel A+C 裁决 → routeByIntent

路径二：技能卡片（预计算决策表，零运行时成本）
  DASHBOARD_SKILL_CARDS[id] → API 直接拿到 thinkingLevel + subIntents + expertPlan
    → resolveThinkingLevel 跳过，直接 routeByIntent
```

### 3.2 SkillCard → professional 图数据流

```
DASHBOARD_SKILL_CARDS（dashboard-contract.ts，静态热门数据）
  │  SkillCard.expertIds + SkillCard.subIntents（预构建）
  ▼
GUI 点击 → API body: { expertIds: string[], subIntents?: SubIntent[] }
  │
  ▼
route.ts → state.explicitExpertIds + state.prebuiltSubIntents
  │
  ├── LLM 路径：intention.ts L147 → 无 prebuiltSubIntents → LLM 产出 subIntents → A+C 裁决
  │
  └── GUI 技能卡片路径：有 card.thinkingLevel + card.subIntents + card.expertPlan
      → 跳过 resolveThinkingLevel，直接 routeByIntent
```

### 3.3 裁决优先级（仅自由对话路径）

**裁决优先级**：

```
1. intent === "chat" → "fast"        （闲聊，跳过 RAG）
2. getDomains(subIntents).size ≥ 2 → "professional"  （A 规则）
3. llmSuggestedLevel === "professional" → "professional" （A 未触发时，C 升权）
4. 默认              → "deep"
```

---

## 四、实施 Task + 依赖图

```
第1轮: SubIntent 双字段 + C 增强
    │
    ▼
第2轮: thinking-level.ts
    │
    ▼
第3轮: intention.ts 调用方
    │
    ▼
第4轮: intention-async.ts 调用方
    │
    ▼
第5轮: tsc + eslint + vitest
```

### 第1轮：SubIntent 双字段 + C 增强（类型 + 模板 + parse，一次对齐）

- [ ] 修改 `src/agents/types/sub-intent.ts`：`domain: string` → `expertId: string` + `domain: ExpertDomain`
- [ ] 修改 `src/agents/prompts/intent-constants.ts` L24：`"domain"（域标识）` → `"expertId"（专家标识）`
- [ ] 修改 `src/agents/prompts/intention.ts`：
  - LLM JSON 模板 `"domain": "域标识"` → `"expertId": "专家标识"` + **新增 `"thinkingLevel": "deep" 或 "professional"`** （L80-93）
  - 提示文案 `domain 字段` → `expertId 字段`（L99）
  - parse 检查 `typeof s.domain` → `typeof s.expertId`（L144）
  - parse 映射 `domain: s.domain` → `expertId: s.expertId, domain: ANALYSIS_EXPERTS[s.expertId]?.domain ?? "跨域"`（L148）
  - parse 提取 `parsed.thinkingLevel` → 传给后续 `resolveThinkingLevel`
  - previousSubIntents 摘要 `s.domain` → `s.expertId`（L19）
- [ ] 修改 `src/agents/prompts/intention_async.ts`：
  - LLM JSON 模板同上 + **新增 `thinkingLevel`**（L62-68）
  - parse 映射补填 domain（L102）+ 提取 `parsed.thinkingLevel`
  - buildSubIntentsFromRouter `domain: id` → `expertId: id, domain: ANALYSIS_EXPERTS[id]?.domain ?? "跨域"`（L126-127）
  - previousSubIntents 摘要（L24）
- [ ] 修改 `src/agents/nodes/intention.ts`：audit log（L262）+ expertPlan 构建（L286-288）+ previousSubIntents（L330）
- [ ] 修改 `src/agents/nodes/intention-async.ts`：expertPlan 构建（L86-88, L164-165）
- [ ] 修改 `src/caijuehub/strategies/sub-intent.ts`：expertKeys 匹配（L84-85）+ outputSegments（L98）+ buildReasoningContext（L183）+ buildOutputSegmentsPrompt（L204）
- [ ] 修改 `src/app/api/agent/chat/stream/route.ts`：turnRecord（L542）→ `expertId: si.expertId, domain: si.domain`
- [x] 修改 `src/agents/prompts/schemas/intention.ts`：新建 LLM JSON schema 集中管理文件（含 validateIntentionFields + buildRetryHint）
- [x] 排除确认：`policy-update-loop.ts`（自有 domain 字段）, `report-generator.ts`（表头字段名）

**为什么 LLM 模板和类型定义必须在同一轮**：LLM JSON 模板输出字段名从 `"domain"` 改为 `"expertId"`，parse 逻辑同步改。分开两轮会导致中间态：类型已改但 LLM 仍输出旧字段名，parse 无法正确构造 SubIntent。

#### thinking-level.ts（原计划第2轮，按原子闭包并入第1轮）

- [x] 新增 `getDomains` 纯函数 — 过滤 isSummary，返回去重 ExpertDomain
- [x] 扩展 `resolveThinkingLevel` 签名（subIntents + llmSuggestedLevel）
- [x] 实现 A 规则 + C 升权
- [x] `src/lib/log/phase.ts`：ACAPhase 新增 `THINKING_LEVEL_RESOLVED` + `INTENTION_RETRY`

**第1轮影响文件清单**：

| 文件 | 改动点数 |
|------|:--:|
| `src/agents/types/sub-intent.ts` | 1 |
| `src/agents/prompts/intent-constants.ts` | 1 |
| `src/agents/prompts/intention.ts` | 4 |
| `src/agents/prompts/intention_async.ts` | 4 |
| `src/agents/prompts/schemas/intention.ts` | 新建 |
| `src/agents/nodes/intention.ts` | 5 |
| `src/agents/nodes/intention-async.ts` | 5 |
| `src/caijuehub/strategies/sub-intent.ts` | 4 |
| `src/app/api/agent/chat/stream/route.ts` | 2 |
| `src/api/agent/contracts/dashboard-contract.ts` | 2 |
| `src/caijuehub/strategies/thinking-level.ts` | 1 |
| `src/lib/log/phase.ts` | 1 |
| **合计** | **30+** |

### 第2轮：thinking-level.ts

- [x] 新增 `getDomains` 纯函数
- [x] 扩展 `resolveThinkingLevel` 签名（subIntents + llmSuggestedLevel）
- [x] 实现 A 规则 + C 升权
- [x] `src/lib/log/phase.ts`：ACAPhase 新增审计字面量

### 第3轮：intention.ts 调用方

**本轮包含 state.ts 类型变更 + route.ts API 契约变更 + intention.ts 消费者适配**，三者连锁必须同轮：

```
state.ts: explicitExpertId: string|null → explicitExpertIds: string[]
    │
    ├── route.ts L119: body.expertId → body.expertIds: string[]
    │   route.ts L270: explicitExpertId: expertId → explicitExpertIds: expertIds ?? []
    │
    ├── intention.ts L40: 解构改为 explicitExpertIds
    │   ├── L82-93: 工具注入（if explicitExpertId → for of explicitExpertIds）
    │   ├── L97-143: tool_calls 注入（if explicitExpertId → 取第一个，或全跳过）
    │   ├── L147: 从 explicitExpertIds 构建 subIntents → 传 resolveThinkingLevel
    │   └── L184: explicitExpertId → explicitExpertIds?.[0]（prompt input 仍单值）
    │
    ├── intention-async.ts L35: 同上解构
    │   ├── L75-77: 预激活（if explicitExpertId → for of explicitExpertIds）
    │   └── L111: explicitExpertId → explicitExpertIds?.[0]
    │
    └── reasoning.ts:
        ├── L78: 证据源（explicitExpertId → explicitExpertIds?.[0]）
        └── L131/500: 汇总专家（explicitExpertId! → explicitExpertIds![0]）
```

**设计决策**：prompt input（L184/L111）和 reasoning（L78/131/500）当前只需要单个 expertId，取 `explicitExpertIds[0]`。未来可扩展为多值。

#### 结构性修复

`thinkingLevel` 从 try 块内 `const` 提升为外部 `let`，try/catch 赋值，删除外部覆写行。

- [x] 修改 `src/agents/state.ts`：`explicitExpertId: Annotation<string | null>()` → `explicitExpertIds: Annotation<string[]>()`
- [x] 修改 `src/agents/agent-runner.ts`：StreamAgentInput 接口适配
- [x] 修改 `src/app/api/agent/chat/stream/route.ts`：
  - L119: `expertId` → `expertIds: string[]` + 新增 `subIntents` + `thinkingLevel`
  - L270: `explicitExpertIds: expertIds ?? []` + `prebuiltSubIntents` + `prebuiltThinkingLevel`
- [x] 修改 `src/app/api/types/farm-agent/schemas.ts`：BaseChatSchema 新增 expertIds/subIntents/thinkingLevel
- [x] intention.ts：
  - L40 解构改为 `explicitExpertIds`
  - L82-93 工具注入：`for (const eid of explicitExpertIds)`
  - L97-143 tool_calls 注入：取 `explicitExpertIds[0]`
  - L147 explicitIntent：优先 `state.prebuiltThinkingLevel` → 跳过 resolveThinkingLevel
  - L184 prompt input：`explicitExpertIds?.[0]`
  - L213 新增外部声明 `let thinkingLevel: ThinkingLevel = "deep"`
  - L223 try 块：赋值 + 传 `result.subIntents` + `result.thinkingLevel`
  - L267 catch 块：赋值 `thinkingLevel = resolveThinkingLevel(parsed.intent)`
  - **删除 L301 覆写行**

### 第4轮：intention-async.ts 调用方

- [x] intention-async.ts：
  - L35 解构改为 `explicitExpertIds`
  - L75-77 预激活：`for (const eid of explicitExpertIds)`
  - L82 Embedding 命中：传 `subIntents`
  - L111 prompt input：`explicitExpertIds?.[0]`
  - L133 新增外部声明 `let thinkingLevel: ThinkingLevel = "deep"`
  - L137 try 块：赋值 + 传 `result.subIntents` + `result.thinkingLevel`
  - **删除 L191 覆写行**
- [x] reasoning.ts L78/131/500：`state.explicitExpertIds?.[0]`（含 isSummary 防御 guard）
- [x] conditional.ts L75/79：`state.explicitExpertIds?.[0]`
- [x] `src/app/api/agent/[hash]/route.ts`, `src/app/api/agent/stream/route.ts`：编译兼容
- [x] API 文档更新：
  - `神经元GUI-SSE流式聊天协议文档.md`：expertId → expertIds + 表格新增 subIntents/thinkingLevel
  - `神经元GUI-API对接文档.md`：expertId → expertIds

### 第5轮：全量验证

- [x] `npx tsc --noEmit` 零错误
- [x] `npx eslint src/` 零 error
- [x] `npx vitest run tests/thinking-level.test.ts` → 12/12 passed
  - getDomains 4 场景：同域去重 / 跨域 / 排除 isSummary / 无效 expertId 防御
  - resolveThinkingLevel 8 场景：chat→fast / 单 expert→deep / 同域→deep / 跨域→professional / 含汇总→deep / 不传→deep / C升权
- [ ] 端到端运行时验证（需启动服务 + GUI 点击技能卡片确认 professional 图路由可达）

---

## 五、验收标准

- [ ] `resolveThinkingLevel` 同域 2 专家（crop_compare + variety_recommend）→ `"deep"`
- [ ] `resolveThinkingLevel` 跨域 2 专家（pest_risk + variety_recommend）→ `"professional"`
- [ ] `resolveThinkingLevel` 跨域 3 专家（pest_risk + variety_recommend + roi_analysis）→ `"professional"`
- [ ] `resolveThinkingLevel` 含汇总专家（pest + weather + daily_report）→ 排除 daily_report 后 `Set{"管"}` → `"deep"`
- [ ] `resolveThinkingLevel` 单 expert → `"deep"`
- [ ] `resolveThinkingLevel` chat → `"fast"`
- [ ] `explicitExpertIds: string[]` 单值 → 构建 subIntents 后 A 判同域 → `"deep"`
- [ ] 不传 `subIntents` → 行为与当前一致（向后兼容）
- [ ] `resolveThinkingLevel` 接受 `llmSuggestedLevel`，A 不触发但 C 建议 `"professional"` 时采纳
- [ ] `intention.ts`: thinkingLevel 外部 let，L271 删除
- [ ] `intention-async.ts`: thinkingLevel 外部 let，L160 删除
- [ ] `intention-async.ts` L82 传 subIntents
- [ ] intention prompt LLM JSON 模板含 `thinkingLevel` 字段
- [ ] `getDomains` 纯函数单测通过
- [ ] `npx tsc --noEmit` 零错误
- [ ] `npx eslint src/` 零 error
- [ ] 现有 deep 图不受影响

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| 触发 runtime-review | `.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-runtime.md` |
| 本 Plan Review | `.qoder/reviews/farm-agent-thinking-level-runtime-fix-review-v1.md` |
| ACA v3 Plan | `.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md` |
| Vocabulary v2 Plan | `.qoder/plans/2026-07/01/farm-agent-domain-vocabulary-plan-v2.md` |
| Handoff | `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-handoff-v1.md` |
