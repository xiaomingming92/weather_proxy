# farm-agent-add-template-standardization-add-route-v1

> **定位**：Plan → ADD 十阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节。
> **模式**：重型（Heavyweight）— 文档工程化变更，无 src/ 代码改动。
> **绑定**：Plan: `.qoder/plans/2026-07/04/farm-agent-add-template-standardization-plan-v1.md` · Handoff: `.qoder/plans/2026-07/04/farm-agent-add-template-standardization-handoff-v1.md`

---

## Step 0：文档先行

**目的**：确认 Plan 就绪，生成执行路线图。

**动作**：
1. Plan 已生成（`farm-agent-add-template-standardization-plan-v1.md`）
2. 术语权威源 TERMINOLOGY.md 待创建（Task 1）
3. 本次为纯文档工程化变更，无需更新 `docs/*/knowledge/` 项目文档

**产出**：
- [x] Plan 就绪
- [ ] TERMINOLOGY.md 已创建
- [x] 无需更新项目知识库文档（变更范围仅 `.qoder/templates/`）

### §0.8 DPS 闸门

调用 `check_dps({ planKeyword: "add-template-standardization" })`。

---

## Step 1-2：跳过

本次变更不涉及 src/ 代码，无 AgentAuditPhase 扩展、无 agentAudit 通道变更。

---

## Step 3：Task 映射表

| Plan Task | 改动文件 | 操作 | 审计 |
|-----------|---------|------|------|
| Task 1: 术语表定稿 | `.qoder/templates/TERMINOLOGY.md` | 新建 | record_dev_operation（DOC） |
| Task 2: 16 schema.json | `.qoder/templates/*.schema.json` ×16 | 新建 | record_dev_operation（SCHEMA） |
| Task 3: 16 模板修正 | `.qoder/templates/*.md` ×16 | 修改 | record_dev_operation（DOC） |
| Task 4: doc-format-guard.sh 重构 | `.qoder/hooks/doc-format-guard.sh` | 修改 | record_dev_operation（COMPONENT） |
| Task 5: 消费方同步 | `AGENTS.md`, `vocabulary.sh` | 修改 | record_dev_operation（DOC） |
| Task 6: 回写验证 | 现有 Plan 抽样 | 检查 | record_dev_operation（DOC） |

## 依赖拓扑

```
Task 1 ──┐
Task 2 ──┤ 可并行
Task 3 ──┘
          │
          ▼
Task 4 ── doc-format-guard.sh 重构
          │
          ▼
Task 5 ── 消费方同步
          │
          ▼
Task 6 ── 全量回写验证
```

## 原子闭包判定

本 Plan 为单轮：6 个 Task 共同构成"模板规范化"这一个完整业务闭包，单独交付任何 Task 均无独立价值。

---

## Step 4-7：跳过（无代码实现）

---

## Step 8：验收

- [ ] TERMINOLOGY.md 存在且为权威源
- [ ] 16 个 template 无禁止词
- [ ] doc-format-guard.sh 重构完成，覆盖全部 16 模板
- [ ] AGENTS.md 术语与模板一致
- [ ] tsc --noEmit（无代码改动，预期 0 error）
