# sse-interrupt-threadId-boundary-fix-plan-v1

> 精简版 Plan：单文件边界修正，消除 ZOD_VALIDATE_FAIL 误报。

**创建时间**: 2026-07-04T01:43:00+08:00
**主导 AI**: Qoder
**Review**: 不适用（Plan 逻辑简单，单行修复，用户授权跳过）

---

## 一、Plan 概述

- **现状**: `emitInterrupt()` 先拿 graph 内部的 `InterruptPayload`（无 `threadId`）校验 `InterruptSSEPayloadSchema`（`threadId` 必填），校验失败后 fallback 注入 `meta.threadId`。日志中出现 `ZOD_VALIDATE_FAIL` 误报。
- **目标**: `meta.threadId` 注入时机从校验后 fallback 改为校验前 `payloadWithMeta`，Schema 保持严格校验。
- **核心原则**: graph 内部不感知网络传输字段（threadId/traceId），边界层 `emitInterrupt()` 负责桥接。

---

## 二、变更范围

### 2.1 涉及文件

| 文件 | 改动类型 | 说明 |
|------|---------|------|
| `src/caijuehub/strategies/sse-terminal-event.ts` | 修改 | `meta.threadId` 注入从 safeParse 失败后 fallback 改为 safeParse 前 |

### 2.2 关键设计决策

1. Schema 保持 `threadId: z.string()` 必填不变——客户端调 `/resume` 依赖此字段
2. `meta.threadId` 来源：4 个 route handler 从 HTTP 请求提取，经 `handleInterrupt()` 传入
3. 注入在边界层而非 graph 层：graph 的 `interrupt()` 不感知 SSE 协议字段

---

## 三、Tasks

### Phase 1: 修复

- [x] Task 1: `emitInterrupt()` 注入时机前移
  - [x] `rawPayload` → `payloadWithMeta = { ...rawPayload, threadId: rawPayload.threadId \|\| meta.threadId, traceId: ... }`
  - [x] `safeParse(payloadWithMeta)` 替代 `safeParse(rawPayload)`
  - [x] `tsc --noEmit` 零错误

### Phase 2: 验收

- [ ] Task 2: 触发 interrupt 场景，日志中 ZOD_VALIDATE_FAIL 消失

---

## 四、Handoff

### 4.1 交接前状态

```
emitInterrupt():
  rawPayload → safeParse → ❌ 失败（无 threadId）
  → fallback 注入 meta.threadId → SSE 事件
  → 日志误报 ZOD_VALIDATE_FAIL
```

### 4.2 交接后状态

```
emitInterrupt():
  rawPayload → 注入 meta.threadId → payloadWithMeta
  → safeParse → ✅ 通过 → SSE 事件
  → 无 ZOD_VALIDATE_FAIL 误报
```

### 4.3 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/caijuehub/strategies/sse-terminal-event.ts` | 修改 | L45-52：注入 `payloadWithMeta` 前移至 `safeParse` 之前 |

### 4.4 回滚方案

```bash
git checkout HEAD~1 -- src/caijuehub/strategies/sse-terminal-event.ts
```

### 4.5 执行前置检查

- [x] `npx tsc --noEmit` 零错误

### 4.6 执行步骤摘要

```text
Step 1 ── 定位 emitInterrupt() L45-52
            │
            ▼
Step 2 ── 注入 meta.threadId → payloadWithMeta（safeParse 之前）
            │
            ▼
Step 3 ── tsc --noEmit 验证
            │
            ▼
Step 4 ── 实际对话触发 interrupt，确认 ZOD_VALIDATE_FAIL 消失
```

### 4.7 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| `meta.threadId` 为空时 `payloadWithMeta.threadId` 为 undefined | safeParse 仍失败，但比之前"校验失败后打补丁"更早暴露问题 | 4 个 route handler 都显式传 threadId，运行时必存在 |

### 4.8 恢复上下文审计查询（新 AI Session 首次启动必读）

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用，AI 助手在自己的对话中**直接复制粘贴这些参数调用工具即可**，不需要写 SQL。共 2 条审计记录可恢复完整开发上下文。

#### 总体一键恢复

```text
query_audit_logs({ keyword: "sse-terminal-event" })
```
→ 预期返回 2 条记录

#### 逐任务/逐文件审计查询

```text
query_audit_logs({ targetId: "src/caijuehub/strategies/sse-terminal-event.ts" })
→ 预期返回 FIX: emitInterrupt() 边界注入修正（zod-dto-convergence）

query_audit_logs({ keyword: "ZOD_VALIDATE_FAIL" })
→ 预期返回 MODIFY: handleInterrupt Zod safeParse + threadId 必填（api-zod-hardening）
```

#### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE "targetId" = 'src/caijuehub/strategies/sse-terminal-event.ts'
ORDER BY "createdAt" DESC;
```

#### 恢复判定标准

- action 命中数 ≥ 2
- grep 验证命令：

```bash
grep -R "payloadWithMeta" src/caijuehub/strategies/sse-terminal-event.ts
grep -R "ZOD_VALIDATE_FAIL" src/
```

### 4.9 后置确认

- [x] `npx tsc --noEmit` 通过
- [x] MCP devlog 已记录：`cmr5p7687000plzmcmnde37r6`
- [ ] 实际对话验证 ZOD_VALIDATE_FAIL 不再出现

### 4.10 脱敏要求

Handoff 文档中 **禁止出现** 以下硬编码值：
- 数据库密码（`POSTGRES_PASSWORD`）
- Chroma auth token（`CHROMA_AUTH_TOKEN`）
- JWT 密钥（`JWT_SECRET`）
- API Key（`OPENAI_API_KEY_*`、`LLM_API_KEY` 等）

所有凭据值应通过 `${ENV_VAR}` 引用，并标注值见 `.env.development`。

---

## 五、验收标准

- [x] `tsc --noEmit` 零错误
- [ ] 实际对话触发 interrupt，日志中不再出现 `ZOD_VALIDATE_FAIL`

---

## 六、关联

| 类型 | 路径 | 关系 |
|------|------|------|
| 上游 Plan | `farm-agent-zod-dto-convergence-plan-v1.md` | 该 Plan 的 `InterruptSSEPayloadSchema.threadId` 强化为必填，暴露了本缺陷 |
| 原创建 Plan | `farm-agent-api-zod-hardening-plan-v1.md`（06-30） | `sse-terminal-event.ts` 原始实现，当时 threadId 未必填 |
# sse-interrupt-threadId-boundary-fix — Plan v1

> **类型**：runtime-fix（单文件边界修正）
> **创建**：2026-07-04
> **关联 Plan**：`farm-agent-zod-dto-convergence-plan-v1.md`（暴露了存量缺陷）

---

## 问题

运行时日志出现 `ZOD_VALIDATE_FAIL`：

```
[AGENT-AUDIT] [NODE_ERROR] ✘ interactionPointDetection 失败
[AGENT-AUDIT] [ZOD_VALIDATE_FAIL] interrupt payload 校验失败:
  [{"expected":"string","code":"invalid_type","path":["threadId"],"message":"Invalid input"}]
```

## 根因

`sse-terminal-event.ts` 的 `emitInterrupt()` 中，`InterruptSSEPayloadSchema` 校验的是 graph 内部的 `InterruptPayload`（不含 `threadId`），而不是注入 `meta.threadId` 之后的完整 SSE 载荷。

```text
旧流程（错误）:
  rawPayload（无 threadId）
    → safeParse → 校验失败 → fallback 注入 meta.threadId → 发送 SSE

新流程（正确）:
  rawPayload（无 threadId）
    → 注入 meta.threadId → payloadWithMeta
      → safeParse → 校验通过 → 发送 SSE
```

**`threadId` 来源**：4 个 route handler 从 HTTP 请求中提取 `threadId`，作为 `meta` 传入 `handleInterrupt()`。graph 内部 `interrupt()` 不感知网络层字段。

## 关联 Plan

| Plan | 关系 |
|------|------|
| `farm-agent-zod-dto-convergence-plan-v1.md`（2026-07-02） | 本 Plan 的前置依赖。该 Plan 中 `InterruptSSEPayloadSchema.threadId: z.string()`（必填）暴露了 `emitInterrupt` 的存量边界注入缺陷 |
| `farm-agent-api-zod-hardening-plan-v1.md`（2026-06-30） | `sse-terminal-event.ts` 的原创建 Plan，当时 `InterruptSSEPayloadSchema` 的 `threadId` 尚未强化为必填 |

## 修复

单文件修改：`src/caijuehub/strategies/sse-terminal-event.ts`

```diff
- const validated = InterruptSSEPayloadSchema.safeParse(rawPayload)
+ const payloadWithMeta = {
+   ...rawPayload,
+   threadId: rawPayload.threadId || meta.threadId,
+   traceId: rawPayload.traceId || meta.traceId || undefined,
+ }
+ const validated = InterruptSSEPayloadSchema.safeParse(payloadWithMeta)
```

Schema 保持 `threadId: z.string()` 必填不变（客户端调 `/resume` 需要）。

## 验收

- [x] `tsc --noEmit` 零错误
- [ ] 实际对话触发 interrupt，日志中不再出现 `ZOD_VALIDATE_FAIL`
