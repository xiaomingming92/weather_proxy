# farm-agent-thinking-level-runtime-fix — 5 轮原子事务交接手册

> **用途**：每个新对话开始时，把对应轮次章节粘贴给 LLM。
>
> **绑定**：Plan: `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md` · Add-route: `farm-agent-thinking-level-runtime-fix-add-route-v1.md` · Specs: `.qoder/specs/farm-agent-thinking-level-runtime-fix/`

---

## 全局元信息

- **父 Plan**: [farm-agent-thinking-level-runtime-fix-plan-v1.md](./farm-agent-thinking-level-runtime-fix-plan-v1.md)
- **原子事务拓扑**: [farm-agent-thinking-level-runtime-fix-add-route-v1.md](./farm-agent-thinking-level-runtime-fix-add-route-v1.md)
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 23 个
- **轮次数**: 5 轮

```text
第1轮 ── SubIntent 双字段 + C 增强（类型+模板+parse）
            │
            ▼
第2轮 ── thinking-level.ts（策略函数 A+C 裁决）
            │
            ▼
第3轮 ── intention.ts 调用方（state+route+scope fix）
            │
            ▼
第4轮 ── intention-async.ts 调用方（scope fix+reasoning+conditional）
            │
            ▼
第5轮 ── 全量验证（tsc+eslint+vitest+API文档）
```

### 交接手册与 spec 的优先级

- 本 handoff 是新对话的入口索引。具体实现细节以 spec/tasks/checklist 为准。
- 如果 handoff 摘要与 spec/tasks/checklist 存在颗粒度差异，以 spec/tasks/checklist 为准。
- 每轮完成后的 ADD-7 不只写入 `record_dev_operation`，还必须用 `query_audit_logs` 回查确认落库。

---

## <第1轮> SubIntent 双字段 + C 增强

### 你当前的位置

你是第 1 轮。上游无依赖。

### 上游已完成

（无——本轮为起始轮）

### 你的 spec 文件

- `.qoder/specs/farm-agent-thinking-level-runtime-fix/spec.md`
- `.qoder/specs/farm-agent-thinking-level-runtime-fix/tasks.md`
- `.qoder/specs/farm-agent-thinking-level-runtime-fix/checklist.md`

### 你要改的文件（10 个：1 新建 + 9 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/types/sub-intent.ts` | 修改 | domain:string → expertId+domain:ExpertDomain 双字段 |
| `src/agents/prompts/intent-constants.ts` | 修改 | 文案 domain→expertId |
| `src/agents/prompts/intention.ts` | 修改 | LLM JSON 模板 expertId+thinkingLevel；parse 推导 domain |
| `src/agents/prompts/intention_async.ts` | 修改 | 同上；buildSubIntentsFromRouter 适配双字段 |
| `src/agents/prompts/schemas/intention.ts` | 新建 | JSON schema 集中管理 + validateIntentionFields + buildRetryHint |
| `src/agents/nodes/intention.ts` | 修改 | si.domain→si.expertId rename + retry 回路 |
| `src/agents/nodes/intention-async.ts` | 修改 | si.domain→si.expertId rename + retry 回路 |
| `src/caijuehub/strategies/sub-intent.ts` | 修改 | si.domain→si.expertId rename |
| `src/app/api/agent/chat/stream/route.ts` | 修改 | capturedSubIntents type + turnRecord 适配 |
| `src/api/agent/contracts/dashboard-contract.ts` | 修改 | SkillCard 扩展 4 字段 + 8 旧卡适配 + crop_decision |

### 高风险误区

- 禁止在本轮修改 `state.ts` 或 `route.ts` API 契约（属于第3轮）
- 禁止修改 `reasoning.ts` 或 `conditional.ts`（属于第4轮）
- LLM JSON 字段名必须从 `"domain"` 改为 `"expertId"`，parse 同步改——分开两轮会导致中间态

### 恢复上下文审计查询

```text
query_audit_logs({ planKeyword: "farm-agent-thinking-level-runtime-fix" })
→ 返回全部 25 条审计记录
```

### 验证标准

- [x] SubIntent 双字段类型正确
- [x] LLM prompt 含 thinkingLevel
- [x] SkillCard 预计算决策表完备
- [x] retry 回路接入

### 完成后记录 ADD-7 审计

每文件一条 `record_dev_operation`，planKeyword: `farm-agent-thinking-level-runtime-fix`。

---

## <第2轮> thinking-level.ts 策略函数

### 你当前的位置

你是第 2 轮。上游第1轮已完成类型体系 + prompt + rename + retry 回路。

### 上游已完成

- SubIntent 双字段类型就绪
- LLM prompt 输出 expertId + thinkingLevel
- 全部 si.domain→si.expertId rename 完成
- SkillCard 预计算决策表就绪

### 你要改的文件（2 个：全部修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/caijuehub/strategies/thinking-level.ts` | 修改 | 新增 getDomains + resolveThinkingLevel 签名扩展 + A+C 裁决 |
| `src/lib/log/phase.ts` | 修改 | ACAPhase 新增 THINKING_LEVEL_RESOLVED + INTENTION_RETRY |

### 核心设计

```text
resolveThinkingLevel(intent, subIntents?, llmSuggestedLevel?)
  ├── chat → "fast"
  ├── getDomains(subIntents).size ≥ 2 → "professional"  (A 规则)
  ├── llmSuggestedLevel === "professional" → "professional"  (C 升权)
  └── 默认 → "deep"
```

### 高风险误区

- 新签名去掉了 `explicitExpertId` 参数，改为 `subIntents?: SubIntent[]`——第3轮调用方必须适配
- C 升权只能把 deep 升为 professional，不能降级 A 的 professional

### 验证标准

- [x] getDomains 纯函数实现
- [x] resolveThinkingLevel A+C 逻辑
- [x] THINKING_LEVEL_RESOLVED 字面量

---

## <第3轮> intention.ts 调用方结构性修复

### 你当前的位置

你是第 3 轮。上游第2轮已完成 resolveThinkingLevel 新签名。

### 上游已完成

- getDomains + resolveThinkingLevel A+C 可用（新签名）
- THINKING_LEVEL_RESOLVED 审计字面量就绪

### 你要改的文件（5 个：全部修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/state.ts` | 修改 | explicitExpertIds + 3 prebuilt 字段 |
| `src/agents/agent-runner.ts` | 修改 | StreamAgentInput 接口适配 |
| `src/app/api/agent/chat/stream/route.ts` | 修改 | API 契约 expertIds[] + prebuilt 传递 |
| `src/app/api/types/farm-agent/schemas.ts` | 修改 | Zod schema 新增 expertIds/subIntents/thinkingLevel |
| `src/agents/nodes/intention.ts` | 修改 | explicitExpertIds + prebuilt优先 + thinkingLevel let + 删除 L301 |

### 核心设计

```text
state.explicitExpertIds: string[]  ← 始终数组
state.prebuiltThinkingLevel        ← SkillCard 点击直接透传，跳过 resolveThinkingLevel
state.prebuiltSubIntents           ← 同上
intention.ts thinkingLevel: let    ← try/catch 赋值，不再外部覆写
```

### 高风险误区

- `thinkingLevel` 必须声明为外部 `let`，不能在 try 内 `const` + 外部覆写
- L301 覆写行必须删除

### 验证标准

- [x] state.ts explicitExpertIds + 3 prebuilt
- [x] route.ts API 契约
- [x] intention.ts scope fix + prebuilt 优先

---

## <第4轮> intention-async.ts 调用方结构性修复

### 你当前的位置

你是第 4 轮。上游第3轮已完成 intention.ts 调用方修复 + state/route 契约。

### 上游已完成

- explicitExpertIds: string[] 可用
- prebuilt 字段可用
- intention.ts thinkingLevel scope fix 完成

### 你要改的文件（4 个：全部修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/intention-async.ts` | 修改 | explicitExpertIds + subIntents passthrough + thinkingLevel let + 删除 L191 |
| `src/agents/nodes/reasoning.ts` | 修改 | explicitExpertIds?.[0] ×3 + isSummary 防御 |
| `src/agents/edges/conditional.ts` | 修改 | explicitExpertIds?.[0] ×2 |
| `src/app/api/agent/[hash]/route.ts` + `stream/route.ts` | 修改 | 编译兼容 |

### 高风险误区

- L191 覆写行必须删除
- reasoning.ts isSummary 路径需要防御 null

### 验证标准

- [x] intention-async.ts scope fix
- [x] reasoning.ts + conditional.ts 适配

---

## <第5轮> 全量验证

### 你当前的位置

你是第 5 轮。上游第1-4轮已完成全部代码实现。

### 上游已完成

- 全部代码实现完成
- 所有 scope bug 修复
- explicitExpertIds 迁移完成

### 你要改的文件（3 个）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `docs/.../神经元GUI-SSE流式聊天协议文档.md` | 修改 | expertId→expertIds + 新增字段 |
| `docs/.../神经元GUI-API对接文档.md` | 修改 | expertId→expertIds |
| `tests/thinking-level.test.ts` | 新建 | getDomains(4) + resolveThinkingLevel(8) |

### 验证标准

- [x] `npx tsc --noEmit` 零错误
- [x] `npx eslint src/` 零 error
- [x] `npx vitest run tests/thinking-level.test.ts` → 12/12
- [ ] 端到端运行时验证（需启动服务）

---

## 每轮收敛判定补充规则

- checklist 全部项已勾选且有可验证证据
- tasks 全部任务已完成
- 禁止 AI 自行声明收敛——收敛声明只能由开发者或 Review AI 做出
