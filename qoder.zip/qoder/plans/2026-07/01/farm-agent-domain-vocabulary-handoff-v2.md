# farm-agent — 8 轮原子事务交接手册

> **适用场景**：多轮原子事务变更，每轮独立收敛。8 个 Task 按 ADD 范式逐轮验收。
>
> **用途**：每轮开始前，AI 读对应轮次章节——明确上下游事务、文件边界、验证标准、审计闭环。

---

## 全局元信息

- **父 Plan**: [farm-agent-domain-vocabulary-plan-v2.md](./farm-agent-domain-vocabulary-plan-v2.md)
- **原子事务拓扑**: [farm-agent-domain-vocabulary-add-route-v2.md](./farm-agent-domain-vocabulary-add-route-v2.md)
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 约 18 个独立文件
- **轮次数**: 8 轮局部闭包
- **拆分原则**: 以业务原子闭包为主（基础设施→数据→路由→接入），每轮独立可编译、可验证

```text
第1轮 ── Task 0: DynamicConfig + MetricsRegistry 基础设施
            │
            ▼
第2轮 ── Task 1: v2 触发词替换
            │
            ▼
第3轮 ── Task 2: centroid + ChromaDB + tier-decider
            │
            ▼
第4轮 ── Task 3: Router 入口 index.ts
            │
            ▼
第5轮 ── Task 4: LLM fallback
            │
            ▼
第6轮 ── Task 5: Router 接入 Metrics + 单测
            │
            ▼
第7轮 ── Task 6: intention_async 体系 + wiring
            │
            ▼
第8轮 ── Task 7: 编译验证 + E2E
```

---

## 原子事务边界说明

- 第1轮（Task 0）是基础设施层，不依赖任何上游，但被所有后续轮次依赖。必须第1轮完成。
- 第2轮（Task 1）是纯数据替换，与第1轮无逻辑依赖，但 tsc 验证依赖第1轮的导出完整。实际可并行但为注意力聚焦而串行。
- 第3-6轮（Task 2-5）构成 Router 核心链路，每轮是上一轮的消费者：centroid→entry→fallback→metrics。
- 第7轮（Task 6）是接入层，依赖 Router 完成 + 原有 Agent 管线稳定，改动面广（7 个文件），是风险最高的一轮。
- 第8轮（Task 7）不是前 7 轮的补丁，而是前 7 轮收敛后的全链路验证；禁止在第 7 轮之后"再补一个 Task 7.5 修复编译问题"。

### 交接手册与 spec 的优先级

- 本 handoff 是每轮的入口索引，负责说明轮次位置、上下游依赖、文件边界、高风险误区、审计闭环。
- 具体实现细节以 `.qoder/specs/farm-agent-domain-vocabulary-v2/spec.md`、`tasks.md`、`checklist.md` 为准。
- 如果 handoff 摘要与 spec/tasks/checklist 存在颗粒度差异，以 spec/tasks/checklist 为准。
- 每轮完成后的 ADD-7 不只写入 `record_dev_operation`，还必须用 `query_audit_logs` 按 planKeyword 回查确认落库。

---

## 第1轮 Task 0: DynamicConfig + MetricsRegistry 基础设施

### 你当前的位置

你是第 1 轮。无上游依赖。本轮构建系统级可调参数（DynamicConfig）和模块化指标收集（MetricsRegistry）两大基础设施，供后续 Router 路由层消费。

### 上游已完成

无（首轮）。

### 恢复上下文审计查询（新 AI Session 首次启动必读）

#### 第一步：搜索代码文件的改动记录

```text
query_audit_logs({ keyword: "farm-agent-domain-vocabulary-plan-v2" })
```
→ 返回 9 条：8 CREATE + 1 MODIFY。覆盖 dynamic-config、metrics-registry、6 个 API route、1 个 Zod schema。

#### 第二步：定位本轮改动文件

```text
query_audit_logs({ targetId: "src/services/dynamic-config.ts" })
```
→ 返回 1 条 CREATE。afterState 含 DEFAULT_CONFIG 三个初始值。

```text
query_audit_logs({ targetId: "src/services/metrics-registry.ts" })
```
→ 返回 1 条 CREATE。afterState 含双消费路径。

#### 恢复顺序建议

```
1. session-init SKILL（强制前置）
2. query_audit_logs({ keyword: "farm-agent-domain-vocabulary-plan-v2" })  → 看本轮所有记录（9 条）
3. read ".qoder/specs/farm-agent-domain-vocabulary-v2/spec.md"           → §1.1-1.8 类型定义
4. read ".qoder/specs/farm-agent-domain-vocabulary-v2/tasks.md"          → Phase 0
5. read ".qoder/specs/farm-agent-domain-vocabulary-v2/checklist.md"      → Phase 0 检查项
```

### 原子事务目标

覆盖 `farm-agent-domain-vocabulary-plan-v2.md` 的 Task 0。构建 DynamicConfig 单例（get/set/getAll/getHistory/onChange）和 MetricsRegistry 单例（register/snapshot/getCounter），提供 6 个系统 API endpoint。

### spec 文件

- `.qoder/specs/farm-agent-domain-vocabulary-v2/spec.md`
- `.qoder/specs/farm-agent-domain-vocabulary-v2/tasks.md`
- `.qoder/specs/farm-agent-domain-vocabulary-v2/checklist.md`

### 你要改的文件（9 个：8 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/services/dynamic-config.ts` | 新建 | DynamicConfigStore 单例：get/set/getAll/getHistory/onChange CRUD + DEFAULT_CONFIG(0.5/0.15/3) |
| `src/services/metrics-registry.ts` | 新建 | MetricsRegistry 单例：register/snapshot/snapshotAll/getCounter，ring buffer 1K |
| `src/app/api/system/config/[key]/route.ts` | 新建 | GET/PUT /api/system/config/:key，Zod 按 key 专属 schema 校验 |
| `src/app/api/system/config/route.ts` | 新建 | GET /api/system/config（全量） |
| `src/app/api/system/config/history/[key]/route.ts` | 新建 | GET /api/system/config/history/:key（变更链） |
| `src/app/api/system/metrics/[name]/route.ts` | 新建 | GET /api/system/metrics/:name（单模块快照） |
| `src/app/api/system/metrics/route.ts` | 新建 | GET /api/system/metrics（全量） |
| `src/app/api/types/system/schemas.ts` | 新建 | Zod schema：EMBEDDING_CONFIDENCE_THRESHOLD(0-1)/MARGIN(≥0)/TOPK(≥1 int) |
| `src/app/api/types/index.ts` | 修改 | barrel export 追加 ./system/schemas |

### 核心设计

```
DynamicConfig（Application Scope，跨 request）
  读: embedding.ts 取 EMBEDDING_CONFIDENCE_THRESHOLD
  写: PUT /api/system/config/:key（人） / policy-update-loop（AI）
  记: getHistory 变更链 + onChange 订阅

MetricsRegistry（Pull 模型，消费者主动查询）
  人: GET /api/system/metrics/:name → JSON
  AI: policy-update-loop.evaluate() 读 getCounter()
```

### 关键契约

- `src/app/api/system/config/[key]/route.ts`: **禁止**用 `z.unknown()` 或 `z.any()` 做 schema——必须按 key 匹配专属 Zod schema（confidence 0-1、margin ≥0、topK ≥1 int）。
- `src/app/api/types/system/schemas.ts`: 新增配置 key 时必须同步更新 CONFIG_SCHEMAS 映射表。
- `src/services/metrics-registry.ts`: `observe` 必须使用 ring buffer（上限 1K），防止内存泄漏。

### 高风险误区

- **禁止**在 PUT config 路由中使用 `z.any()` / `z.unknown()`——每个 key 必须有类型门禁。
- **禁止**跳过 Zod 校验直接 `dynamicConfig.set(key, body.value)`。
- **禁止**在 DynamicConfig 或 MetricsRegistry 中调用 `agentAudit`（基础设施层无审计需求，已由 add-route §3.1 确认）。
- **禁止提前实现第3轮的 centroid-init 或 embedding**——第1轮只做基础设施。

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| CREATE | SERVICE | `src/services/dynamic-config.ts` | DynamicConfig 单例 | ✅ |
| CREATE | SERVICE | `src/services/metrics-registry.ts` | MetricsRegistry 单例 | ✅ |
| CREATE | API_ROUTE | `src/app/api/system/config/[key]/route.ts` | config key 路由 | ✅ |
| CREATE | API_ROUTE | `src/app/api/system/config/route.ts` | config 全量路由 | ✅ |
| CREATE | API_ROUTE | `src/app/api/system/config/history/[key]/route.ts` | config history 路由 | ✅ |
| CREATE | API_ROUTE | `src/app/api/system/metrics/[name]/route.ts` | metrics name 路由 | ✅ |
| CREATE | API_ROUTE | `src/app/api/system/metrics/route.ts` | metrics 全量路由 | ✅ |
| CREATE | SCHEMA | `src/app/api/types/system/schemas.ts` | Zod schema | ✅ |
| MODIFY | SCHEMA | `src/app/api/types/index.ts` | barrel export | ✅ |

**恢复关键词**：
```text
query_audit_logs({ targetId: "src/services/dynamic-config.ts" })
→ CREATE, SERVICE。afterState: DEFAULT_CONFIG 三个初始值。

query_audit_logs({ targetId: "src/services/metrics-registry.ts" })
→ CREATE, SERVICE。afterState: 双消费路径。

query_audit_logs({ targetId: "src/app/api/system/config/[key]/route.ts" })
→ CREATE, API_ROUTE。afterState: GET/PUT，per-key Zod schema。

query_audit_logs({ targetId: "src/app/api/system/config/route.ts" })
→ CREATE, API_ROUTE。afterState: GET 全量。

query_audit_logs({ targetId: "src/app/api/system/config/history/[key]/route.ts" })
→ CREATE, API_ROUTE。afterState: GET 变更链。

query_audit_logs({ targetId: "src/app/api/system/metrics/[name]/route.ts" })
→ CREATE, API_ROUTE。afterState: GET 单模块。

query_audit_logs({ targetId: "src/app/api/system/metrics/route.ts" })
→ CREATE, API_ROUTE。afterState: GET 全量。

query_audit_logs({ targetId: "src/app/api/types/system/schemas.ts" })
→ CREATE, SCHEMA。afterState: 3 key 专属 Zod。

query_audit_logs({ targetId: "src/app/api/types/index.ts" })
→ MODIFY, SCHEMA。afterState: 追加 system/schemas export。
```

### 验证标准

#### 已完成验证

- `npx tsc --noEmit` 通过：EXIT: 0 ✅
- 8 个新建文件全部存在 ✅
- Zod 按 key 专属 schema：3 key × 类型校验（confidence 0-1/margin ≥0/topK ≥1 int） ✅
- 变更来源枚举 api/ai/init 已定义 ✅
- ring buffer 1K 内存保护 ✅
- ADD 合规检查：4 警告（预期——基础设施层无审计需求） ✅

#### 未执行的端到端验证（保留给运行时复测）

- [ ] `curl -s localhost:3000/api/system/config/EMBEDDING_CONFIDENCE_THRESHOLD` 返回 `{"key":"...","value":0.5}`（原因：需服务启动 + ChromaDB，第8轮统一验证）
- [ ] `PUT /api/system/config/EMBEDDING_CONFIDENCE_THRESHOLD -d '{"value":0.7}'` 成功（原因：同上）

### 完成后记录 ADD-7 审计

9 条 `record_dev_operation` 记录已落库，planKeyword=`farm-agent-domain-vocabulary-plan-v2`。

已逐条回查确认：

| cuid | targetId | action | targetType |
|------|----------|--------|------------|
| cmr395bfz | src/services/dynamic-config.ts | CREATE | SERVICE |
| cmr395bfs | src/services/metrics-registry.ts | CREATE | SERVICE |
| cmr395bfv | src/app/api/system/config/[key]/route.ts | CREATE | API_ROUTE |
| cmr395bfk | src/app/api/system/config/route.ts | CREATE | API_ROUTE |
| cmr395bfx | src/app/api/system/config/history/[key]/route.ts | CREATE | API_ROUTE |
| cmr395bfl | src/app/api/system/metrics/[name]/route.ts | CREATE | API_ROUTE |
| cmr395bfv | src/app/api/system/metrics/route.ts | CREATE | API_ROUTE |
| cmr395bg2 | src/app/api/types/system/schemas.ts | CREATE | SCHEMA |
| cmr395bfv | src/app/api/types/index.ts | MODIFY | SCHEMA |

---

## 第2轮 Task 1: v2 触发词替换

### 你当前的位置

你是第 2 轮。上游第 1 轮已完成 DynamicConfig + MetricsRegistry 基础设施（9 文件，tsc=0）。本轮替换 `domain-triggers.ts` 中 13 个专家的触发词为产品 v2 词库。

### 上游已完成

- `src/services/dynamic-config.ts`: DynamicConfigStore 单例，DEFAULT_CONFIG 含 EMBEDDING_CONFIDENCE_THRESHOLD(0.5)/MARGIN(0.15)/TOPK(3)
- `src/services/metrics-registry.ts`: MetricsRegistry 单例，register/snapshot/getCounter
- 6 个系统 API route（config + metrics）可调用

### 原子事务目标

覆盖 Plan Task 1。将 `domain-triggers.ts` 中 13 个专家的触发词从 v1（9-13 条/专家，书面语）替换为 v2 词库（80-150 条/专家，口语化）。`land_analysis` 保留 v1 触发词。删除 `domain-triggers.md` 冗余副本。

### 你要改的文件（2 个：1 修改 + 1 删除）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/vocabulary/domain-triggers.ts` | 修改 | 替换 13 个专家的 expertTriggers 为 v2 词库，land_analysis 保留 v1 并标注 |
| `src/agents/vocabulary/domain-triggers.md` | 删除 | TypeScript 代码的 .md 副本，无消费者 |

### 高风险误区

- **禁止**修改 `collectionHints`——v2 只改触发词，不改 RAG collection 映射。
- **禁止**添加/删除专家——只替换已有 13 个专家的触发词内容。
- **禁止**修改 `DomainTriggerMap` 接口结构。

### 验证标准

- `npx tsc --noEmit` 通过：EXIT: 0 ✅（2026-07-03）
- `npx eslint src/` 0 errors ✅
- 14 个专家触发词已替换为 v2 口语化词库（1295 条），运行时从 `domain_triggers_words.md` 解析 ✅
- `land_analysis` 已纳入 `domain_triggers_words.md`（`## land_analysis` 段）✅
- `domain-triggers.md` 已删除 ✅
- 触发词数据与代码分离：产品团队直接编辑 `.md`，代码零改动 ✅

### 实际改动（验收复核）

| 文件 | 操作 | 实际内容 |
|------|------|------|
| `src/agents/vocabulary/domain_triggers_words.md` | 重构 | 原名 `domain-triggersv2.md`，格式从 GFM 表格 → `## expertId` 分段 + `、` 分隔。新增 `land_analysis` 段，全 14 专家 |
| `src/agents/vocabulary/domain-triggers.ts` | 修改 | 硬编码 230 行 → 87 行。`parseV2Triggers()` 运行时 `readFileSync` 解析 `.md`，模块加载时缓存 |
| `src/agents/vocabulary/domain-triggers.md` | 删除 | TS 代码的冗余 .md 副本 |

### ADD-7 审计记录

| action | targetType | targetId | 审计 ID | 说明 |
|--------|-----------|----------|------|------|
| MODIFY | COMPONENT | `src/agents/vocabulary/domain-triggers.ts` | `cmr4numu6` | v2 词库替换（1285 条） |
| MODIFY | COMPONENT | `src/agents/vocabulary/domain-triggers.ts` | `cmr4nyd0d` | 数据/代码分离重构（硬编码→运行时解析） |
| DELETE | COMPONENT | `src/agents/vocabulary/domain-triggers.md` | `cmr4numty` | 删除冗余 .md 副本 |

### 后置确认

- [x] `npx tsc --noEmit` 通过 — EXIT: 0
- [x] `npx eslint src/` 零 error — 0 errors, 9 warnings（均为已知日志文件）
- [x] `collectionHints` 未修改 — 14 条 collection 映射不变
- [x] `DomainTriggerMap` 接口未变 — 消费者零影响
- [x] 所有文件改动已记录 ADD-7 审计 — 3 条 `record_dev_operation`

---

## 第3轮 Task 2: centroid + ChromaDB + tier-decider

### 你当前的位置

你是第 3 轮。上游第 2 轮已完成 v2 触发词替换。本轮构建 Router 核心层：centroid 初始化写入 ChromaDB、embedding 查询、纯函数裁决。

### 上游已完成

- `src/agents/vocabulary/domain-triggers.ts`: v2 词库已就绪（1300+ 条），供 centroid-init 消费
- `src/services/dynamic-config.ts`: EMBEDDING_CONFIDENCE_THRESHOLD 等参数可读取

### 原子事务目标

覆盖 Plan Task 2。创建 `src/agents/router/` 目录，包含 types.ts、centroid-init.ts、embedding.ts、tier-decider.ts。tier-decider 为纯函数，不读 DynamicConfig。

### 你要改的文件（4 个：全部新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/router/types.ts` | 新建 | Candidate, RouterResult, TierDecision, TierDecisionInput |
| `src/agents/router/centroid-init.ts` | 新建 | initCentroids(): 遍历触发词→getEmbeddings()→upsert ChromaDB |
| `src/agents/router/embedding.ts` | 新建 | embeddingRoute(query): query embedding→ChromaDB query→返回 Candidate[] |
| `src/agents/router/tier-decider.ts` | 新建 | decideTier(candidates, threshold, margin): 纯函数裁决 direct/multi-candidate/fallback |

### 高风险误区

- **禁止**在 tier-decider.ts 中读 DynamicConfig——阈值由调用方传入，保持纯函数。
- **禁止**在 embedding.ts 中做阈值裁决——裁决逻辑全部在 tier-decider.ts。
- **禁止**在 centroid-init 中硬编码 ChromaDB URL——使用 `@/config/chroma-config`。
- **禁止**引入新 embedding 模型——复用 `getEmbeddings()`（text-embedding-v4，1024 维）。

### 验收标准

- `npx tsc --noEmit` 通过：EXIT: 0 ✅（2026-07-03）
- `npx eslint src/agents/router/` 零 error ✅
- 4 个文件均在 `src/agents/router/` 目录下 ✅
- tier-decider.ts 纯函数，零 `dynamicConfig`/`chroma` import ✅
- embedding.ts 不做阈值裁决，只返回 Candidate[] ✅
- centroid-init.ts 使用 `@/config/chroma-config`，无硬编码 URL ✅

### ADD-7 审计记录

| action | targetType | targetId | 审计 ID | 说明 |
|--------|-----------|----------|------|------|
| CREATE | COMPONENT | `src/agents/router/types.ts` | `cmr4oithf` | Router 共享类型定义 |
| CREATE | COMPONENT | `src/agents/router/tier-decider.ts` | `cmr4oithg` | 纯函数裁决层 |
| CREATE | COMPONENT | `src/agents/router/centroid-init.ts` | `cmr4oith8` | centroid 构建 + ChromaDB 写入 |
| CREATE | COMPONENT | `src/agents/router/embedding.ts` | `cmr4oithj` | Embedding 路由（不做阈值裁决）|

### 后置确认

- [x] `npx tsc --noEmit` 通过 — EXIT: 0
- [x] `npx eslint src/agents/router/` 零 error — EXIT: 0
- [x] tier-decider.ts 纯函数 — `grep dynamicConfig|chroma` = 0 matches
- [x] embedding.ts 动态读阈值 — `dynamicConfig.get("EMBEDDING_TOPK")`
- [x] centroid-init.ts 用 `@/config/chroma-config` — 无硬编码 URL
- [x] 复用 `getEmbeddings()` — 零新 embedding 模型
- [x] 无架构文档需更新（Router 层为纯新增模块，不涉及现有架构变更）
- [x] devlog 已落库 — `cmr4p78p0` ROUND_COMPLETE

---

## 第4轮 Task 3: Router 入口 index.ts

### 你当前的位置

你是第 4 轮。上游第 3 轮已完成 centroid/embedding/tier-decider。本轮实现 Router 编排层。

### 原子事务目标

覆盖 Plan Task 3。创建 `index.ts`：initRouter() 启动初始化 + route(query) 串联 embedding→tier-decider→dispatch。

### 你要改的文件（1 个：新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/router/index.ts` | 新建 | initRouter() + route(query)：embedding 查询→tier-decider 裁决→按 action 分发 |

### 验收标准

- `npx tsc --noEmit` 通过：EXIT: 0 ✅（2026-07-03）
- `npx eslint src/agents/router/` 零 error ✅
- `initRouter()` 幂等——多次调用只执行一次 ✅
- `route(query)` 串联：embeddingRoute → dynamicConfig 读阈值 → decideTier → RouterResult ✅
- Embedding 失败返回 tier=2 空候选（降级 LLM）✅

### ADD-7 审计记录

| action | targetType | targetId | 审计 ID | 说明 |
|--------|-----------|----------|------|------|
| CREATE | COMPONENT | `src/agents/router/index.ts` | `cmr4pcj3m` | Router 编排层：initRouter + route |

### 后置确认

- [x] `npx tsc --noEmit` 通过 — EXIT: 0
- [x] `npx eslint src/agents/router/` 零 error — EXIT: 0
- [x] `route(query)` 串联 embedding→tier-decider→dispatch 正确
- [x] 无架构文档需更新（Router 入口为编排层，不涉及新架构变更）
- [x] devlog 已落库 — `cmr4pczdx` ROUND_COMPLETE

---

## 第5轮 Task 4: LLM fallback

### 你当前的位置

你是第 5 轮。上游第 4 轮已完成 Router 编排。本轮实现 Tier 2 LLM fallback。

### 原子事务目标

覆盖 Plan Task 4。创建 `llm-fallback.ts`：buildLlmFallbackPrompt() 构建含 INTENT_SEMANTICS + CROSS_DOMAIN_RULES + top-3 描述的 prompt。

### 依赖前置

LLM fallback prompt 需要 `INTENT_SEMANTICS` 和 `CROSS_DOMAIN_RULES`。如果第 2 轮未提取这些常量到 `intent-constants.ts`，本轮需一并创建。

### 你要改的文件（2 个：1 新建 + 可能 1 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/prompts/intent-constants.ts` | 新建（如未在第 2 轮创建） | INTENT_SEMANTICS + CROSS_DOMAIN_RULES 共享常量 |
| `src/agents/router/llm-fallback.ts` | 新建 | buildLlmFallbackPrompt() + llmFallbackRoute() |

### 验收标准

- `npx tsc --noEmit` 通过：EXIT: 0 ✅（2026-07-03）
- `npx eslint` 零 error ✅
- `intent-constants.ts` 导出 `INTENT_SEMANTICS` + `CROSS_DOMAIN_RULES` ✅
- `intention.ts` 仅 import 变更，函数逻辑未修改 ✅
- `llm-fallback.ts` prompt 含 INTENT_SEMANTICS + CROSS_DOMAIN_RULES + top-3 候选描述 ✅

### ADD-7 审计记录

| action | targetType | targetId | 审计 ID | 说明 |
|--------|-----------|----------|------|------|
| CREATE | COMPONENT | `src/agents/prompts/intent-constants.ts` | `cmr4pto8` | 共享常量提取 |
| MODIFY | COMPONENT | `src/agents/prompts/intention.ts` | `cmr4pto87` | import 改为从 intent-constants |
| CREATE | COMPONENT | `src/agents/router/llm-fallback.ts` | `cmr4pto82` | LLM fallback 路由 |

### 后置确认

- [x] `npx tsc --noEmit` 通过 — EXIT: 0
- [x] `npx eslint` 零 error — EXIT: 0
- [x] `intention.ts` 仅 import 变更 — `git diff` 确认函数逻辑未改
- [x] 无架构文档需更新（常量提取为纯重构，不涉及新架构变更）
- [x] devlog 已落库 — `cmr4pu65b` ROUND_COMPLETE

---

## 第6轮 Task 5: Router 接入 Metrics + 单测

### 你当前的位置

你是第 6 轮。上游第 5 轮已完成 LLM fallback。本轮在 Router.route() 末尾接入 MetricsRegistry（~5 行）。

### 原子事务目标

覆盖 Plan Task 5。修改 `index.ts`：route() 末尾调用 metricsRegistry 记录 tier1Hits/tier2Fallbacks/lastLatencyMs/confidenceSamples。

### 你要改的文件（1 个：修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/router/index.ts` | 修改 | route() 末尾接入 MetricsRegistry（~5 行） |

### 验收标准

- `npx tsc --noEmit` 通过：EXIT: 0 ✅（2026-07-03）
- `npx eslint` 零 error ✅
- `npx vitest run tests/tier-decider.test.ts` 5/5 ✅
- `route()` 末尾接入 MetricsRegistry：tier1Hits/tier2Fallbacks/lastLatencyMs/confidenceSamples ✅

### ADD-7 审计记录

| action | targetType | targetId | 审计 ID | 说明 |
|--------|-----------|----------|------|------|
| MODIFY | COMPONENT | `src/agents/router/index.ts` | `cmr4q1yp9` | MetricsRegistry ~5行 |
| CREATE | TEST | `tests/tier-decider.test.ts` | `cmr4q1yoz` | 纯函数单测 5/5 |
| MODIFY | RULE | `vitest.config.ts` | `cmr4q1yp6` | include tests/ + setupFiles 修正 |

### 后置确认

- [x] `npx tsc --noEmit` 通过 — EXIT: 0
- [x] `npx eslint` 零 error — EXIT: 0
- [x] `npx vitest` 5/5 全通过
- [x] 无架构文档需更新
- [x] devlog 已落库 — `cmr4q2h7p` ROUND_COMPLETE

---

## 第7轮 Task 6: intention_async 体系 + wiring

### 你当前的位置

你是第 7 轮。上游第 6 轮已完成 Router + Metrics。本轮是接入层：新建异步 prompt 模板 + 异步 LangGraph 节点 + professional 图 wiring 切换。

### 上游已完成

- `src/agents/router/`: Router 完整链路（centroid→embedding→tier-decider→llm-fallback→Metrics）
- `src/agents/prompts/intent-constants.ts`: 共享常量

### 原子事务目标

覆盖 Plan Task 6。不改 `intention.ts` 逻辑，新建 `intention_async.ts`（异步 prompt）+ `intention-async.ts`（异步节点）+ wiring professional 图切换。

### 你要改的文件（7 个：3 新建 + 4 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/prompts/intention_async.ts` | 新建 | 异步 prompt 模板：buildContextBlock() 调 Router.route() |
| `src/agents/nodes/intention-async.ts` | 新建 | intentionAsyncNode：与 intentionNode 结构一致，仅 prompt 换为异步版 |
| `src/agents/prompts/intent-constants.ts` | 新建（如未创建） | INTENT_SEMANTICS + CROSS_DOMAIN_RULES |
| `src/agents/prompts/intention.ts` | 修改 | import 改为从 intent-constants.ts，**不改函数逻辑** |
| `src/agents/prompts/types.ts` | 修改 | PromptTemplate.build 类型：`string` → `string \| Promise<string>` |
| `src/agents/agent-graph.ts` | 修改 | professionalWorkflow 的 intention 节点切换为 intentionAsyncNode |
| `src/agents/nodes/index.ts` | 修改 | 导出 intentionAsyncNode |
| `src/agents/prompts/index.ts` | 修改 | 导出 intentionAsyncPrompt |

### 高风险误区

- **禁止修改** `intention.ts` 的 `intentionNode` 函数逻辑——diff 仅限 import 行。
- **禁止修改** `agent`（deep/simple）图的 wiring——仅改 `professionalWorkflow`。
- **禁止**在 intention-async.ts 中写委托代码（`return intentionNode(state)`）——必须完整实现与 intentionNode 同构的异步逻辑。
- **禁止**跳过 router 初始化——intentionAsyncNode 首次调用前必须 `await initRouter()`。

---

## 第8轮 Task 7: 编译验证 + E2E

### 你当前的位置

你是第 8 轮。上游第 1-7 轮已全部完成。本轮是全链路验证，不是补丁。

### 原子事务目标

覆盖 Plan Task 7。`npx tsc --noEmit` 零错误 + 4 条端到端场景验证。

### 你要改的文件（0 个：纯验证）

无新建/修改文件。验证：
- `npx tsc --noEmit` 零错误
- Embedding 命中："地里烂根了" → pest_risk
- 联合链路："选个高产品种" → [crop_compare, variety_recommend]
- LLM fallback："今年种啥能赚钱还不累" → LLM 决策
- deep/simple 图不受影响

### 高风险误区

- **禁止**在第 8 轮新增代码修复前 7 轮的问题——有问题回退到对应轮次修复。
- **禁止**跳过任何一条 E2E 场景。
- **禁止**在 tsc 有 warning 时声明通过。

---

## 每轮收敛判定补充规则

### checklist 证据要求

- [x] **全部项已勾选**（不得有空勾选、不得有"推测通过"）
- [x] **每项勾选有可验证证据**：编译项附 `npx tsc --noEmit` 输出，代码项附文件路径+行号
- [x] **未执行项诚实保留**：无法在当前轮次验证的项保留为 `- [ ]`，注明"待后续运行时验证"

### 收敛声明规则

当前轮次 AI 不得自行声明"本轮已收敛"并直接进入下一轮。收敛声明只能由开发者确认后做出。执行 AI 的职责是完成 checklist/tasks 并附证据。

---

## 附录：每轮启动模板

```text
## 上下文

你在执行 farm-agent domain-vocabulary-v2 的 [第N轮]。
上游 [第1轮~第N-1轮] 已完成。
先读 farm-agent-domain-vocabulary-handoff-v2.md 的 <第N轮> 章节。

## 启动步骤

1. 执行 session-init SKILL
2. query_audit_logs({ keyword: "farm-agent-domain-vocabulary-plan-v2" }) → 恢复上游上下文
3. 读 .qoder/specs/farm-agent-domain-vocabulary-v2/spec.md
4. 读 .qoder/specs/farm-agent-domain-vocabulary-v2/tasks.md 对应 Phase
5. 读 .qoder/specs/farm-agent-domain-vocabulary-v2/checklist.md
6. 按 tasks.md 顺序执行代码修改
7. 每完成一个 SubTask：验证 → 附证据 → 勾选 checklist
8. 每完成一个文件：record_dev_operation → query_audit_logs 回查确认
9. 本轮全部完成后：通知开发者验收

## 关键提醒

- 当前执行的是 [第N轮]/8
- 每轮是原子工程事务，不允许拆到下一轮补齐
- handoff 是入口索引；具体实现以 spec/tasks/checklist 为准
- 禁止自行声明收敛
- 禁止简化代码实现
- 禁止跳过 MCP 回查
```
