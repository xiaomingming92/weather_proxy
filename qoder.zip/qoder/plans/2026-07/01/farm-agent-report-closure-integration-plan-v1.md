# farm-agent-report-closure-integration-plan-v1

## PLAN 元信息

- **Plan 名称**: farm-agent-report-closure-integration-v1
- **启动时间**: 2026-07-01
- **关联文档**:
  - Report Workflow: `.qoder/reports/REPORT-WORKFLOW.md`
  - Gateway Report: `.qoder/reports/farm-agent-runtime-report/gateway.md`
  - ADD Vocabulary: `.qoder/vocabulary/add-governance-vocabulary.md`
  - add-paradigm SKILL: `.qoder/skills/add-paradigm/SKILL.md`
  - Review: `.qoder/reviews/farm-agent-report-closure-integration-review-v1.md`
  - Specs: `.qoder/specs/farm-agent-report-closure-integration/`
  - ADD 规则: `.qoder/rules/project_rules.md`
  - 理论实践映射: `.qoder/rules/theory-practice-map.toml`
  - Guardian: `.qoder/agents/add-flow-guardian.md`
  - Orchestrator: `.qoder/agents/add-orchestrator.md`
  - 入口: `AGENTS.md`
- **ADD-7 审计策略**:

| # | 文件 | targetType | action | beforeState | afterState |
|---|------|-----------|--------|------------|-----------|
| 1 | `.qoder/templates/report-handoff-template.md` | TEMPLATE | TEMPLATE_CREATED | 不存在 | 新建独立 report-handoff 模板 |
| 2 | `AGENTS.md` | DOC | DOC_UPDATED | "9 阶段 Step 0-8"，三步闭环 | "10 阶段 Step 0-9"，四步闭环 |
| 3 | `.qoder/skills/add-paradigm/SKILL.md` | SKILL | SKILL_MODIFIED | "9 phases Step 0-8"，无 Step 9 | "10 phases Step 0-9"，新增 Step 9 章节 |
| 4 | `.qoder/vocabulary/add-governance-vocabulary.md` | DOC | DOC_UPDATED | 无 report/boundary 词汇，Step 8 三步闭环 | 新增 Step 9 + report 词汇，Step 8 更新 |
| 5 | `.qoder/templates/add-route-template.md` | TEMPLATE | TEMPLATE_MODIFIED | Step 0-8 状态表格 | 新增 Step 9 行 |
| 6 | `.qoder/templates/add-route-template-heavyweight.md` | TEMPLATE | TEMPLATE_MODIFIED | Step 0-8 状态表格 | 新增 Step 9 行 |
| 7 | `.qoder/rules/project_rules.md` | DOC | DOC_UPDATED | "9 个阶段（Step 0 - Step 8）" | "10 个阶段（Step 0 - Step 9）" |
| 8 | `.qoder/rules/theory-practice-map.toml` | DOC | DOC_UPDATED | 无 Step 9 映射 | 新增 Step 9 映射 |
| 9 | `.qoder/agents/add-flow-guardian.md` | AGENT | AGENT_MODIFIED | 无 Step 9 入口/出口 | 新增 Step 9 入口/出口检查 |
| 10 | `.qoder/agents/add-orchestrator.md` | AGENT | AGENT_MODIFIED | 无 Step 9 编排 | 新增 Step 9 编排 + 验收提醒 |
| 11 | `.qoder/reports/REPORT-WORKFLOW.md` | DOC | DOC_UPDATED | `**Triage 结果**` 格式，未引用 handoff 模板，Step 0-8 | `- [x]` 格式对齐脚本，引用 report-handoff 模板，Step 0-9 |
| 12 | `.qoder/reports/farm-agent-runtime-report/gateway.md` | REPORT | REPORT_UPDATED | 31 条发现无 `- [x]` 标记，手动统计不准，无用的 §4 | 31 条均有 `- [x]`，删除 §2/§4，脚本可识别 |

---

## 一、背景与目标

### 1.1 问题现状

`gateway.md` 运行时发现的关闭流程存在三个断裂：

1. **handoff 无 Report Closure 模板** — handoff 是 ADD Step 8 验收产物，但没有任何模板告诉开发者如何关闭 gateway.md 发现
2. **REPORT-WORKFLOW.md 格式与脚本不一致** — doc 写 `**Triage 结果**: 已关闭 — {原因}`，但 `check-boundary-report.ts` L58-60 实际解析的是 `- [x]` checklist 行
3. **ADD 工作流未接入 Report 流程** — Step 8 三步闭环（devlog/handoff/架构回看）缺少"关闭 gateway.md 发现"这一步；没有新增 Step 来承载运行时修复的监控关闭职责

### 1.2 目标

1. **新建独立模板** `report-handoff-template.md` — 定义 Report Closure 的标准 handoff 填空模板
2. **新增 ADD Step 9（Report Closure）** — 条件性步骤，runtime-fix plan 必走，其他 plan 跳过
3. **同步所有治理文件** — 10 个文件从 "Step 0-8 / 9阶段" 更新到 "Step 0-9 / 10阶段"
4. **修正 REPORT-WORKFLOW.md** — 格式对齐脚本解析逻辑，引用 report-handoff 模板
5. **词汇表覆盖** — 新增 report/boundary/Step 9 相关触发词
6. **修复 gateway.md 当前数据** — 31 条发现追 `- [x]`，删除手动统计

---

## 二、方案

### 2.1 为什么是独立模板而不是扩展已有 handoff 模板

- `handoff-single-round-template.md` 和 `handoff-multi-round-template.md` 是通用 ADD 模板，不是所有 plan 都涉及 runtime-fix
- 独立模板 `report-handoff-template.md` 由 runtime-fix plan 的 handoff 文件按需引用（`include` 方式），不污染通用模板

### 2.2 为什么是 Step 9 而不是 Step 8 扩展

| 维度 | Step 8 扩展 | Step 9 独立 |
|------|:-----------:|:----------:|
| 关注点分离 | ❌ 文档收敛 + 监控关闭耦合 | ✅ 解耦 |
| 条件触发 | ❌ 非 runtime plan 此步骤为空 | ✅ runtime-fix 必走，其他跳过 |
| 审计可追溯 | ❌ 混在 Step 8 中 | ✅ 独立 step 编号可独立查询 |
| 门禁编排 | ❌ 无独立入口/出口 | ✅ Guardian/Orchestrator 可独立检查 |

**Step 9 定义**：

> **Step 9: Report Closure（运行时发现关闭）** — 条件性步骤。仅 runtime-fix plan（修复 gateway.md 中运行时发现）需要执行。按 `report-handoff-template.md` 在 handoff 中追加 Report Closure 章节，在 gateway.md 中对每个被修复的发现条目追加 `- [x]` 标记，运行 `npx tsx scripts/check-boundary-report.ts` 验证关闭。

### 2.3 report-handoff-template.md 设计

```markdown
# report-handoff-template

> 本模板供 runtime-fix plan 的 handoff 文件按需引用。
> 用途：定义如何在 handoff 中描述 gateway.md 发现的关闭步骤。

## §X Report Closure（gateway.md 发现关闭）

> `check-boundary-report.ts` 通过解析每个 `### 发现:` 条目内的 `- [x]` 行判断关闭状态。
> 修复完成后，按以下步骤关闭对应发现。

### 关闭格式

在 gateway.md 中每个待关闭发现条目体末尾追加：

\`\`\`markdown
- [x] Triage 结果: ✅ 已修复 — commit {hash}（{原因}）。关闭时间: {日期}
\`\`\`

### 本次需关闭的发现

| 错误签名 | 出现次数 | 关闭标记位置 |
|---------|:-------:|------------|
| {错误类型1} | {N} | {锚点描述} |

### 关闭后验证

\`\`\`bash
npx tsx scripts/check-boundary-report.ts
# 预期：已关闭类型不再出现在"未关闭"列表中
\`\`\`
```

### 2.4 需要同步"Step 0-8 → Step 0-9"的文件清单

| # | 文件 | 具体改动 |
|---|------|---------|
| 1 | `AGENTS.md` | L22: "三步闭环" → "四步闭环（含 Step 9）"；L36: "9 阶段（Step 0-8）" → "10 阶段（Step 0-9）"；新增 Step 9 词汇行 |
| 2 | `.qoder/skills/add-paradigm/SKILL.md` | L3 description: "9 phases" → "10 phases"；新增 Step 9 完整章节；Step 8 收敛条件加"如为 runtime-fix 则进入 Step 9" |
| 3 | `.qoder/vocabulary/add-governance-vocabulary.md` | 类别 A 新增 gateway.md / report-handoff 词汇；类别 B Step 8 改为四步闭环 + 新增 Step 9 行；类别 C 新增 boundary-report |
| 4 | `.qoder/templates/add-route-template.md` | Step 状态表格新增 Step 9 行（条件性：runtime-fix 才填） |
| 5 | `.qoder/templates/add-route-template-heavyweight.md` | 同上 |
| 6 | `.qoder/rules/project_rules.md` | L89: "9 个阶段（Step 0 - Step 8）" → "10 个阶段（Step 0 - Step 9）"；L52 ADD-0.1 补充 Step 9；新增 ADD-15 Report Closure 原则 |
| 7 | `.qoder/rules/theory-practice-map.toml` | 新增 `"add-paradigm:Step 9"` 映射 |
| 8 | `.qoder/agents/add-flow-guardian.md` | 新增 Step 9 入口（前置：确认 runtime-fix plan）+ 出口（检查 gateway.md `- [x]` 覆盖率） |
| 9 | `.qoder/agents/add-orchestrator.md` | Step 表新增 Step 9 行；新增 Step 9 编排提醒 |
| 10 | `.qoder/reports/REPORT-WORKFLOW.md` | L158-163 格式修正 `- [x]`；L137 "Step 0-8" → "Step 0-9"；新增 "Step 9 Report Closure" 流程段 |

---

## 三、实施步骤 + 依赖图

```
Task A ── 新建 report-handoff-template.md
            │
            ├──────────────────────┐
            ▼                      ▼
Task B ── 更新 AGENTS.md      Task C ── 更新 add-governance-vocabulary.md
            │                      │
            └──────────┬───────────┘
                       ▼
Task D ── 更新 add-paradigm SKILL.md（核心：新增 Step 9 章节）
            │
            ├──────────────────────┬──────────────┬──────────────┐
            ▼                      ▼              ▼              ▼
Task E ── 更新              Task F ── 更新   Task G ── 更新   Task H ── 更新
add-route 模板              project_rules    theory-practice  add-flow-guardian
(轻量+重型)                 .md             -map.toml        .md
            │                      │              │              │
            └──────────────────────┴──────────────┴──────┬───────┘
                                                         ▼
Task I ── 更新 add-orchestrator.md
            │
            ▼
Task J ── 修正 REPORT-WORKFLOW.md（格式对齐 + 流程补充）
            │
            ▼
Task K ── 修复 gateway.md（31 条发现追 - [x]，删除 §2/§4）
```

### Task A: 新建 report-handoff-template.md

- **文件**: `.qoder/templates/report-handoff-template.md`
- **内容**: 上述 §2.3 的模板内容
- **验证**: 文件存在，包含 "关闭格式" / "关闭后验证" / "check-boundary-report" 三个关键词

### Task B: 更新 AGENTS.md

- L22: `三步闭环：...` → `四步闭环（含 Step 9 Report Closure）...`
- L36: `9 阶段（Step 0-8）` → `10 阶段（Step 0-9）`
- 新增词汇行: `Step 9 / Report Closure / 关闭发现` → `仅 runtime-fix plan 执行，按 report-handoff-template 在 gateway.md 追加 - [x]`

### Task C: 更新 add-governance-vocabulary.md

新增词汇:

| 类别 | 触发词 | 操作 | 优先级 |
|------|--------|------|:--:|
| A | `gateway.md` / `gateway报告` / `运行时报告` | 读 `.qoder/reports/farm-agent-runtime-report/gateway.md` | P1 |
| A | `report-handoff` / `report交接` | 读 `.qoder/templates/report-handoff-template.md` | P1 |
| B | `Step 9` / `Report Closure` / `关闭发现` / `标记修复` | 按 `report-handoff-template.md` 在 gateway.md 追加 `- [x]`，运行 check-boundary-report 验证 | P1 |
| C | `boundary-report` / `边界报告检查` | 运行 `npx tsx scripts/check-boundary-report.ts` | P1 |

更新词汇:
- Step 8 / 收敛: "三步闭环" → "四步闭环（含 Step 9 Report Closure）"
- "9 阶段（Step 0-8）" → "10 阶段（Step 0-9）"

### Task D: 更新 add-paradigm SKILL.md（核心）

改动点:
1. L3 description: `9 phases (Step 0-8)` → `10 phases (Step 0-9)`
2. L66: `Step 0~8` → `Step 0~9`
3. L92: `Step 0-8 具体动作` → `Step 0-9 具体动作`
4. L975 Step 8 收敛条件新增: `如有 gateway.md runtime 发现 → 进入 Step 9 Report Closure`
5. 新增 Step 9 完整章节（在 Step 8 之后）:

```
## Step 9：Report Closure（运行时发现关闭）

> **条件性步骤**：仅 runtime-fix plan（修复 gateway.md 运行时发现）执行。
> 非 runtime plan 跳过本步骤，直接进入架构文档回看。

### 9.1 读取 report-handoff 模板

读取 `.qoder/templates/report-handoff-template.md`，按模板内容在 handoff 中追加 Report Closure 章节。

### 9.2 在 handoff 中追加 Report Closure 章节

按模板填充：
- 关闭格式说明
- 本次需关闭的发现列表（错误签名 + 出现次数 + 锚点）
- 关闭后验证命令

### 9.3 在 gateway.md 中追加 - [x] 标记

对每个被修复的发现条目体末尾追加：
```markdown
- [x] Triage 结果: ✅ 已修复 — commit {hash}（{原因}）。关闭时间: {日期}
```

### 9.4 验证关闭

运行 `npx tsx scripts/check-boundary-report.ts`，确认已修复类型不再出现在"未关闭"列表中。

### Step 9 产出检查

- [ ] handoff 文件已追加 Report Closure 章节（按 report-handoff-template.md）
- [ ] gateway.md 被修复的发现均已追加 `- [x]` 标记
- [ ] `check-boundary-report.ts` 已关闭类型无残留
```

### Task E: 更新 add-route 模板（轻量 + 重型）

- `.qoder/templates/add-route-template.md` Step 状态表格新增 Step 9 行: `| Step 9 | Report Closure（仅 runtime-fix） | ⬜ |`
- `.qoder/templates/add-route-template-heavyweight.md` 同上，但用重型措辞

### Task F: 更新 project_rules.md

- L89: `9 个阶段（Step 0 - Step 8）` → `10 个阶段（Step 0 - Step 9）`
- L52 ADD-0.1 行补充: `Step 0 + Step 8 第二阶段 + Step 9（runtime-fix）`
- 新增 ADD-15 原则行: `ADD-15 | add-paradigm Step 9 | 仅 runtime-fix plan，关闭 gateway.md 运行时发现`

### Task G: 更新 theory-practice-map.toml

- 新增: `"add-paradigm:Step 9"` 映射到 Report Closure 实践

### Task H: 更新 add-flow-guardian.md

- 新增 Step 9 入口检查: "确认当前 plan 为 runtime-fix plan → gateway.md 发现可定位 → report-handoff-template 已读取"
- 新增 Step 9 出口检查: "gateway.md 被修复发现均已 `- [x]` → check-boundary-report 通过"

### Task I: 更新 add-orchestrator.md

- Step 表新增 Step 9 行: `| Step 9 | 是（runtime-fix） | Step 8 收敛 |`
- 新增 Step 9 编排提醒: "Step 9 通过后提醒：gateway.md 已关闭，可进入架构回看"

### Task J: 修正 REPORT-WORKFLOW.md

- L158-163: `**Triage 结果**: 已关闭 — {原因}` → `- [x] Triage 结果: 已关闭 — {原因}`（对齐 `check-boundary-report.ts` L58-60 解析逻辑）
- L137: `进入 ADD 范式（Step 0-8）` → `进入 ADD 范式（Step 0-9），runtime-fix plan 走完 Step 9 Report Closure`
- Triage → Plan 流程 (L116-146): 补充 "修复完成后 → 按 [report-handoff-template](../templates/report-handoff-template.md) 在 handoff 中追加 Report Closure 章节 → 在 gateway.md 追加 `- [x]` 标记 → 运行 check-boundary-report 验证"

### Task K: 修复 gateway.md

- 给 4 种类型 31 条发现追加 `- [x]` 标记（使用 replace_all × 4）
  1. contract null ×19: 在每个 `**合约断裂点**` 块末尾追加
  2. findUnique ×2: 在每个 `app-route-turbo.runtime.dev.js` 堆栈末尾 ``` 后追加
  3. HASH_SEED_TEXT ×6: 在每个 webpack middleware loader 堆栈末尾 ``` 后追加
  4. 未知 GET action ×4: 在每个 `app-route.runtime.dev.js` 堆栈末尾 ``` 后追加
- 删除手动统计 §2（脚本自算，不准）
- 删除 §4 修复验证（被 per-finding `- [x]` 取代）

---

## 四、验收标准

- [ ] `report-handoff-template.md` 已新建，内容含关闭格式 + 关闭后验证
- [ ] `AGENTS.md` 已更新 10 阶段 / 四步闭环 / Step 9 词汇
- [ ] `add-paradigm SKILL.md` 已新增 Step 9 完整章节 + 所有引用更新
- [ ] `add-governance-vocabulary.md` 已新增 gateway.md / report-handoff / Step 9 / boundary-report 词汇
- [ ] `add-route-template.md`（轻量+重型）Step 状态表均已新增 Step 9 行
- [ ] `project_rules.md` L89 已改为 10 阶段 + 新增 ADD-15
- [ ] `theory-practice-map.toml` 已新增 Step 9 映射
- [ ] `add-flow-guardian.md` 已新增 Step 9 入口/出口
- [ ] `add-orchestrator.md` 已新增 Step 9 编排
- [ ] `REPORT-WORKFLOW.md` 格式已对齐 `- [x]`，已引用 report-handoff 模板，已更新 Step 0-9
- [ ] `gateway.md` 31 条发现均已 `- [x]` 标记，§2/§4 已删除
- [ ] `npx tsx scripts/check-boundary-report.ts` 输出全部已关闭（或仅剩未修类型）

---

## 🔁 Review 回流（0.6.5）

> 来源: [farm-agent-report-closure-integration-review-v1](../../reviews/farm-agent-report-closure-integration-review-v1.md)

| Review # | 严重程度 | 回流位置 | 处理 |
|----------|:------:|---------|:--:|
| 1 | P0 | §三 Task K | gateway.md 31 条追 `- [x]` |
| 2 | P0 | §三 Task J | REPORT-WORKFLOW.md 格式对齐 |
| 3 | P1 | §三 Task D | add-paradigm "9→10 phases" |
| 4 | P1 | §三 Task C | 词汇表新增 report 条目 |
| 5 | P2 | — | 已知不处理：历史 plan/review 不回溯修改 |

---

## 五、关联文档

| 文档 | 路径 |
|------|------|
| Report Workflow | `.qoder/reports/REPORT-WORKFLOW.md` |
| Gateway Report | `.qoder/reports/farm-agent-runtime-report/gateway.md` |
| ADD Vocabulary | `.qoder/vocabulary/add-governance-vocabulary.md` |
| add-paradigm SKILL | `.qoder/skills/add-paradigm/SKILL.md` |
| ADD 规则 | `.qoder/rules/project_rules.md` |
| 理论实践映射 | `.qoder/rules/theory-practice-map.toml` |
| Guardian Agent | `.qoder/agents/add-flow-guardian.md` |
| Orchestrator Agent | `.qoder/agents/add-orchestrator.md` |
| AGENTS.md | `AGENTS.md` |
| add-route 轻量模板 | `.qoder/templates/add-route-template.md` |
| add-route 重型模板 | `.qoder/templates/add-route-template-heavyweight.md` |
| handoff 单轮模板 | `.qoder/templates/handoff-single-round-template.md` |
| handoff 多轮模板 | `.qoder/templates/handoff-multi-round-template.md` |
| check-boundary-report | `scripts/check-boundary-report.ts` |
