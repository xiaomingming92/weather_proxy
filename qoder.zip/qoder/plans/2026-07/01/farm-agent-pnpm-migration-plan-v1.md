# farm-agent-pnpm-migration-plan-v1

> 来源: farm-agent 从 npm 切换到 pnpm 包管理器
> 创建: 2026-07-01

## PLAN 元信息

- **Plan 名称**: farm-agent-pnpm-migration-v1
- **启动时间**: 2026-07-01
- **主导 AI**: Qoder
- **关联文档**:
  - CI: `.gitlab-ci.yml`
  - Volta: `volta.toml`
  - 包管理: `package.json`、`.npmrc`(新建)
  - 锁文件: `package-lock.json`(删除)、`pnpm-lock.yaml`(保留)
- **Review**: [farm-agent-pnpm-migration-review-v1](../../reviews/2026-07/01/farm-agent-pnpm-migration-review-v1.md)
  - 状态: ⚠️ 待修复（P0×5 / P1×5 / P2×3）

---

## 一、背景与目标

### 1.1 现状

| 项目 | 当前状态 |
|------|----------|
| 包管理器 | npm（`package-lock.json` 519KB） |
| pnpm 环境 | Volta 已全局安装 pnpm 11.9.0 |
| pnpm-lock.yaml | 已存在（351KB），与 package-lock.json 并存（双锁文件） |
| Volta 配置 | `volta.toml` 仅 pin node 24.x.x，未 pin pnpm |
| package.json | 无 `packageManager` 字段；scripts 内用 `npm run` 互相调用 |
| CI (.gitlab-ci.yml) | `npm ci --legacy-peer-deps`、`npm run db:generate`、`npm run build` |
| .npmrc | 不存在 |
| 文档脚本 | `scripts/db-export.ts`、`scripts/db-import.ts` 等引用 `npm run db:xxx` |

### 1.2 目标

1. 正式切换到 pnpm 作为唯一包管理器
2. 解决双锁文件问题：删除 `package-lock.json`，仅保留 `pnpm-lock.yaml`
3. Volta 自动切换：开发者 `cd` 进项目自动使用 pnpm
4. CI 无缝切换：`npm ci` → `pnpm install --frozen-lockfile`
5. 脚本兼容：所有 `npm run` 调用改为 `pnpm` 或直接用脚本名

---

## 二、Volta 配置

### 2.1 volta.toml 添加 pnpm pin

```diff
{
  "node": "24.x.x",
+ "pnpm": "11.9.0"
}
```

效果：开发者 `cd` 进项目目录，Volta 自动选用 pnpm 11.9.0。

### 2.3 团队协作要求

**强制所有开发者安装 Volta**（`curl https://get.volta.sh | bash`），`cd` 进项目自动切换 pnpm 11.9.0。全局 pnpm 版本不一致会导致 lockfile 格式冲突，Volta 是唯一保证版本一致的方式。

CI 环境同样通过 Volta 获取 pnpm，不另装全局 npm 版 pnpm。

### 2.4 package.json 添加 packageManager 字段

```json
"packageManager": "pnpm@11.9.0"
```

配合 corepack 或 Volta 使用，CI 环境也能自动识别。

---

## 三、锁文件清理

### 3.1 删除 package-lock.json

```bash
rm package-lock.json
git rm package-lock.json  # 已跟踪的话
```

### 3.2 重新生成 pnpm-lock.yaml

当前 `pnpm-lock.yaml` 来源不明（可能与 package-lock.json 并存时的手动创建产物），必须删除后从 package.json 重新解析，避免旧 lockfile 中的脏数据污染新锁文件：

```bash
rm pnpm-lock.yaml
pnpm install
```

不依赖旧 lockfile 增量更新，确保 lockfile 与 package.json 完全一致。

### 3.3 确保 lock 文件一致性

CI 使用 `pnpm install --frozen-lockfile`，本地新增依赖后必须提交 `pnpm-lock.yaml`。

### 3.4 pre-commit hook：lockfile 同步校验

防止本地改 `package.json` 后忘记跑 `pnpm install` 更新 lockfile 并提交，导致 CI `--frozen-lockfile` 挂掉。在 `.githooks/pre-commit` 中增加：

```bash
# 当 package.json 变更但 pnpm-lock.yaml 未同步变更时阻断
if git diff --cached --name-only | grep -q "package.json" && \
   ! git diff --cached --name-only | grep -q "pnpm-lock.yaml"; then
  echo "⚠️  package.json 已变更但 pnpm-lock.yaml 未更新"
  echo "   请先运行 pnpm install 并提交 pnpm-lock.yaml"
  exit 1
fi
```

---

## 四、package.json scripts 改造

### 4.1 替换 `npm run` 内联调用

`pnpm` 允许直接用脚本名调用（类似于 npm），但显式 `npm run` 需要改。实测 package.json 共 **5 处** `npm run` 引用：

| 脚本 | 行 | `npm run` 调用数 | 实例 |
|------|----|-------------------|------|
| `dev` | L7 | **2** | `npm run predev`, `npm run db:ensure` |
| `start` | L9 | **1** | `npm run db:ensure` |
| `db:reset` | L24 | **1** | `npm run db:init:safe` |
| `kb:logs` | L36 | **1** | `npm run kb:sync`（echo 帮助文本，建议同步改） |

改法：`npm run xxx` → `pnpm xxx`（去掉 `run` 关键字）。

### 4.2 npx 调用

`package.json` scripts 中另有 **6 处** `npx prisma` 调用（L19 `db:migrate:deploy`, L21 `db:migrate`, L22 `db:generate`, L23 `db:studio`, L24 `db:reset`）。统一改为 `pnpm exec prisma` 标准写法，不依赖 pnpm 隐式 PATH 注入。

---

## 五、CI 改造 (.gitlab-ci.yml)

### 5.1 build 阶段

```diff
- $AI "cd $DEPLOY_DIR && npm ci --legacy-peer-deps" || ...
+ $AI "cd $DEPLOY_DIR && pnpm install --frozen-lockfile" || ...

- $AI "cd $DEPLOY_DIR && npm run db:generate" || ...
+ $AI "cd $DEPLOY_DIR && pnpm db:generate" || ...

- $AI "cd $DEPLOY_DIR && npm run build" || ...
+ $AI "cd $DEPLOY_DIR && pnpm build" || ...
```

### 5.2 deploy 阶段

```diff
- $AI "cd $DEPLOY_DIR && npm run db:generate" || ...
+ $AI "cd $DEPLOY_DIR && pnpm db:generate" || ...
```

### 5.3 pnpm 可用性

VPS 上确认 pnpm 已通过 Volta 安装（`volta install pnpm@11.9.0`）。

CI 当前使用 `$AI="sudo -u ai bash -l -c"` 模式，`sudo -u` 可能改变 Volta shim 的环境变量行为。在 CI prepare 脚本开头增加显式检查：

```bash
# CI prepare 脚本 — 通过 Volta 验证 pnpm 可用性
$AI "command -v pnpm && pnpm --version" || {
  echo "!!! pnpm 不可用，请确保 ai 用户已通过 Volta 安装 pnpm: volta install pnpm@11.9.0"
  exit 1
}
```

若 `command -v pnpm` 在 `sudo -u ai bash -l -c` 下找不到（Volta shim 未生效），调整为让 `ai` 用户在 login shell 中执行 `volta install pnpm@11.9.0` 后再试。

---

## 六、.npmrc 配置

新建 `.npmrc`：

```ini
# pnpm 配置
public-hoist-pattern[]=*prisma*
public-hoist-pattern[]=*@prisma*
```

- `public-hoist-pattern[]=*prisma*`：Prisma CLI 需要全局可执行
- **不使用** `shamefully-hoist=true`：避免全局破坏 pnpm 严格依赖解析，仅按需 hoist Prisma 相关包。后续如果 Next.js 等框架有隐式依赖需求，再按需追加 pattern

> **原则**: 以 `public-hoist-pattern[]` 从窄到宽逐步放宽，而不是靠 `shamefully-hoist=true` 一把梭后无法回退。

---

## 七、文档脚本更新

全量 grep 扫描结果显示需更新 **24 个文件、~73 处** `npm`/`npx` 引用，分 5 大类：

### 7.1 scripts/*.ts 文案（7 文件，17 处）

| 文件 | 处数 | 类型 | 说明 |
|------|------|------|------|
| `scripts/db-export.ts` | 8 | JSDoc + console | `npm run db:export` |
| `scripts/db-import.ts` | 2 | JSDoc | `npm run db:import` |
| `scripts/agent-diagnose.ts` | 2 | console.log | `npm run db:start` |
| `scripts/check-dev-env.ts` | 2 | console.error | `npm run start`, `npm run dev` |
| `scripts/startup-farm-service-login.ts` | 1 | JSDoc | `npm run dev` |
| `scripts/sync-farm-api-index.ts` | 1 | JSDoc | `npm run docs:sync-farm-service-api` |
| `scripts/sync-farm-service-api-docs.ts` | 1 | JSDoc | `npm run docs:sync-farm-api` |

### 7.2 scripts/*.sh 中的 npx 调用（6 文件，~19 处）

| 文件 | 处数 | 说明 |
|------|------|------|
| `scripts/db-ensure.sh` | 5 | `npx prisma generate/migrate diff/migrate deploy` + `npx tsx` |
| `scripts/db-ensure.prod.sh` | 5 | `npx prisma migrate deploy/resolve/diff` + echo 中的 `npx prisma migrate dev` |
| `scripts/db-import.sh` | 3 | `npx` 可用性检测 + `npx tsx` 调用 ×2 |
| `scripts/db-export.sh` | 2 | `npx` 可用性检测 + `npx tsx` 调用 |
| `scripts/start-infrastructure.sh` | 1 | `npm run dev` 提示语 |
| `scripts/ensure-cron.sh` | 1 | 注释中 `npm run dev` |

### 7.3 scripts/*.ts 中的 npx 用法说明（6 文件，9 处）

| 文件 | 处数 | 说明 |
|------|------|------|
| `scripts/test-wecom-notify.ts` | 1 | 用法注释 |
| `scripts/manage-service-account.ts` | 1 | 用法注释 |
| `scripts/kb-import.ts` | 1 | 用法注释 |
| `scripts/kb-sync-expert-collections.ts` | 1 | 用法注释 |
| `scripts/update-seed-price.ts` | 3 | 用法注释 |
| `scripts/qoder-add-runner.ts` | 2 | 用法注释 |

### 7.4 测试文件（2 文件，5 处）

| 文件 | 处数 | 说明 |
|------|------|------|
| `src/tests/sse-event-flow.test.ts` | 1 | `npx vitest` |
| `tests/test-mcp-server.sh` | 4 | `npx tsx` |

### 7.5 README.md（1 文件，15 处）

| 章节 | 处数 | 命令 |
|------|------|------|
| 安装 | 1 | `npm install` → `pnpm install` |
| 开发启动 | 1 | `npm run dev` → `pnpm dev` |
| 数据库 | 4 | `npm run db:start/stop/status/ensure` |
| 知识库 | 6 | `npm run kb:sync/reset/logs/logs:clear/export/import` |
| Agent 诊断 | 3 | `npm run agent:diagnose/logs/logs:clear` |

### 7.6 改造原则

- `.ts` 文件的 JSDoc/console 文案：`npm run xxx` → `pnpm xxx`
- `.sh` 文件中的 `npx`：`npx prisma` → `pnpm exec prisma`，`npx tsx` → `pnpm exec tsx`，`npx` 可用性检测改为 `pnpm`
- `.ts` 用法注释中的 `npx tsx`：`npx tsx scripts/xxx.ts` → `pnpm exec tsx scripts/xxx.ts`
- `README.md`：全局 `npm` → `pnpm`

> **注意**: 这些文件中的引用是**文档/帮助文本/注释**，不是运行时执行路径。即使不改也不会导致运行时崩溃，但会给出错误命令提示。Plan 完整性要求全部覆盖。

---

## 八、实施步骤

| # | 步骤 | 文件 | 说明 |
|---|------|------|------|
| 1 | Volta pin pnpm | `volta.toml` | 添加 `"pnpm": "11.9.0"` |
| 2 | packageManager 字段 | `package.json` | 添加 `"packageManager": "pnpm@11.9.0"` |
| 3 | 清理旧锁文件 | `package-lock.json` | 删除；验证 `.gitignore` 无显式条目 |
| 4 | 生成新锁文件 | `pnpm-lock.yaml` | 删除旧 lockfile → `pnpm install` 从 package.json 重新解析 |
| 5 | 创建 .npmrc | `.npmrc`(新) | `public-hoist-pattern[]` 优先，去掉 `shamefully-hoist=true` |
| 6 | 改 scripts 内联调用 | `package.json` | `npm run` → `pnpm`（5处）；`npx prisma` → `pnpm exec prisma`（6处） |
| 7 | CI 适配 | `.gitlab-ci.yml` | `npm ci`→`pnpm install --frozen-lockfile`；`npm run`→`pnpm`（4处）；增加 pnpm 可用性检查 |
| 8 | 脚本文案更新（.ts） | 7 个 .ts 文件 | JSDoc/console 文案 `npm run`→`pnpm`（17处） |
| 9 | 脚本 npx 调用（.sh） | 6 个 .sh 文件 | `npx prisma`→`pnpm exec prisma`；`npx tsx`→`pnpm exec tsx`（~17处） |
| 10 | 用法注释更新（.ts） | 6 个 .ts 文件 | `npx tsx`→`pnpm exec tsx`（9处） |
| 11 | 测试文件 | `sse-event-flow.test.ts`, `test-mcp-server.sh` | `npx vitest`/`npx tsx`→`pnpm exec`（5处） |
| 12 | README.md | `README.md` | 全局 `npm`→`pnpm`（15处） |
| 13 | pre-commit hook | `.githooks/pre-commit` | 增加 lockfile 同步校验（§3.4） |
| 14 | 验证 | `pnpm install && pnpm build && tsc --noEmit` | 本地编译通过 |
| 15 | VPS 预装 pnpm | VPS | `volta install pnpm@11.9.0`（不走 `npm i -g pnpm`） |

---

## 九、风险评估

| 风险 | 缓解 |
|------|------|
| `pnpm` 严格依赖解析导致隐式依赖报错 | `public-hoist-pattern[]` 按需放宽 |
| CI VPS 上 pnpm 未安装 | VPS 上预先通过 Volta 安装：`volta install pnpm@11.9.0` |
| `sudo -u ai bash -l -c` 下 pnpm 不可用 | 显式 `command -v pnpm` 检查 + 确认 ai 用户 Volta 配置正确 |
| 删除 package-lock.json 后回滚困难 | git 历史保留，可回退到上一版本 |
| Prisma generate 在 pnpm 下行为差异 | public-hoist-pattern 确保 Prisma CLI 可访问 |
| 双锁文件冲突（npm 和 pnpm 同时存在） | 明确删除 package-lock.json，.gitignore 不恢复 |
| Node 24.x 与 pnpm 11.9.0 兼容性问题 | 构建前 `pnpm --version` 验证正常；查阅 [pnpm 官方兼容性表](https://pnpm.io/installation#compatibility) |

---

## 十、验收标准

- [ ] `volta.toml` 包含 `"pnpm": "11.9.0"`
- [ ] `package.json` 包含 `"packageManager": "pnpm@11.9.0"`
- [ ] `package-lock.json` 已删除
- [ ] `pnpm install` 成功，`pnpm-lock.yaml` 更新
- [ ] `.npmrc` 存在且配置正确（无 `shamefully-hoist=true`）
- [ ] `pnpm build` 成功
- [ ] `tsc --noEmit` 通过
- [ ] CI pipeline 使用 pnpm 命令
- [ ] `package.json` scripts 中无 `npm run` 残留（5 处）
- [ ] `package.json` scripts 中 `npx prisma` 已替换为 `pnpm exec prisma`（6 处）
- [ ] `scripts/*.ts` 文案中无 `npm run` 残留（7 文件 17 处）
- [ ] `scripts/*.sh` 中 `npx prisma`/`npx tsx` 已替换（6 文件 ~17 处）
- [ ] `scripts/*.ts` 用法注释中 `npx tsx` 已替换（6 文件 9 处）
- [ ] 测试文件中 `npx vitest`/`npx tsx` 已替换（2 文件 5 处）
- [ ] `README.md` 中无 `npm` 残留（15 处）
- [ ] `.githooks/pre-commit` 包含 lockfile 同步校验
- [ ] 全项目 `grep -r 'npm ' --include='*.{ts,tsx,js,sh,yml,md}'` 仅返回已确认无需修改的行