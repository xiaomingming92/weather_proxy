# farm-agent-report-closure-integration-add-route-v1

> **定位**：Plan → ADD 十阶段执行映射。
> **模式**：重型。绑定 Plan + Specs + Tasks + Handoff。
> **绑定**：Plan: `farm-agent-report-closure-integration-plan-v1.md` · Spec: `.qoder/specs/farm-agent-report-closure-integration/` · Handoff: 待生成

---

## Step 0：文档先行

- [x] Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
- [x] Review 已生成：`farm-agent-report-closure-integration-review-v1.md`
- [x] 项目文档：纯治理变更，`docs/` 无需更新（无架构/需求变更）
- [x] DPS = 79 🟡 WARN（API维度不适用 + 回流手动确认），可进入 Step 1

---

## Step 1：功能分析

**N/A** — 纯治理文档变更，无代码审计阶段。

---

## Step 2：审计基础设施

**N/A** — 无代码改动，无需审计打点。

---

## Step 3：业务逻辑实现（治理文件变更）

### §3.0 前置守卫

调用 `check_add_route_status` 确认本文件存在。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | 新建 report-handoff-template.md | `.qoder/templates/report-handoff-template.md` | N/A | — | 无 | ⬜ |
| 2 | 更新 AGENTS.md | `AGENTS.md` | N/A | — | 无 | ⬜ |
| 3 | 更新 add-paradigm SKILL.md | `.qoder/skills/add-paradigm/SKILL.md` | N/A | — | 无 | ⬜ |
| 4 | 更新 add-governance-vocabulary.md | `.qoder/vocabulary/add-governance-vocabulary.md` | N/A | — | 无 | ⬜ |
| 5 | 更新 add-route-template.md ×2 | `.qoder/templates/add-route-template*.md` | N/A | — | 无 | ⬜ |
| 6 | 更新 project_rules.md | `.qoder/rules/project_rules.md` | N/A | — | 无 | ⬜ |
| 7 | 更新 theory-practice-map.toml | `.qoder/rules/theory-practice-map.toml` | N/A | — | 无 | ⬜ |
| 8 | 更新 add-flow-guardian.md | `.qoder/agents/add-flow-guardian.md` | N/A | — | 无 | ⬜ |
| 9 | 更新 add-orchestrator.md | `.qoder/agents/add-orchestrator.md` | N/A | — | 无 | ⬜ |
| 10 | 修正 REPORT-WORKFLOW.md | `.qoder/reports/REPORT-WORKFLOW.md` | N/A | — | 无 | ⬜ |
| 11 | 修复 gateway.md | `.qoder/reports/.../gateway.md` | N/A | — | Task 1-10 | ⬜ |

### 依赖拓扑

```
Task 1 ─┐
Task 2 ─┤
Task 3 ─┤
Task 4 ─┤ 可并行
Task 5 ─┤
Task 6 ─┤
Task 7 ─┤
Task 8 ─┤
Task 9 ─┤
Task 10─┘
         │
         ▼
Task 11（依赖 report-handoff-template 就绪 + REPORT-WORKFLOW 格式修正）
```

---

## Step 3.5：实现审查

- [ ] checklist.md 全部 `[E]` 项通过（grep 验证）
- [ ] review-runtime.md 已生成（含 `[R]` gateway.md check-boundary-report）

---

## Step 4：审计数据验证

- [ ] `npx tsc --noEmit` 通过（无代码变更，预期 0 错误）
- [ ] 无阶段对称性/失败路径检查（N/A）

---

## Step 5：合规检查

- [ ] 无 ADD 代码合规项（N/A，纯文档变更）

---

## Step 6-7：定位与修复

**N/A** — 无代码异常。

---

## Step 8：收敛判断

- [ ] checklist.md 全部 `[E]` 项已 `[x]`
- [ ] tasks.md 全部 Task 子项已 `[x]`
- [ ] gateway.md `[R]` 项 check-boundary-report 通过
- [ ] 如是 runtime-fix → 进入 Step 9

---

## Step 9：Report Closure（条件性）

- [ ] 按 `report-handoff-template.md` 在 gateway.md 追 `- [x]` 标记
- [ ] `npx tsx scripts/check-boundary-report.ts` 全部已关闭

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `.qoder/templates/report-handoff-template.md` | CREATE | 1 | TEMPLATE | ⬜ |
| `AGENTS.md` | MODIFY | 2 | DOC | ⬜ |
| `.qoder/skills/add-paradigm/SKILL.md` | MODIFY | 3 | SKILL | ⬜ |
| `.qoder/vocabulary/add-governance-vocabulary.md` | MODIFY | 4 | DOC | ⬜ |
| `.qoder/templates/add-route-template.md` | MODIFY | 5 | TEMPLATE | ⬜ |
| `.qoder/templates/add-route-template-heavyweight.md` | MODIFY | 5 | TEMPLATE | ⬜ |
| `.qoder/rules/project_rules.md` | MODIFY | 6 | DOC | ⬜ |
| `.qoder/rules/theory-practice-map.toml` | MODIFY | 7 | DOC | ⬜ |
| `.qoder/agents/add-flow-guardian.md` | MODIFY | 8 | AGENT | ⬜ |
| `.qoder/agents/add-orchestrator.md` | MODIFY | 9 | AGENT | ⬜ |
| `.qoder/reports/REPORT-WORKFLOW.md` | MODIFY | 10 | DOC | ⬜ |
| `.qoder/reports/farm-agent-runtime-report/gateway.md` | MODIFY | 11 | REPORT | ⬜ |
