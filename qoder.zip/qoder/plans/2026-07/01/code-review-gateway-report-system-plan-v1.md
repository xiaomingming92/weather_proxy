# Plan: Report 文档体系搭建 + Gateway 边界报告链路纠正

> 来源: `.qoder/reports/code-review-combined-report.md` #6-#7
> 关联 handoff: [code-review-gateway-report-system-handoff-v1.md](./code-review-gateway-report-system-handoff-v1.md)
> 创建: 2026-07-01
> 版本: v1

---

## 问题

| # | 问题 | 表现 |
|---|------|------|
| 1 | Reviews 与 Reports 边界模糊 | `farm-agent-review-runtime.md` 放在 reviews/ 下，但它记录的是运行时异常而非 Plan Review |
| 2 | Gateway 报告无去重 | 同一错误盲目追加 27 次，标题全为"边界异常捕获" |
| 3 | 运行时发现 → Report Issue 链路缺失 | Gateway 发现异常后不生成 Issue 草稿，无法进入 Report triage 流程 |
| 4 | 时间戳散落 | 25+ 处 `new Date().toISOString()`，无统一管理 |
| 5 | 缺少 Report 文档体系 | 无模板、无工作流文档、无索引 |

---

## 设计

### 概念分层

```
.qoder/
├── reviews/          ← Plan Review（方案 / 实现 / 运行时 review）
├── reports/          ← Report 体系
│   ├── combined-report.md            静态代码审查
│   ├── fix-verification-report.md    修复验证对照
│   ├── farm-agent-runtime-report/    运行时报告（按子系统目录）
│   │   ├── gateway.md                Gateway 边界合约断裂
│   │   ├── rag.md                    RAG 检索异常（预留）
│   │   └── agent.md                  Agent Node 执行（预留）
│   └── runtime-issue-{id}.md        自动生成的 Issue 草稿
└── plans/            ← ADD Plan 管线
```

### 边界异常 → Report Issue 闭环

```
运行时异常
  │
  ▼
appendRuntimeFinding()
  ├─ 1. AuditLog (UTC, traceId=source_uuid)
  ├─ 2. gateway.md (reportNow, 去重, 语义化标题)
  └─ 3. runtime-issue-{date}-{seq}.md (新发现时自动生成)
        │
        ▼ (协同同事)
   人工 triage → 合并到 combined-report.md → Plan 修复 → ✅/❌
```

### 去重三层

| 层 | 位置 | 策略 |
|----|------|------|
| 内存 | `append-runtime-finding-light.ts` | 60s 窗口，source+error |
| 文件 | `appendRuntimeFinding()` | 签名 `source::path::error` |
| 输出 | `check-boundary-report.ts` | 按 source+error 分组 ×n |

### 时间分层

| 层 | 函数 | 格式 | 用途 |
|----|------|------|------|
| 存储 | `now()` | UTC | AuditLog、Prisma |
| 展示 | `reportNow()` | +08:00 | gateway.md、Issue 草稿、Console |

---

## 实施

### 文档体系（6 文件）

| 文件 | 用途 |
|------|------|
| `REPORT-WORKFLOW.md` | Report 生命周期 + 工作流 |
| `boundary-runtime-report.md` | Runtime ↔ 静态 Report 边界划分 |
| `index.md` | 自动索引（gen-report-index.sh） |
| `report-template.md` | 综合审查报告模板 |
| `fix-verification-template.md` | 修复验证对照模板 |
| `runtime-report-template.md` | 子系统运行时报告模板 |

### 代码纠正（5 文件）

| 文件 | 改动 |
|------|------|
| `append-runtime-finding.ts` | 标题语义化 + 文件去重 + Issue 草稿生成 + traceId 前缀 + 时间分层 |
| `append-runtime-finding-light.ts` | 切 `now()` |
| `proxy.ts` | hash 失败走 `appendRuntimeFinding` |
| `[hash]/route.ts` | 未知 action / JSON 解析失败走 `appendRuntimeFinding` |
| `time.ts` | 新建：`now()` + `reportNow()` |

### 运维脚本（3 文件）

| 文件 | 用途 |
|------|------|
| `gen-report-index.sh` | 每日 2:10 AM 自动生成 reports/index.md |
| `crontab.report.txt` | 独立 cron（不与 dev crontab 合并） |
| `check-boundary-report.ts` | 分组去重输出（原 check-runtime-review.ts 改名） |

---

## 验证

- [x] 边界异常 → gateway.md 语义化条目
- [x] 重复请求 → 去重生效
- [x] 新发现 → Issue 草稿自动生成
- [x] Issue 草稿含 traceId 反向引用
- [x] Report 时间 +08:00，AuditLog 时间 UTC
- [x] check-boundary-report 分组输出

---

## 关联文档

| 文档 | 路径 |
|------|------|
| Handoff | [code-review-gateway-report-system-handoff-v1.md](./code-review-gateway-report-system-handoff-v1.md) |
| 边界划分 | [boundary-runtime-report.md](../../reports/boundary-runtime-report.md) |
| Report 工作流 | [REPORT-WORKFLOW.md](../../reports/REPORT-WORKFLOW.md) |
| Report 索引 | [index.md](../../reports/index.md) |
| 源 Plan | [code-review-log-llm-refactor-plan-v2.md](../2026-06/30/code-review-log-llm-refactor-plan-v2.md) |
