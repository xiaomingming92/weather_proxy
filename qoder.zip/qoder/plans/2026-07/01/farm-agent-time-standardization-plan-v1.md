# farm-agent-time-standardization-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。不写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-time-standardization-v1
- **启动时间**: 2026-07-01T10:00:00.000+08:00
- **主导 AI**: Qoder (Claude)
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-07/01/farm-agent-time-standardization-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-07/01/farm-agent-time-standardization-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-time-standardization-review-v1.md`
  - Spec: `.qoder/specs/farm-agent-time-standardization/spec.md`
  - Tasks: `.qoder/specs/farm-agent-time-standardization/tasks.md`
  - Checklist: `.qoder/specs/farm-agent-time-standardization/checklist.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/lib/time.ts | LIB | LIB_MODIFIED | 仅 now() / reportNow() | 新增 nowDate() / fromUTC() / fromUTCToDate() / toLocalISO() | 待实施 |
| src/lib/log/audit.ts | LOGGER | LOGGER_MODIFIED | formatMessage 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/audit-logger.ts | LOGGER | LOGGER_MODIFIED | formatMessage 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/chat-persistence-logger.ts | LOGGER | LOGGER_MODIFIED | formatMessage 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/chat-stats-logger.ts | LOGGER | LOGGER_MODIFIED | formatMessage 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/stream-chat-logger.ts | LOGGER | LOGGER_MODIFIED | formatMessage 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/stream-bus-logger.ts | LOGGER | LOGGER_MODIFIED | formatMessage 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/model-config-logger.ts | LOGGER | LOGGER_MODIFIED | formatMessage 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/agent-gateway-dev-logger.ts | LOGGER | LOGGER_MODIFIED | formatMessage 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/agent-gateway-audit.ts | LOGGER | LOGGER_MODIFIED | formatMessage 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/farm-server-client.ts | CLIENT | CLIENT_MODIFIED | fsClientAudit 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/credential/service-token.ts | AUTH | AUTH_MODIFIED | audit 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/auth/token-manager.ts | AUTH | AUTH_MODIFIED | tokenManagerAudit 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/auth/credential-store.ts | AUTH | AUTH_MODIFIED | credentialAudit 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/hash-path.ts | LIB | LIB_MODIFIED | hashPathAudit 裸 new Date().toISOString() x3 | import { now } from "@/lib/time" | 待实施 |
| src/services/knowledge-sync.ts | SERVICE | SERVICE_MODIFIED | metadata.lastSync 等 8处裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/services/knowledge-indexer.ts | SERVICE | SERVICE_MODIFIED | lastSyncedAt/vectorizedAt 等 4处裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/services/analysis-context.ts | SERVICE | SERVICE_MODIFIED | updatedAt/activatedAt 等 6处裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/services/report-generator.ts | SERVICE | SERVICE_MODIFIED | 报告时间戳 8处裸 new Date().toISOString() | import { reportNow } from "@/lib/time" | 待实施 |
| src/services/reasoning-engine.ts | SERVICE | SERVICE_MODIFIED | step timestamp 4处裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/services/retrieval-stats.ts | SERVICE | SERVICE_MODIFIED | cachedAt 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/services/cache-ttl-stats.ts | SERVICE | SERVICE_MODIFIED | lastAdjustedAt/updatedAt 2处裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/services/audit-log.ts | SERVICE | SERVICE_MODIFIED | createdAt 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/services/chat-persistence.ts | SERVICE | SERVICE_MODIFIED | deletedAt: new Date() | import { nowDate } from "@/lib/time" | 待实施 |
| src/types/evidence.ts | TYPE | TYPE_MODIFIED | createEmptyEvidenceChain 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/lib/log/notify/channels/wecom.ts | NOTIFY | NOTIFY_MODIFIED | 通知时间裸 new Date().toISOString() | import { reportNow } from "@/lib/time" | 待实施 |
| src/agents/nodes/reasoning.ts | AGENT | AGENT_MODIFIED | step timestamp 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/agents/nodes/retrieval.ts | AGENT | AGENT_MODIFIED | step timestamp 5处裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/agents/nodes/aggregation.ts | AGENT | AGENT_MODIFIED | step timestamp 2处裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/agents/nodes/intention.ts | AGENT | AGENT_MODIFIED | updatedAt 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/agents/tools/impl/index-documents.ts | AGENT | AGENT_MODIFIED | uploadedAt 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/stores/chat-store.ts | STORE | STORE_MODIFIED | 6处裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/stores/task-store.ts | STORE | STORE_MODIFIED | 2处裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/stores/project-store.ts | STORE | STORE_MODIFIED | 2处裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/components/chat/chat-panel.tsx | UI | UI_MODIFIED | message timestamp 4处裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/components/chat/chat-message.tsx | UI | UI_MODIFIED | toLocaleTimeString 展示 2处 | import { fromUTC } from "@/lib/time" | 待实施 |
| src/components/knowledge/knowledge-base-panel.tsx | UI | UI_MODIFIED | toLocaleDateString 展示 | import { fromUTC } from "@/lib/time" | 待实施 |
| src/components/document/document-list.tsx | UI | UI_MODIFIED | toLocaleDateString 展示 | import { fromUTC } from "@/lib/time" | 待实施 |
| src/app/api/project/route.ts + [id]/route.ts | ROUTE | ROUTE_MODIFIED | createdAt/updatedAt 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/app/api/task/route.ts + [id]/route.ts + [id]/status/route.ts | ROUTE | ROUTE_MODIFIED | createdAt/updatedAt 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/app/api/document/route.ts | ROUTE | ROUTE_MODIFIED | createdAt/updatedAt 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/app/api/knowledge/upload/route.ts | ROUTE | ROUTE_MODIFIED | classifiedAt 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/app/api/knowledge/documents/[id]/progress/route.ts | ROUTE | ROUTE_MODIFIED | console.error 内 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/app/api/agent/[hash]/route.ts | ROUTE | ROUTE_MODIFIED | completedAt 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/app/api/agent/chat/route.ts | ROUTE | ROUTE_MODIFIED | completedAt 裸 new Date().toISOString() | import { now } from "@/lib/time" | 待实施 |
| src/app/api/agent/chat/stream/route.ts | ROUTE | ROUTE_MODIFIED | completedAt/timestamp 裸 new Date().toISOString() x3 | import { now } from "@/lib/time" | 待实施 |
| src/app/api/h5/nongqing/prescriptions/[id]/route.ts | ROUTE | ROUTE_MODIFIED | abandonedAt: new Date().toISOString() + completedAt: new Date() | import { now, nowDate } from "@/lib/time" | 待实施 |
| src/app/api/h5/nongqing/tasks/[id]/route.ts | ROUTE | ROUTE_MODIFIED | abandonedAt: new Date().toISOString() + completedAt: new Date() | import { now, nowDate } from "@/lib/time" | 待实施 |
| src/app/api/h5/nongqing/daily-report/route.ts | ROUTE | ROUTE_MODIFIED | reportDate: new Date().toLocaleDateString() | import { reportNow } from "@/lib/time" | 待实施 |
| src/app/api/h5/production-plan/plans/[id]/route.ts | ROUTE | ROUTE_MODIFIED | completedAt: new Date() | import { nowDate } from "@/lib/time" | 待实施 |
| src/app/api/admin/service-accounts/route.ts | ROUTE | ROUTE_MODIFIED | keyRotatedAt: new Date() | import { nowDate } from "@/lib/time" | 待实施 |
| src/app/api/seed-catalog/price/route.ts | ROUTE | ROUTE_MODIFIED | effectiveDate fallback: new Date() | import { nowDate } from "@/lib/time" | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

`src/lib/time.ts` 已定义统一时间函数：
- `now()` → UTC ISO 8601，用于 DB/日志/系统间通信
- `reportNow()` → 本地时区（+8），用于 Report 文档、人类可读输出

但全局扫描发现 **70+ 处**绕过该模块直接调用 `new Date().toISOString()` 或 `new Date()`，导致：

1. **DB 写入时间不规范**：Service 层 JSON metadata 中的 `lastSync`、`classifiedAt`、`excludedAt` 等字段使用裸 `new Date().toISOString()`，虽然语义上是 UTC（`.toISOString()` 始终返回 UTC），但失去了统一管理入口——如需全局调整时区策略，无法通过一处修改生效。

2. **日志/审计时间不规范**：9 个 logger 文件的 `formatMessage` 函数各自裸写 `new Date().toISOString()`，重复代码且失去统一控制点。

3. **Report 生成时间不规范**：`report-generator.ts` 面向人类读者的报告仍使用 UTC 时间戳（`new Date().toISOString()`），显示为 UTC 时间而非北京时间，不符合中国用户习惯。

4. **DB→前端时间转换缺失**：DB 存储 UTC 时间，API 直接透传，前端 Store 拿到后直接显示（如 `chat-store.ts` 的 `createdAt`/`updatedAt`），没有 UTC→本地时区的转换层。用户看到的聊天记录时间是 UTC 而非北京时间。

### 1.2 目标

- **P0**：所有日志/审计/DB metadata JSON 时间统一使用 `now()`（UTC）
- **P0**：所有 Report/通知 等人类可读输出统一使用 `reportNow()`（本地+8）
- **P1**：扩展 `src/lib/time.ts`，新增 UTC→本地时区转换工具函数
- **P1**：前端 Store 读取 DB 时间后做时区转换
- **验证**：`grep -rn "new Date()" src/ | grep -v time.ts | grep -v "Date.now()" | grep -v test` 返回 0（排除合理场景）

---

## 二、方案选型

### 2.1 候选方案对比

| 方案 | 侵入性 | 可控性 | 可逆性 | 结论 |
|------|-------|-------|-------|------|
| A: 逐文件替换 `new Date().toISOString()` → `now()` / `reportNow()` | 低（纯 import 替换） | 高（每处显式选择） | 高（git revert） | ✅ 采用 |
| B: ESLint 规则强制禁止裸 `new Date().toISOString()` | 中（需配置规则） | 高（自动化检查） | 高 | 补充手段，非主方案 |
| C: 全局 monkey-patch `Date.prototype.toISOString` | 高（影响所有依赖） | 低（不可控副作用） | 低（难以回滚） | ❌ 不采用 |

### 2.2 选型理由

选 **A**：纯 import 替换，每处显式选择 `now()` 还是 `reportNow()`，语义清晰，可控性强。后续可搭配 ESLint 规则（方案 B）做持续约束。

**合理豁免场景**（不替换）：
- `Date.now()` — 性能计时，不是时间戳生成
- `new Date(expiresTime)` — 解析外部时间字符串（非时间生成）
- `new Date(timestamp).getTime()` — 数学运算/比较
- `new Date(base).setDate(...)` — 日期计算（如 time-tools.ts）
- `new Date(year, month, day)` — Date 构造（如 formulas.ts）
- 测试 mock 数据中的 `new Date().toISOString()`

**全部替换场景**（零豁免）：
- `new Date().toISOString()` → `now()` 或 `reportNow()`
- `new Date()` 用于 Prisma DateTime 字段 → `nowDate()`

---

## 三、架构设计

### 3.1 时间函数分层

```
┌─────────────────────────────────────────────┐
│            src/lib/time.ts                   │
│  now()         → UTC ISO 8601 string         │
│  nowDate()     → UTC Date 对象 (新增)         │
│  reportNow()   → 本地+8 ISO 8601             │
│  fromUTC()     → UTC→本地 格式化 (新增)       │
│  toLocalISO()  → UTC ISO→本地 ISO (新增)      │
│  fromUTCToDate() → UTC→本地 Date (新增)       │
└──────────────┬──────────────────────────────┘
               │
    ┌──────────┼──────────┐
    ▼          ▼          ▼
  日志/审计   DB写入     Report/UI
  (now())   (now() +     (reportNow())
             nowDate())    (fromUTC)
```

### 3.2 分类替换矩阵

| 原代码 | 场景 | 替换为 | 原因 |
|--------|------|--------|------|
| `formatMessage` 中 `new Date().toISOString()` | 日志/审计文件 | `now()` | 系统级，UTC 便于跨时区排查 |
| Service metadata JSON 中 `new Date().toISOString()` | DB JSON 字段 | `now()` | 存储层统一 UTC |
| Prisma DateTime 字段 `new Date()` | DB 表列 | `nowDate()` | 与 now() 同源，统一入口 |
| 报告文件 `new Date().toISOString()` | Report 文档 | `reportNow()` | 面向中国用户，北京时间 |
| `wecom.ts` `new Date().toISOString().replace(...)` | 通知消息 | `reportNow()` | 人类可读 |
| `new Date().toLocaleDateString("zh-CN")` | 日报日期展示 | `reportNow()` | 人类可读 |
| 前端 Store `new Date().toISOString()` | 内存状态 | `now()` | 保持 UTC，展示层再转 |
| `new Date(dbTime).toLocaleXxx()` | DB→UI 展示 | `fromUTC()` | UTC→本地时区转换 |

---

## 四、实施步骤 + 依赖图

```
Task 1 (time.ts 扩展) ──┐
                         │ 可并行
Task 2 (日志层)  ────────┤
Task 3 (Service层) ─────┤
Task 4 (Report层)  ─────┤
Task 5 (Agent节点) ─────┤
                         │
                         ▼
Task 6 (API Route层) ────┤
Task 7 (前端Store)  ─────┘
                         │
                         ▼
Task 8 (DB→前端转换) ────┐
                         │
                         ▼
Task 9 (验证 & 清理) ────┘
```

### Task 1: 时间工具函数扩展

**范围**：仅 `src/lib/time.ts`

1. 新增 `nowDate(): Date` — 返回当前 UTC Date 对象，供 Prisma DateTime 字段使用
2. 新增 `fromUTC(utcString: string): string` — UTC ISO → 本地时区格式化字符串
3. 新增 `fromUTCToDate(utcString: string): Date` — UTC ISO → 本地 Date 对象
4. 新增 `toLocalISO(utcString: string): string` — UTC ISO → 本地 ISO（带 +08:00）
5. 添加单元测试

### Task 2: 日志/审计层整改（~15 文件）

**范围**：所有 `formatMessage` 函数

替换清单：
- `src/lib/log/audit.ts`
- `src/lib/audit-logger.ts`
- `src/lib/chat-persistence-logger.ts`
- `src/lib/chat-stats-logger.ts`
- `src/lib/stream-chat-logger.ts`
- `src/lib/stream-bus-logger.ts`
- `src/lib/model-config-logger.ts`
- `src/lib/agent-gateway-dev-logger.ts`
- `src/lib/agent-gateway-audit.ts`
- `src/lib/farm-server-client.ts`
- `src/lib/credential/service-token.ts`
- `src/lib/auth/token-manager.ts`
- `src/lib/auth/credential-store.ts`
- `src/lib/hash-path.ts`（x3）
- `src/lib/append-runtime-finding.ts`（already uses `now()`/`reportNow()` ✅，无需改）

### Task 3: Service 层 DB 写入整改（~7 文件）

替换清单：
- `src/services/knowledge-sync.ts` — 8 处 JSON metadata `new Date().toISOString()`
- `src/services/knowledge-indexer.ts` — 4 处 JSON metadata `new Date().toISOString()`
- `src/services/analysis-context.ts` — 6 处 JSON metadata `new Date().toISOString()`
- `src/services/audit-log.ts` — 1 处 JSON metadata `new Date().toISOString()`
- `src/services/retrieval-stats.ts` — 1 处 JSON metadata `new Date().toISOString()`
- `src/services/cache-ttl-stats.ts` — 2 处 JSON metadata `new Date().toISOString()`
- `src/services/chat-persistence.ts` — L251 `deletedAt: new Date()` → `nowDate()`

### Task 4: Report / 通知 / 人读场景整改（~4 文件）

替换清单：
- `src/services/report-generator.ts` — 8 处报告时间戳 → `reportNow()`
- `src/lib/log/notify/channels/wecom.ts` — 通知时间 → `reportNow()`
- `src/app/api/h5/nongqing/daily-report/route.ts` — L125 `toLocaleDateString("zh-CN")` → `reportNow()`
- `src/services/reasoning-engine.ts` — 4 处 step timestamp → `now()`

### Task 5: Agent 节点时间整改（~5 文件）

替换清单：
- `src/agents/nodes/reasoning.ts` — 1 处 `new Date().toISOString()`
- `src/agents/nodes/retrieval.ts` — 5 处 `new Date().toISOString()`
- `src/agents/nodes/aggregation.ts` — 2 处 `new Date().toISOString()`
- `src/agents/nodes/intention.ts` — L25 `new Date().toISOString()`
- `src/agents/tools/impl/index-documents.ts` — L20 `new Date().toISOString()`

### Task 6: API Route 层整改（~13 文件）

`new Date().toISOString()` → `now()`:
- `src/app/api/agent/[hash]/route.ts`
- `src/app/api/agent/chat/route.ts`
- `src/app/api/agent/chat/stream/route.ts`（x3）
- `src/app/api/project/route.ts` + `[id]/route.ts`
- `src/app/api/task/route.ts` + `[id]/route.ts` + `[id]/status/route.ts`
- `src/app/api/document/route.ts`
- `src/app/api/knowledge/upload/route.ts`
- `src/app/api/knowledge/documents/[id]/progress/route.ts`（console.error 内）
- `src/app/api/h5/nongqing/prescriptions/[id]/route.ts` — L131 `abandonedAt`
- `src/app/api/h5/nongqing/tasks/[id]/route.ts` — L173 `abandonedAt`

`new Date()` → `nowDate()`（Prisma DateTime）:
- `src/app/api/h5/nongqing/prescriptions/[id]/route.ts` — L170 `completedAt`
- `src/app/api/h5/nongqing/tasks/[id]/route.ts` — L222 `completedAt`
- `src/app/api/h5/production-plan/plans/[id]/route.ts` — L122 `completedAt`
- `src/app/api/admin/service-accounts/route.ts` — L106 `keyRotatedAt`
- `src/app/api/seed-catalog/price/route.ts` — L43 effectiveDate fallback

### Task 7: 前端 Store 时间整改（~3 文件）

替换清单：
- `src/stores/chat-store.ts` — 6 处
- `src/stores/task-store.ts` — 2 处
- `src/stores/project-store.ts` — 2 处
- `src/components/chat/chat-panel.tsx` — 4 处

**注意**：前端 Store 使用 `now()` 保持 UTC（纯 JS 环境兼容），不做时区转换。

### Task 8: DB→前端时区转换边界层

**范围**：`src/stores/chat-store.ts` + `src/lib/time.ts` + 4 个 UI 组件

1. 在 `chat-store.ts` 的 `rehydrateFromServer` / `loadThreadMessages` 中，对从 API 获取的 `createdAt`/`updatedAt` 调用 `fromUTC()` 转换为本地时间后再存入 Store
2. 在 `chat-store.ts` Thread/Message 类型中增加 `displayCreatedAt` / `displayUpdatedAt` 字段用于 UI 展示
3. UI 组件接入 `fromUTC()`:
   - `src/components/chat/chat-message.tsx` — L55,87 `new Date(timestamp).toLocaleTimeString()` → `fromUTC(timestamp)`
   - `src/components/knowledge/knowledge-base-panel.tsx` — L472 `new Date(doc.uploadedAt).toLocaleDateString()` → `fromUTC(doc.uploadedAt)`
   - `src/components/document/document-list.tsx` — L146 `new Date(doc.createdAt).toLocaleDateString()` → `fromUTC(doc.createdAt)`

### Task 9: 验证 & 清理

1. `npm run build` 编译通过
2. `grep -rn "new Date()\.toISOString\(\)" src/ --include="*.ts" --include="*.tsx" | grep -v time.ts | grep -v ".test."` 确认仅剩合理豁免
3. 运行现有测试确认无回归
4. 更新 `index.md` Plan 索引

---

## 五、验收标准

- [ ] `src/lib/time.ts` 新增 `nowDate()` / `fromUTC()` / `toLocalISO()` / `fromUTCToDate()` 四个工具函数
- [ ] 所有 Logger `formatMessage` 已替换为 `now()`
- [ ] 所有 Service metadata JSON 时间戳已替换为 `now()`
- [ ] 所有 Report 时间戳已替换为 `reportNow()`
- [ ] 前端 Store 时间戳已替换为 `now()`
- [ ] DB→前端时区转换边界层已接入
- [ ] `grep -rn 'new Date().toISOString()' src/ | grep -v time.ts | grep -v test` 返回 0（仅剩豁免场景）
- [ ] `grep -rn 'new Date()' src/ --include="*.ts" --include="*.tsx" | grep -v time.ts | grep -v Date.now | grep -v test` 仅剩时间计算/解析等豁免场景
- [ ] `npm run build` 通过
- [ ] 无回归

---

## 七、Review 回流记录（0.6.5 卡位）

| Review 问题 | 回流位置 | 状态 |
|:--|:--|:--:|
| P0#1: Plan 初始遗漏 9 个文件 | Plan §一 ADD-7 表格已补全 13 行 | ✅ 已回流 |
| P0#2: Prisma DateTime `new Date()` 误判豁免 | Plan §2.2 豁免清单已移除该条；§3.1 新增 `nowDate()`；§3.2 新增对应行 | ✅ 已回流 |
| P1#3: 前端 `fromUTC()` 依赖顺序 | Plan §4 依赖图 Task 7+8 标注依赖 Task 1 | ✅ 已回流 |
| P1#4: DPS 不足 → Specs Requirements 补全 | Specs 从 2 个 Requirement 扩展至 9 个 | ✅ 已回流 |
| P2#5: ESLint 后续约束 | Plan §2.2 备注"后续单独 Plan" | ✅ 已知不处理 |

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-07/01/farm-agent-time-standardization-add-route-v1.md` |
| Handoff | `.qoder/plans/2026-07/01/farm-agent-time-standardization-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-time-standardization-review-v1.md` |
| Spec | `.qoder/specs/farm-agent-time-standardization/spec.md` |
| Tasks | `.qoder/specs/farm-agent-time-standardization/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-time-standardization/checklist.md` |
