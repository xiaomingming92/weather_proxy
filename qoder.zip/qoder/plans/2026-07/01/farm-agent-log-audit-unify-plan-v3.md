# farm-agent-log-audit-unify-plan-v3

> 来源: `.qoder/reports/code-review-combined-report.md` #6-#9
> 原名: code-review-log-llm-refactor-plan (v1, v2)
> 创建: 2026-06-30 (v1) → 2026-07-01 (v2) → 2026-07-01 (v3)
> 版本: v3
> v3 修订: 
> - Atom 2 从"合并两个 agent 文件"重构为"通用 Gateway 审计纯函数 + h5 全量接入"
> - Atom 3 从"内存→DB 迁移"改为"删除 audit-log.ts 死代码"
> - Atom 1 新增 userId 注入 + 适配 utcNow() 基线
> - 修正"神经元已覆盖 gateway 审计"的误判
> - 按 report 体系规范修正 Plan 命名

## PLAN 元信息

- **Plan 名称**: farm-agent-log-audit-unify-v3
- **启动时间**: 2026-07-01T14:00:00.000Z
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-07/01/farm-agent-log-audit-unify-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-07/01/farm-agent-log-audit-unify-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-log-audit-unify-review-v1.md`
  - Specs: `.qoder/specs/farm-agent-log-audit-unify/`
- **ADD-7 审计策略**: (待 Step 1 填充)

---

## 问题摘要

| # | 问题 | 严重度 | 涉及文件 |
|---|------|--------|---------|
| 6 | 7 个 logger + `audit.ts` 共 8 个文件共享相同 `ensureLogDir/writeToFile/formatMessage` 代码模式 | P1 | 8 文件 |
| 7 | `agent-gateway-dev-logger.ts` (仅 IS_DEV) 与 `agent-gateway-audit.ts` (始终运行) 行为/类型不一致，且 gateway 审计仅覆盖 `agent/[hash]`，h5 全家桶完全缺失 | P1 | 2 + 13 files |
| 8 | `audit-log.ts` 内存存储死代码：`createAuditLog()` 无内部调用方，`getAuditLogsByTarget()` 无调用方，与 `writeAuditLog()` DB 方案重复 | P2 | 1 文件 |
| 9 | `agents/index.ts` 职责过大 (563 行) | P1 | 1 文件 |

> Issue #10 (LLM 单例全局可变状态问题) 已独立为[单独 Plan](../2026-06-30/code-review-llm-state-isolation-plan-v1.md)

### 前提背景（影响 Plan 的已落地基线）

1. **时间规范化**（commit `3d811e8`）：所有 `new Date().toISOString()` → `utcNow()`（import from `@/lib/time`），Plan 中所有代码示例须使用 `utcNow()`
2. **审计绕过治理**（`audit-log-bypass-governance-plan-v1`，已实施）：`writeAuditLog()` 已是唯一 DB 写入入口，`getLogUserId()` 统一 userId，ESLint 禁止 `prisma.auditLog.*` 直调和 `userId` 硬编码
3. **Gateway 审计覆盖率现状**：
   - ✅ `agent/[hash]`（神经元 web app）— 已有完整 gateway 审计
   - ❌ `h5/*`（13 条路由）— 只有 `agentAudit()` 领域日志，无请求级 gateway 审计
   - ❌ `knowledge/model/project/task/admin` 等管理类路由 — 无审计

---

## 当前代码基线分析

### Atom 1 相关：重复模式清单

**模式 A — 静态 fs import (5 个文件，纯服务端)**:

```
                  ensureLogDir()  writeToFile()  formatMessage()  readLogs()  clearLogs()  PhaseStart/End
audit-logger.ts       ✅              ✅              ✅             ✅          ✅           ✅
chat-persistence-logger.ts ✅        ✅              ✅             ✅          ✅           ✅
stream-bus-logger.ts  ✅              ✅              ✅             ✅          ✅           ✅
stream-chat-logger.ts ✅              ✅              ✅             ✅          ✅           ✅
agent-gateway-dev-logger.ts ✅      ✅              ✅             ✅          ✅           ✅
```

**模式 B — 动态 import("fs/promises") (2 个文件，Next.js 同构兼容)**:

```
                  ensureLogDir()  writeToFile()  formatMessage()  readLogs()  clearLogs()  PhaseStart/End
chat-stats-logger.ts  ✅              ✅              ✅             ✅          ✅           ✅
model-config-logger.ts ✅             ✅              ✅             ✅          ✅           ✅
```

**模式 C — `src/lib/log/audit.ts` (384 行)**: 内联了 `ensureLogDir/writeToFile/formatMessage`，同时包含 `writeAuditLog` DB 审计逻辑。

**已统一的时间戳**: 全部 8 个文件 + `audit.ts` 的 `formatMessage()` 已使用 `utcNow()`（commit `3d811e8`）。用户身份在 file 日志层缺失（只有 DB 层通过 `getLogUserId()` 统一），`LogFileWriter` 应追加 userId 字段。

### Atom 2 相关：Gateway 审计现状与缺口

#### 已覆盖：`agent/[hash]/route.ts`

| 文件 | 行数 | 触发条件 | 输出通道 |
|------|------|---------|---------|
| `agent-gateway-dev-logger.ts` | 91 | `NODE_ENV === "development"` | console + file |
| `agent-gateway-audit.ts` | 68 | 始终运行 | console + AuditLog DB |

两份代码互为补集：dev-logger 出 console+file（IS_DEV guard），audit 出 console+DB（始终运行）。调用方 `agent/[hash]/route.ts` 同时 import 两个文件。

`agent-gateway-audit.ts` 的实质是 `writeAuditLog()` 的薄包装——加一行 console + 格式化 message。`writeAuditLog()` 已经是统一 DB 入口（含 `getLogUserId()`、traceId 兜底、失败告警）。

#### 未覆盖：h5 全家桶（13 条路由）

```
src/app/api/h5/
├── agent/route.ts                          ❌ 只有 agentAudit()
├── agent/[threadId]/resume/route.ts        ❌
├── nongqing/daily-report/route.ts          ❌ 只有 agentAudit()
├── nongqing/overview/route.ts              ❌
├── nongqing/prescriptions/route.ts         ❌
├── nongqing/prescriptions/[id]/route.ts    ❌
├── nongqing/tasks/route.ts                 ❌
├── nongqing/tasks/[id]/route.ts            ❌
├── production-plan/cost-accounting/route.ts ❌
├── production-plan/generate/route.ts       ❌
├── production-plan/land-analysis/route.ts  ❌
├── production-plan/plans/[id]/route.ts     ❌
├── production-plan/variety-recommend/route.ts ❌
├── upload/image/route.ts                   ❌
└── docs/route.ts + docs/[doc]/route.ts     ❌
```

所有 h5 路由都 import 了 `resolveH5AuthGateway` 做认证，但**没有一条**调用了 gateway 层审计。出现问题时无法回答"谁、何时、请求了什么、耗时多少、成功/失败"。

### Atom 3 相关：audit-log.ts 死代码

- `createAuditLog()`: **无内部调用方**，仅通过 `src/services/index.ts` 对外导出（无前端调用）
- `getAuditLogs()`: 仅被 `src/app/api/audit/route.ts` 调用
- `getAuditLogsByTarget()`: 导出但无调用方
- 内存数组 `auditLogs[]`：进程重启数据丢失
- `AuditLogEntry` 类型有 `ip`, `userAgent` 字段 → Prisma `AuditLog` 模型没有这两个字段
- `AuditAction` 类型（CREATE/UPDATE/DELETE/...）与 `writeAuditLog` 使用的 phase 字符串体系完全不同
- `writeAuditLog()` 已经完整覆盖 DB 写入，`audit-log.ts` 是冗余的遗留系统

### Atom 4 相关：agents/index.ts 精确行号

| 代码段 | 行号 | 目标文件 |
|--------|------|---------|
| `createToolNodeWrapper` 函数 | L34-L187 | `tool-node-wrapper.ts` |
| `workflow` (StateGraph deep 图) | L189-L242 | `agent-graph.ts`（原 v2 `graph.ts`） |
| `professionalWorkflow` (StateGraph professional 图) | L245-L300 | `agent-graph.ts`（原 v2 `graph.ts`） |
| `setAgentTools(agentTools)` 调用 | L31 | `agent-graph.ts` |
| `activeTracers` Map + `tracerCreateTimes` Map + `cleanupExpiredTracers` | L302-L323 | `tracer-store.ts` |
| `wrapNodeWithAudit` 函数 | L325-L411 | `audit-wrapper.ts` |
| `getActiveTracer` + `startChainTrace` + `endChainTrace` | L413-L435 | `tracer.ts` |
| `runAgent` 函数 | L437-L468 | `agent-runner.ts` |
| `StreamAgentInput` 接口 | L470-L483 | `agent-runner.ts` |
| `streamAgent` 函数 | L485-L542 | `agent-runner.ts` |
| `buildPartialState` 函数 | L544-L561 | `agent-runner.ts` |

Agent nodes（`aggregation.ts`, `intention.ts`, `reasoning.ts`, `retrieval.ts`）中的 `timestamp` 字段已使用 `utcNow()`，拆分后无需额外改动。

---

## 原子事务拆分

### Atom 1: 提取公共日志基础设施 (`LogFileWriter`)

**目标**: 消除 8 个文件中的 `ensureLogDir()` + `writeToFile()` + `formatMessage()` 重复代码，并统一注入 userId

#### 1a. 核心类设计

```
src/lib/log/file-writer.ts

interface LogFileWriterOptions {
  prefix: LogPrefix            // 枚举: AGENT_AUDIT / KB_AUDIT / CHAT_PERSIST / ...
  logDir: string               // 日志目录
  logFile: string              // 日志文件名（不含日期后缀）
  enableFileLog: boolean       // 是否启用文件日志
  rotation?: {                 // 日志轮转策略
    type: "daily"              // 按天轮转（当前唯一策略）
    maxDays?: number           // 保留最近 N 天，默认 7
    maxSizeMB?: number         // 单文件最大 MB，默认 50，超过递增 index
  }
  format?: "plain" | "jsonl"  // 文件输出格式，默认 "jsonl"
}

interface LogEntry {
  ts: string                     // utcNow()
  prefix: string
  phase: string
  detail: string
  userId?: string                // 来自 getLogUserId()
  extra?: Record<string, unknown>
}

class LogFileWriter {
  constructor(options: LogFileWriterOptions)
  ensureLogDir(): Promise<void>
  writeToFile(message: string): Promise<void>      // plain 模式
  writeJSONLEntry(entry: LogEntry): Promise<void>  // JSONL 模式
  formatMessage(phase: string, detail: string, extra?: Record<string, unknown>): string
  toJSONLEntry(phase: string, detail: string, extra?: Record<string, unknown>): LogEntry
  rotate(): Promise<void>          // 每次 write 前自动调用
  cleanup(): Promise<void>         // 清理过期文件
  // 便捷方法（console + file 双写）
  log(phase: string, detail: string, extra?: Record<string, unknown>): void
  logPhaseStart(phase: string, description: string, count?: number): void
  logPhaseEnd(phase: string, detail: string): void
  readLogs(lines?: number): Promise<string[]>
  clearLogs(): Promise<void>
  getLogPath(): Promise<string>
}
```

**userId 注入策略**:
- `writeJSONLEntry()` / `formatMessage()` 调用时自动调用 `getLogUserId()`，追加到 JSONL 的 `userId` 字段
- `getLogUserId()` 内部有缓存（`let logUserId: string | null`），多次调用不产生额外 DB 查询
- 对已有 8 个 logger 完全透明——它们不需要感知 userId，`LogFileWriter` 内部处理

#### 1b. 同构兼容方案

针对 `chat-stats-logger.ts` 和 `model-config-logger.ts`，提供 **`LazyLogFileWriter`** 子类：
- 重写 `ensureLogDir/writeToFile`，使用 `await import("fs/promises")` + `webpackIgnore: true`
- 增加 `isServer = typeof window === "undefined"` 守卫
- 纯服务端 → `new LogFileWriter({...})`；同构 → `new LazyLogFileWriter({...})`

#### 1c. 迁移清单

| 文件 | 迁移方式 | 保留内容 |
|------|---------|---------|
| `src/lib/audit-logger.ts` | 创建 `LogFileWriter` 实例，替换内联函数 | 所有 `audit*` 公共函数、`AuditPhase` 类型 |
| `src/lib/chat-persistence-logger.ts` | 同上 | `chatPersistAudit*` 函数、`ChatPersistencePhase` |
| `src/lib/stream-bus-logger.ts` | 同上 | `streamBusAudit*` 函数、DB 双写逻辑、`StreamBusAuditPhase` |
| `src/lib/stream-chat-logger.ts` | 同上 | `streamChatAudit*` 函数、`StreamChatAuditPhase` |
| `src/lib/agent-gateway-dev-logger.ts` | 同上（但 Atom 2 会删除此文件） | `agentGatewayAudit*` 函数（临时保留至 Atom 2） |
| `src/lib/chat-stats-logger.ts` | 创建 `LazyLogFileWriter` 实例 | `chatStatsAudit*` 函数、`ChatStatsAuditPhase` |
| `src/lib/model-config-logger.ts` | 创建 `LazyLogFileWriter` 实例 | `modelConfigAudit*` 函数、`ModelConfigAuditPhase` |
| `src/lib/log/audit.ts` | 创建 `LogFileWriter` 实例，替换 L107-146 | 所有 `agentAudit*` 函数、`writeAuditLog`、失败计数器 |

**验证**:
- 所有 8 个模块编译通过
- JSONL 文件每行包含 `userId` 字段（`JSON.parse` 成功）
- Console 输出保持人类可读格式（`[PREFIX] [ts] [phase] desc`）
- 同构模块在浏览器端不报错

---

### Atom 2: 通用 Gateway 审计纯函数 + h5 全量接入

**目标**: 用单一纯函数替代两个 agent 专属文件，并推广到所有 h5 路由

**核心洞察**: `agent-gateway-audit.ts` 的本质是对 `writeAuditLog()` + `console.log()` 的组合包装。不需要 per-route 的 wrapper 类——一个纯函数 `auditGatewayRequest()` 即可服务所有路由。

**边界约束**（来自 `farm-agent-review-and-evidence-hardening-plan-v1`）:
- Gateway **成功**路径 → 本 Atom 负责：console + `writeAuditLog()` 记录请求元数据
- Gateway **报错**路径 → hardening plan 负责：`appendRuntimeFinding`（instrumentation.ts 全局边界捕获 + route 内手动调用），本 Atom 不替代、不集成

**为什么 Gateway 不管 Agent 内部业务**（与 Atom 1/4 的分层边界）:

```
┌─ Gateway 审计（本 Atom）────────────────────────────┐
│ 层：HTTP 基础设施                                    │
│ 问题：谁、何时、调了哪个 action、耗时多少、成功/失败    │
│ 粒度：1 请求 = 1 条 AuditLog                         │
│ 不感知：意图识别、检索结果、LLM 调用次数、节点拓扑       │
├─────────────────────────────────────────────────────┤
│                                                     │
│  ┌─ Agent 业务审计（Atom 1 LogFileWriter + audit.ts）─┤
│  │ 层：Agent 管线领域逻辑                              │
│  │ 问题：意图走了哪条分支、检索召回了什么、               │
│  │       LLM 调了几次 token、裁决结果是什么             │
│  │ 粒度：1 请求 = N 条 AuditLog + N 行 file 日志        │
│  │ 不感知：HTTP method、hash 校验、token 过期            │
│  └──────────────────────────────────────────────────┤
│                                                     │
└─────────────────────────────────────────────────────┘
```

两者唯一的交集是 `writeAuditLog()`——它只管"往 DB 写一行"，不关心调用方是 gateway 还是 agent。`source` 字段（`GATEWAY_AGENT` / `GATEWAY_H5` / `AGENT_AUDIT`）在 DB 层区分来源。

#### 2a. 新文件：`src/lib/log/gateway-audit.ts`

```typescript
import { writeAuditLog } from "@/lib/log"
import { utcNow } from "@/lib/time"

type GatewayPhase = "GATEWAY_REQUEST" | "GATEWAY_ERROR"

interface GatewayAuditOptions {
  phase: GatewayPhase
  source: "agent" | "h5"           // 区分来源
  action: string                    // e.g. "dashboard", "thread_query", "land_analysis"
  entityId: string
  detail?: Record<string, unknown>
  durationMs?: number
}

// 纯函数：console 人类可读 + DB 写入（成功路径审计）
// 注意：报错路径的 appendRuntimeFinding 由 instrumentation.ts 边界捕获处理，不在本函数内
export async function auditGatewayRequest(opts: GatewayAuditOptions): Promise<void> {
  const ts = utcNow()
  const msg = `[GATEWAY-${opts.source.toUpperCase()}] [${ts}] [${opts.phase}] ${opts.action} entity=${opts.entityId}`
  console.log(msg)

  void writeAuditLog(
    opts.phase,
    `GATEWAY_${opts.source.toUpperCase()}`,
    opts.entityId,
    { action: opts.action, ...opts.detail, durationMs: opts.durationMs },
    `${opts.phase}: ${opts.action} on ${opts.entityId}`
  )
}
```

#### 2b. 调用模式（各 route 中的使用方式）

```typescript
// agent/[hash]/route.ts — 现有模式改为新函数
import { auditGatewayRequest } from "@/lib/log"

// 请求入口
await auditGatewayRequest({
  phase: "GATEWAY_REQUEST",
  source: "agent",
  action: "dashboard",
  entityId: "dashboard",
})

// 错误路径（仅写 AuditLog 记录，appendRuntimeFinding 由 instrumentation.ts 边界捕获）
await auditGatewayRequest({
  phase: "GATEWAY_ERROR",
  source: "agent",
  action: "dashboard",
  entityId: "dashboard",
  detail: { error: errorMsg, durationMs },
})

// ===== h5 路由（新增） =====
// h5/nongqing/daily-report/route.ts
await auditGatewayRequest({
  phase: "GATEWAY_REQUEST",
  source: "h5",
  action: "daily_report",
  entityId: projectId,
  detail: { userId },
  durationMs: Date.now() - startTime,
})
```

#### 2c. 文件操作

- 删除 `src/lib/agent-gateway-dev-logger.ts`
- 删除 `src/lib/agent-gateway-audit.ts`
- 新建 `src/lib/log/gateway-audit.ts`
- 更新 `src/lib/log/index.ts` 导出 `auditGatewayRequest`

#### 2d. h5 路由接入清单（按优先级）

**P0 — 核心业务路由（7 条）**:

| 路由 | action | entityId |
|------|--------|---------|
| `h5/agent/route.ts` | `h5_chat` | traceId |
| `h5/nongqing/daily-report/route.ts` | `daily_report` | projectId |
| `h5/nongqing/overview/route.ts` | `overview` | projectId |
| `h5/nongqing/prescriptions/route.ts` | `prescriptions_list` | projectId |
| `h5/nongqing/tasks/route.ts` | `tasks_list` | projectId |
| `h5/production-plan/variety-recommend/route.ts` | `variety_recommend` | projectId |
| `h5/production-plan/land-analysis/route.ts` | `land_analysis` | projectId |

**P1 — 辅助路由（6 条）**: `prescriptions/[id]`, `tasks/[id]`, `plans/[id]`, `cost-accounting`, `generate`, `upload/image`

**P2 — 管理类路由**（knowledge/model/project/task/admin，不在本次 scope，后续 Plan 处理）

#### 2e. 调用方更新

**`agent/[hash]/route.ts`**:
- 删除 `agent-gateway-dev-logger` 和 `agent-gateway-audit` 的 import
- 所有 `agentGatewayAudit()` / `agentGatewayAuditPhaseStart/End` → `auditGatewayRequest()`
- 所有 `recordAgentGatewayAudit()` / `recordAgentGatewayError()` → `auditGatewayRequest()`
- 现有 `appendRuntimeFinding()` 手动调用（3 处）保持不变——由 hardening plan 的边界捕获机制管理，不纳入本 Atom scope

**验证**:
- `agent/[hash]` 的 8 个 action 全部通过 `auditGatewayRequest` 审计
- h5 7 条 P0 路由新增 gateway 审计
- 错误路径写入 AuditLog（GATEWAY_ERROR），`appendRuntimeFinding` 仍由 instrumentation.ts 边界捕获处理
- DB 中 `targetType = GATEWAY_AGENT` 和 `GATEWAY_H5` 可区分来源
- `agent-gateway-dev-logger.ts` 和 `agent-gateway-audit.ts` 已删除

---

### Atom 3: 删除 `audit-log.ts` 死代码

**目标**: 消除与 `writeAuditLog()` 功能重复的遗留模块

**当前状态**:
- `createAuditLog()`: 无内部调用方（死代码）
- `getAuditLogs()`: 仅被 `src/app/api/audit/route.ts` 调用
- `getAuditLogsByTarget()`: 无调用方
- `AuditLogEntry` 类型与 Prisma `AuditLog` 模型不一致（多了 `ip/userAgent`）
- `AuditAction` 类型（CREATE/UPDATE/DELETE/...）与 `writeAuditLog` 的 phase 字符串体系完全不同

**方案**:

1. **重写 `audit/route.ts`** 直接查询 Prisma：
   ```typescript
   import { prisma } from "@/lib/prisma"

   const logs = await prisma.auditLog.findMany({
     where: { /* filters */ },
     orderBy: { createdAt: "desc" },
     take: 500,
   })
   ```

2. **删除 `src/services/audit-log.ts`** 整个文件

3. **更新 `src/services/index.ts`** 删除 `createAuditLog` / `getAuditLogs` / `getAuditLogsByTarget` 的导出

**验证**:
- `GET /api/audit` 正常返回 DB 中的审计记录
- TypeScript 编译通过，无 import 报错
- `src/services/audit-log.ts` 不存在

---

### Atom 4: `agents/index.ts` 职责拆分

（与 v2 一致，无结构性变化）

**目标**: 将 563 行的单体文件拆分为 6 个职责清晰的模块

**拆分方案**:

| 新文件 | 职责 | 原代码行号 | 导出 |
|--------|------|-----------|------|
| `src/agents/tracer-store.ts` | `activeTracers` Map + `tracerCreateTimes` Map + `cleanupExpiredTracers` | L302-L323 | `activeTracers`, `tracerCreateTimes`, `cleanupExpiredTracers`, `TRACER_TTL_MS` |
| `src/agents/tracer.ts` | `getActiveTracer` + `startChainTrace` + `endChainTrace` | L413-L435 | `getActiveTracer`, `startChainTrace`, `endChainTrace` |
| `src/agents/tool-node-wrapper.ts` | `createToolNodeWrapper` 函数 | L34-L187 | `createToolNodeWrapper` |
| `src/agents/audit-wrapper.ts` | `wrapNodeWithAudit` 函数 | L325-L411 | `wrapNodeWithAudit` |
| `src/agents/agent-graph.ts` | `workflow` (deep) + `professionalWorkflow` + `agent` + `professionalGraph` + `setAgentTools` | L189-L300 + L31 | `agent`, `professionalGraph` |
| `src/agents/agent-runner.ts` | `runAgent` + `streamAgent` + `StreamAgentInput` + `buildPartialState` | L437-L561 | `runAgent`, `streamAgent`, `StreamAgentInput` |

**实施修正**: v3 原设计 `graph.ts` 因 top-level `await createCheckpointer()` 与 index.ts re-export 产生循环依赖（TS2323: Cannot redeclare exported variable），改为 `agent-graph.ts` 作为独立模块，index.ts 通过 re-export 桥接。

**拆分依据（行业实践对照）**:

564 行单体文件混合了 4 种不相关的设计模式，违反了单一职责原则：

| 原始代码段 | 模式 | 行业对标 | 改动触发 |
|-----------|------|---------|---------|
| L34-L187 `createToolNodeWrapper` | **Adapter** | 适配 LangGraph ToolNode 序列化问题 | 工具管线变更 |
| L189-L300 `workflow` + `professionalWorkflow` | **Composition Root** | DI 容器组装对象图（StateGraph 拓扑） | 图结构变更 |
| L302-L411 `wrapNodeWithAudit` + tracer 生命周期 | **Decorator / AOP** | 横切关注点（审计 + 链路追踪） | 审计策略变更 |
| L413-L561 `runAgent` + `streamAgent` | **Facade** | 对外 API 入口，隐藏内部图结构 | API 契约变更 |

**不拆的后果**：改一行 `createToolNodeWrapper`（工具执行逻辑），agent 和 professionalGraph 都要重新编译——模块耦合导致不必要重编译。拆分后 `agent-runner.ts` 只依赖 `agent-graph.ts`（图），不依赖 `tool-node-wrapper.ts`（工具包装器）——各自的 import 边界就是真实的依赖边界。

**最终文件结构**:

```
src/agents/
├── index.ts          (10行) — re-export 层，保持 25+ 外部 import 兼容
├── agent-graph.ts    (121行) — StateGraph 拓扑 + setAgentTools + createCheckpointer
├── agent-runner.ts   (131行) — runAgent + streamAgent + StreamAgentInput
├── tool-node-wrapper.ts (159行) — createToolNodeWrapper（Adapter Pattern）
├── audit-wrapper.ts  (90行) — wrapNodeWithAudit（Decorator Pattern）
├── tracer-store.ts   (26行) — activeTracers 生命周期管理
└── tracer.ts         (28行) — getActiveTracer + start/endChainTrace
```

**index.ts 最终内容**:

```typescript
export { agent, professionalGraph } from "./agent-graph"
export { runAgent, streamAgent } from "./agent-runner"
export type { StreamAgentInput } from "./agent-runner"
export { getActiveTracer, startChainTrace, endChainTrace } from "./tracer"
export { wrapNodeWithAudit } from "./audit-wrapper"
export { createToolNodeWrapper } from "./tool-node-wrapper"
export { activeTracers, tracerCreateTimes, cleanupExpiredTracers, TRACER_TTL_MS } from "./tracer-store"
export { agentTools } from "./tools"
```

**保留在 `index.ts`**:
- 所有 import（节点、边、工具、审计等）
- `setAgentTools(agentTools)` 调用（L31）
- Re-export 上述 6 个模块的公共 API
- `export { agentTools }` (L563)

**依赖关系**:
```
tracer-store.ts (无依赖)
    ├─→ tracer.ts (import tracer-store)
    ├─→ audit-wrapper.ts (import log + tracer-store, optional import tracer)
    └─→ index.ts (import all)

tool-node-wrapper.ts (import tools + log + stream-controller + event-bus)
agent-graph.ts (import nodes + edges + audit-wrapper + tool-node-wrapper + checkpointer)
agent-runner.ts (import agent-graph + log + callback)
```

**验证**:
- 所有 25+ 处 `import { ... } from "@/agents"` 无需修改（`index.ts` 保留 re-export）
- 子路径 import（`@/agents/experts/registry` 等）不受影响
- `agent` / `professionalGraph` 编译通过
- `runAgent` / `streamAgent` 调用正常

---

## 执行顺序

```
Atom 1 (LogFileWriter 基础设施)
  ├─→ Atom 2 (Gateway 审计纯函数 + h5 接入，依赖 Atom 1 的 LogFileWriter)
  └─→ Atom 4 的 audit-wrapper.ts (也使用 LogFileWriter)

Atom 3 (删除 audit-log.ts 死代码，无依赖，可并行)

Atom 4 (agents/index.ts 拆分，无依赖)
```

推荐执行顺序: **Atom 1 → Atom 2 → Atom 3/4 并行**

其中 Atom 2 的 h5 接入分两个子批次：
- 2a: 新建 `gateway-audit.ts` + 重写 `agent/[hash]` 调用方
- 2b: h5 P0 路由接入（7 条）
- 2c: h5 P1 路由接入（6 条）

---

## 风险评估

| 风险 | 严重度 | 缓解 |
|------|--------|------|
| LogFileWriter 改变日志格式，破坏下游解析 | P1 | Console 保持 `[PREFIX] [ts] [phase] desc`；File 切换到 JSONL 是一次性迁移，旧文件保留 |
| `LazyLogFileWriter` 动态 import 在 Edge Runtime 下行为未知 | P2 | 仅 chat-stats/model-config 两个模块使用，在 server 端运行，增加守卫 |
| Agent gateway 审计切换到新函数后遗漏调用点 | P1 | 先实现新函数，`agent/[hash]` 逐 action 替换，编译 + grep 确认无残留旧 import |
| h5 路由接入 gateway 审计后日志量增加 | P2 | `auditGatewayRequest` 的 console 输出极简（单行），DB 写入与现有频率相同 |
| agents/index.ts 拆分破坏 import 路径 | P1 | 保留 `index.ts` re-export；`tracer-store.ts` 消除 audit-wrapper ↔ tracer 循环依赖 |
| 删除 audit-log.ts 后 `audit/route.ts` 过滤参数变化 | P3 | `AuditAction` 枚举不存在于 DB，改用字符串过滤；元调用方仅 admin 后台，低流量 |

---

## ADD 工作流衔接

- **Step 0**: 本 Plan 已包含 DPS 所需的问题定义 + 原子拆分 + 风险评估
- **Step 1-2**: 按 Atom 执行顺序逐个实现，每个 Atom 完成后运行 TypeScript 编译 + 现有测试
- **Step 3**: Atom 4 需要运行 `getActiveTracer` 的调用链路测试
- **Step 8**: 验收后写 devlog（走 MCP `record_dev_operation`）至 `.qoder/plans/2026-07/01/` + 更新 handoff
