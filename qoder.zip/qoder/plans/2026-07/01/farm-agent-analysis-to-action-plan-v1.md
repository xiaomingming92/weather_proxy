# farm-agent-analysis-to-action-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。具体接口定义、WHEN-THEN 场景在 Spec。
> **结构说明**：本 Plan 采用单 Spec 多操作步骤区块模式，1 个 Spec 内含 5 个独立操作区块，按依赖顺序串行执行，整体闭包交付。

## PLAN 元信息

- **Plan 名称**: farm-agent-analysis-to-action-v1
- **启动时间**: 2026-07-01T18:00:00+08:00
- **主导 AI**: Qoder
- **前置 Plan**:
  - [farm-agent-domain-vocabulary-plan-v2.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-07/01/farm-agent-domain-vocabulary-plan-v2.md)（触发词 v2 + 3-Tier 路由，提供精准意图路由）
  - [farm-agent-project-context-activation-plan-v1.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-07/01/farm-agent-project-context-activation-plan-v1.md)（项目上下文激活，提供 activedProjectId）
  - [personnel-management-plan-v1.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/23/personnel-management-plan-v1.md)（人员管理与智能派发，提供调度智能体）
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-07/01/farm-agent-analysis-to-action-add-route-v1.md`（待生成）
  - Handoff: `.qoder/plans/2026-07/01/farm-agent-analysis-to-action-handoff-v1.md`（待生成，多步骤模板）
  - Review: `.qoder/reviews/farm-agent-analysis-to-action-review-v1.md`（待生成）
  - Spec: `.qoder/specs/farm-agent-analysis-to-action/spec.md`（待生成，含 5 个操作区块）
- **ADD-7 审计策略**: 见各操作区块

---

## 一、背景与目标

### 1.1 问题现状

farm-agent 当前存在一条结构性断裂：**分析管线与执行管线完全分离**。

```
当前状态:
  用户: "地里虫子多，打什么药"
    ↓
  3-Tier 路由 → pest_risk 专家
    ↓
  分析完成 → 输出文本报告（"建议使用吡虫啉..."）
    ↓
  ❌ 断链：报告只是文本，不会生成处方、不会创建任务、不会派发农机
```

具体表现：

| # | 断裂点 | 现象 | 根因 |
|---|--------|------|------|
| 1 | 专家无输出动作 | 14 个专家的 `AnalysisExpert` 接口只有 `outputSections`（文本段落），无 `outputActions`（数据写入） | 专家设计为"分析并输出报告"，未设计"分析并触发行动" |
| 2 | 无处方创建工具 | Agent 工具注册表有 `create_task`（项目管理 Task），无 `create_prescription`（AlertPrescription） | 工具层未覆盖农情域 |
| 3 | 日报处方链路休眠 | `daily-report/route.ts` L184-212 有处方创建代码，但 `computeDailyReportData()` 始终返回 `status: "normal"`，分支永远不触发 | 阶段2（LLM 分析）未实现 |
| 4 | Plan 生成无 LLM | `/api/h5/production-plan/generate` 是纯模板查找（仅小麦/水稻），无专家参与 | `plan_generate` 专家未创建 |
| 5 | 分析→派发无桥接 | 处方创建后无法自动触发调度智能体（人员/农机派发） | 调度智能体尚未接入（personnel-management-plan-v1 待实施） |

### 1.2 目标

**闭包定义**：用户说一句农民口语 → Agent 分析 → 生成处方/plan/task 写入 DB → （可选）触发调度派发。

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | 新建 3 个农情域 Agent 工具 | `create_prescription` / `create_production_plan` / `create_farm_task` 可调用，数据写入对应表 |
| P0 | 激活日报 LLM 分析 + 处方自动生成 | `computeDailyReportData()` 返回 `status: "warning"` 时，`AlertPrescription` 自动创建 |
| P0 | 专家配置支持 outputActions | `AnalysisExpert` 接口扩展 `outputActions` 字段，pest_risk / nutrition_diagnose / weather_impact 声明处方生成能力 |
| P1 | reasoning 节点输出→动作桥接 | reasoning 完成后，若专家配置了 `outputActions`，自动调用对应 Agent 工具 |
| P2 | 调度智能体预留学段 | `AlertPrescription` / `FarmTask` 预留 `dispatchStatus` + `dispatchedTo` 字段，为调度智能体接入做准备 |

### 1.3 非目标

- 不实施调度智能体本身（personnel-management-plan-v1 负责）
- 不改造现有 fast/deep 图的核心管线
- 不修改 `collectionHints` 或 RAG 检索逻辑
- 不实施 `plan_generate` 专家（独立 plan，依赖土地分析 + 品种推荐 + 成本估算聚合，复杂度高）

---

## 二、方案选型

### 2.1 专家输出→动作的桥接方式

| 方案 | 描述 | 优点 | 缺点 | 结论 |
|------|------|------|------|------|
| A: 专家 prompt 内直接调工具 | 在专家 reasoning prompt 中指示 LLM 输出 tool_call | 简单直接 | 专家 prompt 膨胀，工具调用与分析推理耦合，难以测试 | ❌ |
| B: AnalysisExpert 扩展 outputActions + reasoning 后处理 | 专家配置声明"我能产出什么动作"，reasoning 节点后处理阶段解析 LLM 输出并调用工具 | 关注点分离，专家只声明能力，执行由框架层完成 | 需要定义输出动作的数据契约 | ✅ 选用 |
| C: 独立 action 节点 | 在 graph 中新增 `actionExecution` 节点，位于 reasoning 之后 | 架构清晰 | 改动图拓扑，影响所有现有专家，风险高 | ⚠️ 保留给后续 |

**选型理由**：B 方案在现有图拓扑（intention → retrieval → reasoning → verdict → response）上最小侵入——reasoning 节点完成后、verdict 之前，增加一个轻量的"输出动作检测"后处理。专家通过配置声明能力，框架层自动执行。

**B→C 演进策略**：

→ 当声明 `outputActions` 的专家数 > 5 时，后处理逻辑会膨胀（每个 action type 一个 case 分支 + 各自的 paramMapping）。此时应评估迁移到方案 C（独立 `actionExecution` 图节点），将后处理从 reasoning 内部提升为图拓扑的一等公民。迁移判定条件在 Step 8 收敛时评估。
[2026-07-02 修订: Review P1-3.5 回流 — 补充 B→C 演进路径]

### 2.2 日报 LLM 分析的激活方式

| 方案 | 描述 | 结论 |
|------|------|------|
| A: 在 route.ts 内直接调 LLM | `computeDailyReportData()` 内部调 `generateText()` | ❌ 绕过 Agent 管线，无法复用专家能力 |
| B: 通过 Agent 管线调 daily_report 专家 | 日报 API 内部触发一次 Agent 调用，走 daily_report 专家 | ⚠️ 循环调用风险，架构复杂 |
| **C: 抽取 LLM 分析函数，专家 prompt 复用** | 新建 `src/services/daily-report-analyzer.ts`，复用 daily_report 专家的 prompt 模板和工具查询能力，但不走完整 Agent 图 | ✅ **选用** |

---

## 三、架构设计

### 3.1 整体数据流（改造后）

```
用户: "地里虫子多，打什么药"
    │
    ▼ 3-Tier 路由（domain-vocabulary-v2）
    Tier 1: "虫子" → pest_risk（<1ms）
    │
    ▼ intention 节点
    expertPlan: [pest_risk]
    │
    ▼ retrieval 节点
    预取 activedProjectId 的农情数据（project-context-activation）
    │
    ▼ reasoning 节点
    pest_risk 专家分析 → 输出结构化结果
    │ 包含: conclusion + evidence + action_steps
    │
    ▼ ★ 新增: outputAction 检测（reasoning 后处理）
    pest_risk.config.outputActions = [{ type: "prescription", ... }]
    → 自动调用 create_prescription 工具
    → AlertPrescription 写入 DB
    │
    ▼ verdict → response
    文本报告 + 结构化数据（处方已创建，ID: xxx）
```

### 3.2 AnalysisExpert 接口扩展

```typescript
~~// 新增类型
interface ExpertOutputAction {
  type: "prescription" | "farm_task" | "production_plan"
  paramMapping: {
    name: string
    description?: string
    steps?: string
    triggerType?: string
    deadline?: string
  }
}~~
→ // 新增类型（v2 — Review P0-3.1 回流后）
→ interface ExpertOutputAction {
→   type: "prescription" | "farm_task" | "production_plan"
→   triggerType?: "pest" | "weather" | "soil_moisture"
→   confidenceThreshold?: number
→   autoConfirmThreshold?: number     // ≥ 此值自动创建
→   interactiveThreshold?: number     // 此值~autoConfirm 之间触发交互点
→   actionPayloadSchema?: z.ZodObject<any>  // LLM 输出的结构化 payload schema
→ }

interface AnalysisExpert {
  // ... 现有字段不变 ...
  outputActions?: ExpertOutputAction[]  // ★ 新增
}
```
[2026-07-02 修订: Review P0-3.1 回流 — paramMapping 替换为 actionPayloadSchema]

### 3.3 新 Agent 工具

```
src/agents/tools/
  ├── schemas/
  │   └── nongqing-tools.ts          # create_prescription / create_farm_task / create_production_plan 的 Zod Schema
  └── impl/
      └── nongqing-tools.ts          # 工具实现：写入 AlertPrescription / FarmTask / ProductionPlan

src/services/
  └── nongqing-action.ts             # 农情动作服务层（封装 Prisma 写入 + 审计）
```

### 3.4 日报 LLM 分析激活

```
src/services/
  └── daily-report-analyzer.ts       # 新增：LLM 分析函数
                                       输入: projectId + 24h 四情数据 + 7天天气
                                       输出: DailyReportData（含 status/riskWarning/solutionPrescription）
                                       复用: daily_report 专家 prompt 模板 + query_farm_weather 等工具
```

---

## 四、操作步骤区块（单 Spec 内 5 个区块）

> 以下 5 个操作区块将在同一个 Spec 中定义，按依赖顺序串行执行。
> 每个区块是独立的验证单元，完成后记录 ADD-7 审计 + 更新 handoff。

~~```
区块 1 → 区块 2 → 区块 3 → 区块 4 → 区块 5
```~~
→ ```
区块 1: Agent 工具层 ────────────────────────────────────── P0
   │  新建 create_prescription / create_farm_task / create_production_plan
   │  文件: nongqing-tools.ts (schema + impl) + nongqing-action.ts (service)
   │  验收: 3 个工具可调用，数据写入对应表，审计记录完整
   │
   ▼
区块 4: 日报 LLM 分析激活 ───────────────────────────────── P0  ★ 提前
   │  新建 daily-report-analyzer.ts
   │  替换 computeDailyReportData() 硬编码为 LLM 分析
   │  处方创建逻辑重构为调用 nongqing-action.ts 服务层
   │  文件: daily-report-analyzer.ts + daily-report/route.ts
   │  验收: 日报返回 warning 时 AlertPrescription 自动创建
   │  ★ 提前理由: 不依赖区块 2/3，可独立交付；快速验证 nongqing-action.ts 服务层
   │
   ▼
区块 2: 专家配置扩展 ────────────────────────────────────── P0
   │  AnalysisExpert 接口增加 outputActions + actionPayloadSchema
   │  pest_risk / nutrition_diagnose / weather_impact 声明处方生成能力
   │  文件: registry.ts + 3 个 config.ts
   │  验收: tsc 通过，专家配置可声明 outputActions
   │
   ▼
区块 3: reasoning 后处理桥接 ────────────────────────────── P1
   │  reasoning 节点完成后检测 outputActions + action_payload 解析
   │  匹配到声明 → 调用对应 Agent 工具
   │  文件: agent-graph.ts 或 reasoning.ts
   │  验收: pest_risk 分析后自动创建 AlertPrescription
   │
   ▼
区块 5: 调度预留学段 ────────────────────────────────────── P2
   │  AlertPrescription / FarmTask 预留 dispatchStatus + dispatchedTo
   │  Schema 变更 + migration
   │  文件: nongqing.prisma + migration
   │  验收: tsc 通过，字段可读写，调度智能体可直接消费
```
[2026-07-02 修订: Review 回流 — 执行顺序调整为 1→4→2→3→5，区块 4 提前独立交付]

---

## 五、各区块详细设计

### 区块 1: Agent 工具层

**新建文件**:

| 文件 | 说明 |
|------|------|
| `src/agents/tools/schemas/nongqing-tools.ts` | 3 个工具的 Zod Schema |
| `src/agents/tools/impl/nongqing-tools.ts` | 工具实现 |
| `src/services/nongqing-action.ts` | 服务层（Prisma 写入 + Layer 2 审计） |

**create_prescription 工具 Schema**:

```typescript
const CreatePrescriptionSchema = z.object({
  projectId: z.number(),
  name: z.string(),
  description: z.string().optional(),
  triggerReason: z.string(),
  triggerType: z.enum(["pest", "weather", "soil_moisture"]),
  scope: z.string().optional(),
  scopeArea: z.number().optional(),
  deadline: z.string().optional(),
  steps: z.array(z.object({ order: z.number(), content: z.string() })).optional(),
  prescriptionSource: z.string().optional(),
  reportTitle: z.string().optional(),
  sourceReportDate: z.string().optional(),
})
```

**create_farm_task 工具 Schema**:

```typescript
const CreateFarmTaskSchema = z.object({
  growthStageId: z.number(),
  name: z.string(),
  description: z.string().optional(),
  scope: z.string().optional(),
  deadline: z.string().optional(),
  steps: z.array(z.object({ order: z.number(), content: z.string() })).optional(),
})
```

**create_production_plan 工具 Schema**:

```typescript
const CreateProductionPlanSchema = z.object({
  projectId: z.number(),
  planName: z.string(),
  cropType: z.string(),
  varietyName: z.string(),
  targetYield: z.number(),
  sowingDate: z.string(),
  maturityDate: z.string(),
  massifIds: z.array(z.number()).optional(),
  coreMetrics: z.record(z.any()).optional(),
})
```

**工具注册**: `src/agents/tools/index.ts` 注册 3 个新工具。

**ADD-7 审计策略**:

| 文件 | targetType | action |
|------|-----------|--------|
| `src/agents/tools/schemas/nongqing-tools.ts` | TOOL | TOOL_CREATED |
| `src/agents/tools/impl/nongqing-tools.ts` | TOOL | TOOL_CREATED |
| `src/services/nongqing-action.ts` | SERVICE | SERVICE_CREATED |
| `src/agents/tools/index.ts` | TOOL | TOOL_REGISTRY_MODIFIED |

---

### 区块 2: 专家配置扩展

**修改文件**:

| 文件 | 改动 |
|------|------|
| `src/agents/experts/registry.ts` | `AnalysisExpert` 接口新增 `outputActions?: ExpertOutputAction[]` |
| `src/agents/experts/configs/pest-risk.config.ts` | 声明 `outputActions: [{ type: "prescription", triggerType: "pest" }]` |
| `src/agents/experts/configs/nutrition-diagnose.config.ts` | 声明 `outputActions: [{ type: "prescription", triggerType: "pest" }]` |
| `src/agents/experts/configs/weather-impact.config.ts` | 声明 `outputActions: [{ type: "prescription", triggerType: "weather" }]` |

**ExpertOutputAction 类型定义**:

```typescript
~~export interface ExpertOutputAction {
  type: "prescription" | "farm_task" | "production_plan"
  triggerType?: "pest" | "weather" | "soil_moisture"
  nameSource: "conclusion" | "action_steps" | "risk"
  confidenceThreshold?: number
}~~
→ export interface ExpertOutputAction {
→   type: "prescription" | "farm_task" | "production_plan"
→   triggerType?: "pest" | "weather" | "soil_moisture"
→   confidenceThreshold?: number
→   /** LLM reasoning 时额外输出的结构化 action payload schema */
→   actionPayloadSchema?: z.ZodObject<any>
→ }
```
[2026-07-02 修订: Review P0-3.1 回流 — 废弃 nameSource 文本提取方案，改为 LLM 直接输出结构化 action_payload]

**映射机制说明**（替代原 `mapReasoningToPrescription()` 黑盒）：

~~从专家自由文本输出（conclusion/action_steps）中提取结构化参数。~~
→ 在专家 reasoning prompt 中增加 `action_payload` 输出约束：当专家配置了 `outputActions` 时，reasoning prompt 末尾追加一段结构化输出指令，要求 LLM 在分析完成后额外输出一个 JSON 块 `action_payload`，其 schema 由 `actionPayloadSchema` 定义。

```
reasoning prompt 尾部追加（仅当 expert.outputActions 存在时）:
  ---
  如果分析结论包含需要处置的风险，请额外输出以下 JSON（包裹在 <action_payload> 标签中）:
  {
    "shouldAct": true/false,
    "payload": { ... 符合 actionPayloadSchema 的结构 ... }
  }
  如果无需处置，输出 { "shouldAct": false }
```

后处理逻辑：
1. 解析 reasoning 输出中的 `<action_payload>` 标签
2. `shouldAct: false` → 跳过
3. `shouldAct: true` → 用 `actionPayloadSchema` 校验 payload → 调用对应工具
4. 解析失败 → 审计记录 + 降级为纯文本报告（不阻断主流程）

**优势**：LLM 直接输出结构化数据，避免从自由文本中提取参数的不可靠性。

**ADD-7 审计策略**:

| 文件 | targetType | action |
|------|-----------|--------|
| `src/agents/experts/registry.ts` | TYPE | TYPE_EXTENDED |
| `src/agents/experts/configs/pest-risk.config.ts` | COMPONENT | CONFIG_EXTENDED |
| `src/agents/experts/configs/nutrition-diagnose.config.ts` | COMPONENT | CONFIG_EXTENDED |
| `src/agents/experts/configs/weather-impact.config.ts` | COMPONENT | CONFIG_EXTENDED |

---

### 区块 3: reasoning 后处理桥接

**修改文件**:

| 文件 | 改动 |
|------|------|
| `src/agents/agent-graph.ts` 或 `src/agents/nodes/reasoning.ts` | reasoning 完成后新增 `executeOutputActions()` 后处理 |

**设计**:

```typescript
// reasoning 节点完成后、verdict 之前
async function executeOutputActions(
  expertId: string,
  reasoningOutput: ReasoningResult,
  state: AgentState
): Promise<ActionPerformed[]> {
  const config = getExpertConfig(expertId)
  if (!config.outputActions?.length) return []

  const results: ActionPerformed[] = []
  for (const action of config.outputActions) {
    if (action.confidenceThreshold && reasoningOutput.confidence < action.confidenceThreshold) continue

    switch (action.type) {
      case "prescription":
        const prescription = mapReasoningToPrescription(reasoningOutput, action, state)
        const result = await createPrescriptionTool(prescription)
        results.push(result)
        break
      // farm_task / production_plan 类似
    }
  }
  return results
}
```

**关键约束**:
- 工具调用走已有的工具注册表，不绕过权限/审计
- 动作执行失败不阻断主流程（catch + 审计记录，response 中注明"处方创建失败"）
- 动作执行结果注入到 verdict/response 的结构化数据中
- verdict 节点需适配：输入增加 `actionResults` 字段，感知 outputAction 执行结果

**自动创建边界与用户确认**：

→ 并非所有分析结果都应自动创建处方。引入三级策略：

| 置信度区间 | 行为 | 说明 |
|-----------|------|------|
| `≥ 0.8` | 自动创建（status=pending） | 高风险，静默创建待人工确认 |
| `0.5 ~ 0.8` | 触发交互点，用户确认后创建 | "检测到虫害风险，是否创建防治处方？" |
| `< 0.5` | 仅输出文本建议 | 不创建处方 |

`ExpertOutputAction` 增加 `autoConfirmThreshold` 和 `interactiveThreshold` 两个阈值字段。交互点走已有的 `interactionPointDetection` 机制（见 `farm-agent-interaction-resume-fix-plan-v1.md`）。
[2026-07-02 修订: Review P1-3.4 回流 — 明确自动创建边界 + 交互点确认机制]

**ADD-7 审计策略**:

| 文件 | targetType | action |
|------|-----------|--------|
| `src/agents/agent-graph.ts` | GRAPH | GRAPH_OUTPUT_ACTION_BRIDGE_ADDED |

---

### 区块 4: 日报 LLM 分析激活

**新建文件**:

| 文件 | 说明 |
|------|------|
| `src/services/daily-report-analyzer.ts` | LLM 分析函数，复用 daily_report 专家 prompt 模板 |

**修改文件**:

| 文件 | 改动 |
|------|------|
| `src/app/api/h5/nongqing/daily-report/route.ts` | `computeDailyReportData()` 调用 `analyzeDailyReport()` 替换硬编码 |

**daily-report-analyzer.ts 设计**:

~~数据聚合复用 LangChain Tool（queryFarmWeather / querySoilMoisture / queryInsectData）。~~
→ 数据聚合**直接调用 `farm-server-client.ts` 和 Prisma 查询**，不走 LangChain Tool 层。原因：LangChain Tool 绑定在 Agent 图的工具链中，独立函数无法直接调用。Tool 的核心查询逻辑本身就是对 `farm-server-client.ts` 的薄封装。

```typescript
export async function analyzeDailyReport(projectId: number, planId?: number): Promise<DailyReportData> {
  // 1. 聚合数据源（直接调用服务层，不走 LangChain Tool）
  const weather = await farmServerClient.getWeather24h(projectId)     // ← farm-server-client
  const soil = await farmServerClient.getSoilMoisture24h(projectId)   // ← farm-server-client
  const insects = await farmServerClient.getInsectData24h(projectId)  // ← farm-server-client
  const dbPlan = await prisma.productionPlan.findFirst({ where: { projectId } })

  // 2. 构建 prompt（复用 daily_report 专家 prompt 模板中的分析指令部分）
  const prompt = buildDailyReportPrompt({ weather, soil, insects, crop: dbPlan?.cropType, stage: ... })

  // 3. LLM 分析（带超时保护）
  const analysis = await Promise.race([
    generateText({ prompt, ... }),
    timeout(30_000).then(() => { throw new Error("DAILY_REPORT_LLM_TIMEOUT") })
  ])

  // 4. 解析为 DailyReportData 结构
  return parseDailyReportAnalysis(analysis, { projectId, crop, stage: ... })
}
```

**LLM 超时/失败降级**：

→ 当 `analyzeDailyReport()` 抛出异常（LLM 超时、解析失败等），`computeDailyReportData()` 降级为返回硬编码 `status: "normal"` demo 数据，确保日报 API 不中断。降级时记录审计日志 `DAILY_REPORT_LLM_FALLBACK`。
[2026-07-02 修订: Review P0-3.3 回流 — 数据获取改用 farm-server-client + 增加超时降级]

**route.ts 改造**:

```diff
- async function computeDailyReportData(_projectId: number, _planId?: number): Promise<DailyReportData> {
-   // 硬编码 demo 数据...
-   return { status: "normal", ... }
- }
+ async function computeDailyReportData(projectId: number, planId?: number): Promise<DailyReportData> {
+   return analyzeDailyReport(projectId, planId)
  }
```

**处方自动创建（重构）**：

~~route.ts L184-212 的处方创建逻辑已经就绪，`status: "warning"` 时自动触发，无需改动。~~
→ route.ts L184-212 的处方创建逻辑**必须重构为调用区块 1 的 `nongqing-action.ts` 服务层**，统一审计通道。当前内联的 `prisma.alertPrescription.create` 直接写 DB，绕过了 Layer 2 审计。重构后：

```diff
- await prisma.alertPrescription.create({ data: { ... } })
+ await createPrescriptionAction({ ... })  // 调用 nongqing-action.ts 服务层
```

**去重键修正**：

~~去重使用 `projectId + sourceReportDate + name` 精确匹配。~~
→ 去重键改为 `projectId + triggerType + sourceReportDate`，避免 LLM 两次分析产出不同 name 导致去重失效。
[2026-07-02 修订: Review P0-3.2 回流 — 统一处方创建通道 + 修正去重键]

**ADD-7 审计策略**:

| 文件 | targetType | action |
|------|-----------|--------|
| `src/services/daily-report-analyzer.ts` | SERVICE | SERVICE_CREATED |
| `src/app/api/h5/nongqing/daily-report/route.ts` | API_ROUTE | API_ROUTE_MODIFIED |

---

### 区块 5: 调度预留学段

**修改文件**:

| 文件 | 改动 |
|------|------|
| `prisma/nongqing.prisma` | AlertPrescription + FarmTask 新增 `dispatchStatus` + `dispatchedTo` |
| `prisma/migrations/xxx/` | 新 migration |

**Schema 变更**:

```prisma
model AlertPrescription {
  // ... 现有字段不变 ...

  // ★ 调度预留（personnel-management-plan-v1 消费）
  dispatchStatus  String?   // pending_dispatch | dispatched | accepted | rejected
  dispatchedTo    String?   // 派发目标（人员ID / 农机ID）
  dispatchedAt    DateTime?
}

model FarmTask {
  // ... 现有字段不变 ...

  // ★ 调度预留
  dispatchStatus  String?
  dispatchedTo    String?
  dispatchedAt    DateTime?
}
```

**约束**:
- 字段全部 nullable，不影响现有逻辑
- 默认不设置值，调度智能体接入后按需写入
- 与 personnel-management-plan-v1 的 `PersonnelProfile` / 农机模型对接

**ADD-7 审计策略**:

| 文件 | targetType | action |
|------|-----------|--------|
| `prisma/nongqing.prisma` | SCHEMA | SCHEMA_FIELD_ADDED |

---

## 六、验收标准（整体闭包）

### 端到端场景验证

- [ ] **场景 1**: 用户说"地里虫子多" → pest_risk 专家分析 → AlertPrescription 自动创建
- [ ] **场景 2**: H5 日报 API 返回 warning → AlertPrescription 自动创建（处方链路激活）
- [ ] **场景 3**: Agent 对话中手动调用 `create_farm_task` → FarmTask 写入 DB
- [ ] **场景 4**: Agent 对话中手动调用 `create_production_plan` → ProductionPlan + GrowthStage + FarmTask 写入 DB
- [ ] **场景 5**: 处方创建后，`dispatchStatus` 字段可读写（为调度预留）

### 技术验证

- [ ] `npx tsc --noEmit` 零错误
- [ ] 3 个新工具注册到 Agent 工具表，可通过 Agent 对话调用
- [ ] `AnalysisExpert.outputActions` 类型定义存在，3 个专家已声明
- [ ] reasoning 后处理检测到 outputActions 时自动调用工具
- [ ] 动作执行失败不阻断主流程，response 中注明失败原因
- [ ] daily-report-analyzer.ts 可独立调用，返回 DailyReportData
- [ ] 现有 fast/deep 图不受影响
- [ ] Schema migration 成功，nullable 字段不影响现有数据

---

## 七、风险矩阵

| 风险 | 概率 | 影响 | 缓解措施 |
|------|:--:|------|---------|
| reasoning 后处理增加工具调用导致延迟 | 中 | 中——用户等待时间增加 | 工具调用异步执行（`Promise.allSettled`），不阻塞 verdict/response 生成 |
| LLM 分析日报质量不稳定 | 中 | 中——可能产生误报处方 | 处方创建前增加去重检查（同项目同日同类型不重复创建），route.ts L186 已有此逻辑 |
| outputActions 声明错误导致误创建处方 | 低 | 高——用户不需要处方但被创建 | confidenceThreshold 门控 + 处方 status 默认 pending，需人工确认 |
| Schema migration 影响生产数据 | 低 | 低——新增字段全部 nullable | migration 仅 ADD COLUMN，不修改/删除现有字段 |
| 日报 LLM 分析成本增加 | 中 | 低——每次日报多一次 LLM 调用 | 日报非高频操作（每日 1-2 次），成本可控 |

---

## 八、依赖关系与前置条件

```
domain-vocabulary-v2（3-Tier 路由）
    │  提供精准路由，确保用户口语 → 正确专家
    │  非强依赖：即使 v2 未完成，本 plan 仍可工作（走 Tier 3 LLM）
    │
project-context-activation（activedProjectId）
    │  提供项目上下文，处方/任务绑定到正确项目
    │  ★ 强依赖：工具 Schema 中 projectId 来自 activedProjectId
    │
personnel-management-plan-v1（调度智能体）
    │  本 plan 区块 5 预留字段，调度智能体消费
    │  非强依赖：预留字段 nullable，调度未接入时不影响
    │
本 plan（analysis-to-action）
    │
    ▼
  闭包交付: 分析 → 生成 → (预留派发)
```

---

## 九、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| 触发词 v2 Plan | `.qoder/plans/2026-07/01/farm-agent-domain-vocabulary-plan-v2.md` | ✅ 已完成 |
| 项目上下文激活 Plan | `.qoder/plans/2026-07/01/farm-agent-project-context-activation-plan-v1.md` | ✅ 已完成 |
| 人员管理 Plan | `.qoder/plans/2026-06/23/personnel-management-plan-v1.md` | 🔄 待实施 |
| 农情报告 API Plan | `.qoder/plans/2026-06/22/farm-agent-nongqing-report-api-plan-v1.md` | ✅ 阶段1完成 |
| 种植计划模型 Plan | `.qoder/plans/2026-06/22/farm-agent-crop-plan-model-plan-v1.md` | ✅ 已完成 |
| ADD Route | `.qoder/plans/2026-07/01/farm-agent-analysis-to-action-add-route-v1.md` | 待生成 |
| Handoff | `.qoder/plans/2026-07/01/farm-agent-analysis-to-action-handoff-v1.md` | 待生成 |
| Spec | `.qoder/specs/farm-agent-analysis-to-action/spec.md` | 待生成 |
