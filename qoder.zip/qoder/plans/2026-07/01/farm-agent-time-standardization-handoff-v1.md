# farm-agent — 时间规范化治理 交接手册

> **单轮变更**：52 文件，纯 import 替换，零功能变更。

---

## 1. 交接前状态

全局 80+ 处绕过 `src/lib/time.ts` 裸调 `new Date().toISOString()` / `new Date()`：
- 日志/审计文件各自生成时间戳，无统一入口
- DB JSON metadata 直接写 UTC ISO 字符串
- Prisma DateTime 字段直接 `new Date()` 赋值
- Report 文档使用 UTC 时间（非北京时间）
- 前端展示 DB 时间时无时区转换

## 2. 交接后状态（目标）

`src/lib/time.ts` 作为唯一时间入口，提供 6 个函数：

| 函数 | 返回 | 用途 |
|------|------|------|
| `utcNow()` | `string` | 日志/DB/系统间通信 |
| `utcNowDate()` | `Date` | Prisma DateTime 字段 |
| `localNow()` | `string` | Report/通知/人类可读 |
| `fromUTC(s)` | `Date` | DB→前端展示转换 |
| `toLocalISO(s)` | `string` | UTC→本地 ISO |
| `fromUTCToDate(s)` | `Date` | 语义别名 |

全局 `new Date().toISOString()` 和裸 `new Date()` 清零（豁免：`Date.now()`、`new Date(x)` 解析、测试 mock）。

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/lib/time.ts` | 修改 | 新增 utcNowDate/fromUTC/fromUTCToDate/toLocalISO，重命名 now→utcNow、reportNow→localNow |
| 2-16 | `src/lib/log/audit.ts` 等 15 文件 | 修改 | `new Date().toISOString()` → `utcNow()` |
| 17-18 | `src/lib/append-runtime-finding*.ts` + `src/proxy.ts` | 修改 | `now()`→`utcNow()`，`reportNow()`→`localNow()` |
| 19-25 | `src/services/knowledge-*.ts` 等 7 文件 | 修改 | JSON metadata `new Date().toISOString()` → `utcNow()`，Prisma DateTime → `utcNowDate()` |
| 26-29 | `src/services/report-generator.ts` 等 4 文件 | 修改 | Report 时间 → `localNow()` |
| 30-34 | `src/agents/nodes/*.ts` 5 文件 | 修改 | step timestamp → `utcNow()` |
| 35-47 | `src/app/api/**/route.ts` 13 文件 | 修改 | 响应/DB 时间 → `utcNow()`/`utcNowDate()` |
| 48-51 | `src/stores/*.ts` + `chat-panel.tsx` 4 文件 | 修改 | 前端时间戳 → `utcNow()` |
| 52-55 | `src/components/**/` 4 文件 | 修改 | `toLocaleXxx` → `fromUTC()` |
| 56 | `src/types/evidence.ts` | 修改 | `createEmptyEvidenceChain` → `utcNow()` |

## 4. 回滚方案

```bash
git revert <commit>
```

无数据迁移，纯 import 替换，一键回滚。

## 5. 执行前置检查

- [x] `npx tsc --noEmit` 0 错误
- [x] `grep` 确认 `new Date().toISOString()` 清零（仅 time.ts 内允许）
- [x] `grep` 确认裸 `new Date()` 清零（豁免场景除外）

## 6. 执行步骤摘要

```
Task 1: time.ts 扩展 (6函数)
            │
    ┌───────┼────────┬────────┬────────┐
    ▼       ▼        ▼        ▼        ▼
Task 2   Task 3   Task 4   Task 5   Task 6
(日志)   (Service) (Report) (Agent)  (API Route)
    │       │        │        │        │
    └───────┴────────┴────────┴────────┘
            │
    ┌───────┴────────┐
    ▼                ▼
Task 7 (Store)   Task 8 (UI fromUTC)
            │
            ▼
Task 9: tsc + grep 验证 → 清零确认
```

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| Report 时间从 UTC 变为北京时间 | 外部系统可能依赖 UTC 格式 | 仅影响 human-readable Report/通知，不影响 API/DB |
| 前端 `fromUTC()` 在 SSR 环境下行为 | Next.js SSR 时区可能不同于浏览器 | fromUTC 使用 `TZ_OFFSET_HOURS` 环境变量，SSR 与客户端一致 |

## 8. 恢复上下文审计查询

### 总体一键恢复

```text
query_audit_logs({ keyword: "time-standardization" })
```
→ 预期返回 10+ 条记录

### 文件级别查询

```text
query_audit_logs({ targetId: "farm-agent-time-standardization-plan-v1" })
query_audit_logs({ targetId: "farm-agent-time-standardization-add-route-v1" })
query_audit_logs({ targetId: "farm-agent-time-standardization-review-v1" })
```

### grep 验证

```bash
# 确认零残留
grep -rn 'new Date().toISOString()' src/ --include='*.ts' --include='*.tsx' | grep -v time.ts | grep -v '.test.'
# 应返回空

# 确认时间函数覆盖
grep -rn 'utcNow\|localNow\|fromUTC' src/ --include='*.ts' --include='*.tsx' | wc -l
# 应 > 100
```

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过（0 错误）
- [x] 所有文件改动已记录 ADD-7 审计
- [x] `new Date().toISOString()` 全局清零
- [x] `new Date()` 裸调用清零（豁免场景外）
- [x] RAHS = 100 🟢
