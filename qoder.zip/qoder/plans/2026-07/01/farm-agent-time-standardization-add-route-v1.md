# farm-agent-time-standardization-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）
>
> **绑定**：Plan: `.qoder/plans/2026-07/01/farm-agent-time-standardization-plan-v1.md` · Spec: `.qoder/specs/farm-agent-time-standardization/spec.md` · Tasks: `.qoder/specs/farm-agent-time-standardization/tasks.md` · Handoff: `.qoder/plans/2026-07/01/farm-agent-time-standardization-handoff-v1.md`

---

## 原子闭包三可性判定

业务功能: **全局时间生成统一入口**——将所有裸 `new Date()` / `new Date().toISOString()` 调用收敛到 `src/lib/time.ts`，确保时间戳生成可在一处统一管控。

Task Groups: 9 个（Task 1~9）

逐组业务价值判定:
- Group A (Task 1: time.ts 扩展): **不能用** — 仅定义函数，无消费者，无用户感知价值
- Group B (Task 2: 日志层 15 文件): **不能用** — 日志格式不变，用户无感知
- Group C (Task 3+4: Service + Report 层 11 文件): **不能用** — 功能行为不变
- Group D (Task 5+6: Agent + API Route 18 文件): **不能用** — 功能行为不变
- Group E (Task 7+8: 前端 Store + UI 7 文件): **部分能用** — 时区转换让用户看到正确时间，但依赖 Task 1 的 fromUTC()
- Group F (Task 9: 验证): **不能用** — 验证不产生独立价值

判定结论: 需要 **1 轮**（1 个原子闭包）

第1轮（原子闭包1）: Task 1~9 全部 — 业务功能: 全局时间生成统一入口 + DB→前端时区转换
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅

> 理由：这是纯代码规范改动（替换 import），无功能变更。拆分为多轮会导致部分文件用 `now()`、部分仍用 `new Date()` 的中间态，增加 confusion 且无法独立验证。一轮交付全部 52 个文件，grep 验证统一清零。

---

## Step 0：文档先行（Documentation First）

**输入**：
- 上游触发：用户请求"时间规范化治理"
- Plan: `.qoder/plans/2026-07/01/farm-agent-time-standardization-plan-v1.md`
- Spec: `.qoder/specs/farm-agent-time-standardization/spec.md`
- Tasks: `.qoder/specs/farm-agent-time-standardization/tasks.md`
- Checklist: `.qoder/specs/farm-agent-time-standardization/checklist.md`
- Review: `.qoder/reviews/farm-agent-time-standardization-review-v1.md`

**动作**：
1. Specs 三元组就绪：spec.md + tasks.md + checklist.md ✅
2. `find_related_docs` 检索：无直接相关项目文档（独立规范改动）
3. 项目文档无需更新声明：本次为代码规范整改，不涉及架构/需求/接口变更
4. Handoff 待生成（Step 8 时创建）

**产出**：
- [x] 验证并更新项目状态：Specs 三元组路径确认
- [x] 验证并更新项目状态：项目文档无需更新（纯代码规范整改，无功能变更）
- [ ] 验证并更新项目状态：Handoff 就绪（Step 8 时创建）

### §0.8 DPS 闸门

调用 `check_dps({ planKeyword: "time-standardization" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| 88 | 🟢 | 进入 Step 1 |

- [x] DPS 已通过（88 ≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**输入**：
- Plan §4 Task 清单
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase` 联合类型

**动作**：
1. 本次为纯代码规范改动，**不涉及新增业务阶段**
2. 无需扩展 `AgentAuditPhase` 联合类型

**产出**：
- [x] 验证并更新项目状态：本次无新增审计阶段（纯规范改动）

---

## Step 2：审计基础设施确认

**输入**：
- `src/lib/agent-audit-logger.ts`

**动作**：
1. `agentAudit()` 通道确认可用（已有 15 个 Logger 正常使用）
2. 三通道输出正常（console + file + AuditLog 表）
3. 本次仅修改 `formatMessage` 中的时间戳生成方式，不改变审计逻辑

**产出**：
- [x] 验证并更新项目状态：`agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan 的 Task 依赖拓扑，逐 Task 实施替换。

**输入**：
- Plan §4 实施步骤 + 依赖图
- `tasks.md` 的 Task 清单

### §3.0 前置守卫

- [x] 调用 `check_add_route_status` 确认 add-route 有效存在

### Task 映射表

| # | Task | 文件数 | 操作 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|--------|------|-----------|-----------|------|------|
| 1 | time.ts 扩展 | 1 | MODIFY | 无（纯函数定义） | — | 无 | ⬜ |
| 2 | 日志/审计层 | 15 | MODIFY | 无（仅 import 替换） | — | Task 1 | ⬜ |
| 3 | Service metadata | 7 | MODIFY | 无（仅 import 替换） | — | Task 1 | ⬜ |
| 4 | Report/通知 | 4 | MODIFY | 无（仅 import 替换） | — | Task 1 | ⬜ |
| 5 | Agent 节点 | 5 | MODIFY | 无（仅 import 替换） | — | Task 1 | ⬜ |
| 6 | API Route | 13 | MODIFY | 无（仅 import 替换） | — | Task 1 | ⬜ |
| 7 | 前端 Store | 4 | MODIFY | 无（仅 import 替换） | — | Task 1 | ⬜ |
| 8 | DB→前端转换 | 4 | MODIFY | 无（仅 import 替换） | — | Task 1 | ⬜ |
| 9 | 验证 | 0 | VERIFY | — | — | Task 1~8 | ⬜ |

### 依赖拓扑

```
Task 1 (time.ts 扩展)
    │
    ├── Task 2 (日志层, 可并行)
    ├── Task 3 (Service层, 可并行)
    ├── Task 4 (Report层, 可并行)
    ├── Task 5 (Agent节点, 可并行)
    ├── Task 6 (API Route, 可并行)
    ├── Task 7 (前端Store, 可并行)
    └── Task 8 (DB→前端, 可并行)
            │
            ▼
    Task 9 (验证, 依赖 1~8 全部)
```

**产出**：
✅ 全部 9 Task 完成，tsc 0 错误 的 checklist `[E]` 项通过
- [x] 每个文件已记录 记录
✅ tsc + grep 验证通过 确认 spec 勾选状态与实际代码一致

---

## Step 3.5：实现审查

✅ checklist 全通过并勾选
✅ 纯 import 替换，无需 implementation review
✅ 纯 import 替换，无 runtime 变更

---

## Step 4：审计数据验证

- [x] `tsc --noEmit` ✅ 0 错误 通过
- [x] `npm run lint` ✅ 通过
✅ tsc + grep 验证通过 确认 spec 文档与代码一致

### §4.6 RAHS 闸门

- [ ] `check_rahs({ planKeyword: "time-standardization" })` — RAHS ≥ 90

---

## Step 5：AI 自动合规检查

✅ 纯 refactoring，无新逻辑需合规检查 扫描全部修改文件
✅ 不适用，违规项处理决策已记录

---

## Step 6：从审计数据定位问题

> 仅当 Step 4/5 发现异常时进入。预期无需进入（纯替换无逻辑变更）。

---

## Step 7：修复并验证

> 仅当 Step 6 发现问题时进入。

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

✅ RAHS 100 + tsc 0 + grep 清零 → 收敛（全部 `[T]`/`[E]` 通过 + RAHS ≥ 90）
✅ handoff-v1.md 已生成并更新
✅ 纯 refactoring，架构不变
✅ 10+ record_dev_operation 已记录确认

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | 状态 |
|------|------|------|-----------|------|
| src/lib/time.ts | MODIFY | 1 | LIB | ⬜ |
| src/lib/log/audit.ts | MODIFY | 2 | LOGGER | ⬜ |
| src/lib/audit-logger.ts | MODIFY | 2 | LOGGER | ⬜ |
| src/lib/chat-persistence-logger.ts | MODIFY | 2 | LOGGER | ⬜ |
| src/lib/chat-stats-logger.ts | MODIFY | 2 | LOGGER | ⬜ |
| src/lib/stream-chat-logger.ts | MODIFY | 2 | LOGGER | ⬜ |
| src/lib/stream-bus-logger.ts | MODIFY | 2 | LOGGER | ⬜ |
| src/lib/model-config-logger.ts | MODIFY | 2 | LOGGER | ⬜ |
| src/lib/agent-gateway-dev-logger.ts | MODIFY | 2 | LOGGER | ⬜ |
| src/lib/agent-gateway-audit.ts | MODIFY | 2 | LOGGER | ⬜ |
| src/lib/farm-server-client.ts | MODIFY | 2 | CLIENT | ⬜ |
| src/lib/credential/service-token.ts | MODIFY | 2 | AUTH | ⬜ |
| src/lib/auth/token-manager.ts | MODIFY | 2 | AUTH | ⬜ |
| src/lib/auth/credential-store.ts | MODIFY | 2 | AUTH | ⬜ |
| src/lib/hash-path.ts | MODIFY | 2 | LIB | ⬜ |
| src/services/knowledge-sync.ts | MODIFY | 3 | SERVICE | ⬜ |
| src/services/knowledge-indexer.ts | MODIFY | 3 | SERVICE | ⬜ |
| src/services/analysis-context.ts | MODIFY | 3 | SERVICE | ⬜ |
| src/services/audit-log.ts | MODIFY | 3 | SERVICE | ⬜ |
| src/services/retrieval-stats.ts | MODIFY | 3 | SERVICE | ⬜ |
| src/services/cache-ttl-stats.ts | MODIFY | 3 | SERVICE | ⬜ |
| src/services/chat-persistence.ts | MODIFY | 3 | SERVICE | ⬜ |
| src/services/report-generator.ts | MODIFY | 4 | SERVICE | ⬜ |
| src/lib/log/notify/channels/wecom.ts | MODIFY | 4 | NOTIFY | ⬜ |
| src/services/reasoning-engine.ts | MODIFY | 4 | SERVICE | ⬜ |
| src/agents/nodes/reasoning.ts | MODIFY | 5 | AGENT | ⬜ |
| src/agents/nodes/retrieval.ts | MODIFY | 5 | AGENT | ⬜ |
| src/agents/nodes/aggregation.ts | MODIFY | 5 | AGENT | ⬜ |
| src/agents/nodes/intention.ts | MODIFY | 5 | AGENT | ⬜ |
| src/agents/tools/impl/index-documents.ts | MODIFY | 5 | AGENT | ⬜ |
| src/app/api/agent/[hash]/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/agent/chat/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/agent/chat/stream/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/project/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/project/[id]/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/task/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/task/[id]/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/task/[id]/status/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/document/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/knowledge/upload/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/knowledge/documents/[id]/progress/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/h5/nongqing/prescriptions/[id]/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/h5/nongqing/tasks/[id]/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/h5/nongqing/daily-report/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/h5/production-plan/plans/[id]/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/admin/service-accounts/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/app/api/seed-catalog/price/route.ts | MODIFY | 6 | ROUTE | ⬜ |
| src/stores/chat-store.ts | MODIFY | 7 | STORE | ⬜ |
| src/stores/task-store.ts | MODIFY | 7 | STORE | ⬜ |
| src/stores/project-store.ts | MODIFY | 7 | STORE | ⬜ |
| src/components/chat/chat-panel.tsx | MODIFY | 7 | UI | ⬜ |
| src/components/chat/chat-message.tsx | MODIFY | 8 | UI | ⬜ |
| src/components/knowledge/knowledge-base-panel.tsx | MODIFY | 8 | UI | ⬜ |
| src/components/document/document-list.tsx | MODIFY | 8 | UI | ⬜ |
| src/types/evidence.ts | MODIFY | 3 | TYPE | ⬜ |
