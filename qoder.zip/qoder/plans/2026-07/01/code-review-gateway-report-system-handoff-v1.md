# farm-agent — Reports 文档体系 + Gateway 边界报告链路 交接手册

> **适用场景**：单轮变更 — 建立 Reports 文档体系，纠正 Gateway 运行时报告链路

---

## 1. 交接前状态

- `.qoder/reviews/` 混放了 Review 文件和 Gateway 运行时发现文件（`farm-agent-review-runtime.md`）
- `appendRuntimeFinding()` 盲目追加到 `review-runtime.md`，无去重、无语义化标题
- Reports（`code-review-combined-report.md` 等）与 Runtime Findings 互不知晓
- 缺少 Report 模板和工作流文档
- 时间戳散落使用 `new Date().toISOString()`，无统一管理

---

## 2. 交接后状态（目标）

- Review 归 `.qoder/reviews/`，Report 归 `.qoder/reports/`
- `farm-agent-runtime-report/` 按子系统目录分类（gateway / rag / agent）
- 边界异常 → 去重 → 语义化标题 → Issue 草稿 → AuditLog traceId 追踪 闭环
- 三层时间函数：`now()` (UTC/DB) + `reportNow()` (+08:00/Report)
- `check-boundary-report.ts` 分组去重输出
- 每日 2:10 AM 自动生成 `reports/index.md`（独立 cron）

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `.qoder/reports/farm-agent-runtime-report/gateway.md` | RENAME | reviews/ 迁入，模板对齐 |
| 2 | `.qoder/reports/REPORT-WORKFLOW.md` | CREATE | Report 生命周期 + 工作流 |
| 3 | `.qoder/reports/boundary-runtime-report.md` | CREATE | Runtime ↔ 静态 Report 边界 |
| 4 | `.qoder/reports/index.md` | CREATE | 自动索引 |
| 5 | `.qoder/templates/report-template.md` | CREATE | 综合审查报告模板 |
| 6 | `.qoder/templates/fix-verification-template.md` | CREATE | 修复验证对照模板 |
| 7 | `.qoder/templates/runtime-report-template.md` | CREATE | 运行时报告模板 |
| 8 | `scripts/gen-report-index.sh` | CREATE | 索引脚本 |
| 9 | `scripts/crontab.report.txt` | CREATE | 独立 cron |
| 10 | `scripts/check-boundary-report.ts` | RENAME/MODIFY | 分组去重输出 |
| 11 | `src/lib/append-runtime-finding.ts` | MODIFY | 标题语义化 + 去重 + Issue草稿 + traceId + 时间分层 |
| 12 | `src/lib/append-runtime-finding-light.ts` | MODIFY | 切 `now()` |
| 13 | `src/lib/time.ts` | CREATE | 项目级时间工具 |
| 14 | `src/proxy.ts` | MODIFY | hash 失败走 boundary report |
| 15 | `src/app/api/agent/[hash]/route.ts` | MODIFY | 未知 action/JSON 解析失败走 boundary report |

---

## 4. 核心设计决策

### 概念分层

| 概念 | 位置 | 说明 |
|------|------|------|
| Review | `.qoder/reviews/` | Plan 管线，归 Plan 管理 |
| Report | `.qoder/reports/` | 综合审查 / 修复验证 / 运行时报告 |
| Runtime Report | `.qoder/reports/farm-agent-runtime-report/` | 按子系统目录 |

### Gateway 只是 Runtime Report 的一个子系统

```
farm-agent-runtime-report/
├── gateway.md  ← 边界合约断裂
├── rag.md      ← RAG 检索异常（预留）
└── agent.md    ← Agent Node 执行（预留）
```

### 边界异常 → Report Issue 闭环

```
运行时异常 → appendRuntimeFinding()
  ├─ AuditLog (UTC, traceId=route_xxx)
  ├─ gateway.md (reportNow, 去重, 语义化标题)
  └─ runtime-issue-{date}-{seq}.md (草稿)
       → combined-report.md (合并, 分级)
```

### 时间分层

| 层 | 函数 | 格式 | 用途 |
|----|------|------|------|
| DB | `now()` | UTC ISO 8601 | AuditLog |
| Report | `reportNow()` | +08:00 ISO 8601 | gateway.md、Issue草稿、Console |

### 去重

- 内存队列：60s 窗口，source+error
- 文件写入：签名 `source::path::error` 命中跳过
- 终端输出：check-boundary-report.ts 按 source+error 分组 ×n

---

## 5. 回滚方案

```bash
# 代码回滚: 还原 append-runtime-finding.ts + proxy.ts + route.ts
git checkout HEAD~1 -- src/lib/append-runtime-finding.ts src/proxy.ts

# Report 文件不影响运行时，无需回滚
```

---

## 6. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| proxy.ts 动态 import `appendRuntimeFinding` 可能在 middleware 环境失败 | hash 失败不走 boundary report | 已有 try/catch 且不影响主流程 |
| 大文件去重需全量读取 | 文件增长后去重变慢 | 签名在 HTML comment 中，grep 即可 |

---

## 7. 恢复上下文审计查询

```text
query_audit_logs({ keyword: "RUNTIME_ERROR" })
```
→ 预期返回 boundary report 相关记录

---

## 8. 后置确认

- [x] `curl /api/agent/test123` → gateway.md 新增语义化条目
- [x] 同请求再次触发 → 去重生效
- [x] Issue 草稿自动生成，含 traceId
- [x] `check-boundary-report.ts` 输出 `28 个（去重后 4 种）`
- [x] Issue 草稿时间 `+08:00`，AuditLog 时间 UTC

---

## 9. 开发日志

### 2026-07-01 — Reports 文档体系搭建 + Gateway 边界报告链路纠正

**触发**: Code Review #6-#9 中日志模块和 Gateway 审计的问题

**执行**:
1. 梳理概念边界：Review 归 Plan，Report 归 Reports
2. 移动 `farm-agent-review-runtime.md` → `farm-agent-runtime-report/gateway.md`
3. 创建 Report 工作流文档、三类模板、索引脚本
4. 纠正 `appendRuntimeFinding`：语义化标题 + 文件去重 + Issue 草稿生成 + traceId 前缀
5. 创建 `time.ts` 统一时间函数（now / reportNow）
6. proxy.ts + route.ts 补横切埋点

**验证**:
- ✅ 去重生效：28 条发现，重复请求不追加
- ✅ 语义化标题：`route /api/agent/test123: 未知 GET action: null`
- ✅ Issue 草稿：`runtime-issue-20260701-01.md`，traceId=`route_xxx`
- ✅ 时间分层：Report `+08:00`，AuditLog UTC
- ✅ check-boundary-report：`28 个（去重后 4 种）`
