# gateway-runtime-fix-service-accounts-prisma-init-plan-v1

> **PLAN 元信息**
> - **来源**: `runtime-issue-20260624-01.md`（Gateway 边界报告）
> - **启动时间**: 2026-07-01
> - **关联文档**:
>   - Runtime Issue: `.qoder/reports/runtime-issue-20260624-01.md`
>   - Gateway Report: `.qoder/reports/farm-agent-runtime-report/gateway.md`

---

## 一、背景

Gateway 边界报告捕获到 `PUT /api/admin/service-accounts` 出现：

```
Cannot read properties of undefined (reading 'findUnique')
```

发生 2 次，集中在 6/24。表明 Prisma client 在请求处理时未初始化。

## 二、根因（初始诊断）

`src/app/api/admin/service-accounts/route.ts` 使用 Prisma 但可能：

1. 热更新时 Prisma singleton 丢失引用
2. `import { prisma } from "@/lib/prisma"` 在 middleware 环境下未正确初始化
3. Next.js 编译缓存导致 stale 引用

## 三、方案（初始）

1. 检查 `src/lib/prisma.ts` 的全局单例模式是否健壮
2. 在 `service-accounts/route.ts` 的 Prisma 调用处增加 `if (!prisma) throw` 守卫
3. 如为热更新问题，增加 `globalForPrisma` 模式（参照其他模块的 `globalForXxx` 写法）

## 四、改动范围（初始）

| 文件 | 改动 |
|------|------|
| `src/lib/prisma.ts` | 检查全局单例 |
| `src/app/api/admin/service-accounts/route.ts` | 增加 prisma 可用性守卫 |

---

## 🔄 Review 回流（2026-07-01）

> 以下为代码审查和 git 历史回溯后的修正诊断。

### 修正根因

**初始诊断 §二 的三条均不成立：**
- `src/lib/prisma.ts` 已有 `globalForPrisma` 模式（L3-L8），单例健壮
- 错误不是 `prisma` 本身为 undefined，而是 `prisma.serviceAccount` 为 undefined，`if (!prisma) throw` 守卫无效
- 堆栈指向 `.next/dev/server/chunks/`，是 Prisma Client 未包含 `ServiceAccount` 模型

**真正根因有两条：**

#### ① 迁移 SQL 不幂等

`prisma migrate dev` 生成的 SQL 默认不带幂等守卫：

```sql
-- Prisma 默认生成（危险）
CREATE TABLE "X" (...);           -- 没有 IF NOT EXISTS
DROP TABLE "ServiceAccount";      -- 没有 IF EXISTS
ALTER TABLE "X" DROP COLUMN "y";  -- 没有 IF EXISTS
```

证据：6/24 的迁移 `20260624080456` 原为 `DROP ALL` 24 张表（含 `DROP TABLE "ServiceAccount"`），在 commit `f5c4e7b` 才替换为安全空操作。

#### ② CI 部署时序有竞态窗口

当前 `.gitlab-ci.yml` deploy 阶段：

```
pm2 running（旧 Client 处理请求）
  → prisma migrate deploy（迁移在旧 Client 脚下改表）
  → prisma generate
  → pm2 restart
```

旧 Prisma Client 在迁移执行期间仍在运行。如果迁移做了 DROP/ALTER，旧 Client 可能访问已被删除的表或列。

### 修正方案

#### A. 部署时序：先停服再迁移 + 维护模式

```
POST /api/admin/maintenance (开启维护模式，后续请求返回 503)
  → sleep 2s（等待活跃请求结束）
  → pm2 stop farm-agent
  → prisma migrate deploy（安全，无 Client 运行）
  → prisma generate
  → pm2 start farm-agent（新进程，维护模式自动清除）
```

维护模式通过 `globalThis.__MAINTENANCE__` 在 middleware 层拦截所有请求，返回 `{ code: 503, message: "服务升级中，请稍后重试" }`。pm2 stop/start 天然清除状态。

#### B. 迁移幂等闸门

`db-ensure.prod.sh` 中，`prisma migrate deploy` 之前扫描待执行的 migration SQL，拒绝不含 `IF NOT EXISTS` / `IF EXISTS` 的 DDL。

### 修正改动范围

| 文件 | 改动 |
|------|------|
| `src/proxy.ts` | **新建维护模式**：`globalThis.__MAINTENANCE__` 拦截全路由返回 503，matcher 扩展至 `/(.*)` |
| `src/app/api/admin/maintenance/route.ts` | **新建**：POST 开启/关闭维护模式，GET 查询状态 |
| `.gitlab-ci.yml:deploy` | `curl POST 开启维护` → `sleep 2s` → `pm2 stop` → `migrate deploy` → `generate` → `pm2 start` |
| `scripts/db-ensure.prod.sh` | 增加迁移 SQL 幂等性扫描 |

> ~~`src/lib/prisma.ts` / `route.ts` 的初始改动~~ → 不采纳，根因不在此。

## 五、验证

- [x] CI deploy 阶段先停服再迁移（`.gitlab-ci.yml` 维护模式 → stop → migrate → generate → start）
- [x] 幂等闸门拦截不安全的迁移 SQL（`db-ensure.prod.sh` 增加 DDL 扫描）
- [x] `PUT /api/admin/service-accounts` 不再出现 findUnique undefined（commit `3d811e8`，gateway.md 已写入验证条目）
