# farm-agent-log-audit-unify-handoff-v1

> 绑定 Plan: `farm-agent-log-audit-unify-plan-v3.md` · Review: `farm-agent-log-audit-unify-review-v1.md`

---

## 你当前的位置

你是本 Plan 的唯一实施轮次。上游已完成 Plan/Review/Specs 三元组 + DPS 88 通过。本轮完成全部 4 个 Atom 实施。

---

## 上游已完成

- Plan v3: `.qoder/plans/2026-07/01/farm-agent-log-audit-unify-plan-v3.md`
- Review: `.qoder/reviews/farm-agent-log-audit-unify-review-v1.md`
- Specs: `.qoder/specs/farm-agent-log-audit-unify/` (spec.md + tasks.md + checklist.md)
- add-route: `.qoder/plans/2026-07/01/farm-agent-log-audit-unify-add-route-v1.md`

---

## 你要改的文件

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/lib/log/file-writer.ts` | CREATE | LogFileWriter + LazyLogFileWriter |
| `src/lib/log/gateway-audit.ts` | CREATE | auditGatewayRequest 纯函数 + GatewayPhase/GatewaySource 枚举 |
| `src/lib/log/index.ts` | MODIFY | 导出 auditGatewayRequest + GatewayPhase + GatewaySource |
| `src/lib/log/audit.ts` | MODIFY | 迁移到 LogFileWriter |
| `src/lib/audit-logger.ts` | MODIFY | 迁移到 LogFileWriter |
| `src/lib/chat-persistence-logger.ts` | MODIFY | 迁移到 LogFileWriter |
| `src/lib/stream-bus-logger.ts` | MODIFY | 迁移到 LogFileWriter |
| `src/lib/stream-chat-logger.ts` | MODIFY | 迁移到 LogFileWriter |
| `src/lib/chat-stats-logger.ts` | MODIFY | 迁移到 LazyLogFileWriter |
| `src/lib/model-config-logger.ts` | MODIFY | 迁移到 LazyLogFileWriter |
| `src/lib/time.ts` | MODIFY | 新增 nowMs() |
| `src/app/api/agent/[hash]/route.ts` | MODIFY | 手动手动四件套 → auditGatewayRequest 一行 |
| `src/app/api/h5/** (13 routes)` | MODIFY | 新增 gateway 审计 |
| `src/app/api/audit/route.ts` | MODIFY | 直查 Prisma |
| `src/services/audit-log.ts` | DELETE | 死代码 |
| `src/services/index.ts` | MODIFY | 删除 audit-log 导出 |
| `src/agents/index.ts` | MODIFY | 563行 → 10行 re-export |
| `src/agents/tracer-store.ts` | CREATE | activeTracers + cleanup |
| `src/agents/tracer.ts` | CREATE | getActiveTracer + start/endChainTrace |
| `src/agents/tool-node-wrapper.ts` | CREATE | createToolNodeWrapper |
| `src/agents/audit-wrapper.ts` | CREATE | wrapNodeWithAudit |
| `src/agents/agent-graph.ts` | CREATE | StateGraph 构建 |
| `src/agents/agent-runner.ts` | CREATE | runAgent + streamAgent |

---

## 核心设计

### 日志分层

```
Gateway 审计 (auditGatewayRequest)
  ├─ console + writeAuditLog (无 file)
  ├─ GatewayPhase: REQUEST | PARAM_ERROR | ERROR
  └─ GatewaySource: HASH | H5

Agent 业务审计 (agentAudit → LogFileWriter + writeAuditLog)
  ├─ console + JSONL file + DB
  └─ 8 logger 共用 LogFileWriter

DB 写入 (writeAuditLog)
  └─ 唯一入口，含 getLogUserId() + traceId 兜底 + 失败告警
```

### Gateway 错误分级

| 级别 | 场景 | 审计方式 |
|------|------|---------|
| REQUEST | 正常成功 | `auditGatewayRequest({phase:REQUEST,...})` |
| PARAM_ERROR | 400/404 业务拒绝 | `auditGatewayRequest({phase:PARAM_ERROR,...})` |
| ERROR | catch 块系统异常 | `auditGatewayRequest({phase:ERROR,...})` |
| unhandled | 未捕获异常 | `appendRuntimeFinding` (hardening plan 负责) |

---

## 关键契约

1. `writeAuditLog()` 是唯一 DB 写入入口，不可绕过（ESLint 强制）
2. Gateway 审计不写 file 日志，不 await DB 写入（fire-and-forget）
3. `auditGatewayRequest` 不调用 `appendRuntimeFinding`（hardening plan 领地）
4. 所有导入 `@/agents` 的外部引用无需修改（index.ts 保留 re-export）
5. 所有计时使用 `nowMs()` from `@/lib/time`

---

## 高风险误区

- ❌ 不要在新代码中写 `prisma.auditLog.create`（ESLint 禁止）
- ❌ 不要在 gateway 审计中调用 `appendRuntimeFinding`
- ❌ 不要把 GatewayPhase 字面量写回 string（已改为 enum）
- ❌ 不要把 `Date.now()` 用于计时（改用 `nowMs()`）

---

## 恢复上下文审计查询

```text
// 一键恢复
query_audit_logs({ planKeyword: "log-audit-unify" })

// 按文件查
query_audit_logs({ targetId: "src/lib/log/file-writer.ts" })
query_audit_logs({ targetId: "src/lib/log/gateway-audit.ts" })
query_audit_logs({ targetId: "src/agents/agent-graph.ts" })
query_audit_logs({ targetId: "src/app/api/agent/[hash]/route.ts" })
```

---

## 完成状态

- [x] Atom 1: LogFileWriter + 8 logger 迁移
- [x] Atom 2: Gateway 审计纯函数 + agent 8 handler + h5 13 路由
- [x] Atom 3: 删除 audit-log.ts
- [x] Atom 4: agents/index.ts 拆分为 7 文件
- [x] tsc --noEmit = 0
- [x] DPS = 88 🟢
- [x] RAHS = 100 🟢
- [x] devlog 已写 (record_dev_operation)
