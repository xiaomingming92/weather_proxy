# gateway-runtime-fix-service-accounts-contract-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。简单修复（移除合约断言），单 Task。
>
> **绑定**：Plan: `gateway-runtime-fix-service-accounts-contract-plan-v1.md`

---

## Step 0：文档先行（Documentation First）

**目的**：确认 Plan 就绪，本次变更为单行修复无需 Specs 三元组。

**输入**：
- Plan: `gateway-runtime-fix-service-accounts-contract-plan-v1.md`
- Runtime Issue: `.qoder/reports/runtime-issue-20260622-01.md`

**动作**：
1. ✅ Plan 已就绪（v1）
2. 单行修复，无需 Specs 三元组（无新增行为，仅移除误判合约断言）
3. 无需更新项目文档（纯运行时纠偏，不改变 API 契约）

**产出**：
- [x] Plan 就绪
- [x] 无需 Specs（单行修复）
- [ ] Handoff 待创建

---

## Step 1-2：审计阶段（跳过）

单行修复无新增业务阶段，审计基础设施不变，跳过 Step 1/2。

---

## Step 3：业务逻辑实现与审计植入

**目的**：移除 PUT /api/admin/service-accounts 的合约断言。

**输入**：
- Plan §3 方案：移除合约断言
- 文件：`src/app/api/admin/service-accounts/route.ts:112`

### Task 映射表

| # | Task | 文件 | 改动 | 依赖 | 状态 |
|---|------|------|------|------|------|
| 1 | 移除 PUT 路由的 contract 参数 | `src/app/api/admin/service-accounts/route.ts` | 从 `appendRuntimeFinding(null, { ... contract: {...} })` 中移除 `contract` 字段 | 无 | ⬜ |

### 依赖拓扑

```
Task 1（独立，无依赖）
```

### 改动细节

**当前代码（L112）**：
```typescript
appendRuntimeFinding(null, { source: "route", requestInfo: { method: "PUT", pathname: "/api/admin/service-accounts" }, contract: { expected: "轮换成功(5min宽限)", actual: name } })
```

**改为**：
```typescript
appendRuntimeFinding(null, { source: "route", requestInfo: { method: "PUT", pathname: "/api/admin/service-accounts" } })
```

**产出**：
- [ ] Task 1 完成

---

## Step 4：审计数据验证

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. 验证 `contract` 为可选字段，移除后不影响类型

**产出**：
- [ ] `tsc --noEmit` 通过
- [ ] 无类型错误

---

## Step 5-7：合规检查（跳过）

单行修复，无新增审计点，跳过合规深度检查。

---

## Step 8：收敛判断

**动作**：
1. 确认修改已应用
2. 写 devlog日志(走mcp)
3. 更新 handoff

**产出**：
- [ ] 修改已应用
- [ ] devlog 已写
- [ ] handoff 已更新

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType |
|------|------|------|-----------|
| `src/app/api/admin/service-accounts/route.ts` | MODIFY | Task 1 | API_ROUTE |
