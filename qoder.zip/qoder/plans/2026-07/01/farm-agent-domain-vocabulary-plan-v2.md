# farm-agent-domain-vocabulary-plan-v2

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。不要写完整实现——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-domain-vocabulary-v2
- **启动时间**: 2026-07-01T12:00:00+08:00
- **DPS 状态**: 🟢 88 分 PASS（2026-07-02）
- **主导 AI**: Qoder
- **前置 Plan**: [farm-agent-domain-vocabulary-plan-v1.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-plan-v1.md)（✅ 已完成 2026-06-26）
- **关联 Plan**: [farm-agent-three-tier-reasoning-graph-plan-v3.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md)（ACA professional 图）
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-07/01/farm-agent-domain-vocabulary-add-route-v2.md`（✅ 已生成 2026-07-02）
  - Handoff: `.qoder/plans/2026-07/01/farm-agent-domain-vocabulary-handoff-v2.md`（待生成）
  - Review: `.qoder/reviews/farm-agent-domain-vocabulary-review-v2.md`（✅ 已完成 2026-07-02）
  - Spec: `.qoder/specs/farm-agent-domain-vocabulary-v2/`（三件套 ✅ 已生成 2026-07-02）
  - 产品触发词源: `src/agents/vocabulary/domain-triggersv2.md`（产品团队提供）
- **v2 变更摘要**:
  1. **触发词升级**：将 v1 的 9-13 条/专家（书面语）替换为产品团队提供的 v2 口语化触发词（80-150 条/专家），覆盖农民真实表达
  2. **2-Tier 语义路由**（Embedding→LLM）：行业验证的 aurelio-labs/semantic-router 方案，替代当前纯 LLM 意图路由。砍掉 Tier 1 规则层——Embedding 模型自带中文语义理解，省去分词复杂度。成本降 ~10x
  3. **触发词定位变更**：触发词从"prompt 注入素材"变为"centroid embedding 源数据"，消除 `slice(0,8)` 截断问题
  4. **联合链路信号**：v2 触发词的自然共现关系（如 crop_compare/variety_recommend 共享 ~40% 触发词）为 Embedding 层 top-K 多候选返回提供语义基础
  5. **centroid 持久化至 ChromaDB**：14 个专家 centroid embedding 写入 ChromaDB，与 RAG 检索走同一通道，重启不丢失
  6. **collectionHints 评估**：确认当前 collectionHints 与 ACA 框架职责边界一致，不需修改

---

## 一、背景与目标

### 1.1 v1 已完成项（不改动）

v1 已交付的基础设施全部保留：
- `src/agents/vocabulary/domain-triggers.ts` 结构与 TypeScript 接口
- `RuntimeInputCategory` 枚举 + factory.ts 分区渲染
- caijuehub 裁决层（`resolve-tool-params.ts`）
- SSE `param_missing` 事件
- intention / reasoning / factory 三个注入点

### 1.2 v2 问题现状

v1 的触发词设计存在三个结构性缺陷，在 v2 产品触发词库发布后暴露：

| # | 缺陷 | 现象 | 根因 |
|---|------|------|------|
| **1** | **覆盖率不足** | 农民说"地里烂根了""叶子有洞"，当前触发词只有"虫害""病害"，LLM 可能漏匹配 | v1 触发词偏书面语（9-13 条/专家），缺少农民口语表达 |
| **2** | **prompt 注入天花板** | v2 产品给了 80-150 条/专家，但 `intention.ts` line 56 `slice(0,8)` 只注入前 8 条，长尾词白加 | 触发词设计为 prompt 输入，但 prompt 有 token 预算上限 |
| **3** | **联合链路无信号** | 用户说"选种"时可能同时需要 crop_compare + variety_recommend，但 v1 触发词没有共现关系，LLM 无法感知联合路由需求 | 触发词设计为独立专家视角，没有跨专家共现标记 |

### 1.3 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | 替换为 v2 产品口语化触发词 | `domain-triggers.ts` 中 13 个专家的触发词替换为 v2 词库（land_analysis 保留 v1 词并标注） |
| P0 | 实现 2-Tier 语义路由（Embedding→LLM） | 新建 `src/agents/router/` 模块，Embedding 层覆盖 ≥85%，LLM fallback ≤15% |
| P1 | 消除 prompt 注入瓶颈 | `intention_async.ts` 不再注入触发词，改为调 Router 获取候选，仅 LLM fallback 时注入 top-3 专家描述 |
| P1 | 支持多专家联合路由 | Router 返回 top-K 候选专家（含置信度），ACA professional 图 fan-out 消费该列表 |
| P2 | 评估并确认 collectionHints 不改 | 结论文档：当前 collectionHints 与 ACA 框架一致，不需修改 |

> **非目标**：不改 v1 的 Storage 层/Category/裁决层/SSE 事件。不改 `collectionHints`（见 §2.4 分析）。

---

## 二、方案选型

### 2.1 行业路由方案对比

| 方案 | 成本 | 延迟 | 覆盖率 | 中文支持 | 结论 |
|------|------|------|--------|----------|------|
| A: 纯 LLM（当前 v1） | 高（~$0.0002/call） | 200-500ms | 依赖 prompt 质量 | prompt 内做中文语义理解 | ❌ v2 触发词 1300+ 条塞不下 prompt |
| B: 3-Tier Cascade（规则→Embedding→LLM） | 低（混合） | 混合 | 90%+ | Tier 1 需中文分词（nodejieba/n-gram）引入额外复杂度 | ⚠️ 规则层对中文不友好 |
| **C: 2-Tier（Embedding→LLM）** | 极低（~$0.00002/call） | 20-50ms | 85%+ | Embedding 模型原生支持中文，零分词依赖 | ✅ **推荐** |

### 2.2 选型理由：2-Tier Embedding + LLM Fallback

来源：[aurelio-labs/semantic-router](https://github.com/aurelio-labs/semantic-router)（GitHub 8k+ stars，行业标准语义路由方案）

```
用户问 "地里烂根了，打什么药"
    │
    ▼ Tier 1: Embedding 相似度（~20-50ms, ~$0.00002）
    ChromaDB 中预存 14 个专家的 centroid embedding
    query embedding（复用 getEmbeddings() 单例，1024 维）
    → ChromaDB 查询 vs 14 个 centroid → cosine 排序
    → top-3: [pest_risk: 0.92, nutrition_diagnose: 0.61, growth_report: 0.43]
    │
    ├── top-1 置信度 > 阈值 且 与 top-2 差距 > margin → 直接返回（覆盖 85-90%）
    │
    ▼ Tier 2: LLM 意图解析（~200-500ms, ~$0.0002）
    prompt 注入 INTENT_SEMANTICS + CROSS_DOMAIN_RULES + top-3 候选专家描述
    LLM 决策最终 expertPlan[]（覆盖 10-15%）
```

| 层 | 成本 | 延迟 | 覆盖率目标 | 技术手段 |
|----|------|------|-----------|---------|
| Tier 1 Embedding | ~$0.00002 | 20-50ms | 85-90% | ChromaDB centroid + cosine |
| Tier 2 LLM | ~$0.0002 | 200-500ms | 10-15% | INTENT_SEMANTICS + CROSS_DOMAIN_RULES + top-3 候选描述 |

**相比 v1（纯 LLM）的改善**：
- 成本：降低 ~10x（85%+ 请求不走 LLM）
- 延迟：P50 从 200ms 降至 20-50ms
- 触发词利用率：1300+ 条全量参与 centroid 构建，不再被 `slice(0,8)` 截断
- 中文：零分词依赖，`text-embedding-v4` 原生支持中文语义

**阈值配置化为 DynamicConfig 读取**（见 §3.7），运行时可在不改代码的情况下通过 API 调整：

```typescript
// embedding.ts — 阈值从 DynamicConfig 动态读取，非硬编码
const threshold = dynamicConfig.get("EMBEDDING_CONFIDENCE_THRESHOLD") ?? 0.5
const margin = dynamicConfig.get("EMBEDDING_MARGIN_THRESHOLD") ?? 0.15
const topK = dynamicConfig.get("EMBEDDING_TOPK") ?? 3
if (topScore > threshold && topScore - secondScore > margin) { ... }
```

```typescript
// src/services/dynamic-config.ts — 初始值（启动时从常量注入）
export const DEFAULT_CONFIG: Record<string, unknown> = {
  EMBEDDING_CONFIDENCE_THRESHOLD: 0.5,
  EMBEDDING_MARGIN_THRESHOLD: 0.15,
  EMBEDDING_TOPK: 3,
}
```

> **行业对照**：aurelio-labs/semantic-router（8k+ stars）所有示例和 notebook 使用 `score_threshold=0.5`，LiteLLM auto-router（10k+ stars）官方示例配置默认 0.5。v2 直接采用两大项目的行业默认值 0.5。
>
> **调优指引**：若 Tier 1 误匹配率高（Router 把不相关的 query 匹配到错误专家），通过 `PUT /api/system/config/EMBEDDING_CONFIDENCE_THRESHOLD` 逐步提高至 0.55→0.6。若 Tier 2 fallback 率 > 30%（太多降级到 LLM），降低至 0.45→0.4。AI 自动调参见 §3.9 闭环。

**为什么砍掉规则层（Tier 1）**：
- 行业实践（aurelio-labs/semantic-router）不做规则匹配，纯 embedding
- 中文分词方案（nodejieba/n-gram/Intl.Segmenter）各有缺陷，维护成本高
- `text-embedding-v4` 1024 维已足够捕捉"烂根→pest_risk"这类语义关联
- 规则层带来的边际收益（$0 成本）不抵复杂度代价——embedding 层已是 ~$0.00002，接近免费

### 2.3 触发词定位变更

| | v1 | v2 |
|---|-----|-----|
| 触发词角色 | prompt 注入素材 | centroid embedding 源数据（写入 ChromaDB） |
| prompt 内容 | `slice(0,8)` 条触发词 | Tier 2 LLM fallback 时注入 top-3 候选专家的 `description` + INTENT_SEMANTICS + CROSS_DOMAIN_RULES |
| 触发词价值 | 给 LLM 做线索 | 给 Embedding 层做语义锚点 |
| 词库越大 | prompt 越臃肿（负面） | centroid 越精准（正面） |

### 2.4 collectionHints 不改的决策依据

经分析确认当前 `collectionHints` 不需修改：

- **ACA 框架职责边界**：检索层故意隔离（每个专家独立查自己的 RAG collection），跨专家推理在 conflictResolver 的结构化输出层面做，不在 RAG 层
- **daily_report/weekly_report** 是 deep 图 isSummary 汇总专家，查 `farm_monitoring` 足够；professional 图的跨域聚合由 `aggregationNode` 负责
- **planting_advice** 在 deep 图只需 `agronomy`；在 professional 图中它作为 fan-out 的一个专家产出自己的 ExpertClaim，子领域由各自专家并行产出

---

## 三、架构设计

### 3.1 新模块：`src/agents/router/`

```
src/agents/router/
  ├── index.ts              # 2-Tier 路由入口: route(query) → RouterResult
  ├── embedding.ts          # Tier 1: ChromaDB centroid 相似度检索
  ├── tier-decider.ts       # 纯函数裁决：根据候选分数决定走 Tier 1 直接返回 / 多候选 / Tier 2 fallback
  ├── llm-fallback.ts       # Tier 2: LLM fallback（调用 intention async prompt）
  ├── centroid-init.ts      # 启动/更新时：从 DOMAIN_TRIGGERS 构建 centroid → 写入 ChromaDB
  └── types.ts              # TierDecision { tier, action, expertIds, candidates, confidence }
```

### 3.2 数据流

```
启动/词库更新时（按需）:
  DOMAIN_TRIGGERS.expertTriggers
    → CentroidInit.build()
      → 每个专家的触发词文本 → getEmbeddings() (text-embedding-v4, 1024 维)
      → 均值池化 → per-expert centroid
      → 写入 ChromaDB collection: "expert_centroids"

运行时（每次请求）:
  userQuery
    → getEmbeddings(query) → query embedding（复用，同时给 RAG 检索）
    → ChromaDB.query(collection="expert_centroids", topK=3, queryEmbedding)
    → top-3: [{ expertId, score }, ...]
    │
    → tier-decider.ts 纯函数裁决：
      ├── top-1 > threshold 且 top-1 − top-2 > margin → action: "direct"（Tier 1 单专家）
      ├── top-1 > threshold 但 top-1 − top-2 < margin → action: "multi-candidate"（Tier 1 联合链路）
      └── top-1 < threshold → action: "fallback"（升级 Tier 2 LLM）
    │
    index.ts 编排：根据 action 分发——
      ├── direct / multi-candidate → 直接返回 RouterResult
      └── fallback → llm-fallback.ts
            prompt = INTENT_SEMANTICS + CROSS_DOMAIN_RULES + top-3 专家描述
            → LLM 决策 expertPlan[]
```

### 3.3 intention_async 体系（新建，仅 professional 图使用）

现有 `intention.ts` 保持不变（deep/simple 图继续用同步 LLM 路由）。新建以下文件构成 professional 图的异步 intention 体系：

| 文件 | 角色 |
|------|------|
| `src/agents/prompts/intention_async.ts` | 异步 prompt 模板，调 `Router.route()` 获取候选，Embedding 命中时跳过 LLM |
| `src/agents/nodes/intention-async.ts` | 异步 LangGraph 节点函数，替代 `intentionNode` 在 professional 图中的位置 |
| `src/agents/prompts/intent-constants.ts` | 共享常量：`INTENT_SEMANTICS` + `CROSS_DOMAIN_RULES`，两方 import |

```typescript
// intention_async.ts - 异步 prompt 模板
async function buildContextBlock(input: IntentionInput): Promise<string> {
  const routerResult = await Router.route(input.userMessage)
  if (routerResult.tier === "llm") {
    // Tier 2 fallback: 注入 INTENT_SEMANTICS + CROSS_DOMAIN_RULES + top-3 描述
    return formatExpertDescriptions(routerResult.candidates)
  }
  // Tier 1 命中：直接构建候选专家上下文，不调 LLM
  return formatDirectMatch(routerResult.candidates)
}

// intention-async.ts - LangGraph 节点函数
// 复用 intentionNode 的大多数逻辑（tool_calls 注入、explicitExpertId 路径、
//   subIntent 激活、关键词兜底），唯一差异：
//   intentionPrompt.build(input)  →  intentionAsyncPrompt.build(input)
export async function intentionAsyncNode(state: typeof AgentState.State) {
  // ... 同 intentionNode，但 prompt 构建走异步
}
```

**与 `intention.ts` 的关系**：
- `intention.ts`：同步，deep/simple 图，LLM 直接做意图解析 → 不改（仅 import 改为从 intent-constants）
- `intention_async.ts`：异步 prompt 模板，professional 图，Router 路由 → LLM fallback → 新建
- `intention-async.ts`：异步 LangGraph 节点，professional 图 → 新建
- 三者共享 `INTENT_SEMANTICS` 和 `CROSS_DOMAIN_RULES` 常量

### 3.4 agent-graph.ts wiring 变更

两个图当前的 `intention` 节点指向同一个 `intentionNode` 函数。v2 后 professional 图独立走 `intentionAsyncNode`：

```diff
// src/agents/agent-graph.ts
  const professionalWorkflow = new StateGraph(AgentState)
  professionalWorkflow
-   .addNode("intention", async (state, config) => {
-     return wrapNodeWithAudit("intention", state, intentionNode, config)
-   })
+   .addNode("intention", async (state, config) => {
+     return wrapNodeWithAudit("intention", state, intentionAsyncNode, config)
+   })
```

**不变项**：
- `agent`（deep/simple）图的 wiring 完全不变
- 路由边 `routeByIntent` 不变——`intentionAsyncNode` 返回相同的 `currentTask.intent` + `currentTask.thinkingLevel`
- toolNode → intention 的回边不变

### 3.5 与 ACA professional 图的关系

```
Router.route("选个高产的品种")
  → ChromaDB centroid 查询
  → top-3: [crop_compare: 0.88, variety_recommend: 0.85, planting_advice: 0.52]
  → 前两者置信度接近 + 联合链路信号 → 返回 [crop_compare, variety_recommend]

intention_async 节点（professional 图）:
  → 消费 RouterResult.expertIds
  → 产出 expertPlan: [crop_compare, variety_recommend]
  → fan-out 两个专家并行推理
  → conflictResolver 比较两方 ExpertClaim
  → aggregation 合并输出
```

### 3.6 Centroid 存储：ChromaDB 持久化

不使用内存 Map，而是写入 ChromaDB `expert_centroids` collection：

```typescript
// centroid-init.ts
interface ExpertCentroid {
  expertId: string      // "pest_risk"
  label: string         // "病虫害风险"
  embedding: number[]   // 1024 维 centroid
}

async function buildCentroids(): Promise<void> {
  for (const [expertId, triggers] of Object.entries(DOMAIN_TRIGGERS.expertTriggers)) {
    const triggerText = triggers.join("、")  // 所有触发词拼接为一段文本
    const emb = await getEmbeddings(triggerText)  // 1024 维
    const centroid = meanPool(emb)  // 如有多个 batch 取均值
    // 写入 ChromaDB
    await chroma.upsert("expert_centroids", {
      id: expertId,
      embedding: centroid,
      metadata: { label: ANALYSIS_EXPERTS[expertId].label }
    })
  }
}
```

**优势**：
- 与 RAG 检索走同一 ChromaDB 通道，架构一致
- 重启不丢失，无需重新 embedding
- 词库更新时 `upsert` 覆盖即可
- 查询时 ChromaDB 自带 cosine 排序，不需要自己算

### 3.7 动态参数层：DynamicConfig

阈值常量（如 `EMBEDDING_CONFIDENCE_THRESHOLD`）不能硬编码——上线后需要根据 Metrics 反馈动态调整，且调整必须即时生效、可追溯、可回滚。引入统一的 `DynamicConfig` 单例替代硬编码常量：

```typescript
// src/services/dynamic-config.ts

interface ConfigChange {
  key: string
  oldValue: unknown
  newValue: unknown
  timestamp: number
  source: "api" | "ai" | "init"      // 谁改的
}

interface DynamicConfigStore {
  get<T>(key: string): T | undefined                // R
  set<T>(key: string, value: T, source?: "api" | "ai" | "init"): void  // C/U
  getAll(): Record<string, unknown>                 // R（全量）
  delete(key: string): void                         // D
  getHistory(key: string): ConfigChange[]           // 变更链（回滚用）
  onChange(key: string, handler: (change: ConfigChange) => void): () => void  // AI 订阅
}
```

**初始值初始化**：应用启动时从 `types.ts` 常量批量 `set("key", value, "init")` 注入，运行时覆盖内存值：

```typescript
// embedding.ts — 从硬编码迁移到动态读取
const threshold = dynamicConfig.get("EMBEDDING_CONFIDENCE_THRESHOLD") ?? 0.75
if (score > threshold) ...

// API 消费链（人调参）
PUT  /api/system/config/EMBEDDING_CONFIDENCE_THRESHOLD  { "value": 0.65 }
GET  /api/system/config/history/EMBEDDING_CONFIDENCE_THRESHOLD  → 变更链

// AI 消费链（policy-update-loop 订阅）
dynamicConfig.onChange("EMBEDDING_CONFIDENCE_THRESHOLD", (change) => {
  agentAudit("CONFIG_CHANGE", `threshold ${change.oldValue}→${change.newValue} by ${change.source}`)
})
```

**与现有 `GlobalStateProvider` 的关系**：`GlobalStateProvider` 管理 Agent 运行时状态（每个 request 的 context），`DynamicConfig` 管理系统级可调参数（跨 request 的配置）。两者正交——前者是 Request Scope，后者是 Application Scope。

### 3.8 可观测收集层：MetricsRegistry

有了可调参数，还需要运行时指标来判断"调没调对"。引入统一的 `MetricsRegistry` 单例，任意模块注册自己的 Collector，支持人类（API 查询）和 AI（policy-update-loop 输入）双消费路径：

```typescript
// src/services/metrics-registry.ts

interface MetricsSnapshot {
  name: string                       // "router"
  counters: Record<string, number>   // tier1Hits: 423
  gauges: Record<string, number>     // p95LatencyMs: 280
  distributions: Record<string, number[]>  // confidenceSamples: [...]
  windowSize: number
  lastResetAt: number
}

interface MetricsCollector {
  readonly name: string
  incr(key: string, delta?: number): void          // C/U（计数器）
  gauge(key: string, value: number): void          // C/U（瞬时值）
  observe(key: string, value: number): void        // C/U（分布样本）
  snapshot(): MetricsSnapshot                      // R（快照，不清零）
  reset(): void                                    // D（窗口切换）
}

interface MetricsRegistry {
  register(name: string): MetricsCollector         // C
  unregister(name: string): void                   // D
  snapshot(name: string): MetricsSnapshot | null   // R（按名）
  snapshotAll(): MetricsSnapshot[]                 // R（全量）
  getCounter(name: string, key: string): number    // R（AI 消费，单值）
}
```

**Router 接入示例（~5 行）**：

```typescript
const routerMetrics = metricsRegistry.register("router")
routerMetrics.incr(result.tier === 1 ? "tier1Hits" : "tier2Fallbacks")
routerMetrics.gauge("lastLatencyMs", latencyMs)
routerMetrics.incr(`expert_${result.expertIds[0]}`)
routerMetrics.observe("confidenceSamples", result.confidence)
```

**双消费路径**：

| 消费者 | 方式 | 实现 |
|--------|------|------|
| 人 | `GET /api/system/metrics/router` → JSON | API route 调 `snapshot("router")` |
| AI | `policy-update-loop.evaluate()` 新输入 | 调 `getCounter("router", "tier2FallbackRate")` 作为决策输入 |

**与现有 `CognitiveEventBus` / `PolicyUpdateLoop` 的范式一致性**：三者都是单例注册 + 按名查询。EventBus 是 push（订阅者被动接收），MetricsRegistry 是 pull（消费者主动查询），DynamicConfig 是 read/write（随时读写）。三者共用同一架构范式，零新依赖。

### 3.9 调参闭环：MetricsRegistry → policy-update-loop

以上两个消费者（人 + AI）通过同一基础设施（DynamicConfig + MetricsRegistry）形成双闭环：

```
┌─────────────────────────────────────────────────────────┐
│                    人 工 调 参                              │
│  GET /api/system/metrics/router → 看指标                   │
│  PUT /api/system/config/EMBEDDING_CONFIDENCE_THRESHOLD    │
└────────────────────────┬────────────────────────────────┘
                         │ 人决策，手动调
                         ▼
┌─────────────────────────────────────────────────────────┐
│                  DynamicConfig                            │
│  get("EMBEDDING_CONFIDENCE_THRESHOLD") ← embedding.ts 读  │
│  set(key, value, "api")                  ← 人/API 写      │
│  set(key, value, "ai")                   ← policy 写     │
└────────────────────────┬────────────────────────────────┘
                         │ 阈值热更新
                         ▼
┌─────────────────────────────────────────────────────────┐
│                  Router.route()                           │
│  读 DynamicConfig → Embedding 路由 → 返回 RouterResult    │
│  写 MetricsRegistry: incr tier1Hits/tier2Fallbacks       │
└────────────────────────┬────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│                  MetricsRegistry                          │
│  snapshot("router") → 人看 API                           │
│  getCounter("router", "tier1Hits") → policy-update-loop  │
└──────────────┬──────────────────────────────────────────┘
               │               │
               ▼               ▼
         人看 API       ┌──────────────────────────┐
                        │   policy-update-loop     │
                        │   evaluateRouterThreshold│
                        │   → 满足条件则自动调参     │
                        │   → dynamicConfig.set(... │
                        │      "ai")               │
                        └──────────────────────────┘
```

#### 3.9.1 新增 PolicyDomain: `router_threshold`

扩展 `src/agents/policy-update-loop.ts` 的 `PolicyDomain` 类型：

```typescript
export type PolicyDomain =
  | "cache_ttl"
  | "response_prompt_hint"
  | "expert_activation"
  | "evidence_filter"
  | "router_threshold"           // ← 新增
```

#### 3.9.2 纯决策函数: `evaluateRouterThreshold`

遵循现有 4 个决策函数的相同接口范式——输入外部注入、输出 `PolicyUpdateRecord | null`、无副作用：

```typescript
// src/agents/policy-update-loop.ts — 决策函数 5

/**
 * Router 阈值自动调整（AI 消费 MetricsRegistry）
 *
 * 触发条件：
 *   1. tier1Rate < 0.6 → 阈值过高，降低 0.05（下限 0.3）
 *   2. tier1Rate > 0.85 且 expert 集中度 > 60% → 阈值过低，提高 0.05（上限 0.8）
 *
 * 安全约束：
 *   - 最小样本数 windowSize ≥ 20，避免小样本抖动
 *   - 每次调整步长固定 0.05，不跳变
 *   - 调整方向与观测指标逻辑一致：降低阈值 → 更多 Tier1 命中；提高阈值 → 更严格匹配
 */
export function evaluateRouterThreshold(
  routerSnapshot: MetricsSnapshot | null,
): PolicyUpdateRecord | null {
  if (!routerSnapshot || routerSnapshot.windowSize < 20) return null

  const tier1Hits = routerSnapshot.counters.tier1Hits || 0
  const tier2Fallbacks = routerSnapshot.counters.tier2Fallbacks || 0
  const total = tier1Hits + tier2Fallbacks
  if (total === 0) return null

  const tier1Rate = tier1Hits / total
  const currentThreshold = dynamicConfig.get("EMBEDDING_CONFIDENCE_THRESHOLD") ?? 0.5

  // 场景 1：Tier1 命中率过低 → 阈值太高，降低
  if (tier1Rate < 0.6) {
    const newThreshold = Math.max(0.3, +(currentThreshold - 0.05).toFixed(2))
    if (newThreshold === currentThreshold) return null
    return makeRouterThresholdRecord(currentThreshold, newThreshold, tier1Rate,
      `tier1Rate=${(tier1Rate*100).toFixed(0)}% 过低 → 降阈值以增加 Embedding 命中`)
  }

  // 场景 2：Tier1 命中率过高 + 专家集中 → 阈值太低，提高
  if (tier1Rate > 0.85) {
    const expertKeys = Object.keys(routerSnapshot.counters)
      .filter(k => k.startsWith("expert_"))
    const maxExpertHits = Math.max(...expertKeys.map(k => routerSnapshot.counters[k] || 0), 0)
    const concentration = tier1Hits > 0 ? maxExpertHits / tier1Hits : 0

    if (concentration > 0.6) {
      const newThreshold = Math.min(0.8, +(currentThreshold + 0.05).toFixed(2))
      if (newThreshold === currentThreshold) return null
      return makeRouterThresholdRecord(currentThreshold, newThreshold, tier1Rate,
        `tier1Rate=${(tier1Rate*100).toFixed(0)}% 过高 + 集中度${(concentration*100).toFixed(0)}% → 升阈值`)
    }
  }

  return null
}

function makeRouterThresholdRecord(
  current: number, next: number, tier1Rate: number, reason: string
): PolicyUpdateRecord {
  return {
    id: `router_threshold_${Date.now()}`,
    domain: "router_threshold",
    inputMetrics: { tier1Rate: Math.round(tier1Rate * 100) / 100, currentThreshold: current },
    decisionReason: `触发: ${reason} | EMBEDDING_CONFIDENCE_THRESHOLD ${current}→${next}`,
    affectedPolicy: {
      before: { EMBEDDING_CONFIDENCE_THRESHOLD: current },
      after: { EMBEDDING_CONFIDENCE_THRESHOLD: next },
    },
    rollbackData: {
      previousState: { EMBEDDING_CONFIDENCE_THRESHOLD: current },
      restorationQuery: `PUT /api/system/config/EMBEDDING_CONFIDENCE_THRESHOLD ${current}`,
    },
    confidence: Math.round(Math.min(90, Math.abs(next - current) * 200)),
    sourceEvents: [],
    timestamp: Date.now(),
    applied: false,
  }
}
```

#### 3.9.3 PolicyUpdateLoop.apply() 扩展

在 `apply()` 方法新增 `router_threshold` 分支，调用 `DynamicConfig.set()` 落实阈值变更：

```typescript
// src/agents/policy-update-loop.ts — apply() 方法扩展
if (record.domain === "router_threshold") {
  const after = record.affectedPolicy.after as { EMBEDDING_CONFIDENCE_THRESHOLD: number }
  dynamicConfig.set("EMBEDDING_CONFIDENCE_THRESHOLD", after.EMBEDDING_CONFIDENCE_THRESHOLD, "ai")
}
```

对应 `rollback()` 同理：

```typescript
if (record.domain === "router_threshold") {
  const before = record.rollbackData.previousState as { EMBEDDING_CONFIDENCE_THRESHOLD: number }
  dynamicConfig.set("EMBEDDING_CONFIDENCE_THRESHOLD", before.EMBEDDING_CONFIDENCE_THRESHOLD, "ai")
}
```

#### 3.9.4 evaluate() 注入 MetricsSnapshot

`PolicyUpdateLoop.evaluate()` 新增 `routerMetrics` 参数，与其他外部注入参数（ttlStats/turnHistory）一致的接口风格：

```typescript
async evaluate(
  ttlStats: TtlStats | null,
  turnHistory: AnalysisTurnRecord[],
  pathMetrics: StrategyAdjustment | null,
  toolExecutionStats?: ExecutionStateSnapshot | null,
  routerMetrics?: MetricsSnapshot | null,     // ← 新增
): Promise<PolicyUpdateRecord | null> {
  // ... 现有 4 个决策函数不变 ...

  // 5. router_threshold — MetricsSnapshot 外部注入
  if (routerMetrics) {
    results.push(evaluateRouterThreshold(routerMetrics))
  }
  // ... 后续冷却期/置信度检查不变 ...
}
```

#### 3.9.5 调参安全约束

| 约束 | 机制 | 值 |
|------|------|---|
| 小样本保护 | `windowSize ≥ 20` | 20 次路由后才启用 AI 调参 |
| 步长限制 | 每次 ±0.05 | 不跳变，缓慢逼近最优值 |
| 范围边界 | `[0.3, 0.8]` | 不调到极端值 |
| 冷却期 | 复用 `decisions.cooldownTurns` | 同 domain 不连续调 |
| 置信度门槛 | 复用 `decisions.confidenceThreshold` | 低置信建议不应用 |
| 变更来源 | `source: "ai"` | 与人的 `"api"` 区分，可审计 |
| 回滚 | `rollback()` → `dynamicConfig.set(oldValue)` | 一键恢复 |

> **人类优先**：AI 自动调参只做建议级调整（±0.05/次）。人可以在任何时刻通过 API 覆盖，且变更历史完整记录 `source` 字段，明确是 AI 还是人做的调整。

---

## 四、实施步骤

```
Task 0: 新建 DynamicConfig + MetricsRegistry 基础设施
   │
   ▼
Task 1: 替换 domain-triggers.ts 触发词为 v2 词库
   │
   ▼
Task 2: 构建 centroid embedding + 写入 ChromaDB（centroid-init + embedding）
   │
   ▼
Task 3: 实现 Router 入口（index.ts 主流程）
   │
   ▼
Task 4: 实现 LLM fallback（llm-fallback.ts）
   │
   ▼
Task 5: Router 接入 Metrics + 单测
   │
   ▼
Task 6: 新建 intention_async 体系 + wiring profession 图
   │
   ▼
Task 7: 编译验证 + 端到端测试
```

### Task 0: 新建 DynamicConfig + MetricsRegistry 基础设施 ✅ 已完成（2026-07-03）

**文件**: `src/services/dynamic-config.ts` + `src/services/metrics-registry.ts` + `src/api/system/config/route.ts` + `src/api/system/metrics/route.ts`（新建）+ `src/instrumentation.ts`（修改）

- [x] `DynamicConfig` 单例：`get/set/getAll/getHistory/onChange` CRUD 接口
- [x] 初始值初始化：`initDynamicConfig()` 在 `instrumentation.ts` register() 中调用，启动时从 `DEFAULT_CONFIG` 批量 `set("key", value, "init")` 注入
- [x] 变更来源枚举 `"api" | "ai" | "init"`，每次 set 记录时间戳 + 旧值
- [x] `onChange` 订阅机制：AI 消费端（policy-update-loop）可注册回调
- [x] `MetricsRegistry` 单例：`register/snapshot/snapshotAll/getCounter` 接口
- [x] `MetricsCollector` 内部实现：`incr/gauge/observe/snapshot/reset`（纯内存，不引入外部依赖）
- [x] API route `GET/PUT /api/system/config/:key`：人类查看/修改参数（含 Zod 值校验 `getConfigValueSchema`）
- [x] API route `GET /api/system/config/history/:key`：变更链查询
- [x] API route `GET /api/system/metrics/:name`：人类查看模块指标
- [x] `tsc --noEmit` 验证通过

> **实施修正（2026-07-03）**：验收发现 `initDynamicConfig()` 定义了但未调用，已在 `src/instrumentation.ts` 的 `register()` 中补齐调用，确保启动时 DynamicConfig 初始值（`EMBEDDING_CONFIDENCE_THRESHOLD` 0.5 / `EMBEDDING_MARGIN_THRESHOLD` 0.15 / `EMBEDDING_TOPK` 3）在运行时路由注册前就绪。

### Task 1: 替换触发词为 v2 词库

**文件**: `src/agents/vocabulary/domain-triggers.ts`（修改）

- [ ] 将 13 个专家的 `expertTriggers` 替换为产品提供的 v2 口语化触发词（`domain-triggersv2.md`）
- [ ] `land_analysis` 专家 v2 未覆盖，保留 v1 触发词并标注 `// v2 未提供，保留存量词`
- [ ] 删除 `src/agents/vocabulary/domain-triggers.md`（TypeScript 代码的 .md 副本，无消费者）
- [ ] `tsc --noEmit` 验证

### Task 2: 构建 centroid embedding + 写入 ChromaDB

**文件**: `src/agents/router/centroid-init.ts` + `src/agents/router/embedding.ts`（新建）

- [ ] `CentroidInit.build()`: 每个专家的触发词拼接为一段文本 → `getEmbeddings()` → 均值池化 → 1024 维 centroid
- [ ] **复用系统已有 embedding 模型**：`getEmbeddings()`（即 `text-embedding-v4`，1024 维），不引入新模型
- [ ] 写入 ChromaDB `expert_centroids` collection（`upsert`），每条 { expertId, embedding, metadata: { label } }
- [ ] `embeddingRoute(query)`: query embedding → ChromaDB.query(topK=3) → 候选列表
- [ ] 阈值从 `DynamicConfig` 动态读取，而非 `types.ts` 硬编码常量。`DEFAULT_CONFIG` 定义初始值：`EMBEDDING_CONFIDENCE_THRESHOLD`(0.5)、`EMBEDDING_MARGIN_THRESHOLD`(0.15)、`EMBEDDING_TOPK`(3)
- [ ] 阈值判定逻辑：`const threshold = dynamicConfig.get("EMBEDDING_CONFIDENCE_THRESHOLD") ?? 0.5` → `topScore > threshold && topScore - secondScore > margin` → 直接返回；否则升级 Tier 2 LLM
- [ ] 单测：≥3 条模拟农民口语用例

### Task 3: 实现 Router 入口

**文件**: `src/agents/router/index.ts`（新建）

- [ ] `Router.init()`: 应用启动时调用，确保 ChromaDB `expert_centroids` collection 已就绪
- [ ] `Router.route(query)`: 串联 Embedding 层 → 阈值判定 → 高置信度直接返回；低置信度走 LLM fallback
- [ ] `RouterResult` 类型：`{ expertIds: string[], confidence: number, tier: 1|2, candidates: Candidate[] }`
- [ ] `tsc --noEmit` 验证

### Task 4: 实现 LLM fallback

**文件**: `src/agents/router/llm-fallback.ts`（新建）

- [ ] `llmFallbackRoute(query, candidates)`: 调 LLM 意图解析
- [ ] prompt 注入完整上下文：`INTENT_SEMANTICS` + `CROSS_DOMAIN_RULES` + top-3 候选专家描述（用 expert 的 `description` 字段，不用触发词）
- [ ] 返回 `RouterResult { tier: 2 }`
- [ ] 单测：≥2 条典型 fallback 用例（如"今年种啥能赚钱还不累"）

### Task 5: Router 接入 Metrics + 单测

**文件**: `src/agents/router/index.ts`（修改，追加 ~5 行）

- [ ] `route()` 末尾接入 `MetricsRegistry`：递增 `tier1Hits`/`tier2Fallbacks` 计数器，记录 `lastLatencyMs` 和 `confidenceSamples`
- [ ] 单测：Embedding 命中（"地里烂根了" → pest_risk）、LLM fallback、无匹配

### Task 6: 新建 intention_async 体系 + wiring profession 图

**文件**: `src/agents/prompts/intent-constants.ts`（新建） + `src/agents/prompts/intention_async.ts`（新建） + `src/agents/nodes/intention-async.ts`（新建） + `src/agents/agent-graph.ts`（修改） + `src/agents/nodes/index.ts`（修改） + `src/agents/prompts/index.ts`（修改） + `src/agents/prompts/intention.ts`（修改 import only）

- [ ] 提取 `INTENT_SEMANTICS` + `CROSS_DOMAIN_RULES` 到 `intent-constants.ts`
- [ ] `intention.ts` 改为从 `intent-constants.ts` import（不改逻辑，diff 仅 import 行）
- [ ] 新建 `intention_async.ts`：异步 prompt 模板，`buildContextBlock()` 调 `Router.route()`
- [ ] 新建 `intention-async.ts`：异步 LangGraph 节点 `intentionAsyncNode`，复用 `intentionNode` 逻辑，唯一差异是 prompt 构建走异步
- [ ] Embedding 命中（tier=1）→ 跳过 LLM，直接用候选构建 `subIntents[]` 和 `expertPlan`
- [ ] LLM fallback（tier=2）→ 调 LLM，prompt 注入 INTENT_SEMANTICS + CROSS_DOMAIN_RULES + top-3 专家描述
- [ ] 修改 `agent-graph.ts`：`professionalWorkflow` 的 `.addNode("intention", ...)` 改为使用 `intentionAsyncNode`
- [ ] 修改 `nodes/index.ts`：导出 `intentionAsyncNode`
- [ ] 修改 `prompts/index.ts`：导出 `intentionAsyncPrompt`
- [ ] **不改动** `intention.ts` 的 `intentionNode` 函数逻辑——deep/simple 图继续使用同步版本
- [ ] **不改动** `agent`（deep/simple）图的 wiring
- [ ] `tsc --noEmit` 验证

### Task 7: 编译验证 + 端到端测试

- [ ] `npx tsc --noEmit` 通过
- [ ] Embedding 命中："地里烂根了" → pest_risk（20-50ms）
- [ ] Embedding 命中："叶子发黄是什么问题" → [nutrition_diagnose, pest_risk]（20-50ms）
- [ ] 联合链路："选个高产品种" → [crop_compare, variety_recommend]
- [ ] LLM fallback："今年种啥能赚钱还不累" → LLM 决策（200-500ms）
- [ ] 现有 deep/simple 图不受影响（`intention.ts` 未改）

---

## 五、验收标准

- [ ] `domain-triggers.ts` 中 13 个专家触发词已替换为 v2 词库，`land_analysis` 保留并标注
- [ ] `src/agents/router/` 模块存在（`index.ts` + `embedding.ts` + `llm-fallback.ts` + `centroid-init.ts` + `types.ts`）
- [ ] ChromaDB `expert_centroids` collection 包含 14 个 centroid（1024 维）
- [ ] `Router.route()` 返回 `RouterResult`，包含 `expertIds` + `confidence` + `tier`
- [ ] `intention_async.ts` + `intention-async.ts` 已新建，`intention.ts` 的 `intentionNode` 函数逻辑未修改（deep/simple 图不受影响）
- [ ] `agent-graph.ts` 中 `professionalWorkflow` 的 intention 节点已切换为 `intentionAsyncNode`
- [ ] `agent`（deep/simple）图的 wiring 未修改
- [ ] `intention_async.ts` 中 Embedding 命中后不调 LLM → 成本降低 ≥80%
- [ ] `npx tsc --noEmit` 零错误
- [ ] 现有 fast/deep 图不受影响

---

## 六、风险矩阵

| 风险 | 概率 | 影响 | 缓解措施 |
|------|:--:|------|---------|
| Embedding 服务不可用 | 低 | 中——Tier 1 Embedding 和 RAG 检索同时不可用 | 复用 `getEmbeddings()` 单例，embedding 不可用时直接走 Tier 2 LLM（降级但可用） |
| ChromaDB centroid collection 被误删 | 低 | 低——需重启时重建 | `centroid-init.ts` 支持按需重建，启动时检测 collection 不存在则自动构建 |
| Embedding 阈值（`EMBEDDING_CONFIDENCE_THRESHOLD`/`EMBEDDING_MARGIN_THRESHOLD`）初期不准 | 中 | 中——误判导致过多请求走 LLM fallback 或低质直接返回 | 阈值采用行业默认值 0.5（aurelio-labs semantic-router + LiteLLM auto-router 一致值），可通过 `DynamicConfig` 运行时热更新；Tier 2 prompt 保留了完整 INTENT_SEMANTICS，即使误升级也不会降质。上线后监控 Embedding 命中率与误判率调整 |
| 联合链路 fan-out 依赖 professional 图（尚未实现） | 高 | 高——v3 ACA plan 轮次 4 未完成前，多专家路由只能走 deep 图 subIntents | 本 plan 不依赖 professional 图完成；Router 返回 top-K 候选，intention_async 用 subIntents 消费（当前 deep 图已支持） |
| `intention_async.ts` 与 `intention.ts` 共享常量修改时不同步 | 低 | 低——常量提取为独立文件后单向依赖 | `INTENT_SEMANTICS` 和 `CROSS_DOMAIN_RULES` 提取到 `src/agents/prompts/intent-constants.ts`，两方 import 同一源 |
| `intentionAsyncNode` 与 `intentionNode` 逻辑分叉 | 低 | 中——两个节点函数独立维护，可能漂移 | `intentionAsyncNode` 最大化复用 intentionNode 的子函数（tool_calls 注入、subIntent 激活、关键词兜底），仅 prompt 构建路径不同 |

---

## 七、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| V1 Plan | `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-plan-v1.md` | ✅ 已完成 |
| V1 Handoff | `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-handoff-v1.md` | ✅ 已完成 |
| V3 ACA Plan | `.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md` | 🔄 进行中 |
| v2 产品触发词 | `src/agents/vocabulary/domain-triggersv2.md` | ✅ 已提供 |
| ADD Route | `.qoder/plans/2026-07/01/farm-agent-domain-vocabulary-add-route-v2.md` | ✅ 已生成 |
| Handoff | `.qoder/plans/2026-07/01/farm-agent-domain-vocabulary-handoff-v2.md` | 待生成 |
| Spec | `.qoder/specs/farm-agent-domain-vocabulary-v2/` | ✅ 已生成（三件套） |
