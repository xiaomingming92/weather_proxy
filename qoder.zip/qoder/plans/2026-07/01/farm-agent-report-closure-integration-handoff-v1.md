# farm-agent-report-closure-integration-handoff-v1

> **Plan**: `farm-agent-report-closure-integration-plan-v1.md`
> **日期**: 2026-07-01
> **ADD 轮次**: 1 轮（纯治理文档变更）

---

## §1 背景

gateway.md 运行时发现关闭流程断裂：无 Report Closure 模板、REPORT-WORKFLOW.md 格式与脚本不一致、ADD 未接入 Report 流程。

## §2 方案

- 新建独立 `report-handoff-template.md`
- 新增 ADD Step 9（Report Closure）条件性步骤
- 同步 10 个治理文件 Step 0-8 → Step 0-9
- 修正 REPORT-WORKFLOW.md 格式对齐 `- [x]`
- gateway.md 31 条发现追加 `- [x]` 标记

## §3 改动文件（12 个）

| 文件 | 操作 | 内容 |
|------|------|------|
| `report-handoff-template.md` | 新建 | Report Closure 填空模板 |
| `AGENTS.md` | 修改 | 10阶段 + Step9词汇 + devlog日志(走mcp)对齐 |
| `add-paradigm/SKILL.md` | 修改 | 10 phases + Step9完整章节 |
| `add-governance-vocabulary.md` | 修改 | 13文档类型 + 12ADD阶段 + 5条新词汇 |
| `add-route-template.md` ×2 | 修改 | 新增 Step9 章节 |
| `project_rules.md` | 修改 | 10阶段 + ADD-16 |
| `theory-practice-map.toml` | 修改 | ADD-17 Step9映射 |
| `add-flow-guardian.md` | 修改 | Step9入口/出口 |
| `add-orchestrator.md` | 修改 | Step9编排 + devlog日志(走mcp)对齐 |
| `REPORT-WORKFLOW.md` | 修改 | 格式对齐 - [x] + Step0-9 |
| `gateway.md` | 修改 | 31条追 - [x] + 删§2/§4 |

## §4 验证结果

| 检查项 | 状态 |
|--------|:--:|
| `check-boundary-report.ts` 31/31 已关闭 | ✅ |
| checklist 12项 grep 验证 | ✅ |
| devlog 12条 MCP 落库 | ✅ |

## §5 devlog（审计日志）

| # | action | targetId | cuid |
|---|--------|----------|------|
| 1 | TEMPLATE_CREATED | report-handoff-template.md | cmr1p2uxo0001lzvfcc8tseoi |
| 2 | DOC_UPDATED | AGENTS.md | cmr1p30q80009lzvfyu6jwvbi |
| 3 | SKILL_MODIFIED | add-paradigm/SKILL.md | cmr1p30q70005lzvfpz6s1or7 |
| 4 | DOC_UPDATED | add-governance-vocabulary.md | cmr1p30q80007lzvfr8hisnri |
| 5 | TEMPLATE_MODIFIED | add-route-template.md | cmr1p30q00003lzvfmh28as2d |
| 6 | TEMPLATE_MODIFIED | add-route-template-heavyweight.md | cmr1p37so000flzvff65iq12h |
| 7 | DOC_UPDATED | project_rules.md | cmr1p37so000dlzvfo6jnb91a |
| 8 | DOC_UPDATED | theory-practice-map.toml | cmr1p37su000hlzvfhu8y43is |
| 9 | AGENT_MODIFIED | add-flow-guardian.md | cmr1p37sn000blzvfafx1xnxv |
| 10 | AGENT_MODIFIED | add-orchestrator.md | cmr1p3clw000jlzvf6hn5xacl |
| 11 | DOC_UPDATED | REPORT-WORKFLOW.md | cmr1p3clx000nlzvfzjde277v |
| 12 | REPORT_UPDATED | gateway.md | cmr1p3clx000llzvf4azbeoca |

恢复关键词：
```text
query_audit_logs({ keyword: "report-closure-integration" })
```

## §6 已知残留

无。

## §7 回滚

`git revert` 即可。所有改动限定在 `.qoder/` + `AGENTS.md`，不影响 `src/`。
