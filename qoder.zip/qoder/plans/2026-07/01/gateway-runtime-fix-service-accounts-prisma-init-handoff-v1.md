# gateway-runtime-fix-service-accounts-prisma-init-handoff-v1

> **Plan**: `gateway-runtime-fix-service-accounts-prisma-init-plan-v1.md`
> **日期**: 2026-07-01
> **ADD 轮次**: 1 轮

---

## §1 背景

Gateway 边界报告捕获到 `PUT /api/admin/service-accounts` 出现 `Cannot read properties of undefined (reading 'findUnique')`，6/24 发生 2 次。

## §2 根因

初始诊断为 Prisma singleton 问题，Review 回流后修正为：

1. **迁移 SQL 不幂等** — `prisma migrate dev` 默认生成的 DDL 不带 `IF NOT EXISTS` / `IF EXISTS`
2. **CI 部署时序竞态** — `pm2 restart` 在迁移执行后才切换 Client，旧 Client 在迁移期间仍在运行

## §3 方案

1. **维护模式**：`proxy.ts` 顶部拦截全路由返回 503，`/api/admin/maintenance` POST 控制开关
2. **CI 部署时序**：`curl POST 开启维护` → `sleep 2s` → `pm2 stop` → `migrate deploy` → `generate` → `pm2 start`（新进程自动清除维护模式）
3. **迁移幂等闸门**：`db-ensure.prod.sh` 在 migrate 前扫描 SQL，拒绝不安全 DDL

## §4 改动文件

| 文件 | 改动 |
|------|------|
| `src/proxy.ts` | 顶部加 `isMaintenanceMode()` 检查 → 503；matcher 扩展至全路由；导出 setMaintenanceMode |
| `src/app/api/admin/maintenance/route.ts` | **新建**：POST `{ enabled: true/false }` 控制维护模式，GET 查询状态 |
| `.gitlab-ci.yml:deploy` | `curl POST 维护` → `sleep 2s` → `pm2 stop` → `migrate deploy` → `generate` → `pm2 start` |
| `scripts/db-ensure.prod.sh` | 新增 [0/3] 幂等闸门 |

## §5 验证结果

| 检查项 | 状态 |
|--------|------|
| `tsc --noEmit` | ✅ 通过 |
| 幂等闸门对现有 6 个 migration 无误杀 | ✅ 通过 |
| 维护模式开启后请求返回 503 | ⬜ 待运行时验证 |
| pm2 start 后维护模式自动清除 | ⬜ 待运行时验证 |
| CI deploy 完整时序 | ⬜ 待部署验证 |

## §6 devlog（审计日志）✅ 已落库 DevOperation

| # | 时间 | action | targetType | targetId | reason |
|---|------|--------|-----------|----------|--------|
| 1 | 2026-07-01 | MODIFY | PROXY | `src/proxy.ts` | 加维护模式拦截 + 扩展 matcher |
| 2 | 2026-07-01 | CREATE | API_ROUTE | `src/app/api/admin/maintenance/route.ts` | 维护模式控制 API |
| 3 | 2026-07-01 | MODIFY | CI_CONFIG | `.gitlab-ci.yml` | curl 维护 → sleep → stop → migrate → start |
| 4 | 2026-07-01 | MODIFY | SCRIPT | `scripts/db-ensure.prod.sh` | 迁移 SQL 幂等闸门 |

## §7 已知残留

无。

## §8 回滚

恢复 `.gitlab-ci.yml` 和 `db-ensure.prod.sh` 至改动前状态即可。
