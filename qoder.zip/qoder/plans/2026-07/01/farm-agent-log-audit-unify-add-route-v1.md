# farm-agent-log-audit-unify-add-route-v1

> **定位**：Plan → ADD 十阶段执行映射。不重复 Plan 的架构设计，只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）
>
> **绑定**：Plan: `farm-agent-log-audit-unify-plan-v3.md` · Spec: `farm-agent-log-audit-unify/` · Handoff: `farm-agent-log-audit-unify-handoff-v1.md`

---

## Step 0：文档先行

**输入**：Plan v3 + `code-review-combined-report.md` #6-#9

**动作**：
1. 确认 Specs 三元组就绪（需新建 `spec.md` + `tasks.md` + `checklist.md`）
2. 调用 `find_related_docs` 检索受影响的架构文档
3. 确认 Handoff 就绪（待 Step 8 生成）

**产出**：
- [ ] 验证并更新项目状态：Specs 三元组路径确认
- [ ] 验证并更新项目状态：项目文档已更新（或无需更新声明已记录）
- [ ] 验证并更新项目状态：Handoff 占位已记录

### §0.8 DPS 闸门

调用 `check_dps({ planKeyword: "log-audit-unify" })`。

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**动作**：确定本次涉及的审计阶段，决定是否扩展 `AgentAuditPhase`。

**分析结论**：本 Plan 不涉及 Agent 管线新阶段（不修改 agent nodes），不需要扩展 `AgentAuditPhase`。新增的 `auditGatewayRequest()` 使用自由 string action，不走 Phase 联合类型。

**产出**：
- [ ] 验证并更新项目状态：确认无需扩展 AgentAuditPhase（本次不改 agent 管线）

---

## Step 2：审计基础设施确认

**动作**：确认 `agentAudit()` + `writeAuditLog()` 通道可用。

**产出**：
- [ ] 验证并更新项目状态：`agentAudit()` 通道确认可用
- [ ] 验证并更新项目状态：`writeAuditLog()` 确认是唯一 DB 入口（ESLint 规则已生效）

---

## Step 3：业务逻辑实现与审计植入

### §3.0 前置守卫

调用 `check_add_route_status({ planKeyword: "log-audit-unify" })`。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| A1.1 | 创建 LogFileWriter | `src/lib/log/file-writer.ts` | 无（基础设施） | — | 无 | ⬜ |
| A1.2 | audit-logger.ts 迁移 | `src/lib/audit-logger.ts` | `LogFileWriter.log()` | — | A1.1 | ⬜ |
| A1.3 | chat-persistence-logger.ts 迁移 | `src/lib/chat-persistence-logger.ts` | `LogFileWriter.log()` | — | A1.1 | ⬜ |
| A1.4 | stream-bus-logger.ts 迁移 | `src/lib/stream-bus-logger.ts` | `LogFileWriter.log()` | — | A1.1 | ⬜ |
| A1.5 | stream-chat-logger.ts 迁移 | `src/lib/stream-chat-logger.ts` | `LogFileWriter.log()` | — | A1.1 | ⬜ |
| A1.6 | agent-gateway-dev-logger.ts 迁移 | `src/lib/agent-gateway-dev-logger.ts` | `LogFileWriter.log()` | — | A1.1 | ⬜ |
| A1.7 | chat-stats-logger.ts 迁移 | `src/lib/chat-stats-logger.ts` | `LazyLogFileWriter.log()` | — | A1.1 | ⬜ |
| A1.8 | model-config-logger.ts 迁移 | `src/lib/model-config-logger.ts` | `LazyLogFileWriter.log()` | — | A1.1 | ⬜ |
| A1.9 | audit.ts 迁移 | `src/lib/log/audit.ts` | `LogFileWriter.log()` | — | A1.1 | ⬜ |
| A2.1 | 创建 gateway-audit.ts | `src/lib/log/gateway-audit.ts` | `auditGatewayRequest()` | — | A1.1 | ⬜ |
| A2.2 | 重写 agent/[hash] callers | `src/app/api/agent/[hash]/route.ts` | `auditGatewayRequest()` | — | A2.1 | ⬜ |
| A2.3 | 删除旧 gateway 文件 | `src/lib/agent-gateway-dev-logger.ts`, `src/lib/agent-gateway-audit.ts` | — | — | A2.2 | ⬜ |
| A2.4 | h5 P0 路由接入 | `h5/agent/*`, `h5/nongqing/*`, `h5/production-plan/*` (7 条) | `auditGatewayRequest({source:"h5"})` | — | A2.1 | ⬜ |
| A2.5 | h5 P1 路由接入 | 6 条辅助路由 | `auditGatewayRequest({source:"h5"})` | — | A2.4 | ⬜ |
| A3.1 | 重写 audit/route.ts | `src/app/api/audit/route.ts` | 无（Prisma 查询替代） | — | 无 | ⬜ |
| A3.2 | 删除 audit-log.ts | `src/services/audit-log.ts` | — | — | A3.1 | ⬜ |
| A3.3 | 更新 services/index.ts | `src/services/index.ts` | 删除导出 | — | A3.2 | ⬜ |
| A4.1 | 创建 tracer-store.ts | `src/agents/tracer-store.ts` | 无（结构拆分） | — | 无 | ⬜ |
| A4.2 | 创建 tracer.ts | `src/agents/tracer.ts` | 无 | — | A4.1 | ⬜ |
| A4.3 | 创建 tool-node-wrapper.ts | `src/agents/tool-node-wrapper.ts` | 无 | — | 无 | ⬜ |
| A4.4 | 创建 audit-wrapper.ts | `src/agents/audit-wrapper.ts` | 无（已有 audit 调用） | — | A1.1, A4.1 | ⬜ |
| A4.5 | 创建 graph.ts | `src/agents/graph.ts` | 无 | — | A4.3, A4.4 | ⬜ |
| A4.6 | 创建 agent-runner.ts | `src/agents/agent-runner.ts` | 无 | — | A4.5 | ⬜ |
| A4.7 | 精简 index.ts | `src/agents/index.ts` | re-export | — | A4.1-A4.6 | ⬜ |

### 依赖拓扑

```
A1.1 (LogFileWriter)
  ├── A1.2 ~ A1.9 (parallel: 8 logger 迁移)
  └── A2.1 (gateway-audit.ts, 依赖 LogFileWriter)
        ├── A2.2 (agent/[hash] 调用方)
        │     └── A2.3 (删除旧 gateway 文件)
        └── A2.4 (h5 P0: 7 routes, parallel)
              └── A2.5 (h5 P1: 6 routes)

A3.1 → A3.2 → A3.3 (serial, 独立于 Atom 1/2/4)

A4.1 ──→ A4.2 (tracer 依赖 tracer-store)
A4.3     (独立)
A4.4     (依赖 A1.1 LogFileWriter + A4.1 tracer-store)
A4.5     (依赖 A4.3 + A4.4)
A4.6     (依赖 A4.5)
A4.7     (依赖 A4.1-A4.6)
```

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计
3. 验证并更新项目状态：将该 Task 在 `tasks.md` 中逐子项勾选为 `[x]`

**产出**：
- [ ] 验证并更新项目状态：全部 Task 的 `[T]` 项通过
- [ ] 验证并更新项目状态：每个文件有 `record_dev_operation` 记录
- [ ] 验证并更新项目状态：调用 `check_spec_sync` 确认 spec 文档与代码一致

---

## Step 3.5：实现审查

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 生成 `review-implementation.md`
3. 生成 `review-runtime.md`（含 `[R]` 待验证清单）

**产出**：
- [ ] 验证并更新项目状态：`checklist.md` 全部 `[T]` 项已通过并勾选
- [ ] 验证并更新项目状态：`review-implementation.md` 已生成
- [ ] 验证并更新项目状态：`review-runtime.md` 已生成

---

## Step 4：审计数据验证

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. `npm run lint` —— 无新增 lint 问题
3. 调用 `check_phase_symmetry`、`check_failure_path`
4. **重型强制**：调用 `check_spec_sync`

**产出**：
- [ ] `tsc --noEmit` 通过
- [ ] `npm run lint` 通过
- [ ] 阶段对称性验证通过
- [ ] 验证并更新项目状态：`check_spec_sync` 通过

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "log-audit-unify" })`。

- [ ] RAHS 已通过（≥ 90），可进入 Step 5

---

## Step 5：AI 自动合规检查

**动作**：对每个修改文件调用 `check_add_compliance`。

**产出**：
- [ ] 验证并更新项目状态：合规报告已生成
- [ ] 验证并更新项目状态：`checklist.md` ADD 规则合规项已勾选

---

## Step 6：从审计数据定位问题（仅异常时进入）

- [ ] 验证并更新项目状态：问题清单已记录

---

## Step 7：修复并验证（仅异常时进入）

- [ ] 验证并更新项目状态：所有问题已修复，复验通过

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**动作**：
1. 收敛判断（全部 `[T]` 通过 + RAHS ≥ 90）
2. 更新 Handoff（§7/§8/§9）
3. 架构文档回看
4. ADD-7 回查确认

**产出**：
- [ ] 验证并更新项目状态：收敛判定通过
- [ ] 验证并更新项目状态：Handoff 已更新
- [ ] 验证并更新项目状态：架构文档已校准
- [ ] 验证并更新项目状态：ADD-7 审计记录已落库确认

---

## Step 9：Report Closure

> 本 Plan 不是 runtime-fix plan，**不需要执行 Step 9**。

- [x] 跳过（本 Plan 非 runtime-fix）

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/lib/log/file-writer.ts` | CREATE | A1.1 | COMPONENT | ⬜ |
| `src/lib/log/gateway-audit.ts` | CREATE | A2.1 | COMPONENT | ⬜ |
| `src/lib/log/index.ts` | MODIFY | A1.1, A2.1 | COMPONENT | ⬜ |
| `src/lib/audit-logger.ts` | MODIFY | A1.2 | COMPONENT | ⬜ |
| `src/lib/chat-persistence-logger.ts` | MODIFY | A1.3 | COMPONENT | ⬜ |
| `src/lib/stream-bus-logger.ts` | MODIFY | A1.4 | COMPONENT | ⬜ |
| `src/lib/stream-chat-logger.ts` | MODIFY | A1.5 | COMPONENT | ⬜ |
| `src/lib/agent-gateway-dev-logger.ts` | DELETE | A2.3 | COMPONENT | ⬜ |
| `src/lib/agent-gateway-audit.ts` | DELETE | A2.3 | COMPONENT | ⬜ |
| `src/lib/chat-stats-logger.ts` | MODIFY | A1.7 | COMPONENT | ⬜ |
| `src/lib/model-config-logger.ts` | MODIFY | A1.8 | COMPONENT | ⬜ |
| `src/lib/log/audit.ts` | MODIFY | A1.9 | COMPONENT | ⬜ |
| `src/app/api/agent/[hash]/route.ts` | MODIFY | A2.2 | API_ROUTE | ⬜ |
| `src/app/api/h5/agent/route.ts` | MODIFY | A2.4 | API_ROUTE | ⬜ |
| `src/app/api/h5/nongqing/daily-report/route.ts` | MODIFY | A2.4 | API_ROUTE | ⬜ |
| `src/app/api/h5/nongqing/overview/route.ts` | MODIFY | A2.4 | API_ROUTE | ⬜ |
| `src/app/api/h5/nongqing/prescriptions/route.ts` | MODIFY | A2.4 | API_ROUTE | ⬜ |
| `src/app/api/h5/nongqing/tasks/route.ts` | MODIFY | A2.4 | API_ROUTE | ⬜ |
| `src/app/api/h5/production-plan/variety-recommend/route.ts` | MODIFY | A2.4 | API_ROUTE | ⬜ |
| `src/app/api/h5/production-plan/land-analysis/route.ts` | MODIFY | A2.4 | API_ROUTE | ⬜ |
| `src/app/api/audit/route.ts` | MODIFY | A3.1 | API_ROUTE | ⬜ |
| `src/services/audit-log.ts` | DELETE | A3.2 | COMPONENT | ⬜ |
| `src/services/index.ts` | MODIFY | A3.3 | COMPONENT | ⬜ |
| `src/agents/tracer-store.ts` | CREATE | A4.1 | COMPONENT | ⬜ |
| `src/agents/tracer.ts` | CREATE | A4.2 | COMPONENT | ⬜ |
| `src/agents/tool-node-wrapper.ts` | CREATE | A4.3 | COMPONENT | ⬜ |
| `src/agents/audit-wrapper.ts` | CREATE | A4.4 | COMPONENT | ⬜ |
| `src/agents/graph.ts` | CREATE | A4.5 | COMPONENT | ⬜ |
| `src/agents/agent-runner.ts` | CREATE | A4.6 | COMPONENT | ⬜ |
| `src/agents/index.ts` | MODIFY | A4.7 | COMPONENT | ⬜ |
