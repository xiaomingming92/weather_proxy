# gateway-runtime-fix-service-accounts-contract-plan-v1

> **PLAN 元信息**
> - **来源**: `runtime-issue-20260622-01.md`（Gateway 边界报告）
> - **启动时间**: 2026-07-01
> - **关联文档**:
>   - Runtime Issue: `.qoder/reports/runtime-issue-20260622-01.md`
>   - Gateway Report: `.qoder/reports/farm-agent-runtime-report/gateway.md`

---

## 一、背景

Gateway 边界报告捕获到 `PUT /api/admin/service-accounts` 持续触发"合约断裂"：

- **期望**: `轮换成功(5min宽限)`
- **实际**: `ruifengyun-h5-backend`

发生 19 次，最新 6/30。调用的 `appendRuntimeFinding(null, { contract: ... })` 把 API 正常返回（服务账户名称）误判为合约断裂。

同文件 POST（创建）和 DELETE（禁用）存在相同模式：`contract.expected` 是操作描述字符串，`contract.actual` 是服务账户名称，同样会导致误判。

## 二、根因

`src/app/api/admin/service-accounts/route.ts` 三个成功路径均存在合约断言 mismatch：

| 行 | 方法 | expected | actual |
|----|------|----------|--------|
| L73 | POST | `创建成功` | `name`（账户名） |
| L112 | PUT | `轮换成功(5min宽限)` | `name`（账户名） |
| L139 | DELETE | `禁用成功` | `name`（账户名） |

`contract.actual` 始终是服务账户名称（如 `ruifengyun-h5-backend`），永远不会等于操作描述字符串，导致每次成功操作都被误报为合约断裂。

## 三、方案

移除所有三个成功路径的 `contract` 参数。API 返回 HTTP 200 即可判定成功，不需要在 `appendRuntimeFinding` 中重复断言响应体内容。

## 四、改动范围

| 文件 | 行 | 改动 |
|------|----|------|
| `src/app/api/admin/service-accounts/route.ts:73` | POST | 移除 `contract: { expected: "创建成功", actual: name }` |
| `src/app/api/admin/service-accounts/route.ts:112` | PUT | ✅ 已移除（v1 第一轮） |
| `src/app/api/admin/service-accounts/route.ts:139` | DELETE | 移除 `contract: { expected: "禁用成功", actual: name }` |

## 五、验证

- [x] `PUT /api/admin/service-accounts` 不再触发边界异常（v1 第一轮已完成）
- [x] `POST /api/admin/service-accounts` 不再触发边界异常
- [x] `DELETE /api/admin/service-accounts` 不再触发边界异常
- [x] gateway.md 不再新增 null 错误（commit `3d811e8`，已写入验证条目）
