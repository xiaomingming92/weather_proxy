# farm-agent-project-context-activation-plan-v1

> 来源: 神经元前端需要透传 projectId 数组和 activedProjectId，支持多专家流程/工具调用/专家卡片推理时提前获取项目上下文
> 创建: 2026-07-01

## PLAN 元信息

- **Plan 名称**: farm-agent-project-context-activation-v1
- **启动时间**: 2026-07-01T08:00:00.000Z
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-07/01/farm-agent-project-context-activation-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-07/01/farm-agent-project-context-activation-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-project-context-activation-review-v1.md`
  - Specs: `.qoder/specs/farm-agent-project-context-activation/`
- **ADD-7 审计策略**: (待 Step 1 填充)

---

## 一、背景与目标

### 1.1 问题现状

神经元前端接口类型中已预留 `userVO.projectId: number[]` 和 `userVO.activedProjectId?: number` 字段，但仅止于 TypeScript interface 声明——DTO/Zod Schema 未同步、handshake 未保存、farm-project-context 未扩展、无运行时更新通道。

1. **handshake 未保存**：`activedProjectId` 和 `projectId` 数组只在类型定义中存在，handshake handler 里没有保存到 farm-project-context
2. **无运行时更新通道**：用户在神经元界面切换项目后，agent 不知道——只能等下一次 chat 请求时通过 `body.projectId` 透传，但此时 LLM 推理已经开始，来不及预取地块/作物数据
3. **工具调用拿不到 activedProjectId**：`getFarmProjectId()` 只返回单个 projectId，工具执行时不知道用户当前聚焦哪个项目

### 1.2 目标

1. **handshake 记录**：handshake 时将 `projectId[]` 和 `activedProjectId` 写入 farm-project-context
2. **新增 activate-project 端点**：支持神经元在用户切换项目时主动通知 agent，在 chat 之前就预载项目上下文
3. **LLM 推理可用**：`getFarmProjectId()` 能返回 activedProjectId，16 个专家/tool 调用能提前获取地块、作物、气候等数据

---

## 二、方案

### 2.1 farm-project-context 扩展

```
src/lib/farm-project-context.ts

let currentProjectId: number | null = null     // 已废弃，保留兼容
let projectIds: number[] = []                  // 用户绑定的所有项目 ID
let activedProjectId: number | null = null     // 当前激活的项目 ID

export function setFarmProjectIds(ids: number[]): void
export function getFarmProjectIds(): number[]
export function setActivedProjectId(id: number | null): void
export function getActivedProjectId(): number | null

// 保持向后兼容
export function setFarmProjectId(projectId: number | null): void  // 同时设置 activedProjectId
export function getFarmProjectId(): number | null                 // 返回 activedProjectId
```

### 2.2 handshake 记录 projectId

```typescript
// handleHandshakePOST 中，upsert user_profile 之后新增:
if (body.userVO) {
  if (body.userVO.projectId?.length) {
    setFarmProjectIds(body.userVO.projectId)
  }
  if (body.userVO.activedProjectId) {
    setActivedProjectId(body.userVO.activedProjectId)
  }
}
```

### 2.3 新增 activate-project 端点

**GET**：`/api/agent/{hash}?action=activateProject&projectId=456`

**POST**：`/api/agent/{hash}` with body `{ type: "activate-project", projectId: 456 }`

两种方式都支持，轻量操作——只更新 activedProjectId，不创建线程、不触发推理。

```typescript
// 新增 POST 类型
interface ActivateProjectRequestBody {
  type: "activate-project"
  projectId: number
}

async function handleActivateProjectPOST(body: ActivateProjectRequestBody) {
  setActivedProjectId(body.projectId)
  void auditGatewayRequest({
    phase: GatewayPhase.REQUEST,
    source: GatewaySource.HASH,
    action: "GATEWAY_ACTIVATE_PROJECT",
    entityId: String(body.projectId),
  })
  return makeJsonResponse({ activedProjectId: body.projectId })
}
```

### 2.4 数据流（含 DB 持久化）

```
agrisynapse 用户切换项目
  │
  ├─→ POST /api/agent/{hash}  { type: "activate-project", projectId: 456 }
  │     ├─→ setActivedProjectId(456)           ← 内存（快，推理用）
  │     └─→ prisma.userProfile.update(...)     ← DB 持久化（重启恢复用）
  │
  ├─→ 重启后首次 handshake（前端未传 activedProjectId）
  │     └─→ prisma.userProfile.findUnique()    ← 从 DB 回读到内存
  │
  ├─→ POST /api/agent/{hash}  { type: "chat", messages: [...], projectId: 789 }
  │     └─→ setFarmProjectId(789) → 兼容旧行为
  │     └─→ streamAgent(input) → LLM 推理中 getActivedProjectId() = 456
  │           └─→ 工具调用: 查询 projectId=456 的地块、土壤、气候数据
  │
  └─→ 专家卡片触发: intention 节点识别 "虫害" → pest_risk expert
        └─→ retrieval 节点: getActivedProjectId() → 预取该项目的农情数据
```

---

## 三、实施步骤

| # | 步骤 | 文件 | 说明 |
|---|------|------|------|
| 1 | 扩展 farm-project-context | `src/lib/farm-project-context.ts` | 新增 projectIds[] + activedProjectId + getter/setter |
| 2 | 同步 DTO + Zod Schema | `src/dto/agent.dto.ts`、`src/app/api/types/` | 补充 projectId[] + activedProjectId 字段 |
| 3 | Prisma UserProfile 加字段 | `prisma/main.prisma` | projectIds Json? + activedProjectId Int? |
| 4 | handshake 双写 | `src/app/api/agent/[hash]/route.ts` | upsert 写入 projectIds + activedProjectId；前端未传时从 DB 回读恢复内存 |
| 5 | 新增 activate-project POST handler | `src/app/api/agent/[hash]/route.ts` | handleActivateProjectPOST + 类型 + 路由分发 + DB 双写 |
| 6 | 新增 activate-project GET handler | `src/app/api/agent/[hash]/route.ts` | GET action=activateProject 分发 + DB 双写 |
| 7 | 验证 | tsc + curl 测试 + DB 持久化验证 |

---

## 四、风险评估

| 风险 | 缓解 |
|------|------|
| `getFarmProjectId()` 语义变化影响现有调用方 | 保留向后兼容——`setFarmProjectId(n)` 同时设置 `activedProjectId = n`；`getFarmProjectId()` 返回 `activedProjectId` |
| 神经元未及时发送 activate-project 导致上下文缺失 | chat 请求的 `body.projectId` 兜底，fallback 到旧行为 |

---

## 五、验收标准

- [ ] `getActivedProjectId()` 在 handshake 后返回正确值
- [ ] `GET ?action=activateProject&projectId=456` 返回 200
- [ ] `POST { type: "activate-project", projectId: 456 }` 返回 200
- [ ] 后续 chat 请求中工具调用能获取到 activedProjectId
- [ ] `tsc --noEmit` 通过
- [ ] 现有 `getFarmProjectId()` 调用方行为不变
- [ ] activateProject 后 DB `UserProfile.activedProjectId` 已更新
- [ ] 重启后 handshake（前端未传 activedProjectId）能从 DB 恢复到内存
