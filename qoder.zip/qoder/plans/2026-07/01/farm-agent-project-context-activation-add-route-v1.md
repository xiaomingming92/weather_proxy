# farm-agent-project-context-activation-add-route-v1

> Plan: `farm-agent-project-context-activation-plan-v1.md`

## Step 0：文档先行
- [ ] DPS ≥ 85

## Step 1-2：审计阶段
- [x] 跳过 — 不改 agent 管线，无需扩展 Phase

## Step 3：实施

| # | Task | 文件 | 审计 | 依赖 | 状态 |
|---|------|------|------|------|------|
| 1 | 扩展 farm-project-context | `src/lib/farm-project-context.ts` | 无 | 无 | ⬜ |
| 2 | 同步 DTO + Zod | `src/dto/agent.dto.ts`、`src/app/api/types/` | 无 | 无 | ⬜ |
| 3 | handshake 保存 | `src/app/api/agent/[hash]/route.ts` | auditGatewayRequest | 1 | ⬜ |
| 4 | activate-project POST | `src/app/api/agent/[hash]/route.ts` | auditGatewayRequest | 1,2 | ⬜ |
| 5 | activate-project GET | `src/app/api/agent/[hash]/route.ts` | auditGatewayRequest | 4 | ⬜ |

依赖: 1→3, 1→4, 2→4, 4→5

## Step 4：验证
- [ ] tsc=0
- [ ] curl 测试

## Step 8：收敛
- [ ] handoff
- [ ] devlog

## 文件清单

| 文件 | 操作 | targetType |
|------|------|-----------|
| `src/lib/farm-project-context.ts` | MODIFY | COMPONENT |
| `src/dto/agent.dto.ts` | MODIFY | DTO |
| `src/app/api/types/index.ts` | MODIFY | TYPE |
| `src/app/api/agent/[hash]/route.ts` | MODIFY | API_ROUTE |
