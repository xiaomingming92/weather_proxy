# gateway-runtime-fix-service-accounts-contract-handoff-v1

> **Plan**: `gateway-runtime-fix-service-accounts-contract-plan-v1.md`
> **日期**: 2026-07-01
> **ADD 轮次**: 1 轮（单行修复）

---

## §1 背景

Gateway 边界报告捕获到 `PUT /api/admin/service-accounts` 持续触发合约断裂误判。

## §2 根因

`appendRuntimeFinding(null, { contract: { expected: "...", actual: name } })` 中 `actual` 是服务账户名称，`expected` 是操作描述字符串，永不匹配。影响 POST、PUT、DELETE 三个成功路径。

## §3 方案

移除所有三个成功路径的 `contract` 参数。API 返回 200 即可判定成功，无需断言响应体。

## §4 改动文件

| 文件 | 行 | 改动 |
|------|----|------|
| `src/app/api/admin/service-accounts/route.ts:73` | POST | 移除 `contract` |
| `src/app/api/admin/service-accounts/route.ts:112` | PUT | 移除 `contract` |
| `src/app/api/admin/service-accounts/route.ts:139` | DELETE | 移除 `contract` |

## §5 验证结果

| 检查项 | 状态 |
|--------|------|
| `tsc --noEmit` | ✅ 通过 |
| 运行时：POST/PUT/DELETE 不再触发边界异常 | ⬜ 待部署后验证 |
| Gateway 报告不再新增误判 | ⬜ 待部署后验证 |

## §6 devlog（审计日志）✅ 已落库 DevOperation

| # | 时间 | action | targetType | targetId | reason |
|---|------|--------|-----------|----------|--------|
| 1 | 2026-07-01 | MODIFY | API_ROUTE | `src/app/api/admin/service-accounts/route.ts` | 移除 PUT `appendRuntimeFinding` 的 `contract` 参数 |
| 2 | 2026-07-01 | MODIFY | API_ROUTE | `src/app/api/admin/service-accounts/route.ts` | 移除 POST `appendRuntimeFinding` 的 `contract` 参数 |
| 3 | 2026-07-01 | MODIFY | API_ROUTE | `src/app/api/admin/service-accounts/route.ts` | 移除 DELETE `appendRuntimeFinding` 的 `contract` 参数 |

## §7 已知残留

无。

## §8 回滚

如需回滚，恢复 L112 的 `contract` 参数即可：

```typescript
appendRuntimeFinding(null, { source: "route", requestInfo: { method: "PUT", pathname: "/api/admin/service-accounts" }, contract: { expected: "轮换成功(5min宽限)", actual: name } })
```
