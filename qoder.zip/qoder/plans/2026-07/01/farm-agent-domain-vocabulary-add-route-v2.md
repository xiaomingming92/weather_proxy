# farm-agent-domain-vocabulary-add-route-v2

> **定位**：Plan → ADD 十阶段执行映射。不重复 Plan 的架构设计，只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）
>
> **绑定**：Plan: `farm-agent-domain-vocabulary-plan-v2.md` · Spec: `farm-agent-domain-vocabulary-v2/` · Handoff: `farm-agent-domain-vocabulary-handoff-v2.md`

---

## Step 0：文档先行

**输入**：Plan v2 + Review v2（`.qoder/reviews/farm-agent-domain-vocabulary-review-v2.md`）

**动作**：
1. 确认 Specs 三元组就绪（需新建 `spec.md` + `tasks.md` + `checklist.md`）
2. 调用 `find_related_docs` 检索受影响的架构文档
3. Review 回流确认：P0/P1 问题已写回 Plan（见 Review 结论）

**产出**：
- [ ] 验证并更新项目状态：Specs 三元组路径确认
- [ ] 验证并更新项目状态：项目文档已更新（或无需更新声明已记录）
- [ ] 验证并更新项目状态：Handoff 占位已记录

### §0.6.5 Review 回流卡位

Review v2 的 10 条发现已在 Review 讨论中逐条处理并写回 Plan：

| # | 级别 | 状态 | 写回 Plan 的位置 |
|---|:--:|:--:|------|
| P0 #1 | 🔴 | 本 add-route + spec 即解决 | — |
| P0 #2 | 🔴 | 新建 `intention_async.ts`，不改 `intention.ts` | Plan §3.3 |
| P0 #3 | 🔴 | DPS 88 分 🟢 PASS | Plan 元信息 |
| P1 #4 | 🟡 | 维度笔误已修正 | Plan 验收 §5 |
| P1 #5 | 🟡 | 不成立（professional 图独立，不需兜底） | — |
| P1 #6 | 🟡 | Tier 2 LLM prompt 保留完整上下文 | Plan §2.2, §3.3 |
| P2 #7 | 🟢 | 砍 Tier 1 后无需分词 | Plan §2.2（为什么砍规则层） |
| P2 #8 | 🟢 | 阈值标注需调优 | Plan §2.2, 风险矩阵 §6 |
| P2 #9 | 🟢 | professional 图耦合风险已覆盖 | Plan 风险矩阵 §6 |
| P2 #10 | 🟢 | 不改 `PromptTemplate` 接口 | Plan §3.3 |

- [x] Review 回流完成（全部 10 条已处理）

### §0.8 DPS 闸门

调用 `check_dps({ planKeyword: "farm-agent-domain-vocabulary-plan-v2" })`。

- [x] DPS 已通过（88 分 🟢 PASS），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**动作**：确定本次涉及的审计阶段，决定是否扩展 `AgentAuditPhase`。

**分析结论**：本 Plan 不涉及 Agent 管线新阶段。改动范围：
- `src/agents/vocabulary/domain-triggers.ts`：触发词数据替换（无管线阶段）
- `src/agents/router/`：新建模块，路由层新能力（调用 embedding + LLM，但不创建新 Agent 节点）
- `src/agents/prompts/intention_async.ts`：新建 prompt 模板（不涉及 Agent 节点执行阶段）

不需要扩展 `AgentAuditPhase`。

**产出**：
- [ ] 验证并更新项目状态：确认无需扩展 AgentAuditPhase

---

## Step 2：审计基础设施确认

**动作**：确认 `agentAudit()` + `writeAuditLog()` 通道可用。Router 和 intention 新增代码需嵌入审计。

**产出**：
- [ ] 验证并更新项目状态：`agentAudit()` 通道确认可用
- [ ] 验证并更新项目状态：Router 模块的审计植入点已确定

---

## Step 3：业务逻辑实现与审计植入

### §3.0 前置守卫

调用 `check_add_route_status({ planKeyword: "domain-vocabulary-v2" })`。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| T1 | 替换触发词为 v2 词库 | `src/agents/vocabulary/domain-triggers.ts` | 无（数据替换） | — | 无 | ⬜ |
| T2 | 构建 centroid + 写入 ChromaDB | `src/agents/router/centroid-init.ts`, `embedding.ts`, `types.ts` | `agentAudit("ROUTER_INIT", ...)` | — | T1 | ⬜ |
| T3 | 实现 Router 入口 | `src/agents/router/index.ts` | `agentAudit("ROUTER_ROUTE", { tier, expertIds })` | — | T2 | ⬜ |
| T4 | 实现 LLM fallback | `src/agents/router/llm-fallback.ts` | 复用 `agentAudit("ROUTER_ROUTE", ...)` | — | T3 | ⬜ |
| T5 | Router 接入 Metrics + 单测 | `src/agents/router/index.ts`（修改追加） | `agentAudit("ROUTER_METRICS", ...)` | — | T4 | ⬜ |
| T6 | 新建 intention_async 体系 + wiring profession 图 | `intent-constants.ts`, `intention_async.ts`, `intention-async.ts`, `agent-graph.ts`, `nodes/index.ts`, `prompts/index.ts`, `intention.ts` | 无（新建节点 + 图切换，复用现有审计） | — | T5 | ⬜ |
| T7 | 编译验证 + 端到端测试 | — | — | — | T6 | ⬜ |

### 依赖拓扑

```
T1 (触发词替换)
  └── T2 (centroid + ChromaDB)
        └── T3 (Router 入口)
              └── T4 (LLM fallback)
                    └── T5 (Metrics + 单测)
                          └── T6 (intention_async 体系 + wiring)
                                └── T7 (编译 + 测试)
```

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计
3. 验证并更新项目状态：将该 Task 在 `tasks.md` 中逐子项勾选为 `[x]`

**产出**：
- [ ] 验证并更新项目状态：全部 Task 的 `[T]` 项通过
- [ ] 验证并更新项目状态：每个文件有 `record_dev_operation` 记录
- [ ] 验证并更新项目状态：调用 `check_spec_sync` 确认 spec 文档与代码一致

---

## Step 3.5：实现审查

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 生成 `review-implementation.md`
3. 生成 `review-runtime.md`（含 `[R]` 待验证清单）

**重点验证项**：
- Router ChromaDB centroid 查询正确性
- Embedding 阈值命中率
- intention_async.ts 与 intention.ts 行为一致性（deep/simple 图不受影响）
- intent-constants.ts 双端导入正确

**产出**：
- [ ] 验证并更新项目状态：`checklist.md` 全部 `[T]` 项已通过并勾选
- [ ] 验证并更新项目状态：`review-implementation.md` 已生成
- [ ] 验证并更新项目状态：`review-runtime.md` 已生成

---

## Step 4：审计数据验证

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. `npm run lint` —— 无新增 lint 问题
3. 调用 `check_phase_symmetry`、`check_failure_path`
4. **重型强制**：调用 `check_spec_sync`

**产出**：
- [ ] `tsc --noEmit` 通过
- [ ] `npm run lint` 通过
- [ ] 阶段对称性验证通过
- [ ] 验证并更新项目状态：`check_spec_sync` 通过

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "farm-agent-domain-vocabulary-plan-v2" })`。

- [ ] RAHS 已通过（≥ 90），可进入 Step 5

---

## Step 5：AI 自动合规检查

**动作**：对每个修改文件调用 `check_add_compliance`。

**产出**：
- [ ] 验证并更新项目状态：合规报告已生成
- [ ] 验证并更新项目状态：`checklist.md` ADD 规则合规项已勾选

---

## Step 6：从审计数据定位问题（仅异常时进入）

- [ ] 验证并更新项目状态：问题清单已记录

---

## Step 7：修复并验证（仅异常时进入）

- [ ] 验证并更新项目状态：所有问题已修复，复验通过

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**动作**：
1. 收敛判断（全部 `[T]` 通过 + RAHS ≥ 90）
2. 更新 Handoff（§7/§8/§9）
3. 架构文档回看
4. ADD-7 回查确认

**特别验证**：
- `intention.ts` 未被修改（diff 验证）
- ChromaDB `expert_centroids` collection 存在且包含 14 条记录
- deep/simple 图回归测试通过

**产出**：
- [ ] 验证并更新项目状态：收敛判定通过
- [ ] 验证并更新项目状态：Handoff 已更新
- [ ] 验证并更新项目状态：架构文档已校准
- [ ] 验证并更新项目状态：ADD-7 审计记录已落库确认

---

## Step 9：Report Closure

> 本 Plan 不是 runtime-fix plan，**不需要执行 Step 9**。

- [x] 跳过（本 Plan 非 runtime-fix）

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/agents/vocabulary/domain-triggers.ts` | MODIFY | T1 | COMPONENT | ⬜ |
| `src/agents/vocabulary/domain-triggers.md` | DELETE | T1 | COMPONENT | ⬜ |
| `src/agents/router/types.ts` | CREATE | T2 | COMPONENT | ⬜ |
| `src/agents/router/centroid-init.ts` | CREATE | T2 | COMPONENT | ⬜ |
| `src/agents/router/embedding.ts` | CREATE | T2 | COMPONENT | ⬜ |
| `src/agents/router/tier-decider.ts` | CREATE | T2 | COMPONENT | ⬜ |
| `src/agents/router/index.ts` | CREATE | T3 | COMPONENT | ⬜ |
| `src/agents/router/llm-fallback.ts` | CREATE | T4 | COMPONENT | ⬜ |
| `src/agents/prompts/intent-constants.ts` | CREATE | T6 | COMPONENT | ⬜ |
| `src/agents/prompts/intention_async.ts` | CREATE | T6 | COMPONENT | ⬜ |
| `src/agents/nodes/intention-async.ts` | CREATE | T6 | COMPONENT | ⬜ |
| `src/agents/agent-graph.ts` | MODIFY | T6 | COMPONENT | ⬜ |
| `src/agents/nodes/index.ts` | MODIFY | T6 | COMPONENT | ⬜ |
| `src/agents/prompts/index.ts` | MODIFY | T6 | COMPONENT | ⬜ |
| `src/agents/prompts/intention.ts` | MODIFY | T6 | COMPONENT | ⬜ |
