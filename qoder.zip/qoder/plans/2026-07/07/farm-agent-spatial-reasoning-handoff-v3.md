# farm-agent-spatial-reasoning — 13 轮原子事务交接手册 (v3)

> 多轮原子事务变更，每轮独立收敛。当前第 1-7 轮已完成，第 8-13 轮待执行。
>
> **v3 更新 (2026-07-22)**: 对齐 `farm-agent-spatial-reasoning-plan-v3.md` 13 轮结构。新增轮次 8（数据保真度+加权仲裁 Kalman+D-S）、轮次 12（professional 图扩展）。OOP 重构（BaseReasoningNode + 子类）归入轮次 5-7 的实践过程优化，不独立成轮。

---

## 全局元信息

- **父 Plan**: [farm-agent-spatial-reasoning-plan-v3.md](./farm-agent-spatial-reasoning-plan-v3.md)
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 约 40 个文件
- **Round 数**: 13 轮

```text
第1轮 ── 空间计算层 (types + voronoi + fcm + coordinate + state)
            │
            ▼
第2轮 ── spatialPreprocessing 节点
            │
            ▼
第2.5轮 ── toolResults 保鲜基础设施 (jieqi + freshness + hydration)
            │
            ▼
第3轮 ── summaryRetrieval + summaryReasoning
            │
            ▼
第4轮 ── 现有推理改造 + Graph 接入
            │
            ▼
第4.5-4.8轮 ── tool-result-aggregator + 三节点接入 (Prompt Engine 输入侧)
            │
            ▼
第5轮 ── ★ 觉知注入层 (prompts/awareness.ts)
            │
            ▼
第6轮 ── ★ GlobalState 第八域 spatial
            │
            ▼
第7轮 ── ★ 觉知裁决 (resolveAwareness)
     [实践优化: OOP 重构 — BaseReasoningNode + SpatialPreprocessingNode]
            │
            ▼
第8轮 ── ★ 数据保真度 + 加权仲裁 (Kalman + D-S) [v3 新增]
            │
            ▼
第9轮 ── 报告模板数据结构化 (reports→report-templates + dataSchema)
            │
            ▼
第10轮 ── 多 GUI 渲染解耦 + 后处理校验
            │
            ▼
第11轮 ── Prompt + Response + EventBus + 专家注册
            │
            ▼
第12轮 ── professional 图 toolResultsHydration 扩展 [v3 新增]
            │
            ▼
第13轮 ── 编译 + Lint + 验证 + 架构文档
```

---

## 原子事务边界说明

- 每轮文件集合形成独立边界，不会被其他轮回头修改
- 每轮完成后可通过 `tsc --noEmit` 独立验证
- 第 1-4.8 轮是 v2 原始 scope；第 5-7 轮是 Review §10 回流新增；第 2.5/4.5-4.8 是 v2 中间插轮
- 第 8 轮是 v3 新增（数据保真度+加权仲裁）；第 12 轮是 v3 新增（professional 图扩展）
- 第 13 轮不是前 12 轮的补丁，而是前 12 轮收敛后的验证合流
- 轮次 5-7 在实践中采用了 OOP 模式（BaseReasoningNode 抽象基类 + 子类 + SpatialPreprocessingNode 独立类），作为实现优化不改变轮次边界

---

## 第1轮 空间计算层 ✅

### 你当前的位置

你是第 1 轮。上游无依赖。

### 原子事务目标

新建 spatial lib 四个文件 + 修改 state.ts 空间字段。

### 你要改的文件（5 个：4 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/lib/spatial/types.ts` | 新建 | VoronoiRegion / SensorInfo / PlotInfo / ManagementZone / SpatialContext 五个接口 |
| `src/lib/spatial/voronoi.ts` | 新建 | Voronoi 图计算 (Fortune's Algorithm via d3-delaunay) |
| `src/lib/spatial/fcm.ts` | 新建 | FCM 聚类 (PCA + 模糊C均值) |
| `src/lib/spatial/coordinate-transform.ts` | 新建 | CGCS2000 ↔ WGS-84 坐标转换（默认恒等，偏差<1m 跳过，按需精确） |
| `src/agents/state.ts` | 修改 | 新增 spatialRegions / managementZones / spatialContextDigest Annotation |

### 高风险误区

- 禁止在 voronoi.ts / fcm.ts 中引入运行时依赖（除 d3-delaunay 外）
- 禁止移除降级回退路径（spatialRegions = null 时必须行为不变）

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `CREATE` | COMPONENT | `src/lib/spatial/types.ts` | Task 1.1: SensorInfo/PlotInfo/VoronoiRegion/ManagementZone/SpatialContext | ✅ |
| `CREATE` | COMPONENT | `src/lib/spatial/voronoi.ts` | Task 1.2: Fortune Algorithm via d3-delaunay, O(n log n), 5 exports | ✅ |
| `CREATE` | COMPONENT | `src/lib/spatial/fcm.ts` | Task 1.3: PCA降维 + FCM聚类 → ManagementZone[] | ✅ |
| `CREATE` | COMPONENT | `src/lib/spatial/coordinate-transform.ts` | Task 1.5: Helmert七参数, 偏差<1m恒等返回 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/state.ts` | Task 1.4: spatialRegions/managementZones/spatialContextDigest/jieqi Annotation | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] 3 传感器 × 9 地块 → 3 Voronoi 区域
- [x] state.ts spatialRegions / managementZones default = null

### 恢复上下文审计查询

> 新 AI Session 首次启动时运行以下查询恢复本轮完整开发上下文。

```text
query_audit_logs({ targetId: "src/lib/spatial/types.ts" })
query_audit_logs({ targetId: "src/lib/spatial/voronoi.ts" })
query_audit_logs({ targetId: "src/lib/spatial/fcm.ts" })
query_audit_logs({ targetId: "src/lib/spatial/coordinate-transform.ts" })
query_audit_logs({ targetId: "src/agents/state.ts" })
```

---

## 第2轮 spatialPreprocessing 节点 ✅

### 你当前的位置

你是第 2 轮。上游第 1 轮已完成。

### 上游已完成

- `src/lib/spatial/voronoi.ts` — computeVoronoiRegions() 可调用
- `src/lib/spatial/fcm.ts` — computeManagementZones() 可调用
- `src/agents/state.ts` — spatialRegions / managementZones 字段

### 原子事务目标

新建 spatialPreprocessing 节点，编排 Voronoi + FCM 计算。

### 你要改的文件（1 个：1 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/spatial-preprocessing.ts` | 新建 | 空间预处理节点：调 Farm-Server → Voronoi + FCM → 写入 AgentState。纯代码逻辑，不调 LLM |

> **实践优化**: 后续在轮次 6-7 的 OOP 重构中，此节点重构为 `SpatialPreprocessingNode` 独立类，包含 checkCache/compute/syncToGlobalState 三段式 + GlobalState 缓存读写。

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `NODE_CREATED` | NODE | `src/agents/nodes/spatial-preprocessing.ts` | Task 2.1: 调Farm-Server /massif/options + /equipment/page → Voronoi+FCM → 写入AgentState | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] 数据完整性三字段非空校验

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/nodes/spatial-preprocessing.ts" })
```

---

## 第2.5轮 toolResults 保鲜基础设施 ✅

### 你当前的位置

你是第 2.5 轮。上游第 1-2 轮已完成。

### 原子事务目标

JieqiTable Prisma model + 节气种子脚本 + getCurrentJieqi 运行时查询 + toolResultFreshness 保鲜策略 + toolResultsHydration 节点重构 + deep 图拓扑更新。

### 你要改的文件（6 个：3 新建 + 3 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `prisma/main.prisma` | 修改 | JieqiTable 表：(year, name, date, time, source, projectId) |
| `scripts/seed-jieqi.ts` | 新建 | 紫金山天文台节气数据种子脚本 |
| `src/lib/jieqi.ts` | 新建 | getCurrentJieqi() + isJieqiChanged() |
| `src/caijuehub/strategies/toolResultFreshness.ts` | 新建 | resolveToolResultFreshness() + RefreshPolicy |
| `src/agents/nodes/tool-results-hydration.ts` | 修改 | 接入 caijuehub 保鲜策略 |
| `src/agents/agent-graph.ts` | 修改 | toolNode → toolResultsHydration → spatialPreprocessing |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `CREATE` | SCHEMA | `prisma/main.prisma` | Task 2.5.1: JieqiTable `@@unique([year,name,projectId])` + `@@index([year,projectId])` | ✅ |
| `CREATE` | COMPONENT | `scripts/seed-jieqi.ts` | Task 2.5.2: 紫金山天文台官方数据, `pnpm seed:jieqi` | ✅ |
| `CREATE` | COMPONENT | `src/lib/jieqi.ts` | Task 2.5.3: getCurrentJieqi() projectId覆盖→fallback全国, isJieqiChanged() | ✅ |
| `CREATE` | COMPONENT | `src/caijuehub/strategies/toolResultFreshness.ts` | Task 2.5.4: resolveToolResultFreshness(), realtime/daily-cache/jieqi/weekly | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/tool-results-hydration.ts` | Task 2.5.5: 接入 caijuehub resolveToolResultFreshness() 策略层 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/agent-graph.ts` | Task 2.5.6: toolNode→toolResultsHydration→spatialPreprocessing 拓扑更新 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] JieqiTable migration 幂等
- [x] getCurrentJieqi() 优先 projectId 覆盖 → fallback 全国默认
- [x] toolResultsHydration 接入 caijuehub 策略层

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "prisma/main.prisma" })
query_audit_logs({ targetId: "scripts/seed-jieqi.ts" })
query_audit_logs({ targetId: "src/lib/jieqi.ts" })
query_audit_logs({ targetId: "src/caijuehub/strategies/toolResultFreshness.ts" })
query_audit_logs({ targetId: "src/agents/nodes/tool-results-hydration.ts" })
query_audit_logs({ targetId: "src/agents/agent-graph.ts" })
```

---

## 第3轮 summaryRetrieval + summaryReasoning ✅

### 你当前的位置

你是第 3 轮。上游第 1-2.5 轮已完成。

### 上游已完成

- `src/agents/nodes/spatial-preprocessing.ts` — 空间预处理节点
- `src/agents/experts/registry.ts` — AnalysisExpert 新增 summaryExpertIds 字段

### 原子事务目标

新建 summaryRetrieval + summaryReasoning 节点。

### 你要改的文件（2 个：2 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/summary-retrieval.ts` | 新建 | 领域知识代理检索：跨 collection ChromaDB 联合检索 |
| `src/agents/nodes/summary-reasoning.ts` | 新建 | 汇总专家推理：三字段完整性验证 → 空间上下文 → LLM invoke |

> **实践优化**: 后续 OOP 重构中，summary-reasoning.ts 重构为 `SummaryReasoningNode extends BaseReasoningNode`，聚合模式为 `detailed`。

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `NODE_CREATED` | NODE | `src/agents/nodes/summary-retrieval.ts` | Task 3.1: summaryExpertIds→collectionName 跨collection检索, 每collection 5条/总上限10 | ✅ |
| `CREATE` | NODE | `src/agents/nodes/summary-retrieval.ts` | 第3轮：领域知识代理检索节点（第二次 record_dev_operation 确认） | ✅ |
| `NODE_CREATED` | NODE | `src/agents/nodes/summary-reasoning.ts` | Task 3.2: 三字段完整性校验+buildSpatialContextSection+单LLM invoke | ✅ |
| `CREATE` | NODE | `src/agents/nodes/summary-reasoning.ts` | 第3轮：汇总专家推理节点（第二次 record_dev_operation 确认） | ✅ |
| `REGISTRY_MODIFIED` | REGISTRY | `src/agents/experts/registry.ts` | 轮次3: AnalysisExpert 新增 summaryExpertIds 字段 (string[]) | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] summaryRetrieval：两级优先级（summaryExpertIds → 降级所有非 isSummary 专家）
- [x] summaryReasoning：三字段完整性校验 + 降级路径

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/nodes/summary-retrieval.ts" })
query_audit_logs({ targetId: "src/agents/nodes/summary-reasoning.ts" })
query_audit_logs({ targetId: "src/agents/experts/registry.ts" })
```

---

## 第4轮 现有推理改造 + Graph 接入 ✅

### 你当前的位置

你是第 4 轮。上游第 1-3 轮已完成。

### 原子事务目标

删除 reasoning.ts 截断 + per-expert 数据源改造 + Prompt 类型扩展 + Graph 拓扑接入。

### 你要改的文件（5 个：5 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/reasoning.ts` | 修改 | 删除 contentStr.slice(0,200) 截断，改用 state.toolResults |
| `src/agents/nodes/per-expert-reasoning.ts` | 修改 | 消费 state.toolResults 结构化数据 |
| `src/agents/prompts/types.ts` | 修改 | 新增 SpatialContext / RegionSummary 接口 |
| `src/agents/agent-graph.ts` | 修改 | deep 图新增 3 节点 + 条件边 |
| `src/agents/edges/conditional.ts` | 修改 | routeByIntent 新增 spatialPreprocessing 路由分支 |

> **实践优化**: 后续 OOP 重构中，reasoning.ts → `ReasoningNode extends BaseReasoningNode`，per-expert-reasoning.ts → `PerExpertReasoningNode extends BaseReasoningNode`，agent-graph.ts 使用 `XxxNode.toNodeFunction()` 工厂方法。

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `MODIFY` | COMPONENT | `src/agents/nodes/reasoning.ts` | Task 4.1: 删除 contentStr.slice(0,200) 截断→state.toolResults 结构化 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/per-expert-reasoning.ts` | Task 4.2: JSON.stringify(tr.list)→state.toolResults 结构化替代全量 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/context-engine/types.ts` | Task 4.3: SpatialContext/ManagementZone re-export, ExpertPromptInput.spatialContext | ✅ |
| `COMPONENT_MODIFIED` | COMPONENT | `src/agents/prompts/types.ts` | Task 4.3: ExpertPromptInput 新增 spatialContext 字段 + SpatialContext/RegionSummary 接口 | ✅ |
| `GRAPH_MODIFIED` | GRAPH | `src/agents/agent-graph.ts` | Task 4.4: deep图新增 spatialPreprocessing/summaryRetrieval/summaryReasoning 三节点+条件边 | ✅ |
| `GRAPH_MODIFIED` | GRAPH | `src/agents/agent-graph.ts` | Task 4.4(二次): 方案B投影(AgentState→GlobalState.spatial) + 注册确认 | ✅ |
| `COMPONENT_MODIFIED` | COMPONENT | `src/agents/edges/conditional.ts` | Task 4.4: isSummary+toolResults.length>0→spatialPreprocessing, +tracer.recordRouteDecision | ✅ |
| `COMPONENT_MODIFIED` | COMPONENT | `src/agents/edges/conditional.ts` | Task 4.4(二次): routeByIntent 新增 spatialPreprocessing 分支确认 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] grep 确认 reasoning.ts `slice(0,200)` 已删除
- [x] per-expert-reasoning.ts 使用 state.toolResults（非 messages）
- [x] professional 图拓扑未修改

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/nodes/reasoning.ts" })
query_audit_logs({ targetId: "src/agents/nodes/per-expert-reasoning.ts" })
query_audit_logs({ targetId: "src/agents/context-engine/types.ts" })
query_audit_logs({ targetId: "src/agents/prompts/types.ts" })
query_audit_logs({ targetId: "src/agents/agent-graph.ts" })
query_audit_logs({ targetId: "src/agents/edges/conditional.ts" })
```

---

## 第4.5-4.8轮 tool-result-aggregator + 三节点接入 ✅

### 你当前的位置

你是第 4.5-4.8 轮。上游第 1-4 轮已完成。

> **架构定位**: 本模块属于 Prompt Engine 的输入侧数据准备层，与 awareness.ts（觉知注入）平级。空间计算层（Voronoi/FCM）只管纯几何计算，本模块负责将结构化数据变成 prompt 文本。

### 原子事务目标

新建 tool-result-aggregator 模块（Prompt Engine 输入侧）+ 统计/空间验证工具 + 三个推理节点接入聚合。

### 你要改的文件（12 个：6 新建 + 6 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/prompts/tool-result-aggregator/index.ts` | 新建 | 公共 API aggregateToolResults() + compact/standard/detailed 三级 |
| `src/agents/prompts/tool-result-aggregator/types.ts` | 新建 | PlotStat / RegionSummary / DetailLevel / AggregationResult |
| `src/agents/prompts/tool-result-aggregator/massif-grouper.ts` | 新建 | 按 massifId 分组 |
| `src/agents/prompts/tool-result-aggregator/trend-calculator.ts` | 新建 | Mann-Kendall + Sen's Slope + 正态分布策略接口 |
| `src/agents/prompts/tool-result-aggregator/stats-calculator.ts` | 新建 | 均值 + 标准差 |
| `src/agents/prompts/tool-result-aggregator/summary-builder.ts` | 新建 | 结构化摘要 + 验证工具提示 |
| `src/agents/tools/impl/statistic-tools.ts` | 新建 | verify_mean/std/trend + detect_outliers |
| `src/agents/tools/impl/statistic-tools-wrapper.ts` | 新建 | LangChain tool 包装 |
| `src/agents/tools/impl/spatial-tools.ts` | 新建 | verify_plot_region/zone_membership/sensor_coverage/plot_distance |
| `src/agents/tools/impl/spatial-tools-wrapper.ts` | 新建 | LangChain tool 包装 |
| `src/agents/tools/index.ts` | 修改 | 注册 8 个验证工具 |
| `src/agents/prompts/awareness.ts` | 修改 | 新增 buildSpatialVerificationHint + injectAwareness hasSpatialData 参数 |

### 关键设计

```text
aggregateToolResults(toolResults, spatialRegions?, detailLevel)
  ├─ compact  (~20 tokens):   地块数 + 记录总数
  ├─ standard (~100-200):     + 每地块统计量(均值+标准差) + 趋势箭头
  └─ detailed (~300-500):     + 区域归并 + 自然语言摘要
```

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `CREATE` | COMPONENT | `src/agents/prompts/tool-result-aggregator/index.ts` | Task 4.5: aggregateToolResults() 三级+6子模块(types/massif-grouper/trend-calculator/stats-calculator/summary-builder) | ✅ |
| `CREATE` | COMPONENT | `src/agents/tools/impl/spatial-tools.ts` | Task 4.5: verify_plot_region/zone_membership/sensor_coverage/plot_distance | ✅ |
| `CREATE` | COMPONENT | `src/agents/tools/impl/spatial-tools-wrapper.ts` | Task 4.5: LangChain tool 包装 verifyPlotRegionTool 等 4 工具 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/tools/index.ts` | Task 4.5: 注册8验证工具(spatial×4+statistic×4) | ✅ |
| `MODIFY` | COMPONENT | `src/agents/prompts/awareness.ts` | Task 4.5: +buildSpatialVerificationHint, injectAwareness +hasSpatialData参数 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/summary-reasoning.ts` | Task 4.6: detailLevel="detailed" + spatialRegions区域归并 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/reasoning.ts` | Task 4.7: detailLevel="standard", 替换一句话摘要(toolResultsBlock) | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/per-expert-reasoning.ts` | Task 4.8: detailLevel="compact", 替换 JSON.stringify(tr.list) 全量 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] aggregateToolResults 三级输出正确
- [x] Mann-Kendall + Sen's Slope 计算正确（O(n²) n<500 零压力）
- [x] 8 个验证工具已注册到 agentTools
- [x] summary-reasoning 使用 `detailed` 模式
- [x] reasoning 使用 `standard` 模式
- [x] per-expert-reasoning 使用 `compact` 模式

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/prompts/tool-result-aggregator/index.ts" })
query_audit_logs({ targetId: "src/agents/tools/impl/spatial-tools.ts" })
query_audit_logs({ targetId: "src/agents/tools/impl/spatial-tools-wrapper.ts" })
query_audit_logs({ targetId: "src/agents/tools/index.ts" })
query_audit_logs({ targetId: "src/agents/prompts/awareness.ts" })
```

---

## 第5轮 ★ 觉知注入层（Review §10 回流）✅

### 你当前的位置

你是第 5 轮。上游第 1-4.8 轮已完成。

### 原子事务目标

新建觉知注入层：T0-T3 自适应分级生成空间感知文本 + per-expert 差异化注入。

### 你要改的文件（1 个：1 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/prompts/awareness.ts` | 新建 | buildSpatialDigest() T0-T3 自适应分级 + injectAwareness() per-expert 差异化 + buildSpatialVerificationHint() |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_CREATED` | COMPONENT | `src/agents/prompts/awareness.ts` | Task 5.1: buildSpatialDigest() T0-T3 + injectAwareness() per-expert差异化(summary→all, pest_risk→insect, weather_impact→weather) | ✅ |
| `STATE_MODIFIED` | STATE | `src/agents/state.ts` | Task 5.2: 新增 spatialAwareness Annotation<string\|null>, 不进Checkpointer | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] T0-T3 分级判定逻辑正确
- [x] per-expert 过滤：pest_risk→insect, weather_impact→weather, 汇总专家→all
- [x] buildSpatialVerificationHint 返回空间验证工具列表

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/prompts/awareness.ts" })
query_audit_logs({ targetId: "src/agents/state.ts" })
```

---

## 第6轮 ★ GlobalState 第八域 spatial（Review §10 回流）✅

### 你当前的位置

你是第 6 轮。上游第 1-5 轮已完成。

### 原子事务目标

GlobalState 新增第八域 spatial：SpatialStateSnapshot 类型 + spatial 域 default + syncSpatial() 方法 + spatialPreprocessing 缓存读写。

### 你要改的文件（2 个：2 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/global-state.ts` | 修改 | +SpatialStateSnapshot + spatial 域 + syncSpatial() + jieqi 字段 |
| `src/agents/nodes/spatial-preprocessing.ts` | 修改 | checkCache() → compute() → syncToGlobalState() 三段式 |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] SpatialStateSnapshot 字段完整：spatialRegions / managementZones / spatialContextDigest / computedAt / sensorIds / jieqi
- [x] syncSpatial() 方法签名正确
- [x] spatialPreprocessing 缓存命中 → 跳过 API 调用（TTL 1h）

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_MODIFIED` | COMPONENT | `src/agents/global-state.ts` | Task 6.1: SpatialStateSnapshot+spatial域(第八域)+syncSpatial()+jieqi字段 | ✅ |
| `COMPONENT_CREATED` | COMPONENT | `src/agents/global-state.ts` | 轮次5-7补全: global-state.ts第八域+awareness.ts+registry.ts summaryExpertIds | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/spatial-preprocessing.ts` | Task 6.2: checkCache→compute→syncToGlobalState 三段式, TTL 1h | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] SpatialStateSnapshot 字段完整：spatialRegions / managementZones / spatialContextDigest / computedAt / sensorIds / jieqi
- [x] syncSpatial() 方法签名正确
- [x] spatialPreprocessing 缓存命中 → 跳过 API 调用（TTL 1h）

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/global-state.ts" })
query_audit_logs({ targetId: "src/agents/nodes/spatial-preprocessing.ts" })
```

---

## 第7轮 ★ 觉知裁决（Review §10 回流）[含 OOP 重构] ✅

### 你当前的位置

你是第 7 轮。上游第 1-6 轮已完成。

### 原子事务目标

新建觉知裁决策略：resolveAwareness() 实现 per-expert TTL 检查 + 缓存命中/过期判定 + buildSpatialDigest 按需生成。

### 你要改的文件（1 个：1 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/caijuehub/strategies/awareness.ts` | 新建 | resolveAwareness() TTL 检查 + per-expert 过滤 + 级别判定 |

---

### ▸ 实践优化：OOP 重构（轮次 5-7 的实施过程中完成）

> 在本轮实施过程中，三个推理节点 + spatialPreprocessing 节点进行了 OOP 重构，提取了 BaseReasoningNode 抽象基类（6 项共享能力），避免在每个子类中重复实现相同逻辑。此重构属于轮次 5-7 的实践过程优化，不改变轮次边界。

**核心设计**：
```text
BaseReasoningNode (abstract)
│  1. checkRagEmpty()           — GlobalState ragEmpty 检测
│  2. aggregateTools()          — tool-result-aggregator 聚合
│  3. formatAggregatedSummary() — 聚合结果 → 文本摘要
│  4. buildStatisticToolHints() — 统计验证工具提示
│  5. buildSpatialToolHints()   — 空间验证工具提示
│  6. injectSpatialAwareness()  — 空间感知注入（resolveAwareness TTL 裁决）
│
├── ReasoningNode (deep 普通专家)
│     额外: KB 冲突检测 + evidenceChain 回写
│
├── SummaryReasoningNode (deep 汇总专家)
│     额外: buildSpatialContextSection + detailed 聚合
│
└── PerExpertReasoningNode (pro 单专家)
      额外: fanoutExpertId + 按 realtimeToolNames 过滤

SpatialPreprocessingNode (独立类，非推理节点)
  checkCache() → compute() → syncToGlobalState()
```

**OOP 重构涉及的文件**（6 个：1 新建 + 5 修改）：

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/agents/nodes/base-reasoning-node.ts` | 新建 | 抽象基类：6 项共享能力 |
| `src/agents/nodes/reasoning.ts` | 修改 | → ReasoningNode extends BaseReasoningNode |
| `src/agents/nodes/summary-reasoning.ts` | 修改 | → SummaryReasoningNode extends BaseReasoningNode |
| `src/agents/nodes/per-expert-reasoning.ts` | 修改 | → PerExpertReasoningNode extends BaseReasoningNode |
| `src/agents/nodes/spatial-preprocessing.ts` | 修改 | → SpatialPreprocessingNode 独立类 |
| `src/agents/agent-graph.ts` | 修改 | 4 个节点使用 XxxNode.toNodeFunction()（-36行） |

---

### ADD-7 审计记录 — 第7轮本体

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_CREATED` | COMPONENT | `src/caijuehub/strategies/awareness.ts` | Task 7.1: resolveAwareness() TTL, pest_risk=1h/weekly_report=1d/land_analysis=-1, AwarenessDecision{shouldInject,digest,cacheHit,ttlExpired} | ✅ |

### ADD-7 审计记录 — OOP 重构（实践优化）

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `CREATE` | COMPONENT | `src/agents/nodes/base-reasoning-node.ts` | OOP: 抽象基类 BaseReasoningNode, 6项共享能力, exports ReasoningNodeContext | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/base-reasoning-node.ts` | OOP(轮次7适配): injectSpatialAwareness → resolveAwareness() TTL裁决, updateDomain写回 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/reasoning.ts` | OOP: →ReasoningNode, KB冲突检测+evidenceChain回写, standard聚合, 6项能力对齐 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/summary-reasoning.ts` | OOP: →SummaryReasoningNode, buildSpatialContextSection, detailed聚合, 6项能力对齐 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/per-expert-reasoning.ts` | OOP: →PerExpertReasoningNode, fanoutExpertId过滤, standard全量, 6项能力对齐 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/spatial-preprocessing.ts` | OOP: →SpatialPreprocessingNode, checkCache/compute/syncToGlobalState三段式 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/agent-graph.ts` | OOP: toNodeFunction()工厂方法替换, 172→136行(-36), 零内联逻辑, 4 factoryMethods | ✅ |

### 交叉轮次记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `DECISION` | PLAN | `src/lib/spatial/data-fidelity.ts` | 轮次8 数据保真度推迟: Kalman+D-S是精度调优层非功能缺失, defer to v2 | ✅ |

---

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] per-expert TTL 映射正确：daily_report=1h, weekly_report=1d, pest_risk=1h, land_analysis=-1
- [x] AwarenessDecision 输出字段完整：shouldInject / digest / cacheHit / ttlExpired
- [x] injectSpatialAwareness 通过 resolveAwareness() 做 TTL 裁决
- [x] 缓存未命中时 updateDomain("spatial", { spatialContextDigest }) 写回
- [x] 三个推理节点共享 BaseReasoningNode 6 项能力
- [x] agent-graph.ts 使用 toNodeFunction() 工厂方法
- [x] reasoning.ts KB 冲突检测能力未丢失
- [x] reasoning.ts evidenceChain 回写能力未丢失
- [x] summary-reasoning.ts buildSpatialContextSection 能力未丢失
- [x] per-expert-reasoning.ts fanoutExpertId 过滤能力未丢失
- [x] spatial-preprocessing.ts 缓存读写能力未丢失

### 恢复上下文审计查询 — 第7轮本体 + OOP 重构

```text
query_audit_logs({ targetId: "src/caijuehub/strategies/awareness.ts" })
query_audit_logs({ targetId: "src/agents/nodes/base-reasoning-node.ts" })
query_audit_logs({ targetId: "src/agents/nodes/reasoning.ts" })
query_audit_logs({ targetId: "src/agents/nodes/summary-reasoning.ts" })
query_audit_logs({ targetId: "src/agents/nodes/per-expert-reasoning.ts" })
query_audit_logs({ targetId: "src/agents/nodes/spatial-preprocessing.ts" })
query_audit_logs({ targetId: "src/agents/agent-graph.ts" })
```

---

## 第8轮 ★ 数据保真度 + 加权仲裁（Kalman + D-S）⬜

### 你当前的位置

你是第 8 轮。上游第 1-7 轮已完成。

### 上游已完成

- `src/caijuehub/strategies/awareness.ts` — 觉知裁决
- `src/agents/global-state.ts` — SpatialStateSnapshot + syncSpatial()
- `src/agents/prompts/tool-result-aggregator/` — RegionSummary 产出

### 原子事务目标

为每个 RegionSummary 字段计算保真度权重，Kalman 滤波平滑传感器噪声，加权仲裁覆盖 LLM 数值偏差。

### 你要改的文件（2 个：2 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/lib/spatial/data-fidelity.ts` | 新建 | 8.1 FidelityProfile 保真度评估（sourceAccuracy/completeness/consistency/beliefEntropy/kalmanGain → compositeWeight）；8.2 卡尔曼滤波平滑（kalmanFieldProfile: R=传感器精度, Q=历史方差, P₀=R×2，连续3点增益收敛 \|ΔK\|<0.01） |
| `src/caijuehub/strategies/data-fidelity.ts` | 新建 | 8.3 resolveFieldArbitration()：compositeWeight≥0.65→override, 0.4-0.65→blend, <0.4→keep_llm |

### 关键设计

```text
数据管道:
  Farm-Server 传感器原始值
    → Kalman 滤波 (kalmanFieldProfile, P₀=R×2)
    → FidelityProfile (5 维权重 → compositeWeight)
    → resolveFieldArbitration (三档仲裁)
    → 后处理覆盖 (response.ts 消费)
```

### 验证标准

- [ ] `npx tsc --noEmit` 通过
- [ ] 权重值在 0-1 范围且符合源精度等级
- [ ] 连续 3 点卡尔曼增益收敛（|ΔK| < 0.01）
- [ ] 仲裁结果可追溯 reason

---

## 第9轮 报告模板数据结构化 ⬜

### 你当前的位置

你是第 9 轮。上游第 1-8 轮已完成。

### 原子事务目标

重构报告模板目录结构，泛型化 ReportSectionDef，新增 dataSchema 字段定义。

### 你要改的文件

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/reports/` → `src/agents/report-templates/` | 重命名+拆分 | agrisynapse/h5 子目录 |
| `src/agents/experts/registry.ts` | 修改 | ReportSectionDef 泛型化 + dataSchema 新增（contentType/fields/source/nested/columnConfig） |
| `src/agents/report-templates/agrisynapse/*.ts` (13个) | 修改 | 各自补齐 dataSchema，evidence 型章节定义 columns |
| `src/agents/report-templates/h5/*.ts` (新建) | 新建 | 镜像已有 H5 route Zod DTO 结构 |

### 验证标准

- [ ] `npx tsc --noEmit` 通过
- [ ] 目录结构正确
- [ ] 每个模板 dataSchema 字段完整性校验通过

---

## 第10轮 多 GUI 渲染解耦 + 后处理校验 ⬜

### 你当前的位置

你是第 10 轮。上游第 1-9 轮已完成。

### 上游已完成

- `src/agents/report-templates/` — 模板目录重构+dataSchema 字段已补齐
- `src/lib/spatial/data-fidelity.ts` — FidelityProfile + Kalman 滤波
- `src/caijuehub/strategies/data-fidelity.ts` — 加权仲裁

### 原子事务目标

后处理校验层实现：调用 data-fidelity 加权仲裁后覆盖 LLM 数值偏差。sectionType 开放映射 + authoritative 权威数据覆盖。

### 你要改的文件

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/response.ts` | 修改 | 后处理校验层：遍历 dataSchema.fields，source:"authoritative" 字段经加权仲裁后覆盖 LLM |
| `src/agents/report-templates/agrisynapse/*.ts` | 修改 | 核验 columnConfig 与 el-table-column 属性对齐 |

### 验证标准

- [ ] `npx tsc --noEmit` 通过
- [ ] authoritative 字段用 RegionSummary 权威数据覆盖 LLM 数值偏差
- [ ] columnConfig 与 el-table-column 属性对齐

---

## 第11轮 Prompt 装订 + Response 装订 + EventBus + 专家注册 ⬜

### 你当前的位置

你是第 11 轮。上游第 1-10 轮已完成。

### 原子事务目标

Prompt 装订 + Response 装订 + EventBus + 专家注册。

### 你要改的文件（7 个：7 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/prompts/experts/factory.ts` | 修改 | ExpertPromptInput 注入 spatialContext；build() 注入 `[空间上下文]` 区块 |
| `src/agents/nodes/response.ts` | 修改 | +buildRegionSummary + isSummary 分支：消费 reportTemplate 替代 strategy.sections |
| `src/agents/cognitive-event-bus.ts` | 修改 | +fanout_started / fanin_complete |
| `src/lib/langgraph/send-api.ts` | 修改 | emit fanout_started |
| `src/agents/nodes/kb-conflict-aggregator.ts` | 修改 | emit fanin_complete |
| `src/agents/experts/registry.ts` | 修改 | +summaryExpertIds |
| `src/config/chroma-config.ts` | 修改 | +SUMMARY_RETRIEVAL_CONFIG（PER_COLLECTION_LIMIT / TOTAL_LIMIT） |

### 验证标准

- [ ] `npx tsc --noEmit` 通过
- [ ] factory.ts 注入 spatialContext 后 prompt 含 `[空间上下文]` 区块
- [ ] response.ts isSummary 分支使用 reportTemplate 章节定义
- [ ] EventBus 可订阅 fanout_started / fanin_complete
- [ ] SUMMARY_RETRIEVAL_CONFIG 参数集中管理

---

## 第12轮 professional 图 toolResultsHydration 扩展 ⬜

### 你当前的位置

你是第 12 轮。上游第 1-11 轮已完成。

### 上游已完成

- `src/agents/nodes/tool-results-hydration.ts` — deep 图保鲜节点已稳定
- `src/agents/agent-graph.ts` — deep 图拓扑已就绪

### 原子事务目标

professional 图接入 toolResultsHydration 节点。

### 你要改的文件（1 个：1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/agent-graph.ts` | 修改 | professional 图 `toolNode → toolResultsHydration → [perExpert fan-out]` |

> **前置条件**: deep 图验证效果后决定是否执行。perExpertReasoning 是第一批消费者。

### 验证标准

- [ ] `npx tsc --noEmit` 通过
- [ ] professional 图拓扑验证正确

---

## 第13轮 编译 + Lint + 手动验证 + 架构文档 ⬜

### 你当前的位置

你是最后一轮。上游第 1-12 轮已完成。

### 原子事务目标

全量编译验证 + ESLint + 端到端验证 + 架构文档更新。

### 验证标准

- [ ] `npx tsc --noEmit` 零错误
- [ ] `npx eslint src/` 零 error
- [ ] 9 地块 + 3 传感器 → 3 Voronoi 区域 + 3 FCM 分区
- [ ] 觉知注入：每轮 prompt 含空间 digest（T0-T3 自适应格式），per-expert 差异化
- [ ] GlobalState 缓存：TTL 未过期 + sensorIds 未变 → 跳过 API 调用
- [ ] resolveAwareness() TTL 裁决生效
- [ ] BaseReasoningNode 6 项能力在三个子类中均工作
- [ ] 后处理校验：authoritative 字段经加权仲裁后覆盖 LLM 数值偏差
- [ ] 回退路径：spatialRegions 为空时行为一致
- [ ] professional 图 toolResultsHydration 拓扑正确
- [ ] 架构文档已更新

---

## 每轮收敛判定补充规则

- checklist 全部项已勾选，不得有空勾选或推测通过
- 每完成一个文件修改：record_dev_operation 写入 ADD-7 审计
- 写入审计后：query_audit_logs 回查确认落库

---

## 附录：每轮启动模板

```text
## 上下文
你在执行 farm-agent-spatial-reasoning 改进的 [第N轮]。
上游已完成。先读 .qoder/plans/2026-07/07/farm-agent-spatial-reasoning-handoff-v3.md 的 <第N轮> 章节。

## 启动操作
1. session-init SKILL
2. add-paradigm SKILL
3. 读 .qoder/specs/farm-agent-spatial-reasoning/spec.md / tasks.md / checklist.md
4. 按 tasks.md 顺序执行
5. 每完成一个文件：record_dev_operation → query_audit_logs 回查
```

### 脱敏要求

禁止出现以下硬编码值：数据库密码、Chroma auth token、JWT 密钥、API Key、Farm-Server 凭证。所有凭据值通过 `${ENV_VAR}` 引用。
