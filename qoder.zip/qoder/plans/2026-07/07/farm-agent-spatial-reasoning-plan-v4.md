# farm-agent 空间推理 Plan v4 — toolResults 保鲜策略增量补充

> **基线文档**: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-plan-v3.md`（1640 行，不再修改）
> **增量范围**: 轮次 2.5 的 toolResults 保鲜策略细化 + per-expert TTL 保鲜策略 + caijuehub 归属
> **同步日期**: 2026-07-22
> **Spec**: `.qoder/specs/farm-agent-spatial-reasoning/spec.md`

---

## 一、v3 轮次 2.5 的问题回顾

v3 轮次 2.5 实现了三个文件：

| 文件 | 状态 | 问题 |
|------|:----:|------|
| `prisma/main.prisma` — ToolResultSnapshot | ✅ 已完成 | 无问题 |
| `src/lib/tool-result-cache.ts` | ✅ 已完成 | 纯缓存读写层，边界清晰 |
| `src/agents/nodes/tool-results-hydration.ts` | ⚠️ 需重构 | 当前硬编码 `today === today` + 方案 C 一刀切，未按 per-expert TTL 区分行为 |

**核心问题**：hydration 节点把所有专家的保鲜策略一刀切为"当天跳过缓存"，但实际不同专家/场景的行为差异很大（见下表）。

---

## 二、完整的 per-expert TTL 保鲜策略

### 2.1 策略决策矩阵

不同场景下，三层存储的交互行为完全不同：

| 场景 | Checkpointer | GlobalState.spatial | tool_result_snapshot | Farm-Server |
|------|:-----------:|:-------------------:|:-------------------:|:-----------:|
| 同一 thread resume | ✅ 恢复 toolResults | TTL 检查→过期则重算（纯计算） | 不查 | ❌ 不调 |
| 日报（新 thread，daily_report） | 无历史 | TTL=1h 检查 | 查当天快照→未命中→走 API | 走 API |
| 周报（新 thread，weekly_report） | 无历史 | TTL=1d 检查 | 查 7 天快照→聚合 | 命中则不调 |
| pest_risk（TTL=1h 过期后） | 看是否同 thread | 过期→重算（纯计算） | 不查 | ❌ 不调 |
| land_analysis（TTL=-1） | 看是否同 thread | 永不刷新 | 首次写入后永远读快照 | 仅首次调用 |

### 2.2 完整的 per-expert TTL 表

| Expert | TTL | snapshot 查询行为 | snapshot 写入行为 | 备注 |
|--------|:---:|:-----------------:|:-----------------:|------|
| `daily_report` | 1h | 查当天快照→未命中→走 API | toolNode 返回后立即写 | 高频刷新 |
| `weekly_report` | 1d | 查 7 天快照→聚合 | toolNode 返回后立即写 | 周报收益最大（省 6 天 API） |
| `pest_risk` | 1h | 查当天快照 | toolNode 返回后立即写 | 虫情预警 |
| `pest_risk_outbreak` | 30min | 查当天快照（窗口更短） | toolNode 返回后立即写 | 虫害爆发 |
| `weather_impact` | 1h | 查当天快照 | toolNode 返回后立即写 | 气象影响 |
| `crop_compare` | 1d | 查当天快照 | toolNode 返回后立即写 | 低频分析 |
| `roi_analysis` | 1d | 查当天快照 | toolNode 返回后立即写 | 低频分析 |
| `land_analysis` | 24节气 | 每个节气切换时失效→重新调 API→新快照；支持手动刷新 | 节气切换或手动触发时写入 | 7个下游专家依赖（见下方） |
| `nutrition_diagnose` | 待定 | 有自己的 toolResults + 自己的 TTL | 待定 | 营养诊断，依赖 land_analysis 按节气更新 |
| `growth_report` | 待定 | 有自己的 toolResults + 自己的 TTL | 待定 | 生长报告，依赖 land_analysis 按节气更新 |
| `planting_advice` | 待定 | 有自己的 toolResults + 自己的 TTL | 待定 | 种植建议，依赖 land_analysis 按节气更新 |
| `work_plan` | 待定 | 有自己的 toolResults + 自己的 TTL | 待定 | 农事计划，依赖 land_analysis 按节气更新 |
| `machinery_dispatch` | 待定 | 有自己的 toolResults + 自己的 TTL | 待定 | 农机调度，依赖 land_analysis 按节气更新 |
| `crop_compare` | 待定 | 有自己的 toolResults + 自己的 TTL | 待定 | 品种对比，依赖 land_analysis 按节气更新 |
| `roi_analysis` | 待定 | 有自己的 toolResults + 自己的 TTL | 待定 | 成本核算，依赖 land_analysis 按节气更新 |

### 2.3 三种缓存策略对比（已补充到 Spec）

| 维度 | 方案 A（不缓存） | 方案 B（全量缓存） | 方案 C（增量缓存，当前采用） |
|------|:---:|:---:|:---:|
| **缓存时机** | 永不缓存 | 立即缓存 | 当天跳过，历史缓存 |
| **实时性** | ⭐⭐⭐ 最高 | ⭐⭐ 中等 | ⭐⭐⭐ 高（当天实时） |
| **API 成本** | ⭐ 最高 | ⭐⭐⭐ 最低 | ⭐⭐ 中等 |
| **周报收益** | ❌ 无 | ✅ 省 6 天 | ✅ 省 6 天 |
| **实现复杂度** | ⭐⭐⭐ 最简单 | ⭐⭐ 中等 | ⭐⭐⭐ 高 |

**当前采用方案 C**，但不应一刀切——需按 per-expert TTL 差异化处理。

---

## 三、架构决策：caijuehub 策略归属

### 3.1 核心认知

tool_result_snapshot 的保鲜逻辑**不应该散落在 hydration 节点中硬编码**。

```
当前（错误）：
  toolResultsHydration 节点内部硬编码 "date === today → 跳过"
  ↓
  所有专家一刀切，无法区分 daily_report vs weekly_report vs land_analysis

正确：
  caijuehub/strategies/toolResultFreshness.ts（新增策略）
    ↓ 策略决策：查询日期范围 + 是否同 thread + expert 类型
  toolResultsHydration 节点（纯 IO 层）
    ↓ 执行：调 hydrateToolResults() / persistToolResults()
```

### 3.2 caijuehub 新增策略文件

**文件**: `src/caijuehub/strategies/toolResultFreshness.ts`（新建）

**职责**: 根据 expert 类型 + 当前状态，返回保鲜决策

```typescript
interface FreshnessDecision {
  /** 是否需要查询 snapshot */
  shouldQuerySnapshot: boolean
  /** 查询的日期范围（如周报 = 7 天数组） */
  queryDates: string[]
  /** 是否需要写入 snapshot */
  shouldPersist: boolean
  /** 写入日期 */
  persistDate: string
  /** 是否透传（同 thread resume 时） */
  shouldPassthrough: boolean
  /** 决策原因（审计用） */
  reason: string
}

function resolveToolResultFreshness(
  expertId: string,
  isSameThreadResume: boolean,
  currentDate: string
): FreshnessDecision
```

### 24 节气刷新机制（land_analysis + 7 个下游专家）

land_analysis 采用**24 节气刷新 + 允许手动刷新**，而非简单的 TTL 或永续快照。

**RefreshPolicy 枚举**：

``` typescipt
type RefreshPolicy =
  | "realtime"      // daily_report/pest_risk/weather_impact: 1h/30min/1h
  | "daily-cache"   // weekly_report: 查 7 天快照聚合
  | "jieqi"    // land_analysis: 24 节气切换时失效
  | "weekly"        // growth_report/machinery_dispatch: 周度刷新
```

**24 节气判断逻辑**：

``` typescipt
snapshot.jieqi = "小暑"
当前节气 = getCurrentJieqi()  // 根据公历日期计算（每年日期固定±1天）

if (snapshot.jieqi !== 当前节气):
  → 快照失效，重新调 API，写入新快照（jieqi=当前节气）
else:
  → 快照有效，直接读取

手动刷新: 用户通过 GUI 触发 → 强制失效 → 重新调 API
```

**land_analysis 与下游专家的关系**：

7 个专家（nutrition_diagnose / growth_report / planting_advice / work_plan / machinery_dispatch / crop_compare / roi_analysis）**依赖** land_analysis 的数据（土地信息），但**各自有独立的 toolResults 和自己的 TTL 保鲜策略**。

land_analysis 按 24 节气更新的意义：这些专家调 toolNode 时，如果 pipeline 中需要先获取土地数据，确保拿到的是当前节气的最新土地快照，而非过期的旧数据。

**兜底检查逻辑**：

触发这 7 个专家时，`resolveToolResultFreshness()` 先执行前置检查，再执行自身 TTL 检查：

```
resolveToolResultFreshness(expertId, isResume, currentDate)
  │
  ├── 1. 前置检查：expertId ∈ LAND_ANALYSIS_DEPENDENTS？
  │     ├── 是 → 查 land_analysis snapshot.jieqi vs 当前节气
  │     │     ├── 节气已切换 → 标记 land_analysis 需刷新
  │     │     └── 节气未变 → 跳过
  │     └── 否 → 跳过
  │
  └── 2. 自身 TTL 检查
        └── 按 expertId 自己的 TTL/RefreshPolicy 决策
```

```typescript
const LAND_ANALYSIS_DEPENDENTS = [
  "nutrition_diagnose",
  "growth_report",
  "planting_advice",
  "work_plan",
  "machinery_dispatch",
  "crop_compare",
  "roi_analysis",
] as const
```

### 24 节气数据存表方案

节气数据必须存入数据库表（JieqiTable），而非硬编码在代码中。

**数据来源与权威性**：

| 年份范围 | 数据来源 | 精度 | 责任 |
|---------|---------|:---:|------|
| 已发布年份 | 紫金山天文台官方发布 | 分钟级 | 零责任（官方权威） |
| 未发布年份 | 等待下一年度 seed 更新 | — | 运维每年初执行 `pnpm seed:jieqi` |

**实现方案**：

``prisma
model JieqiTable {
  id        Int      @id @default(autoincrement())
  year      Int                              // 2026
  name      String                           // "小暑"
  date      String                           // "07-07"
  time      String?                          // "10:38"（可选，精确到分钟）
  source    String                           // "紫金山天文台"
  projectId Int?                             // null=全国默认，有值=项目级覆盖

  @@unique([year, name, projectId])
  @@index([year, projectId])
}
```

**数据初始化流程**：

1. **种子脚本**：`scripts/seed-jieqi.ts`
   - 从紫金山天文台官方数据整理当前已发布年份的节气时刻（精确到分钟）
   - 写入 JieqiTable（projectId=null，全国默认）

2. **npm 命令**：`package.json` 新增 `"seed:jieqi": "tsx scripts/seed-jieqi.ts"`

3. **运行时查询**：
   ```typescript
   function getCurrentJieqi(projectId?: number): string {
     // SELECT from JieqiTable WHERE year=当前年
     // 优先取 projectId 匹配的行，fallback 全国默认
     // 比较 snapshot.jieqi vs 当前节气 → 判断是否过期
   }
   ```

4. **项目级覆盖**（可选）：
   - 管理后台为特定 projectId 写入本地化节气数据（如海外项目时区偏移）
   - SELECT 优先取 projectId 匹配的行

**维护流程**：
- 每年初紫金山天文台发布新年度数据后，运维执行 `pnpm seed:jieqi` 追加新年数据
- `source` 字段记录数据来源（紫金山天文台），可追溯
- 项目级覆盖通过管理后台写入（如海外项目时区偏移）

### 3.3 hydration 节点重构方向

重构后的 `toolResultsHydrationNode` 接收策略决策作为输入（从 state 或 config 传入），自身只负责 IO：

```
graph invoke
  │
  ▼
intention 节点 → 确定 expertId + isSameThreadResume
  │
  ▼
toolResultsHydration 节点
  ├── 调 resolveToolResultFreshness(expertId, isResume, today)
  │   ├── shouldPassthrough=true → return {}（同 thread resume）
  │   ├── shouldQuerySnapshot=true → hydrateToolResults(dates)
  │   │   ├── 命中 → return { toolResults: 缓存版本 }
  │   │   └── 未命中 → return {}（走 Farm-Server）
  │   └── shouldPersist=true → persistToolResults(toolResults)
  │
  ▼
spatialPreprocessing / perExpertReasoning / ...
```

### 3.4 职责边界

| 层 | 文件 | 职责 |
|----|------|------|
| **策略层** | `caijuehub/strategies/toolResultFreshness.ts` | 决策：查不查、查几天、写不写 |
| **IO 层** | `src/lib/tool-result-cache.ts` | 纯读写：hydrateToolResults / persistToolResults |
| **节点层** | `src/agents/nodes/tool-results-hydration.ts` | 组合：调策略层 → 调 IO 层 → return state 更新 |

---

## 四、实施计划

| # | 任务 | 文件 | 依赖 |
|---|------|------|------|
| v4.1 | toolResultFreshness 策略 | `src/caijuehub/strategies/toolResultFreshness.ts`（新建） | per-expert TTL 配置表 |
| v4.2 | hydration 节点重构 | `src/agents/nodes/tool-results-hydration.ts`（修改） | v4.1 |
| v4.3 | Spec 同步更新 | `.qoder/specs/farm-agent-spatial-reasoning/spec.md` | v4.1 + v4.2 |
| v4.4 | 单元测试 | `tests/tool-result-freshness.test.ts`（新建） | v4.1 |
| v4.5 | tool-result-aggregator 模块 | `src/agents/prompts/tool-result-aggregator/`（新建） | 无（独立模块） |
| v4.6 | summary-reasoning 接入聚合 | `src/agents/nodes/summary-reasoning.ts`（修改） | v4.5 |
| v4.7 | reasoning 接入聚合 | `src/agents/nodes/reasoning.ts`（修改） | v4.5 |
| v4.8 | per-expert-reasoning 接入聚合 | `src/agents/nodes/per-expert-reasoning.ts`（修改） | v4.5 |

---

## 五、与 v3 的关系

- v3 轮次 2.5 的 **2.5.1（Prisma model）和 2.5.2（tool-result-cache.ts）已完成，不需要改**
- v3 轮次 2.5 的 **2.5.3（tool-results-hydration.ts）需要重构**，接入 caijuehub 策略层
- v3 的其他轮次（3-13）不受影响
- v4 不新增轮次，只修正 2.5.3 的实现方式

---

## 六、tool-result-aggregator 模块（Prompt Engine 输入侧）

> **架构定位**：本模块属于 Prompt Engine 的输入侧数据准备层，与 `awareness.ts`（觉知注入）平级。空间计算层（Voronoi/FCM）只管纯几何计算，本模块负责将结构化数据变成 prompt 文本。

### 6.1 模块结构

```
src/agents/prompts/tool-result-aggregator/
├── index.ts                # 公共 API：aggregateToolResults()
├── types.ts                # PlotStat, RegionSummary, DetailLevel 等接口
├── massif-grouper.ts       # 按 massifId/massifName 分组
├── trend-calculator.ts     # computeTrend / computeDominantTrend
├── stats-calculator.ts     # computeAvgValues / 各数值字段统计
└── summary-builder.ts      # buildSummaryText 自然语言摘要生成
```

### 6.2 DetailLevel 设计

| 级别 | 内容 | token 估算 | 消费场景 |
|------|------|:---------:|---------|
| `compact` | 地块数 + 记录总数 | ~20 | per-expert-reasoning（professional 图） |
| `standard` | compact + 每地块统计量 + 趋势箭头 | ~100-200 | reasoning.ts（deep 普通专家） |
| `detailed` | standard + 区域归并 + 自然语言摘要 | ~300-500 | summary-reasoning.ts（deep 汇总专家） |

### 6.3 公共 API

```typescript
export function aggregateToolResults(
  toolResults: ToolResult[],
  spatialRegions?: VoronoiRegion[],  // 可选，professional 图不需要
  detailLevel: DetailLevel = "standard"
): AggregationResult {
  // 1. massif-grouper：按地块分组
  // 2. stats-calculator：计算每地块统计量
  // 3. trend-calculator：计算趋势（仅 standard/detailed）
  // 4. 区域归并（仅 detailed，需要 spatialRegions）
  // 5. summary-builder：生成自然语言摘要（仅 detailed）
}
```

### 6.4 消费者对接

| 节点 | detailLevel | spatialRegions | 改动 |
|------|:-----------:|:--------------:|------|
| `summary-reasoning.ts` | `detailed` | ✅ 有 | 替换当前 `toolResults.length` 统计 |
| `reasoning.ts` | `standard` | ❌ 无 | 替换 `toolResultsBlock` 一句话摘要 |
| `per-expert-reasoning.ts` | `compact` | ❌ 无 | 替换 `JSON.stringify(tr.list)` 全量注入 |

### 6.5 与 Prompt Engine 输出侧的关系

> **关联 Plan**：`farm-agent-prompt-engine-structured-output-plan-v1.md`
>
> 本模块和 structured-output plan 形成 Prompt Engine 的完整闭环：
> - **输入侧**（本模块）：原始 toolResults → 结构化摘要 → prompt 文本
> - **输出侧**（structured-output plan）：Zod schema + withStructuredOutput → 约束 LLM 输出
>
> 两个 plan 改的是同一个文件的**不同位置**，可以完全并行：
> ```
> per-expert-reasoning.ts 改动:
>   // 第 59-72 行（输入侧）— 本模块
>   - const toolResults = stateToolResults.filter(...).map(tr => JSON.stringify(tr.list))
>   + const toolResults = aggregateToolResults(stateToolResults, undefined, "compact")
>
>   // 第 91 行（输出侧）— structured-output plan
>   - const response = await getLLM().invoke(prompt)
>   + const { result } = await structuredInvoke(llm, prompt, ReasoningSchema)
> ```

---

## 七、架构分层总结

```
┌─────────────────────────────────────────────────┐
│  Prompt Engine                                   │
│  ├── 输入侧（数据准备）                          │
│  │   ├── tool-result-aggregator/   ← v4 新增    │
│  │   │   ├── massif-grouper                      │
│  │   │   ├── trend-calculator                    │
│  │   │   ├── stats-calculator                    │
│  │   │   └── summary-builder                     │
│  │   ├── awareness.ts（觉知注入）                 │
│  │   └── buildSpatialContextSection()            │
│  │                                               │
│  └── 输出侧（结构化约束）                         │
│      ├── structured-invoke.ts                    │
│      ├── intention.zod.ts                        │
│      └── expert-claim.zod.ts                     │
│      （参见 prompt-engine-structured-output-plan-v1.md）
│                                                   │
│  空间计算层（spatial-reasoning v3 独占）          │
│  ├── voronoi.ts（几何计算）                       │
│  ├── fcm.ts（聚类算法）                           │
│  └── coordinate-transform.ts                     │
└─────────────────────────────────────────────────┘
```
