# farm-agent-spatial-reasoning-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。

## PLAN 元信息

- **Plan 名称**: farm-agent-spatial-reasoning-v1
- **启动时间**: 2026-07-07T12:00:00+08:00
- **主导 AI**: Qoder
- **触发来源**: `project-massif-resolution` + `professional-fanout` 两个 Plan 验收后，识别出多地块分析的根本瓶颈不在工具层，而在 LLM 推理层——工具结果被截断为 200 字符碎片，LLM 无法进行空间推理
- **前置依赖**:
  - `farm-agent-project-massif-resolution-plan-v1.md`（route 层注入 prebuiltMassifIds）
  - `farm-agent-professional-fanout-plan-v1.md`（professional 图 Send API fan-out）
  - `farm-agent-thinking-level-runtime-fix-plan-v1.md`（thinkingLevel 路由到 professional）
- **关联文档**:
  - Handoff: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-spatial-reasoning-review-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/agents/nodes/reasoning.ts` | NODE | NODE_MODIFIED | L108-118 toolMessages 截断 200 字符注入 prompt | 改用 state.toolResults 结构化数据，按地块分组聚合后注入 | 待实施 |
| `src/agents/nodes/per-expert-reasoning.ts` | NODE | NODE_MODIFIED | 同 reasoning.ts 的截断逻辑 | 同 reasoning.ts 改造 | 待实施 |
| `src/agents/tools/impl/farm-data-tools.ts` | TOOL | TOOL_MODIFIED | 返回完整 list + columns，无聚合 | 新增按地块分组统计的 summary 字段 | 待实施 |
| `src/lib/spatial/voronoi.ts` | LIB | LIB_CREATED | 不存在 | Voronoi 图计算：农场轮廓 → 传感器覆盖区域划分 | 待实施 |
| `src/agents/prompts/reasoning.ts` | PROMPT | PROMPT_MODIFIED | 无空间推理上下文 | 新增空间推理 section：区域划分 + 传感器覆盖 + 四情联动 | 待实施 |
| `src/agents/prompts/experts/factory.ts` | PROMPT | PROMPT_MODIFIED | per-expert prompt 无空间上下文 | 注入 fanoutExpertId 对应的区域边界 + 传感器分布 | 待实施 |
| `src/agents/state.ts` | STATE | STATE_MODIFIED | 无 spatialRegions | 新增 spatialRegions: VoronoiRegion[] | 待实施 |
| `src/agents/nodes/response.ts` | NODE | NODE_MODIFIED | toolExecutionSummary 仅显示"返回 N 条记录" | 按地块分组展示统计摘要 | 待实施 |
| `src/agents/cognitive-event-bus.ts` | EVENT_BUS | EVENT_BUS_MODIFIED | 无 fanout 事件 | 新增 professional:fanout_started / professional:fanin_complete | 待实施 |

- **原子事务结构**: 4 轮
  - 第1轮：Voronoi 空间计算层（新建 spatial lib）
  - 第2轮：工具结果结构化聚合（farm-data-tools 改造 + reasoning 注入改造）
  - 第3轮：Prompt 工程 + 空间推理上下文（prompt 模板 + factory 改造）
  - 第4轮：CognitiveEventBus + GlobalState 感知 + tsc/eslint 验证

---

## 一、背景与目标

### 1.1 为什么前三个 Plan 没做这个

| Plan | 做了什么 | 为什么没做空间推理 |
|------|------|------|
| `thinking-level-runtime-fix` | 修路由：professional 图可达 | 只修路由，不碰推理内容 |
| `project-massif-resolution` | route 层注入 prebuiltMassifIds → 全农场默认值 | 解决的是"不缺参"，不是"怎么推理" |
| `professional-fanout` | 串行→Send API fan-out 并行 | 解决的是 experts 之间并行，不是 expert 内部推理质量 |

三个 Plan 的共同盲区：**LLM 推理时看到的是被截断的 200 字符工具结果碎片，不是完整的结构化数据**。

### 1.2 问题现状

**数据流断裂**：

```
Farm-Server → toolNode → state.toolResults (完整 list + columns)
                │
                ▼
         reasoning.ts L108-118
           contentStr.slice(0, 200) ← 截断到 200 字符
                │
                ▼
         LLM prompt: "[工具: query_insect_data] {\"success\":true,\"total\":200,\"list\":[{\"massifName\":\"一号地块\"..." ← 只看到第一条记录的碎片
```

**后果**：
1. LLM 不知道全农场有多少个地块、每个地块的趋势如何
2. 无法进行跨地块比较（"地块A 虫害上升，地块B 正常"）
3. 无法利用 graphicDrawing 坐标做空间推理（"低洼区域 + 多雨 + 湿度高 → 虫害风险高"）
4. 多传感器覆盖时无法选最优设备

### 1.3 目标

1. **工具结果不截断**：LLM 看到按地块分组的聚合统计，而非 200 字符碎片
2. **空间推理能力**：Voronoi 图预先计算区域划分 + 传感器覆盖，LLM 拿到结构化空间上下文
3. **四情联动推理**：墒情 × 虫情 × 气象 × 农事 在同一上下文内联动分析
4. **自适应采样**：重点区域（虫害上升区）可标记为高采样频率
5. **CognitiveEventBus 感知**：GlobalState 感知 fan-out 进度
6. 零 tsc 错误，零 eslint error

---

## 二、方案选型

### 2.1 候选方案对比

| 方案 | 数据注入 | 空间推理 | LLM 负载 | 结论 |
|------|------|------|------|------|
| **A: Voronoi 预计算 + 结构化聚合（推荐）** | 按区域分组统计，LLM 看到区域级摘要 | Voronoi 代码层预计算，LLM 只消费结果 | 低（4-6 个区域） | ✅ 采纳 |
| B: 全量数据不截断直送 LLM | 200 条原始记录全部注入 prompt | 无 | 极高（200 条 × 10 字段 = 5000+ tokens） | ❌ 超 LLM 注意力极限 |
| C: 保持现状（截断 200 字符） | 碎片 JSON | 无 | 低 | ❌ 不解决问题 |

### 2.2 选型理由

**方案 A（Voronoi + 聚合）**：
- Voronoi 是计算几何经典算法，时间复杂度 O(n log n)，9 个地块 < 1ms
- 输入：地块 graphicDrawing 坐标 + 传感器坐标 → 输出：每个传感器覆盖的区域多边形
- LLM 不需要做几何计算，拿到的是"区域 A（低洼区，3 地块，传感器 S1+S2 覆盖）"这样的结构化描述
- 对齐行业标准：九丞 WX-Q2 四情融合研判算法、BCBS 传感器覆盖算法

**为什么不选 B**：
- 200 个地块 × 10 字段 = 5000+ tokens 原始数据 → LLM 注意力退化
- 即使 DeepSeek-V3 支持 64K 上下文，但超过 10 个地块的逐地块分析质量急剧下降
- 行业共识：LLM 做"区域级推理"，不做"逐记录审计"

---

## 三、架构设计

### 3.1 数据流转（当前 → 预期）

**当前（截断）**：

```
query_insect_data(massifId=undefined) → Farm-Server 返回 200 条记录
  │
  ▼ state.toolResults = [{ toolName, success, recordCount: 200, list: [...], columns: [...] }]
  │
  ▼ reasoning.ts L108-118: toolMessages → contentStr.slice(0, 200) → 碎片 JSON
  │
  ▼ LLM: "查询成功，返回 200 条记录" ← 不知道内容
  │
  ▼ responseNode: toolExecutionSummary → "查询成功，返回 200 条记录"
```

**预期（结构化聚合 + 空间推理）**：

```
① query_insect_data(massifId=undefined) → Farm-Server 返回 200 条记录
  │
  ▼ state.toolResults = [{ toolName, success, recordCount, list: [...], columns: [...] }]
  │
  ▼ ② Voronoi 预计算（src/lib/spatial/voronoi.ts）
  │   输入: state.spatialRegions ← massif 的 graphicDrawing 坐标
  │   输出: 4 个区域，每个区域包含 { regionId, bounds, massifIds, sensorIds }
  │
  ▼ ③ 工具结果结构化聚合（reasoning.ts 改造）
  │   读取 state.toolResults[].list → 按 massifName 分组
  │   → 计算 per-region 统计: { 虫害趋势, 土墒均值, 气象变化 }
  │   → 注入 prompt: "区域 A（低洼区，3 地块，虫害↑+15%，土墒偏高）"
  │
  ▼ ④ LLM 推理（prompt 含空间上下文）
  │   "你是农场空间推理助手。当前农场划分为 4 个区域：
  │    区域 A [低洼区]: 地块 1,2,3 | 虫害↑ | 土墒偏高 | 本周多雨
  │    区域 B [高地区]: 地块 4,5   | 正常 | 土墒偏低 | 同区域 A
  │    请分析各区域风险并给出建议。"
  │
  ▼ ⑤ responseNode: 按区域分组展示结果
```

### 3.2 Voronoi 空间计算层

```
输入: massif 列表的 graphicDrawing 坐标（多边形顶点）
      + 传感器坐标（从 equipment API 获取）

算法: Fortune's Algorithm (O(n log n))
      → 每个传感器生成一个 Voronoi cell（凸多边形）
      → 叠加农场边界裁剪（boundary clipping）
      → 输出: spatialRegions: [{ regionId, bounds, massifIds, sensorIds, riskLevel }]

传感器选择逻辑:
  - 同一种设备存在多个 → 取覆盖 massif 最多的 Voronoi cell 对应的传感器
  - 重点区域 → 标记为高采样频率（adaptive sampling）
```

### 3.3 工具结果聚合逻辑

```
state.toolResults[].list → 按 massifName 分组
  → 每个地块: { massifName, recordCount, trend: "↑/→/↓" }
  → 按 spatialRegion 归并: { regionId, plots: [...], summary: "虫害↑+15%" }
  → 注入 LLM prompt（区域级摘要，不超过 2000 tokens）
```

### 3.4 Prompt 工程

**空间推理 section**（新增到 reasoning prompt）：

```
[空间推理上下文]
当前农场划分为 {N} 个区域（基于传感器 Voronoi 覆盖范围）：
- 区域 A [低洼区]: 覆盖地块 [1,2,3]，传感器 S1(虫情)+S2(气象) 覆盖
  虫情: ↑ 上升趋势（最近 7 天 +15%），发现 2 类害虫
  土墒: 偏高（平均 78%），本周降雨量 45mm
  气象: 温度 22-28°C，湿度 75-85%
- 区域 B [高地区]: 覆盖地块 [4,5]，传感器 S3(虫情)+S2(气象) 覆盖
  虫情: → 平稳
  土墒: 偏低（平均 42%）
  气象: 同区域 A

[推理要求]
1. 分析各区域的风险等级
2. 跨区域比较：低洼区 vs 高地区的虫害差异原因
3. 给出 per-region 的农事建议
4. 标记需要加强采样的重点区域
```

### 3.5 上下游依赖

```
上游（已完成）:
  project-massif-resolution → prebuiltMassifIds（全农场默认值）
  professional-fanout → per-expert 并行推理
  thinking-level-runtime-fix → professional 图路由

本 Plan:
  Voronoi 空间计算 + 工具结果聚合 + Prompt 工程 + CognitiveEventBus

下游（后续）:
  PolicyUpdateLoop 自适应策略调整
  GUI 端区域可视化（地图 + 热力图）
```

### 3.6 模型响应过程的数据装订

```
responseNode 消费 state.toolResults + state.spatialRegions
  → 按区域分组展示:
    [区域 A - 低洼区]
      - 虫情监测: 200 条记录，3 个地块，趋势↑
      - 土墒监测: 150 条记录，平均湿度 78%
      - 气象数据: 7 天，降雨量 45mm
      - 风险评估: 虫害高风险 + 渍涝风险
      - 建议: 排涝 + 防虫
    [区域 B - 高地区]
      ...
  → 不再显示"返回 200 条记录"，而是"区域 A 虫害↑，区域 B 正常"
```

---

## 四、实施 Task + 依赖图

```
第1轮: Voronoi 空间计算 (spatial/voronoi.ts 新建)
    │
    ▼
第2轮: 工具结果聚合 (farm-data-tools 改造 + reasoning 注入改造)
    │
    ▼
第3轮: Prompt 工程 (prompt 模板 + factory 改造)
    │
    ▼
第4轮: CognitiveEventBus + 验证
```

### 第1轮：Voronoi 空间计算层

- [ ] `src/lib/spatial/voronoi.ts`（新建）：
  - 实现 Fortune's Algorithm 或使用 `d3-delaunay` / `@turf/voronoi` npm 包
  - 输入: massif 的 graphicDrawing 坐标数组 + 传感器坐标数组
  - 输出: `VoronoiRegion[]`（regionId, polygon, massifIds, sensorId）
  - 边界裁剪: 叠加农场外轮廓多边形，裁剪超出的 Voronoi cell
  - 传感器选择: 同类型多传感器 → 取覆盖 massif 面积最大的 cell

- [ ] `src/agents/state.ts`：
  - 新增 `spatialRegions: Annotation<VoronoiRegion[] | null>()`

### 第2轮：工具结果结构化聚合

- [ ] `src/agents/tools/impl/farm-data-tools.ts`：
  - 每个工具返回新增 `summary` 字段：按 massifName 分组统计
  - 示例: `summary: { byPlot: { "一号地块": { recordCount: 25, trend: "up" } }, byRegion: [...] }`

- [ ] `src/agents/nodes/reasoning.ts`（L108-118 改造）：
  - 删除 `contentStr.slice(0, 200)` 截断
  - 改用 `state.toolResults[].list` → 按 `spatialRegions` 分组 → 注入 prompt
  - 保留回退路径：spatialRegions 为空时回退现有逻辑

- [ ] `src/agents/nodes/per-expert-reasoning.ts`（同步改造）：
  - 同 reasoning.ts 的改造逻辑

- [ ] `src/agents/nodes/response.ts`：
  - `toolExecutionSummary` 不再只显示"返回 N 条记录"
  - 按区域分组展示统计摘要

### 第3轮：Prompt 工程

- [ ] `src/agents/prompts/reasoning.ts`：
  - 新增 `[空间推理上下文]` section
  - 从 `state.spatialRegions` + `state.toolResults` 构建区域描述

- [ ] `src/agents/prompts/experts/factory.ts`：
  - per-expert prompt 新增 `spatialContext` 参数
  - 注入当前 expert 对应的区域边界 + 传感器分布

### 第4轮：CognitiveEventBus + 验证

- [ ] `src/agents/cognitive-event-bus.ts`：
  - 新增 `professional:fanout_started` / `professional:fanin_complete` 事件类型
  - `routeByExpertPlan` 调用时 emit fanout_started
  - `kbConflictAggregator` 入口时 emit fanin_complete

- [ ] `npx tsc --noEmit` 零错误
- [ ] `npx eslint src/` 零 error

---

## 五、验收标准

- [ ] Voronoi 计算：9 个地块 + 3 个传感器 → 3 个区域，每个区域正确覆盖对应地块
- [ ] 工具结果聚合：200 条虫情记录 → 按地块分组统计 → 4 个区域摘要
- [ ] reasoning.ts 不再截断：`contentStr.slice(0, 200)` 已删除
- [ ] LLM prompt 含空间推理上下文：区域划分 + 传感器覆盖 + 四情联动
- [ ] CognitiveEventBus：fanout_started + fanin_complete 事件可被 GlobalState 订阅
- [ ] 回退路径：spatialRegions 为空时，行为与当前一致
- [ ] `npx tsc --noEmit` 零错误
- [ ] `npx eslint src/` 零 error

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| 前置 Plan（project-massif-resolution） | `.qoder/plans/2026-07/06/farm-agent-project-massif-resolution-plan-v1.md` |
| 前置 Plan（professional-fanout） | `.qoder/plans/2026-07/06/farm-agent-professional-fanout-plan-v1.md` |
| 前置 Plan（thinking-level-runtime-fix） | `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md` |
| Farm-Server API 文档 | `docs/大田精准耕播智能决策系统/knowledge/02-规范/Farm-Server API接口文档（自动生成）.md` |
| 决策管线架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` |
| Handoff | `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-spatial-reasoning-review-v1.md` |
