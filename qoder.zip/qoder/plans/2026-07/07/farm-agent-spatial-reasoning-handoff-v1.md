# farm-agent-spatial-reasoning — 14 轮原子事务交接手册

> 多轮原子事务变更，每轮独立收敛。当前第 1-7 轮 + OOP 重构已完成，第 8-11 轮待执行。
> 
> **v2 更新 (2026-07-22)**: 补充轮次 2.5、4.5-4.8、Context Engine OOP 重构章节。

---

## 全局元信息

- **父 Plan**: [farm-agent-spatial-reasoning-plan-v3.md](./farm-agent-spatial-reasoning-plan-v3.md)
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 约 35 个文件
- **Round数**: 11 轮（含 2.5、4.5-4.8 子轮）

```text
第1轮 ── 空间计算层 (types + voronoi + fcm + coordinate + state)
            │
            ▼
第2轮 ── spatialPreprocessing 节点
            │
            ▼
第2.5轮 ── toolResults 保鲜基础设施 (jieqi + freshness + hydration)
            │
            ▼
第3轮 ── summaryRetrieval + summaryReasoning
            │
            ▼
第4轮 ── 现有推理改造 + Graph 接入
            │
            ▼
第4.5-4.8轮 ── tool-result-aggregator + 三节点接入 (Observation Compression)
            │
            ▼
第5轮 ── 觉知注入层 (prompts/awareness.ts)
            │
            ▼
第6轮 ── GlobalState 第八域 spatial
            │
            ▼
第7轮 ── 觉知裁决 (resolveAwareness)
            │
            ▼
★ OOP 重构 ── BaseReasoningNode + 子类 + agent-graph 瘦身 + 空间验证工具
            │
            ▼
第8轮 ── 报告模板数据结构化 (reports→report-templates + dataSchema)
            │
            ▼
第9轮 ── 多 GUI 渲染解耦 + 后处理校验
            │
            ▼
第10轮 ── Prompt + Response + EventBus + 专家注册
            │
            ▼
第11轮 ── 编译 + Lint + 验证 + 架构文档
```

---

## 原子事务边界说明

- 每轮文件集合形成独立边界，不会被其他轮回头修改
- 每轮完成后可通过 `tsc --noEmit` 独立验证
- 第 1-4 轮是 v2 原始 scope，第 2.5/4.5-4.8 是 v2 新增子轮，第 5-7 轮是 Review §10 回流新增
- OOP 重构是 v2 架构升级（BaseReasoningNode + Context Engine 能力对齐）
- 第 8-9 轮是模板数据结构化+渲染解耦，第 10-11 轮是装订与验证
- 第 11 轮不是前 10 轮的补丁，而是前 10 轮收敛后的验证合流

---

## 第1轮 空间计算层

### 你当前的位置

你是第 1 轮。上游无依赖。

### 上游已完成

无。

### 恢复上下文审计查询

> 共 5+ 条审计记录可恢复本轮完整开发上下文。

```text
query_audit_logs({ targetId: "src/lib/spatial/types.ts" })
query_audit_logs({ targetId: "src/lib/spatial/voronoi.ts" })
query_audit_logs({ targetId: "src/lib/spatial/fcm.ts" })
query_audit_logs({ targetId: "src/lib/spatial/coordinate-transform.ts" })
query_audit_logs({ targetId: "src/agents/state.ts" })
```

### 原子事务目标

新建 spatial lib 四个文件 + 修改 state.ts 空间字段。

### 你要改的文件（5 个：4 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/lib/spatial/types.ts` | 新建 | VoronoiRegion / SensorInfo / ManagementZone / SpatialContext 五个接口 |
| `src/lib/spatial/voronoi.ts` | 新建 | Voronoi 图计算 (Fortune's Algorithm via d3-delaunay) |
| `src/lib/spatial/fcm.ts` | 新建 | FCM 聚类 (PCA + 模糊C均值) |
| `src/lib/spatial/coordinate-transform.ts` | 新建 | CGCS2000 ↔ WGS-84 坐标转换 |
| `src/agents/state.ts` | 修改 | 新增 spatialRegions / managementZones / spatialAwareness / jieqi / projectId Annotation |

### 高风险误区

- 禁止在 voronoi.ts / fcm.ts 中引入运行时依赖（除 d3-delaunay 外）
- 禁止移除降级回退路径（spatialRegions = null 时必须行为不变）

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `CREATE` | COMPONENT | `src/lib/spatial/types.ts` | 空间类型定义 | ✅ |
| `CREATE` | COMPONENT | `src/lib/spatial/voronoi.ts` | Voronoi 图计算 | ✅ |
| `CREATE` | COMPONENT | `src/lib/spatial/fcm.ts` | FCM 聚类 | ✅ |
| `CREATE` | COMPONENT | `src/lib/spatial/coordinate-transform.ts` | 坐标转换 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/state.ts` | 空间字段 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] 3 传感器 × 9 地块 → 3 Voronoi 区域
- [x] state.ts spatialRegions / managementZones default = null

---

## 第2轮 spatialPreprocessing 节点

### 你当前的位置

你是第 2 轮。上游第 1 轮已完成。

### 上游已完成

- `src/lib/spatial/voronoi.ts` — computeVoronoiRegions() 可调用
- `src/lib/spatial/fcm.ts` — computeManagementZones() 可调用
- `src/agents/state.ts` — spatialRegions / managementZones 字段

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/nodes/spatial-preprocessing.ts" })
```

### 原子事务目标

新建 spatialPreprocessing 节点，编排 Voronoi + FCM 计算。

### 你要改的文件（1 个：1 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/spatial-preprocessing.ts` | 新建 | 空间预处理节点：调 Farm-Server → Voronoi + FCM → 写入 AgentState |

> **v2 OOP 升级**: 此文件已重构为 `SpatialPreprocessingNode` 类，包含 checkCache/compute/syncToGlobalState 三段式。

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `MODIFY` | COMPONENT | `src/agents/nodes/spatial-preprocessing.ts` | OOP 重构 + GlobalState 缓存 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] 数据完整性三字段非空校验
- [x] SpatialPreprocessingNode.toNodeFunction() 工厂方法可用

---

## 第2.5轮 toolResults 保鲜基础设施（v2 新增）

### 你当前的位置

你是第 2.5 轮。上游第 1-2 轮已完成。

### 上游已完成

- `src/agents/nodes/spatial-preprocessing.ts` — 空间预处理节点
- `src/agents/state.ts` — jieqi 字段

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "prisma/main.prisma" })
query_audit_logs({ targetId: "scripts/seed-jieqi.ts" })
query_audit_logs({ targetId: "src/lib/jieqi.ts" })
query_audit_logs({ targetId: "src/caijuehub/strategies/toolResultFreshness.ts" })
query_audit_logs({ targetId: "src/agents/nodes/tool-results-hydration.ts" })
```

### 原子事务目标

JieqiTable Prisma model + 节气种子脚本 + getCurrentJieqi 运行时查询 + toolResultFreshness 保鲜策略 + toolResultsHydration 节点重构 + deep 图拓扑更新。

### 你要改的文件（6 个：3 新建 + 3 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `prisma/main.prisma` | 修改 | JieqiTable 表：(year, name, date, time, source, projectId) |
| `scripts/seed-jieqi.ts` | 新建 | 紫金山天文台节气数据种子脚本 |
| `src/lib/jieqi.ts` | 新建 | getCurrentJieqi() + isJieqiChanged() |
| `src/caijuehub/strategies/toolResultFreshness.ts` | 新建 | resolveToolResultFreshness() + RefreshPolicy |
| `src/agents/nodes/tool-results-hydration.ts` | 修改 | 接入 caijuehub 保鲜策略 |
| `src/agents/agent-graph.ts` | 修改 | toolNode → toolResultsHydration → spatialPreprocessing |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `CREATE` | SCHEMA | `prisma/main.prisma` | JieqiTable | ✅ |
| `CREATE` | COMPONENT | `scripts/seed-jieqi.ts` | 节气种子脚本 | ✅ |
| `CREATE` | COMPONENT | `src/lib/jieqi.ts` | 节气运行时查询 | ✅ |
| `CREATE` | COMPONENT | `src/caijuehub/strategies/toolResultFreshness.ts` | 保鲜策略 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/tool-results-hydration.ts` | 接入保鲜策略 | ✅ |
| `GRAPH_MODIFIED` | GRAPH | `src/agents/agent-graph.ts` | deep 图拓扑更新 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] JieqiTable migration 幂等
- [x] getCurrentJieqi() 优先 projectId 覆盖 → fallback 全国默认
- [x] toolResultsHydration 接入 caijuehub 策略层

---

## 第3轮 summaryRetrieval + summaryReasoning

### 你当前的位置

你是第 3 轮。上游第 1-2.5 轮已完成。

### 上游已完成

- `src/agents/nodes/spatial-preprocessing.ts` — 空间预处理节点
- `src/agents/experts/registry.ts` — AnalysisExpert 新增 summaryExpertIds 字段

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/nodes/summary-retrieval.ts" })
query_audit_logs({ targetId: "src/agents/nodes/summary-reasoning.ts" })
```

### 原子事务目标

新建 summaryRetrieval + summaryReasoning 节点。

### 你要改的文件（2 个：2 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/summary-retrieval.ts` | 新建 | 领域知识代理检索：跨 collection ChromaDB 联合检索 |
| `src/agents/nodes/summary-reasoning.ts` | 新建 | 汇总专家推理：三字段完整性验证 → 空间上下文 → LLM invoke |

> **v2 OOP 升级**: summary-reasoning.ts 已重构为 `SummaryReasoningNode extends BaseReasoningNode`，聚合模式为 `detailed`。

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `CREATE` | NODE | `src/agents/nodes/summary-retrieval.ts` | 领域知识代理检索 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/summary-reasoning.ts` | OOP 重构 + detailed 聚合 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] summaryRetrieval：两级优先级（summaryExpertIds → 降级所有非 isSummary 专家）
- [x] summaryReasoning：三字段完整性校验 + 降级路径
- [x] SummaryReasoningNode.toNodeFunction() 工厂方法可用

---

## 第4轮 现有推理改造 + Graph 接入

### 你当前的位置

你是第 4 轮。上游第 1-3 轮已完成。

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/nodes/reasoning.ts" })
query_audit_logs({ targetId: "src/agents/nodes/per-expert-reasoning.ts" })
query_audit_logs({ targetId: "src/agents/agent-graph.ts" })
query_audit_logs({ targetId: "src/agents/edges/conditional.ts" })
```

### 原子事务目标

删除 reasoning.ts 截断 + per-expert 数据源改造 + Prompt 类型扩展 + Graph 拓扑接入。

### 你要改的文件（5 个：5 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/reasoning.ts` | 修改 | 删除 contentStr.slice(0,200) 截断，改用 state.toolResults |
| `src/agents/nodes/per-expert-reasoning.ts` | 修改 | 消费 state.toolResults 结构化数据 |
| `src/agents/context-engine/types.ts` | 修改 | 新增 SpatialContext / RegionSummary 接口 |
| `src/agents/agent-graph.ts` | 修改 | deep 图新增 3 节点 + 条件边 |
| `src/agents/edges/conditional.ts` | 修改 | routeByIntent 新增 spatialPreprocessing 路由分支 |

> **v2 OOP 升级**: reasoning.ts → `ReasoningNode extends BaseReasoningNode`，per-expert-reasoning.ts → `PerExpertReasoningNode extends BaseReasoningNode`，agent-graph.ts 使用 `XxxNode.toNodeFunction()` 工厂方法。

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `MODIFY` | COMPONENT | `src/agents/nodes/reasoning.ts` | 去截断 + OOP 重构 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/per-expert-reasoning.ts` | 消数据 + OOP 重构 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/context-engine/types.ts` | SpatialContext 接口 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/agent-graph.ts` | 工厂方法替换（-36行） | ✅ |
| `MODIFY` | COMPONENT | `src/agents/edges/conditional.ts` | spatialPreprocessing 路由 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] grep 确认 reasoning.ts `slice(0,200)` 已删除
- [x] per-expert-reasoning.ts 使用 state.toolResults（非 messages）
- [x] professional 图拓扑未修改
- [x] ReasoningNode.toNodeFunction() / PerExpertReasoningNode.toNodeFunction() 可用

---

## 第4.5-4.8轮 tool-result-aggregator + 三节点接入（v2 新增，Observation Compression）

### 你当前的位置

你是第 4.5-4.8 轮。上游第 1-4 轮已完成。

### 上游已完成

- `src/agents/nodes/reasoning.ts` — reasoning 节点
- `src/agents/nodes/summary-reasoning.ts` — summary-reasoning 节点
- `src/agents/nodes/per-expert-reasoning.ts` — per-expert-reasoning 节点

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/context-engine/tool-result-aggregator/index.ts" })
query_audit_logs({ targetId: "src/agents/tools/impl/statistic-tools.ts" })
query_audit_logs({ targetId: "src/agents/tools/impl/statistic-tools-wrapper.ts" })
query_audit_logs({ targetId: "src/agents/tools/impl/spatial-tools.ts" })
query_audit_logs({ targetId: "src/agents/tools/impl/spatial-tools-wrapper.ts" })
query_audit_logs({ targetId: "src/agents/tools/index.ts" })
```

### 原子事务目标

新建 tool-result-aggregator 模块（Observation Compression 核心）+ 统计/空间验证工具 + 三个推理节点接入聚合。

### 你要改的文件（12 个：6 新建 + 6 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/context-engine/tool-result-aggregator/index.ts` | 新建 | 公共 API aggregateToolResults() + compact/standard/detailed 三级 |
| `src/agents/context-engine/tool-result-aggregator/types.ts` | 新建 | PlotStat / RegionSummary / DetailLevel / AggregationResult |
| `src/agents/context-engine/tool-result-aggregator/massif-grouper.ts` | 新建 | 按 massifId 分组 |
| `src/agents/context-engine/tool-result-aggregator/trend-calculator.ts` | 新建 | Mann-Kendall + Sen's Slope + 正态分布策略接口 |
| `src/agents/context-engine/tool-result-aggregator/stats-calculator.ts` | 新建 | 均值 + 标准差 |
| `src/agents/context-engine/tool-result-aggregator/summary-builder.ts` | 新建 | 结构化摘要 + 验证工具提示 |
| `src/agents/tools/impl/statistic-tools.ts` | 新建 | verify_mean/std/trend + detect_outliers |
| `src/agents/tools/impl/statistic-tools-wrapper.ts` | 新建 | LangChain tool 包装 |
| `src/agents/tools/impl/spatial-tools.ts` | 新建 | verify_plot_region/zone_membership/sensor_coverage/plot_distance |
| `src/agents/tools/impl/spatial-tools-wrapper.ts` | 新建 | LangChain tool 包装 |
| `src/agents/tools/index.ts` | 修改 | 注册 8 个验证工具 |
| `src/agents/context-engine/awareness.ts` | 修改 | 新增 buildSpatialVerificationHint + injectAwareness hasSpatialData 参数 |

### 关键设计

```text
aggregateToolResults(toolResults, spatialRegions?, detailLevel)
  ├─ compact  (~20 tokens):   地块数 + 记录总数
  ├─ standard (~100-200):     + 每地块统计量(均值+标准差) + 趋势箭头
  └─ detailed (~300-500):     + 区域归并 + 自然语言摘要
```

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `CREATE` | COMPONENT | `src/agents/context-engine/tool-result-aggregator/index.ts` | aggregator 核心模块 | ✅ |
| `CREATE` | COMPONENT | `src/agents/tools/impl/spatial-tools.ts` | 空间验证工具 | ✅ |
| `CREATE` | COMPONENT | `src/agents/tools/impl/spatial-tools-wrapper.ts` | 空间工具包装 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/tools/index.ts` | 注册 8 个验证工具 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/context-engine/awareness.ts` | 空间验证工具提示 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] aggregateToolResults 三级输出正确
- [x] Mann-Kendall + Sen's Slope 计算正确（O(n²) n<500 零压力）
- [x] 8 个验证工具已注册到 agentTools
- [x] summary-reasoning 使用 `detailed` 模式
- [x] reasoning 使用 `standard` 模式
- [x] per-expert-reasoning 使用 `standard` 模式（全量指标不截断）

---

## 第5轮 觉知注入层

### 你当前的位置

你是第 5 轮（Review §10 回流）。上游第 1-4.8 轮已完成。

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/context-engine/awareness.ts" })
```

### 原子事务目标

新建觉知注入层：T0-T3 自适应分级生成空间感知文本 + per-expert 差异化注入。

### 你要改的文件（2 个：1 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/context-engine/awareness.ts` | 新建 | buildSpatialDigest() T0-T3 + injectAwareness() + buildSpatialVerificationHint() |
| `src/agents/state.ts` | 修改 | 新增 spatialAwareness Annotation<string\|null> |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `MODIFY` | COMPONENT | `src/agents/context-engine/awareness.ts` | 空间验证工具提示 | ✅ |
| `STATE_MODIFIED` | STATE | `src/agents/state.ts` | spatialAwareness Annotation | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] T0-T3 分级判定逻辑正确
- [x] per-expert 过滤：pest_risk→insect, weather_impact→weather, 汇总专家→all
- [x] buildSpatialVerificationHint 返回空间验证工具列表

---

## 第6轮 GlobalState 第八域 spatial

### 你当前的位置

你是第 6 轮（Review §10 回流）。上游第 1-5 轮已完成。

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/agents/global-state.ts" })
```

### 原子事务目标

GlobalState 新增第八域 spatial：SpatialStateSnapshot 类型 + spatial 域 default + syncSpatial() 方法 + spatialPreprocessing 缓存读写。

### 你要改的文件（2 个：2 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/global-state.ts` | 修改 | +SpatialStateSnapshot + spatial 域 + syncSpatial() + jieqi 字段 |
| `src/agents/nodes/spatial-preprocessing.ts` | 修改 | checkCache() → compute() → syncToGlobalState() 三段式 |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `MODIFY` | COMPONENT | `src/agents/global-state.ts` | SpatialStateSnapshot + spatial 域 + syncSpatial() | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/spatial-preprocessing.ts` | GlobalState 缓存读写三段式 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] SpatialStateSnapshot 字段完整：spatialRegions / managementZones / spatialAwareness / computedAt / sensorIds / jieqi
- [x] syncSpatial() 方法签名正确
- [x] spatialPreprocessing 缓存命中 → 跳过 API 调用（TTL 1h）

---

## 第7轮 觉知裁决

### 你当前的位置

你是第 7 轮（Review §10 回流）。上游第 1-6 轮已完成。

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/caijuehub/strategies/awareness.ts" })
query_audit_logs({ targetId: "src/agents/nodes/base-reasoning-node.ts" })
```

### 原子事务目标

新建觉知裁决策略 + 三个推理节点接入 resolveAwareness() TTL 裁决链路。

### 你要改的文件（5 个：2 新建 + 3 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/caijuehub/strategies/awareness.ts` | 新建 | resolveAwareness() TTL 检查 + per-expert 过滤 + 级别判定 |
| `src/agents/nodes/base-reasoning-node.ts` | 新建 | injectSpatialAwareness() 调用 resolveAwareness() + updateDomain 写回 |
| `src/agents/nodes/reasoning.ts` | 修改 | `await this.injectSpatialAwareness()` |
| `src/agents/nodes/summary-reasoning.ts` | 修改 | `await this.injectSpatialAwareness()` |
| `src/agents/nodes/per-expert-reasoning.ts` | 修改 | `await this.injectSpatialAwareness(fanoutExpertId)` |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_CREATED` | COMPONENT | `src/caijuehub/strategies/awareness.ts` | resolveAwareness() | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/base-reasoning-node.ts` | injectSpatialAwareness → resolveAwareness | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] per-expert TTL 映射正确
- [x] AwarenessDecision 输出字段完整
- [x] injectSpatialAwareness 通过 resolveAwareness() TTL 裁决
- [x] 缓存未命中时 updateDomain("spatial", { spatialAwareness }) 写回

---

## ★ Context Engine OOP 重构（v2 架构升级，2026-07-22）

### 你当前的位置

这是 v2 架构升级，在轮次 1-7 全部完成后执行。

### 上游已完成

- 轮次 1-7 全部代码已就绪
- tool-result-aggregator 模块已就绪
- 验证工具体系已就绪

### 恢复上下文审计查询

> 共 12 条审计记录可恢复本轮完整开发上下文。

```text
query_audit_logs({ targetId: "src/agents/nodes/base-reasoning-node.ts" })
query_audit_logs({ targetId: "src/agents/nodes/reasoning.ts" })
query_audit_logs({ targetId: "src/agents/nodes/summary-reasoning.ts" })
query_audit_logs({ targetId: "src/agents/nodes/per-expert-reasoning.ts" })
query_audit_logs({ targetId: "src/agents/nodes/spatial-preprocessing.ts" })
query_audit_logs({ targetId: "src/agents/agent-graph.ts" })
```

### 原子事务目标

三个推理节点 + spatialPreprocessing 节点 OOP 重构为类继承 BaseReasoningNode + agent-graph.ts 工厂方法替换。

### 你要改的文件（6 个：1 新建 + 5 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/base-reasoning-node.ts` | 新建 | 抽象基类：6 项共享能力 |
| `src/agents/nodes/reasoning.ts` | 修改 | → ReasoningNode extends BaseReasoningNode |
| `src/agents/nodes/summary-reasoning.ts` | 修改 | → SummaryReasoningNode extends BaseReasoningNode |
| `src/agents/nodes/per-expert-reasoning.ts` | 修改 | → PerExpertReasoningNode extends BaseReasoningNode |
| `src/agents/nodes/spatial-preprocessing.ts` | 修改 | → SpatialPreprocessingNode 独立类 |
| `src/agents/agent-graph.ts` | 修改 | 4 个节点使用 XxxNode.toNodeFunction()（-36行） |

### 核心设计

```text
BaseReasoningNode (abstract)
│  1. checkRagEmpty()           — GlobalState ragEmpty 检测
│  2. aggregateTools()          — tool-result-aggregator 聚合
│  3. formatAggregatedSummary() — 聚合结果 → 文本摘要
│  4. buildStatisticToolHints() — 统计验证工具提示
│  5. buildSpatialToolHints()   — 空间验证工具提示
│  6. injectSpatialAwareness()  — 空间感知注入（resolveAwareness TTL 裁决）
│
├── ReasoningNode (deep 普通专家)
│     额外: KB 冲突检测 + evidenceChain 回写
│
├── SummaryReasoningNode (deep 汇总专家)
│     额外: buildSpatialContextSection + detailed 聚合
│
└── PerExpertReasoningNode (pro 单专家)
      额外: fanoutExpertId + 按 realtimeToolNames 过滤

SpatialPreprocessingNode (独立类，非推理节点)
  checkCache() → compute() → syncToGlobalState()
```

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `CREATE` | COMPONENT | `src/agents/nodes/base-reasoning-node.ts` | OOP 抽象基类 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/reasoning.ts` | OOP 重构 + 6 项能力对齐 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/summary-reasoning.ts` | OOP 重构 + detailed 聚合 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/per-expert-reasoning.ts` | OOP 重构 + standard 全量 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/nodes/spatial-preprocessing.ts` | OOP 重构 + 缓存三段式 | ✅ |
| `MODIFY` | COMPONENT | `src/agents/agent-graph.ts` | 工厂方法替换（-36行） | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] 4 个 export class 可从外部 import
- [x] agent-graph.ts 使用 toNodeFunction() 工厂方法
- [x] 三个推理节点共享 BaseReasoningNode 6 项能力
- [x] reasoning.ts KB 冲突检测能力未丢失
- [x] reasoning.ts evidenceChain 回写能力未丢失
- [x] summary-reasoning.ts buildSpatialContextSection 能力未丢失
- [x] per-expert-reasoning.ts fanoutExpertId 过滤能力未丢失
- [x] spatial-preprocessing.ts 缓存读写能力未丢失
- [x] injectSpatialAwareness 通过 resolveAwareness() 做 TTL 裁决

---

## 第8轮 报告模板数据结构化

### 你当前的位置

你是第 8 轮。上游第 1-7 轮 + OOP 重构已完成。

### 上游已完成

- `src/caijuehub/strategies/awareness.ts` — 觉知裁决
- `src/agents/nodes/base-reasoning-node.ts` — OOP 基类

### 原子事务目标

重构报告模板目录结构，泛型化 ReportSectionDef，新增 dataSchema 字段定义。

### 你要改的文件

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/reports/` → `src/agents/report-templates/` | 重命名+拆分 | agrisynapse/h5 子目录 |
| `src/agents/experts/registry.ts` | 修改 | ReportSectionDef 泛型化 + dataSchema 新增 |
| `src/agents/report-templates/agrisynapse/*.ts` (13个) | 修改 | 各自补齐 dataSchema |
| `src/agents/report-templates/h5/*.ts` (新建) | 新建 | 镜像已有 H5 route Zod DTO 结构 |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| — | — | `src/agents/report-templates/` | 目录重构 | ⬜ |
| — | — | `src/agents/experts/registry.ts` | ReportSectionDef 泛型 | ⬜ |
| — | — | `agrisynapse/*.template.ts` x13 | 补齐 dataSchema | ⬜ |
| — | — | `h5/*.template.ts` | H5 模板契约文档 | ⬜ |

---

## 第9轮 多 GUI 渲染解耦 + 后处理校验

### 你当前的位置

你是第 9 轮。上游第 1-8 轮已完成。

### 原子事务目标

后处理校验层实现 + sectionType 开放映射 + authoritative 权威数据覆盖。

### 你要改的文件

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/response.ts` | 修改 | 后处理校验层：遍历 dataSchema.fields |
| `src/agents/report-templates/agrisynapse/*.ts` | 修改 | 核验 columnConfig 与 el-table 属性对齐 |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| — | — | `src/agents/nodes/response.ts` | 后处理校验层 | ⬜ |
| — | — | `agrisynapse/*.template.ts` | columnConfig 对齐 | ⬜ |

---

## 第10轮 Prompt + Response + EventBus + 专家注册

### 你当前的位置

你是第 10 轮。上游第 1-9 轮已完成。

### 原子事务目标

Prompt 装订 + Response 装订 + EventBus + 专家注册。

### 你要改的文件（7 个：7 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/prompts/experts/factory.ts` | 修改 | ExpertPromptInput 注入 spatialContext |
| `src/agents/nodes/response.ts` | 修改 | +buildRegionSummary + isSummary 分支 |
| `src/agents/cognitive-event-bus.ts` | 修改 | +fanout_started / fanin_complete |
| `src/lib/langgraph/send-api.ts` | 修改 | emit fanout_started |
| `src/agents/nodes/kb-conflict-aggregator.ts` | 修改 | emit fanin_complete |
| `src/agents/experts/registry.ts` | 修改 | +summaryExpertIds |
| `src/config/chroma-config.ts` | 修改 | +SUMMARY_RETRIEVAL_CONFIG |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| — | — | `src/agents/prompts/experts/factory.ts` | spatialContext 注入 | ⬜ |
| — | — | `src/agents/nodes/response.ts` | buildRegionSummary + isSummary | ⬜ |
| — | — | `src/agents/cognitive-event-bus.ts` | fanout/fanin 事件 | ⬜ |
| — | — | `src/lib/langgraph/send-api.ts` | emit fanout_started | ⬜ |
| — | — | `src/agents/nodes/kb-conflict-aggregator.ts` | emit fanin_complete | ⬜ |
| — | — | `src/agents/experts/registry.ts` | +summaryExpertIds | ⬜ |
| — | — | `src/config/chroma-config.ts` | +SUMMARY_RETRIEVAL_CONFIG | ⬜ |

---

## 第11轮 编译 + Lint + 验证 + 架构文档

### 你当前的位置

你是最后一轮。上游第 1-10 轮已完成。

### 原子事务目标

全量编译验证 + ESLint + 端到端验证 + 架构文档更新。

### 验证标准

- [ ] `npx tsc --noEmit` 零错误
- [ ] `npx eslint src/` 零 error
- [ ] 9 地块 + 3 传感器 → 3 Voronoi 区域 + 3 FCM 分区
- [ ] 觉知注入：每轮 prompt 含空间 digest
- [ ] GlobalState 缓存：TTL 未过期 → 跳过 API 调用
- [ ] resolveAwareness() TTL 裁决生效
- [ ] BaseReasoningNode 6 项能力在三个子类中均工作
- [ ] 回退路径：spatialRegions 为空时行为一致
- [ ] 架构文档已更新

---

## 每轮收敛判定补充规则

- checklist 全部项已勾选，不得有空勾选或推测通过
- 每完成一个文件修改：record_dev_operation 写入 ADD-7 审计
- 写入审计后：query_audit_logs 回查确认落库

---

## 附录：每轮启动模板

```text
## 上下文
你在执行 farm-agent-spatial-reasoning 改进的 [第N轮]。
上游已完成。先读 .qoder/plans/2026-07/07/farm-agent-spatial-reasoning-handoff-v1.md 的 <第N轮> 章节。

## 启动操作
1. session-init SKILL
2. add-paradigm SKILL
3. 读 .qoder/specs/farm-agent-spatial-reasoning/spec.md / tasks.md / checklist.md
4. 按 tasks.md 顺序执行
5. 每完成一个文件：record_dev_operation → query_audit_logs 回查
```

### 脱敏要求

禁止出现以下硬编码值：数据库密码、Chroma auth token、JWT 密钥、API Key、Farm-Server 凭证。所有凭据值通过 `${ENV_VAR}` 引用。
# farm-agent-spatial-reasoning — 11 轮原子事务交接手册

> 多轮原子事务变更，每轮独立收敛。当前第 1-8 轮代码已完成，第 9-11 轮待执行。

---

## 全局元信息

- **父 Plan**: [farm-agent-spatial-reasoning-plan-v3.md](./farm-agent-spatial-reasoning-plan-v3.md)
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 约 24 个文件
- **Round数**: 11 轮

```text
第1轮 ── 空间计算层 (types + voronoi + fcm + coordinate + state)
            │
            ▼
第2轮 ── spatialPreprocessing 节点
            │
            ▼
第3轮 ── summaryRetrieval + summaryReasoning
            │
            ▼
第4轮 ── 现有推理改造 + Graph 接入
            │
            ▼
第5轮 ── 觉知注入层 (prompts/awareness.ts)
            │
            ▼
第6轮 ── GlobalState 第八域 spatial
            │
            ▼
第7轮 ── 觉知裁决 (resolveAwareness)
            │
            ▼
第8轮 ── 报告模板数据结构化 (reports→report-templates + dataSchema)
            │
            ▼
第9轮 ── 多 GUI 渲染解耦 + 后处理校验
            │
            ▼
第10轮 ── Prompt + Response + EventBus + 专家注册
            │
            ▼
第11轮 ── 编译 + Lint + 验证 + 架构文档
```

---

## 原子事务边界说明

- 每轮文件集合形成独立边界，不会被其他轮回头修改
- 每轮完成后可通过 `tsc --noEmit` 独立验证
- 第 1-4 轮是 v2 原始 scope，第 5-7 轮是 Review §10 回流新增，第 8-9 轮是模板数据结构化+渲染解耦，第 10-11 轮是装订与验证
- 第 11 轮不是前 10 轮的补丁，而是前 10 轮收敛后的验证合流

---

## 第1轮 空间计算层

### 你当前的位置

你是第 1 轮。上游无依赖。

### 上游已完成

无。

### 恢复上下文审计查询（新 AI Session 首次启动必读）

> 共 5 条审计记录可恢复本轮完整开发上下文。

#### 第一步：搜索代码文件的改动记录

```text
query_audit_logs({ targetId: "src/lib/spatial/types.ts" })
```
→ 返回 1 条：LIB_CREATED。空间类型定义，五个接口已就绪。

```text
query_audit_logs({ targetId: "src/lib/spatial/voronoi.ts" })
```
→ 返回 1 条：LIB_CREATED。Voronoi 图计算 (d3-delaunay)。

```text
query_audit_logs({ targetId: "src/lib/spatial/fcm.ts" })
```
→ 返回 1 条：LIB_CREATED。FCM 聚类 (PCA + 模糊C均值)。

```text
query_audit_logs({ targetId: "src/lib/spatial/coordinate-transform.ts" })
```
→ 返回 1 条：LIB_CREATED。CGCS2000 ↔ WGS-84 坐标转换。

```text
query_audit_logs({ targetId: "src/agents/state.ts" })
```
→ 返回 1 条：STATE_MODIFIED。spatialRegions + managementZones 字段。

#### 第二步：搜索文档变更记录

```text
query_audit_logs({ keyword: "spatial-reasoning" })
```
→ 返回第一轮记录。

#### 第三步：按行动词搜索

```text
query_audit_logs({ keyword: "LIB_CREATED" })
```
→ 返回 4 条：spatial lib 四个文件的创建记录。

#### 恢复顺序建议

```
1. session-init SKILL（强制前置）
2. query_audit_logs({ keyword: "spatial-reasoning" })  → 看全部 10 条
3. read ".qoder/specs/farm-agent-spatial-reasoning/spec.md"
4. read ".qoder/specs/farm-agent-spatial-reasoning/tasks.md"
5. read ".qoder/specs/farm-agent-spatial-reasoning/checklist.md"
```

### 原子事务目标

新建 spatial lib 四个文件 + 修改 state.ts 空间字段。

### 你要改的文件（5 个：4 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/lib/spatial/types.ts` | 新建 | VoronoiRegion / SensorInfo / ManagementZone / SpatialContext 五个接口 |
| `src/lib/spatial/voronoi.ts` | 新建 | Voronoi 图计算 (Fortune's Algorithm via d3-delaunay) |
| `src/lib/spatial/fcm.ts` | 新建 | FCM 聚类 (PCA + 模糊C均值) |
| `src/lib/spatial/coordinate-transform.ts` | 新建 | CGCS2000 ↔ WGS-84 坐标转换 |
| `src/agents/state.ts` | 修改 | 新增 spatialRegions / managementZones Annotation |

### 高风险误区

- 禁止在 voronoi.ts / fcm.ts 中引入运行时依赖（除 d3-delaunay 外）
- 禁止移除降级回退路径（spatialRegions = null 时必须行为不变）

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `LIB_CREATED` | LIB | `src/lib/spatial/types.ts` | 空间类型定义 | ✅ |
| `LIB_CREATED` | LIB | `src/lib/spatial/voronoi.ts` | Voronoi 图计算 | ✅ |
| `LIB_CREATED` | LIB | `src/lib/spatial/fcm.ts` | FCM 聚类 | ✅ |
| `LIB_CREATED` | LIB | `src/lib/spatial/coordinate-transform.ts` | 坐标转换 | ✅ |
| `STATE_MODIFIED` | STATE | `src/agents/state.ts` | spatialRegions + managementZones | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] 3 传感器 × 9 地块 → 3 Voronoi 区域
- [x] state.ts spatialRegions / managementZones default = null

---

## 第2轮 spatialPreprocessing 节点

### 你当前的位置

你是第 2 轮。上游第 1 轮已完成。

### 上游已完成

- `src/lib/spatial/voronoi.ts` — computeVoronoiRegions() 可调用
- `src/lib/spatial/fcm.ts` — computeManagementZones() 可调用
- `src/agents/state.ts` — spatialRegions / managementZones 字段

### 恢复上下文审计查询（新 AI Session 首次启动必读）

> 共 1 条审计记录可恢复本轮完整开发上下文。

#### 第一步：搜索代码文件的改动记录

```text
query_audit_logs({ targetId: "src/agents/nodes/spatial-preprocessing.ts" })
```
→ 返回 1 条：NODE_CREATED。空间预处理节点，编排 Voronoi + FCM 计算。

#### 第二步：搜索文档变更记录

```text
query_audit_logs({ keyword: "spatial-reasoning" })
```
→ 返回 2 轮各文件的修改记录。

#### 第三步：按行动词搜索

```text
query_audit_logs({ keyword: "NODE_CREATED" })
```
→ 返回 3 条：spatial-preprocessing + summary-retrieval + summary-reasoning 的创建记录。

### 原子事务目标

新建 spatialPreprocessing 节点，编排 Voronoi + FCM 计算。

### 你要改的文件（1 个：1 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/spatial-preprocessing.ts` | 新建 | 空间预处理节点：调 Farm-Server → Voronoi + FCM → 写入 AgentState |

### 高风险误区

- 禁止在 spatialPreprocessing 节点中调用 LLM（纯代码逻辑）
- 三字段完整性校验必须在进入下一节点前完成

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `NODE_CREATED` | NODE | `src/agents/nodes/spatial-preprocessing.ts` | 空间预处理节点 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] 数据完整性三字段非空校验

---

## 第3轮 summaryRetrieval + summaryReasoning

### 你当前的位置

你是第 3 轮。上游第 1-2 轮已完成。

### 上游已完成

- `src/agents/nodes/spatial-preprocessing.ts` — spatialPreprocessing 节点，产出 spatialRegions + managementZones
- `src/lib/spatial/voronoi.ts` — Voronoi 图计算
- `src/lib/spatial/fcm.ts` — FCM 管理分区聚类
- `src/agents/experts/registry.ts` — AnalysisExpert 新增 summaryExpertIds 字段

### 原子事务目标

新建 summaryRetrieval 节点（跨 collection ChromaDB 联合检索）+ summaryReasoning 节点（三字段完整性验证 + 空间上下文 LLM 推理）。

### 你要改的文件（2 个：2 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/summary-retrieval.ts` | 新建 | 领域知识代理检索：summaryExpertIds → grounding.collectionName → 跨 collection ChromaDB 联合检索，每 collection 5 条，总上限 10 条 |
| `src/agents/nodes/summary-reasoning.ts` | 新建 | 汇总专家推理：三字段完整性验证 → buildSpatialContextSection() → 单 LLM invoke → verdictResult |

### 高风险误区

- 禁止硬编码 cateId——使用 registry 的 grounding.collectionName
- summaryReasoning 三字段完整性验证：任一缺失 → 降级无空间模式

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `NODE_CREATED` | NODE | `src/agents/nodes/summary-retrieval.ts` | 领域知识代理检索 | ✅ |
| `NODE_CREATED` | NODE | `src/agents/nodes/summary-reasoning.ts` | 汇总专家推理 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] summaryRetrieval：两级优先级（summaryExpertIds → 降级所有非 isSummary 专家）
- [x] summaryReasoning：三字段完整性校验 + 降级路径

---

## 第4轮 现有推理改造 + Graph 接入

### 你当前的位置

你是第 4 轮。上游第 1-3 轮已完成。

### 上游已完成

- `src/agents/nodes/summary-retrieval.ts` — 领域知识代理检索
- `src/agents/nodes/summary-reasoning.ts` — 汇总专家推理

### 恢复上下文审计查询（新 AI Session 首次启动必读）

> 共 5 条审计记录可恢复本轮完整开发上下文。

#### 第一步：搜索代码文件的改动记录

```text
query_audit_logs({ targetId: "src/agents/nodes/reasoning.ts" })
```
→ 返回 Task 4.1: 删除 contentStr.slice(0,200) 截断，改用 state.toolResults

```text
query_audit_logs({ targetId: "src/agents/nodes/per-expert-reasoning.ts" })
```
→ 返回 Task 4.2: 消费 state.toolResults 结构化数据

```text
query_audit_logs({ targetId: "src/agents/prompts/types.ts" })
```
→ 返回 Task 4.3: ExpertPromptInput 新增 spatialContext 字段

```text
query_audit_logs({ targetId: "src/agents/agent-graph.ts" })
```
→ 返回 Task 4.4: deep 图新增三节点 + 条件边

```text
query_audit_logs({ targetId: "src/agents/edges/conditional.ts" })
```
→ 返回 Task 4.4: routeByIntent 新增 spatialPreprocessing 路由分支

#### 第二步：搜索文档变更记录

```text
query_audit_logs({ keyword: "spatial-reasoning" })
```
→ 返回全部轮次记录。

#### 第三步：按行动词搜索

```text
query_audit_logs({ keyword: "COMPONENT_MODIFIED" })
```
→ 返回 4 轮各文件的修改记录。

#### 恢复顺序建议

```
1. session-init SKILL
2. query_audit_logs({ keyword: "spatial-reasoning" })
3. read spec.md / tasks.md / checklist.md
```

### 原子事务目标

删除 reasoning.ts 截断 + per-expert 数据源改造 + Prompt 类型扩展 + Graph 拓扑接入。

### 你要改的文件（5 个：5 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/reasoning.ts` | 修改 | 删除 contentStr.slice(0,200) 截断，改用 state.toolResults |
| `src/agents/nodes/per-expert-reasoning.ts` | 修改 | 消费 state.toolResults 结构化数据 |
| `src/agents/prompts/types.ts` | 修改 | 新增 SpatialContext / RegionSummary 接口 |
| `src/agents/agent-graph.ts` | 修改 | deep 图新增 3 节点 + 条件边 |
| `src/agents/edges/conditional.ts` | 修改 | routeByIntent 新增 spatialPreprocessing 路由分支 |

### 高风险误区

- 禁止修改 professional 图拓扑
- reasoning.ts 只删除截断，不新增 buildSpatialContext（由第 3 轮负责）

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_MODIFIED` | COMPONENT | `src/agents/nodes/reasoning.ts` | Task 4.1: 删除截断，改用 state.toolResults | ✅ |
| `COMPONENT_MODIFIED` | COMPONENT | `src/agents/nodes/per-expert-reasoning.ts` | Task 4.2: 消费 state.toolResults | ✅ |
| `COMPONENT_MODIFIED` | COMPONENT | `src/agents/prompts/types.ts` | Task 4.3: SpatialContext/RegionSummary 接口 | ✅ |
| `GRAPH_MODIFIED` | GRAPH | `src/agents/agent-graph.ts` | Task 4.4: 三节点注册+条件边 | ✅ |
| `COMPONENT_MODIFIED` | COMPONENT | `src/agents/edges/conditional.ts` | Task 4.4: spatialPreprocessing 路由分支 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] grep 确认 reasoning.ts L112 `slice(0,200)` 已删除
- [x] per-expert-reasoning.ts 使用 state.toolResults（非 messages）
- [x] professional 图拓扑未修改

---

## 第5轮 觉知注入层

### 你当前的位置

你是第 5 轮（Review §10 回流）。上游第 1-4 轮已完成。

### 上游已完成

- `src/agents/agent-graph.ts` — 空间节点已注册到 deep 图
- `src/agents/prompts/types.ts` — SpatialContext / RegionSummary 接口已就绪

### 恢复上下文审计查询（新 AI Session 首次启动必读）

> 共 2 条审计记录可恢复本轮完整开发上下文。

#### 第一步：搜索代码文件的改动记录

```text
query_audit_logs({ targetId: "src/agents/prompts/awareness.ts" })
```
→ 返回 Task 5.1: buildSpatialDigest() T0-T3 自适应分级 + injectAwareness()

```text
query_audit_logs({ targetId: "src/agents/state.ts" })
```
→ 返回 Task 1.5 (spatialRegions/managementZones) + Task 5.2 (spatialAwareness)

#### 第二步：搜索文档变更记录

```text
query_audit_logs({ keyword: "spatial-reasoning" })
```
→ 返回全部轮次记录。

#### 第三步：按行动词搜索

```text
query_audit_logs({ keyword: "COMPONENT_CREATED" })
```
→ 返回 awareness.ts 的创建记录。

### 原子事务目标

新建觉知注入层：T0-T3 自适应分级生成空间感知文本 + per-expert 差异化注入。

### 你要改的文件（2 个：1 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/prompts/awareness.ts` | 新建 | buildSpatialDigest() T0-T3 自适应分级 + injectAwareness() per-expert 差异化 |
| `src/agents/state.ts` | 修改 | 新增 spatialAwareness Annotation<string|null> |

### 高风险误区

- digest 必须结构化表格优先，非自由文本
- 注入位置必须是 system message 区域（持久 DNA），不混入对话历史

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_CREATED` | COMPONENT | `src/agents/prompts/awareness.ts` | Task 5.1: T0-T3 分级 + per-expert 注入 | ✅ |
| `STATE_MODIFIED` | STATE | `src/agents/state.ts` | Task 5.2: spatialAwareness Annotation | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] T0-T3 分级判定逻辑正确
- [x] per-expert 过滤：pest_risk→insect, weather_impact→weather, 汇总专家→all

---

## 第6轮 GlobalState 第八域 spatial

### 你当前的位置

你是第 6 轮（Review §10 回流）。上游第 1-5 轮已完成。

### 上游已完成

- `src/agents/prompts/awareness.ts` — 觉知注入层已就绪
- `src/agents/state.ts` — spatialAwareness 字段已就绪

### 恢复上下文审计查询（新 AI Session 首次启动必读）

> 共 1 条审计记录可恢复本轮完整开发上下文。

#### 第一步：搜索代码文件的改动记录

```text
query_audit_logs({ targetId: "src/agents/global-state.ts" })
```
→ 返回 Task 6.1: GlobalState 第八域 spatial — SpatialStateSnapshot + spatial 域 + syncSpatial()

#### 第二步：搜索文档变更记录

```text
query_audit_logs({ keyword: "spatial-reasoning" })
```
→ 返回全部轮次记录。

#### 第三步：按行动词搜索

```text
query_audit_logs({ keyword: "COMPONENT_MODIFIED" })
```
→ 返回 global-state.ts 的修改记录。

### 原子事务目标

GlobalState 新增第八域 spatial：SpatialStateSnapshot 类型 + spatial 域 default + syncSpatial() 方法。

### 你要改的文件（2 个：2 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/global-state.ts` | 修改 | +SpatialStateSnapshot 类型 + spatial 域 default + syncSpatial() 方法 |
| `src/agents/nodes/spatial-preprocessing.ts` | 修改 | 计算后调用 globalState.syncSpatial() |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_MODIFIED` | COMPONENT | `src/agents/global-state.ts` | Task 6.1: SpatialStateSnapshot + spatial 域 + syncSpatial() | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] SpatialStateSnapshot 字段完整：spatialRegions / managementZones / spatialAwareness / computedAt / sensorIds
- [x] syncSpatial() 方法签名正确

---

## 第7轮 觉知裁决

### 你当前的位置

你是第 7 轮（Review §10 回流）。上游第 1-6 轮已完成。

### 上游已完成

- `src/agents/global-state.ts` — SpatialStateSnapshot + syncSpatial() 已就绪
- `src/agents/prompts/awareness.ts` — buildSpatialDigest() 已就绪

### 恢复上下文审计查询（新 AI Session 首次启动必读）

> 共 1 条审计记录可恢复本轮完整开发上下文。

#### 第一步：搜索代码文件的改动记录

```text
query_audit_logs({ targetId: "src/caijuehub/strategies/awareness.ts" })
```
→ 返回 Task 7.1: resolveAwareness() per-expert TTL 检查 + 缓存命中/过期判定 + buildSpatialDigest 按需生成

#### 第二步：搜索文档变更记录

```text
query_audit_logs({ keyword: "spatial-reasoning" })
```
→ 返回全部轮次记录。

#### 第三步：按行动词搜索

```text
query_audit_logs({ keyword: "COMPONENT_CREATED" })
```
→ 返回 awareness.ts 的创建记录。

### 原子事务目标

新建觉知裁决策略：resolveAwareness() 实现 per-expert TTL 检查 + 缓存命中/过期判定 + buildSpatialDigest 按需生成。

### 你要改的文件（1 个：1 新建）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/caijuehub/strategies/awareness.ts` | 新建 | resolveAwareness() TTL 检查 + per-expert 过滤 + 级别判定 |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_CREATED` | COMPONENT | `src/caijuehub/strategies/awareness.ts` | Task 7.1: resolveAwareness() per-expert TTL + 缓存判定 | ✅ |

### 验证标准

- [x] `npx tsc --noEmit` 通过
- [x] per-expert TTL 映射正确：daily_report=1h, weekly_report=1d, pest_risk=1h, land_analysis=never
- [x] AwarenessDecision 输出字段完整：shouldInject / digest / cacheHit / ttlExpired

---

## 第8轮 报告模板数据结构化

### 你当前的位置

你是第 8 轮。上游第 1-7 轮已完成。

### 上游已完成

- `src/caijuehub/strategies/awareness.ts` — 觉知裁决

### 原子事务目标

重构报告模板目录结构，泛型化 ReportSectionDef，新增 dataSchema 字段定义。

### 你要改的文件

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/reports/` → `src/agents/report-templates/` | 重命名+拆分 | agrisynapse/h5 子目录 |
| `src/agents/experts/registry.ts` | 修改 | ReportSectionDef 泛型化 + dataSchema 新增 |
| `src/agents/report-templates/agrisynapse/*.ts` (13个) | 修改 | 各自补齐 dataSchema（contentType/fields/source/nested/columnConfig） |
| `src/agents/report-templates/h5/*.ts` (新建) | 新建 | 镜像已有 H5 route Zod DTO 结构 |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| — | — | `src/agents/report-templates/` | Task 8.1: 目录重构 | ⬜ |
| — | — | `src/agents/experts/registry.ts` | Task 8.2: ReportSectionDef 泛型 | ⬜ |
| — | — | `agrisynapse/*.template.ts` x13 | Task 8.3: 补齐 dataSchema | ⬜ |
| — | — | `h5/*.template.ts` | Task 8.4: H5 模板契约文档 | ⬜ |

---

## 第9轮 多 GUI 渲染解耦 + 后处理校验

### 你当前的位置

你是第 9 轮。上游第 1-8 轮已完成。

### 上游已完成

- `src/agents/report-templates/` — 模板目录重构+dataSchema 字段已补齐

### 原子事务目标

后处理校验层实现 + sectionType 开放映射 + authoritative 权威数据覆盖。

### 你要改的文件

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/response.ts` | 修改 | 后处理校验层：遍历 dataSchema.fields，source:"authoritative" 覆盖 LLM |
| `src/agents/report-templates/agrisynapse/*.ts` | 修改 | 核验 columnConfig 与 el-table 属性对齐 |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| — | — | `src/agents/nodes/response.ts` | Task 9.1: 后处理校验层 | ⬜ |
| — | — | `agrisynapse/*.template.ts` | Task 9.2: columnConfig 对齐 | ⬜ |

---

## 第10轮 Prompt + Response + EventBus + 专家注册

### 你当前的位置

你是第 10 轮。上游第 1-9 轮已完成。

### 上游已完成

- `src/agents/prompts/awareness.ts` — 觉知注入层
- `src/agents/global-state.ts` — GlobalState 第八域
- `src/caijuehub/strategies/awareness.ts` — 觉知裁决

### 恢复上下文审计查询（新 AI Session 首次启动必读）

> 共 1 条审计记录可恢复本轮部分开发上下文。

#### 第一步：搜索代码文件的改动记录

```text
query_audit_logs({ targetId: "src/agents/agent-graph.ts" })
```
→ 返回 Task 8.1（部分）: agent-graph.ts 注册空间节点 + 方案B投影（AgentState→GlobalState.spatial）

#### 第二步：搜索文档变更记录

```text
query_audit_logs({ keyword: "spatial-reasoning" })
```
→ 返回全部轮次记录。

#### 第三步：按行动词搜索

```text
query_audit_logs({ keyword: "GRAPH_MODIFIED" })
```
→ 返回 agent-graph.ts 的修改记录。

### 原子事务目标

Prompt 装订 + Response 装订 + EventBus + 专家注册。

### 你要改的文件（7 个：7 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/prompts/experts/factory.ts` | 修改 | ExpertPromptInput 注入 spatialContext |
| `src/agents/nodes/response.ts` | 修改 | +buildRegionSummary + isSummary 分支 |
| `src/agents/cognitive-event-bus.ts` | 修改 | +fanout_started / fanin_complete |
| `src/lib/langgraph/send-api.ts` | 修改 | emit fanout_started |
| `src/agents/nodes/kb-conflict-aggregator.ts` | 修改 | emit fanin_complete |
| `src/agents/experts/registry.ts` | 修改 | +summaryExpertIds |
| `src/config/chroma-config.ts` | 修改 | +SUMMARY_RETRIEVAL_CONFIG |

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `GRAPH_MODIFIED` | GRAPH | `src/agents/agent-graph.ts` | Task 8.1（部分）: 方案B投影 | ✅ |
| — | — | `src/agents/prompts/experts/factory.ts` | Task 8.2: spatialContext 注入 | ⬜ |
| — | — | `src/agents/nodes/response.ts` | Task 8.3: buildRegionSummary + isSummary | ⬜ |
| — | — | `src/agents/cognitive-event-bus.ts` | Task 8.4: fanout_started / fanin_complete | ⬜ |
| — | — | `src/lib/langgraph/send-api.ts` | Task 8.5: emit fanout_started | ⬜ |
| — | — | `src/agents/nodes/kb-conflict-aggregator.ts` | Task 8.6: emit fanin_complete | ⬜ |
| — | — | `src/agents/experts/registry.ts` | Task 8.7: +summaryExpertIds | ⬜ |
| — | — | `src/config/chroma-config.ts` | Task 8.8: +SUMMARY_RETRIEVAL_CONFIG | ⬜ |

### 验证标准

- [ ] `npx tsc --noEmit` 通过
- [ ] factory.ts 注入 spatialContext 后 prompt 含 [空间上下文] 区块
- [ ] response.ts isSummary 分支使用 reportTemplate 章节定义
- [ ] EventBus 可订阅 fanout_started / fanin_complete
- [ ] SUMMARY_RETRIEVAL_CONFIG 参数集中管理

---

## 第11轮 编译 + Lint + 验证 + 架构文档

### 你当前的位置

你是最后一轮。上游第 1-10 轮已完成。

### 原子事务目标

全量编译验证 + ESLint + 端到端验证 + 架构文档更新。

### 验证标准

- [ ] `npx tsc --noEmit` 零错误
- [ ] `npx eslint src/` 零 error
- [ ] 9 地块 + 3 传感器 → 3 Voronoi 区域 + 3 FCM 分区
- [ ] 觉知注入：每轮 prompt 含空间 digest
- [ ] GlobalState 缓存：TTL 未过期 → 跳过 API 调用
- [ ] 回退路径：spatialRegions 为空时行为一致
- [ ] 架构文档已更新

---

## 每轮收敛判定补充规则

- checklist 全部项已勾选，不得有空勾选或推测通过
- 每完成一个文件修改：record_dev_operation 写入 ADD-7 审计
- 写入审计后：query_audit_logs 回查确认落库

---

## 附录：每轮启动模板

```text
## 上下文
你在执行 farm-agent-spatial-reasoning 改进的 [第N轮]。
上游已完成。先读 .qoder/plans/2026-07/07/farm-agent-spatial-reasoning-handoff-v1.md 的 <第N轮> 章节。

## 启动操作
1. session-init SKILL
2. add-paradigm SKILL
3. 读 .qoder/specs/farm-agent-spatial-reasoning/spec.md / tasks.md / checklist.md
4. 按 tasks.md 顺序执行
5. 每完成一个文件：record_dev_operation → query_audit_logs 回查
```

### 脱敏要求

禁止出现以下硬编码值：数据库密码、Chroma auth token、JWT 密钥、API Key、Farm-Server 凭证。所有凭据值通过 `${ENV_VAR}` 引用。