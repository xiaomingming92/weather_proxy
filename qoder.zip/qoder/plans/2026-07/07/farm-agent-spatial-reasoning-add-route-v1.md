# farm-agent-spatial-reasoning-add-route-v1

> **定位**：Plan → ADD Step 执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——涉及 6 新建文件 + 13 修改文件，跨 deep/professional 两条图路径，含两个数学算法（Voronoi + FCM）实现，必须逐 Step 验证。
>
> **绑定**：Plan: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-plan-v2.md` · Spec: `.qoder/specs/farm-agent-spatial-reasoning/spec.md` · Tasks: `.qoder/specs/farm-agent-spatial-reasoning/tasks.md` · Handoff: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-handoff-v1.md`

---

## 算法与文献清单

> 本 Plan 涉及两个核心算法，均有充分的学术文献和实践支撑。实施前需确认算法理解和依赖就绪。

### A. Voronoi 空间划分（几何层，Task 1.2）

| 属性 | 值 |
|------|-----|
| **算法** | Voronoi Diagram（泰森多边形），基于 Fortune's Algorithm (sweepline) |
| **时间复杂度** | O(n log n)，n = 传感器数量（通常 3-10 个） |
| **npm 包** | `d3-delaunay` — `Delaunay.from(points).voronoi()` + `cellPolygon(i)` |
| **坐标系统** | Farm-Server 使用天地图 CGCS2000（≈ WGS-84，偏差 < 1m），农业场景下可直接当 WGS-84 使用 |

**算法步骤**：
1. 传感器坐标 → UTM 笛卡尔平面投影（或简单线性近似）
2. Fortune's Algorithm 计算 Voronoi 图 → 每个传感器的 Voronoi cell（凸多边形）
3. 可选：叠加农场外轮廓裁剪超出边界的 cell
4. 对每个地块，从 API 的 graphicDrawing 分号分隔字符串（"lng,lat;lng,lat;..."）解析坐标点，计算多边形重心点
5. 重心点落在哪个 Voronoi cell → 该地块归属该 cell 对应的传感器
6. 输出 `VoronoiRegion[]`

**关键文献**：

| # | 文献 | 链接 | 用途 |
|:--:|------|------|------|
| 1 | Thiessen 1911 — 气象学泰森多边形标准做法 | [SuperMap: 泰森多边形空间插值](https://help.supermap.com/iDesktopX/zh/tutorial/Analyst/Raster/ThiessenPolygon) | 空间插值理论基础 |
| 2 | 物理学报 2014 — BCBS 算法（盲区形心覆盖策略） | [https://wulixb.iphy.ac.cn/article/doi/10.7498/aps.63.220701](https://wulixb.iphy.ac.cn/article/doi/10.7498/aps.63.220701) | 传感器覆盖范围归因 |
| 3 | Nature Machine Intelligence 2021 — Voronoi 镶嵌辅助稀疏传感器全局场重建（Fukami et al.） | [https://doi.org/10.1038/s42256-021-00402-2](https://doi.org/10.1038/s42256-021-00402-2) | Voronoi 镶嵌将任意传感器位置映射为结构化网格 → CNN 超分辨率重建 → 全局空间场恢复；支持移动传感器和任意数量传感器，被引 45+ |
| 4 | Nature 2025 — 无线传感器网络自适应覆盖优化 | [https://www.nature.com/articles/s41598-025-16031-3](https://www.nature.com/articles/s41598-025-16031-3) | k-Order Voronoi + Power Diagram 加权距离 |
| 5 | IEEE JSTSP 2025 — AI for Smart Agriculture 特刊 | [https://signalprocessingsociety.org/blog/ieee-jstsp-special-series-artificial-intelligence-smart-agriculture](https://signalprocessingsociety.org/blog/ieee-jstsp-special-series-artificial-intelligence-smart-agriculture) | AI+农业综述 |
| 6 | Nature 2025 — UAV 覆盖路径规划中的 Voronoi 分割 | [https://www.nature.com/articles/s41598-025-20978-8](https://www.nature.com/articles/s41598-025-20978-8) | UAV 场景 Voronoi 应用 |

### B. FCM 管理分区聚类（分析分区层，Task 1.3）

| 属性 | 值 |
|------|-----|
| **算法** | Fuzzy C-Means（模糊C均值聚类）+ PCA 降维 |
| **输入** | `state.toolResults[].list` 多源数据矩阵（虫情/土墒/气象数值字段） |
| **输出** | `ManagementZone[]`，每个 zone 含 `{ zoneId, label, massifIds, massifNames, summary, dominantTrend }` |
| **依赖** | 纯函数，不依赖 LLM，不依赖外部 API |

**算法步骤**：
1. 从 `toolResults` 提取多源数据矩阵（以 massifName × 数值字段构成）
2. PCA 降维 → 提取 3 个主控因子（通常对应虫情/土墒/气象维度）
3. Fuzzy C-Means 聚类 → 模糊隶属度矩阵
4. 最优分区数判定（Xie-Beni 指数或轮廓系数）
5. 去模糊化 → 每个地块归属一个管理分区
6. 输出 `ManagementZone[]`

**关键文献**：

| # | 文献 | 链接 | 用途 |
|:--:|------|------|------|
| 1 | Nature 2025 — 基于 FCM 聚类的精准农业管理分区划定 | [https://www.nature.com/articles/s41598-025-07283-0](https://www.nature.com/articles/s41598-025-07283-0) | FCM 管理分区核心参考 |
| 2 | 农业工程学报 2025 — 基于 FCM 的玉米农田管理分区研究 | [http://vip.hnadl.cn/article/detail.aspx?id=7100650408](http://vip.hnadl.cn/article/detail.aspx?id=7100650408) | 玉米场景 FCM 实践 |
| 3 | Precision Agriculture 2022 — 管理分区聚类与平滑管线 | [https://m.zhangqiaokeyan.com/journal-foreign-detail/0704065207883.html](https://m.zhangqiaokeyan.com/journal-foreign-detail/0704065207883.html) | 管理分区管线化 |
| 4 | 生态学报 2020 — 基于 GIS 的盐渍化农田管理分区 | [https://www.ecologica.cn/html/2020/19/stxb201810092178.htm](https://www.ecologica.cn/html/2020/19/stxb201810092178.htm) | GIS + 管理分区 |
| 5 | AgriGPT (浙江大学 2025) — 农业领域 LLM 生态系统 | [https://arxiv.org/html/2508.08632v1](https://arxiv.org/html/2508.08632v1) | Tri-RAG 多通道检索增强 |
| 6 | Smart Sensors 2024 — 精准农业智能传感器综述 | [https://pmc.ncbi.nlm.nih.gov/articles/PMC11053448/](https://pmc.ncbi.nlm.nih.gov/articles/PMC11053448/) | 自适应采样频率理论基础 |
| 7 | 专利 CN202510338326 — 卫星物联网智慧农业信息管理方法 | [https://www.xjishu.com/zhuanli/55/202510338326.html](https://www.xjishu.com/zhuanli/55/202510338326.html) | 分区级环境变化预测模型 |

### C. 两层协作关系

```
几何层（Voronoi）                         分析分区层（FCM）
─────────────────                       ─────────────────
输入: 坐标 (lat, lng)                     输入: 数据 (虫情/土墒/气象数值)
算法: Fortune's Algorithm O(n log n)      算法: Fuzzy C-Means 聚类
输出: "传感器 S1 覆盖地块 1,2,3"           输出: "地块 1,3,5 ∈ 低湿区"
用途: 传感器数据归因                       用途: 差异化分析决策

协作: Voronoi 先确定"每个地块数据来自哪个传感器"
      → FCM 再按数值相似性划分管理分区
      → LLM 拿到分区级摘要做跨分区比较
```

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全，算法依赖就绪。

**输入**：
- Review: `.qoder/reviews/farm-agent-spatial-reasoning-review-v2.md`
- Plan: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-plan-v2.md`

**动作**：
1. 确认 Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
2. 调用 `find_related_docs` 检索受影响的架构/规范文档
3. 安装算法依赖：`pnpm add d3-delaunay`（Voronoi 图计算）
4. 确认 Farm-Server `GET /admin-api/farm/massif/options?projectId=X` 和 `GET /admin-api/farm/equipment/options?projectId=X` API 可用；注意 graphicDrawing 为分号分隔 "lng,lat" 格式，需反转坐标顺序；equipment type 仅保留 "1"气象站 / "2"土壤 / "4"虫情
5. 确认 CGCS2000 → WGS-84 坐标偏差 < 1m，农业场景可直接使用

**产出**：
- [ ] Specs 三元组路径确认
- [ ] 项目文档更新：在 `决策管线架构说明书` 中新增 deep 图汇总专家路径（三节点拓扑 + deep/professional 范式差异说明 + summaryRetrieval 存在原因）
- [ ] `d3-delaunay` 依赖已安装
- [ ] Farm-Server 坐标 API 可用性确认

### §0.8 DPS 闸门（上游文档质量校验）

调用 `check_dps({ planKeyword: "spatial-reasoning" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计打点定义

**目的**：定义本次变更涉及的所有审计打点，扩展 `AgentAuditPhase`。

**输入**：
- Plan §3 的图拓扑
- `src/lib/agent-audit-logger.ts` 当前 `AgentAuditPhase` 联合类型

**动作**：
1. 在 `AgentAuditPhase` 联合类型中新增空间相关字面量

**产出**：
- [ ] 审计打点清单已同步到 tasks.md

| 字面量 | 使用场景 | Task |
|-------|---------|------|
| `SPATIAL_PREPROCESS` | spatialPreprocessing 节点执行全过程（数据入口 → Voronoi → FCM → 写入 state） | 2.1 |
| `SPATIAL_AGGREGATE` | aggregateToolResults 聚合完成（regionCount, plotCount, totalRecords） | 2.1 |
| `SUMMARY_RETRIEVAL` | 汇总专家 RAG 检索完成（hitCount, sourceBreakdown） | 3.1 |
| `SUMMARY_REASONING` | 汇总专家推理完成（zoneCount, evidenceCount, confidence） | 3.2 |
| `PROFESSIONAL_FANOUT_STARTED` | routeByExpertPlan Send API fan-out 启动 | 5.3 |
| `PROFESSIONAL_FANIN_COMPLETE` | kbConflictAggregator 专家结果汇聚完成 | 5.3 |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用。

**输入**：
- `src/lib/agent-audit-logger.ts`
- Step 1 的 `AgentAuditPhase` 扩展

**动作**：
1. 确认 `agentAudit(phase, detail, extra?)` 接受 Step 1 新增字面量
2. 确认三通道输出正常（console + file + AuditLog 表）
3. 确认辅助函数可用（`agentAuditNodeStart/End/Error`、`agentAuditRetrieval` 等）

**产出**：
- [ ] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

### §3.0 前置守卫

调用 `check_add_route_status({ planKeyword: "spatial-reasoning" })` 确认 add-route 有效。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增字面量 | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1.1 | 空间类型定义 | `src/lib/spatial/types.ts`（新建） | 无（纯类型定义） | — | 无 | ⬜ |
| 1.2 | Voronoi 图计算 | `src/lib/spatial/voronoi.ts`（新建） | 无（纯函数库） | — | 1.1 | ⬜ |
| 1.3 | FCM 管理分区聚类 | `src/lib/spatial/fcm.ts`（新建） | 无（纯函数库） | — | 1.1 | ⬜ |
| 1.4 | state 新增空间字段 | `src/agents/state.ts` | 无（结构变更） | — | 1.1 | ⬜ |
| 1.5 | 坐标转换工具 | `src/lib/spatial/coordinate-transform.ts`（新建） | 无（纯函数） | — | 1.1 | ⬜ |
| 2.1 | 空间预处理节点 | `src/agents/nodes/spatial-preprocessing.ts`（新建） | `agentAuditNodeStart/End` + `agentAudit("SPATIAL_PREPROCESS", ...)` + `agentAudit("SPATIAL_AGGREGATE", ...)` | `SPATIAL_PREPROCESS`, `SPATIAL_AGGREGATE` | 1.2, 1.3, 1.4 | ⬜ |
| 3.1 | 领域知识代理检索 | `src/agents/nodes/summary-retrieval.ts`（新建） | `agentAudit("SUMMARY_RETRIEVAL", ...)` | `SUMMARY_RETRIEVAL` | 2.1 | ⬜ |
| 3.2 | 汇总专家推理 | `src/agents/nodes/summary-reasoning.ts`（新建） | `agentAuditNodeStart/End` + `agentAudit("SUMMARY_REASONING", ...)` | `SUMMARY_REASONING` | 2.1, 3.1 | ⬜ |
| 4.1 | deep 图 reasoning 去截断 | `src/agents/nodes/reasoning.ts` | `agentAuditNodeStart/End`（已有） | — | 2.1 | ⬜ |
| 4.2 | per-expert 数据升级 | `src/agents/nodes/per-expert-reasoning.ts` | `agentAuditNodeStart/End`（已有） | — | 2.1 | ⬜ |
| 4.3 | Prompt 类型扩展 | `src/agents/prompts/types.ts` | 无（类型定义） | — | 1.1 | ⬜ |
| 4.4 | deep 图拓扑更新 | `src/agents/agent-graph.ts` | 无（图编译） | — | 2.1, 3.1, 3.2 | ⬜ |
| 5.1 | factory.ts 空间上下文注入 | `src/agents/prompts/experts/factory.ts` | 无（prompt 构建） | — | 4.3 | ⬜ |
| 5.2 | response.ts 区域分组展示 | `src/agents/nodes/response.ts` | `agentAuditNodeStart/End`（已有） | — | 2.1 | ⬜ |
| 5.3 | EventBus fanout 事件 | `src/agents/cognitive-event-bus.ts` + `send-api.ts` + `kb-conflict-aggregator.ts` | `emit("professional:fanout_started")` + `emit("professional:fanin_complete")` | — | 2.1 | ⬜ |
| 6.1 | TypeScript 编译 | 全局 | 无 | — | 全部 | ⬜ |
| 6.2 | ESLint 检查 | 全局 | 无 | — | 6.1 | ⬜ |
| 6.3 | 手动端到端验证 | 全局 | 无 | — | 6.2 | ⬜ |

### 依赖拓扑

```
Task 1.1 (types.ts) ──→ Task 1.2 (voronoi.ts)
                   ├──→ Task 1.3 (fcm.ts)      ← 1.2/1.3/1.4/1.5 可并行
                   ├──→ Task 1.4 (state.ts)
                   └──→ Task 1.5 (coordinate-transform.ts)
                              │
          ┌───────────────────┘
          ▼
Task 2.1 (spatial-preprocessing.ts)  ← 编排 1.2+1.3，写入 1.4
          │
          ├──→ Task 3.1 (summary-retrieval.ts)
          │         │
          │         ▼
          │    Task 3.2 (summary-reasoning.ts)  ← 消费 2.1 空间数据 + 3.1 证据链
          │
          ├──→ Task 4.1 (reasoning.ts)          ← 4.1/4.2/4.3 可并行
          ├──→ Task 4.2 (per-expert-reasoning.ts)
          └──→ Task 4.3 (prompts/types.ts)
          │         │
          │         ▼
          │    Task 4.4 (agent-graph.ts)         ← 依赖 2.1+3.1+3.2 文件存在
          │
          ├──→ Task 5.1 (factory.ts)             ← 5.1/5.2/5.3 可并行
          ├──→ Task 5.2 (response.ts)
          └──→ Task 5.3 (cognitive-event-bus + send-api + kb-conflict)
                    │
                    ▼
              Task 6.1 → 6.2 → 6.3 (验证)
```

**产出**：
- [ ] 全部 Task `[T]` 通过
- [ ] ADD-7 记录落库（`record_dev_operation` 每条 task）
- [ ] `check_spec_sync` 通过

---

## Step 3.5：实现审查

**目的**：验证意图与实现无语义鸿沟。

**输入**：
- `checklist.md`
- `review-implementation-template.md`

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 按 `checklist-template.md` 执行跨项目联调检查
3. 读取 `review-implementation-template.md`，生成 `review-implementation.md`
4. 所有 `[T]` 项通过后，生成 `review-runtime.md`（含 `[R]` 待验证清单）

**产出**：
- [ ] `checklist.md` 全部 `[T]` 项已通过
- [ ] `review-implementation.md` 已生成
- [ ] `review-runtime.md` 已生成

---

## Step 4：审计数据验证

**目的**：编译 + 审计完整性检查。

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. `npx eslint src/` —— 零 error
3. 调用 `check_phase_symmetry` 验证打点标记完整性
4. 调用 `check_failure_path` 验证降级路径审计等价（ADD-6）：spatialRegions 为空 → 回退无空间模式

**关键降级路径验证**：
- [ ] `spatialRegions = null` → reasoning.ts 回退现有逻辑（不注入空间上下文 section）
- [ ] `managementZones = null` → summaryReasoning 降级为无空间模式
- [ ] Farm-Server API 不可用 → spatialPreprocessing 设 null，不阻塞管线
- [ ] 无传感器 → 每个地块独立成区域（不报错）

**产出**：
- [ ] `npx tsc --noEmit` 通过
- [ ] `npx eslint src/` 通过
- [ ] 对称性验证通过
- [ ] 失败路径审计等价验证通过

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "spatial-reasoning" })`。

- [ ] RAHS ≥ 90

---

## Step 5：AI 自动合规检查

**目的**：扫描全部修改文件的 ADD-1~ADD-7 合规性。

**动作**：
1. 对每个修改文件调用 `check_add_compliance(code, projectPattern="event-based")`
2. 汇总合规报告，标注违规项和风险等级

**产出**：
- [ ] 合规报告已生成
- [ ] 所有违规项有处理决策（修复/豁免/记录）

---

## Step 6-7：异常修复（条件性）

> 仅当 Step 4/5 发现异常时进入。

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二部分

**目的**：功能收敛判定，更新 Handoff，回到架构文档做最终校准。

**动作**：
1. **收敛判断**：全部 `[T]` 项通过 + RAHS ≥ 90 + 手动验证 5 项通过 → 功能收敛
2. **Handoff 更新**：更新 Handoff 的 §7（实际产出与偏离）、§8（验证结果）、§9（后置确认）
3. **Step 0 第二部分**：回架构文档做最终校准——验证决策管线说明书已反映空间推理新节点
4. **ADD-7 回查**：`query_audit_logs` 确认全部 17 个 task 的 `record_dev_operation` 记录已落库

**产出**：
- [ ] 收敛判定结果
- [ ] Handoff 已更新
- [ ] 架构文档已校准
- [ ] ADD-7 审计记录已落库确认

---

## Step 9：Report Closure（条件性）

> 本 Plan 不是 runtime-fix plan，跳过。

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/lib/spatial/types.ts` | CREATE | 1.1 | LIB | ⬜ |
| `src/lib/spatial/voronoi.ts` | CREATE | 1.2 | LIB | ⬜ |
| `src/lib/spatial/fcm.ts` | CREATE | 1.3 | LIB | ⬜ |
| `src/lib/spatial/coordinate-transform.ts` | CREATE | 1.5 | LIB | ⬜ |
| `src/agents/state.ts` | MODIFY | 1.4 | STATE | ⬜ |
| `src/agents/nodes/spatial-preprocessing.ts` | CREATE | 2.1 | NODE | ⬜ |
| `src/agents/nodes/summary-retrieval.ts` | CREATE | 3.1 | NODE | ⬜ |
| `src/agents/nodes/summary-reasoning.ts` | CREATE | 3.2 | NODE | ⬜ |
| `src/agents/nodes/reasoning.ts` | MODIFY | 4.1 | NODE | ⬜ |
| `src/agents/nodes/per-expert-reasoning.ts` | MODIFY | 4.2 | NODE | ⬜ |
| `src/agents/prompts/types.ts` | MODIFY | 4.3 | PROMPT | ⬜ |
| `src/agents/agent-graph.ts` | MODIFY | 4.4 | GRAPH | ⬜ |
| `src/agents/prompts/experts/factory.ts` | MODIFY | 5.1 | PROMPT | ⬜ |
| `src/agents/nodes/response.ts` | MODIFY | 5.2 | NODE | ⬜ |
| `src/agents/cognitive-event-bus.ts` | MODIFY | 5.3 | EVENT_BUS | ⬜ |
| `src/lib/langgraph/send-api.ts` | MODIFY | 5.3 | COMPONENT | ⬜ |
| `src/agents/nodes/kb-conflict-aggregator.ts` | MODIFY | 5.3 | NODE | ⬜ |
| `package.json` | MODIFY | 1.2 | CONFIG | ⬜ |
| `src/agents/nodes/retrieval.ts` | UNCHANGED | — | NODE | — |
| `src/agents/prompts/reasoning.ts` | UNCHANGED | — | PROMPT | — |
