# farm-agent-spatial-reasoning-plan-v2

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度。

## PLAN 元信息

- **Plan 名称**: farm-agent-spatial-reasoning-v2
- **启动时间**: 2026-07-07T18:00:00+08:00
- **主导 AI**: Qoder
- **触发来源**: `project-massif-resolution` + `professional-fanout` 两个 Plan 验收后，识别出多地块分析的根本瓶颈不在工具层，而在 LLM 推理层——工具结果被截断为 200 字符碎片，LLM 无法进行空间推理。v1 已存在，v2 在 v1 基础上大幅扩展：补齐独立推理模型设计、完整 Prompt 工程、全量数据装订链路、每文件改动细节。
- **前置依赖**:
  - `farm-agent-project-massif-resolution-plan-v1.md`（route 层注入 prebuiltMassifIds，解决"全农场不缺参"）
  - `farm-agent-professional-fanout-plan-v1.md`（professional 图 Send API fan-out，解决 experts 之间并行）
  - `farm-agent-thinking-level-runtime-fix-plan-v1.md`（thinkingLevel 路由到 professional，解决 professional 图可达性）
- **关联文档**:
  - Handoff: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-handoff-v1.md`（Step 8 收敛后生成）
  - Review: `.qoder/reviews/farm-agent-spatial-reasoning-review-v2.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/agents/nodes/spatial-preprocessing.ts` | NODE | NODE_CREATED | 不存在 | 新增：空间预处理节点。消费 state.toolResults + prebuiltMassifIds → 调 Farm-Server 获取 graphicDrawing 坐标和传感器坐标 → Voronoi 传感器覆盖归因 + FCM 管理分区聚类 → 写入 state.spatialRegions + state.managementZones。纯代码逻辑，不调 LLM | 待实施 |
| `src/agents/nodes/summary-retrieval.ts` | NODE | NODE_CREATED | 不存在 | 新增：领域知识代理检索节点。deep 图无 fan-out 拓扑，无法触发领域专家（pest_risk/weather/soil）各自的 per-expert retrieval → 本节点用汇总专家专属 filter（报告模板 + 农事标准 + 四情方法论）做一次宽泛的 ChromaDB 全类目检索（5-10 条），替领域专家补齐本该通过 RAG 获取的方法论/标准/历史案例知识，追加到 evidenceChain 末尾 | 待实施 |
| `src/agents/nodes/summary-reasoning.ts` | NODE | NODE_CREATED | 不存在 | 新增：汇总专家独立推理节点。消费 spatialRegions + managementZones + evidenceChain → 构建全农场区域级摘要 prompt → 单 LLM invoke → 产出 verdictResult。不做 KB 冲突检测，不做多 expert 遍历 | 待实施 |
| `src/agents/nodes/reasoning.ts` | NODE | NODE_MODIFIED | L108-118 toolMessages 截断 200 字符注入 prompt | 仅删除 `contentStr.slice(0, 200)` 截断，改用 `state.toolResults` 结构化数据。空间上下文由 summaryReasoning 独立负责，回退路径不变 | 待实施 |
| `src/agents/nodes/per-expert-reasoning.ts` | NODE | NODE_MODIFIED | L62-67 toolResults 全量 JSON 注入 | 改用 state.toolResults 结构化数据 → 按地块分组聚合 → 注入 per-expert prompt。暂不消费 spatialRegions（仅 deep 图使用），后续根据周报效果评估是否需要 | 待实施 |
| `src/agents/nodes/retrieval.ts` | NODE | COMPONENT_UNCHANGED | 现有 RAG 检索逻辑 | 不变。本节点的职责保持为 RAG evidence expert 路径的检索。汇总专家的领域知识检索由 summary-retrieval.ts 独立负责（不经过本节点），空间预处理由 spatial-preprocessing.ts 独立负责 | 不变 |
| `src/lib/spatial/voronoi.ts` | LIB | LIB_CREATED | 不存在 | Voronoi 图计算：Fortune's Algorithm（via d3-delaunay）→ 传感器覆盖区域划分。内部通过 `toCartesian()` 将地理坐标转为笛卡尔平面坐标 | 待实施 |
| `src/lib/spatial/coordinate-transform.ts` | LIB | LIB_CREATED | 不存在 | CGCS2000 ↔ WGS-84 坐标转换工具函数。注意：Farm-Server 使用天地图 CGCS2000 坐标系，与 WGS-84 偏差 < 1m。提供精确转换能力，但空间推理场景默认不调用（偏差对 Voronoi 分区无影响），调用方按需启用 | 待实施 |
| `src/lib/spatial/fcm.ts` | LIB | LIB_CREATED | 不存在 | FCM 聚类实现：PCA 降维 + 模糊C均值聚类 → 管理分区划分 | 待实施 |
| `src/agents/state.ts` | STATE | STATE_MODIFIED | 无 spatialRegions / managementZones | 新增 `spatialRegions: Annotation<VoronoiRegion[] \| null>()` + `managementZones: Annotation<ManagementZone[] \| null>()` | 待实施 |
| `src/agents/prompts/reasoning.ts` | PROMPT | PROMPT_UNCHANGED | 现有 reasoningPrompt 模板 | 不变。`buildSpatialContextSection()` 由 summary-reasoning.ts 内部负责，不修改 prompts/reasoning.ts | 不变 |
| `src/agents/prompts/experts/factory.ts` | PROMPT | PROMPT_MODIFIED | per-expert prompt 无空间上下文 | ExpertPromptInput 新增 `spatialContext?: SpatialContext`；build() 注入 `[空间上下文]` 区块 | 待实施 |
| `src/agents/prompts/types.ts` | PROMPT | PROMPT_MODIFIED | ExpertPromptInput 无 spatialContext | 新增 SpatialContext / ManagementZone 接口 | 待实施 |
| `src/agents/nodes/response.ts` | NODE | NODE_MODIFIED | toolExecutionSummary 仅显示"返回 N 条记录"；不区分汇总专家和普通专家，全部走 chat 风格 prompt | ① 新增 `buildRegionSummary()`；② `toolExecutionSummary` 新增 `regionBreakdown` 可选字段（四种路径回退为 undefined）；③ 新增 `isSummary` 分支：当 `expert.isSummary === true` 时，消费 `expert.reportTemplate` 章节定义替代 strategy.sections，`buildStreamingTextPrompt` 使用汇总专家专用 prompt 模板（非 chat 风格） | 待实施 |
| `src/agents/cognitive-event-bus.ts` | EVENT_BUS | EVENT_BUS_MODIFIED | 无 fanout 事件 | 新增 `professional:fanout_started` / `professional:fanin_complete` 到 CognitiveEvent 联合类型 | 待实施 |
| `src/agents/agent-graph.ts` | GRAPH | GRAPH_MODIFIED | deep 图无空间预处理/汇总检索/汇总推理节点 | 新增 spatialPreprocessing / summaryRetrieval / summaryReasoning 三个节点到 deep 图；professional 图不变 | 待实施 |

- **原子事务结构**: 6 轮
  - 第1轮：空间计算层（新建 spatial lib：types + voronoi + fcm + coordinate-transform + state 字段）
  - 第2轮：spatialPreprocessing 节点（数据入口统一 + Voronoi + FCM 编排）
  - 第3轮：summaryRetrieval（领域知识代理检索，替领域专家补齐 deep 图无法 fan-out 的 RAG 知识）+ summaryReasoning 节点（汇总专家推理）
  - 第4轮：现有 reasoning 节点改造（仅删除截断）+ per-expert-reasoning 改造（仅消费 toolResults 结构化数据，暂不不注入空间上下文）
  - 第5轮：Prompt 工程（仅 factory.ts 注入 spatialContext）+ Response 装订 + CognitiveEventBus
  - 第6轮：tsc + eslint 零错误验证

---

## 一、为什么前三个 Plan 一直没做这个 — 根因分析

### 1.1 前置 Plan 做了什么、为什么没碰空间推理

| Plan | 做了什么 | 为什么没做空间推理 | 根本原因 |
|------|---------|-------------------|---------|
| `thinking-level-runtime-fix` (07/04) | 修路由：thinkingLevel 从 `deep` 改为 `professional` 时，conditional edge 正确路由到 professional 图 | 只修路由，不碰推理内容。它的职责是"让 professional 图能被执行"，不关心 professional 图执行时 LLM 看到什么数据 | 路由层问题 vs 推理层问题是两个不同的维度，解决路由不等于解决推理质量 |
| `project-massif-resolution` (07/06) | route 层注入 `prebuiltMassifIds`：从 Farm-Server 拉取当前项目下所有地块 ID，注入 state 作为全农场默认值 | 解决的是"不缺参"——即工具调用时 massifId 参数不为空，Farm-Server 能返回数据。但不解决"有了数据之后 LLM 怎么用" | 数据可达性 ≠ 数据可用性。数据到了 state 但 LLM 看到的是 200 字符碎片 |
| `professional-fanout` (07/06) | 串行→Send API fan-out 并行：多个 expert 通过 LangGraph Send API 并行执行 perExpertRetrieval → perExpertReasoning | 解决的是 experts 之间的并行度，不是单个 expert 内部的推理质量。每个 expert 的 prompt 仍然只看到 200 字符截断结果 | 并行是拓扑优化，推理质量是 prompt 工程问题 |

### 1.2 三个 Plan 的共同盲区

```
Farm-Server ──→ toolNode ──→ state.toolResults (完整 list + columns，可以到 200 条 × 10 字段)
                                    │
                                    ▼
                            reasoning.ts L108-118
                              contentStr.slice(0, 200)  ← 截断到 200 字符
                                    │
                                    ▼
                            LLM prompt:
                            "[工具: query_insect_data] {\"success\":true,\"total\":200,\"list\":[{\"massifName\":\"一号地块\"..."
                                    │
                                    ▼
                            LLM 只看到第一条记录的碎片 JSON，不知道全农场有多少个地块、
                            每个地块的趋势如何、无法做跨地块比较
```

**核心矛盾**：`state.toolResults` 已经是一个完整的数据契约（`{ toolName, success, recordCount, list, columns }`），但 reasoning.ts 在构建 prompt 时**完全没有消费它**——它消费的是 `state.messages` 中的 ToolMessage 字符串，然后用 `slice(0, 200)` 截断。

### 1.3 为什么这个盲区迟迟未被发现

1. **单地块场景下不暴露**：当用户只查一个地块时，200 字符足够覆盖第一条记录的关键信息，LLM 能给出合理回答。问题只在多地块（全农场）场景下暴露。
2. **数据契约与消费解耦**：`toolResults` 是 `toolNode → response` 的契约（`toolresults-contract` Plan 引入），但 reasoning 节点没有升级为消费 `toolResults`，仍在消费 `messages` 中的 ToolMessage。
3. **professional 图刚上线**：professional 图（Send API fan-out）是 07/06 才验收的，在此之前全农场分析根本走不到 per-expert 推理，问题自然不暴露。

---

## 二、问题背景 — 全农场分析的完整链路断裂分析

### 2.0 产品需求与行业对标（6 点需求 × 行业算法）

全农场整体态势分析不是"把多个个地块的数据拼在一起给 LLM 看"，而是需要一整套空间推理基础设施。xiaomingming提出的 6 个核心需求，按性质分为两层：

**几何层（#1-3）**：回答"农场长什么样、设备在哪里、数据归谁管"——输入是坐标，输出是空间关系。

**分析分区层（#4-6）**：回答"哪些地块应该一起分析、数据怎么聚合、推理怎么联动"——输入是数据，输出是决策分区。

#### 2.0.1 几何层：空间坐标与传感器覆盖

| # | 产品需求 | 行业算法 | 行业来源 |
|:--:|------|------|------|
| 1 | **农场外轮廓多边形顶点信息**：拿到农场边界的所有顶点坐标，形成完整的农场几何模型 | **Voronoi Diagram（泰森多边形）+ Delaunay 三角剖分** | 气象学标准做法（Thiessen 1911）；[SuperMap: 泰森多边形空间插值](https://help.supermap.com/iDesktopX/zh/tutorial/Analyst/Raster/ThiessenPolygon)；[Voronoi 图在传感器网络覆盖中的应用](https://wulixb.iphy.ac.cn/article/doi/10.7498/aps.63.220701) |
| 2 | **设备在农场内的坐标信息**：传感器、气象站、虫情测报灯的物理位置坐标，建立设备→地块的空间映射 | **Voronoi cell 天然定义传感器覆盖范围**：每个传感器覆盖离它最近的所有区域，这是计算几何中"最近邻归属"的标准解法 | [物理学报 2014: BCBS 算法（盲区形心覆盖策略）](https://wulixb.iphy.ac.cn/article/doi/10.7498/aps.63.220701)；[CSDN 2025: Voronoi 图划分 + Kriging 插值法传感器布局](https://blog.csdn.net/weixin_36444661/article/details/155584440) |
| 3 | **同一种设备存在多个时的选择算法**：当多个虫情测报灯/气象站覆盖同一区域时，按覆盖范围选最优设备 | **k-Order Voronoi + Power Diagram（功率图）**：k-Order Voronoi 支持多个最近邻，Power Diagram 支持加权距离（传感器精度/可靠性加权） | [Nature 2025: 无线传感器网络自适应覆盖优化](https://www.nature.com/articles/s41598-025-16031-3)；[IEEE JSTSP 2025: AI for Smart Agriculture](https://signalprocessingsociety.org/blog/ieee-jstsp-special-series-artificial-intelligence-smart-agriculture)；[Nature 2025: UAV 覆盖路径规划中的 Voronoi 分割](https://www.nature.com/articles/s41598-025-20978-8) |

**几何层小结**：这三个需求本质上是**计算几何问题**——Voronoi 图是统一的解法。外轮廓 + 设备坐标 → Voronoi 划分 → 每个传感器覆盖哪些地块 → 同类型多传感器时按 Power Diagram 选最优。几何层不涉及数据内容，只涉及空间关系。

#### 2.0.2 分析分区层：数据驱动的管理分区与推理

| # | 产品需求 | 行业算法 | 行业来源 |
|:--:|------|------|------|
| 4 | **重点关注区域加量采样**：当某个传感器类型被重点关注时（如虫情上升期），可动态调高该区域的采样频率 | **Adaptive Sampling Rate（自适应采样频率）**：基于奈奎斯特准则 + 变化率阈值触发，动态调整采样频率 | [Smart Sensors 2024: 精准农业智能传感器综述](https://pmc.ncbi.nlm.nih.gov/articles/PMC11053448/)；[专利 CN202510338326：卫星物联网智慧农业信息管理方法](https://www.xjishu.com/zhuanli/55/202510338326.html)（"根据区域分类信息分别构建不同区域的环境变化预测模型"） |
| 5 | **推理时四情数据不裁切、不降维**：虫情/土墒/气象/农事四情数据全量进入推理上下文，不因上下文窗口限制而截断 | **Long-Context LLM + 管理分区聚合**：不是把原始数据全量注入 LLM，而是通过管理分区（FCM 聚类）做数据驱动的聚合，让 LLM 看到分区级摘要而非原始记录 | [Nature 2025: 基于 FCM 聚类的精准农业管理分区划定](https://www.nature.com/articles/s41598-025-07283-0)；[AgriGPT (浙江大学 2025): 农业领域 LLM 生态系统](https://arxiv.org/html/2508.08632v1)（Tri-RAG 多通道检索增强） |
| 6 | **四情融合推理模型**：墒情 × 虫情 × 气象 × 农事在同一上下文内联动分析，跨数据源交叉推理 | **Fuzzy C-Means 管理分区 + 九丞 WX-Q2 四情融合研判算法**：PCA 降维提取主控因子 → FCM 聚类划分管理分区 → per-zone 综合决策 | [农业工程学报 2025: 基于 FCM 的玉米农田管理分区研究](http://vip.hnadl.cn/article/detail.aspx?id=7100650408)；[Precision Agriculture 2022: 管理分区聚类与平滑管线](https://m.zhangqiaokeyan.com/journal-foreign-detail/0704065207883.html)；[生态学报 2020: 基于 GIS 的盐渍化农田管理分区](https://www.ecologica.cn/html/2020/19/stxb201810092178.htm) |

**分析分区层小结**：这三个需求本质上是**数据分析问题**——分区依据不是传感器位置，而是数据本身的相似性（土壤养分、墒情、虫情趋势、气象条件）。FCM 模糊聚类是学术界和工业界的标准做法。

#### 2.0.3 两层之间的关系

```
几何层（Voronoi）                         分析分区层（FCM 管理分区）
─────────────────                       ─────────────────────────
输入: 坐标 (lat, lng)                     输入: 数据 (土壤养分、墒情、虫情、气象)
算法: Fortune's Algorithm O(n log n)      算法: Fuzzy C-Means 聚类
输出: "传感器 S1 覆盖地块 1,2,3"           输出: "地块 1,3,5 属于低湿区，地块 2,4,6 属于高燥区"
用途: 传感器数据归因                       用途: 差异化分析决策

两层的协作关系:
  Voronoi 先确定"每个地块的数据来自哪个传感器"
    → 数据归因完成
  FCM 再基于归因后的数据，按数值相似性划分管理分区
    → 分区完成
  LLM 拿到分区级摘要，做跨分区比较和综合决策
```

> **关键认知**：几何层和分析分区层解决的是不同的问题，不能互相替代。Voronoi 回答"传感器管哪块地"，FCM 回答"哪些地应该一起管"。前者是几何问题，后者是数据分析问题。

### 2.1 当前数据流转（断裂版）

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                        当前数据流（截断版）                                      │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ① GUI 用户点击"全农场虫情分析"卡片                                              │
│     │                                                                        │
│     ▼                                                                        │
│  ② route.ts: resolveProjectMassifIds()                                       │
│     → Farm-Server /massif/options?projectId=X → 返回 9 个地块                 │
│     → state.prebuiltMassifIds = [1, 2, 3, 4, 5, 6, 7, 8, 9]                 │
│     │                                                                        │
│     ▼                                                                        │
│  ③ intentionNode: thinkingLevel = "professional"                             │
│     → expertPlan = [{ expertId: "pest_risk" }, { expertId: "crop_compare" }] │
│     │                                                                        │
│     ▼                                                                        │
│  ④ routeByExpertPlan: Send API fan-out                                       │
│     → new Send("perExpertRetrieval", { fanoutExpertId: "pest_risk" })        │
│     → new Send("perExpertRetrieval", { fanoutExpertId: "crop_compare" })     │
│     │                                                                        │
│     ▼                                                                        │
│  ⑤ perExpertRetrieval: LLM 决定调用 tool                                      │
│     → tool_calls: [query_insect_data(massifId=undefined, dataTime=[...])]    │
│     │                                                                        │
│     ▼                                                                        │
│  ⑥ toolNode: 执行 query_insect_data                                          │
│     → Farm-Server /insect-data/page?projectId=X → 返回 200 条记录             │
│     → state.toolResults = [{                                                │
│         toolName: "query_insect_data",                                       │
│         success: true,                                                       │
│         recordCount: 200,                                                    │
│         list: [200 条完整记录，每条含 massifName/dataTime/at/ah/lux/...],      │
│         columns: [{ prop: "massifName", label: "地块" }, ...]                │
│       }]                                                                     │
│     │                                                                        │
│     ▼                                                                        │
│  ⑦ perExpertReasoningNode (per-expert-reasoning.ts L62-67):                  │
│     const toolMessages = messages.filter(m => m.role === "tool")             │
│     const toolResults = toolMessages.map(tm => ({                            │
│       toolName: tm.name,                                                     │
│       content: typeof tm.content === "string" ? tm.content : JSON.stringify  │
│     }))                                                                      │
│     → 每条 toolResult.content = JSON.stringify(完整 ToolMessage)             │
│     → 这是一个巨大的 JSON 字符串，包含 200 条记录的全部字段                      │
│     │                                                                        │
│     ▼                                                                        │
│  ⑧ factory.ts build():                                                      │
│     for (const tr of input.toolResults) {                                    │
│       lines.push(`- [${tr.toolName}] ${tr.content}`)  ← 注入完整 JSON 字符串  │
│     }                                                                        │
│     → prompt 中注入的是 200 条记录的完整 JSON，可能 10000+ 字符                  │
│     │                                                                        │
│     ▼                                                                        │
│  ⑨ LLM 推理:                                                                 │
│     → 收到一个巨大的 JSON blob，没有按地块分组，没有统计摘要                      │
│     → 注意力被 200 条扁平记录淹没，无法有效跨地块比较                            │
│     → 最终输出："查询成功，返回 200 条记录，虫情正常" ← 敷衍式回答                │
│                                                                              │
│  问题总结：                                                                    │
│  1. deep 图 reasoning.ts 有 slice(0,200) 截断，但 professional 图的             │
│     per-expert-reasoning.ts 没有截断，而是注入了全量 JSON 字符串——               │
│     两种路径都有问题，但问题不同：deep 图是信息不足，professional 图是信息过载     │
│  2. 两个路径都没有做"按地块分组聚合 → 区域级摘要"的中间处理                       │
│  3. 没有空间推理上下文：地块的 graphicDrawing 坐标从未被利用                     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 当前问题在两种图上的不同表现

| 维度 | deep 图 (reasoning.ts) | professional 图 (per-expert-reasoning.ts) |
|------|----------------------|------------------------------------------|
| 截断方式 | `contentStr.slice(0, 200)` — 硬截断 | 无截断，注入完整 JSON 字符串 |
| LLM 看到什么 | 第一条记录的碎片 JSON | 200 条记录的完整 JSON blob（可能 10000+ 字符） |
| 问题 | 信息不足，LLM 不知道全貌 | 信息过载，LLM 注意力退化 |
| 根本原因 | 消费 `state.messages` 中的 ToolMessage 字符串 | 同左，且直接注入全量 content |
| 都没做的事 | 消费 `state.toolResults` 结构化数据 | 同左 |

---

## 三、架构设计

### 3.0 图拓扑（deep 图 × professional 图 完整版）

#### 3.0.1 deep 图：汇总专家全农场分析路径

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    deep 图（汇总专家全农场分析）                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  __start__                                                                  │
│      │                                                                      │
│      ▼                                                                      │
│  intention (intentionAsyncNode)                                             │
│    │ thinkingLevel = "deep", explicitExpertId = "daily_report"               │
│    │ prebuiltMassifIds = [1,2,3,4,5,6,7,8,9]                                │
│    ▼                                                                        │
│  ┌─ routeByIntent ──────────────────────────────────────────────┐          │
│  │  thinkingLevel=deep → "retrieval"（单专家路径）                 │          │
│  └───────────────────────────────────────────────────────────────┘          │
│      │                                                                      │
│      ▼                                                                      │
│  retrieval (现有 retrievalNode)                                              │
│    │ 不变：RAG 检索 → evidenceChain                                          │
│    ▼                                                                        │
│  toolNode (LLM 决定调用工具)                                                  │
│    │ tool_calls → toolNode 执行 → 结果写回 state.toolResults                 │
│    │ .addEdge("toolNode", "intention")  ← 循环回 intention                  │
│    │ .addEdge("intention", "spatialPreprocessing")  ← 工具调用完成后进入     │
│    ▼                                                                        │
│  ★ spatialPreprocessing (★新增: spatial-preprocessing.ts)                    │
│    │ 输入: state.toolResults + prebuiltMassifIds + projectId                │
│    │ 步骤1: 调 Farm-Server /massif/options 获取 graphicDrawing 坐标         │
│    │ 步骤2: 调 Farm-Server /equipment/page 获取传感器坐标                   │
│    │ 步骤3: computeVoronoiRegions(sensors, massifs) → VoronoiRegion[]       │
│    │ 步骤4: computeManagementZones(toolResults, voronoiRegions) → FCM 聚类  │
│    │ 输出: state.spatialRegions, state.managementZones                      │
│    │ 纯代码逻辑，不调 LLM，不调 RAG                                          │
│    │ 审计: SPATIAL_PREPROCESS (regionCount, zoneCount, sensorCount)         │
│    ▼                                                                        │
│  ★ summaryRetrieval (★新增: summary-retrieval.ts)                            │
│    │ 角色: 领域知识代理检索 — deep 图无 fan-out 拓扑，不能触发领域专家        │
│    │       (pest_risk/weather/soil) 各自的 per-expert retrieval。             │
│    │       本节点从当前汇总专家的 summaryExpertIds（如 weekly_report →         │
│    │       ["weather_impact", "pest_risk"]）提取各专家的 grounding.            │
│    │       collectionName，做跨 collection 联合 ChromaDB 检索（每 collection   │
│    │       3-5 条，总上限 10 条），替领域专家补齐本该通过 fan-out RAG 获取     │
│    │       的方法论/标准/历史案例知识。                                       │
│    │ 检索策略: 不硬编码 cateId，改用 registry 的 grounding.collectionName     │
│    │ 检索量: 每 collection 3-5 条，总上限 10 条（配置集中管理于 chroma-config.ts              │
│    │       SUMMARY_RETRIEVAL_CONFIG，不在节点代码中硬编码）                               │
│    │ 输出: 按相似度降序，top 10 追加到 evidenceChain 末尾                      │
│    │ 审计: SUMMARY_RETRIEVAL (hitCount, sourceBreakdown)                    │
│    ▼                                                                        │
│  ★ summaryReasoning (★新增: summary-reasoning.ts)                            │
│    │ 输入: spatialRegions + managementZones + evidenceChain + toolResults   │
│    │ 构建: 空间上下文 section → 全农场区域级摘要 prompt                        │
│    │ 推理: 单 LLM invoke（汇总专家 prompt，不做 KB 冲突检测）                  │
│    │ 输出: verdictResult                                                      │
│    │ 审计: SUMMARY_REASONING (zoneCount, evidenceCount, confidence)          │
│    ▼                                                                        │
│  interactionPointDetection (现有)                                            │
│    │                                                                         │
│    ├─ 有交互点 → response (interrupt)                                        │
│    └─ 无交互点 → verdict                                                     │
│         │                                                                    │
│         ▼                                                                    │
│  verdict (现有) → response (现有) → __end__                                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**deep 图新增节点声明（agent-graph.ts）**：

```typescript
// deep 图新增（在现有 retrieval/verdict 等节点之后）
workflow
  .addNode("spatialPreprocessing", async (state, config) => {
    return wrapNodeWithAudit("spatialPreprocessing", state, spatialPreprocessingNode, config)
  })
  .addNode("summaryRetrieval", async (state, config) => {
    return wrapNodeWithAudit("summaryRetrieval", state, summaryRetrievalNode, config)
  })
  .addNode("summaryReasoning", async (state, config) => {
    return wrapNodeWithAudit("summaryReasoning", state, summaryReasoningNode, config)
  })
  // 条件边：intention 后根据 thinkingLevel 路由
  .addConditionalEdges("intention", routeByIntent, [
    "toolNode", "retrieval", "response", "spatialPreprocessing"
  ])
  .addEdge("spatialPreprocessing", "summaryRetrieval")
  .addEdge("summaryRetrieval", "summaryReasoning")
  .addEdge("summaryReasoning", "interactionPointDetection")
```

> **关键设计决策**：`spatialPreprocessing` 在 `toolNode → intention` 循环完成后才进入。LLM 在 intention 阶段决定调哪些工具 → toolNode 执行 → 结果回传 intention → LLM 确认数据足够 → 路由到 spatialPreprocessing。这保证了空间预处理拿到的 toolResults 是完整的。
>
> **路由条件**（`routeByIntent` 内部判断逻辑）：
> ```typescript
> // intention 节点产出 state.lastAIMessage
> // routeByIntent 新增 spatialPreprocessing 分支：
> //   条件1: thinkingLevel === "deep"
> //   条件2: lastAIMessage 无 tool_calls（LLM 不再请求新工具，数据收集完毕）
> //   条件3: state.toolResults.length > 0（有工具调用发生过）
> //   → 路由到 "spatialPreprocessing"
> // 若条件2 不满足（还有 tool_calls）→ "toolNode"（继续工具调用循环）
> // 若条件3 不满足（无数据工具被调用，纯 RAG 场景）→ "retrieval"（现有逻辑）
> ```
>
> **deep 图 vs professional 图范式差异**：deep 图是 DAG 单路径纵向推理（线性管线，无 fan-out/fan-in）。汇总专家在 deep 图中运行时，无法像 professional 图那样通过 Send API fan-out 触发领域专家（pest_risk/weather/soil）各自做 per-expert retrieval → reasoning。因此需要 `summaryRetrieval` 节点用一次宽泛的 ChromaDB 检索（报告模板 + 农事标准 + 四情方法论）替多个领域专家补齐知识贡献。这与 professional 图的 fan-out/fan-in 范式是互补关系，不是重复

#### 3.0.2 professional 图：多专家并行分析路径（不变）

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    professional 图（多专家并行分析，不变）                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  __start__                                                                  │
│      │                                                                      │
│      ▼                                                                      │
│  intention (intentionAsyncNode)                                             │
│    │ thinkingLevel = "professional", expertPlan = [...]                     │
│    ▼                                                                        │
│  routeByExpertPlan (send-api.ts)                                            │
│    │ expertPlan 为空 → "kbConflictAggregator" 直通                           │
│    │ expertPlan 有值 → Send[] fan-out:                                       │
│    │                                                                         │
│    ├─[Send]→ perExpertRetrieval [fanoutExpertId="pest_risk"]                │
│    │           │  RAG 检索（按 expert.evidenceFilter 过滤）                   │
│    │           ▼                                                             │
│    │         perExpertReasoning [fanoutExpertId="pest_risk"]                 │
│    │           │  单 expert LLM 推理（工具结果归集 + prompt 构建）            │
│    │           │  .addConditionalEdges: tool_calls → toolNode → 循环         │
│    │           ▼                                                             │
│    │         perExpertStructuredOutput (structuredOutputNode)                │
│    │           │  fanoutExpertId 存在 → 从 verdictResult 取 reasoning 文本   │
│    │           │  → ExpertClaim(pest_risk)                                   │
│    │                                                                         │
│    ├─[Send]→ perExpertRetrieval [fanoutExpertId="weather_impact"]           │
│    │           │  ... (同上)                                                  │
│    │           ▼                                                             │
│    │         perExpertReasoning → perExpertStructuredOutput                  │
│    │           → ExpertClaim(weather_impact)                                 │
│    │                                                                         │
│    └─[Send]→ perExpertRetrieval [fanoutExpertId="crop_compare"]             │
│                │  ... (同上)                                                  │
│                ▼                                                             │
│              perExpertReasoning → perExpertStructuredOutput                  │
│                → ExpertClaim(crop_compare)                                   │
│                                                                             │
│  ── fan-in (expertClaims reducer concat) ──                                  │
│    │                                                                         │
│    ▼                                                                         │
│  kbConflictAggregator (现有)                                                  │
│    │ 遍历 ExpertClaim[] → 收集 KB 冲突 → interrupt（如需）                    │
│    │ CognitiveEventBus.emit("professional:fanin_complete")  ★新增           │
│    ▼                                                                         │
│  conflictResolver (现有) → aggregation (现有) → coordinationDialogue (现有)  │
│    ▼                                                                         │
│  interactionPointDetection (现有) → verdict (现有) → response (现有)          │
│    │                                                                         │
│    ▼                                                                         │
│  __end__                                                                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

> **professional 图不变**：本 Plan 不修改 professional 图拓扑。per-expert-reasoning 的改造仅涉及 prompt 工程（消费 toolResults 结构化数据替代全量 JSON），暂不注入空间上下文（spatialRegions 仅 deep 图使用）。

#### 3.0.3 两种图的分工

| 维度 | deep 图（汇总专家） | professional 图（多专家） |
|------|---------------------|--------------------------|
| 场景 | 全农场日报/周报/生长报告 | 多专家并行分析（虫害+气象+品种） |
| 推理模式 | 单专家，全量数据，一次推理 | 多专家，并行推理，fan-in 汇聚 |
| 空间预处理 | ✅ 走 spatialPreprocessing | ❌ 不经过（per-expert 各自处理） |
| 检索方式 | summaryRetrieval（汇总专家专属） | perExpertRetrieval（按 expert filter） |
| 推理节点 | summaryReasoning（新增） | perExpertReasoning（现有） |
| 冲突处理 | 不需要（单专家） | kbConflictAggregator → conflictResolver |

### 3.1 推理模型总览

本 Plan 的核心创新是引入一个**独立于 LLM 的代码层推理模型**——spatialPreprocessing 节点作为**数据生产者**，summaryReasoning 节点作为**数据消费者**。这个模型不替代 LLM，而是**预处理数据**，让 LLM 拿到的是"烹饪好的食材"而非"生肉"。

> **数据完整性关注**：spatialPreprocessing → summaryReasoning 是数据生产→消费的关键链路。spatialPreprocessing 必须保证以下数据完整传递：
> - `state.toolResults`（工具返回的原始数据，不截断、不降维）
> - `state.spatialRegions`（Voronoi 传感器覆盖区域，含地块归属）
> - `state.managementZones`（FCM 管理分区，含 per-zone 数据摘要）
> - summaryReasoning 消费时必须验证以上三个字段非空，任一项缺失 → 降级为无空间模式（回退现有逻辑）。

```
┌─────────────────────────────────────────────────────────────────────┐
│                    独立推理模型（代码层，非 LLM）                        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  输入层（spatialPreprocessing 作为统一数据入口）                       │
│  ├─ state.toolResults[].list (200 条原始记录，不截断)                │
│  ├─ state.toolResults[].columns (字段定义)                           │
│  ├─ state.prebuiltMassifIds (全农场地块 ID)                          │
│  ├─ massif 的 graphicDrawing 坐标 (从 Farm-Server 获取)              │
│  └─ 传感器坐标 (从 Farm-Server equipment API 获取)                   │
│                                                                     │
│       │  spatialPreprocessing 节点（纯代码，不调 LLM）               │
│       ▼                                                              │
│  计算层                                                              │
│  ├─ Voronoi 空间划分 (Fortune's Algorithm, O(n log n))               │
│  │   → 输入: 传感器坐标点集                                          │
│  │   → 输出: 每个传感器的 Voronoi cell (凸多边形)                     │
│  │   → 叠加农场边界裁剪                                              │
│  │   → 输出: spatialRegions: VoronoiRegion[]                        │
│  │                                                                   │
│  ├─ FCM 管理分区聚类                                                  │
│  │   → 输入: toolResults 数据 + Voronoi 归因后地块数据               │
│  │   → 算法: PCA 降维 + Fuzzy C-Means 聚类                           │
│  │   → 输出: managementZones: ManagementZone[]                       │
│  │                                                                   │
│  └─ 工具结果结构化聚合（按 managementZone 归并）                      │
│      → 输入: state.toolResults[].list (200 条) + managementZones     │
│      → 步骤1: 按 massifName 分组                                     │
│      → 步骤2: 计算每个地块的统计量 (recordCount, 均值, 趋势↑/→/↓)     │
│      → 步骤3: 按 managementZone 归并                                  │
│      → 步骤4: 生成区域级摘要文本 (每个区域 ≤ 500 tokens)              │
│      → 输出: SpatialContext { regions: RegionSummary[] }            │
│                                                                     │
│       │                                                              │
│       ▼                                                              │
│  消费层（summaryReasoning 作为消费者）                                │
│  ├─ 验证 spatialRegions / managementZones / toolResults 完整性      │
│  ├─ buildSpatialContext() → 产出 [空间推理上下文]                     │
│  ├─ 注入汇总专家 prompt → 单 LLM invoke                               │
│  └─ 产出 verdictResult（含 per-zone 分析结论）                        │
│                                                                     │
│  展示层                                                              │
│  └─ response.ts: buildRegionSummary() → 按区域分组展示               │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 3.2 Voronoi 空间计算层详解

**为什么选择 Voronoi 图？**

Voronoi 图是计算几何中解决"最近邻归属"问题的标准算法。在农场场景中：
- 每个传感器（虫情测报灯、气象站、土墒传感器）有一个物理坐标
- 农场中的每个地块应该归属于"最近"的传感器
- Voronoi 图天然给出了这个划分：每个传感器的 Voronoi cell 内所有点离该传感器最近

**算法细节**：

```
输入:
  sensors: [{ id: "S1", type: "insect", lat: 32.15, lng: 118.72 }, ...]
  massifs: [{ id: 1, name: "一号地块", graphicDrawing: "[{lat:32.150,...},{lat:32.152,...},...]" }, ...]
  farmBoundary: Polygon (农场外轮廓，可选，用于裁剪)

步骤:
  1. 将传感器坐标转换为笛卡尔平面坐标（UTM 投影或简单线性近似）
  2. 运行 Fortune's Algorithm (sweepline) 计算 Voronoi 图
     - 时间复杂度: O(n log n)，n = 传感器数量 (通常 3-10 个)
     - 输出: 每个传感器对应一个 Voronoi cell (凸多边形，由半边结构表示)
  3. 可选：叠加农场边界多边形，裁剪超出边界的 cell
  4. 对每个地块，计算其 graphicDrawing 多边形的重心点
  5. 判断重心点落在哪个 Voronoi cell 内 → 该地块归属于该 cell 对应的传感器
  6. 输出: VoronoiRegion[]

输出类型:
  VoronoiRegion {
    regionId: "region_A"
    sensorId: "S1"
    sensorType: "insect" | "weather" | "soil_moisture"
    massifIds: [1, 2, 3]
    massifNames: ["一号地块", "二号地块", "三号地块"]
    polygon: [{ lat: number, lng: number }]  // Voronoi cell 多边形顶点
    riskLevel?: "low" | "medium" | "high"  // 根据工具数据动态计算
  }
```

**实现方案选择**：

| 方案 | 优点 | 缺点 | 结论 |
|------|------|------|------|
| 手写 Fortune's Algorithm | 零依赖，完全可控 | 实现复杂，边界情况多 | ❌ 不推荐 |
| 使用 `d3-delaunay` npm 包 | 成熟稳定，API 简洁 | 增加一个依赖 | ✅ 推荐 |
| 使用 `@turf/voronoi` | GeoJSON 原生支持 | 依赖较重，需要 turf 全家桶 | 备选 |

**推荐方案**：`d3-delaunay`（npm: `d3-delaunay`），它提供了 `Delaunay.from(points).voronoi()` 方法，可以直接计算 Voronoi 图，并支持 `cellPolygon(i)` 获取每个 cell 的多边形。

### 3.3 工具结果结构化聚合层详解

**聚合逻辑**（纯函数，不依赖 LLM）：

```typescript
function aggregateToolResults(
  toolResults: ToolResult[],
  spatialRegions: VoronoiRegion[]
): RegionSummary[] {
  // 步骤1: 建立 massifName → regionId 的索引
  const massifToRegion = new Map<string, string>()
  for (const region of spatialRegions) {
    for (const name of region.massifNames) {
      massifToRegion.set(name, region.regionId)
    }
  }

  // 步骤2: 按 massifName 分组所有记录
  const byPlot = new Map<string, Record<string, unknown>[]>()
  for (const tr of toolResults) {
    for (const record of tr.list) {
      const massifName = record.massifName as string
      if (!massifName) continue
      if (!byPlot.has(massifName)) byPlot.set(massifName, [])
      byPlot.get(massifName)!.push(record)
    }
  }

  // 步骤3: 计算每个地块的统计量
  const plotStats: PlotStat[] = []
  for (const [massifName, records] of byPlot) {
    plotStats.push({
      massifName,
      recordCount: records.length,
      trend: computeTrend(records),  // 按时间排序，比较首尾值
      avgValues: computeAvgValues(records),  // 各数值字段的均值
      regionId: massifToRegion.get(massifName) || "unassigned",
    })
  }

  // 步骤4: 按 regionId 归并
  const byRegion = new Map<string, PlotStat[]>()
  for (const ps of plotStats) {
    if (!byRegion.has(ps.regionId)) byRegion.set(ps.regionId, [])
    byRegion.get(ps.regionId)!.push(ps)
  }

  // 步骤5: 生成区域级摘要
  const regionSummaries: RegionSummary[] = []
  for (const [regionId, plots] of byRegion) {
    const region = spatialRegions.find(r => r.regionId === regionId)
    regionSummaries.push({
      regionId,
      plotCount: plots.length,
      totalRecordCount: plots.reduce((sum, p) => sum + p.recordCount, 0),
      dominantTrend: computeDominantTrend(plots),
      plotNames: plots.map(p => p.massifName),
      sensorType: region?.sensorType || "unknown",
      summaryText: buildSummaryText(region, plots),  // 自然语言摘要
    })
  }

  return regionSummaries
}
```

**趋势计算（computeTrend）**：

```
输入: 按 dataTime 排序的记录数组
算法:
  1. 取前 1/3 记录的均值 = earlyAvg
  2. 取后 1/3 记录的均值 = lateAvg
  3. 变化率 = (lateAvg - earlyAvg) / earlyAvg × 100%
  4. 变化率 > 10% → "↑" (上升)
     变化率 < -10% → "↓" (下降)
     否则 → "→" (平稳)
```

**区域摘要文本生成（buildSummaryText）**：

```
输入: region + plotStats[]
输出: 不超过 500 tokens 的自然语言摘要

示例:
  "区域 A [低洼区]: 覆盖 3 个地块（一号地块、二号地块、三号地块），
   虫情传感器 S1 覆盖。
   虫情趋势: ↑ 上升（+15%），最近 7 天发现 2 类害虫。
   土墒: 平均湿度 78%，偏高。
   气象: 本周降雨量 45mm，温度 22-28°C。
   风险: 虫害高风险 + 渍涝风险。"
```

---

## 四、完整数据流转（预期版）

### 4.1 deep 图：汇总专家全农场分析（预期数据流）

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                   deep 图汇总专家全农场分析（预期数据流）                          │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ① GUI 用户点击"全农场日报"卡片 → route.ts 注入 prebuiltMassifIds              │
│     → state.prebuiltMassifIds = [1, 2, 3, 4, 5, 6, 7, 8, 9]                 │
│                                                                              │
│  ② intentionNode: thinkingLevel = "deep", explicitExpertId = "daily_report"  │
│     → LLM 决定调用工具: query_insect_data + query_soil_moisture +             │
│       query_farm_weather（全农场，不传 massifId）                              │
│                                                                              │
│  ③ retrieval (现有，不变): RAG 知识库检索 → evidenceChain                       │
│                                                                              │
│  ④ toolNode: LLM 调用的工具执行                                                │
│     → 3 个工具 × 200 条记录 = 600 条原始数据                                   │
│     → state.toolResults = [                                                  │
│         { toolName: "query_insect_data", success: true, recordCount: 200,    │
│           list: [...], columns: INSECT_DATA_COLUMNS },                        │
│         { toolName: "query_soil_moisture", success: true, recordCount: 150,  │
│           list: [...], columns: SOIL_MOISTURE_COLUMNS },                      │
│         { toolName: "query_farm_weather", success: true, recordCount: 63,    │
│           list: [...], columns: WEATHER_COLUMNS },                            │
│       ]                                                                      │
│     → toolNode → intention 循环: LLM 确认数据足够，不再调工具                   │
│                                                                              │
│  ⑤ ★ spatialPreprocessing (★新增节点) ★                                      │
│     │ 步骤1: 调 Farm-Server /massif/options?projectId=X 获取 9 个地块          │
│     │        的 graphicDrawing 坐标                                           │
│     │ 步骤2: 调 Farm-Server /equipment/page?projectId=X 获取传感器坐标         │
│     │ 步骤3: computeVoronoiRegions(sensors, massifs)                          │
│     │        → spatialRegions: [                                              │
│     │            { regionId: "A", sensorId: "S1", sensorType: "insect",      │
│     │              massifIds: [1,2,3], massifNames: ["一号","二号","三号"] },  │
│     │            { regionId: "B", sensorId: "S2", sensorType: "weather",     │
│     │              massifIds: [4,5,6], massifNames: ["四号","五号","六号"] },  │
│     │            { regionId: "C", sensorId: "S3", sensorType: "soil",        │
│     │              massifIds: [7,8,9], massifNames: ["七号","八号","九号"] },  │
│     │          ]                                                              │
│     │ 步骤4: computeManagementZones(toolResults, spatialRegions)              │
│     │        → FCM 聚类: PCA 降维 3 个主成分 → 模糊C均值 → 最优分区数 = 3       │
│     │        → managementZones: [                                             │
│     │            { zoneId: "low_wet", label: "低湿区", massifIds: [1,2,3],    │
│     │              summary: "虫情↑+15%, 土墒78%, 本周降雨45mm" },              │
│     │            { zoneId: "high_dry", label: "高燥区", massifIds: [4,5,6],   │
│     │              summary: "虫情→, 土墒42%, 正常" },                          │
│     │            { zoneId: "transition", label: "过渡区", massifIds: [7,8,9], │
│     │              summary: "虫情→, 土墒55%, 正常" },                          │
│     │          ]                                                              │
│     │ 输出: state.spatialRegions, state.managementZones                       │
│     │ 数据完整性保证: 三个字段（toolResults + spatialRegions + managementZones）│
│     │   全部非空才进入下一节点，任一项缺失 → 降级路径                            │
│                                                                              │
│  ⑥ ★ summaryRetrieval (★新增节点) ★                                           │
│     │ 角色: 领域知识代理检索 — deep 图无 fan-out，不能触发领域专家各自的        │
│     │       per-expert retrieval。本节点用宽泛 filter 做一次 ChromaDB 检索，    │
│     │       替领域专家（pest_risk/weather/soil）补齐本该通过 fan-out RAG 获取   │
│     │       的方法论/标准/历史案例知识。                                       │
│     │ 检索: ChromaDB 全类目检索（报告模板 + 农事标准 + 四情方法论）             │
│     │        → 5-10 条相关文档                                                │
│     │ 输出: 追加到 evidenceChain 末尾                                           │
│                                                                              │
│  ⑦ ★ summaryReasoning (★新增节点) ★                                           │
│     │ 验证: spatialRegions? managementZones? toolResults? → 全部非空 ✓        │
│     │ 构建: buildSpatialContextSection(managementZones, toolResults)          │
│     │       → "当前农场划分为 3 个管理分区：                                     │
│     │          低湿区 [地块1,2,3]: 虫情↑+15%, 土墒偏高78%, 本周多雨              │
│     │          高燥区 [地块4,5,6]: 虫情→, 土墒偏低42%, 正常                     │
│     │          过渡区 [地块7,8,9]: 虫情→, 土墒55%, 正常"                        │
│     │ 推理: 汇总专家 prompt → 单 LLM invoke → verdictResult                    │
│     │ 输出: 含 per-zone 分析结论的 verdictResult                               │
│                                                                              │
│  ⑧ interactionPointDetection → verdict → response                            │
│     │ responseNode: buildRegionSummary(managementZones, toolResults)          │
│     │ → "低湿区: 虫情 200条↑ | 土墒 150条 78% | 风险: 虫害+渍涝"               │
│     │ → "高燥区: 虫情 80条→ | 土墒 100条 42% | 风险: 干旱"                     │
│     │ → "过渡区: 虫情 60条→ | 土墒 80条 55% | 风险: 低"                        │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 professional 图：多专家并行分析（数据流不变）

professional 图的数据流与本 Plan 无关——per-expert-reasoning 仅消费 toolResults 结构化数据替代全量 JSON，暂不注入空间上下文。图拓扑和数据流不变。详见 §3.0.2。

---

## 五、Prompt 工程

### 5.1 reasoning.ts 空间推理 section

**新增 buildSpatialContextSection() 函数**：

```typescript
// src/agents/prompts/reasoning.ts 新增

function buildSpatialContextSection(
  regions: VoronoiRegion[],
  toolResults: ToolResult[]
): string {
  if (!regions || regions.length === 0) return ""

  const regionSummaries = aggregateToolResults(toolResults, regions)
  const lines: string[] = []

  lines.push("[空间推理上下文]")
  lines.push(`当前农场划分为 ${regionSummaries.length} 个区域（基于传感器 Voronoi 覆盖范围）：`)
  lines.push("")

  for (const rs of regionSummaries) {
    lines.push(`- ${rs.summaryText}`)
    lines.push("")
  }

  lines.push("[推理要求]")
  lines.push("1. 分析各区域的风险等级（高/中/低），给出判断依据")
  lines.push("2. 进行跨区域比较：解释不同区域数据差异的可能原因（地形、传感器覆盖、微气候等）")
  lines.push("3. 给出 per-region 的农事建议（优先处理高风险区域）")
  lines.push("4. 标记需要加强采样的重点区域（自适应采样建议）")
  lines.push("5. 如果存在四情（墒情×虫情×气象×农事）联动信号，请综合分析")

  return lines.join("\n")
}
```

**reasoningPrompt.build() 改造**：

```typescript
// 原 build() 签名不变，新增 spatialContext 可选参数
build(input: ReasoningInput): string {
  // ... 现有 evidenceList 构建逻辑 ...

  let prompt = `
你是一个专业的农场空间推理助手，运行在农场智能决策系统中。
以下是领域能力映射，帮助你理解用户问题背后的系统能力：

${buildDomainContext(input)}

你需要基于以下证据进行深度推理。

用户问题：${input.query}

证据列表：
${evidenceList}
`

  // ★ 新增：空间推理上下文
  if (input.spatialContext) {
    prompt += `\n\n${buildSpatialContextSection(input.spatialContext.regions, input.spatialContext.toolResults)}`
  }

  prompt += `
请严格按照以下格式输出推理过程和结论 JSON：
{
  "reasoning_path": [...],
  "traces": [...],
  "conclusion": { "content": "...", "actions": [...] },
  "confidence": { "base_confidence": ..., "reliability_discount": ..., "conflict_discount": ..., "final_confidence": ... }
}
只返回 JSON。
`
  return prompt
}
```

### 5.2 factory.ts per-expert prompt 空间上下文注入

**ExpertPromptInput 扩展**：

```typescript
// src/agents/prompts/types.ts 新增

interface SpatialContext {
  regions: RegionSummary[]
}

interface RegionSummary {
  regionId: string
  plotCount: number
  totalRecordCount: number
  dominantTrend: "↑" | "→" | "↓"
  plotNames: string[]
  sensorType: string
  summaryText: string
}

// ExpertPromptInput 扩展
interface ExpertPromptInput {
  // ... 现有字段 ...
  spatialContext?: SpatialContext  // ★ 新增
}
```

**factory.ts build() 改造**：

```typescript
// src/agents/prompts/experts/factory.ts

build(input: ExpertPromptInput): string {
  const lines: string[] = []
  lines.push(`═══ ${config.name} ═══`)
  lines.push("")
  lines.push(config.systemPrompt)
  lines.push("")

  // ★ 新增：空间推理上下文（在领域触发词之前注入，确保 LLM 先看到空间结构）
  if (input.spatialContext && input.spatialContext.regions.length > 0) {
    lines.push("【空间上下文 — 当前农场区域划分】")
    lines.push(`当前专家 ${config.id} 负责分析以下 ${input.spatialContext.regions.length} 个区域：`)
    for (const region of input.spatialContext.regions) {
      lines.push(`- ${region.summaryText}`)
    }
    lines.push("请基于以上区域划分，对每个区域给出独立的分析结论。")
    lines.push("")
  }

  // ... 现有领域触发词、工具数据、证据、运行时参数等逻辑 ...

  return lines.join("\n")
}
```

### 5.3 两种图的 Prompt 差异

| 维度 | deep 图 reasoning.ts | professional 图 per-expert-reasoning.ts |
|------|---------------------|----------------------------------------|
| spatialContext 来源 | retrieval 节点末尾预计算，写入 state.spatialRegions | 同左（两个图共享 state） |
| 注入位置 | reasoningPrompt.build() 中作为独立 section | factory.ts build() 中作为 `[空间上下文]` 区块 |
| 注入内容 | 全农场所有区域的摘要 | 仅本 expert 相关的区域（根据 expert 的 realtimeToolNames 过滤） |
| 回退路径 | spatialRegions 为空时，section 不生成，行为与当前一致 | 同左 |

### 5.4 Prompt Token 预算分析

| 组件 | 当前 token 数（估算） | 改造后 token 数（估算） | 变化 |
|------|---------------------|----------------------|------|
| reasoningPrompt 基础模板 | ~200 | ~200 | 不变 |
| 领域触发词上下文 | ~100 | ~100 | 不变 |
| evidenceList (5 条 × 200 字符) | ~300 | ~300 | 不变 |
| 工具结果截断 (200 字符) | ~100 | — | 删除 |
| 空间推理上下文 (4 区域) | — | ~500 | 新增 |
| per-expert 工具结果聚合 | ~200 (全量 JSON) | ~400 (按区域聚合) | 增加但可控 |
| **总计** | **~900** | **~1500** | **+600 tokens** |

600 tokens 的增量在 LLM 上下文窗口（64K+）中完全可接受，且换来的是推理质量的阶跃提升。

---

## 六、上下游依赖

### 6.1 完整依赖链路

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              上游 (已完成)                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────────────────────────────┐                                   │
│  │ thinking-level-runtime-fix (07/04)    │                                   │
│  │ → professional 图路由可达              │                                   │
│  │ → 产出: thinkingLevel 正确路由到       │                                   │
│  │   professional 图                      │                                   │
│  └──────────────┬───────────────────────┘                                   │
│                 │                                                            │
│                 ▼                                                            │
│  ┌──────────────────────────────────────┐                                   │
│  │ project-massif-resolution (07/06)    │                                   │
│  │ → route 层注入 prebuiltMassifIds      │                                   │
│  │ → 产出: 全农场地块 ID 默认值           │                                   │
│  │ → 解决: 工具调用不缺参                 │                                   │
│  └──────────────┬───────────────────────┘                                   │
│                 │                                                            │
│                 ▼                                                            │
│  ┌──────────────────────────────────────┐                                   │
│  │ professional-fanout (07/06)          │                                   │
│  │ → Send API fan-out 并行              │                                   │
│  │ → 产出: per-expert 并行推理           │                                   │
│  │ → 解决: experts 之间可并行            │                                   │
│  └──────────────┬───────────────────────┘                                   │
│                 │                                                            │
├─────────────────┼──────────────────────────────────────────────────────────┤
│                 ▼                                                            │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │              ★ 本 Plan: spatial-reasoning ★                           │   │
│  │                                                                      │   │
│  │  第1轮: Voronoi 空间计算 (spatial/voronoi.ts 新建)                     │   │
│  │  第2轮: 工具结果结构化聚合 (farm-data-tools 改造 + reasoning 改造)     │   │
│  │  第3轮: Prompt 工程 (reasoning 模板 + factory 改造 + types 扩展)      │   │
│  │  第4轮: Response 装订 + CognitiveEventBus + retrieval 预计算          │   │
│  │  第5轮: tsc + eslint 零错误验证                                       │   │
│  │                                                                      │   │
│  │  产出:                                                                │   │
│  │  - Voronoi 空间计算层，9 地块 → 3-4 区域                              │   │
│  │  - 工具结果不截断，按区域聚合统计                                      │   │
│  │  - LLM 拿到空间推理上下文，能做跨区域比较                              │   │
│  │  - CognitiveEventBus 感知 fan-out 进度                                │   │
│  │  - Response 按区域分组展示                                             │   │
│  └──────────────┬───────────────────────────────────────────────────────┘   │
│                 │                                                            │
│                 ▼                                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                              下游 (后续)                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────────────────────────────┐                                   │
│  │ PolicyUpdateLoop 自适应采样策略       │                                   │
│  │ → 消费 spatialRegions 中高风险区域     │                                   │
│  │ → 自动调高重点区域采样频率             │                                   │
│  └──────────────────────────────────────┘                                   │
│                                                                             │
│  ┌──────────────────────────────────────┐                                   │
│  │ GUI 端区域可视化                      │                                   │
│  │ → 消费 spatialRegions 多边形           │                                   │
│  │ → 渲染农场地图 + Voronoi 热力图         │                                   │
│  └──────────────────────────────────────┘                                   │
│                                                                             │
│  ┌──────────────────────────────────────┐                                   │
│  │ 四情融合研判 (墒情×虫情×气象×农事)      │                                   │
│  │ → 消费 multi-tool 聚合结果             │                                   │
│  │ → 跨数据源交叉分析                     │                                   │
│  └──────────────────────────────────────┘                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 6.2 关键依赖关系

| 依赖方 | 被依赖方 | 依赖内容 | 阻断风险 |
|--------|---------|---------|---------|
| spatial/voronoi.ts | Farm-Server /massif/options API | 获取地块 graphicDrawing 坐标 | API 不可用时回退为空 spatialRegions |
| spatial/voronoi.ts | Farm-Server /equipment/page API | 获取传感器坐标 | 无传感器时每个地块独立成区域 |
| reasoning.ts 改造 | state.spatialRegions | 消费 Voronoi 计算结果 | spatialRegions 为空时回退现有逻辑 |
| per-expert-reasoning.ts 改造 | state.toolResults | 消费结构化数据替代全量 JSON | toolResults 为空时原样传给 prompt（空工具数据段），不降级回读 ToolMessage |
| response.ts 改造 | state.spatialRegions + state.toolResults | 按区域分组展示 | 同上 |
| factory.ts 改造 | ExpertPromptInput.spatialContext | 注入专家 prompt | 为 undefined 时行为不变 |

**降级策略**：所有改造都有回退路径。当 `spatialRegions` 为空时（API 不可用、无传感器等），行为与当前完全一致。这是嵌入式路径演化的核心原则：新能力在已有路径内增强，不新增节点或路由，失败时静默降级。

---

## 七、工具结果的不裁切、全量处理

### 7.1 当前裁切点分析

在代码中有**两处**导致数据不完整的关键裁切点：

**裁切点 1: reasoning.ts L108-118（deep 图）**

```typescript
// 当前代码
const summaries = toolMessages.map((tm) => {
  const toolName = tm.name || "unknown"
  const contentStr = typeof tm.content === "string" ? tm.content : JSON.stringify(tm.content)
  return `[工具: ${toolName}] ${contentStr.slice(0, 200)}`  // ← 硬截断 200 字符
})
```

**问题**：`contentStr` 是 ToolMessage 的完整 JSON 字符串（可能包含 200 条记录），`slice(0, 200)` 只取了 JSON 的前 200 个字符——通常只包含第一条记录的 massifName 和 dataTime 字段，后面的记录全部丢失。

**裁切点 2: per-expert-reasoning.ts L62-67（professional 图）**

```typescript
// 当前代码
const toolResults = toolMessages
  .filter(tm => toolNames.includes(tm.name || ""))
  .map(tm => ({
    toolName: tm.name || "unknown",
    content: typeof tm.content === "string" ? tm.content : JSON.stringify(tm.content),
    // ← 没有截断，但注入的是全量 JSON 字符串，信息过载
  }))
```

**问题**：虽然没有截断，但全量 JSON 注入 prompt 导致 LLM 注意力退化。200 条记录 × 10 字段 = 5000+ tokens 原始数据，LLM 无法有效处理。

### 7.2 改造方案：不裁切，全量处理，但聚合后注入

**核心思路**：不裁切任何数据，但也不把原始数据直接喂给 LLM。而是在代码层做聚合，LLM 拿到的是聚合后的结构化摘要。

```
改造前:
  ToolMessage 全量 JSON (10000+ 字符)
    → slice(0, 200) 或 全量注入
    → LLM 看到碎片或被淹没

改造后:
  state.toolResults[].list (200 条完整记录)
    → 代码层聚合 (aggregateToolResults)
    → 产出 RegionSummary[] (每个区域 ≤ 500 tokens)
    → LLM 看到结构化摘要，信息密度高
```

**改造后的 reasoning.ts（deep 图）**：

```typescript
// 改造后代码
const toolResultsBlock = buildSpatialContextSection(
  state.spatialRegions,
  state.toolResults
)
// toolResultsBlock 现在是按区域聚合的摘要，不再是 200 字符碎片
```

**改造后的 per-expert-reasoning.ts（professional 图）**：

```typescript
// 改造后代码
const spatialCtx = buildSpatialContext(state.toolResults, state.spatialRegions)
const prompt = promptTemplate.build({
  query,
  evidences: pkg.evidences,
  toolResults,  // 保留原始 toolResults 供 factory.ts 内部使用
  runtimeInputs: pkg.runtimeInputs,
  spatialContext: spatialCtx,  // ★ 新增：空间上下文
})
```

### 7.3 全量数据处理的数据量分析

| 场景 | 地块数 | 虫情记录数 | 土墒记录数 | 气象记录数 | 原始数据量 | 聚合后 token 数 |
|------|:---:|:---:|:---:|:---:|------|:---:|
| 小农场 | 3 | 60 | 45 | 21 | ~3000 chars | ~400 tokens |
| 中农场 | 9 | 200 | 150 | 63 | ~12000 chars | ~800 tokens |
| 大农场 | 20 | 500 | 400 | 140 | ~30000 chars | ~1500 tokens |

聚合后的 token 数始终控制在 2000 以内，即使在 20 个地块的大农场场景下也不会超预算。

---

## 八、模型响应过程的数据装订过程

### 8.1 数据装订的定义

"数据装订"是指从**原始工具结果**到**最终用户可见的响应**的完整转换链路。这个链路包含：

1. **采集层**：toolNode 执行 → Farm-Server 返回原始数据
2. **契约层**：ToolMessage → state.toolResults（结构化契约）
3. **聚合层**：toolResults[].list → 按地块分组 → 按区域归并 → RegionSummary[]
4. **注入层**：RegionSummary[] → prompt 文本 → LLM 推理
5. **展示层**：推理结果 + toolResults → responseNode 构建展示内容

### 8.2 完整装订链路

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    模型响应数据装订完整链路                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Layer 1: 采集层 (toolNode)                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ toolNode 执行 query_insect_data(massifId=undefined)                  │    │
│  │   → Farm-Server /insect-data/page?projectId=X&pageSize=200          │    │
│  │   → 返回: { code: 0, data: { total: 200, list: [...] } }           │    │
│  │   → tool 返回: { success: true, total: 200, list: [...], columns }  │    │
│  │                                                                     │    │
│  │ 审计: TOOL_INVOKED + TOOL_COMPLETED                                  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                        │
│                                    ▼                                        │
│  Layer 2: 契约层 (state.toolResults)                                         │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ toolNode 写入 state.toolResults:                                     │    │
│  │ [{                                                                   │    │
│  │   toolName: "query_insect_data",                                    │    │
│  │   success: true,                                                     │    │
│  │   recordCount: 200,                                                  │    │
│  │   list: [200 条完整记录],                                             │    │
│  │   columns: [{ prop: "massifName", label: "地块" }, ...]              │    │
│  │ }]                                                                   │    │
│  │                                                                     │    │
│  │ 治理来源: toolresults-contract Plan (2026-06-23)                      │    │
│  │ 消费方: reasoning 节点 + response 节点                                │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                        │
│                                    ▼                                        │
│  Layer 3: 聚合层 (aggregateToolResults)  ★本Plan新增★                       │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ 输入: state.toolResults[].list (200 条原始记录)                        │    │
│  │       + state.spatialRegions (Voronoi 区域划分)                       │    │
│  │                                                                     │    │
│  │ 处理:                                                                │    │
│  │   1. 按 massifName 分组 → 每个地块的 recordCount + trend            │    │
│  │   2. 按 spatialRegion 归并 → 区域级统计                              │    │
│  │   3. 生成自然语言摘要 → summaryText                                  │    │
│  │                                                                     │    │
│  │ 输出: SpatialContext {                                               │    │
│  │   regions: [{                                                        │    │
│  │     regionId: "A",                                                  │    │
│  │     plotCount: 3,                                                    │    │
│  │     dominantTrend: "↑",                                             │    │
│  │     summaryText: "区域 A [低洼区]: 3 地块，虫害↑+15%，2 类害虫"       │    │
│  │   }, ...]                                                            │    │
│  │ }                                                                    │    │
│  │                                                                     │    │
│  │ 审计: SPATIAL_AGGREGATE (regionCount, plotCount, totalRecords)       │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                        │
│                                    ▼                                        │
│  Layer 4: 注入层 (Prompt 构建)                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ reasoning.ts: buildSpatialContextSection()                            │    │
│  │   → 将 SpatialContext 转为 prompt 文本                                │    │
│  │                                                                     │    │
│  │ factory.ts: build() 注入 spatialContext                              │    │
│  │   → 在 per-expert prompt 中添加 [空间上下文] 区块                      │    │
│  │                                                                     │    │
│  │ LLM 最终看到的 prompt:                                                │    │
│  │   "═══ 虫害风险评估 ═══                                                │    │
│  │    [空间上下文]                                                       │    │
│  │    当前农场划分为 2 个区域：                                            │    │
│  │    - 区域 A [虫情传感器 S1 覆盖]: 3 地块，虫害↑+15%                    │    │
│  │    - 区域 B [气象传感器 S2 覆盖]: 2 地块，正常                          │    │
│  │    [推理要求] 1. 分析各区域风险等级 2. 跨区域比较 ..."                  │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                        │
│                                    ▼                                        │
│  Layer 5: 展示层 (responseNode)                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ buildRegionSummary(spatialRegions, toolResults):                     │    │
│  │   → 消费 state.toolResults 结构化数据                                 │    │
│  │   → 消费 state.spatialRegions 区域划分                                │    │
│  │   → 产出 toolExecutionSummary (含 regionBreakdown)                   │    │
│  │                                                                     │    │
│  │ 最终 responseNode 输出:                                               │    │
│  │   displayContent.sections:                                           │    │
│  │     [                                                                │    │
│  │       { type: "conclusion", title: "回复",                           │    │
│  │         content: "区域 A 虫害风险高（+15%），建议立即喷洒农药..." },     │    │
│  │       { type: "evidence", title: "区域分析",                          │    │
│  │         content: "区域 A: 虫情 200条↑ | 土墒 150条 78%湿\n           │    │
│  │                   区域 B: 虫情 80条→ | 土墒 100条 42%湿" },          │    │
│  │       { type: "reasoning", title: "推理路径", ... },                 │    │
│  │       { type: "confidence", title: "置信度", ... },                  │    │
│  │     ]                                                                │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 8.3 装订过程中的数据保真度

| 阶段 | 数据形态 | 保真度 | 说明 |
|------|---------|:---:|------|
| 采集层 | 200 条原始记录，每条约 10 字段 | 100% | Farm-Server 原始数据 |
| 契约层 | `state.toolResults` 结构化数组 | 100% | 完整传递，无丢失 |
| 聚合层 | `RegionSummary[]` 区域级摘要 | ~95% | 丢失了逐记录粒度，保留了统计趋势 |
| 注入层 | Prompt 文本（~800 tokens） | ~90% | 文本化过程中丢失了数值精度（保留 2 位有效数字） |
| LLM 推理 | 推理结论 + 置信度 | ~80% | LLM 理解偏差，但输入信息完整 |
| 展示层 | displayContent.sections | ~85% | 前端渲染时截断长文本（保留 100 字符摘要） |

**保真度设计原则**：前两层 100% 保真（原始数据可审计），聚合层 95% 保真（统计信息完整），注入层 90% 保真（文本化有损但语义完整），LLM 推理 80%+ 保真（受模型能力限制）。每次降级都有明确的边界和审计记录。

---

## 九、实施 Task + 依赖图

```
轮次 1: 空间计算层
  ├── Task 1.1: 空间类型定义（新建 spatial/types.ts）
  │     │  产出类型接口 → 被 1.2/1.3/1.4/1.5/4.3 消费
  │     ▼
  ├── Task 1.2: Voronoi 图计算（新建 spatial/voronoi.ts）
  ├── Task 1.3: FCM 管理分区聚类（新建 spatial/fcm.ts）
  ├── Task 1.4: state 新增空间字段（改造 state.ts）
  └── Task 1.5: 坐标转换工具（新建 spatial/coordinate-transform.ts）
        │  1.2/1.3/1.4/1.5 可并行
        ▼
轮次 2: spatialPreprocessing 节点
  └── Task 2.1: 空间预处理节点（新建 spatial-preprocessing.ts）
        │  消费 1.2 voronoi + 1.3 fcm + 1.4 state 字段
        │  产出 state.spatialRegions + state.managementZones → 被 3.2/4.2/5.2 消费
        ▼
轮次 3: 领域知识代理检索 + 汇总专家推理
  ├── Task 3.1: 领域知识代理检索（新建 summary-retrieval.ts）
  │     │  角色：替领域专家（pest_risk/weather/soil）补齐 deep 图无法 fan-out 的 RAG 知识
  │     │  产出 evidenceChain 追加 → 被 3.2 消费
  │     ▼
  └── Task 3.2: 汇总专家推理（新建 summary-reasoning.ts）
        │  消费 2.1 的 spatialRegions/managementZones + 3.1 的 evidenceChain
        │  产出 verdictResult → 被 response 消费
        ▼
轮次 4: 现有推理改造 + Graph 接入
  ├── Task 4.1: deep 图 reasoning 去截断（改造 reasoning.ts）
  ├── Task 4.2: per-expert 消数据（改造 per-expert-reasoning.ts）
  ├── Task 4.3: Prompt 类型扩展（改造 prompts/types.ts）
  │     │  4.1/4.2/4.3 可并行
  │     ▼
  └── Task 4.4: deep 图新增 3 节点 + 条件边（改造 agent-graph.ts）
        │  依赖 2.1 + 3.1 + 3.2 的文件存在
        ▼
轮次 5: Prompt 装订 + Response 装订 + EventBus
  ├── Task 5.1: factory.ts 注入空间上下文（改造 prompts/experts/factory.ts）
  │     │  依赖 4.3 的 SpatialContext 类型
  ├── Task 5.2: response.ts 区域分组展示 + isSummary 分支（改造 response.ts）
  │     │  消费 2.1 的 managementZones
  └── Task 5.3: EventBus 新增 fanout 事件（改造 cognitive-event-bus + send-api + kb-conflict）
        │  5.1/5.2/5.3 可并行
        ▼
轮次 6: 编译 + Lint + 手动验证
  ├── Task 6.1: tsc --noEmit 零错误
  ├── Task 6.2: eslint src/ 零 error
  └── Task 6.3: 手动验证（回退路径 + 数据完整性 + 端到端）
```

### 轮次 1: 空间计算层

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 1.1 | 空间类型定义 | `src/lib/spatial/types.ts`（新建） | 定义 `VoronoiRegion` / `SensorInfo` / `PlotInfo` / `ManagementZone` / `SpatialContext` 五个接口；导出给 1.2/1.3/1.4/4.3 使用 | `tsc --noEmit` |
| 1.2 | Voronoi 图计算 | `src/lib/spatial/voronoi.ts`（新建） | 安装 `d3-delaunay`；实现 `computeVoronoiRegions()` / `parseGraphicDrawing()` / `computeCentroid()` / `assignPlotToRegion()`；基于 Delaunay 三角剖分 + Fortune's Algorithm 计算传感器 Voronoi cell，按地块重心判定归属 | `tsc --noEmit` + 3 传感器 × 9 地块 → 3 区域 |
| 1.3 | FCM 管理分区聚类 | `src/lib/spatial/fcm.ts`（新建） | 实现 `computeManagementZones()`：多源数据矩阵提取 → PCA 降维 → 模糊C均值聚类 → 最优分区数判定 → 输出 `ManagementZone[]`；纯函数不依赖 LLM | `tsc --noEmit` + 200 条记录 → 3 个分区 |
| 1.4 | state 新增空间字段 | `src/agents/state.ts` | 新增 `spatialRegions: Annotation<VoronoiRegion[] \| null>()` + `managementZones: Annotation<ManagementZone[] \| null>()`；import 1.1 的类型 | `tsc --noEmit` |
| 1.5 | 坐标转换工具 | `src/lib/spatial/coordinate-transform.ts`（新建） | 导出声明的 CGCS2000 → WGS-84 转换函数 `cgcs2000ToWgs84(lat, lng): { lat, lng }`；内部使用 Helmert 七参数或简化的三参数模型；偏差 < 1m 时恒等返回（即默认跳过转换），调用方按需开启精确模式 | `tsc --noEmit` + 输入/输出偏差 < 1e-6 |

### 轮次 2: spatialPreprocessing 节点

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 2.1 | 空间预处理节点 | `src/agents/nodes/spatial-preprocessing.ts`（新建） | 统一数据入口，编排 Voronoi + FCM 计算。输入 `state.toolResults` + `prebuiltMassifIds` + `projectId`；步骤1 调 Farm-Server /massif/options 获取 graphicDrawing 坐标；步骤2 调 /equipment/page 获取传感器坐标；步骤3 调 1.2 `computeVoronoiRegions()` → `state.spatialRegions`；步骤4 调 1.3 `computeManagementZones()` → `state.managementZones`；数据完整性校验三字段全非空，降级设 null 不阻塞管线；审计 `SPATIAL_PREPROCESS` | `tsc --noEmit` + 数据完整性三字段非空校验 |

### 轮次 3: 领域知识代理检索 + 汇总专家推理

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 3.1 | 领域知识代理检索 | `src/agents/nodes/summary-retrieval.ts`（新建） | **检索策略**：不硬编码 cateId——从当前汇总专家的 `summaryExpertIds`（如 weekly_report → ["weather_impact", "pest_risk"]）提取各专家的 `grounding.collectionName`，做跨 collection 联合 ChromaDB 检索（每 collection 3-5 条，总上限 10 条）；按相似度降序取 top 10 追加到 `evidenceChain` 末尾。`summaryExpertIds` 未配置时降级为取所有非 isSummary 且有 grounding 的专家；审计 `SUMMARY_RETRIEVAL` | `tsc --noEmit` + 检索命中 > 0 |
| 3.2 | 汇总专家推理 | `src/agents/nodes/summary-reasoning.ts`（新建） | 消费 2.1 的 `spatialRegions` + `managementZones` + 3.1 的 `evidenceChain` + `toolResults`；三字段完整性验证（任一项缺失 → 降级无空间模式）；`buildSpatialContextSection()` 产出空间推理上下文 section；汇总专家 prompt → 单 LLM invoke → `verdictResult`；不做 KB 冲突检测；审计 `SUMMARY_REASONING` | `tsc --noEmit` + 单测（三字段全非空 → 推理；任一缺失 → 降级） |

### 轮次 4: 现有推理改造 + Graph 接入

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 4.1 | deep 图 reasoning 去截断 | `src/agents/nodes/reasoning.ts` | 仅删除 L108-118 `contentStr.slice(0, 200)` 截断；改用 `state.toolResults` 结构化数据替代 `toolMessages` 字符串；不新增 `buildSpatialContext()`（由 3.2 独立负责）；`toolResults` 为空时回退现有逻辑 | `tsc --noEmit` + grep 确认 slice(0,200) 已删除 |
| 4.2 | per-expert 数据升级 | `src/agents/nodes/per-expert-reasoning.ts` | 改用 `state.toolResults` 结构化数据 → 按地块分组聚合；暂不消费 spatialRegions（仅 deep 图使用），后续根据周报效果评估 | `tsc --noEmit` |
| 4.3 | Prompt 类型扩展 | `src/agents/prompts/types.ts` | 新增 `SpatialContext` / `ManagementZone` 接口（从 1.1 re-export）；`ExpertPromptInput` 新增 `spatialContext?: SpatialContext` 字段 | `tsc --noEmit` |
| 4.4 | deep 图拓扑更新 | `src/agents/agent-graph.ts` | deep 图新增 3 节点注册：`spatialPreprocessing` / `summaryRetrieval` / `summaryReasoning`；新增条件边 `intention` → `spatialPreprocessing`；新增边 `spatialPreprocessing` → `summaryRetrieval` → `summaryReasoning` → `interactionPointDetection`；professional 图不变 | 图编译无异常 |

### 轮次 5: Prompt 装订 + Response 装订 + EventBus

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 5.1 | factory.ts 空间上下文注入 | `src/agents/prompts/experts/factory.ts` | `build()` 中注入 `[空间上下文]` 区块：遍历 `input.spatialContext.regions` → 输出 per-region 摘要文本 + 推理要求；在领域触发词之前注入确保 LLM 先看到空间结构 | `tsc --noEmit` + prompt 模板含 `[空间上下文]` 区块 |
| 5.2 | response.ts 区域分组展示 | `src/agents/nodes/response.ts` | ① 新增 `buildRegionSummary()` 消费 `managementZones` + `toolResults` → 按区域分组；② `toolExecutionSummary` 新增 `regionBreakdown?: string`；③ 新增 `isSummary` 分支：当 `expert.isSummary === true` 时消费 `expert.reportTemplate` 替代 `strategy.sections`，`buildStreamingTextPrompt` 使用汇总专家专用模板；改动 ~30 行 | `tsc --noEmit` |
| 5.3 | EventBus fanout 事件 | `src/agents/cognitive-event-bus.ts` + `src/lib/langgraph/send-api.ts` + `src/agents/nodes/kb-conflict-aggregator.ts` | `CognitiveEvent` 联合类型新增 `professional:fanout_started` / `professional:fanin_complete`；`routeByExpertPlan` 调用时 emit `fanout_started`；`kbConflictAggregator` 入口时 emit `fanin_complete` | `tsc --noEmit` |

### 轮次 6: 编译 + Lint + 手动验证

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 6.1 | TypeScript 编译 | 全局 | `npx tsc --noEmit` 零错误 | 零错误 |
| 6.2 | ESLint 检查 | 全局 | `npx eslint src/` 零 error | 零 error |
| 6.3 | 手动端到端验证 | 全局 | ① 9 地块 + 3 传感器 → 3 Voronoi 区域 + 3 FCM 分区；② 200 条虫情 → 按地块分组 → 按分区归并 → 区域级摘要；③ `reasoning.ts` 截断已删除；④ summaryReasoning 三字段完整性校验；⑤ 回退路径（spatialRegions 为空时行为一致） | 5 项全部通过 |
| 6.4 | 架构文档更新 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` | ① 新增 deep 图汇总专家路径（spatialPreprocessing → summaryRetrieval → summaryReasoning 三节点拓扑）；② 补充"deep 图（DAG 单路径纵向推理）vs professional 图（fan-out/fan-in 横向并行）范式差异"；③ 写明 summaryRetrieval 的存在原因：deep 图无 fan-out 拓扑，需通过统一检索节点代理领域专家的 RAG 知识贡献 | 文档更新完成 |

---

## 十、验收标准

- [ ] **Voronoi 计算正确性**：9 个地块 + 3 个传感器 → 3 个区域，每个地块正确归属于最近的传感器覆盖区域
- [ ] **FCM 管理分区**：基于多源数据（虫情/土墒/气象）聚类 → 3 个管理分区，分区内同质、分区间异质
- [ ] **spatialPreprocessing 数据完整性**：toolResults / spatialRegions / managementZones 三个字段全部非空
- [ ] **summaryReasoning 消费验证**：三个字段非空才推理，任一项缺失 → 降级为无空间模式
- [ ] **截断已删除**：`reasoning.ts` 中 `contentStr.slice(0, 200)` 已删除
- [ ] **LLM prompt 含空间推理上下文**：管理分区 + 传感器覆盖 + 四情联动数据
- [ ] **CognitiveEventBus**：`professional:fanout_started` 和 `professional:fanin_complete` 事件可被 GlobalState 订阅
- [ ] **Response 按区域展示**：`toolExecutionSummary` 新增 `regionBreakdown`，按管理分区分组展示
- [ ] **回退路径**：`spatialRegions` 为空时，行为与当前一致
- [ ] **零编译错误**：`npx tsc --noEmit` 零错误
- [ ] **零 lint error**：`npx eslint src/` 零 error

---

## 十一、涉及文件清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/lib/spatial/types.ts` | **新建** | VoronoiRegion / SensorInfo / PlotInfo / ManagementZone / SpatialContext 类型定义 |
| `src/lib/spatial/voronoi.ts` | **新建** | Voronoi 图计算（Fortune's Algorithm via d3-delaunay）+ 地块归属判定 |
| `src/lib/spatial/fcm.ts` | **新建** | FCM 聚类实现：PCA 降维 + 模糊C均值聚类 → 管理分区划分 |
| `src/lib/spatial/coordinate-transform.ts` | **新建** | CGCS2000 ↔ WGS-84 坐标转换工具函数，默认恒等（偏差 < 1m 跳过），按需精确转换 |
| `src/agents/nodes/spatial-preprocessing.ts` | **新建** | 空间预处理节点：统一数据入口，编排 Voronoi + FCM，纯代码逻辑 |
| `src/agents/nodes/summary-retrieval.ts` | **新建** | 领域知识代理检索：从 summaryExpertIds → grounding.collectionName 做跨 collection 联合检索 |
| `src/agents/nodes/summary-reasoning.ts` | **新建** | 汇总专家独立推理节点：消费 spatialRegions + managementZones → 全农场区域级 prompt |
| `src/agents/state.ts` | 修改 | 新增 `spatialRegions: Annotation<VoronoiRegion[] \| null>()` + `managementZones: Annotation<ManagementZone[] \| null>()` |
| `src/agents/agent-graph.ts` | 修改 | deep 图新增 3 节点注册 + 条件边；professional 图不变 |
| `src/agents/nodes/reasoning.ts` | 修改 | 仅删除 `contentStr.slice(0, 200)` 截断，改用 `state.toolResults` 结构化数据 |
| `src/agents/nodes/per-expert-reasoning.ts` | 修改 | 消费 state.toolResults 结构化数据 → 按地块分组聚合；暂不消费 spatialRegions |
| `src/agents/nodes/retrieval.ts` | **不变** | 空间预处理由 spatial-preprocessing.ts 独立负责 |
| `src/agents/nodes/response.ts` | 修改 | ① `regionBreakdown` 可选字段；② `isSummary` 分支：消费 `expert.reportTemplate` 章节定义替代 `strategy.sections`，使用汇总专家专用 prompt 模板 |
| `src/agents/prompts/reasoning.ts` | **不变** | `buildSpatialContextSection()` 由 summary-reasoning.ts 内部负责 |
| `src/agents/prompts/experts/factory.ts` | 修改 | `ExpertPromptInput` 新增 `spatialContext`；`build()` 注入 `[空间上下文]` 区块 |
| `src/agents/prompts/types.ts` | 修改 | 新增 `SpatialContext` / `ManagementZone` 接口 |
| `src/agents/cognitive-event-bus.ts` | 修改 | `CognitiveEvent` 联合类型新增 `professional:fanout_started` / `professional:fanin_complete` |
| `src/lib/langgraph/send-api.ts` | 修改 | `routeByExpertPlan` 调用时 emit `professional:fanout_started` |
| `src/agents/nodes/kb-conflict-aggregator.ts` | 修改 | 入口时 emit `professional:fanin_complete` |
| `src/agents/experts/registry.ts` | **修改** | ① 新增 `EXPERT_IDS` as const 数组 + `ExpertId` 类型；② `AnalysisExpert` 新增 `summaryExpertIds?: ExpertId[]` 字段 |
| `src/config/chroma-config.ts` | **修改** | 新增 `SUMMARY_RETRIEVAL_CONFIG`（PER_COLLECTION_LIMIT / TOTAL_LIMIT），summaryRetrievalNode 检索参数集中管理 |
| `src/agents/experts/configs/weekly-report.config.ts` | **修改** | 新增 `summaryExpertIds: ["weather_impact", "pest_risk"]` |
| `src/agents/experts/configs/daily-report.config.ts` | **修改** | 新增 `summaryExpertIds: ["weather_impact", "pest_risk"]` |
| `package.json` | 修改 | 新增依赖 `d3-delaunay` |
| `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` | **修改** | 新增 deep 图汇总专家路径（含 spatialPreprocessing + summaryRetrieval + summaryReasoning 三节点拓扑），补充"deep 图 vs professional 图范式差异"说明：deep 图是 DAG 单路径纵向推理，professional 图是 fan-out/fan-in 横向并行；summaryRetrieval 的存在原因是 deep 图无 fan-out 拓扑，需通过统一检索节点代理领域专家的 RAG 知识贡献 |

---

## 十二、关联文档

| 文档 | 路径 |
|------|------|
| 前置 Plan（project-massif-resolution） | `.qoder/plans/2026-07/06/farm-agent-project-massif-resolution-plan-v1.md` |
| 前置 Plan（professional-fanout） | `.qoder/plans/2026-07/06/farm-agent-professional-fanout-plan-v1.md` |
| 前置 Plan（thinking-level-runtime-fix） | `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md` |
| 前置 Plan（toolresults-contract） | `.qoder/plans/2026-06/23/farm-agent-toolresults-contract-add-route-v1.md` |
| ADD Route | `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-add-route-v1.md` |
| Spec | `.qoder/specs/farm-agent-spatial-reasoning/spec.md` |
| Tasks | `.qoder/specs/farm-agent-spatial-reasoning/tasks.md` |
| Checklist | `.qoder/specs/farm-agent-spatial-reasoning/checklist.md` |
| Farm-Server API 文档 | `docs/大田精准耕播智能决策系统/knowledge/02-规范/Farm-Server API接口文档（自动生成）.md` |
| 决策管线架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` |
| 技术架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统技术架构说明书》.md` |
| Handoff | `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-handoff-v1.md`（Step 8 收敛后生成） |
| Review | `.qoder/reviews/farm-agent-spatial-reasoning-review-v2.md` |
