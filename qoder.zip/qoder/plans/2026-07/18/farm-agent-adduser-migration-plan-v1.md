# farm-agent-adduser-migration-plan-v1

> 精简版 Plan 模板：适用于单一聚焦改动（配置收敛、重构、修复等）。Tasks 合并于 Plan 体，无需独立 spec 文件。

**创建时间**: 2026-07-18T09:30:00+08:00
**主导 AI**: Qoder

---

## 一、Plan 概述

- **现状**: `prisma/add.prisma` 中的 `AddUser` 模型与 farm-agent 现有 `prisma/main.prisma` 冲突——`AuditLog` 和 `DevOperation` 在两个文件中重复定义，且 `userId` FK 指向不同的用户模型（main.prisma 指向 `User`，add.prisma 指向 `AddUser`）。add-coder MCP 工具链使用 `prisma.addUser` 查找/创建系统用户，但当前 `DevOperation.userId` 指向 `User` 表，FK 验证失败。

- **目标**: 将 `DevOperation` / `AuditLog` 的 `user` 关系从 `User` 迁移到 `AddUser`，与 add-coder 标准对齐。存量数据零丢失——`DevOperation`（2365 条）+ `AuditLog`（42062 条）的 `userId` 字段值不变（仍为 `"ai-assistant"`），仅更换 FK 目标表。

- **核心原则**: 存量数据零丢失；userId 值不变仅换 FK 目标表；与 add-coder 标准对齐；先备份再操作。

---

## 二、变更范围

### 2.1 涉及文件

| 文件 | 改动类型 | 说明 |
|------|---------|------|
| `prisma/main.prisma` | 修改 | `AuditLog.user` 和 `DevOperation.user` 的 `@relation` 从 `User` 改 `AddUser`；删除 `User.audits` / `User.devOps` |
| `prisma/add.prisma` | 修改 | 替换为完整版（含反向关系 `DevOperation[]`、`AuditLog[]`），与 add-coder 模板对齐 |
| `src/lib/log-user.ts` | 修改 | `prisma.user.upsert` → `prisma.addUser.upsert`，去掉 `password` 字段 |
| `src/lib/log/audit.ts` | 无代码改动 | 不改签名，但实际 userId 变为 AddUser.id（FK 目标表变更） |
| `.qoder/scripts/mcp-server.ts` | 无需修改 | 已使用 `prisma.addUser` |
| `.qoder_backup/plans/*` / `specs/*` | NO_CHANGE | 历史文档，不参与迁移 |

### 2.2 关键设计决策

1. **userId 值不变策略**：`DevOperation` 和 `AuditLog` 的 `userId` 全部为 `"ai-assistant"`（cuid 字符串），更换 FK 目标表从 `User` 到 `AddUser` 时无需 UPDATE 任何行，只需在 `AddUser` 表预置同名用户。
2. **先备份再迁移**：Task 1 必须执行 `db-backup.sh`，作为整个迁移的前置步骤。
3. **反向关系从 User 迁移到 AddUser**：`User.devOps[]` / `User.audits[]` 删除，`AddUser` 新增 `devOperations[]` / `auditLogs[]`。
4. **不受影响模块零改动**：`credential-store.ts`、`audit.ts`（通过 `getLogUserId()` 间接引用）、`services/*`、`api/**`、`scripts/*` 均不直接操作 AuditLog/DevOperation，无需修改。

### 2.3 存量数据

```
DevOperation: 2365 行   ─┐
AuditLog:    42062 行   ─┼─ userId 全部为 "ai-assistant"
                         ─┘
User 表 ai-assistant: id="ai-assistant", email="ai-assistant@internal"
```

---

## 三、Tasks（合并在 Plan 中，无需独立 spec/tasks.md）

> 单轮 Plan，Task 扁平排列无需分组。依赖关系见 §4.6 执行 Task 摘要。

- [ ] Task 1: 数据库备份
  - [ ] `bash scripts/db-backup.sh`
  - [ ] 验收: 确认 `${BACKUP_DIR}/farm-agent-*.sql.gz` 文件存在且非空
- [ ] Task 2: SQL 迁移（创建 AddUser + 切 FK）
  - [ ] `podman exec farm-agent-postgres psql -U farm_admin -d farm_agent -c "INSERT INTO \"AddUser\" (id, username, email) VALUES ('ai-assistant', 'ai-assistant', 'ai-assistant@internal');"`
  - [ ] `podman exec farm-agent-postgres psql -U farm_admin -d farm_agent -c "ALTER TABLE \"DevOperation\" DROP CONSTRAINT IF EXISTS \"DevOperation_userId_fkey\";"`
  - [ ] `podman exec farm-agent-postgres psql -U farm_admin -d farm_agent -c "ALTER TABLE \"AuditLog\" DROP CONSTRAINT IF EXISTS \"AuditLog_userId_fkey\";"`
  - [ ] 验收: `SELECT COUNT(*) FROM "AddUser"` = 1；`DevOperation` / `AuditLog` 数据仍存在
- [ ] Task 3: 更新 Prisma Schema + db push
  - [ ] 修改 `prisma/main.prisma`：`AuditLog.user` 和 `DevOperation.user` 的 `@relation` 从 `User` 改 `AddUser`；删除 `User.audits` / `User.devOps`
  - [ ] 修改 `prisma/add.prisma`：替换为完整版（含 `DevOperation[]`、`AuditLog[]` 反向关系）
  - [ ] `pnpm exec prisma db push --schema=prisma/`（遇到 checkpoint 表警告按 y）
  - [ ] 验收: `prisma db push` 成功；`prisma generate` 成功；`npx next build --webpack` 编译通过
- [ ] Task 4: 更新 `src/lib/log-user.ts`
  - [ ] `prisma.user.upsert` → `prisma.addUser.upsert`，去掉 `password` 字段
  - [ ] 验收: `tsx --env-file=.env.development scripts/startup-farm-service-login.ts` 成功登录 + AuditLog 写入
- [ ] Task 5: 回迁历史数据
  - [ ] `cp -rn .qoder_backup/plans/* .qoder/plans/ && cp -rn .qoder_backup/specs/* .qoder/specs/ && cp -rn .qoder_backup/reviews .qoder/reviews && cp -rn .qoder_backup/reports/farm-agent-runtime-report .qoder/reports/`
  - [ ] 验收: `ls .qoder/plans/2026-06/` 有内容
- [ ] Task 6: 端到端验证
  - [ ] `pnpm dev` 全链路启动
  - [ ] 验收: ChromaDB ✅ / Prisma migrate ✅ / startup-farm-service-login ✅ / Next.js dev server 启动无报错 / 浏览器 http://localhost:3000 可访问

---

## 四、Handoff

> 与独立 `handoff-single-round-template.md` 结构一致。

### 4.1 交接前状态

`prisma/main.prisma` 中 `User` 模型包含 `password`、`role` 等业务字段，`DevOperation` 和 `AuditLog` 的 `userId` FK 指向 `User` 表。`prisma/add.prisma` 中的 `AddUser` 模型（仅 id/username/email）与 `DevOperation`/`AuditLog` 无反向关系。add-coder MCP 工具链期望 `record_dev_operation` 通过 `prisma.addUser` 查找系统用户，但当前 FK 指向 `User` 表导致验证失败。

存量数据：`DevOperation` 2365 条，`AuditLog` 42062 条，userId 全部为 `"ai-assistant"`。

### 4.2 交接后状态（目标）

`DevOperation.userId` 和 `AuditLog.userId` 的 FK 指向 `AddUser` 表。`AddUser` 表预置 `ai-assistant` 用户（id 与原来 `User` 表中的 `ai-assistant` 一致）。`AddUser` 包含完整的反向关系（`DevOperation[]`、`AuditLog[]`）。`User` 表不再包含 `devOps[]` / `audits[]` 反向关系。`src/lib/log-user.ts` 使用 `prisma.addUser.upsert`。存量数据 userId 值不变（仍为 `"ai-assistant"`），零数据丢失。

### 4.3 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `prisma/main.prisma` | 修改 | `AuditLog.user` 和 `DevOperation.user` 的 `@relation` 从 `User` 改 `AddUser`；删除 `User.devOps[]` / `User.audits[]` |
| 2 | `prisma/add.prisma` | 修改 | 替换为完整版 AddUser（含 `DevOperation[]`、`AuditLog[]` 反向关系） |
| 3 | `src/lib/log-user.ts` | 修改 | `prisma.user.upsert` → `prisma.addUser.upsert`，去掉 `password` 字段 |
| 4 | `AddUser` 表（数据库） | 新建行 | INSERT `ai-assistant` 用户（id/username/email） |
| 5 | `.qoder/plans/` / `specs/` / `reports/` / `reviews/` | 回迁 | 从 `.qoder_backup/` 恢复历史 ADD 文档 |

### 4.4 回滚方案

```sql
-- Step 1: 删除新 FK（AddUser 表）
ALTER TABLE "DevOperation" DROP CONSTRAINT IF EXISTS "DevOperation_userId_fkey";
ALTER TABLE "AuditLog"  DROP CONSTRAINT IF EXISTS "AuditLog_userId_fkey";

-- Step 2: 恢复 Prisma schema → prisma db push 创建旧 FK（User 表）
-- 即反向修改 prisma/main.prisma 和 prisma/add.prisma

-- Step 3: 删除 AddUser 行
DELETE FROM "AddUser" WHERE id = 'ai-assistant';
```

或直接 `git reset --hard <pre-migration-commit>` + `prisma db push`。

### 4.5 执行前置检查

- [ ] `npx tsc --noEmit` 当前无错误（或已知错误与本变更无关）
- [ ] `podman ps` 确认 farm-agent-postgres 容器运行中
- [ ] `scripts/db-backup.sh` 可执行（`chmod +x` 如需要）
- [ ] `AddUser` 表当前为空（`SELECT COUNT(*) FROM "AddUser"` = 0），避免 id 冲突

### 4.6 执行 Task 摘要

```text
Task 1 (备份)
    │
    ▼
Task 2 (SQL 迁移：创建 AddUser + 切 FK)
    │
    ▼
Task 3 (Schema + db push)
    │
    ▼
Task 4 (log-user.ts)
    │
    ▼
Task 5 (回迁历史)
    │
    ▼
Task 6 (端到端验证)
```

### 4.7 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| `db-backup.sh` 未执行 | 无法回滚 | Task 1 必须首先执行并验收 |
| `AddUser` 插入失败（id 冲突） | 迁移中断 | 前置检查确认表为空，新表默认空 |
| DROP FK 时表被锁 | 迁移等待 | 本地开发环境，无并发 |
| `prisma db push` 再次提示 drop checkpoint 表 | 需确认 | 已知行为，按 y 跳过 |

### 4.8 恢复上下文审计查询（新 AI Session 首次启动必读）

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用，AI 助手在自己的对话中**直接复制粘贴这些参数调用工具即可**，不需要写 SQL。共 4 条审计记录可恢复完整开发上下文。

#### 总体一键恢复

```text
query_audit_logs({ keyword: "adduser-migration" })
```
→ 预期返回 4 条记录

#### 逐任务/逐文件审计查询

```text
query_audit_logs({ targetId: "prisma/main.prisma" })
→ 预期返回 SCHEMA_MODIFIED: DevOperation.user 和 AuditLog.user 的 @relation 从 User 改 AddUser

query_audit_logs({ targetId: "prisma/add.prisma" })
→ 预期返回 SCHEMA_CREATED: 完整版 AddUser（含 DevOperation[]、AuditLog[] 反向关系）

query_audit_logs({ targetId: "src/lib/log-user.ts" })
→ 预期返回 COMPONENT_MODIFIED: prisma.user.upsert → prisma.addUser.upsert

query_audit_logs({ targetId: "src/lib/log/audit.ts" })
→ 预期返回 COMPONENT_MODIFIED: userId 变为 AddUser.id（FK 目标表变更）
```

#### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE "targetId" IN (
  'prisma/main.prisma',
  'prisma/add.prisma',
  'src/lib/log-user.ts',
  'src/lib/log/audit.ts'
)
ORDER BY "createdAt" DESC;
```

#### 恢复判定标准

- action 命中数 ≥ 4
- grep 验证命令：

```bash
grep -R "addUser" src/lib/log-user.ts
grep -R "AddUser" prisma/main.prisma prisma/add.prisma
```

### 4.9 后置确认

- [ ] `npx tsc --noEmit` 通过
- [ ] `pnpm exec prisma generate` 成功
- [ ] `npx next build --webpack` 编译通过
- [ ] `pnpm dev` 全链路启动无报错
- [ ] MCP 工具 `record_dev_operation` 调用后 `DevOperation` 表有新记录，userId 为 `"ai-assistant"`

### 4.10 脱敏要求

Handoff 文档中 **禁止出现** 以下硬编码值：
- 数据库密码（`POSTGRES_PASSWORD`）
- Chroma auth token（`CHROMA_AUTH_TOKEN`）
- JWT 密钥（`JWT_SECRET`）
- API Key（`OPENAI_API_KEY_*`、`LLM_API_KEY` 等）

所有凭据值应通过 `${ENV_VAR}` 引用，并标注值见 `.env.development`。

---

## 五、验收标准

- [ ] `DevOperation.userId` FK 指向 `AddUser` 表
- [ ] `AuditLog.userId` FK 指向 `AddUser` 表
- [ ] `AddUser` 表存在 `ai-assistant` 用户（id="ai-assistant"）
- [ ] `src/lib/log-user.ts` 使用 `prisma.addUser.upsert`
- [ ] 存量 `DevOperation`（2365 条）和 `AuditLog`（42062 条）数据完整，userId 值不变
- [ ] `pnpm dev` 全链路启动成功，浏览器可访问
- [ ] MCP 工具 `record_dev_operation` 可正常写入 DevOperation 记录

---

## 六、关联

| 类型 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-07/18/farm-agent-adduser-migration-add-route-v1.md` |
| Handoff | 见本文第四部分 |
| Spec | `.qoder/specs/farm-agent-adduser-migration/` |
| Review | `.qoder/reviews/farm-agent-adduser-migration-review-v1.md` |
