# farm-agent MCP 驾仓 + OS Kernel 用户空间 + ROS2 桥接 + Rust HAL — Plan v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。不写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-mcp-cockpit-ros2-bridge-v1
- **启动时间**: 2026-07-14
- **主导 AI**: Qoder
- **关联文档**:
  - 上游架构: `docs/大田精准耕播智能决策系统/knowledge/01-架构/Agent-OS-Kernel-架构说明书.md`
  - 认知决策管线: `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md`
- **Specs 策略**: 本 Plan 为架构路线图级计划，不直接产出代码。Phase 1（MCP 驾仓）和 Phase 2（Skill Registry）各需独立 Spec。Phase 3（ROS2 Bridge）和 Phase 4（Rust HAL）属于跨项目范畴，仅定义接口契约。
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| .qoder/plans/2026-07/14/farm-agent-mcp-cockpit-ros2-bridge-plan-v1.md | PLAN | PLAN_CREATED | 无 MCP 驾仓架构设计 | 完整四阶段路线图 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

farm-agent 已建成完整的 Agent OS Kernel（GlobalStateProvider / CognitiveEventBus / PolicyUpdateLoop / Checkpointer / Report 体系），但存在三层断裂：

| 断裂层 | 现象 | 严重度 |
|--------|------|:--:|
| **用户空间缺失** | OS Kernel 只有内核态运行，无外部可观测/可操控接口。PolicyUpdateLoop 产出仅通过 console.log 和 agentAudit 消费，Report 系统发现需人工 triage 才能进入 ADD 流程。 | P0 |
| **Agent 间无互操作** | IDE Agent（Qoder）通过 add-dev-tools MCP 操作开发流程，但无法调用 farm-agent 的 22 个领域工具（天气、土壤、虫情等）。两个 Agent 是完全隔离的孤岛。 | P1 |
| **物理世界断层** | agentTools 通过 HTTP API 间接访问 farm-server 数据，没有直达传感器/执行器的通道。OODA 循环（Observe-Orient-Decide-Act）在 Act 环节断裂——Agent 只能分析建议，不能闭环执行。 | P2 |

### 1.2 目标

构建"认知操作系统"的完整四层架构：

```
用户空间 (Dashboard / IDE / H5)
        ↕ MCP (JSON-RPC over stdio/HTTP)
────────────────────────────────────
Agent OS Kernel (认知内核)
  PolicyUpdateLoop │ Skill Registry │ Report │ Checkpointer
  CognitiveEventBus │ GlobalStateProvider
  LangGraph 管线 (intention→...→response)
        ↕ 消息桥接层
────────────────────────────────────
ROS2 Network (物理世界)
  上位机(Agent) ↔ 下位机(Controller) ↔ Rust HAL Node
        ↕
  传感器 / 执行器 (土壤、气象、虫情、灌溉、施药)
```

**四个 Phase 分步实施**：

- **Phase 1: MCP 驾仓** — farm-agent 暴露自身 MCP Server，让 OS Kernel 拥有用户空间操控能力
- **Phase 2: Agent Skill Registry** — Agent 内部 Skill 可被 MCP 发现和激活，PolicyUpdateLoop 可消费 Skill 产出
- **Phase 3: ROS2 消息桥接** — 上位机 Agent 与下位机 Controller 通过 ROS2 topic/service/action 打通
- **Phase 4: Rust HAL Node** — Rust 实现的硬件抽象节点，连接传感器和执行器

---

## 二、方案选型

### 2.1 MCP Server 技术方案

| 方案 | 做法 | 优势 | 劣势 | 结论 |
|------|------|------|------|:--:|
| A: 与现有 add-dev-tools 合并 | 在 `.qoder/scripts/mcp-server.ts` 中追加 agent tools | 单进程，无额外运维 | 职责混淆：dev-tools（开发治理）和 agent-capabilities（运行时服务）不应耦合 | 备选 |
| B: 独立 MCP Server 进程 | 新建 `src/mcp-server.ts`，独立注册 agent tools | 职责清晰，可独立扩缩 | 多一个进程 | **选用** |
| C: HTTP API 包装 | 把 agent tools 包装成 REST API | 通用性好 | 不符合 MCP 协议标准，IDE Agent 无法直接消费 | 备选 |

**选型理由**：方案 B 保持 dev-tools 和 agent-capabilities 的职责分离。agent-mcp-server 是 agent 运行时的对外接口，dev-mcp-server 是开发流程的门禁工具。两个 MCP Server 可注册到同一个 `mcp.json` 中让 IDE Agent 同时消费。

### 2.2 ROS2 桥接通信中间件

| 方案 | 协议 | 延迟 | 跨机器 | 结论 |
|------|------|------|:--:|:--:|
| A: ROS2 native (DDS) | DDS (RTPS) | <1ms | ✅ | 上位机需装 ROS2 环境，TypeScript 生态弱 |
| B: MCP over HTTP → ROS2 bridge | HTTP ↔ DDS | ~10-50ms | ✅ | **选用**：Agent 侧零 ROS2 依赖 |
| C: MQTT / NATS / Zenoh | Pub-Sub | <5ms | ✅ | 需额外中间件 |
| D: Unix Domain Socket + Protobuf | Protobuf | <1ms | ❌ | 限同机 |

**选型理由**：方案 B 最务实。Agent 侧（TypeScript/Node.js）通过 MCP tool 发 HTTP 请求到 Rust ROS2 bridge node，bridge node 负责 DDS 通信。Agent 不需要安装 ROS2，只需知道 bridge node 的 HTTP endpoint。

### 2.3 Rust HAL Node 选型

| 考量 | 选择 | 理由 |
|------|------|------|
| 语言 | Rust | 零成本抽象、无 GC、`embedded-hal` 生态成熟 |
| ROS2 绑定 | `ros2_rust` + `rclrs` | 官方 Rust client library |
| MCP 暴露 | `mcp-server` (Rust crate) 或 HTTP endpoint | 让 HAL Node 自身也可被 IDE Agent 直接操控 |
| 硬件接口 | `embedded-hal` (I2C/SPI/UART/CAN) | 标准嵌入式抽象层 |
| 安全熔断 | PolicyUpdateLoop rollback 信号 → HAL Node 紧急停机 | 复用 OS Kernel 的策略回滚能力 |

---

## 三、架构设计

### 3.1 Phase 1: MCP 驾仓 — 用户空间操控

```
┌──────────────────────────────────────────────────────┐
│                   IDE Agent (Qoder)                    │
│  mcp.json:                                            │
│    farm-agent-dev-tools  (开发门禁: DPS/RAHS/审计)     │
│    farm-agent-capabilities ← 新增! (agent 能力)       │
│         │                                              │
│         ▼                                              │
│  ┌──────────────────────────────────────────────┐     │
│  │        farm-agent MCP Server (新增)           │     │
│  │                                              │     │
│  │  tools:                                      │     │
│  │    agent_query_weather_realtime              │     │
│  │    agent_query_soil_moisture                 │     │
│  │    agent_query_insect_data                   │     │
│  │    ... (22 个 agentTools 全部暴露)            │     │
│  │                                              │     │
│  │  —— OS Kernel 驾仓工具 (新增) ——              │     │
│  │    policy_status       → getSnapshot()       │     │
│  │    policy_evaluate     → PolicyUpdateLoop    │     │
│  │    policy_rollback     → rollback()          │     │
│  │    skill_list          → Skill Registry      │     │
│  │    skill_activate      → 激活指定 Skill       │     │
│  │    report_findings     → gateway.md 查询     │     │
│  │    checkpoint_status   → Checkpointer 状态    │     │
│  └──────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────┘
```

**文件变更**：

| 文件 | 变更类型 | 变更内容 |
|------|---------|------|
| `src/mcp-server/agent-capabilities.ts` | 新增 | MCP Server 主入口，注册 agentTools + OS Kernel 驾仓工具 |
| `src/mcp-server/tools/agent-tools.ts` | 新增 | 将 22 个 LangChain StructuredTool 适配为 MCP tool schema |
| `src/mcp-server/tools/os-kernel-tools.ts` | 新增 | policy_status / policy_evaluate / policy_rollback / skill_list / skill_activate / report_findings / checkpoint_status |
| `.qoder/mcp.json` | 修改 | 新增 `farm-agent-capabilities` server 配置 |
| `package.json` | 修改 | 新增 `mcp:agent` 启动脚本 |

### 3.2 Phase 2: Agent Skill Registry

在 OS Kernel 内部建立 Skill Registry，将现有的专家/工具/策略能力声明式注册：

```typescript
// 概念模型
interface AgentSkill {
  id: string
  trigger: CognitiveEvent["type"][]   // 订阅事件
  dependsOn: StateDomainKey[]          // 依赖域
  strategy: "pull" | "wait" | "skip"  // 复用 EVENT_CONSUMER_REGISTRY 策略
  execute: (ctx: SkillContext) => Promise<SkillResult>
  postCondition?: (result: SkillResult) => boolean
}
```

与现有体系的关系：
- **Skill Registry** ↔ **EVENT_CONSUMER_REGISTRY**：Skill 是消费者的一种，统一注册在同一注册表中
- **Skill 产出** → **PolicyUpdateLoop**：Skill 的执行结果作为额外输入参数传入 evaluate()
- **Skill 激活** → **MCP tool `skill_activate`**：外部可通过 MCP 手动激活

**文件变更**：

| 文件 | 变更类型 | 变更内容 |
|------|---------|------|
| `src/agents/skill-registry.ts` | 新增 | Skill Registry 类型定义 + 注册函数 + 调度器 |
| `src/caijuehub/strategies/event-consumer-strategies.ts` | 修改 | 注册 skill-dispatcher-consumer |
| `src/agents/policy-update-loop.ts` | 修改 | evaluate() 新增 skillResults 参数 |

### 3.3 Phase 3: ROS2 消息桥接

```
farm-agent MCP Server
        │ HTTP POST /ros2/publish
        ▼
┌───────────────────┐
│  ROS2 Bridge Node  │  ← Rust 实现，独立进程
│  (HTTP ↔ DDS)      │
│                    │
│  订阅的 topic:     │
│    /sensor/soil_moisture
│    /sensor/weather_station
│    /sensor/insect_trap
│    /sensor/camera/ndvi
│                    │
│  发布的 topic:     │
│    /actuator/irrigation/command
│    /actuator/sprayer/command
│                    │
│  提供的 service:   │
│    /sensor/query   │
│    /actuator/execute│
└───────────────────┘
```

**接口契约**：

| MCP Tool (Agent 侧) | ROS2 方向 | ROS2 类型 | 说明 |
|------|:--:|------|------|
| `agent_query_soil_moisture` | ← sub | `/sensor/soil_moisture` (topic) | 土壤湿度传感器数据 |
| `agent_query_farm_weather` | ← sub | `/sensor/weather_station` (topic) | 气象站实时数据 |
| `agent_query_insect_data` | ← sub | `/sensor/insect_trap` (topic) | 虫情测报灯数据 |
| `agent_actuate_irrigation` | → pub | `/actuator/irrigation/command` (action) | 灌溉阀门控制 |
| `agent_actuate_sprayer` | → pub | `/actuator/sprayer/command` (action) | 施药设备控制 |

### 3.4 Phase 4: Rust HAL Node — 硬件抽象层

```
┌─────────────────────────────────────────┐
│          Rust HAL Node                    │
│                                           │
│  ┌─────────────────────────────────────┐ │
│  │  ros2_rust::Node                    │ │
│  │  - subscription /sensor/*           │ │
│  │  - publisher /actuator/*            │ │
│  └──────────────┬──────────────────────┘ │
│                 │                         │
│  ┌──────────────┴──────────────────────┐ │
│  │  Hardware Abstraction Layer         │ │
│  │  - I2C: 土壤传感器 (SHT30/31)       │ │
│  │  - SPI: ADC 采集模块                │ │
│  │  - UART: GPS/气象站                 │ │
│  │  - CAN: 农机控制器                    │ │
│  │  - GPIO: 继电器/阀门                 │ │
│  └──────────────┬──────────────────────┘ │
│                 │                         │
│  ┌──────────────┴──────────────────────┐ │
│  │  Safety Layer                        │ │
│  │  - 指令校验 (policy confidence ≥ 70) │ │
│  │  - 熔断器 (连续异常 → 紧急停机)       │ │
│  │  - 回滚支持 (OS Kernel rollback 信号) │ │
│  └─────────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

---

## 四、实施步骤 + 依赖图

```
Phase 1: MCP 驾仓
├── Task 1.1: agent-capabilities MCP Server 骨架
├── Task 1.2: 22 个 agentTools 适配为 MCP tool schema
├── Task 1.3: OS Kernel 驾仓工具 (policy/report/checkpoint)
└── Task 1.4: mcp.json 双 Server 注册 + 端到端验证
        │
        ▼
Phase 2: Agent Skill Registry
├── Task 2.1: Skill Registry 类型定义 + 注册函数
├── Task 2.2: Skill 接入 EVENT_CONSUMER_REGISTRY
├── Task 2.3: PolicyUpdateLoop 消费 Skill 产出
└── Task 2.4: MCP skill_list / skill_activate 暴露
        │
        ▼
Phase 3: ROS2 消息桥接 (跨项目)
├── Task 3.1: Rust ROS2 Bridge Node 项目创建
├── Task 3.2: agentTools ↔ ROS2 topic/service 映射契约
├── Task 3.3: MCP agent tools 桥接 HTTP → Bridge Node
└── Task 3.4: 端到端数据流验证 (传感器→Agent→MCP→GUI)
        │
        ▼
Phase 4: Rust HAL Node (跨项目)
├── Task 4.1: embedded-hal 驱动层 (I2C/SPI/UART/CAN)
├── Task 4.2: Safety Layer (指令校验 + 熔断 + 回滚)
├── Task 4.3: HAL Node ↔ ROS2 Bridge 集成
└── Task 4.4: OODA 全闭环验证 (传感器→认知→决策→执行→传感器)
```

### Phase 1: MCP 驾仓 — Agent 用户空间操控

#### Task 1.1: agent-capabilities MCP Server 骨架

**目标**：创建独立的 farm-agent MCP Server，与现有 add-dev-tools 并列运行。

**改动文件**：
- `src/mcp-server/agent-capabilities.ts` (新增) — MCP Server 主入口
- `package.json` (修改) — 新增 `mcp:agent` 脚本

**实施要点**：
- 使用 `@modelcontextprotocol/sdk` 创建 McpServer 实例
- server name: `farm-agent-capabilities`, version: `1.0.0`
- 使用 `StdioServerTransport` 通信
- 复用现有 Prisma 连接（读取 agent 运行时数据）
- 不加载 Next.js 路由，纯 MCP 进程

**验收**：`tools/list` 返回空工具列表，Server 正常启动无报错

#### Task 1.2: 22 个 agentTools 适配为 MCP tool schema

**目标**：将 `src/agents/tools/index.ts` 中的 22 个 LangChain StructuredTool 暴露为 MCP tool。

**改动文件**：
- `src/mcp-server/tools/agent-tools.ts` (新增)

**实施要点**：
- 遍历 `agentTools` 数组，为每个工具调用 `server.registerTool()`
- tool name 使用 `agent_` 前缀避免与 dev-tools 命名冲突
- 从 StructuredTool 的 `.schema`（Zod schema）提取 MCP `inputSchema`
- 从 StructuredTool 的 `.description` 提取 MCP `description`
- tool handler 内调用 `tool.invoke(args)` 执行

**验收**：`tools/list` 返回所有 22 个工具，`tools/call agent_query_weather_realtime` 返回合法结果

#### Task 1.3: OS Kernel 驾仓工具

**目标**：新增 7 个 OS Kernel 操控工具，让外部可通过 MCP 查询和干预 Agent 认知状态。

**改动文件**：
- `src/mcp-server/tools/os-kernel-tools.ts` (新增)

**实施要点**：

| MCP Tool | 对应 OS Kernel 能力 | 参数 | 返回值 |
|----------|---------------------|------|--------|
| `policy_status` | `GlobalStateProvider.getSnapshot()` | 无 (或 threadId) | 七域快照 JSON |
| `policy_evaluate` | `PolicyUpdateLoop.evaluate()` | ttlStats?, turnHistory? | PolicyUpdateRecord |
| `policy_rollback` | `PolicyUpdateLoop.rollback()` | domain: string | rollback 结果 |
| `skill_list` | Skill Registry (Phase 2 前置) | 无 | 已注册 Skill 列表 |
| `skill_activate` | Skill Registry (Phase 2 前置) | skillId: string | 激活结果 |
| `report_findings` | gateway.md 查询 | status?: "open"\|"closed" | 运行时发现列表 |
| `checkpoint_status` | PostgresSaver 查询 | threadId?: string | checkpoint 状态 |

**验收**：7 个工具全部出现在 `tools/list` 中，`policy_status` 返回合法 JSON

#### Task 1.4: mcp.json 双 Server 注册 + 端到端验证

**目标**：在 `.qoder/mcp.json` 中注册两个 MCP Server，IDE Agent 可同时消费。

**改动文件**：
- `.qoder/mcp.json` (修改)

**实施要点**：
```json
{
  "mcpServers": {
    "farm-agent-dev-tools": {
      "command": "tsx",
      "args": [".qoder/scripts/mcp-server.ts"]
    },
    "farm-agent-capabilities": {
      "command": "tsx",
      "args": ["src/mcp-server/agent-capabilities.ts"],
      "env": {
        "NODE_ENV": "development",
        "DATABASE_URL": "..."
      }
    }
  }
}
```

**验收**：IDE Agent 可以同时调用 `check_dps`（dev-tools）和 `agent_query_weather_realtime`（capabilities），两个 Server 互不干扰。

---

### Phase 2: Agent Skill Registry

#### Task 2.1: Skill Registry 类型定义 + 注册函数

**目标**：在 OS Kernel 内部建立可声明式注册的 Skill 体系。

**改动文件**：
- `src/agents/skill-registry.ts` (新增)

**实施要点**：
- `AgentSkill` 接口：id / trigger / dependsOn / strategy / execute / postCondition
- `SkillContext` 类型：包含 GlobalStateProvider snapshot + CognitiveEventBus + AgentState
- `registerSkill(skill)` 注册函数
- `getSkill(id)` 查询函数
- `listSkills()` 列出全部
- 与 `EVENT_CONSUMER_REGISTRY` 同构设计，Skill 可作为消费者的一类

**验收**：类型系统完整，registerSkill 可正常注册

#### Task 2.2: Skill 接入 EVENT_CONSUMER_REGISTRY

**目标**：Skill 作为消费者注册到 EVENT_CONSUMER_REGISTRY，由 caijuehub 统一裁决就绪条件。

**改动文件**：
- `src/caijuehub/strategies/event-consumer-strategies.ts` (修改)

**实施要点**：
- 新增 `skill-dispatcher-consumer`：订阅 `strategy:resolved`，策略 pull
- 新增 `skill-executor-consumer`：订阅 `action:proposed`，策略 wait
- 裁决函数 `resolveEventConsumerReadiness` 对 `dependsOn` 含 `skill` 域的消费者特殊处理

**验收**：EVENT_CONSUMER_REGISTRY 含 skill 相关消费者，注册表长度 +2

#### Task 2.3: PolicyUpdateLoop 消费 Skill 产出

**目标**：Skill 的执行结果（如灌溉建议、病虫害诊断）作为 PolicyUpdateLoop 的额外输入，影响策略调整。

**改动文件**：
- `src/agents/policy-update-loop.ts` (修改)

**实施要点**：
- `evaluate()` 新增 `skillResults?: SkillResult[]` 参数
- `evaluateExpertActivation` 可读取 skill 激活频率，建议激活高频 Skill
- `evaluateEvidenceFilter` 可读取 skill 置信度，动态调整过滤条件
- Skill 产出写入 GlobalStateProvider 的 `policy` 域

**验收**：PolicyUpdateLoop 在 skill 激活后产出不同的策略记录

#### Task 2.4: MCP skill_list / skill_activate 暴露

**目标**：Phase 1 预留的 `skill_list` 和 `skill_activate` MCP tool 在此 Phase 真正实现。

**改动文件**：
- `src/mcp-server/tools/os-kernel-tools.ts` (修改)

**验收**：`tools/call skill_list` 返回已注册 Skill 列表，`tools/call skill_activate` 触发 Skill 执行并返回结果

---

### Phase 3: ROS2 消息桥接（跨项目）

#### Task 3.1: Rust ROS2 Bridge Node 项目创建

**目标**：创建独立 Rust 项目 `farm-agent-ros2-bridge`，作为 Agent 与 ROS2 网络的协议转换层。

**改动文件**：独立 Rust 项目（不在 farm-agent 仓库内）

**实施要点**：
- 使用 `ros2_rust` + `rclrs` crate
- HTTP server (actix-web) 监听 Agent MCP tool 发来的请求
- 将 HTTP 请求转换为 ROS2 publish / service call
- 将 ROS2 subscription 数据缓存为 HTTP 可查询状态
- 参考架构：`HTTP POST /ros2/topic/{name}` → `publisher.publish(msg)`

#### Task 3.2: agentTools ↔ ROS2 topic/service 映射契约

**目标**：定义 Agent 工具与 ROS2 消息类型的映射表。

**改动文件**：
- `src/mcp-server/tools/ros2-bridge-tools.ts` (新增) — ROS2 桥接 MCP tool 集
- `docs/ros2-bridge-contract.md` (新增) — 接口契约文档

**映射契约**：

| Agent Tool | ROS2 类型 | 消息类型 | QoS |
|------|:--:|------|:--:|
| `query_soil_moisture` | Subscription | `sensor_msgs/msg/Range` | RELIABLE |
| `query_farm_weather` | Subscription | `sensor_msgs/msg/Temperature` + `Humidity` | BEST_EFFORT |
| `query_insect_data` | Subscription | 自定义 `farm_msgs/msg/InsectCount` | RELIABLE |
| `actuate_irrigation` | Action | 自定义 `farm_msgs/action/Irrigate` | RELIABLE |
| `actuate_sprayer` | Action | 自定义 `farm_msgs/action/Spray` | RELIABLE |

#### Task 3.3: MCP agent tools 桥接 HTTP → Bridge Node

**目标**：agentTools 中的外部数据工具（天气/土壤/虫情）改为通过 Bridge Node HTTP API 获取数据。

**改动文件**：
- `src/agents/tools/impl/farm-data-tools.ts` (修改) — 添加 Bridge Node 回退路径
- `src/agents/tools/impl/weather-tools.ts` (修改) — 同上

**实施要点**：
- 工具调用时优先尝试 Bridge Node（`BRIDGE_NODE_URL` 环境变量）
- Bridge Node 不可用时回退到现有 farm-server HTTP API
- 不改变工具接口签名，对 LLM 透明

**验收**：设置 BRIDGE_NODE_URL 后，工具调用返回 ROS2 传感器数据

#### Task 3.4: 端到端数据流验证

**目标**：从传感器到 GUI 的完整数据流验证。

**验证链路**：
```
物理传感器 → Rust HAL 读取 → ROS2 topic publish
  → Bridge Node HTTP 缓存
  → MCP tool agent_query_soil_moisture
  → IDE Agent 可查询 / agrisynapse GUI 可展示
```

**验收**：传感器数值通过 MCP tool 可查询，数据延迟 < 5 秒

---

### Phase 4: Rust HAL Node（跨项目）

#### Task 4.1: embedded-hal 驱动层

**目标**：使用 Rust `embedded-hal` 对接物理硬件。

**改动文件**：独立 Rust 项目（不在 farm-agent 仓库内）

**实施要点**：
- I2C: `embedded-hal` + `linux-embedded-hal` → SHT30/SHT31 温湿度传感器
- SPI: `embedded-hal` + `linux-embedded-hal` → ADS1115 ADC 模块
- UART: `serialport` crate → GPS/气象站串口通信
- CAN: `socketcan` crate → 农机 ISO 11783 (ISOBUS)
- GPIO: `sysfs_gpio` → 继电器/电磁阀门

#### Task 4.2: Safety Layer

**目标**：硬件指令执行必须经过安全校验，融合 OS Kernel 的策略回滚能力。

**实施要点**：
- 指令前置校验：PolicyUpdateLoop.confidence ≥ 70 才放行 actuator 指令
- 执行熔断：连续 3 次执行异常 → 紧急停机 + 上报 Report 系统
- 回滚支持：OS Kernel PolicyUpdateLoop.rollback() → HAL Node 执行反向操作
- 人机协同：高危操作（如大面积施药）必须人工确认

#### Task 4.3: HAL Node ↔ ROS2 Bridge 集成

**目标**：HAL Node 作为 ROS2 Node 加入 DDS 网络，与 Bridge Node 通信。

**验收**：HAL Node 发布 `/sensor/soil_moisture` topic，Bridge Node 成功订阅并缓存

#### Task 4.4: OODA 全闭环验证

**目标**：从传感器到执行器的完整 OODA 循环验证。

```
Observe: 土壤传感器 → Rust HAL → ROS2 topic → Bridge Node → MCP tool
Orient:  agent_query_soil_moisture → AgentState → CognitiveEventBus
Decide:  PolicyUpdateLoop 检测干旱趋势 → 激活 irrigation_decision Skill
         → 产出灌溉建议 (置信度 85%)
Act:     MCP agent_actuate_irrigation → Bridge Node → ROS2 action
         → Rust HAL Node 检查 safety → GPIO 开启电磁阀门
         → 传感器反馈湿度变化 → 回到 Observe
```

**验收**：全链路时间 < 30 秒（从传感器读数到执行器动作），异常熔断 < 3 秒触发

---

## 五、验收标准

### Phase 1
- [ ] Task 1.1: `tools/list` 返回空工具列表，Server 正常启动
- [ ] Task 1.2: `tools/list` 返回 22 个 agent_ 前缀工具，`tools/call agent_query_weather_realtime` 返回合法数据
- [ ] Task 1.3: 7 个 OS Kernel 驾仓工具全部可用，`policy_status` 返回合法七域快照
- [ ] Task 1.4: IDE Agent 可同时调用 dev-tools 和 capabilities 两个 MCP Server

### Phase 2
- [ ] Task 2.1: Skill Registry 类型系统通过 tsc
- [ ] Task 2.2: EVENT_CONSUMER_REGISTRY 含 skill 消费者
- [ ] Task 2.3: PolicyUpdateLoop 在 skill 激活后产出不同策略记录
- [ ] Task 2.4: `skill_list` 和 `skill_activate` MCP tool 可正常使用

### Phase 3
- [ ] Task 3.1: Rust Bridge Node 项目编译通过，HTTP server 可响应
- [ ] Task 3.2: ROS2 消息类型契约文档完成
- [ ] Task 3.3: agentTools 通过 Bridge Node 获取数据，有回退路径
- [ ] Task 3.4: 传感器数值通过 MCP tool 可查询，延迟 < 5 秒

### Phase 4
- [ ] Task 4.1: HAL Node 成功读取至少一种传感器（I2C/UART）
- [ ] Task 4.2: Safety Layer 熔断逻辑通过模拟测试
- [ ] Task 4.3: HAL Node ↔ Bridge Node DDS 通信正常
- [ ] Task 4.4: OODA 全闭环执行成功，总延迟 < 30 秒，熔断 < 3 秒

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| Agent OS Kernel 架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/Agent-OS-Kernel-架构说明书.md` |
| 决策管线架构说明书 | `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` |
| PolicyUpdateLoop 源码 | `src/agents/policy-update-loop.ts` |
| CognitiveEventBus 源码 | `src/agents/cognitive-event-bus.ts` |
| EVENT_CONSUMER_REGISTRY | `src/caijuehub/strategies/event-consumer-strategies.ts` |
| agentTools 清单 | `src/agents/tools/index.ts` |
| Checkpointer 工厂 | `src/lib/checkpointer.ts` |
| Report 工作流 | `.qoder/reports/REPORT-WORKFLOW.md` |
| add-dev-tools MCP Server | `.qoder/scripts/mcp-server.ts` |
| OS Kernel Wiring Plan | `.qoder/plans/2026-06/12/farm-agent-os-kernel-wiring-plan-v1.md` |
