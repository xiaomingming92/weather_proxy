# API 响应格式统一：success/error → code/message (v1)

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度（文件路径 + Task 验收标准 + 架构维度全覆盖）。不在此写完整 TS 类型定义或精确函数签名。

## PLAN 元信息

- **Plan 名称**: api-response-format-unification-v1
- **启动时间**: 2026-07-13T10:49:00+08:00
- **主导 AI**: Qoder (Claude)
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-07/13/api-response-format-unification-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-07/13/api-response-format-unification-handoff-v1.md`
  - Review: `.qoder/reviews/api-response-format-unification-review-v1.md`

---

## 一、背景与目标

### 1.1 问题现状

当前 farm-agent 后端 REST API 存在两种响应格式混用，同一项目中不统一：

| 格式 | 使用模块 |
|------|---------|
| `{ success: true/false, data, error }` | 对话域(agent)、种子库(seed-catalog)、项目(project)、文档(document)、知识库(knowledge 全模块)、系统(system)、审计(audit)、用户(users) |
| `{ code: 200/400/..., message, data }` | H5 生产计划(4 个路由)、Admin 管理 |

部分文件（task/route.ts、admin/service-accounts/route.ts）同一文件内混用两种格式。Agrisynapse 前端为此维护两套类型（`ApiResponse<T>` 和 `FarmAgentResponse<T>`）。实际影响范围远超 Plan 初版预估：涉及 **48 个文件**（后端 38 路由 + agrisynapse 前端 4 + farm-agent GUI 4 + 文档 1 + 基础设施 3）。

### 1.2 目标

神经元 GUI（Agrisynapse）及 farm-agent 自有 GUI 调用的全部 REST API 端点，统一使用 `{ code, message }` 格式，与 H5 接口保持一致，消除双类型维护成本。

---

## 二、方案选型

> 本次为单向格式统一，无须多方案对比。仅列出"为何选 code/message 而非 success/error"的理由。

| 维度 | `{ success, error }` (当前) | `{ code, message }` (目标) |
|------|---------------------------|---------------------------|
| H5 兼容性 | 不一致，H5 端用 code/message | ✅ 与 H5 完全一致 |
| HTTP 语义 | success 与 HTTP status 冗余 | code 映射 HTTP status，message 描述错误 |
| 扩展性 | bool 只有两态 | 数字支持更多状态码（409 冲突等） |
| 前端解析 | 两套类型 | 一套 `ApiResponse<T>` 通吃 |

**选型理由**：H5 生产计划 4 个路由和 Admin 模块已使用 `code/message` 格式且稳定运行；对话域和种子库向 H5 对齐，改动可控。

---

## 三、架构设计

### 3.1 数据流转（响应格式变更链路）

```
Agrisynapse 前端
  │  fetch → JSON.parse → 检查 .code / .message
  │  文件: src/api/llm/agent/index.ts (request 函数, L99-122)
  │        src/api/llm/seed/index.ts (SeedApi, L57-127)
  │        src/store/modules/agentChat.ts (L142,154,499,570)
  ▼
farm-agent 后端 Route Handler
  │  NextResponse.json({ code: 200/400/..., message/data })
  │  文件: src/app/api/agent/[hash]/route.ts (makeSuccessResponse/makeErrorResponse)
  │        src/app/api/seed-catalog/* (3 个文件)
  │        src/app/api/project/* (2 个文件)
  │        src/app/api/document/* (2 个文件)
  ▼
HTTP Response
  { code: 200, data: T }        — 成功
  { code: 400, message: "..." }  — 参数校验
  { code: 404, message: "..." }  — 资源不存在
  { code: 500, message: "..." }  — 服务端错误
```

**回退路径**：本次纯字段重命名，不涉及 Prisma Schema 或数据库迁移。任一 Task 失败只需回退对应文件的 SearchReplace 即可。

### 3.2 影响域拓扑

```
                    agent/[hash]/route.ts (核心，~10 处)
                   /           |            \
          resume/     chat/threads/       (agent 子路由)
         route.ts     route.ts

          seed-catalog/route.ts    ← 独立模块
          seed-catalog/[id]/route.ts
          seed-catalog/price/route.ts

          project/route.ts         ← 独立模块
          project/[id]/route.ts

          document/route.ts        ← 独立模块
          document/[id]/vectorize/route.ts

          task/route.ts            ← Zod 校验残留修正
          task/[id]/route.ts
          task/[id]/status/route.ts
          admin/service-accounts/  ← 同上
          admin/maintenance/

          knowledge/ 全模块        ← Plan 初版遗漏（14 个文件）
          grounding/batch, mapping, disciplines, stats
          documents/[id], documents/[id]/tags, documents/[id]/grounding
          documents/[id]/index/cancel
          upload, sync, sync/cancel
          vectors, vectors/files

          system/config, system/metrics ← Plan 初版遗漏
          audit, users/me               ← Plan 初版遗漏
          agent/.../debug, agent/.../report ← Plan 初版遗漏
          types/farm-agent/schemas       ← Zod schema 修正
          doc-format-guard.sh            ← MAGIC_DIR 支持
          mcp-server.ts                  ← execSync→spawnSync 安全加固
```

Agent 模块、种子库、项目、文档四组互不依赖，可并行修改。前端依赖后端先行。

### 3.3 数据模型变更

无 Prisma Schema 变更。唯一类型变更在前端：

```typescript
// 改前 (agent/types.ts)
interface ApiResponse<T = unknown> {
  success: boolean
  data?: T
  error?: string
}

// 改后
interface ApiResponse<T = unknown> {
  code: number
  data?: T
  message?: string
}
```

`seed/index.ts` 中 `FarmAgentResponse<T>` 做同样变更。

---

## 四、实施 Task + 依赖图

```
Task 1 (agent 核心) ──┐
Task 2 (种子库)     ──┤ 可并行
Task 3a (杂项路由)  ──┤
Task 3b (knowledge) ──┘  ← 增量回流
          │
          ▼
Task 4 (前端类型+seed 客户端)
          │
          ▼
Task 5 (前端 agent 客户端+Store)
          │
          ▼
Task 6 (文档同步)
          │
          ▼
Task 7 (端到端测试)
```

> **实施状态**: 全部 7 个 Task 已完成 ✅ (2026-07-13)

### Task 1: 后端 agent 核心路由 ✅
- [x] `agent/[hash]/route.ts`: 修改 makeSuccessResponse/makeErrorResponse 底层，`success/error` → `code/message`
- [x] `agent/resume/route.ts`: 响应格式统一
- [x] `agent/chat/threads/route.ts`: DELETE 响应格式统一

### Task 2: 后端种子库路由 ✅
- [x] `seed-catalog/route.ts`: GET 分页 + POST 创建（6 条路径）
- [x] `seed-catalog/[id]/route.ts`: GET + PUT + DELETE（9 条路径）
- [x] `seed-catalog/price/route.ts`: POST 价格（6 条路径）

### Task 3a: 后端杂项路由 ✅
- [x] `project/route.ts` + `project/[id]/route.ts`
- [x] `document/route.ts` + `document/[id]/vectorize/route.ts`
- [x] `task/route.ts`: POST Zod 校验残留修正
- [x] `admin/service-accounts/route.ts`: 同上
- [x] `admin/maintenance/route.ts`: 同上

### Task 3b: 后端 knowledge + system + audit + users（Plan 初版遗漏，增量回流）✅
- [x] `knowledge/grounding/batch/route.ts`
- [x] `knowledge/grounding/mapping/route.ts`
- [x] `knowledge/grounding/disciplines/route.ts`
- [x] `knowledge/grounding/stats/route.ts`
- [x] `knowledge/documents/[id]/route.ts`
- [x] `knowledge/documents/[id]/tags/route.ts`
- [x] `knowledge/documents/[id]/grounding/route.ts`
- [x] `knowledge/documents/[id]/index/cancel/route.ts`
- [x] `knowledge/documents/route.ts`
- [x] `knowledge/upload/route.ts`
- [x] `knowledge/sync/route.ts`
- [x] `knowledge/sync/cancel/route.ts`
- [x] `knowledge/vectors/route.ts`
- [x] `knowledge/vectors/files/route.ts`
- [x] `system/config/[key]/route.ts`
- [x] `system/metrics/[name]/route.ts`
- [x] `audit/route.ts`
- [x] `users/me/route.ts`
- [x] `agent/chat/threads/[threadId]/debug/route.ts`
- [x] `agent/chat/threads/[threadId]/messages/[messageId]/report/route.ts`
- [x] `task/[id]/status/route.ts`
- [x] `types/farm-agent/schemas.ts` (Zod schema 类型修正)

### Task 4: 前端类型 + 种子库客户端（agrisynapse）✅
- [x] `agrisynapse/src/api/llm/agent/types.ts`: `ApiResponse<T>` 接口 `{success,data,error}` → `{code,data,message}`
- [x] `agrisynapse/src/api/llm/seed/index.ts`: `FarmAgentResponse<T>` 类型同步 + 6 处 `json.code !== 200` 判断

### Task 5: 前端 agent 客户端 + Store（agrisynapse）✅
- [x] `agrisynapse/src/api/llm/agent/index.ts`: `request()` 日志判断 `res.code === 200`
- [x] `agrisynapse/src/store/modules/agentChat.ts`: 4 处 `res.code`/`res.message` 判断

### Task 5b: farm-agent 自有 GUI 组件（Plan 初版遗漏）✅
- [x] `src/components/task/task-panel.tsx`: `result.success` → `result.code === 200`（2 处）
- [x] `src/components/knowledge/knowledge-base-panel.tsx`: `data.success` → `data.code === 200`（5 处）+ `data.error` → `data.message`（3 处）
- [x] `src/components/auth/login-form.tsx`: `data.success` → `data.code === 200` + `data.error` → `data.message`
- [x] `src/components/project/project-panel.tsx`: `data.success` → `data.code === 200`

### Task 6: 文档同步 ✅
- [x] `docs/.../神经元GUI-API对接文档.md`: §2.2 错误响应格式、§3-§4 全部响应示例；版本 v2.0 → v2.1

### Task 7: 端到端测试 ✅
- [x] 种子库 CRUD 全流程 curl（查询/创建/更新/删除/价格）
- [x] 对话 handshake → chat SSE → resume
- [x] 线程管理（查询/列表/删除/改名）

---

## 五、验收标准

- [x] 所有神经元 GUI 端点返回 `{ code, message }` 格式
- [ ] Agrisynapse 前端 `pnpm build` 无 TS 类型错误
- [x] 种子库 CRUD 全流程 curl 测试通过
- [x] 对话握手 + 流式聊天流程测试通过
- [x] 文档更新至 v2.1，示例与代码一致
- [x] H5 生产计划接口不受影响（格式不变）

---

## 六、关联文档

| 文档 | 路径 |
|------|------|
| ADD Route | `.qoder/plans/2026-07/13/api-response-format-unification-add-route-v1.md` |
| Handoff | `.qoder/plans/2026-07/13/api-response-format-unification-handoff-v1.md` |
| Review | `.qoder/reviews/api-response-format-unification-review-v1.md` |
| Spec | `.qoder/specs/api-response-format-unification/spec.md` |
| Tasks | `.qoder/specs/api-response-format-unification/tasks.md` |
| Checklist | `.qoder/specs/api-response-format-unification/checklist.md` |