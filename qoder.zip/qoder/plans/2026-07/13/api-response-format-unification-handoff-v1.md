# farm-agent — API 响应格式统一 success/error → code/message 交接手册

> **适用场景**：单轮变更——全部 REST API 响应格式从 `{success,error}` 统一为 `{code,message}`，与 H5 协议对齐。

---

## 1. 交接前状态

farm-agent 后端 REST API 响应格式混用：
- `{ success: true/false, data, error }` — 对话域、种子库、知识库、项目、文档、系统、审计、用户
- `{ code: 200/400/..., message, data }` — H5 生产计划、Admin 管理

Agrisynapse 前端维护两套类型（`ApiResponse` 和 `FarmAgentResponse`），farm-agent 自有 GUI 组件（task/knowledge/auth/project 面板）直接检查 `data.success`/`data.error`。

---

## 2. 交接后状态（目标）

全部端点统一使用 `{ code, message }`：
- 成功：`{ code: 200, data: T }`
- 错误：`{ code: 400/404/409/500, message: "描述" }`

H5 `resume` 端点增量加 `code/message`，保留旧 `success/error` 兼容。

---

## 3. 改动清单

### 后端 farm-agent（38 路由）

| # | 模块 | 文件数 | 操作 |
|---|------|--------|------|
| 1 | agent 核心 | 6 | 修改 |
| 2 | agent 子路由 | 4 | 同上 |
| 3 | seed-catalog | 3 | 同上 |
| 4 | project | 2 | 同上 |
| 5 | document | 2 | 同上 |
| 6 | task | 3 | 同上 |
| 7 | admin | 2 | 同上 |
| 8 | knowledge | 14 | 同上（Plan 初版遗漏） |
| 9 | system | 2 | 同上（Plan 初版遗漏） |
| 10 | audit | 1 | 同上（Plan 初版遗漏） |
| 11 | users | 1 | 同上（Plan 初版遗漏） |
| 12 | H5 resume | 1 | 增量加 `code/message` |

### 前端 agrisynapse（4 文件）

| # | 文件 | 操作 |
|---|------|------|
| 13 | `agrisynapse/src/api/llm/agent/types.ts` | `ApiResponse<T>` 接口重构 |
| 14 | `agrisynapse/src/api/llm/seed/index.ts` | `FarmAgentResponse<T>` + 6 处判断 |
| 15 | `agrisynapse/src/api/llm/agent/index.ts` | 日志判断 `res.code === 200` |
| 16 | `agrisynapse/src/store/modules/agentChat.ts` | 4 处 `code`/`message` 判断 |

### farm-agent GUI 组件（4 文件）

| # | 文件 | 操作 |
|---|------|------|
| 17 | `src/components/task/task-panel.tsx` | `result.success` → `result.code === 200`（2 处） |
| 18 | `src/components/knowledge/knowledge-base-panel.tsx` | `data.success`/`data.error` → `code`/`message`；`alert()` → 组件化错误 |
| 19 | `src/components/auth/login-form.tsx` | `data.success`/`data.error` → `code`/`message` |
| 20 | `src/components/project/project-panel.tsx` | `data.success` → `data.code === 200` |

### 文档 + 基础设施（4 文件）

| # | 文件 | 操作 |
|---|------|------|
| 21 | `docs/.../神经元GUI-API对接文档.md` | v2.0 → v2.1 |
| 22 | `src/app/api/types/farm-agent/schemas.ts` | Zod schema 类型修正 |
| 23 | `.qoder/hooks/doc-format-guard.sh` | MAGIC_DIR 支持 |
| 24 | `.qoder/scripts/mcp-server.ts` | execSync→spawnSync + validateDocWithGuard |

---

## 4. 回滚方案

```bash
git revert HEAD
```

无数据迁移，纯代码层改动。

---

## 5. 执行前置检查

- [x] 全部 REST 端点 curl 测试通过
- [x] `grep -rn 'success:' src/app/api/` 仅剩 H5 兼容保留 + Zod `parsed.success`
- [x] 文档 `"success"/"error"` 零残留
- [x] `npx tsc --noEmit` + `eslint` 当前无 error

---

## 6. 执行步骤摘要

```
Task 1 (agent 核心) ──┐
Task 2 (种子库)     ──┤ 可并行 → 完成
Task 3a (杂项路由)  ──┤
Task 3b (knowledge) ──┘
          │
          ▼
Task 4 (agrisynapse 类型+客户端) → 完成
          │
          ▼
Task 5 (agrisynapse Store)       → 完成
Task 5b (farm-agent GUI 组件)    → 完成
          │
          ▼
Task 6 (文档同步)   → 完成
          │
          ▼
Task 7 (端到端测试) → 完成
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| H5 调用方依赖 `success/error` | 瑞丰耘前端报错 | H5 resume 增量保留旧字段，其余 H5 路由已是 `code/message` |
| agrisynapse 前端类型不兼容 | TS 编译错误 | 类型定义同步更新 |
| farm-agent GUI 组件遗漏 | 面板功能异常 | 全量 grep 确认零残留 |
| MCP create_plan 校验失效 | 后续 Plan 格式不规范 | mcp-server.ts 已加 `validateDocWithGuard` |

---

## 8. 恢复上下文审计查询

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用，直接复制粘贴参数调用即可。

### 总体一键恢复

```text
query_audit_logs({ planKeyword: "api-response-format-unification" })
```
→ 预期返回 1 条 VERIFY 记录

### 逐任务/逐文件审计查询

```text
query_audit_logs({ targetId: "src/app/api/agent/[hash]/route.ts" })
→ 预期返回: makeSuccessResponse/makeErrorResponse 底层修改

query_audit_logs({ targetId: "src/app/api/seed-catalog/route.ts" })
→ 预期返回: success/error → code/message 全部路径

query_audit_logs({ targetId: "docs/.../神经元GUI-API对接文档.md" })
→ 预期返回: v2.0 → v2.1 文档同步
```

### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "DevOperation"
WHERE "planKeyword" = 'api-response-format-unification'
ORDER BY "createdAt" DESC;
```

### 恢复判定标准

- DevOperation 命中数 ≥ 1
- grep 验证：

```bash
grep -rn 'code:' src/app/api/agent/[hash]/route.ts | head -5
grep -rn '"code":' docs/.../神经元GUI-API对接文档.md | head -3
grep -rn 'data\.success\|data\.error' src/components/ | wc -l  # 预期 0
```

---

## 9. 后置确认

- [x] 种子库 CRUD 全流程 curl 通过
- [x] Agent handshake + thread list 通过
- [x] Knowledge documents + grounding stats 通过
- [x] 错误响应格式验证（404/400 均返回 `code` + `message`）
- [x] grep 确认 API 路由 `success:` 零残留（排除 H5 兼容 + Zod parsed）
- [x] grep 确认 GUI 组件 `data.error`/`data.success` 零残留
- [x] devlog 已记录（`record_dev_operation` VERIFY）
- [x] handoff 文件已生成
- [x] `npx tsc --noEmit` + `eslint` 通过

### 脱敏要求

Handoff 文档中 **禁止出现** 以下类型的硬编码值：
- 数据库密码（`POSTGRES_PASSWORD`）
- Chroma auth token（`CHROMA_AUTH_TOKEN`）
- JWT 密钥（`JWT_SECRET`）
- API Key

所有凭据值应通过 `${ENV_VAR}` 引用，并标注"值见 `.env.development` / `.env.production`"。

---
