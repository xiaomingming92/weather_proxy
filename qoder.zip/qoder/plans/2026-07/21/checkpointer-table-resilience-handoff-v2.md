# farm-agent — Checkpointer 表完整性防护 v2 交接手册

> **适用场景**：v1 完成 MemorySaver→PostgresSaver 迁移后，checkpoint 表在 db reset/备份恢复后静默丢失，无感知。v2 增加三层检测防护。
>
> **父 Plan**: `.qoder/plans/2026-07/21/checkpointer-table-resilience-plan-v2.md`

---

## 1. 交接前状态

- v1 (2026-06-26): `PostgresSaver` 已替换 `MemorySaver`，`setup()` 首次 graph invoke 时建表
- 2026-06-30 之后：`prisma db push` 建议 db reset → 用户备份恢复 → checkpoint 表随数据库重建丢失
- 之后 20 天 0 条 CHECKPOINTER 日志 → checkpointer 静默降级 MemorySaver，resume 机制失效
- 空间推理管线（spatial-reasoning-plan-v3）依赖 PostgresSaver 持久化 AgentState

---

## 2. 交接后状态（目标）

- `createCheckpointer()` 每次 startup 检测 4 张 checkpoint 表完整性
- 表存在 → PostgresSaver 正常初始化（不重复 setup）
- 表缺失 → throw Error 阻止服务启动（不降级 MemorySaver）+ 恢复指引
- `db-ensure.sh` / `db-ensure.prod.sh` 启动前检测 checkpoint 表
- `db-export.sh` 导出时显式验证 checkpoint 表在 dump 中
- `pnpm init:checkpointer` 一键创建 checkpoint 表 + 审计日志
- 恢复流程统一：`bash scripts/db-import.sh → pnpm init:checkpointer → 重启`

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/lib/checkpointer.ts` | 修改 | 新增 `checkTablesExist()` + 移除 MemorySaver 降级 + 表缺失 throw |
| 2 | `src/agents/agent-runner.ts` | 修改 | `runAgent()`/`streamAgent()` 加 try-catch，检测 42P01 并 wrap |
| 3 | `src/lib/log/phase.ts` | 修改 | 新增 `CheckpointerPhase` 类型（6 个 phase 字符串） |
| 4 | `src/types/pg.d.ts` | 新建 | `pg` 模块最小类型声明 |
| 5 | `scripts/db-ensure.sh` | 修改 | 新增 [8/8] checkpoint 表检测 + 统一步号 |
| 6 | `scripts/db-ensure.prod.sh` | 修改 | 新增 [3/3] checkpoint 表检测 |
| 7 | `scripts/db-export.sh` | 修改 | 新增 [3/3] checkpoint 表导出验证 |
| 8 | `scripts/init-checkpointer.ts` | 新建 | checkpoint 表创建脚本 + audit 日志 |
| 9 | `package.json` | 修改 | 新增 `pnpm init:checkpointer` 命令 |

---

## 4. 回滚方案

### 代码回滚

```bash
git revert <commit>
```

### 数据回滚

checkpoint 表由 `PostgresSaver.setup()` 动态管理，回滚后表可保留：

```sql
-- 如需清空 checkpoint 数据：
DROP TABLE IF EXISTS checkpoint_migrations CASCADE;
DROP TABLE IF EXISTS checkpoints CASCADE;
DROP TABLE IF EXISTS checkpoint_blobs CASCADE;
DROP TABLE IF EXISTS checkpoint_writes CASCADE;
```

---

## 5. 执行前置检查

- [ ] PostgreSQL 容器运行中（`podman ps | grep farm-agent-postgres`）
- [ ] `DATABASE_URL` 在 `.env.development` / `.env.production` 中已配置
- [ ] `psql` 或 podman exec 方式可连接数据库
- [ ] `npx tsc --noEmit` 通过（checkpointer 相关文件零错误）

---

## 6. 执行步骤摘要

```text
Task 1: 修改 src/lib/checkpointer.ts
        ├── 新增 checkTablesExist() — 查询 information_schema
        ├── createCheckpointer() — 检测表 → 缺失 throw Error
        └── 移除 MemorySaver 导入和降级路径
            │
Task 2: 修改 src/agents/agent-runner.ts
        ├── 新增 isCheckpointTableMissingError()
        ├── 新增 wrapCheckpointError() 
        └── runAgent()/streamAgent() 加 try-catch
            │
Task 3: 新增 scripts/init-checkpointer.ts
        ├── import createCheckpointer + agentAudit
        ├── dotenv 加载 .env 文件
        └── 成功/失败分支 + audit 日志
            │
Task 4: 修改 scripts/db-ensure.sh + .prod.sh
        ├── 新增 [8/8] checkpoint 表检测
        ├── 修复 -tAc→-tA + -h -p 端口
        └── 恢复流程指引
            │
Task 5: 修改 scripts/db-export.sh
        ├── 新增 [3/3] checkpoint 表导出验证
        └── 原 [1/2][2/2]→[1/3][2/3][3/3]
            │
Task 6: package.json 新增 init:checkpointer
            │
Task 7: npx tsc --noEmit → 零错误
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| 表丢失后服务无法启动 | 开发/生产中断 | 清晰指引 + `pnpm init:checkpointer` 恢复 |
| psql 连接问题（端口/权限） | 误报表丢失 | 已修复 -h -p 端口 + -tA 标志 |
| 容器内 psql 端口不一致 | 检测失败 | 分支处理：本地 psql 用 5433，容器内用 5432 |
| HMR 重复初始化 | 多次 checkTablesExist | 保留单例 guard |

### 实施发现回流

- `-tAc` 中 `-c` 与 pipe 输入冲突 → 改为 `-tA`
- `db-ensure.sh` 步号混乱（/4、/6、/7、7.5/7）→ 统一 [1/8]~[8/8]
- `instrumentation.ts` 不适合做 runtime 检测 → 改为 `agent-runner.ts`
- 恢复指引"PostgresSaver 自动可用"不准确 → 改为显式 `pnpm init:checkpointer`

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

### 总体一键恢复

```text
query_audit_logs({ keyword: "checkpointer-table-resilience" })
```
→ 预期返回 9 条记录

### 逐任务/逐文件审计查询

```text
query_audit_logs({ targetId: "src/lib/checkpointer.ts" })
→ 预期返回 COMPONENT_MODIFIED: startup 表检测 + 移除 MemorySaver 降级

query_audit_logs({ targetId: "src/agents/agent-runner.ts" })
→ 预期返回 COMPONENT_MODIFIED: 运行时 42P01 错误检测

query_audit_logs({ targetId: "scripts/init-checkpointer.ts" })
→ 预期返回 COMPONENT_CREATED: checkpoint 表初始化脚本

query_audit_logs({ targetId: "scripts/db-ensure.sh" })
→ 预期返回 COMPONENT_MODIFIED: [8/8] checkpoint 表检测

query_audit_logs({ keyword: "CHECKPOINTER_TABLES_MISSING" })
→ 预期返回 1+ 条: 表缺失审计记录
```

### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "DevOperation"
WHERE "planKeyword" = 'checkpointer-table-resilience'
ORDER BY "createdAt" DESC;
```

### 恢复判定标准

- action 命中数 ≥ 7
- grep 验证命令：

```bash
grep -R "checkTablesExist" src/lib/
grep -R "isCheckpointTableMissingError" src/agents/
grep -R "init:checkpointer" package.json
grep "\[8/8\] LangGraph" scripts/db-ensure.sh
```

---

## 9. 后置确认

### 编译期验证

- [ ] 未验证 `npx tsc --noEmit` — 需验证 checkpointer 相关文件

### 功能验证

- [ ] `pnpm init:checkpointer` 成功创建 4 张表 + audit 日志
- [ ] `db-ensure.sh` [8/8] 表完整时 ✅ 通过
- [ ] `db-ensure.sh` [8/8] 表缺失时 exit 1 + 恢复指引
- [ ] dev server 完整启动 + 发起对话 + resume

### CHECKPOINTER 表完整性验证

```bash
podman exec farm-agent-postgres psql -U farm_admin -d farm_agent -tAc \
  "SELECT COUNT(*) FROM information_schema.tables \
   WHERE table_schema='public' \
   AND table_name IN ('checkpoints','checkpoint_blobs','checkpoint_writes','checkpoint_migrations');"
# 预期输出: 4
```

---

## 10. 脱敏要求

Handoff 文档中 **禁止出现** 以下类型的硬编码值：
- 数据库密码（`POSTGRES_PASSWORD`）→ 值见 `.env.development`
- ChromaDB Token（`CHROMA_AUTH_TOKEN`）→ 值见 `.env.development`
- JWT 密钥（`JWT_SECRET`）→ 值见 `.env.development`
- API Key → 值见 `.env.development`

所有凭据值应通过 `${ENV_VAR}` 引用，并标注"值见 `.env.development` / `.env.production`"。
