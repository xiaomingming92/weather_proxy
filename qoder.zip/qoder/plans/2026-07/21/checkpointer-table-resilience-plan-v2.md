# checkpointer-table-resilience-plan-v2

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。不要写完整实现——那是 Spec 的职责。
>
> **增量更新**：本 Plan 是 `checkpointer-postgres-migration-plan.md`（2026-06-26）的 v2 增量补充。v1 解决了"MemorySaver → PostgresSaver 迁移"，v2 解决"checkpoint 表丢失后无自愈机制"。

## PLAN 元信息

- **Plan 名称**: checkpointer-table-resilience-v2
- **启动时间**: 2026-07-21T12:00:00+08:00
- **主导 AI**: Qoder
- **前置 Plan**: `checkpointer-postgres-migration-plan.md`（v1，2026-06-26）
- **关联文档**:
  - v1 Plan: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-plan.md`
  - v1 Handoff: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-handoff.md`

---

## 一、背景与目标

### 1.1 问题现状

v1 在 2026-06-26 完成 MemorySaver → PostgresSaver 迁移，`setup()` 成功建表。但 2026-06-30 之后 checkpoint 表消失：

**根因**：`prisma db push` 建议 `db reset`，用户备份恢复数据后，checkpoint 表随数据库重建丢失。`checkpointer.ts` 的 `setup()` 是 **lazy one-shot** 设计——首次 graph invoke 时跑一次建表 SQL，之后不再验证表是否存在。任何外部原因（db reset / 手动 DROP TABLE / 容器重建）导致表丢失后，checkpointer 静默降级为 MemorySaver，resume 机制失效。

**日志证据**：
```
最后一条成功日志: 2026-06-30T08:18:42.066Z [CHECKPOINTER_POSTGRES_CONNECT]
之后 20 天 0 条 CHECKPOINTER 日志 → 既无 connect 也无 fallback
```

**影响**：
- resume 端点无法恢复中断的对话
- 多轮对话上下文在服务重启后丢失（MemorySaver 降级无告警）
- 开发者无感知（无日志，无告警）

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | 每次进程启动强制验证 checkpoint 表 | 启动日志可见 setup() 执行结果 |
| P0 | db-ensure.sh 包含 checkpoint 表验证 | Prisma migration 后自动建表 |
| P1 | 运行时 fallback 检测 | 查询失败时自动 setup() + 重试 |
| P2 | 表丢失告警 | audit 日志记录表重建事件 |

---

## 二、技术方案

### 2.1 变更范围

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/lib/checkpointer.ts` | 重构 | 新增 `checkTablesExist()`，`createCheckpointer()` startup 检测表 → 缺失 throw Error |
| `src/agents/agent-runner.ts` | 修改 | `runAgent()`/`streamAgent()` 加 try-catch，捕获 42P01 并 wrap 清晰错误 |
| `src/lib/log/phase.ts` | 修改 | 新增 `CheckpointerPhase` 类型（6 个 phase） |
| `src/types/pg.d.ts` | 新建 | `pg` 模块最小类型声明 |
| `scripts/db-ensure.sh` | 修改 | 新增 [8/8] checkpoint 表检测 + 恢复流程引导 |
| `scripts/db-ensure.prod.sh` | 修改 | 新增 [3/3] checkpoint 表检测 + 恢复流程引导 |
| `scripts/db-export.sh` | 修改 | 新增 [3/3] checkpoint 表导出验证 + 审计日志 |
| `scripts/init-checkpointer.ts` | 新建 | checkpoint 表首次创建脚本，替代原始 `node -e` 命令 |
| `package.json` | 修改 | 新增 `pnpm init:checkpointer` npm 命令 |

**不改的部分**：
- `agent-graph.ts` checkpointer 消费方式不变
- resume 端点代码不变
- LangGraph API 对 checkpointer 透明
- `src/agents/instrumentation.ts` 未修改（原计划可选，实际由 agent-runner.ts 承担 runtime 职责）

### 2.2 修复 1：startup 检测 + 条件初始化

``typescript
// src/lib/checkpointer.ts

// 当前（错的）：lazy one-shot，假设表始终存在
let checkpointerPromise: Promise<BaseCheckpointSaver> | null = null;
if (checkpointerPromise) return checkpointerPromise;

// 修复：每次 startup 检测表是否存在
// 如果表存在：跳过 setup()，直接使用（表已由正常流程创建）
// 如果表不存在：log warning + 降级 MemorySaver + 引导用户执行恢复流程
// 不静默执行 setup()——表丢失是异常信号，需用户介入
```

**关键逻辑**：
``typescript
async function checkTablesExist(): Promise<boolean> {
  // SELECT COUNT(*) FROM information_schema.tables
  // WHERE table_name IN ('checkpoints', 'checkpoint_blobs', ...)
  // 返回 true 当且仅当 4 张表都存在
}

export async function createCheckpointer() {
  if (checkpointerPromise) return checkpointerPromise;
  
  checkpointerPromise = (async () => {
    const tablesExist = await checkTablesExist();
    
    if (!tablesExist) {
      // 不降级 MemorySaver——空间推理管线（spatial-reasoning-plan-v3）依赖
      // PostgresSaver 持久化 AgentState，MemorySaver 会导致空间数据静默丢失
      console.error('[Checkpointer] ❌ checkpoint 表不存在');
      console.error('[Checkpointer] 这表明数据库可能经历过 reset 或备份恢复');
      console.error('[Checkpointer] 请执行: bash scripts/db-import.sh 恢复数据，然后重启 dev server');
      throw new Error(
        'Checkpointer tables missing. Run: bash scripts/db-import.sh'
      );
    }
    
    // 表存在，正常使用 PostgresSaver（不执行 setup）
    const pg = new PostgresSaver();
    return pg;
  })();
  
  return checkpointerPromise;
}
```

### 2.3 修复 2：db-ensure.sh checkpoint 表检测 + 流程引导

``bash
# scripts/db-ensure.sh — Prisma migration 之后

echo "🔍 检查 LangGraph checkpoint 表..."
MISSING=$(psql "$DATABASE_URL" -tAc \
  "SELECT COUNT(*) FROM information_schema.tables \
   WHERE table_schema='public' \
   AND table_name IN ('checkpoints','checkpoint_blobs','checkpoint_writes','checkpoint_migrations');" 2>/dev/null)

if [ "$MISSING" != "4" ]; then
  echo ""
  echo "❌ checkpoint 表不完整 ($MISSING/4)"
  echo ""
  echo "这表明数据库可能经历过 reset 或备份恢复。"
  echo "请按以下流程恢复："
  echo ""
  echo "  1. 停止 dev server (Ctrl+C)"
  echo "  2. 执行 npm run db:backup（如有需要）"
  echo "  3. 从备份恢复数据: bash scripts/db-import.sh (PostgreSQL + ChromaDB 全量恢复)"
  echo "  4. 重启 dev server，checkpoint 表将由 PostgresSaver.setup() 自动创建"
  echo ""
  echo "如确认无需恢复数据，可手动执行："
  echo "  node -e \"require('./src/lib/checkpointer').createCheckpointer()\""
  echo ""
  exit 1
else
  echo "✅ checkpoint 表完整 (4/4)"
fi
```

**设计原则**：不静默建表——表丢失是数据库异常信号，应由用户决定是走恢复流程还是手动重建。

### 2.4 修复 3：运行时 fallback（不降级，抛出错误）

```typescript
// src/lib/checkpointer.ts — 运行时异常处理

// 当 checkpoint 查询失败（PG error 42P01 = table not found）
// → log error + audit 告警
// → 抛出错误（不降级 MemorySaver）
//   空间推理管线依赖 PostgresSaver，MemorySaver 会导致空间数据静默丢失
// → 控制台输出恢复指引：
//   "[Checkpointer] ❌ checkpoint 表丢失"
//   "[Checkpointer] 请停止服务并执行: bash scripts/db-import.sh"
//   "[Checkpointer] 恢复后重启 dev server，PostgresSaver 将自动可用"
```

---

## 三、风险与缓解

| 风险 | 概率 | 缓解措施 |
|------|------|---------|
| db-ensure.sh psql 不可用 | 低 | 脚本内已有 psql 调用，复用现有逻辑 |
| 用户忽略告警 | 中 | 不降级，直接抛错阻止服务，控制台醒目输出 + 恢复指引清晰 |
| Next.js HMR 重复初始化 | 低 | 保留单例 guard，每次 startup 检测表存在性 |
| MemorySaver 降级导致数据丢失 | 不适用 | 不降级，缺表时直接抛错阻止服务启动 |

---

## 四、验收标准

1. `npm run dev` → 启动日志可见 `[CHECKPOINTER] checkpoint 表检测通过，PostgreSQL checkpointer 已就绪`
2. 手动 `DROP TABLE checkpoints CASCADE` → 下次 startup → 日志输出 `[CHECKPOINTER] ❌ checkpoint 表不存在` + throw 阻止服务 + 恢复指引
3. `scripts/db-ensure.sh` 执行 → 检测到表缺失 → 输出恢复流程指引 → `exit 1` 阻止启动
4. 用户执行恢复流程后重启 → checkpoint 表存在 → 正常初始化 PostgresSaver
5. 连续 3 次 dev server 重启（表存在情况下）→ 每次都有检测日志 → 不重复执行 setup

---

## 五、涉及 Commit

```
fix(checkpointer): 增加 checkpoint 表检测与恢复流程引导

- src/lib/checkpointer.ts: 每次 startup 检测表存在性，缺失时抛错阻止服务（不降级 MemorySaver）
- 原因：空间推理管线依赖 PostgresSaver 持久化，MemorySaver 会导致空间数据静默丢失
- scripts/db-ensure.sh: Prisma migration 后验证 4 张 checkpoint 表，缺失时输出恢复流程指引
- 不静默建表——表丢失是数据库异常信号，由用户决定恢复方式

根因: v1 的 setup() 是 lazy one-shot，db reset / 数据恢复后表丢失无感知。
修复: startup 检测 + 流程引导 + 运行时告警，确保用户及时介入恢复。
```

---

## 六、实施回流（2026-07-21）

实际实施中发现原 Plan 未覆盖的额外工作，回流至 Plan：

### 6.1 新增文件

| 文件 | 原因 |
|------|------|
| `scripts/init-checkpointer.ts` | 原 Plan 用 `node -e "require(...)"` 过于原始，改为独立 ts 脚本 + 审计日志 |
| `src/types/pg.d.ts` | `pg` 模块无 TS 类型声明，需最小类型文件 |
| `scripts/db-export.sh` [3/3] | 原 Plan 只覆盖了 db-ensure.sh，但导出备份也需要显式验证 checkpoint 表 |
| `scripts/db-ensure.prod.sh` [3/3] | 原 Plan 只计划改 dev 版，生产 CI 同样需要检测 |

### 6.2 实施中发现的 bug

| bug | 根因 | 修复 |
|-----|------|------|
| db-ensure.sh psql 总是返回 0/4 | 本地 psql 未指定 `-h -p`，默认连 5432；`-tAc` 中 `-c` 与 pipe 冲突 | 增加 `-h "$PG_HOST" -p "$PG_PORT"`；`-tAc` → `-tA` |
| 容器内 psql 端口与外部不同 | podman exec 走容器内部 socket，端口是 5432 非 5433 | 分支处理：本地 psql 用 5433，容器 psql 用 5432 |
| db-ensure.sh 步号混乱 | 混用 /4、/6、/7、7.5/7 | 统一为 [1/8]~[8/8] |
| 恢复指引说"自动创建" | PostgresSaver.setup() 不会自动运行（二次启动时单例已缓存） | 改为显式指引 `pnpm init:checkpointer` |

### 6.3 设计调整

| 原设计 | 实际方案 | 原因 |
|--------|---------|------|
| `src/agents/instrumentation.ts` 做 startup 初始化 | `agent-runner.ts` 做 runtime error wrap | instrumentation 太底层，graph invoke 时才需要检测 checkpoint 错误 |
| 表缺失时降级 MemorySaver | 表缺失时 throw Error 阻止服务 | 空间推理管线依赖 PostgresSaver，MemorySaver 导致数据静默丢失 |
