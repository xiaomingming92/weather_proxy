# farm-agent — ESLint 全量修复（error 清零 + cast 消除 + unused-vars 清理）交接手册

> **适用场景**：单轮变更（1 个原子闭包），修复全部 ESLint error 级别问题 + 消除 ~37 处 `as unknown as` 双重 cast + unused-vars 收敛。

---

## 1. 交接前状态

`npx eslint src/`：**220 问题**（49 errors + 171 warnings）
- 35 × `no-explicit-any`
- 9 × `prefer-const`
- 3 × `react-hooks`（set-state-in-effect × 2 + purity × 1）
- 2 × 杂项（no-require-imports + no-restricted-imports）
- 159 × `no-unused-vars`（warning，P2 暂不处理）
- 11 × 其他 warning
- ~60+ 处 `as unknown as` 双重 cast

---

## 2. 交接后状态（目标）

`npx eslint src/`：**0 errors**，54 warnings
`npx tsc --noEmit`：零错误
`as unknown as`：23 处残留（均为合法类型边界）

---

## 3. 改动清单

### Phase 1: ESLint error 修复（49 → 0）

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/workers/ocr-worker.ts` | 修改 | 7 处 `any` → 具体类型 |
| 2 | `src/caijuehub/strategies/resolve-tool-params.ts` | 修改 | 3 处 `any` → 具体类型 |
| 3 | `src/agents/nodes/structured-output.ts` | 修改 | 2 处 `any` + 1 处 `let`→`const` |
| 4 | `src/agents/tool-node-wrapper.ts` | 修改 | 2 处 `any` → 具体类型 + `Array.isArray` |
| 5 | `src/agents/tools/impl/seed-catalog.ts` | 修改 | 2 处 `any` → 具体类型 |
| 6 | `src/agents/agent-runner.ts` | 修改 | 2 处 `any` → 具体类型 |
| 7 | `src/agents/nodes/coordination-dialogue.ts` | 修改 | 1 处 `any` + 1 处 `let`→`const` |
| 8 | `src/agents/nodes/intention.ts` | 修改 | 1 处 `any` → 具体类型 |
| 9 | `src/agents/tools/impl/web-search.ts` | 修改 | 1 处 `any` + 1 处 `let`→`const` |
| 10 | `src/app/api/agent/[hash]/route.ts` | 修改 | 1 处 `any` + Zod schema 联动 + body.type 提取 |
| 11 | `src/app/api/agent/chat/route.ts` | 修改 | 1 处 `any` → 具体类型 |
| 12 | `src/app/api/agent/stream/route.ts` | 修改 | 2 处 `any` → 具体类型 |
| 13 | `src/app/api/h5/agent/route.ts` | 修改 | 1 处 `any` → 具体类型 |
| 14 | `src/app/api/h5/nongqing/prescriptions/[id]/route.ts` | 修改 | 2 处 `any` + Prisma cast 降级 |
| 15 | `src/app/api/h5/nongqing/tasks/[id]/route.ts` | 修改 | 2 处 `any` + Prisma cast 降级 |
| 16 | `src/app/api/h5/production-plan/variety-recommend/route.ts` | 修改 | 1 处 `any` → 具体类型 |
| 17 | `src/app/api/seed-catalog/route.ts` | 修改 | 2 处 `any` → 具体类型 |
| 18 | `src/services/index-job-manager.ts` | 修改 | 2 处 `any` → 具体类型 |
| 19 | `src/components/chat/evidence-chain-panel.tsx` | 修改 | 状态提升：expandedIds Set 受控组件 |
| 20 | `src/components/chat/node-progress-timeline.tsx` | 修改 | `now` prop + eslint-disable |
| 21 | `src/caijuehub/strategies/service-auth-resolver.ts` | 修改 | `require()` → `import` |
| 22 | `src/lib/append-runtime-finding.ts` | 修改 | `globalThis.crypto.randomUUID()` |
| 23 | 日志文件 × 9 | 不修改 | no-restricted-syntax：标注为已知存量 |
| 24 | `src/components/knowledge/knowledge-base-panel.tsx` | 修改 | 图片加 alt 属性 |

### Phase 2: `as unknown as` 双重 cast 消除（~60+ → 23）

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 25 | `src/agents/nodes/reasoning.ts` | 修改 | `as unknown[]` → `Array.isArray` |
| 26 | `src/agents/nodes/response.ts` | 修改 | `as unknown[]` → `Array.isArray` |
| 27 | `src/lib/climate-zone-lookup.ts` | 修改 | 3 处 JSON import → `.default` |
| 28 | `src/agents/tools/impl/climate-zone-tools.ts` | 修改 | 2 处 JSON import → `.default` |
| 29 | `src/agents/types/structured-output.ts` | 修改 | InteractionPoint.type → InterruptType 枚举 |
| 30 | `src/agents/prompts/types.ts` | 修改 | InteractionPointOutput.type → InterruptType 枚举 |
| 31 | `src/agents/nodes/interaction-point-detection.ts` | 修改 | 移除 cast，类型同源 |
| 32 | `src/agents/prompts/interaction-point-detection.ts` | 修改 | validTypes → `InterruptType[]` |
| 33 | `src/lib/agent-chain-tracer.ts` | 修改 | 定义 JsonSerializable + sanitizeSnapshot 内部 cast |
| 34 | `src/services/chat-persistence.ts` | 修改 | Prisma.InputJsonValue 单步 cast |
| 35 | `src/dto/agent.dto.ts` | 修改 | ChatRequest 补齐 intent 字段 |
| 36 | `src/app/api/types/hash/schemas.ts` | 修改 | NeuronChatRequestSchema 补全全部字段 |
| 37 | `src/agents/global-state.ts` | 修改 | 9 个 interface → type + 单步 cast |
| 38 | `src/stores/chat-store.ts` | 修改 | structuredData 参数收窄 |
| 39 | `src/components/chat/chat-panel.tsx` | 修改 | 调用方适配 Partial<StructuredAgentResponse> |
| 40 | `src/app/api/agent/chat/stream/route.ts` | 修改 | body 用 Zod 推导类型 |

### Phase 3: unused-vars 清理（161 → 43）

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 41 | `eslint.config.mjs` | 修改 | 添加 `_` 前缀忽略规则 |
| 42 | 72 个 src/ 文件 | 修改 | 删除 84 处未使用 import/类型/函数 + 34 处 `_` 前缀 |

---

## 4. 回滚方案

### 代码回滚

```bash
git reset --hard HEAD~N   # N = 本 Plan 的 commit 数
```

### 数据回滚

无数据迁移，纯代码变更，回滚无风险。

---

## 5. 执行前置检查

- [x] Plan 已生成（`.qoder/plans/2026-07/02/farm-agent-eslint-fix-plan-v1.md`）
- [x] ADD Route 已生成（`.qoder/plans/2026-07/02/farm-agent-eslint-fix-add-route-v1.md`）
- [x] Review 已生成（`.qoder/reviews/eslint-fix-review-v1.md`）
- [x] Spec 已生成（`.qoder/specs/farm-agent-eslint-fix/`）
- [x] 原子闭包判定：单轮（1 个原子闭包，12 个 Task 构成一个完整业务功能）
- [x] `npx tsc --noEmit` 当前无新增错误
- [ ] DPS 闸门通过（≥ 85）

---

## 6. 执行步骤摘要

```text
Task 1: eslint --fix (9 prefer-const + 部分 unused-vars)
            │
            ▼
Task 2: 修复 no-explicit-any (35个, 19文件) ── 核心耗时
            │
            ├──────────────┬──────────────┐
            ▼              ▼              ▼
Task 3: React hooks   Task 4: 杂项    Task 5: warning
 (3个, 2文件)        (2个, 2文件)    (11个)
            │              │              │
            └──────────────┴──────────────┘
                           │
                           ▼
                  Task 6: tsc + eslint 复验
                           │
                           ▼
Task 7-11: as unknown as 消除（5 轮，16 文件）
                           │
                           ▼
Task 12: unused-vars 清理 + 最终复验
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| `any` → 具体类型后 `tsc` 报新错 | 需回退修正 | 逐文件修复后 `tsc --noEmit` |
| React hooks 修复引入无限循环 | 运行时卡死 | 审阅依赖数组，添加安全 guards |
| `--fix` 误删有效变量 | 编译错误 | `git diff` 逐行审阅 |
| `interface` → `type` 失去声明合并 | 消费方报错 | grep 确认零 `extends`/`implements` 依赖 |
| 多符号 import 行整行删除 | 误删在用符号 | 只删未使用的那个符号 |

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

> **给后续 AI 助手的说明**：以下每个 `query_audit_logs(...)` 都是 MCP 工具调用，AI 助手在自己的对话中**直接复制粘贴这些参数调用工具即可**，不需要写 SQL。共 50 条审计记录可恢复完整开发上下文。

### 总体一键恢复

```text
query_audit_logs({ planKeyword: "eslint-fix" })
```
→ 预期返回 58 条记录（2 PLAN + 3 SPEC + 1 DOC + 2 HANDOFF + 1 RULE + 3 API_ROUTE + 2 COMPONENT 批量 + 36 COMPONENT 逐文件 + 1 UTIL 删除 + 1 PLAN 更新 + 1 HANDOFF 重写）

### 逐任务审计查询

```text
query_audit_logs({ planKeyword: "eslint-fix", targetType: "COMPONENT" })
→ 预期返回 ~38 条: 各组件文件修改记录

query_audit_logs({ planKeyword: "eslint-fix", targetType: "API_ROUTE" })
→ 预期返回 ~12 条: 各 API route 文件修改记录

query_audit_logs({ planKeyword: "eslint-fix", targetType: "SPEC" })
→ 预期返回 3 条: spec.md + tasks.md + checklist.md 创建记录

query_audit_logs({ planKeyword: "eslint-fix", targetType: "RULE" })
→ 预期返回 1 条: eslint.config.mjs 配置变更
```

### 逐文件审计查询（关键文件）

```text
query_audit_logs({ targetId: "src/workers/ocr-worker.ts" })
→ 预期返回 MODIFY: 7 处 any → OCRResult/OCRData/OcrEngine interfaces

query_audit_logs({ targetId: "src/agents/agent-runner.ts" })
→ 预期返回 MODIFY: 2 处 any → Parameters<typeof fn>

query_audit_logs({ targetId: "src/agents/global-state.ts" })
→ 预期返回 MODIFY: 9 个 interface → type + 单步 cast

query_audit_logs({ targetId: "src/lib/agent-chain-tracer.ts" })
→ 预期返回 MODIFY: JsonSerializable 类型定义 + sanitizeSnapshot 内部 cast

query_audit_logs({ targetId: "src/app/api/agent/[hash]/route.ts" })
→ 预期返回 MODIFY: any 修复 + Zod schema 联动 + body dispatch 优化
```

### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE "planKeyword" = 'eslint-fix'
ORDER BY "createdAt" DESC;
```

### 恢复判定标准

- action 命中数 ≥ 58
- grep 验证命令：

```bash
grep -R "as unknown as" src/ --include="*.ts" --include="*.tsx" | wc -l
# 预期: 23

npx tsc --noEmit 2>&1 | tail -1
# 预期: 退出码 0

npx eslint src/ 2>&1 | grep "error"
# 预期: 0 errors
```

---

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过 — 证据: 退出码 0
- [x] `npx eslint src/` 零 error — 证据: 0 errors, 54 warnings
- [x] 所有文件改动已记录 ADD-7 审计 — 证据: `query_audit_logs({ planKeyword: "eslint-fix" })` = 58 条
- [x] Plan §五 验收标准全部通过（P0 error 清零 + Phase 2 cast 收敛 + Phase 3 unused-vars 收敛）
- [x] 无架构文档需更新（已确认）

---

## 原子闭包判定

```
原子闭包三可性判定
══════════════════
业务功能: 修复全部 ESLint error 级别问题 + 消除不必要 cast + unused-vars 收敛
Task Groups: Task 1-12（依赖链）

逐组业务价值判定:
  Task 1 (自动修复): 不能用 — 仅修复 9 个 prefer-const，用户感知不到 lint 通过
  Task 2 (no-explicit-any): 不能用 — 35 个 any 修复是完整功能的一部分
  Task 3-5 (hooks + 杂项 + warning): 不能用 — 各自为完整功能的一部分
  Task 6 (复验): 不能用 — 验证步骤，不产生独立价值
  Task 7-11 (cast 消除): 不能用 — 依赖 Phase 1，是同一质量目标的延伸
  Task 12 (unused-vars): 不能用 — 收尾步骤，依赖前面全部完成

判定结论: 需要 1 轮（1 个原子闭包）

第1轮（原子闭包1）: Task 1-12 — 业务功能: ESLint 全量修复 → lint 通过 + cast 收敛
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## 遗留项

| 项 | 状态 |
|----|------|
| P1 warning 11 个（`no-restricted-syntax` 9 + `exhaustive-deps` 1 + `alt-text` 1） | add-route Task 5 仍为 `⬜` |
| unused-vars 43 个 "assigned but never used" | 需人工判断是否死代码 |
| `[H]` 审阅项（checklist 第四/五组） | 需逐文件读代码确认类型语义 |
| Zod-DTO 收敛 plan | 待启动（依赖 eslint-fix，串行） |

### Zod-DTO 发现（另起 Plan）

验收过程中发现 `ChatRequest` 存在三份并行类型定义：
- `src/dto/agent.dto.ts` — 手写 interface
- `src/app/api/types/hash/schemas.ts` — Zod `NeuronChatRequestSchema`
- `src/app/api/types/farm-agent/schemas.ts` — Zod `AgentChatStreamSchema`

Route 用法不一致：`[hash]/route.ts` 用 Zod safeParse ✅，`stream/route.ts` 和 `chat/route.ts` 导入 schema 但不校验 ❌。

**结论**：另起 Zod-DTO 收敛 plan。依赖关系 eslint → Zod-DTO（串行）。

---

### 脱敏要求

Handoff 文档中 **禁止出现** 以下类型的硬编码值：
- 数据库密码（`POSTGRES_PASSWORD`）
- Chroma auth token（`CHROMA_AUTH_TOKEN`）
- JWT 密钥（`JWT_SECRET`）
- API Key（`OPENAI_API_KEY_*`）

所有凭据值应通过 `${ENV_VAR}` 引用，并标注"值见 `.env.development` / `.env.production`"。
