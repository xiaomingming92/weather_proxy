# farm-agent-zod-dto-convergence-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。不要写完整实现——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-zod-dto-convergence-v1
- **启动时间**: 2026-07-02T21:00:00+08:00
- **主导 AI**: Qoder
- **前置依赖**: `farm-agent-eslint-fix-v1`（已收敛，error = 0）
  - 直接依赖：RunnableConfig 泛型升级（Task 13）→ 消除 route 层 4 个 `as any`，使 stream/chat/[hash] 三个 route 的 `ChatRequest` 消费方可以安全切换到 Zod 类型
  - 间接依赖：no-explicit-any 35→0 + prefer-const 9→0 → src/ 全面处于 lint-clean 基线，本次 Zod 类型迁移不会引入新的 lint error
  - proxy 正则分流修复（同轮完成）→ 自有 GUI 端点不再被 hash 校验误拦，safeParse 回归测试可覆盖全部 28 端点
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-07/02/farm-agent-zod-dto-convergence-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-07/02/farm-agent-zod-dto-convergence-handoff-v1.md`
  - Review: `.qoder/reviews/zod-dto-convergence-review-v1.md`
  - Specs: `.qoder/specs/farm-agent-zod-dto-convergence/`
  - **Runtime Fix**: `.qoder/plans/2026-07/04/sse-interrupt-threadId-boundary-fix-plan-v1.md` — emitInterrupt() 边界注入时机修正（本 Plan 的 InterruptSSEPayloadSchema 强化暴露了存量缺陷）
- **实施进度**: Phase 1-6 ✅ | Phase 7 ⬜（待手动执行 `pnpm test:api`）
- **ADD-7 审计策略**: 见 §6

---

## 一、背景与目标

### 1.1 问题现状

项目中 HTTP 请求体类型存在**三套并行定义**，导致：

- 加字段需改 2–3 处，容易漂移
- 19 个 route 用 `await request.json()` 但**不做运行时校验**（导入了 schema 却没调 `safeParse`）
- `h5/types/dto.ts` 与 `types/h5/schemas.ts` 导出同名类型（`LandAnalysisData` 等），消费方 import 路径不可预测

#### 三套并行类型系统

| 来源 | 文件 | 类型数量 | 收敛后 |
|------|------|:--:|------|
| 手写 DTO | `src/dto/agent.dto.ts` | 3 | **删除**，请求类型由 `z.infer` 自动推导，响应类型迁入 `types/response.dto.ts` 以 `Dto` 后缀命名 |
| Zod schema (hash) | `src/app/api/types/hash/schemas.ts` | 8 schema + 8 infer | `NeuronChatRequestSchema` 覆盖 `ChatRequest` 但 stream/chat route 不用 |
| Zod schema (farm-agent) | `src/app/api/types/farm-agent/schemas.ts` | ~15 schema + ~10 infer | `AgentChatStreamSchema` 也覆盖 `ChatRequest`，字段集合与前两者微差 |
| 手写 DTO (H5) | `src/app/api/h5/types/dto.ts` | ~25 interface | 与 `types/h5/schemas.ts` 的 `z.infer` 类型同名重复 |
| 死文件 | `src/app/api/h5/types/schemas.ts` | — | 304 行完整死文件，全项目零导入 |

#### 手写 DTO 散落清单

| 文件 | 内容 | 消费方 | 状态 |
|------|------|------|:--:|
| `src/dto/agent.dto.ts` | `ChatRequest` / `ChatResponse` / `StreamResponse` | 3 个 route | Task 3 删除 |
| `src/dto/knowledge.dto.ts` | `KnowledgeDocumentResponse` + 工具函数 `toDisplayName` | 2 个 route | P2: 响应类型迁 `types/response.dto.ts` |
| `src/app/api/h5/types/dto.ts` | ~25 个 H5 响应 interface | **零导入**（死文件） | Task 2 删除 |
| `src/app/api/h5/types/schemas.ts` | 304 行死文件 | 零导入 | Task 2 删除 |

#### Route 校验现状

| 状态 | Route 数量 | 说明 |
|------|:--:|------|
| 有 `safeParse` | 13 | 运行时校验 ✅ |
| 有 `request.json()` 无 `safeParse` | 18 | 无运行时校验 ❌ |
| GET only / 特殊 | 其余 | 不涉及请求体 |

> **Review 发现**: Plan 原始数据"safeParse=17"偏高，实测约 13 个；`h5/types/dto.ts` 全项目零导入，与 `h5/types/schemas.ts` 同为死文件，Task 2 可直接删除无需逐接口分析。

#### ChatRequest 三份定义差异

| 字段 | `dto/agent.dto.ts` | `hash/schemas.ts` | `farm-agent/schemas.ts` |
|------|:--:|:--:|:--:|
| `messages` | ✅ | ✅ | ✅ role 多了 `"system"` |
| `messages[].name` | `string?` | `string?` | **缺失** ❌ |
| `user` | `{ id, username, role }` | 同左 | `Record<string, unknown>` |
| `project` | `{ id, name, status }` | 同左 | `Record<string, unknown>` |
| `modelConfig` | ✅ | ✅ | ✅ provider 是 `string` 非 enum |
| `type` | ❌ | `z.literal("chat")` 必填 | ❌ |
| `userId` | `number` | `number` | `string \| number` |
| `intent` | ❌ 缺失 | ✅ optional | ✅ optional |
| `interactionResponse` | ❌ | ✅ optional | ❌ |

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | Zod schema 成为 HTTP 边界唯一真相源 | 每个 POST endpoint 有且仅有一个 Zod schema + `safeParse` |
| P0 | 消除手写 DTO | `src/dto/` 目录已删除 ✅ |
| P1 | H5 死文件清理 | `h5/types/dto.ts` + `h5/types/schemas.ts` 已删除 ✅ |
| P2 | `[hash]/route.ts` 内联 interface 消除 | 3 个 interface → `z.infer` 类型 ✅ |

> **非目标**：不改响应体类型（`ChatResponse` 等是出站数据，无需 Zod 校验）；不改 Agent 内部传递类型（`AgentState` 等）；不引入新依赖。

---

## 二、方案选型

### 2.1 收敛策略

| 方案 | 方式 | 风险 | 结论 |
|------|------|------|------|
| **A: Zod 唯一源 + 类型别名兼容** | 删除手写 DTO，从 `z.infer` 导出同名 type alias | 低（结构类型兼容） | ✅ **推荐** |
| B: DTO 唯一源 + schema 从 DTO 生成 | 用 `zod-to-ts` 反推 | 需新依赖 + schema 丢失 `.refine()` 等运行时约束 | ❌ |
| C: 保持双源 + 同步检查脚本 | CI 加 diff 检查 | 维护成本高，治标不治本 | ❌ |

### 2.2 选型理由

- TypeScript 结构类型系统保证 `z.infer<typeof schema>` 与手写 `interface` 字段一致时可互换
- 现有 17 个 route 已在用 `safeParse`，模式成熟可复制
- 不改响应体类型——出站数据不经过用户输入校验，Zod 的价值在入站

---

## 三、架构设计

### 3.1 类型流向（收敛后）

```text
HTTP 请求体
    │
    ▼
Zod Schema（src/app/api/types/*/schemas.ts）
    │  ← safeParse() 运行时校验
    │  ← z.infer 导出类型
    ▼
Route Handler（类型化 body）
    │
    ▼
Agent / Service 层（消费 z.infer 类型或内部类型）
```

### 3.2 类型别名兼容层

`src/dto/agent.dto.ts` 不直接删除，改为 **re-export 层**：

```typescript
// 收敛后的 src/dto/agent.dto.ts
export type { NeuronChatRequest as ChatRequest } from "@/app/api/types"
export interface ChatResponse { /* 保留原 interface */ }
export interface StreamResponse { /* 保留原 interface */ }
```

保证所有 `import { ChatRequest } from "@/dto/agent.dto"` 的消费方无需改代码。

**前提**：`NeuronChatRequest` 与 `ChatRequest` 的字段集必须兼容。当前差异（`messages.role` 多了 `"system"`、`userId` 类型不同）需要 Task 1 先统一。

---

## 四、实施步骤

```text
Task 1: 字段对齐 — 统一 ChatRequest 三份定义差异
         │
         ▼
Task 2: 删除死文件 + H5 DTO 合并
         │
         ▼
Task 3: agent.dto.ts 改为 re-export 兼容层
         │
         ▼
Task 4: [hash]/route.ts 内联 interface 消除
         │
         ▼
Task 5: 19 个未校验 route 补 safeParse
         │
         ▼
Task 6: tsc + eslint 复验
```

### Task 1: 字段对齐 + 抽取 BaseChatSchema

**目的**：统一 `ChatRequest` 在三处的字段定义差异，抽取公共 base schema 使 Zod 成为唯一真相源。

**文件**：2 个

| 差异点 | 当前 | 收敛为 |
|--------|------|--------|
| `messages[].name` | farm-agent schema 缺失 | 补 `name: z.string().optional()` |
| `messages[].role` | hash: `string` / farm-agent: `enum` | 统一 `string`（兼容两种） |
| `user` | hash: 具体结构 / farm-agent: `Record` | 统一具体结构（hash 版本） |
| `project` | hash: 具体结构 / farm-agent: `Record` | 统一具体结构（hash 版本） |
| `userId` | hash: `number` / farm-agent: `string \| number` | 统一 `number`（实际调用方传 number） |
| `modelConfig.provider` | hash: `enum` / farm-agent: `string` | 保持 `enum`（更严格） |
| `intent` | dto 缺失 | dto 补 `intent?: string` |
| `interactionResponse` | farm-agent schema 缺失 | 补（hash 已有） |
| **`type`** | hash 必填 / farm-agent 无 | `BaseChatSchema` 中**可选**，`NeuronChatRequestSchema.extend()` 覆盖为**必填** |

**抽取策略**：

```typescript
// base 层 — 所有共有字段，type 可选
const BaseChatSchema = z.object({
  messages: ..., threadId, user, project, modelConfig,
  type: z.literal("chat").optional(),
  // ... 其余共有字段
})

// hash 路由 — type 必填（dispatch 依赖）
export const NeuronChatRequestSchema = BaseChatSchema.extend({
  type: z.literal("chat"),
  interactionResponse: ...,  // hash 独有
})

// farm-agent 自有 GUI — 沿用 base
export const AgentChatStreamSchema = BaseChatSchema.extend({
  userId: z.union([z.string(), z.number()]).optional(),
})
```

- [x] 对齐 `AgentChatStreamSchema` 与 `NeuronChatRequestSchema` 的字段集
- [x] 抽取 `BaseChatSchema`，两份子 schema 通过 `.extend()` 表达差异
- [x] `tsc --noEmit` 验证

### Task 2: 删除死文件

**目的**：消除死文件。

**文件**：2 个删除

- [x] 删除 `src/app/api/h5/types/schemas.ts`（304 行完整死文件，零导入）
- [x] 删除 `src/app/api/h5/types/dto.ts`（全项目零导入）
- [x] `tsc --noEmit` 验证

### Task 3: DTO 删除 + 响应类型 Zod 化 + Dto 后缀统一

**目的**：Zod 接管后手写 DTO 为 Spring 残余。删 `src/dto/` 目录，响应类型在各域 `schemas.ts` 以 Zod schema + `Dto` 后缀定义。

**文件**：2 删除 + 5 import 修改 + 3 schema 新增 + 22 H5 类型重命名

- [x] 删除 `src/dto/agent.dto.ts` + `src/dto/knowledge.dto.ts`
- [x] `ChatResponseDto` / `StreamResponseDto` / `KnowledgeDocumentResponseDto` → Zod schema（放在 `farm-agent/schemas.ts`）
- [x] 3 个 agent route import 迁移：`ChatRequest` → `AgentChatStreamRequest` / `NeuronChatRequest`
- [x] 2 个 knowledge route import 迁移：`toDisplayName` → `lib/utils.ts`
- [x] H5 响应类型 18 个 + SSE 3 个统一 `Dto` 后缀
- [x] `tsc --noEmit` 验证

### Task 4: [hash]/route.ts 内联 interface 消除

**目的**：3 个本地 interface 与 Zod schema 重复，改用 `z.infer` 类型。

**文件**：1 个

- [x] `HandshakeRequestBody` / `UpdateThreadTitleRequestBody` / `ActivateProjectRequestBody` → Zod 类型
- [x] `PostBody` union 改为全 Zod 类型，消除 `& { type: "chat" }` 交集
- [x] `tsc --noEmit` 验证

### Task 5: 路由补 safeParse（P0+P1 完成，P2 修正）

**P0 (3 路由)**:
- [x] `agent/stream/route.ts`：`AgentChatStreamSchema.safeParse`
- [x] `agent/chat/route.ts`：同上
- [x] `h5/agent/route.ts`：已有 `H5AgentRequestSchema.safeParse`

**P1 (6 路由)**:
- [x] `task/route.ts`、`task/[id]/status/route.ts`
- [x] `seed-catalog/route.ts`、`seed-catalog/price/route.ts`
- [x] `auth/login/route.ts`、`auth/register/route.ts`

**P2 (11 路由，需新建 body schema)**：见上表 |

| # | Route | 对应 Schema | 优先级 |
|---|-------|-----------|--------|
| 5.1 | `agent/stream/route.ts` | `AgentChatStreamSchema` | P0 |
| 5.2 | `agent/chat/route.ts` | `AgentChatStreamSchema` | P0 |
| 5.3 | `agent/chat/threads/route.ts` | 需新建 body schema（不是 `TaskIdSchema`，该 schema 为 query params 校验） | P2 |
| 5.4 | `h5/nongqing/tasks/[id]/route.ts` PATCH | 需新建 body schema（`status, operatorName, actualArea, notes, photos`） | P2 |
| 5.5 | `h5/nongqing/prescriptions/[id]/route.ts` PATCH | 同上 | P2 |
| 5.6 | `h5/production-plan/cost-accounting/route.ts` POST | 需新建 body schema（`plantingArea, cropType, ...` 共 8 字段） | P2 |
| 5.7 | `project/route.ts` | 需新建 | P2 |
| 5.8 | `project/[id]/route.ts` | 需新建 | P2 |
| 5.9 | `task/[id]/route.ts` | 需新建 | P2 |
| 5.10 | `seed-catalog/[id]/route.ts` | 需新建 | P2 |
| 5.11 | `h5/production-plan/plans/[id]/route.ts` | 需新建 | P2 |

> **Phase 5 实施发现**: 原 Plan 将 `tasks/[id]` / `prescriptions/[id]` / `cost-accounting` 标记为 P1（已有 schema），但实际已有 schema 为 query params 校验用（`TaskIdSchema` / `PrescriptionIdSchema` / `CostAccountingRequestSchema`），PATCH body 的字段完全不同，需独立新建 body schema。修正为 P2。

`safeParse` 模式（参考 `[hash]/route.ts` 现有实现）：

```typescript
const rawBody = await request.json()
const parsed = SomeSchema.safeParse(rawBody)
if (!parsed.success) {
  return NextResponse.json(
    { success: false, error: "Invalid request", details: parsed.error.issues },
    { status: 400 }
  )
}
const body = parsed.data
```

### Task 6: 编译 + ESLint 复验

- [ ] `npx tsc --noEmit` 零错误
- [ ] `npx eslint src/` 零 error
- [ ] `as unknown as` 数量 ≤ 23（不因本次变更增加）

### Task 7: 差异回归验证

- [ ] `pnpm test:api` 全量通过（28 端点）

---

## 五、验收标准

- [x] `npx tsc --noEmit` 零错误（10 个存量 Zod-Prisma 缺口已对齐） ✅
- [x] `npx eslint src/` 零 error ✅
- [x] `src/dto/` 目录已删除 ✅
- [x] 两个 h5 死文件已删除 ✅
- [x] 全项目响应类型统一 `Dto` 后缀 ✅
- [x] 18 路由 safeParse 就绪 ✅
- [x] 消费方 import 无 `@/dto/` 引用 ✅
- [ ] 原有业务功能不受影响

---

## 六、ADD-7 审计策略

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/dto/agent.dto.ts` | COMPONENT | COMPONENT_DELETED | 手写 ChatRequest/ChatResponse/StreamResponse | 删除，请求类型由 z.infer 推导，响应类型迁 response.dto.ts | 待实施 |
| `src/app/api/h5/types/dto.ts` | COMPONENT | COMPONENT_DELETED | ~25 手写 interface | 删除（合并到 schemas.ts） | 待实施 |
| `src/app/api/h5/types/schemas.ts` | COMPONENT | COMPONENT_DELETED | 死文件 | 删除 | 待实施 |
| `src/app/api/types/farm-agent/schemas.ts` | COMPONENT | COMPONENT_MODIFIED | 字段集与 hash 不一致 | 对齐 | 待实施 |
| `src/app/api/agent/[hash]/route.ts` | API | API_MODIFIED | 3 个内联 interface | z.infer 类型 | 待实施 |
| `src/app/api/agent/stream/route.ts` | API | API_MODIFIED | 无 safeParse | 补 safeParse | 待实施 |
| `src/app/api/agent/chat/route.ts` | API | API_MODIFIED | 无 safeParse | 补 safeParse | 待实施 |
| 其他 16 个 route 文件 | API | API_MODIFIED | 无 safeParse | 补 safeParse | 待实施 |

---

## 七、风险点

| 风险 | 影响 | 缓解 | 状态 |
|------|------|------|:--:|
| `type` 字段约束冲突 | 统一 schema 后部分路由被 Zod 拒收 | Task 1 抽取 BaseChatSchema，`type` 基础层可选，hash 层 `.extend()` 覆盖为必填 | ✅ |
| `z.infer` 与手写 interface 字段不完全兼容 | tsc 报错 | Task 1 先对齐 9 个差异字段，Task 3 再切换 | ✅ |
| `safeParse` 拒绝之前能通过的畸形请求 | 前端报错 | 400 响应包含 `error.issues` 详情 | ⚠️ 观察 |
| `ChatRequest` 消费方 import 迁移遗漏 | tsc 报错 | `grep -r "@/dto/" src/` = 0 验收 | ✅ |
| `safeParse` 暴露 Zod-Prisma 类型缺口 | tsc 10 errors | Task 6 存量对齐：TaskRequestSchema 补字段、TaskStatusSchema 改 enum、catalogId number→string、null→undefined | ✅ |
| `InterruptSSEPayloadSchema.threadId` 必填暴露 `emitInterrupt` 边界注入缺陷 | 运行时 ZOD_VALIDATE_FAIL 误报 | → `.qoder/plans/2026-07/04/sse-interrupt-threadId-boundary-fix-plan-v1.md`：safeParse 前注入 meta.threadId | ✅ |
