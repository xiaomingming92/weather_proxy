# farm-agent-eslint-fix-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"。不要写完整实现——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-eslint-fix-v1
- **启动时间**: 2026-07-02T12:00:00+08:00
- **主导 AI**: Qoder
- **关联文档**:
  - ADD Route: `.qoder/plans/2026-07/02/farm-agent-eslint-fix-add-route-v1.md`
  - Handoff: `.qoder/plans/2026-07/02/farm-agent-eslint-fix-handoff-v1.md`
  - Review: `.qoder/reviews/eslint-fix-review-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/workers/ocr-worker.ts` | COMPONENT | COMPONENT_MODIFIED | 7 处 `any` 类型 | 定义 OCR 相关 interface 替换 | 待实施 |
| `src/caijuehub/strategies/resolve-tool-params.ts` | COMPONENT | COMPONENT_MODIFIED | 3 处 `any` 类型 | 定义 ToolParam 类型替换 | 待实施 |
| `src/agents/nodes/*.ts` | COMPONENT | COMPONENT_MODIFIED | 多处 `any` + `let` | 具体类型 + `const` | 待实施 |
| `src/app/api/**/route.ts` | API | API_MODIFIED | 多处 `any` 类型 | 内联具体类型 | 待实施 |
| `src/components/chat/*.tsx` | COMPONENT | COMPONENT_MODIFIED | 3 个 hooks 规则违规 | 符合 React 最佳实践 | 待实施 |
| `src/services/index-job-manager.ts` | COMPONENT | COMPONENT_MODIFIED | 2 处 `any` 类型 | 定义 Job 类型替换 | 待实施 |
| `src/lib/append-runtime-finding.ts` | UTIL | UTIL_MODIFIED | crypto import 受限 | `node:crypto` 前缀修正 | 待实施 |
| `src/caijuehub/strategies/service-auth-resolver.ts` | COMPONENT | COMPONENT_MODIFIED | `require()` 风格 import | ES module `import` | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

执行 `npx eslint src/` 产生 **220 个问题**（49 errors + 171 warnings）：

| 规则 | 数量 | 级别 | 说明 |
|------|:--:|:--:|------|
| `@typescript-eslint/no-explicit-any` | **35** | error | 使用 `any` 类型 |
| `prefer-const` | **9** | error | `let` 应改为 `const` |
| `react-hooks/set-state-in-effect` | **2** | error | Effect 内同步 setState |
| `react-hooks/purity` | **1** | error | render 阶段调 impure 函数 |
| `@typescript-eslint/no-require-imports` | **1** | error | require() 风格 import |
| `no-restricted-imports` | **1** | error | 受限 crypto import |
| `@typescript-eslint/no-unused-vars` | **159** | warning | 未使用变量/import |
| `no-restricted-syntax` | **9** | warning | 审计/日志文件未注册 |
| `react-hooks/exhaustive-deps` | **1** | warning | useEffect 依赖缺失 |
| `jsx-a11y/alt-text` | **1** | warning | 图片缺少 alt |

涉及 **35 个文件**。`ocr-worker.ts`（7 errors）、`resolve-tool-params.ts`（3 errors）为最严重文件。

### 1.2 目标

| 优先级 | 目标 | 验收标准 |
|--------|------|---------|
| P0 | 修复全部 49 个 error | `npx eslint src/` 零 error |
| P1 | 修复 P1 级 warning（no-restricted-syntax + react-hooks/exhaustive-deps + jsx-a11y/alt-text） | 11 个 warning 清零 |
| P2 | 清理未使用变量（可选） | `no-unused-vars` warning 按需修复 |

> **非目标**：不改动业务逻辑、不改架构结构、不引入新依赖。

---

## 二、方案选型

### 2.1 修复策略对比

| 方案 | 方式 | 风险 | 结论 |
|------|------|------|------|
| A: 全量 `--fix` | 自动化修复 + 人工 review diff | 可能引入类型错误（`any` 不能用 fix） | ⚠️ 部分可用 |
| **B: 分类修复 + 逐文件验证** | 按规则分组 → 逐文件手动修复 → tsc/eslint 复验 | 低 | ✅ **推荐** |
| C: 全局禁用规则 | 修改 eslint.config.mjs | 降低代码质量 | ❌ |

### 2.2 选型理由

- `prefer-const`（9 个）可用 `--fix` 自动修复
- `no-explicit-any`（35 个）需逐行定义具体类型，不可自动
- `react-hooks` 类（3 个）需理解组件逻辑后重构
- 其他杂项（2 个）单文件简单修改

---

## 三、架构设计

本次变更不涉及架构变更。所有修改均为类型注解替换、import 风格调整、React hooks 合规修复——不改变运行时行为。

> **无架构变更声明**：本轮仅做 lint 合规修复，不新增模块，不修改数据流，不影响部署拓扑。

---

## 四、实施步骤

```
Task 1: 自动修复 (prefer-const + unused-vars) ── 1 分钟
         │
         ▼
Task 2: 修复 no-explicit-any (35个, 19文件) ── 核心耗时
         │
         ▼
Task 3: 修复 React hooks 问题 (3个, 2文件) ── 需理解组件逻辑
         │
         ▼
Task 4: 修复杂项 error (2个, 2文件)
         │
         ▼
Task 5: 修复 warning (no-restricted-syntax + alt-text + deps)
         │
         ▼
Task 6: tsc --noEmit + eslint 复验
```

### Task 1: 自动修复

**文件**: 8 个（涉及 `prefer-const` 的文件）

- [ ] 执行 `npx eslint --fix src/` 自动修复 `prefer-const` 全部 9 个 + 部分 `no-unused-vars`
- [ ] `git diff` 确认变更合理
- [ ] `npx tsc --noEmit` 验证无类型破坏

### Task 2: 修复 no-explicit-any（核心）

**文件**: 19 个

| # | 文件 | 数量 | 修复策略 |
|---|------|:--:|------|
| 2.1 | `src/workers/ocr-worker.ts` | 7 | 定义 OCR 相关 interface |
| 2.2 | `src/caijuehub/strategies/resolve-tool-params.ts` | 3 | 定义 ToolParam 类型 |
| 2.3 | `src/agents/nodes/structured-output.ts` | 2 | 用已知类型替换 |
| 2.4 | `src/agents/tool-node-wrapper.ts` | 2 | 用 LangGraph 内置类型 |
| 2.5 | `src/agents/tools/impl/seed-catalog.ts` | 2 | 定义 SeedCatalog 类型 |
| 2.6 | `src/agents/agent-runner.ts` | 2 | 用 AgentState 类型 |
| 2.7 | `src/agents/nodes/coordination-dialogue.ts` | 1 | 定义 DialogueResult |
| 2.8 | `src/agents/nodes/intention.ts` | 1 | 指定 IntentionInput |
| 2.9 | `src/agents/tools/impl/web-search.ts` | 1 | SearchResult |
| 2.10 | `src/app/api/agent/[hash]/route.ts` | 1 | 内联类型 |
| 2.11 | `src/app/api/agent/chat/route.ts` | 1 | 内联类型 |
| 2.12 | `src/app/api/agent/stream/route.ts` | 2 | 内联类型 |
| 2.13 | `src/app/api/h5/agent/route.ts` | 1 | 内联类型 |
| 2.14 | `src/app/api/h5/nongqing/prescriptions/[id]/route.ts` | 2 | 内联类型 |
| 2.15 | `src/app/api/h5/nongqing/tasks/[id]/route.ts` | 2 | 内联类型 |
| 2.16 | `src/app/api/h5/production-plan/variety-recommend/route.ts` | 1 | 内联类型 |
| 2.17 | `src/app/api/seed-catalog/route.ts` | 2 | 内联类型 |
| 2.18 | `src/services/index-job-manager.ts` | 2 | 定义 Job 类型 |

- [ ] 逐文件修复，修复后 `npx eslint --no-ignore <file>` 验证
- [ ] 每批完成后 `npx tsc --noEmit` 验证类型

### Task 3: 修复 React hooks

**文件**: 2 个

- [ ] `src/components/chat/evidence-chain-panel.tsx` L54：`setState` in effect → 改为 ref 或 useMemo 计算
- [ ] `src/components/chat/node-progress-timeline.tsx` L315：`Date.now` in render → 改为 useEffect 内调用
- [ ] `src/components/chat/node-progress-timeline.tsx` L444：`setState` in effect → 同 evidence-chain-panel

### Task 4: 修复杂项 error

**文件**: 2 个

- [ ] `src/caijuehub/strategies/service-auth-resolver.ts` L127：`require()` → `import` ES module
- [ ] `src/lib/append-runtime-finding.ts` L14：crypto import 路径修正（使用 `node:crypto`）

### Task 5: 修复 warning

**文件**: 3 类

- [ ] `no-restricted-syntax`（9 个日志文件）：确认 ①裁决层契约已更新 ② caijue.toml 已注册 ③ ADD-7 已记录（或标注为已知存量、不需处理）
- [ ] `react-hooks/exhaustive-deps`（1 个）：补充缺失依赖项（注意无限循环风险）
- [ ] `jsx-a11y/alt-text`（1 个）：`knowledge-base-panel.tsx` 图片加 alt 属性

### Task 6: 编译 + ESLint 复验

- [x] `npx tsc --noEmit` 零错误
- [x] `npx eslint src/` 零 error
- [ ] warning 数量从 171 降至 ≤ 160（no-unused-vars 不在本次 P0 范围）

### Task 7: 消除 `as unknown as` 双重 cast — 第一轮（10 处）

**文件**: 10 个

- [x] D 类：3 处 `as unknown[]` → `Array.isArray()` 运行时检查（tool-node-wrapper, reasoning, response）
- [x] C 类：5 处 JSON import `as unknown as` → `.default as`（climate-zone-lookup ×2, climate-zone-tools ×2, city-coords）
- [x] E 类：2 处枚举对齐（InteractionPoint.type + InteractionPointOutput.type → InterruptType 枚举）

### Task 8: 消除 `as unknown as` — JsonSerializable 边界（3 处）

**文件**: 3 个

- [x] `agent-chain-tracer.ts`：定义 `JsonSerializable` 类型，`sanitizeSnapshot` 内部收敛 cast
- [x] `chat-persistence.ts`：`nodes as unknown as Prisma.InputJsonValue` → 单步 cast
- [x] `prompts/interaction-point-detection.ts`：validTypes 改用 `InterruptType[]`

### Task 9: 消除 `as unknown as` — DTO + Zod 联动（8 处）

**文件**: 4 个

- [x] `dto/agent.dto.ts`：ChatRequest 补齐 `intent` 字段
- [x] `[hash]/route.ts`：5 处 body cast 消除 + `handleChatPOST` 改用 `NeuronChatRequest`
- [x] `schemas.ts`（hash）：`NeuronChatRequestSchema` 补全全部字段
- [x] `[hash]/route.ts`：`handleUpdateThreadTitlePOST` 改用 `UpdateThreadTitleRequest` + body.type dispatch 提取变量

### Task 10: 消除 `as unknown as` — Prisma + 域迭代 + 杂项（12 处）

**文件**: 7 个

- [x] Prisma InputJsonValue ×4：双 cast → 单步 cast（prescriptions/[id] ×2, tasks/[id] ×2）
- [x] `global-state.ts`：9 个 `interface` → `type`（七域快照 + Meta + GlobalSystemState），消除 index signature 差异
- [x] `chat-store.ts`：`updateLastAssistantStructuredData` 参数收窄为 `Partial<StructuredAgentResponse>`
- [x] `stream/route.ts`：`body` 直接用 Zod 推导类型，消除 body.userId cast

### Task 11: `as unknown as` 残留分类（23 处 — 合法类型边界，本轮不消除）

| 根因 | 数量 | 消除方式 |
|------|:--:|----------|
| LangGraph 边界 | 7 | 需 LangGraph 包装层 Plan |
| fetch proxy | 5 | 需统一 fetch 适配层 Plan |
| 消息类型桥接 | 3 | 需统一消息序列化层 Plan |
| LLM response 解析 | 2 | 需定义 LLM response DTO |
| Stream chunk | 2 | 需 stream 类型包装 |
| 第三方库（TOML/OCR/Prisma/layer2） | 4 | 库签名差异，cast 必要 |

### Task 12: unused-vars 清理（161 → 43）

- [x] `eslint.config.mjs`：添加 `_` 前缀忽略规则
- [x] 84 处未使用 import/类型/函数删除（72 文件）
- [x] 34 处接口强制参数 `_` 前缀处理

### Task 13: `RunnableConfig` 泛型升级 — 消除 route 层 4 个 `as any`

**根因**：验收时发现 `npx eslint src/` 报 4 error（非 0），全部为 `no-explicit-any`。根因是 3 个 route 文件调用 `streamAgent()`/`runAgent()` 时参数类型不匹配，用 `as any` 绕过。

**方案**：利用 LangChain `RunnableConfig<ConfigurableFieldType>` 自带的泛型参数，定义 `AgentConfigurable` 接口精确约束 `configurable` 字段。

**文件**: 5 个

- [x] `src/agents/agent-runner.ts`：定义 `AgentConfigurable` 接口 + 函数签名改为 `RunnableConfig<AgentConfigurable>` + 内部消除 2 处 `as Record<string, unknown>` / `as GlobalStateProvider`
- [x] `src/agents/audit-wrapper.ts`：消除 2 处 `as GlobalStateProvider` / `as CognitiveEventBus`
- [x] `src/app/api/agent/[hash]/route.ts`：`globalStateProvider` + `eventBus` 从 input 移到 config.configurable，删 `as any`
- [x] `src/app/api/agent/chat/route.ts`：删 input 的 `as any`，`result` 类型改为具体类型
- [x] `src/app/api/agent/stream/route.ts`：删 input `as any` + config `as any`

---

## 五、验收标准

- [x] `npx eslint src/` error = 0
- [x] `npx tsc --noEmit` 零类型错误
- [x] `no-explicit-any` 从 35 → 0
- [x] `prefer-const` 从 9 → 0
- [x] `react-hooks` error 从 3 → 0
- [x] 杂项 error（no-require-imports + no-restricted-imports + prefer-const）→ 0
- [x] `as unknown as` 从 ~60+ → 23（消除 ~37 处，剩余均为合法类型边界）
- [x] Task 13 完成后 `no-explicit-any` 4 → 0（route 层 `as any` 消除）
- [x] 原有业务功能不受影响（仅类型注解/import 风格变更，8 个端点全部通过 curl 验证 + proxy 正则分流修复）

### Task 14: 运行时端点验证

**目的**：确认 ESLint 类型修改后，改动的 6 个 Route 文件对应的端点仍正常响应。

| # | 端点 | 方法 | 改动文件 | 验证方式 |
|---|------|------|---------|---------|
| 14.1 | `/api/h5/nongqing/prescriptions/{id}` | GET | prescriptions/[id]/route.ts | curl 200 + JSON 响应 |
| 14.2 | `/api/h5/nongqing/tasks/{id}` | GET | tasks/[id]/route.ts | curl 200 + JSON 响应 |
| 14.3 | `/api/h5/production-plan/variety-recommend` | POST | variety-recommend/route.ts | curl 200 + JSON 响应 |
| 14.4 | `/api/agent/chat` | POST | agent/chat/route.ts | curl 200（含 agent 调 LLM）|
| 14.5 | `/api/agent/stream` | POST | agent/stream/route.ts | curl SSE 响应 |
| 14.6 | `/api/agent/{hash}` | POST | agent/[hash]/route.ts | curl handshake 200 |
| 14.7 | 首页加载 | GET | / | HTTP 200 + 无编译错误 |
| 14.8 | `pnpm dev` 无运行时异常 | — | 全部文件 | 控制台零异常 |

- [x] 14.1 `/api/h5/nongqing/prescriptions/{id}` GET 200（prisma cast 降级正确）
- [x] 14.2 `/api/h5/nongqing/tasks/{id}` GET 200（prisma cast 降级正确）
- [x] 14.3 `/api/h5/production-plan/variety-recommend` POST 200（LLM response cast 正确）
- [x] 14.4 `/api/agent/chat` POST 200（`result: any` 消除正确）
- [x] 14.5 `/api/agent/chat/stream` POST 200（`as any` 消除 + proxy 修复）
- [x] 14.6 `/api/agent/{hash}` handshake POST 200（hash 路由分流正确）
- [x] 14.7 首页 `/` GET 200
- [x] 14.8 `pnpm dev` 控制台无运行时异常（含 proxy 正则分流修复）

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| ADD Route | `.qoder/plans/2026-07/02/farm-agent-eslint-fix-add-route-v1.md` | ✅ |
| Handoff | `.qoder/plans/2026-07/02/farm-agent-eslint-fix-handoff-v1.md` | ✅ |
| Review | `.qoder/reviews/eslint-fix-review-v1.md` | ✅ |
| **下游 Plan** | `.qoder/plans/2026-07/02/farm-agent-zod-dto-convergence-plan-v1.md` | ✅ 实施完成 — 依赖本 Plan 的 RunnableConfig 泛型升级 + lint-clean 基线 |