# farm-agent — Zod-DTO 收敛 交接手册

> **适用场景**：单轮变更。三套并行 ChatRequest 类型定义 → Zod 唯一源，手写 DTO 全部删除。

---

## 1. 交接前状态

- 三套并行的 HTTP 请求体类型定义：手写 `agent.dto.ts` + Zod `hash/schemas.ts` + Zod `farm-agent/schemas.ts`
- 加字段需改 2-3 处，容易漂移
- 18+ 个 POST route 无运行时 `safeParse` 校验
- `src/dto/` 目录含 2 个手写 DTO 文件（Spring 残余）
- 2 个 H5 死文件（`h5/types/dto.ts` + `h5/types/schemas.ts`，零导入）
- 全项目响应类型命名不统一（部分无 Dto 后缀）

---

## 2. 交接后状态（目标）

- Zod 成为 HTTP 边界唯一真相源：请求类型 `z.infer` 自动推导，响应类型以 `Dto` 后缀命名
- `BaseChatSchema` 抽取公共字段，`NeuronChatRequestSchema` / `AgentChatStreamSchema` 通过 `.extend()` 派生
- 32 个 route 含 `safeParse` 运行时校验
- `src/dto/` 目录已删除，零残留引用
- 2 个 H5 死文件已删除
- 全项目 24 个响应类型统一 `Dto` 后缀
- `TaskStatus` z.enum 单源（`transitions.ts` → `schemas.ts`）

---

## 3. 改动清单

| # | 文件 | 操作 | 内容 |
|---|------|------|------|
| 1 | `src/app/api/types/farm-agent/schemas.ts` | 修改 | 抽取 `BaseChatSchema` + `ChatResponseDtoSchema` 等 3 DTO |
| 2 | `src/app/api/types/hash/schemas.ts` | 修改 | `NeuronChatRequestSchema = BaseChatSchema.omit().extend()` |
| 3 | `src/app/api/types/h5/schemas.ts` | 修改 | 18 个响应类型统一 Dto 后缀 |
| 4 | `src/app/api/types/sse/schemas.ts` | 修改 | 3 个 SSE payload 统一 Dto 后缀 |
| 5 | `src/app/api/agent/stream/route.ts` | 修改 | 删 `as any`，改 `AgentChatStreamSchema.safeParse` |
| 6 | `src/app/api/agent/chat/route.ts` | 修改 | 同上 |
| 7 | `src/app/api/agent/[hash]/route.ts` | 修改 | 删 3 手写 interface，`PostBody` 改用 Zod 类型 |
| 8 | `src/app/api/h5/agent/route.ts` | 已有 | `H5AgentRequestSchema.safeParse`（存量） |
| 9 | `src/app/api/task/route.ts` 等 6 个 | 修改 | P1: `safeParse` 补全 |
| 10 | `src/app/api/h5/` 3 个 PATCH | 修改 | P2: 新建 `TaskCompleteSchema` 等 + `safeParse` |
| 11 | `src/app/api/agent/chat/threads/` 等 6 个 | 修改 | P2: inline `z.object` + `safeParse` |
| 12 | `src/lib/transitions.ts` | 修改 | `TASK_STATUS_VALUES = [...] as const` 单源 |
| 13 | `src/lib/utils.ts` | 修改 | `toDisplayName` 迁入（来自 `knowledge.dto.ts`） |
| 14 | `src/dto/agent.dto.ts` | 删除 | 请求类型由 `z.infer` 推导 |
| 15 | `src/dto/knowledge.dto.ts` | 删除 | 类型迁 `schemas.ts`，函数迁 `lib/utils.ts` |
| 16 | `src/app/api/h5/types/dto.ts` | 删除 | 死文件（零导入） |
| 17 | `src/app/api/h5/types/schemas.ts` | 删除 | 304 行死文件 |
| 18 | `eslint.config.mjs` | 修改 | `no-unused-vars` warn→error；`jsx-a11y/alt-text` off |
| 19 | `src/caijuehub/caijue.toml` | 修改 | 补全 9 条 logger 模块注册 |
| 20 | `src/components/chat/status-indicator.tsx` | 修改 | `_MatrixRain`→`MatrixRain` |
| 21 | `src/components/chat/chat-panel.tsx` | 修改 | `handleSend` 包 `useCallback` |
| 22 | `src/agents/nodes/kb-conflict-aggregator.ts` | 修改 | 删未使用 `userDecision` 变量 |
| 23 | `tests/` | 变更 | `src/tests/` → `tests/` 统一 |

---

## 4. 回滚方案

```bash
git reset --hard HEAD~4
```
无数据迁移，纯代码变更。

---

## 5. 执行前置检查

- [x] `npx tsc --noEmit` 零错误
- [x] `npm run lint` src/ 零 error（10 warnings 保留）
- [x] `grep -r "@/dto/" src/` = 0（DTO 零残留）
- [x] 全项目 Dto 后缀统一（24 个类型）
- [ ] `pnpm test:api` 手动执行（LLM 耗时约 5min）

---

## 6. 执行步骤摘要

```text
Phase 1 ── BaseChatSchema 抽取 + 字段对齐
            │
            ▼
Phase 2 ── 删除 h5 死文件（2 个）
            │
            ▼
Phase 3 ── DTO 删除 + 24 类型 Dto 后缀统一
            │
            ▼
Phase 4 ── [hash]/route.ts 内联 interface 消除
            │
            ▼
Phase 5 ── 18 route safeParse 补全（P0+P1+P2）
            │
            ▼
Phase 6 ── tsc/eslint 验证（0 error）
            │
            ▼
Phase 7 ── pnpm test:api 回归（手动执行）
```

---

## 7. 关键风险点

| 风险 | 影响 | 缓解 |
|------|------|------|
| `safeParse` 拒绝之前能通过的畸形请求 | 前端报 400 | 400 响应含 `details: parsed.error.issues` |
| Prisma schema 与 Zod schema 类型缺口 | seed-catalog 等 tsc 报错 | Phase 6 已对齐全部 10 个存量缺口 |
| `no-unused-vars` warn→error 暴露存量未用变量 | CI 新增 error | 已修复 3 处，剩余 46 处为存量（非本次引入） |

---

## 8. 恢复上下文审计查询（新 AI Session 首次启动必读）

> 共 9 条审计记录可恢复完整开发上下文。

### 总体一键恢复

```text
query_audit_logs({ planKeyword: "zod-dto-convergence" })
```
→ 预期返回 ≥ 8 条记录

### 逐文件审计查询

```text
query_audit_logs({ targetId: "src/app/api/types/farm-agent/schemas.ts" })
→ 预期 CREATE: BaseChatSchema + ChatResponseDtoSchema + ...

query_audit_logs({ targetId: "src/dto/" })
→ 预期 DELETE: Spring 残余 DTO 全部删除

query_audit_logs({ targetId: "eslint.config.mjs" })
→ 预期 CREATE: no-unused-vars error + jsx-a11y off

query_audit_logs({ targetId: "src/caijuehub/caijue.toml" })
→ 预期 CREATE: 9 条 logger 模块注册
```

### SQL 管理员验证

```sql
SELECT action, "targetType", "targetId", reason, "createdAt"
FROM "AuditLog"
WHERE detail::text LIKE '%zod-dto-convergence%'
ORDER BY "createdAt" DESC;
```

### 恢复判定标准

- action 命中数 ≥ 8
- grep 验证命令：

```bash
grep -R "zod-dto-convergence" .qoder/specs/
grep -R "BaseChatSchema" src/app/api/types/
grep -R "safeParse" src/app/api/ | wc -l
```

---

## 9. 后置确认

- [x] `npx tsc --noEmit` 通过（0 errors）
- [x] `npm run lint` src/ 零 error（10 warnings 保留）
- [x] 所有文件改动已记录 ADD-7 审计（`query_audit_logs({ planKeyword: "zod-dto-convergence" })` 可回查）
- [x] `grep -r "@/dto/" src/` = 0（DTO 零残留）
- [x] 全项目 Dto 后缀统一（24 个类型）
- [ ] `pnpm test:api` 28 端点全量通过（手动执行）

---

### 脱敏要求

Handoff 文档中 **禁止出现** 以下类型的硬编码值：
- 数据库密码（`POSTGRES_PASSWORD`）
- Chroma auth token（`CHROMA_AUTH_TOKEN`）
- JWT 密钥（`JWT_SECRET`）
- API Key（`OPENAI_API_KEY_*`）

所有凭据值应通过 `${ENV_VAR}` 引用，并标注"值见 `.env.development` / `.env.production`"。
