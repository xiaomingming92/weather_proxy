# farm-agent-eslint-fix-add-route-v1

> **定位**：Plan → ADD 九阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行“验证并更新项目状态”。
>
> **绑定**：Plan: `.qoder/plans/2026-07/02/farm-agent-eslint-fix-plan-v1.md` · Handoff: `.qoder/plans/2026-07/02/farm-agent-eslint-fix-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan 就绪。

**输入**：
- Plan: `.qoder/plans/2026-07/02/eslint-fix-plan-v1.md`（✅ MCP 已生成）
- `find_related_docs` 检索结果：无匹配项目文档（ESLint 修复属代码质量任务，不需更新架构/需求文档）

**动作**：
1. ✅ Plan 已通过 MCP `create_plan` 落盘
2. ✅ `find_related_docs` 已调用，无需更新项目文档（已声明理由）
3. ⬜ 生成 ADD Route（本文档）
4. ⬜ 生成 Handoff
5. ⬜ 生成 Review

**产出**：
- [x] Plan 文件已创建
- [x] 项目文档无需更新（ESLint 修复不涉及架构/需求变更，已声明）
- [ ] Handoff 就绪
- [ ] DPS 闸门通过（≥ 85）

### §0.8 DPS 闸门

调用 `check_dps({ planKeyword: "eslint-fix" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**目的**：ESLint 修复属于代码质量任务，不新增业务阶段，不扩展 AgentAuditPhase。

**动作**：
1. ESLint 修复不涉及新增业务阶段 → `AgentAuditPhase` 联合类型**不作扩展**
2. 无需新增 logger 文件

**产出**：
- [x] 确认无需扩展 AgentAuditPhase
- [x] 确认无需新建 logger

| Phase | 使用场景 | Task |
|-------|---------|------|
| — | 无新增业务阶段 | — |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用。

**动作**：
1. 确认 `agentAudit(phase, detail, extra?)` 函数存在
2. 确认 `record_dev_operation` MCP 工具可用（用于 ADD-7 文件操作审计）

**产出**：
- [ ] 确认 `agentAudit()` 通道正常（本次不新增调用，仅确认可用）
- [ ] 确认 `record_dev_operation` 可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan §4 的 Task 依赖拓扑，逐 Task 修复 ESLint 问题。

### §3.0 前置守卫

调用 `check_add_route_status` 确认 add-route 文件存在。

- [ ] `check_add_route_status` 通过

### Task 映射表

| # | Task | 涉及文件数 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|:--:|-----------|-----------|------|------|
| 1 | 自动修复 (`eslint --fix`) | 8 | 无（自动化） | — | 无 | ⬜ |
| 2 | 修复 `no-explicit-any` | 19 | `record_dev_operation` 每文件 | — | Task 1 | ⬜ |
| 3 | 修复 React hooks | 2 | `record_dev_operation` 每文件 | — | Task 2 | ⬜ |
| 4 | 修复杂项 error | 2 | `record_dev_operation` 每文件 | — | Task 2 | ⬜ |
| 5 | 修复 warning | 3 | `record_dev_operation` 每文件 | — | Task 2 | ⬜ |
| 6 | `tsc --noEmit` + ESLint 复验 | 全部 | `check_spec_sync` | — | Task 1-5 | ✅ |
| 7 | `as unknown as` 消除第一轮 | 10 | `record_dev_operation` | — | Task 6 | ✅ |
| 8 | `as unknown as` JsonSerializable 边界 | 3 | `record_dev_operation` | — | Task 7 | ✅ |
| 9 | `as unknown as` DTO + Zod 联动 | 4 | `record_dev_operation` | — | Task 8 | ✅ |
| 10 | `as unknown as` Prisma + 域迭代 + 杂项 | 7 | `record_dev_operation` | — | Task 9 | ✅ |
| 11 | `as unknown as` 残留分类 | — | 文档记录 | — | Task 10 | ✅ |

### 依赖拓扑

```
Task 1 (eslint --fix)
    │
    ▼
Task 2 (no-explicit-any, 35个) ──┬──→ Task 3 (React hooks, 并行)
                                 ├──→ Task 4 (杂项 error, 并行)
                                 └──→ Task 5 (warning, 并行)
                                          │
                                          ▼
                                     Task 6 (复验)
```

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计
3. 将该 Task 在本文档中标记为 ✅

**产出**：
- [ ] 全部 Task `[T]` 项通过
- [ ] 每个文件有 `record_dev_operation` 记录
- [ ] `check_spec_sync` 确认变更一致

---

## Step 3.5：实现审查

**目的**：代码完成后，验证意图与实现无语义鸿沟。

**动作**：
1. 逐项验证 Plan §五 验收标准全部通过
2. 生成 `review-implementation.md`

**产出**：
- [ ] 验收标准全部通过
- [ ] `review-implementation.md` 已生成

---

## Step 4：审计数据验证

**目的**：编译 + ESLint 完整性检查。

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. `npx eslint src/` —— 零 error
3. 调用 `check_spec_sync` 确认变更一致

**产出**：
- [ ] `tsc --noEmit` 通过
- [ ] `npx eslint src/` 零 error
- [ ] `check_spec_sync` 通过

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "eslint-fix" })`。

| RAHS | 判定 | 动作 |
|------|:--:|------|
| ≥ 90 | 🟢 | 进入 Step 5 |

- [ ] RAHS 已通过（≥ 90）

---

## Step 5：AI 自动合规检查

**目的**：扫描全部修改文件的 ADD-1~ADD-7 合规性。

**动作**：
1. 对修改文件调用 `check_add_compliance`

**产出**：
- [ ] 合规报告已生成

---

## Step 6-7：从审计数据定位问题 + 修复

> **仅当 Step 4/5 发现异常时进入。**（ESLint 修复预期无异常）

---

## Step 8：收敛判断 + Handoff 更新 + Step 0 第二阶段

**目的**：功能收敛判定，更新 Handoff。

**动作**：
1. 收敛判断：全部 `[T]` 项通过 + RAHS ≥ 90
2. RAHS 最终核定
3. 更新 Handoff
4. Step 0 第二阶段：确认无架构文档需更新

**产出**：
- [ ] 收敛判定结果
- [ ] Handoff 已更新
- [ ] 架构文档无需更新（已确认）

---

## Step 9：Report Closure

> **不适用。** 本 Plan 非 runtime-fix 类型。

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/workers/ocr-worker.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/caijuehub/strategies/resolve-tool-params.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/agents/nodes/structured-output.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/agents/tool-node-wrapper.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/agents/tools/impl/seed-catalog.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/agents/agent-runner.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/agents/nodes/coordination-dialogue.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/agents/nodes/intention.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/agents/tools/impl/web-search.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/app/api/agent/[hash]/route.ts` | MODIFY | 2 | API | ⬜ |
| `src/app/api/agent/chat/route.ts` | MODIFY | 2 | API | ⬜ |
| `src/app/api/agent/stream/route.ts` | MODIFY | 2 | API | ⬜ |
| `src/app/api/h5/agent/route.ts` | MODIFY | 2 | API | ⬜ |
| `src/app/api/h5/nongqing/prescriptions/[id]/route.ts` | MODIFY | 2 | API | ⬜ |
| `src/app/api/h5/nongqing/tasks/[id]/route.ts` | MODIFY | 2 | API | ⬜ |
| `src/app/api/h5/production-plan/variety-recommend/route.ts` | MODIFY | 2 | API | ⬜ |
| `src/app/api/seed-catalog/route.ts` | MODIFY | 2 | API | ⬜ |
| `src/services/index-job-manager.ts` | MODIFY | 2 | COMPONENT | ⬜ |
| `src/components/chat/evidence-chain-panel.tsx` | MODIFY | 3 | COMPONENT | ⬜ |
| `src/components/chat/node-progress-timeline.tsx` | MODIFY | 3 | COMPONENT | ⬜ |
| `src/caijuehub/strategies/service-auth-resolver.ts` | MODIFY | 4 | COMPONENT | ⬜ |
| `src/lib/append-runtime-finding.ts` | MODIFY | 4 | UTIL | ⬜ |
| 日志文件 × 9（`no-restricted-syntax`） | NOOP | 5 | — | ⬜ |
| `src/components/knowledge/knowledge-base-panel.tsx` | MODIFY | 5 | COMPONENT | ⬜ |
| `src/agents/nodes/reasoning.ts` | MODIFY | 7 | COMPONENT | ✅ |
| `src/agents/nodes/response.ts` | MODIFY | 7 | COMPONENT | ✅ |
| `src/lib/climate-zone-lookup.ts` | MODIFY | 7 | UTIL | ✅ |
| `src/agents/tools/impl/climate-zone-tools.ts` | MODIFY | 7 | COMPONENT | ✅ |
| `src/agents/types/structured-output.ts` | MODIFY | 7 | COMPONENT | ✅ |
| `src/agents/prompts/types.ts` | MODIFY | 7 | COMPONENT | ✅ |
| `src/agents/nodes/interaction-point-detection.ts` | MODIFY | 7 | COMPONENT | ✅ |
| `src/agents/prompts/interaction-point-detection.ts` | MODIFY | 8 | COMPONENT | ✅ |
| `src/lib/agent-chain-tracer.ts` | MODIFY | 8 | UTIL | ✅ |
| `src/services/chat-persistence.ts` | MODIFY | 8 | COMPONENT | ✅ |
| `src/dto/agent.dto.ts` | MODIFY | 9 | COMPONENT | ✅ |
| `src/app/api/types/hash/schemas.ts` | MODIFY | 9 | API | ✅ |
| `src/agents/global-state.ts` | MODIFY | 10 | COMPONENT | ✅ |
| `src/stores/chat-store.ts` | MODIFY | 10 | COMPONENT | ✅ |
| `src/components/chat/chat-panel.tsx` | MODIFY | 10 | COMPONENT | ✅ |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY | 10 | API | ✅ |
