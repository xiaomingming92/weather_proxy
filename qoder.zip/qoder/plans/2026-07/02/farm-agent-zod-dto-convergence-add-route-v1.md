# farm-agent-zod-dto-convergence-add-route-v1

> **定位**：Plan → ADD 十阶段执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"，包含 `check_spec_sync` 文档-代码交叉校验。适用于后端系统、多层管线、审计合规场景。
>
> **绑定**：Plan: `.qoder/plans/2026-07/02/farm-agent-zod-dto-convergence-plan-v1.md` · Spec: `.qoder/specs/farm-agent-zod-dto-convergence/`（待创建） · Tasks: `.qoder/specs/farm-agent-zod-dto-convergence/tasks.md`（待创建） · Handoff: `.qoder/plans/2026-07/02/farm-agent-zod-dto-convergence-handoff-v1.md`（待创建）

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全，项目文档反映即将实现的变更。

**动作**：
1. 确认 Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
2. 本次变更属纯代码重构（DTO 体系收敛），**无需更新项目知识库文档**——不改变业务逻辑、不增减 API 端点、不修改架构设计。《神经元GUI-API对接文档》《瑞丰耘H5小程序API对接文档》等已经在 ESLint 修复阶段同步至 v1.7/v5.4/v1.4，与本次变更一致
3. 确认 Handoff 就绪（含 round 边界、ADD-7 策略表、回滚方案）

**产出**：
- [ ] Specs 三元组路径确认：`.qoder/specs/farm-agent-zod-dto-convergence/`
- [ ] 项目文档无需更新——不改变外部合约（请求/响应 schema、端点签名不变）
- [ ] Handoff 就绪

### §0.8 DPS 闸门（上游文档质量校验）

调用 `check_dps({ planKeyword: "zod-dto-convergence" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |
| 70–84 | 🟡 | 回退补齐短板 |
| < 70 | 🔴 | 回退细化 Plan |

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计阶段定义

**目的**：本次为纯 DTO 类型收敛 + schema 统一，不涉及新的业务阶段。

**动作**：
1. 本次变更不新增业务阶段——Zod schema 对齐、死文件删除、safeParse 补全是基础设施加固
2. 现有 `agentAudit` 调用无需修改
3. 新增 safeParse 后 route 层可按现有 pattern 嵌入审计（`agentAuditRequest` / `agentAuditResponse` 已存在）

**产出**：
- [ ] 无需扩展 `AgentAuditPhase`（纯基础设施变更，不新增业务阶段）

---

## Step 2：审计基础设施确认

**动作**：
1. 确认 `agentAudit()` 通道可用——本次不新增调用点
2. 已有审计通道：`agentAuditRequest`（入站）、`agentAuditResponse`（出站）、`chatPersistAudit`（持久化）

**产出**：
- [ ] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 Plan 的 Task 依赖拓扑，逐 Task 实施代码 + 嵌入审计点。

### §3.0 前置守卫

调用 `check_add_route_status` 确认 add-route 文件有效存在。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 新增 Phase | 依赖 | 状态 |
|---|------|------|-----------|-----------|------|------|
| 1 | 字段对齐 + BaseChatSchema | `src/app/api/types/farm-agent/schemas.ts` | `agentAudit("SCHEMA_ALIGNED", ...)` | — | 无 | ⬜ |
| 2 | 删除死文件 | `src/app/api/h5/types/dto.ts`, `schemas.ts` | 无（删除操作） | — | Task 1 | ⬜ |
| 3 | 删除 agent.dto.ts，响应迁 types/ | `src/dto/agent.dto.ts`, `knowledge.dto.ts` + `types/response.dto.ts` + `lib/utils.ts` + 5 个消费方 import | `agentAudit("DTO_CONVERGED", ...)` | — | Task 1 | ⬜ |
| 4 | [hash]/route.ts 内联 interface 消除 | `src/app/api/agent/[hash]/route.ts` | 无（类型替换） | — | Task 1 | ⬜ |
| 5 | 19 route 补 safeParse | 19 个 route 文件 | `agentAuditRequest` / `agentAuditResponse` 已有 | — | Task 1-4 | ⬜ |
| 6 | tsc + eslint 复验 | 全部文件 | 无 | — | Task 1-5 | ⬜ |
| 7 | pnpm test:api 回归 | `tests/test-api.sh` | 无 | — | Task 1-6 | ⬜ |

### 依赖拓扑

```
Task 1 (schema 对齐) ── 基础层，所有下游依赖
    ├── Task 2 (删死文件，依赖 Task 1 tsc 通过)
    ├── Task 3 (删 dto + 迁响应类型，依赖 Task 1)
    ├── Task 4 (hash 内联消除，依赖 Task 1)
    └── Task 5 (补 safeParse，依赖 Task 1-4)
            │
            └── Task 6 (复验) ──→ Task 7 (pnpm test:api)
```

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计
3. 将该 Task 在 `tasks.md` 中逐子项勾选为 `[x]`

**产出**：
- [ ] 全部 Task 的 `[T]` 项通过
- [ ] 每个文件有 `record_dev_operation` 记录
- [ ] `check_spec_sync` 确认 spec 文档与实际代码一致

---

## Step 3.5：实现审查

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 生成 `review-implementation.md`
3. `[T]` 项通过后，生成 `review-runtime.md`（含 `[R]` 待验证清单 = `pnpm test:api`）

**产出**：
- [ ] checklist.md 全部 `[T]` 项已通过
- [ ] review-implementation.md 已生成
- [ ] review-runtime.md 已生成

---

## Step 4：审计数据验证

**动作**：
1. `npx tsc --noEmit`
2. `npx eslint src/`
3. `check_phase_symmetry`
4. `check_failure_path`
5. `check_spec_sync`

**产出**：
- [ ] tsc 零错误
- [ ] eslint 零 error
- [ ] 阶段对称性验证通过
- [ ] 失败路径审计等价验证通过

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "zod-dto-convergence" })`。

- [ ] RAHS ≥ 90

---

## Step 5：AI 自动合规检查

**动作**：
1. 对修改文件调用 `check_add_compliance`
2. 汇总合规报告

**产出**：
- [ ] 合规报告已生成

---

## Step 8：收敛判断 + Handoff 更新

**动作**：
1. 收敛判断：全部 `[T]` 项通过 + RAHS ≥ 90
2. 更新 Handoff
3. 架构文档最终校准
4. ADD-7 回查：`query_audit_logs` 确认全部记录已落库

**产出**：
- [ ] 收敛判定通过
- [ ] Handoff 已更新
- [ ] 架构文档已校准（无变更——纯类型收敛，不改变架构）

---

## 原子闭包判定

```
原子闭包三可性判定
══════════════════
业务功能: Zod-Only DTO 体系收敛——消除手写 DTO/死文件，
          使 Zod schema 成为 HTTP 边界唯一类型真相源，
          19 个 route 补运行时校验 + 3 个死文件清理

Task Groups: Task 1-7（依赖链）

逐组业务价值判定:
  Task 1 (schema 对齐): 不能用 — 只是字段统一，用户无感知
  Task 2 (删死文件): 不能用 — 纯清理，用户无感知
  Task 3 (删 dto + 迁类型): 不能用 — dto 目录删除但 schema 对齐未完成
  Task 4 (hash 内联消除): 不能用 — 单文件类型替换，用户无感知
  Task 5 (补 safeParse): 不能用 — 依赖 Task 1 的类型基础
  Task 6 (复验): 不能用 — 验证步骤
  Task 7 (api 测试): 不能用 — 验证步骤

判定结论: 需要 1 轮（1 个原子闭包）

第1轮（原子闭包1）: Task 1-7 — 业务功能: Zod-Only DTO 体系收敛
  可独立提交✅ 可独立验证✅ 可独立审计✅ 可独立恢复✅
```

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/app/api/types/farm-agent/schemas.ts` | MODIFY | 1 | SCHEMA | ⬜ |
| `src/app/api/types/response.dto.ts` | CREATE | 3 | SCHEMA | ⬜ |
| `src/app/api/h5/types/dto.ts` | DELETE | 2 | SCHEMA | ⬜ |
| `src/app/api/h5/types/schemas.ts` | DELETE | 2 | SCHEMA | ⬜ |
| `src/dto/agent.dto.ts` | DELETE | 3 | COMPONENT | ⬜ |
| `src/dto/knowledge.dto.ts` | DELETE | 3 | COMPONENT | ⬜ |
| `src/lib/utils.ts` | MODIFY | 3 | UTIL | ⬜ |
| `src/app/api/agent/[hash]/route.ts` | MODIFY | 4 | API_ROUTE | ⬜ |
| `src/app/api/agent/stream/route.ts` | MODIFY | 3,5 | API_ROUTE | ⬜ |
| `src/app/api/agent/chat/route.ts` | MODIFY | 3,5 | API_ROUTE | ⬜ |
| `src/app/api/knowledge/upload/route.ts` | MODIFY | 3 | API_ROUTE | ⬜ |
| `src/app/api/knowledge/documents/route.ts` | MODIFY | 3 | API_ROUTE | ⬜ |
| 15 个 route 文件 | MODIFY | 5 | API_ROUTE | ⬜ |
