# chat-panel.tsx 重构：Streaming 逻辑与 UI 分离

## 背景

`chat-panel.tsx` 的 `handleSend` 函数承载了 310 行流式处理逻辑，内部直接操作 30+ 个 zustand store action selector，导致：

1. **ESLint `react-hooks/exhaustive-deps` 警告**：`handleInteractionSelect` 依赖 `handleSend`，规则追踪到 25 个传递依赖全部报 "missing dependency"
2. **依赖爆炸**：`handleSend` 的 deps 数组缺少 30+ 个 store function，存在闭包过期风险
3. **职责不清**：SSE 解析、事件分发、store 更新、UI 状态全部耦合在组件中

## 目标

- SSR 解析、流式引擎、UI 三层分离
- 消除 `exhaustive-deps` 警告（不用 `eslint-disable`）
- 组件只负责数据读取与渲染，不直接操作 store action

## 方案

### 新增文件

| 文件 | 职责 | 行数 |
|------|------|------|
| `src/hooks/use-stream-parser.ts` | 纯 async generator，SSE 字节流 → JSON 事件 | 49 |
| `src/hooks/use-chat-streaming-engine.ts` | 核心引擎 hook：构建请求、解析流、分派 store | 310 |

### 修改文件

| 文件 | 变更 |
|------|------|
| `src/components/chat/chat-panel.tsx` | 468 行 → 154 行（-67%） |

### 架构对比

```
Before (单体):
  ChatPanel
    ├── 30+ useChatStore((s) => s.xxx)   ← 依赖爆炸
    ├── handleSend (310 行 useCallback)    ← 状态耦合太深
    ├── SSE 解析（内联）
    └── handleInteractionSelect（ESLint 告警）

After (三层分离):
  use-stream-parser.ts          ← 纯 I/O 层
    └── parseSSEStream()        AsyncGenerator<Record<string,unknown>>

  use-chat-streaming-engine.ts  ← 引擎层（getState() 避免依赖爆炸）
    ├── sendMessage()
    ├── processStreamEvent()
    └── handleToken()

  chat-panel.tsx (154 行)       ← UI 层（只读 selector）
    ├── handleSend (5 行)       deps: [engineSend] ✅
    └── handleInteractionSelect deps: [activeThreadId, isStreaming, handleSend] ✅
```

### 关键技术决策：`getState()` 替代 selector

引擎 hook 内部使用 `useChatStore.getState()` 命令式访问所有 store action，而非通过 30+ 个 selector 闭包捕获。理由：

- 流式处理本质是**命令式**逻辑，不适合 React 响应式范式
- `getState()` 始终返回最新 store 快照，无闭包过期问题
- `sendMessage` 的 `useCallback` deps 从 30+ 缩减到 **5 个真正会变化的值**：`[activeThreadId, activeModel, isAuthenticated, authUser, authToken]`

## 验证

- ESLint：零错误零警告（`src/components/chat/` + `src/hooks/`）
- TypeScript：`tsc --noEmit` 通过
- `handleInteractionSelect` 原始 `exhaustive-deps` 警告自然消除，**无需 eslint-disable**

## 文件清单

```
新增:
  src/hooks/use-stream-parser.ts
  src/hooks/use-chat-streaming-engine.ts

修改:
  src/components/chat/chat-panel.tsx  (468 → 154 行)
```
