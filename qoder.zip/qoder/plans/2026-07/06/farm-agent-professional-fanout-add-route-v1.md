# farm-agent-professional-fanout-add-route-v1

> **定位**：Plan → ADD Step 执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"。适用于后端系统、多层管线、审计合规场景。
>
> **绑定**：Plan: `.qoder/plans/2026-07/06/farm-agent-professional-fanout-plan-v1.md` · Spec: `.qoder/specs/farm-agent-professional-fanout/spec.md` · Tasks: `.qoder/specs/farm-agent-professional-fanout/tasks.md` · Handoff: `.qoder/plans/2026-07/06/farm-agent-professional-fanout-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs + Handoff 三元组齐全。

**动作**：
1. 确认 Specs 三元组就绪：`spec.md` + `tasks.md` + `checklist.md`
2. 调用 `find_related_docs` 检索受影响的架构/规范/需求文档——已搜索，决策管线说明书 §1.2 已提及 professional 图
3. LangGraph Send API SDK 已验证：`node_modules/@langchain/langgraph` v1.4.7 + 官方文档确认

**产出**：
- [x] Specs 三元组路径确认
- [x] 项目文档无需更新（决策管线说明书 §1.2 已覆盖 professional 图）
- [ ] Handoff 就绪（待生成）

### §0.8 DPS 闸门（上游文档质量校验）

调用 `check_dps({ planKeyword: "professional-fanout" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |

- [x] DPS 已通过（88），可进入 Step 1

---

## Step 1：功能分析与审计打点定义

**目的**：确认审计字面量覆盖。

**动作**：
1. ACAPhase 已有 `PROFESSIONAL_FAN_OUT` / `PROFESSIONAL_INTENTION` / `PROFESSIONAL_AGGREGATE` → 无需新增
2. 各节点沿用 `NODE_START` / `NODE_END` / `NODE_ERROR`

**产出**：
- [ ] 审计打点清单已同步到 tasks.md

| 字面量 | 使用场景 | Task |
|-------|---------|------|
| `PROFESSIONAL_FAN_OUT` | routeByExpertPlan 产 Send[] | Task 3.1 |
| `PROFESSIONAL_INTENTION` | intentionAsyncNode 产 expertPlan | 已有 |
| `PROFESSIONAL_AGGREGATE` | aggregation 节点 | 已有 |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用。

**产出**：
- [ ] `agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

### §3.0 前置守卫

调用 `check_add_route_status` 确认 add-route 有效。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 依赖 |
|---|------|------|-----------|------|
| 1.1 | expertClaims reducer | `state.ts` | 无（结构变更） | 无 |
| 1.1 | fanoutExpertId 字段 | `state.ts` | 无（结构变更） | 无 |
| 1.2 | Send API 封装 | `lib/langgraph/send-api.ts`（新建） | `agentAudit("PROFESSIONAL_FAN_OUT", ...)` | Task 1.1 |
| 2.1 | perExpertRetrieval | `nodes/per-expert-retrieval.ts`（新建） | `agentAuditNodeStart/End` | Task 1.2 |
| 2.2 | reasoningNode 单 expert | `nodes/reasoning.ts` | `agentAuditNodeStart/End` | Task 2.1 |
| 2.3 | structuredOutput 单 expert | `nodes/structured-output.ts` | `agentAuditNodeStart/End` | Task 2.2 |
| 3.1 | routeByExpertPlan | `edges/conditional.ts` | `agentAudit("PROFESSIONAL_FAN_OUT", ...)` | Task 2 |
| 3.2 | professionalWorkflow 重建 | `agent-graph.ts` | 无（图编译） | Task 3.1 |
| 3.3 | 集成测试 | `tests/professional-fanout.test.ts`（新建） | 测试框架 | Task 3.2 |

### 依赖拓扑

```
Task 1.1 (state.ts) ──→ Task 1.2 (send-api.ts)
                              │
                              ▼
Task 1.2 ──→ Task 2.1 (per-expert-retrieval)
                  │
                  ▼
            Task 2.2 (reasoning)
                  │
                  ▼
            Task 2.3 (structured-output)
                  │
                  ▼
            Task 3.1 (routeByExpertPlan)
                  │
                  ▼
            Task 3.2 (agent-graph)
                  │
                  ▼
            Task 3.3 (集成测试)
```

**产出**：
- [ ] 全部 Task `[T]` 通过
- [ ] ADD-7 记录落库
- [ ] `check_spec_sync` 通过

---

## Step 3.5：实现审查

**产出**：
- [ ] `checklist.md` 全部 `[T]` 项通过并勾选
- [ ] `review-implementation.md` 已生成

---

## Step 4：审计数据验证

**动作**：
1. `npx tsc --noEmit` 零错误
2. `npm run lint` 零 error
3. 调用 `check_failure_path` 验证降级路径

**产出**：
- [ ] tsc + lint 通过
- [ ] 失败路径审计等价验证通过

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "professional-fanout" })`。

- [ ] RAHS ≥ 90

---

## Step 5：AI 自动合规检查

**产出**：
- [ ] 合规报告已生成

---

## Step 6-7：异常修复（条件性）

> 仅当 Step 4/5 发现异常时进入。

---

## Step 8：收敛判断 + Handoff 更新

**动作**：
1. 全部 `[T]` 项通过 + RAHS ≥ 90 → 收敛
2. 更新 Handoff §7-§9
3. 回架构文档做最终校准

**产出**：
- [ ] 收敛判定结果
- [ ] Handoff 已更新
- [ ] ADD-7 审计记录落库确认

---

## Step 9：Report Closure（条件性）

> 本 Plan 不是 runtime-fix plan，跳过。

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/agents/state.ts` | MODIFY | 1.1 | STATE | ⬜ |
| `src/lib/langgraph/send-api.ts` | CREATE | 1.2 | COMPONENT | ⬜ |
| `src/agents/nodes/per-expert-retrieval.ts` | CREATE | 2.1 | NODE | ⬜ |
| `src/agents/nodes/reasoning.ts` | MODIFY | 2.2 | NODE | ⬜ |
| `src/agents/nodes/structured-output.ts` | MODIFY | 2.3 | NODE | ⬜ |
| `src/agents/edges/conditional.ts` | MODIFY | 3.1 | EDGE | ⬜ |
| `src/agents/agent-graph.ts` | MODIFY | 3.2 | COMPONENT | ⬜ |
| `tests/professional-fanout.test.ts` | CREATE | 3.3 | TEST | ⬜ |
