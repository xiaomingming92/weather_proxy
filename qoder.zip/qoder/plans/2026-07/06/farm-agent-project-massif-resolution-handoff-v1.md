# farm-agent — 3 轮原子事务交接手册

> **适用场景**：3 轮原子事务变更，每轮独立收敛。projectId → massifIds 自动解析。
>
> **用途**：每个新对话开始时，把对应 Round 章节粘贴给 LLM。它需要明确自己正在执行哪个原子工程事务、上游事务已经提交了什么、当前事务的文件边界是什么、验证标准是什么、完成后记录哪些 ADD-7 审计。

---

## 全局元信息

- **父 Plan**: `.qoder/plans/2026-07/06/farm-agent-project-massif-resolution-plan-v1.md`
- **原子事务拓扑**: `.qoder/plans/2026-07/06/farm-agent-project-massif-resolution-add-route-v1.md`
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 8 个独立文件
- **Round 数**: 3 轮局部闭包
- **拆分原则**: 以文件边界独立为主，每轮文件互不跨轮修改

```text
第1轮 ── farm-api + context 层
            │  massif.ts + farm-project-context.ts + phase.ts
            ▼
第2轮 ── state + route + intention 消费端串联
            │  state.ts + agent-runner.ts + route.ts + intention.ts
            ▼
第3轮 ── resolve-tool-params 补位 + 全量验证
            │  resolve-tool-params.ts
            ▼  收敛 (tsc=0, eslint=0, RAHS=100)
```

---

## 原子事务边界说明

本手册中的"轮"按轮次级闭包划分（ADD 范式 §0.7）：

- **轮次级闭包**：一轮内的文件集合形成独立边界——该轮修改的文件不会被其他轮次回头修改，该轮的验证不依赖"下一轮补齐"。轮次之间是生产者-消费者关系，不是互相修补。
- **独立验证**：每轮完成后可通过 `tsc --noEmit` + `eslint` + checklist [T] 项独立验证。

因此：

- 第1轮和第2轮虽然都涉及 state.ts 的相邻字段，但第2轮新增的 `prebuiltMassifIds` 是独立 Annotation，不修改第1轮产出的函数签名——文件归属清晰，互不跨轮修改。
- 第3轮不是前 2 轮的补丁，而是前 2 轮收敛后的裁决层补位——`resolve-tool-params.ts` 只扩展 3 个 `available()` 条件，不修改第 1/2 轮的任何文件。
- 每一轮完成后必须能够独立证明收敛，不能依赖"下一轮再补齐"才能成立。

### 交接手册与 spec 的优先级

- 本 handoff 是新对话的入口索引，负责说明 Round 位置、上下游依赖、文件边界、高风险误区、恢复关键词和审计闭环。
- 具体实现细节以对应 `.qoder/specs/farm-agent-project-massif-resolution/spec.md`、`tasks.md`、`checklist.md` 为准。
- 如果 handoff 摘要与 spec/tasks/checklist 存在颗粒度差异，以 spec/tasks/checklist 为准，不允许按 handoff 的简写自行简化实现。
- 每轮完成后的 ADD-7 不只写入 `record_dev_operation`，还必须用 `query_audit_logs` 按 action/targetId/keyword 回查确认落库。

---

## 第1轮：farm-api + context 层

### 你当前的位置

你是第 1 轮。无上游依赖。建立 `projectId → massifIds[]` 数据源能力——本轮产出 `resolveProjectMassifIds()` 函数供第 2/3 轮消费。

### 上游已完成

- 无（第 1 轮，无上游）

### 恢复上下文审计查询（新 AI Session 首次启动必读）

#### 第一步：搜索代码文件的改动记录

```text
query_audit_logs({ targetId: "src/lib/farm-api/massif.ts" })
```
→ 返回 1 条：COMPONENT_MODIFIED。beforeState: getPage 无显式 projectId，afterState: getPage 显式 projectId + 新增 getAllByProjectId。

```text
query_audit_logs({ targetId: "src/lib/farm-project-context.ts" })
```
→ 返回 1 条：COMPONENT_MODIFIED。beforeState: 无 resolveProjectMassifIds，afterState: 新增 resolveProjectMassifIds + 6 种回退路径。

```text
query_audit_logs({ targetId: "src/lib/log/phase.ts" })
```
→ 返回 1 条：TYPE_MODIFIED。beforeState: 11 个子类型，afterState: 新增 ProjectMassifPhase。

#### 第二步：搜索文档变更记录

```text
query_audit_logs({ keyword: "DOC_CREATED" })
```
→ 返回 Plan / Spec / tasks / checklist 的创建记录。

#### 第三步：按行动词搜索

```text
query_audit_logs({ keyword: "COMPONENT_MODIFIED" })
```
→ 返回本轮全部文件改动记录。

#### 恢复顺序建议

```
1. session-init SKILL（强制前置）
2. query_audit_logs({})                                    → 查看最近所有操作
3. query_audit_logs({ keyword: "PROJECT_MASSIF" })         → 看本轮所有记录（应返回 7+ 条）
4. read ".qoder/specs/farm-agent-project-massif-resolution/spec.md"
5. read ".qoder/specs/farm-agent-project-massif-resolution/tasks.md"
6. read ".qoder/specs/farm-agent-project-massif-resolution/checklist.md"
```

### 原子事务目标

覆盖 `farm-agent-project-massif-resolution-plan-v1.md` 的 Round 1。建立 Farm-Server API 调用能力 + activedProjectId → massifIds 解析函数 + 审计字面量注册。

### spec 文件

- `.qoder/specs/farm-agent-project-massif-resolution/spec.md`
- `.qoder/specs/farm-agent-project-massif-resolution/tasks.md`
- `.qoder/specs/farm-agent-project-massif-resolution/checklist.md`

### 架构文档

- `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` — §2.1 AgentState 字段（本次变更在 route 层，不改变管线拓扑）

### 你要改的文件（3 个：0 新建 + 3 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/lib/farm-api/massif.ts` | MODIFY | `getPage` 显式加 `projectId?: number`（L60）；新增 `getAllByProjectId(projectId)`（L74）调 `/farm/massif/options?projectId={projectId}` |
| `src/lib/farm-project-context.ts` | MODIFY | 新增 `resolveProjectMassifIds()`（L72-110）：读 activedProjectId → getFarmToken() → createMassifApi() → getAllByProjectId() → data.map(m => m.id)；6 种回退路径均有 `agentAudit("PROJECT_MASSIF_RESOLVE", ...)` |
| `src/lib/log/phase.ts` | MODIFY | 新增 `ProjectMassifPhase` 子类型（`PROJECT_MASSIF_RESOLVE` / `PROJECT_MASSIF_PREFILL`）并入 `AgentAuditPhase`（L203-220） |

### 核心设计

```text
resolveProjectMassifIds() 的回退链（任意环节失败 → return null）：
  1. activedProjectId == null → null
  2. getFarmToken() → null → null
  3. createMassifApi().getAllByProjectId() → response.code !== 200 → null
  4. response.data 非数组 → null
  5. data.map(m => m.id).length === 0 → null
  6. catch (error) → null
返回 null 时，上层 resolveToolParams 自然触发 param_missing。
```

### 关键契约细化

- `src/lib/farm-api/massif.ts`：`getAllByProjectId` 的 projectId 参数来自自动生成 API 文档（`Farm-Server API接口文档（自动生成）.md` L987），确认 `/massif/options` 支持 `projectId` 可选参数。
- `src/lib/farm-project-context.ts`：`resolveProjectMassifIds` 不抛出异常——所有异常在内部 catch 并返回 null，调用方不需要额外 try/catch。
- `src/lib/log/phase.ts`：新增 `ProjectMassifPhase` 后 `AgentAuditPhase` 从 11 子类型变为 12 子类型——所有已有 `agentAudit()` 调用不受影响。

### 高风险误区

- 禁止在 `resolveProjectMassifIds` 中抛出异常——必须内部 catch 返回 null。
- 禁止硬编码 massifId 值作为 fallback——必须返回 null 让 resolveToolParams 触发 param_missing。

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_MODIFIED` | API | `src/lib/farm-api/massif.ts` | 新增 getAllByProjectId + getPage projectId | ✅ |
| `COMPONENT_MODIFIED` | LIB | `src/lib/farm-project-context.ts` | 新增 resolveProjectMassifIds + 6 回退路径 | ✅ |
| `TYPE_MODIFIED` | TYPE | `src/lib/log/phase.ts` | 新增 ProjectMassifPhase 子类型 | ✅ |

**恢复关键词**：
```text
query_audit_logs({ keyword: "PROJECT_MASSIF" })
→ 返回全部 7+ 条本轮 ADD-7 审计记录
```

### 验证标准

#### 已完成验证

- `npx tsc --noEmit` 零错误
- `npx eslint` zero error
- grep 确认 L60（getPage projectId）、L74（getAllByProjectId）、L72-110（resolveProjectMassifIds）、L203-220（ProjectMassifPhase）
- checklist.md 全部 [T] 编译项已勾选

#### 未执行的端到端验证（保留给运行时复测）

- [ ] activedProjectId=1001 → resolveProjectMassifIds 返回地块列表（需启动服务 + Farm-Server 网络可达）

### 完成后记录 ADD-7 审计

| 文件 | action |
|------|--------|
| `src/lib/farm-api/massif.ts` | `COMPONENT_MODIFIED` |
| `src/lib/farm-project-context.ts` | `COMPONENT_MODIFIED` |
| `src/lib/log/phase.ts` | `TYPE_MODIFIED` |

完成后一键验证：
```text
query_audit_logs({ keyword: "PROJECT_MASSIF" })
→ 确认 7+ 条全部落库
```

---

## 第2轮：state + route + intention 消费端串联

### 你当前的位置

你是第 2 轮。上游第 1 轮已完成 `resolveProjectMassifIds()` 函数和 `ProjectMassifPhase` 类型注册。

### 上游已完成

- 第 1 轮交付 `resolveProjectMassifIds(): Promise<number[] | null>`（`src/lib/farm-project-context.ts` L72-110）
- 第 1 轮交付 `getAllByProjectId(projectId)`（`src/lib/farm-api/massif.ts` L74）
- 第 1 轮交付 `ProjectMassifPhase` 审计字面量（`src/lib/log/phase.ts` L203-220）

### 恢复上下文审计查询

#### 第一步：搜索代码文件的改动记录

```text
query_audit_logs({ targetId: "src/agents/state.ts" })
```
→ 返回 1 条：STATE_MODIFIED。beforeState: 无 prebuiltMassifIds，afterState: 新增 prebuiltMassifIds Annotation (L134)。

```text
query_audit_logs({ targetId: "src/agents/agent-runner.ts" })
```
→ 返回 1 条：COMPONENT_MODIFIED。beforeState: 无 prebuiltMassifIds，afterState: StreamAgentInput.prebuiltMassifIds (L46)。

```text
query_audit_logs({ targetId: "src/app/api/agent/chat/stream/route.ts" })
```
→ 返回 1 条：COMPONENT_MODIFIED。beforeState: 未调用 resolveProjectMassifIds，afterState: try/catch 调用 + 注入 prebuiltMassifIds (L264-283)。

```text
query_audit_logs({ targetId: "src/agents/nodes/intention.ts" })
```
→ 返回 1 条：COMPONENT_MODIFIED。beforeState: 无 PROJECT_MASSIF_PREFILL，afterState: explicitIntent 分支新增审计 (L173-177)。

#### 恢复顺序建议

```
1. session-init SKILL
2. query_audit_logs({ keyword: "PROJECT_MASSIF" })
3. query_audit_logs({ keyword: "PROJECT_MASSIF_PREFILL" })
4. read ".qoder/specs/farm-agent-project-massif-resolution/spec.md"
```

### 原子事务目标

覆盖 `farm-agent-project-massif-resolution-plan-v1.md` 的 Round 2。将第 1 轮的 `resolveProjectMassifIds()` 串联到 Agent State → API route → intentionNode 消费端，使全路径（卡片 + 自然对话）受益。

### spec 文件

- `.qoder/specs/farm-agent-project-massif-resolution/spec.md`
- `.qoder/specs/farm-agent-project-massif-resolution/tasks.md`
- `.qoder/specs/farm-agent-project-massif-resolution/checklist.md`

### 架构文档

- `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` — §2.1 AgentState 字段（新增 prebuiltMassifIds 字段，不改变管线拓扑）

### 你要改的文件（4 个：0 新建 + 4 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/state.ts` | MODIFY | 新增 `prebuiltMassifIds: Annotation<number[] \| null>()`（L134），在 `massifIds` 和 `massifName` 之间 |
| `src/agents/agent-runner.ts` | MODIFY | `StreamAgentInput` 新增 `prebuiltMassifIds?: number[] \| null`（L46），在 `prebuiltExpertPlan` 和 `projectId` 之间 |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY | import `resolveProjectMassifIds`（L13）；在 `streamAgent` 调用前无条件 try/catch 调用（L264-272）；注入 `prebuiltMassifIds` 到 `StreamAgentInput`（L283） |
| `src/agents/nodes/intention.ts` | MODIFY | explicitIntent 分支：prebuiltMassifIds 有值时 `agentAudit("PROJECT_MASSIF_PREFILL")`（L173-177）；LLM 路径由 `resolveToolParams` 自动识别 |

### 核心设计

```text
route.ts 无条件调用 resolveProjectMassifIds() 的设计理由：
  - 不等意图节点判断是什么路径（卡片/自然对话）
  - 作为系统级默认值提前注入 State
  - activedProjectId 有效 → prebuiltMassifIds 有值 → resolveToolParams 不缺参
  - 失败 → prebuiltMassifIds=null → resolveToolParams 触发 param_missing
```

### 关键契约细化

- `src/agents/state.ts`：`prebuiltMassifIds` 是 `Annotation<number[] | null>()`——与 `massifIds` 同类型，不强制任何 reducer。
- `src/app/api/agent/chat/stream/route.ts`：`try/catch` 包裹 `resolveProjectMassifIds()` 调用——Farm-Server 异常不得中断 chat 请求。
- `src/agents/nodes/intention.ts`：只在 explicitIntent 分支记录 `PROJECT_MASSIF_PREFILL` 审计——LLM 路径由 `resolveToolParams` 层自动识别，无需额外日志。

### 高风险误区

- 禁止在 `route.ts` 中根据 `expertIds` 有值/无值做条件判断——本 Plan 已扩大为全路径覆盖。
- 禁止在 `intention.ts` 中修改 LLM 路径的 subIntents 构建逻辑——`prebuiltMassifIds` 的消费全在 `resolveToolParams` 层。

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `STATE_MODIFIED` | STATE | `src/agents/state.ts` | 新增 prebuiltMassifIds Annotation | ✅ |
| `COMPONENT_MODIFIED` | AGENT_RUNNER | `src/agents/agent-runner.ts` | StreamAgentInput 新增 prebuiltMassifIds | ✅ |
| `COMPONENT_MODIFIED` | API | `src/app/api/agent/chat/stream/route.ts` | import + try/catch + 注入 prebuiltMassifIds | ✅ |
| `COMPONENT_MODIFIED` | NODE | `src/agents/nodes/intention.ts` | explicitIntent 分支 PROJECT_MASSIF_PREFILL 审计 | ✅ |

### 验证标准

#### 已完成验证

- `npx tsc --noEmit` 零错误
- `npx eslint` zero error
- grep 确认 L134（state.ts）、L46（agent-runner.ts）、L264-283（route.ts）、L173-177（intention.ts）

#### 未执行的端到端验证（保留给运行时复测）

- [ ] 点击"周报分析"卡片 → deep 图推理 → 不触发 param_missing
- [ ] 自由打字"帮我分析虫情" → 不触发 param_missing
- [ ] 点击"地块虫害分析"卡片（massifIds=[1,2]）→ 跳过 projectId 解析 → 行为不变

### 完成后记录 ADD-7 审计

| 文件 | action |
|------|--------|
| `src/agents/state.ts` | `STATE_MODIFIED` |
| `src/agents/agent-runner.ts` | `COMPONENT_MODIFIED` |
| `src/app/api/agent/chat/stream/route.ts` | `COMPONENT_MODIFIED` |
| `src/agents/nodes/intention.ts` | `COMPONENT_MODIFIED` |

---

## 第3轮：resolve-tool-params 补位 + 全量验证

### 你当前的位置

你是第 3 轮。上游第 1 轮已完成 `resolveProjectMassifIds()`，第 2 轮已完成 State + route + intention 串联。

### 上游已完成

- 第 1 轮交付 `resolveProjectMassifIds(): Promise<number[] | null>`
- 第 2 轮交付 `prebuiltMassifIds` 的完整链路：route.ts 注入 → state.ts 存储 → intention.ts 审计

### 恢复上下文审计查询

```text
query_audit_logs({ targetId: "src/caijuehub/strategies/resolve-tool-params.ts" })
```
→ 返回 1 条：COMPONENT_MODIFIED。beforeState: available 仅检查 massifId + massifIds，afterState: 3 个规则新增 prebuiltMassifIds 检查。

### 原子事务目标

覆盖 `farm-agent-project-massif-resolution-plan-v1.md` 的 Round 3。裁决层补位——`resolveToolParams` 的 3 个 `available()` lambda 识别 `prebuiltMassifIds`，使全项目地块默认值时工具调用不缺参。

### spec 文件

- `.qoder/specs/farm-agent-project-massif-resolution/spec.md`
- `.qoder/specs/farm-agent-project-massif-resolution/tasks.md`
- `.qoder/specs/farm-agent-project-massif-resolution/checklist.md`

### 你要改的文件（1 个：0 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/caijuehub/strategies/resolve-tool-params.ts` | MODIFY | 3 个规则 `query_soil_moisture` / `query_insect_data` / `query_farm_weather` 的 `available()` lambda 新增 `(s.prebuiltMassifIds?.length ?? 0) > 0`（L36/43/50） |

### 核心设计

```text
available(s) 的优先级链：
  1. s.massifId != null              → 用户手动选了单个地块
  2. (s.massifIds?.length ?? 0) > 0  → GUI 卡片预填充多地块
  3. (s.prebuiltMassifIds?.length ?? 0) > 0 → route 层系统默认值（本 Plan）
  以上任一条件满足 → 不缺参 → 不触发 param_missing
```

### 高风险误区

- 禁止新增规则——只需扩展已有 3 个规则的 `available()` 条件。
- 禁止修改 `requiredIn` 函数——`weekly_report`/`daily_report` 仍需排除 massifId 检查。

### ADD-7 审计记录

| action | targetType | targetId | 说明 | 状态 |
|--------|-----------|----------|------|:--:|
| `COMPONENT_MODIFIED` | STRATEGY | `src/caijuehub/strategies/resolve-tool-params.ts` | 3 个 available() 新增 prebuiltMassifIds | ✅ |

### 验证标准

#### 已完成验证

- `npx tsc --noEmit` 零错误（全量）
- `npx eslint src/` zero error（全量）
- grep 确认 L36/43/50（3 个 available()）

#### 未执行的端到端验证（保留给运行时复测）

- [ ] activedProjectId=null → 不自动解析 → 触发 param_missing（回退）

### 完成后记录 ADD-7 审计

| 文件 | action |
|------|--------|
| `src/caijuehub/strategies/resolve-tool-params.ts` | `COMPONENT_MODIFIED` |

---

## 每轮收敛判定补充规则

### checklist 证据要求

- [x] **全部项已勾选**：7/7 [T] 编译项已勾选并附证据
- [x] **每项勾选有可验证证据**：grep 行号 / tsc 输出 / eslint 输出
- [x] **未执行项诚实保留**：5 项 [R] 运行时验证保留为 `- [ ]`，注明"需启动服务"
- [x] **证据可直接获取**：后续 AI Session 通过 `query_audit_logs({ keyword: "PROJECT_MASSIF" })` 可查到全部审计记录

### tasks 证据要求

- [x] **全部任务已完成**（tasks.md 中 8 个 Task 全部 `[x]`）
- [x] **每个任务有对应的 checklist 项覆盖**
- [x] **task 完成状态与 ADD-7 审计记录一致**：8 个文件均有 `record_dev_operation` 记录

---

## 附录：每轮启动模板

新对话开始时，直接把下面内容 + 对应 Round 章节粘贴给 LLM：

```text
## 上下文

你在执行 farm-agent project-massif-resolution 改进的 [第N轮]。
上游 [第1轮~第N-1轮] 已完成。
先读 .qoder/plans/2026-07/06/farm-agent-project-massif-resolution-handoff-v1.md 的 <第N轮> 章节。

## 启动操作（按顺序）

1. 执行 session-init SKILL
2. 执行 add-paradigm SKILL（含 Step 0 文档先行）
3. 读本轮对应 .qoder/specs/farm-agent-project-massif-resolution/spec.md
4. 读本轮对应 .qoder/specs/farm-agent-project-massif-resolution/tasks.md
5. 读本轮对应 .qoder/specs/farm-agent-project-massif-resolution/checklist.md
6. 按 tasks.md 顺序执行代码修改
7. 每完成一个 Task：读 checklist.md → 逐项验证 → **附可验证证据** → 勾选
8. 每完成一个文件修改：record_dev_operation 写入 ADD-7 审计
9. 写入审计后：query_audit_logs 按 action/targetId/keyword 回查确认落库
10. 收敛后：回到 add-paradigm SKILL Step 0.6，验收后回看架构文档，标记偏差点

## 关键提醒

- 当前执行的是 [第N轮]/3
- 当前 Round 是一个原子工程事务，不允许拆到下一轮补齐
- handoff 是入口索引；具体实现以 spec/tasks/checklist 为准
- 禁止提前实现下一轮的核心内容
- 禁止简化代码实现
- 禁止跳过 MCP 回查
```
