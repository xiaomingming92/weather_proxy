# farm-agent-project-massif-resolution-add-route-v1

> **定位**：Plan → ADD Step 执行映射。不重复 Plan 的架构设计和 Specs 的任务细节——只定义每个 ADD Step 在本 Plan 中的具体动作、输入、产出。
>
> **模式**：重型（Heavyweight）——每一步产出检查强制执行"验证并更新项目状态"。适用于后端系统、多层管线、审计合规场景。
>
> **绑定**：Plan: `.qoder/plans/2026-07/06/farm-agent-project-massif-resolution-plan-v1.md` · Spec: `.qoder/specs/farm-agent-project-massif-resolution/spec.md` · Tasks: `.qoder/specs/farm-agent-project-massif-resolution/tasks.md` · Handoff: `.qoder/plans/2026-07/06/farm-agent-project-massif-resolution-handoff-v1.md`

---

## Step 0：文档先行（Documentation First）

**目的**：代码动工前，确认 Plan + Specs 三元组齐全，项目文档反映即将实现的变更。

**输入**：
- 上游 Plan（已创建）
- `农场管理软件小程序端 需求文档.md`
- `神经元GUI-API对接文档.md`（v1.8 已对齐）

**动作**：
1. 创建 Specs 三元组：`spec.md` + `tasks.md` + `checklist.md`
2. 调用 `find_related_docs` 检索受影响的架构/规范/需求文档——已搜索，主要受影响的 API 文档已在上一任务对齐
3. 创建 Handoff 文件（含 3 轮原子事务）
4. 确认 ADD-7 审计策略表（从 Plan 元信息复制）

**产出**：
- [ ] 验证并更新项目状态：Specs 三元组路径确认
- [ ] 验证并更新项目状态：API 对接文档 v1.8 已对齐（上一任务完成）
- [ ] 验证并更新项目状态：Handoff 就绪

### §0.8 DPS 闸门（上游文档质量校验）

调用 `check_dps({ planKeyword: "project-massif-resolution" })`。

| DPS | 判定 | 动作 |
|-----|:--:|------|
| ≥ 85 | 🟢 | 进入 Step 1 |
| 70–84 | 🟡 | 回退补齐短板 |
| < 70 | 🔴 | 回退细化 Plan |

- [ ] DPS 已通过（≥ 85），可进入 Step 1

---

## Step 1：功能分析与审计打点定义

**目的**：定义本次变更涉及的所有审计打点。

**动作**：
1. 列出本次变更涉及的业务环节：项目地块解析 → 意图节点消费 → 工具参数裁决
2. 在 `AgentAuditPhase` 联合类型中新增字面量

**产出**：
- [ ] 验证并更新项目状态：审计打点清单已同步到 tasks.md

| 字面量 | 使用场景 | Task |
|-------|---------|------|
| `PROJECT_MASSIF_RESOLVE` | resolveProjectMassifIds 调用成功/失败 | Task 1 |
| `PROJECT_MASSIF_PREFILL` | intention.ts explicitIntent 路径 prebuiltMassifIds 填充 | Task 2 |

---

## Step 2：审计基础设施确认

**目的**：确认 `agentAudit()` 通道可用。

**动作**：
1. 确认 `agentAudit()` 接受新增字面量
2. 确认三通道输出正常

**产出**：
- [ ] 验证并更新项目状态：`agentAudit()` 通道确认可用

---

## Step 3：业务逻辑实现与审计植入

**目的**：按 3 轮 Task 依赖拓扑逐 Task 实施。

**输入**：
- Plan §三 实施 Task + 依赖图
- `tasks.md` 的 Task 清单

### §3.0 前置守卫

调用 `check_add_route_status` 确认 add-route 有效。

### Task 映射表

| # | Task | 文件 | 审计植入点 | 依赖 |
|---|------|------|-----------|------|
| 1 | farm-api 层新增 getAllByProjectId | `src/lib/farm-api/massif.ts` | 无（API 调用层） | 无 |
| 1 | farm-project-context 新增 resolveProjectMassifIds | `src/lib/farm-project-context.ts` | `agentAudit("PROJECT_MASSIF_RESOLVE", ...)` | 无 |
| 2 | state.ts 新增 prebuiltMassifIds | `src/agents/state.ts` | 无（结构变更） | Task 1 |
| 2 | agent-runner.ts 新增 prebuiltMassifIds | `src/agents/agent-runner.ts` | 无（类型扩展） | Task 1 |
| 2 | route.ts 调用 resolveProjectMassifIds | `src/app/api/agent/chat/stream/route.ts` | 无（透传层） | Task 1 |
| 2 | intention.ts explicitIntent 路径消费 | `src/agents/nodes/intention.ts` | `agentAudit("PROJECT_MASSIF_PREFILL", ...)` | Task 2 |
| 3 | resolve-tool-params.ts available 扩展 | `src/caijuehub/strategies/resolve-tool-params.ts` | 无（裁决逻辑） | Task 2 |
| 3 | tsc + eslint 验证 | 全量 | — | Task 3 |

### 依赖拓扑

```
Task 1 (farm-api + context) ──→ Task 2 (state + route + intention) ──→ Task 3 (resolve-tool-params + 验证)
```

### 每个 Task 完成后

1. 验证该 Task 的 checklist `[T]` 项
2. 调用 `record_dev_operation` 记录 ADD-7 审计
3. **验证并更新项目状态**：将该 Task 在 `tasks.md` 中勾选

**产出**：
- [ ] 验证并更新项目状态：全部 Task `[T]` 通过，`tasks.md` 已完成项已勾选
- [ ] 验证并更新项目状态：每个文件有 `record_dev_operation` 记录
- [ ] 验证并更新项目状态：`check_spec_sync` 通过

---

## Step 3.5：实现审查

**动作**：
1. 逐项执行 `checklist.md` 中所有 `[T]` 编译期检查项
2. 生成 `review-implementation.md`

**产出**：
- [ ] 验证并更新项目状态：`checklist.md` 全部 `[T]` 项通过并勾选
- [ ] 验证并更新项目状态：`review-implementation.md` 已生成

---

## Step 4：审计数据验证

**动作**：
1. `npx tsc --noEmit` —— 零类型错误
2. `npm run lint` —— 无新增 lint 问题
3. 调用 `check_failure_path` 验证失败路径（回退到 param_missing 的 4 种场景）

**产出**：
- [ ] `tsc --noEmit` 通过
- [ ] `npm run lint` 通过
- [ ] 失败路径审计等价验证通过

### §4.6 RAHS 闸门

调用 `check_rahs({ planKeyword: "project-massif-resolution" })`。

| RAHS | 判定 | 动作 |
|------|:--:|------|
| ≥ 90 | 🟢 | 进入 Step 5 |
| 70–89 | 🟡 | 自检 |
| < 70 | 🔴 | 返工 |

- [ ] RAHS 已通过（≥ 90）

---

## Step 5：AI 自动合规检查

**动作**：对每个修改文件调用 `check_add_compliance`。

**产出**：
- [ ] 验证并更新项目状态：合规报告已生成，违规项处理决策已记录

---

## Step 6-7：异常修复（条件性）

> 仅当 Step 4/5 发现异常时进入。

---

## Step 8：收敛判断 + Handoff 更新

**动作**：
1. 全部 `[T]` 项通过 + RAHS ≥ 90 → 收敛
2. 更新 Handoff §7-§9
3. 回架构文档做最终校准
4. `query_audit_logs` 确认 ADD-7 记录落库

**产出**：
- [ ] 验证并更新项目状态：收敛判定结果
- [ ] 验证并更新项目状态：Handoff 已更新
- [ ] 验证并更新项目状态：ADD-7 审计记录已落库确认

---

## Step 9：Report Closure（条件性）

> 本 Plan 不是 runtime-fix plan，跳过。

---

## 附录：文件清单

| 文件 | 操作 | Task | targetType | ADD-7 状态 |
|------|------|------|-----------|------------|
| `src/lib/farm-api/massif.ts` | MODIFY | 1 | API | ⬜ |
| `src/lib/farm-project-context.ts` | MODIFY | 1 | LIB | ⬜ |
| `src/agents/state.ts` | MODIFY | 2 | STATE | ⬜ |
| `src/agents/agent-runner.ts` | MODIFY | 2 | AGENT_RUNNER | ⬜ |
| `src/app/api/agent/chat/stream/route.ts` | MODIFY | 2 | API | ⬜ |
| `src/agents/nodes/intention.ts` | MODIFY | 2 | NODE | ⬜ |
| `src/caijuehub/strategies/resolve-tool-params.ts` | MODIFY | 3 | STRATEGY | ⬜ |
