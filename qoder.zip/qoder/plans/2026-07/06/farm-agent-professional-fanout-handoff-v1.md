# farm-agent — 3 轮原子事务交接手册

> **适用场景**：3 轮原子事务变更，每轮独立收敛。professionalWorkflow 串行→Send API fan-out。
>
> **用途**：每个新对话开始时，把对应 Round 章节粘贴给 LLM。

---

## 全局元信息

- **父 Plan**: `.qoder/plans/2026-07/06/farm-agent-professional-fanout-plan-v1.md`
- **原子事务拓扑**: `.qoder/plans/2026-07/06/farm-agent-professional-fanout-add-route-v1.md`
- **目标仓库**: `/home/xmm/ai/farm-agent`
- **总文件数**: 8 个独立文件
- **Round 数**: 3 轮局部闭包
- **拆分原则**: 以文件边界独立为主，每轮文件互不跨轮修改

```text
第1轮: Send API 基础设施
   │  state.ts + send-api.ts
   ▼
第2轮: 节点适配（全串行: 2.1 → 2.2 → 2.3）
   │  per-expert-retrieval.ts + reasoning.ts + structured-output.ts
   ▼
第3轮: 图组装 + 集成验证
   │  conditional.ts + agent-graph.ts + test.ts
   ▼  收敛 (tsc=0, eslint=0)
```

---

## 原子事务边界说明

本手册中的"轮"按轮次级闭包划分（ADD 范式 §0.7）：

- 第1轮只改 state.ts + 新建 send-api.ts，不碰 Agent 节点逻辑
- 第2轮只改/新建 3 个节点文件，依赖第1轮的 `fanoutExpertId` Annotation 和 Send API 类型
- 第3轮只改 edges + agent-graph + 测试，消费第2轮的节点函数

每轮文件互不跨轮修改，每轮完成后可独立 `tsc + eslint` 验证。

### 交接手册与 spec 的优先级

- 本 handoff 是新对话的入口索引
- 具体实现细节以 `.qoder/specs/farm-agent-professional-fanout/spec.md`、`tasks.md`、`checklist.md` 为准
- 每轮完成后的 ADD-7 不只写入 `record_dev_operation`，还必须用 `query_audit_logs` 回查确认落库

---

## 第1轮：Send API 基础设施

### 你当前的位置

第1轮，无上游依赖。建立 expertClaims reducer + fanoutExpertId State 字段 + Send API 封装。

### 上游已完成

- 无（第1轮）

### 你要改的文件（2 个：1 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/state.ts` | MODIFY | expertClaims 改为带 concat reducer 的 Annotation；新增 `fanoutExpertId: Annotation<string \| null>()` |
| `src/lib/langgraph/send-api.ts` | CREATE | 导入 `Send` from `@langchain/langgraph`；导出 `routeByExpertPlan(state)` |

### 核心设计

```text
expertClaims reducer: (current, update) => update ? [...(current || []), ...update] : current
  default: () => null  ← P2-1 拒绝改为 []
fanoutExpertId: Annotation<string | null>()  ← Send API 分支路由标识
```

### 关键契约细化

- `src/agents/state.ts`：expertClaims 的 reducer 仅在写入时触发，不影响 deep/fast 图
- `src/lib/langgraph/send-api.ts`：`routeByExpertPlan` 返回 `Send[] | string`（空计划返回 `"kbConflictAggregator"`）

### 高风险误区

- 禁止修改 expertClaims 的 `default: () => null` 为 `[]`
- 禁止在 send-api.ts 中引入 agent 内部依赖（保持纯工具模块）

### 验证标准

- [ ] `npx tsc --noEmit` 零错误
- [ ] deep 图不受影响（grep 确认 reducer 仅在写入时触发）

---

## 第2轮：节点适配

### 你当前的位置

第2轮。上游第1轮已完成 `fanoutExpertId` Annotation + `routeByExpertPlan` 函数签名。

### 上游已完成

- state.ts: expertClaims reducer + fanoutExpertId 字段
- send-api.ts: routeByExpertPlan 函数签名

### 你要改的文件（3 个：2 新建 + 1 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/nodes/per-expert-retrieval.ts` | CREATE | 接收 `state.fanoutExpertId`，查 `ANALYSIS_EXPERTS[fanoutExpertId].evidenceFilter`，调 RAG → 构建单 expert 的 expertPackage |
| `src/agents/nodes/per-expert-reasoning.ts` | CREATE | 读 `fanoutExpertId` + `expertPackages[0]`，加载 per-expert prompt，过滤本 expert 的 toolMessages 注入 `toolResults`，单 LLM invoke，解析产出 `verdictResult` |
| `src/agents/nodes/structured-output.ts` | MODIFY | `state.fanoutExpertId` 存在时从 `verdictResult.conclusion.content` 读取 reasoning 文本 |

### 核心设计

```text
perExpertRetrieval:
  state.fanoutExpertId → ANALYSIS_EXPERTS[id].evidenceFilter → RAG
  → expertPackage = { expertId, label, evidences, toolResults: [], ... }
  → 写入 state.expertPackages = [expertPackage]

perExpertReasoning:
  state.fanoutExpertId + expertPackages[0]
  → 从 state.messages 筛选本 expert 的 toolMessages（按 realtimeToolNames 过滤）
  → loadExpertPrompt(fanoutExpertId).build({ toolResults })
  → 单 LLM invoke → reasoningPrompt.parse() → verdictResult

structuredOutputNode (fan-out 上下文):
  从 verdictResult.conclusion.content 取 reasoning 文本
  → 产出 ExpertClaim → reducer concat 写入 expertClaims
```

> **隔离决策**：ACA v3 设计为复用 deep 图的 reasoningNode，但会导致节点职责混杂。本 Plan 新建 perExpertReasoning，职责单一，不改造现有 reasoningNode。

### 依赖关系（全串行）

```
Task 2.1 (per-expert-retrieval) → 2.2 (reasoning) → 2.3 (structured-output)
```

### 高风险误区

- 禁止在 perExpertRetrieval 中调用工具——工具调用仅在 perExpertReasoning 的 LLM 推理中
- 禁止跳过深图回归测试

### 验证标准

- [ ] `npx tsc --noEmit` 零错误
- [ ] deep 图单专家推理不受影响
- [ ] 推理产出的 reasoningText 格式正确

---

## 第3轮：图组装 + 集成验证

### 你当前的位置

第3轮。上游第2轮已完成 3 个节点函数。

### 你要改的文件（3 个：1 新建 + 2 修改）

| 文件 | 操作 | 改什么 |
|------|------|--------|
| `src/agents/edges/conditional.ts` | MODIFY | 新增 `routeByExpertPlan`：读 state.expertPlan → 返回 `Send("perExpertRetrieval", { fanoutExpertId })[]` |
| `src/agents/agent-graph.ts` | MODIFY | professionalWorkflow 从串行改为 Send API fan-out 拓扑 |
| `tests/professional-fanout.test.ts` | CREATE | 2 expert mock fan-out → ExpertClaim[] 全链路 |

### 核心设计

```text
professionalWorkflow:
  .addConditionalEdges("intention", routeByExpertPlan)
  .addNode("perExpertRetrieval", perExpertRetrievalNode)
  .addNode("perExpertReasoning", perExpertReasoningNode)  // 复用 reasoningNode（双模式）
  .addNode("perExpertStructuredOutput", perExpertStructuredOutputNode)
  .addEdge("perExpertRetrieval", "perExpertReasoning")
  .addEdge("perExpertReasoning", "perExpertStructuredOutput")
  .addEdge("perExpertStructuredOutput", "kbConflictAggregator")  // ★ fan-in 边
```

### 验证标准

- [ ] `npx tsc --noEmit` 零错误
- [ ] professionalGraph 编译无异常
- [ ] 2 expert mock fan-out → ExpertClaim[] 全链路通过

---

## 恢复上下文审计查询

```text
# 一键恢复
query_audit_logs({ keyword: "PROFESSIONAL_FAN_OUT" })
→ 返回所有 fan-out 相关审计记录

# 按文件恢复
query_audit_logs({ targetId: "src/lib/langgraph/send-api.ts" })
query_audit_logs({ targetId: "src/agents/agent-graph.ts" })

# 文档恢复
read ".qoder/specs/farm-agent-professional-fanout/spec.md"
read ".qoder/plans/2026-07/06/farm-agent-professional-fanout-plan-v1.md"
```

---

## 每轮收敛判定补充规则

> 以下规则与 `add-paradigm` SKILL Step 8 收敛条件并列。

### checklist 证据要求

- [ ] **全部项已勾选**（不得有空勾选、不得有"推测通过"）
- [ ] **每项勾选有可验证证据**：tsc 输出、grep 行号、测试结果
- [ ] **未执行项诚实保留**：运行时验证保留为 `- [ ]`
- [ ] **证据可直接获取**：后续 AI Session 通过 `query_audit_logs` 按 keyword 可查到

### tasks 证据要求

- [ ] **全部任务已完成**（tasks.md 中全部 `- [x]`）
- [ ] **每个任务有对应的 checklist 项覆盖**
- [ ] **task 完成状态与 ADD-7 审计记录一致**

### 收敛声明规则

执行 AI 不得自行声明"本轮已收敛"。收敛声明只能由开发者或 Review AI 做出。

---

## 附录：每轮启动模板

新对话开始时，直接把下面内容 + 对应 Round 章节粘贴给 LLM：

```text
## 上下文

你在执行 farm-agent professional-fanout 改进的 [第N轮]。
上游 [第1轮~第N-1轮] 已完成。
先读 .qoder/plans/2026-07/06/farm-agent-professional-fanout-handoff-v1.md 的 <第N轮> 章节。

## 启动操作（按顺序）

1. 执行 session-init SKILL
2. 执行 add-paradigm SKILL
3. 读本轮对应 .qoder/specs/farm-agent-professional-fanout/spec.md
4. 读本轮对应 .qoder/specs/farm-agent-professional-fanout/tasks.md
5. 读本轮对应 .qoder/specs/farm-agent-professional-fanout/checklist.md
6. 按 tasks.md 顺序执行代码修改
7. 每完成一个 Task：验证 → 附证据 → 勾选 checklist
8. 每完成一个文件：record_dev_operation 写入 ADD-7 审计
9. 完成后：query_audit_logs 回查确认落库

## 关键提醒

- 当前执行的是 [第N轮]/3
- 当前 Round 是一个原子工程事务
- handoff 是入口索引；具体实现以 spec/tasks/checklist 为准
- 禁止提前实现下一轮的核心内容
```

---

### 脱敏要求

Handoff 文档中 **禁止出现** 以下类型的硬编码值：
- 数据库密码（`POSTGRES_PASSWORD`）
- Chroma auth token（`CHROMA_AUTH_TOKEN`）
- JWT 密钥（`JWT_SECRET`）
- API Key（`OPENAI_API_KEY_*`）

所有凭据值应通过 `${ENV_VAR}` 引用，并标注"值见 `.env.development` / `.env.production`"。
