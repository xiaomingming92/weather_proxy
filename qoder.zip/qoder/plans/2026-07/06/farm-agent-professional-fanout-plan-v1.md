# farm-agent-professional-fanout-plan-v1

## PLAN 元信息

- **Plan 名称**: farm-agent-professional-fanout-v1
- **启动时间**: 2026-07-06T12:00:00+08:00
- **主导 AI**: Qoder
- **上游依赖**:
  - [ACA v3 Plan](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md)（轮次 1-3 已完成，轮次 4.1-4.2 已完成，轮次 4.3 Send API fan-out 未实现）
  - [thinking-level-runtime-fix Plan](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md)（修路由，不碰图拓扑）
- **关联文档**:
  - Add-route: `.qoder/plans/2026-07/06/farm-agent-professional-fanout-add-route-v1.md`（待生成）
  - Handoff: `.qoder/plans/2026-07/06/farm-agent-professional-fanout-handoff-v1.md`（待生成）
  - Review: `.qoder/reviews/farm-agent-professional-fanout-review-v1.md`（待生成）
  - Spec: `.qoder/specs/farm-agent-professional-fanout/spec.md`（待生成）
  - Tasks: `.qoder/specs/farm-agent-professional-fanout/tasks.md`（待生成）
  - Checklist: `.qoder/specs/farm-agent-professional-fanout/checklist.md`（待生成）
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| src/agents/agent-graph.ts | COMPONENT | COMPONENT_MODIFIED | professionalWorkflow 全 `.addEdge` 串行链（L71-121） | Send API fan-out：per-expert 并行管线 + fan-in 串行链 + toolNode 循环 | ✅ 已完成 |
| src/agents/nodes/reasoning.ts | COMPONENT | COMPONENT_UNCHANGED | 串行模式：遍历所有 expertPackages | 不变（fan-out 推理由 per-expert-reasoning.ts 负责） | ✅ 不变 |
| src/agents/nodes/retrieval.ts | COMPONENT | COMPONENT_UNCHANGED | 串行模式：单次 RAG 检索 | 不变（fan-out 检索由 per-expert-retrieval.ts 负责） | ✅ 不变 |
| src/agents/nodes/structured-output.ts | COMPONENT | COMPONENT_MODIFIED | 接收 expertPackages[]，遍历调用 LLM | fanoutExpertId 存在时从 verdictResult 取 reasoning | ✅ 已完成 |
| src/agents/nodes/per-expert-retrieval.ts | NODE | NODE_CREATED | 不存在 | 新建：fan-out 分支内单 expert RAG 检索 | ✅ 已完成 |
| src/agents/nodes/per-expert-reasoning.ts | NODE | NODE_CREATED | 不存在 | 新建：fan-out 分支内单 expert LLM 推理 + 工具结果归集 + verdictResult | ✅ 已完成 |
| src/agents/state.ts | STATE | STATE_MODIFIED | expertClaims 无 reducer；无 fanoutExpertId | expertClaims 改为带 concat reducer 的 Annotation；新增 fanoutExpertId 字段 | ✅ 已完成 |
| src/lib/langgraph/send-api.ts | COMPONENT | COMPONENT_CREATED | 不存在 | routeByExpertPlan + PROFESSIONAL_FAN_OUT 审计 | ✅ 已完成 |
| src/agents/edges/conditional.ts | EDGE | COMPONENT_MODIFIED | hasToolCalls 未导出 | 导出 hasToolCalls 供 agent-graph 使用 | ✅ 已完成 |
| src/agents/nodes/index.ts | INDEX | COMPONENT_MODIFIED | 无 structuredOutput/perExpert 导出 | 新增 structuredOutputNode + perExpertRetrievalNode + perExpertReasoningNode 导出 | ✅ 已完成 |
| tests/professional-fanout.test.ts | TEST | TEST_CREATED | 不存在 | 2-expert mock fan-out → ExpertClaim[] 集成测试 | 待实施 |

---

## 一、背景与目标

### 1.1 问题现状

`src/agents/agent-graph.ts` L71-121 的 `professionalWorkflow` 当前是**全串行 `.addEdge` 链**：

```
__start__ → intention → retrieval → reasoning → kbConflictAggregator
→ conflictResolver → aggregation → coordinationDialogue
→ interactionPointDetection → verdict → response → __end__
```

**零 Send API fan-out**。所有 expert 共享一个 `retrieval` 节点、一个 `reasoning` 节点——不存在 per-expert 并行推理。

ACA v3 Plan（`farm-agent-three-tier-reasoning-graph-plan-v3.md`）要求的 professional 图拓扑是：

```
intention (产出 expertPlan: Expert[])
    │
    ▼
┌─── Send API fan-out（per-expert 并行，零 interrupt）────┐
│  Expert A: perExpertRetrieval → perExpertReasoning →    │
│            perExpertStructuredOutput → ExpertClaim       │
│  Expert B: perExpertRetrieval → perExpertReasoning →    │
│            perExpertStructuredOutput → ExpertClaim       │
│  ★ 各自产出 ExpertClaim，KB 冲突写入 metadata           │
└──────────────────── fan-in → ExpertClaim[] ─────────────┘
    │
    ▼ kbConflictAggregator（串行，唯一 interrupt 点）
    ▼ conflictResolver → aggregation → coordinationDialogue
    ▼ interactionPointDetection → verdict → response
```

> **与 ACA v3 的差异**：ACA v3 设计为复用 deep 图的 `retrieval` + `reasoning` 节点，但会导致节点职责混杂。本 Plan 采用隔离方案——新建 `perExpertRetrieval` + `perExpertReasoning`，每个节点职责单一，不改造现有 deep 图节点。`kbConflictAggregator` 同时适配 deep 图和 professional 图——它只消费 `ExpertClaim[]`，不关心来源。

ACA v3 Plan 轮次 1-3 的节点代码（structuredOutput / kbConflictAggregator / conflictResolver / aggregation / coordinationDialogue）和轮次 4.1-4.2（intention 增强 + routeByIntent）均已就位。本 Plan（轮次 4.3）已完成 Send API fan-out 图组装 + per-expert 节点隔离。

当前 reasoningNode 在串行模式下遍历 `expertPackages[]`，逐个 expert 构建 prompt 区块后拼接为单个 LLM 调用，产出**一段**自由文本（不是 per-expert 结构体）。fan-out 模式需要拆分为：每个 expert 独立调用 reasoning → 独立调用 structuredOutput → 产出 ExpertClaim。

### 1.2 目标

1. 将 `professionalWorkflow` 从串行 `.addEdge` 改为 **LangGraph Send API fan-out + fan-in** 拓扑
2. `reasoningNode` 适配 per-expert 单上下文模式（每个 Send 分支内独立推理）
3. `retrievalNode` 适配 per-expert 检索（按 expert 的 `knowledgeBaseIds` / `realtimeToolNames` 过滤）
4. `structuredOutputNode` 适配 fan-out 模式（消费单 expert 的 reasoning 文本 → ExpertClaim）
5. fan-in 后串行链保持不变（kbConflictAggregator → conflictResolver → ... → response）
6. 零 tsc 错误，零 eslint error；现有 deep 图不受影响

### 1.3 不在本 Plan 范围内

| 项目 | 理由 |
|------|------|
| thinkingLevel 裁决逻辑 | 由 `farm-agent-thinking-level-runtime-fix-plan-v1.md` 负责 |
| KB 冲突检测算法 | 已由 kbConflictAggregator / conflictResolver 实现 |
| coordinationDialogue 约束松弛 | 已由轮次 3 实现 |
| Resume / interrupt 恢复链路 | 已由 Phase 0（h5-agent-route-code-quality）实现 |

---

## 二、方案选型

### 2.1 LangGraph Send API 调研

**LangGraph JS SDK v1.4.7**（当前安装版本，检查 `npm view @langchain/langgraph version` 已是 latest）。Send API 文档位置：
- 本地 SDK：`node_modules/@langchain/langgraph/dist/constants.d.ts` L103 `declare class Send<Node, Args>`
- 官方文档：[Use the graph API — map-reduce and the Send API](https://docs.langchain.com/oss/javascript/langgraph/use-graph-api#map-reduce-and-the-send-api)
  - 确认导入：`import { Send } from "@langchain/langgraph"`
  - 用法：`new Send(nodeName, args)` 返回 `Send<Node, Args>`
  - fan-in 边：`.addEdge("generateJoke", "bestJoke")` 在 fan-out 后显式声明

Send API 的核心机制：
- 从 conditional edge 函数返回 `Send[]` 而非单个节点名
- 每个 `Send(nodeName, stateOverride)` 在同一个 superstep 内并行执行
- 所有目标节点的输出通过 `Annotation` reducer 汇聚（如 `Annotated<ExpertClaim[], { reducer: (a, b) => [...a, ...b] }>`）
- fan-out 后自动 fan-in：所有 Send 目标完成后，图自动前进到下一节点

### 2.2 候选方案对比

| 方案 | 实现方式 | 并行度 | 复杂度 | 与现有代码兼容 | 结论 |
|------|---------|:--:|:--:|------|:--:|
| **A: Send API fan-out**（推荐） | `routeToExperts()` 返回 `Send("perExpertReasoning", { fanoutExpertId })[]` → fan-in → 串行 | ✅ 真并行 | 中 | reasoning/structuredOutput 需适配单 expert | ✅ 采纳 |
| B: 保持串行 + 批量 LLM | 当前方式：拼接 expert prompt → 单 LLM 调用 | ❌ 串行 | 低 | 零改动 | ❌ 不解决并行问题 |
| C: Promise.all 手动并行 | 在 reasoningNode 内部 `Promise.all(expertPackages.map(...))` | ⚠️ 伪并行（同一节点内） | 低 | reasoning 需改造 | ❌ 无 LangGraph 原生 fan-in |

### 2.3 选型理由

**方案 A（Send API）**是 ACA v3 Plan 设计目标，也是唯一能实现 per-expert 独立管线（retrieval → reasoning → structuredOutput）的方案。方案 B 不改图拓扑、不产生并行收益。方案 C 在单节点内 `Promise.all` 无法利用 LangGraph 的 fan-in reducer 汇聚 ExpertClaim[]，KB 冲突标记、interrupt 恢复的局部重跑等功能也无法实现。

**关键风险**：LangGraph JS Send API 与 Python 文档可能存在行为差异。缓解措施见 §七。

---

## 三、架构设计

### 3.1 目标图拓扑（实际实施）

```
professionalWorkflow（agent-graph.ts L71-119）:
───────────────────────────────────────────────────────────

__start__
    │
    ▼
intention (intentionAsyncNode)
  │ 产出 expertPlan: Expert[{ expertId, label, ... }]
  │ 写入 state.expertPlan
  ▼
routeByExpertPlan (conditional edge, src/lib/langgraph/send-api.ts)
  │  expertPlan 为空 → "kbConflictAggregator" 直通
  │  expertPlan 有值 → 返回 Send[]:
  │    new Send("perExpertRetrieval", { fanoutExpertId })
  │
  ├─[Send]→ perExpertRetrieval [fanoutExpertId="pest_risk"]
  │           │  读 ANALYSIS_EXPERTS[pest_risk].evidenceFilter → RAG
  │           │  → expertPackage → 写入 state.expertPackages
  │           ▼
  │         perExpertReasoning [fanoutExpertId="pest_risk"]
  │           │  读 expertPackages[0] + 过滤本 expert 的 toolMessages
  │           │  → loadExpertPrompt.build() → LLM invoke → verdictResult
  │           ▼
  │         perExpertStructuredOutput [fanoutExpertId="pest_risk"]
  │           │  从 verdictResult.conclusion.content 取 reasoning 文本
  │           │  → ExpertClaim → reducer concat 写入 expertClaims ──┐
  ├─[Send]→ perExpertRetrieval [fanoutExpertId="weather_impact"] ──┤
  │           ... (同上)                                            │
  └─[Send]→ perExpertRetrieval [fanoutExpertId="roi_analysis"] ────┘
                                                    │
                                          ★ 并行 superstep ★
                                          ★ 零 interrupt ★
                                          ★ 各自产出 ExpertClaim ★
                                                    │
            .addEdge("perExpertStructuredOutput", "kbConflictAggregator")
                                                    │
                                                    ▼ fan-in: ExpertClaim[]
                                              kbConflictAggregator（串行，唯一 interrupt 点）
                                                    │
                                              conflictResolver（纯函数）
                                                    │
                                              aggregation
                                                    │
                                              coordinationDialogue
                                                    │
                                              interactionPointDetection
                                                    │
                                              verdict → response → __end__
```

### 3.2 节点改造明细

| 节点 | 当前行为 | 目标行为 | 改造方式 |
|:--|:--|:--|:--|
| `intention` | ✅ 已产出 expertPlan | **不变** | — |
| `routeByExpertPlan` | ❌ 不存在 | 从 expertPlan 构建 `Send[]` 数组 | **新建** conditional edge 函数 |
| `perExpertRetrieval` | ❌ 不存在 | 接收 `state.fanoutExpertId`，查 ANALYSIS_EXPERTS[fanoutExpertId].knowledgeBaseIds 过滤检索；label 从注册表读取 | **新建**（复用 retrieval 核心逻辑） |
| `perExpertReasoning` | ❌ 不存在 | 接收 `state.fanoutExpertId` + `expertPackages[0]`，加载 per-expert prompt，注入工具结果，单 LLM 推理，产出 `verdictResult` | **新建**（职责单一：单 expert 推理 + 工具结果归集） |
| `perExpertStructuredOutput` | 遍历 expertPackages[]，`reasoningText` 为空字符串 | fan-out 分支内：reasoningNode 已产出 `verdictResult`，从 `verdictResult.conclusion.content` 取 reasoning 文本 | **改造** structuredOutputNode：`state.fanoutExpertId` 存在时从 verdictResult 读文本，不再自己构建 prompt |
| `reasoning`（deep 图） | ✅ 已有 | **不变** — 不改造，不回退为纯 deep 图逻辑 | — |
| `kbConflictAggregator` | ✅ 已实现 | **不变** | — |
| `conflictResolver` | ✅ 已实现 | **不变** | — |
| `coordinationDialogue` | ✅ 已实现 | **不变** | — |
| `aggregation` | ✅ 已实现 | **不变** | — |

### 3.2.1 deep 图 vs professional 图（fan-out 分支）的核心差异

两个图共享 structuredOutputNode，但 reasoning 和 retrieval 各自独立：

| 维度 | deep 图（串行） | professional 图 fan-out 分支 |
|------|------|------|
| `fanoutExpertId` | 不存在 | 存在（Send API 注入） |
| retrieval 节点 | 现有 `retrievalNode` | 新建 `perExpertRetrieval`（职责单一：单 expert RAG） |
| reasoning 节点 | 现有 `reasoningNode`（遍历并列提示） | 新建 `perExpertReasoning`（职责单一：单 expert LLM 推理 + 工具结果归集） |
| structuredOutputNode | `reasoningText` 为空字符串，节点自己构建 prompt | 从 `verdictResult.conclusion.content` 读取 reasoning 文本，不再自己构建 prompt |

> **隔离决策**：ACA v3 Plan 设计为复用现有 retrieval + reasoning 节点，但会导致节点职责混杂（"串行多 expert 拼接"和"fan-out 单 expert 推理"用同一个函数）。本 Plan 采用隔离方案——每个节点只做一件事，不改造现有节点。

### 3.3 State 扩展

当前 `expertClaims` 使用 `Annotation<ExpertClaim[] | null>()`（`state.ts` L160），没有 reducer。Send API fan-in 需要 `expertClaims` 使用数组 concat reducer，使得每个 Send 分支产出的 ExpertClaim 自动汇聚：

```typescript
// 改造前
expertClaims: Annotation<ExpertClaim[] | null>()

// 改造后
expertClaims: Annotation<ExpertClaim[] | null>({
  reducer: (current, update) => update 
    ? [...(current || []), ...update] 
    : current,
  default: () => null,
})
```

> 不影响非 professional 图——deep/fast 图不写 expertClaims，reducer 仅在被写入时触发。

新增 `fanoutExpertId` 字段供 Send API 分支路由标识：

```typescript
// 新增
fanoutExpertId: Annotation<string | null>(),
```

> `fanoutExpertId` 由 `new Send("perExpertRetrieval", { fanoutExpertId: "pest_risk" })` 注入每个分支的 State 副本，perExpertRetrieval / perExpertReasoning / perExpertStructuredOutput 通过 `state.fanoutExpertId` 识别当前正在处理哪个专家。fan-in 后该字段不再有意义。

### 3.4 数据流

```
intention
  │ expertPlan: Expert[{ expertId, label, knowledgeBaseIds, realtimeToolNames }]
  ▼
routeByExpertPlan()（src/lib/langgraph/send-api.ts）
  │  expertPlan 为空 → "kbConflictAggregator" 直通
  │  expertPlan 有值 → for each expert:
  │    return Send("perExpertRetrieval", { fanoutExpertId: expert.expertId })
  ▼
perExpertRetrieval (每个 Send 分支独立运行)
  │ 输入: state.fanoutExpertId
  │ 读取 ANALYSIS_EXPERTS[fanoutExpertId].knowledgeBaseIds
  │ 调用 RAG 检索 → evidenceChain[per-expert]
  │ 构建单 expert 的 expertPackage[]
  │ 写入 state.expertPackages（临时，供 reasoning 消费）
  ▼
perExpertReasoning (每个 Send 分支独立运行)
  │ 输入: state.expertPackages[0]（当前 expert 的包）
  │ 调用 loadExpertPrompt(fanoutExpertId).build()
  │ 单 LLM 推理 → state.reasoningText（自由文本）
  ▼
perExpertStructuredOutput (每个 Send 分支独立运行)
  │ 输入: state.reasoningText, state.fanoutExpertId
  │ 调用 structuredOutputNode(singleExpertInput)
  │ 产出: ExpertClaim（单个）
  │ 写入: state.expertClaims（通过 reducer concat 汇聚）
  ▼
fan-in: ExpertClaim[]（LangGraph 自动等待所有 Send 分支完成）
  ▼
kbConflictAggregator → conflictResolver → ... → response
```

### 3.5 toolNode 的位置

当前串行图中 `toolNode` 在 `intention` 后循环（`intention → toolNode → intention`）。fan-out 模式下：

- **perExpertRetrieval 内部不调用工具**——工具调用仅发生在 perExpertReasoning 的 LLM 推理过程中
- 如果 LLM 推理中需要调用工具（如 `query_insect_data`），工具调用遵循 LangGraph 标准模式：`perExpertReasoning → toolNode → perExpertReasoning`
- 工具循环在 **per-expert 子图内**完成，不跨 expert
- **隔离机制**：虽然 toolNode 是全局共享节点（L57 唯一定义），但每个 `Send` 分支通过 LangGraph 内部 state 副本隔离——perExpertReasoning 产出的 tool_calls 写入该分支的 state.messages，toolNode 执行后结果回写到同一分支的 state.messages。分支间的 state 通过 `state.fanoutExpertId` 区分，fan-in 时由 reducer（expertClaims concat）统一汇聚

---

## 四、实施步骤 + 依赖图

```
轮次 1: Send API 基础设施
  ├── Task 1.1: expertClaims reducer 改造（state.ts）
  └── Task 1.2: Send API 封装（新建 lib/langgraph/send-api.ts）
        │
        ▼
轮次 2: 节点适配
  ├── Task 2.1: perExpertRetrieval 新建（nodes/per-expert-retrieval.ts）
  │     │  产出 expertPackage → 被 2.2 消费
  │     ▼
  ├── Task 2.2: reasoningNode 单 expert 模式（改造 reasoning.ts）
  │     │  消费 2.1 的 expertPackage，产出 reasoning 文本 → 被 2.3 消费
  │     ▼
  └── Task 2.3: structuredOutputNode 单 expert 模式（改造 structured-output.ts）
        │
        ▼
轮次 3: 图组装 + 集成验证
  ├── Task 3.1: routeByExpertPlan 新建（edges/conditional.ts）
  ├── Task 3.2: professionalWorkflow 重建（agent-graph.ts）
  └── Task 3.3: 集成测试（2-expert mock fan-out → ExpertClaim[]）
```

### 轮次 1: Send API 基础设施

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 1.1 | expertClaims Reducer | `src/agents/state.ts` | `expertClaims` 从普通 `Annotation` 改为带 `reducer: concat` 的 Annotation | `tsc --noEmit` |
| 1.2 | Send API 封装 | `src/lib/langgraph/send-api.ts`（新建） | 导出 `routeByExpertPlan(state)` → `Send[]`；封装 `fanOutToExperts(expertPlan, subgraph)` 工具函数 | `tsc --noEmit` |

### 轮次 2: 节点适配

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 2.1 | perExpertRetrieval | `src/agents/nodes/per-expert-retrieval.ts`（新建） | 从 state 取 `fanoutExpertId`，查 `ANALYSIS_EXPERTS[fanoutExpertId].knowledgeBaseIds`；label 从注册表读取，调 RAG → 构建单 expert 的 `expertPackage` → 写入 state | `tsc --noEmit` + 单测 |
| 2.2 | perExpertReasoning | `src/agents/nodes/per-expert-reasoning.ts`（新建） | 读 `fanoutExpertId` + `expertPackages[0]`，加载 per-expert prompt，过滤本 expert 的 toolMessages 注入 `toolResults`，单 LLM invoke，解析产出 `verdictResult` | `tsc --noEmit` + 单测 |
| 2.3 | structuredOutputNode fan-out 上下文 | `src/agents/nodes/structured-output.ts` | `state.fanoutExpertId` 存在时从 `verdictResult.conclusion.content` 读取 reasoning 文本；不存在时保持空字符串（自己构建 prompt） | `tsc --noEmit` + 单测 |

### 轮次 3: 图组装 + 集成验证

| # | 任务 | 文件 | 说明 | 验收 |
|---|------|------|------|------|
| 3.1 | routeByExpertPlan | `src/agents/edges/conditional.ts` | 新增 `routeByExpertPlan`：读 `state.expertPlan`，返回 `Send("perExpertRetrieval", { fanoutExpertId })[]`；空计划返回 `"kbConflictAggregator"` 直通 | `tsc --noEmit` |
| 3.2 | professionalWorkflow 重建 | `src/agents/agent-graph.ts` | 替换现有串行 professionalWorkflow 为 Send API fan-out 拓扑；添加 `perExpertRetrieval` / `perExpertReasoning` / `perExpertStructuredOutput` 节点 | 图编译无异常 |
| 3.3 | 集成验证 | `tests/professional-fanout.test.ts`（新建） | 2 expert mock：pest_risk + weather_impact → fan-out → ExpertClaim[] → kbConflictAggregator → conflictResolver | 端到端通过 |

---

## 五、验收标准

### 编译期

- [ ] `npx tsc --noEmit` 零错误
- [ ] `npm run lint` 零 eslint error
- [ ] professionalGraph 编译无异常

### 单元测试

- [ ] routeByExpertPlan：3 expert → 3 个 Send；0 expert → 直通 kbConflictAggregator
- [ ] perExpertRetrieval：按 fanoutExpertId 正确过滤 knowledgeBaseIds
- [ ] reasoningNode 单 expert 模式产出正确 reasoning 文本
- [ ] structuredOutputNode 单 expert 模式产出正确 ExpertClaim
- [ ] expertClaims reducer：2 个分支各产出 1 个 ExpertClaim → concat 为 2 个

### 集成测试

- [ ] 2 expert mock fan-out → ExpertClaim[] → kbConflictAggregator → conflictResolver → aggregation 全链路
- [ ] expertClaims 汇聚正确（2 个 Send 分支完成 → state.expertClaims.length === 2）

### 回归测试

- [ ] deep 图单专家推理不受影响（pest_risk → deep 图 → 正确响应）
- [ ] fast 图不受影响
- [ ] isSummary 路径（weekly_report）不受影响

---

## 六、关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| ACA v3 Plan | `.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md` | ✅ 权威上游 |
| thinking-level-runtime-fix | `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md` | ✅ 并行 Plan（修路由） |
| Add-route | `.qoder/plans/2026-07/06/farm-agent-professional-fanout-add-route-v1.md` | ✅ 已生成 |
| Handoff | `.qoder/plans/2026-07/06/farm-agent-professional-fanout-handoff-v1.md` | 待生成 |
| Review | `.qoder/reviews/farm-agent-professional-fanout-review-v1.md` | ✅ 已生成 |
| Spec | `.qoder/specs/farm-agent-professional-fanout/spec.md` | ✅ 已生成 |
| Tasks | `.qoder/specs/farm-agent-professional-fanout/tasks.md` | ✅ 已生成 |
| Checklist | `.qoder/specs/farm-agent-professional-fanout/checklist.md` | ✅ 已生成 |

---

## 七、风险矩阵

| 风险 | 概率 | 影响 | 缓解措施 |
|------|:--:|------|---------|
| LangGraph JS Send API 行为与 Python 文档不一致 | 中 | 高 — fan-out 失败则 professional 图不可用 | 轮次 1.2 先做 Send API 最小可行性验证（2 expert mock fan-out） |
| PostgresSaver 并发写 checkpoint 竞态（同一 threadId 多分支并发写） | 低 | 中 — checkpoint 覆盖导致 State 丢失 | 轮次 3.3 集成测试覆盖并发写场景 |
| reasoningNode 单 expert 模式与现有串行模式切换逻辑 bug | 中 | 中 — deep 图受影响 | 通过 `state.fanoutExpertId` 存在性判断模式切换；deep 图回归测试 |
| perExpertRetrieval 多个 expert 同时调用向量数据库导致 QPS 过载 | 低 | 低 — 专家数通常 ≤5 | 不做限流（专家数少）；后续按需加并发控制 |
| structuredOutputNode 单 expert 模式 JSON parse 失败率上升（串行模式有多次重试） | 低 | 低 — 现有 MAX_RETRIES=2 不变 | 保留现有重试 + 降级机制 |

---

## 八、补充说明

### 8.1 与 thinking-level-runtime-fix Plan 的职责边界

| Plan | 职责 | 边界 |
|------|------|------|
| `thinking-level-runtime-fix` | 修 routeByIntent → professional 路由可达 | 不碰 professionalWorkflow 图拓扑 |
| **本 Plan** | 将 professionalWorkflow 从串行改为 Send API fan-out | 不碰 resolveThinkingLevel / Router |

两个 Plan 无代码冲突——thinking-level-runtime-fix 修改 `resolveThinkingLevel` 和 `intention.ts` 的 `thinkingLevel` 写入逻辑（均在串行图执行前），本 Plan 修改 reasoning/retrieval/structuredOutput 节点和 agent-graph.ts 的图编译。

### 8.2 LangGraph JS Send API 语法参考

根据 LangGraph JS v1.3.2 文档，Send API 的用法：

```typescript
import { Send } from "@langchain/langgraph"

// conditional edge 返回 Send 数组实现 fan-out
function routeByExpertPlan(state: AgentState): Send[] | string {
  const expertPlan = state.expertPlan
  if (!expertPlan || expertPlan.length === 0) {
    return "kbConflictAggregator" // 直通
  }
  return expertPlan.map(expert =>
    new Send("perExpertRetrieval", { fanoutExpertId: expert.expertId })
  )
}

// 图定义
professionalWorkflow
  .addConditionalEdges("intention", routeByExpertPlan, [
    "perExpertRetrieval",
    "kbConflictAggregator",
  ])
  .addNode("perExpertRetrieval", perExpertRetrievalNode)
  .addNode("perExpertReasoning", perExpertReasoningNode)
  .addNode("perExpertStructuredOutput", perExpertStructuredOutputNode)
  .addEdge("perExpertRetrieval", "perExpertReasoning")
  .addEdge("perExpertReasoning", "perExpertStructuredOutput")
  // fan-out 所有 Send 目标完成后，自动 fan-in 到 kbConflictAggregator
  .addEdge("perExpertStructuredOutput", "kbConflictAggregator")
```

> ⚠️ Send API 语法以实际 `@langchain/langgraph` 版本为准。轮次 1.2 必须先读取 `node_modules/@langchain/langgraph/dist/graph/state.d.ts` 确认 API。

### 8.3 reasoningNode 双模式切换设计

```typescript
// reasoning.ts L66 改造后
export async function reasoningNode(state: typeof AgentState.State) {
  // fan-out 模式：state.fanoutExpertId 由 Send API 注入
  if (state.fanoutExpertId) {
    return singleExpertReasoning(state) // 新路径
  }
  // 串行模式：deep 图回退
  return multiExpertReasoning(state) // 现有逻辑
}
```

通过 `state.fanoutExpertId` 的存在性区分：
- `fanoutExpertId` 存在 → fan-out 分支，单 expert 推理
- `fanoutExpertId` 不存在 → deep 图（或旧 professional 图），维持现有逻辑
