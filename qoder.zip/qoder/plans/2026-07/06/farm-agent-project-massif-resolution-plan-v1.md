# farm-agent-project-massif-resolution-plan-v1

> **Plan/Spec 边界提醒**：Plan 回答"改什么、为什么改、改哪里"——写到让 Review 能判断方向对不对、有没有遗漏维度的程度（文件路径 + Task 验收标准 + 架构维度全覆盖）。**不要**在 Plan 中写完整 TS 类型定义、WHEN-THEN 场景、精确函数签名——那是 Spec 的职责。

## PLAN 元信息

- **Plan 名称**: farm-agent-project-massif-resolution-v1
- **启动时间**: 2026-07-06T15:00:00+08:00
- **主导 AI**: Qoder
- **触发来源**: `farm-agent-thinking-level-runtime-fix-plan-v1` Step 8 验收期间发现 gap：全农场卡片语义与 param_missing 互斥；Review 讨论后扩大范围至全路径（卡片 + 自然对话），param_missing 定位为最后防线而非第一反应
- **前置依赖**: `farm-agent-thinking-level-runtime-fix-plan-v1`（thinkingLevel A+C 裁决 + SkillCard 预计算决策表 + massifIds 字段）
- **关联文档**:
  - Handoff: `.qoder/plans/2026-07/06/farm-agent-project-massif-resolution-handoff-v1.md`
  - Review: `.qoder/reviews/farm-agent-project-massif-resolution-review-v1.md`
- **ADD-7 审计策略**:

| 文件 | targetType | action | beforeState | afterState | 状态 |
|-----|-----------|--------|------------|-----------|------|
| `src/lib/farm-project-context.ts` | LIB | LIB_MODIFIED | activedProjectId 仅内存存储，无 API 查询能力 | 新增 `resolveProjectMassifIds(projectId)` 函数 | 待实施 |
| `src/lib/farm-api/massif.ts` | API | API_MODIFIED | getPage 无 projectId 筛选 | getPage 支持 projectId 参数；新增 `getAllByProjectId` | 待实施 |
| `src/agents/nodes/intention.ts` | NODE | NODE_MODIFIED | 全农场语义时依赖 param_missing 弹出选择器 | 消费 route 层注入的 prebuiltMassifIds，全路径（卡片+自然对话）均受益 | 待实施 |
| `src/agents/agent-runner.ts` | AGENT_RUNNER | AGENT_RUNNER_MODIFIED | StreamAgentInput 无 prebuiltMassifIds | 新增 prebuiltMassifIds: number[] | 待实施 |
| `src/agents/state.ts` | STATE | STATE_MODIFIED | 无 prebuiltMassifIds | 新增 prebuiltMassifIds Annotation | 待实施 |
| `src/app/api/agent/chat/stream/route.ts` | API | API_MODIFIED | 透传 massifId 单值 | 每次 chat 请求无条件调 resolveProjectMassifIds → 注入 prebuiltMassifIds（系统级默认值） | 待实施 |
| `src/caijuehub/strategies/resolve-tool-params.ts` | STRATEGY | STRATEGY_MODIFIED | 仅检查 massifId + massifIds | 新增 prebuiltMassifIds 检查 | 待实施 |
| `src/api/agent/contracts/dashboard-contract.ts` | CONTRACT | CONTRACT_MODIFIED | massifIds 字段仅用于卡片展示 | 不变（语义已有），注释补充全农场解析说明 | 待实施 |

- **原子事务结构**: 3 轮
  - 第1轮：farm-api 层 + farm-project-context 层（数据源 + 上下文注入）
  - 第2轮：intention.ts 调用方 + state + route 契约（消费端串联）
  - 第3轮：resolve-tool-params.ts 补位 + tsc + eslint 验证

---

## 一、背景与目标

### 1.1 问题现状

`farm-agent-thinking-level-runtime-fix-plan-v1` 为 SkillCard 引入了 `massifIds` 字段，区分了两种地块模式：

- **指定地块**（massifIds = [1,2]）：工具调用透传，跳过 param_missing
- **全农场**（massifIds = undefined）：缺参时触发 param_missing SSE 事件

但"全农场"的触发机制有两个层面的缺陷：

**缺陷一：语义矛盾**。param_missing 的本意是让用户补选地块，而"全农场"的语义本应是"对项目下所有地块执行分析"，不应弹出选择器。农业软件行业的共识是：模糊语义（不提具体地块）= 默认"我的项目/农场"。

**缺陷二：param_missing 定位错误**。当前 param_missing 是"用户没手动填 massifId 就弹"的第一反应。正确的定位应该是最后一道防线——只在系统确无能力获取地块数据时才弹出。LLM 已有 `query_massif` 工具可按名称模糊搜索地块（用户说"地块A"时 LLM 应主动调此工具解析，而非让用户在 param_missing 选择器里找），activedProjectId 已在上下文中（系统应主动用它解析全项目地块），两者用尽后才应弹出选择器。

**缺陷三：自然对话路径完全遗漏**。用户自由打字"帮我分析虫情"时，expertIds 为空 → route 层不做任何解析 → prebuiltMassifIds 为 null → LLM 调 query_insect_data 缺参 → 触发 param_missing。与卡片路径问题同源。

根因：

1. `activedProjectId` 已在 handshake 时存入 `farm-project-context.ts`（[L14](file:///home/xmm/ai/farm-agent/src/lib/farm-project-context.ts#L14)），供工具调用透传至 Farm-Server
2. Farm-Server 有 `/farm/massif/options` 和 `/farm/massif/page` 端点可以拿到项目地块列表
3. 但**没有任何代码**自动调用 `projectId → massifIds[]` 解析
4. 导致卡片点击 + 自由打字两种路径下，LLM 调农情工具时均可能缺参 → 触发 param_missing

**影响面**：所有 9 张不传 massifIds 的卡片 + 推荐话题 + 自然对话中的"不限地块"语义，全部受此 gap 影响。

### 1.2 目标

- `activedProjectId` 存在时，route 层自动解析为项目下全量地块 ID 列表，注入 `prebuiltMassifIds`——系统级默认值，覆盖**全路径**（卡片点击 + 自然对话）
- 工具调用不再因缺 massifId 而触发 param_missing（已有全项目地块数据兜底）
- 指定地块卡片（massifIds 已预填充）行为不变
- activedProjectId 不存在或解析失败时，回退到 param_missing（最后防线）
- 零 tsc 错误，零 eslint error

### 1.3 非目标

- 不改变 Handshake 协议（activedProjectId 已有）
- 不改变 SkillCard 数据结构（massifIds 字段已有）
- 不改变 deep / professional 图内部逻辑
- 不改变 LLM 通过 `query_massif` 工具解析地名→ID 的现有能力（这不是本 Plan 范围，但本 Plan 的 `prebuiltMassifIds` 默认值与 `query_massif` 精确解析形成互补）

---

## 二、方案设计

### 2.1 数据流（全路径统一）

```
Handshake → activedProjectId=1001
                │
    任何 chat 请求进入 route.ts
                │
                ▼
① massifId/massifIds 均未传？
   → 调 resolveProjectMassifIds()
   → 成功：prebuiltMassifIds = [1,2,3,4,5,7,8,9,10]
   → 失败/null：prebuiltMassifIds = null（回退到 param_missing）
                │
        ┌───────┴───────┐
        ▼               ▼
   卡片路径            自然对话路径
  (explicitIntent)   (LLM 意图解析)
        │               │
        ▼               ▼
   intentionNode 消费 prebuiltMassifIds
   → resolveToolParams: 有值 → 不缺参 → 不触发 param_missing
        │
        ▼
   如有更精确地块名（如用户说"地块A"）
   → LLM 调 query_massif(name="地块A") 精确解析
   → 覆盖默认的 prebuiltMassifIds
```

**关键设计决策**：解析从 intention 层上提到 route 层——不等意图节点判断是什么路径，而是作为系统级默认值提前注入。这样无论用户是点卡片还是打字，只要 activedProjectId 有效就受益。

### 2.2 地块解析的互补机制

本 Plan 不改变 LLM 通过 `query_massif` 工具按名称模糊搜索地块的现有能力。两者是互补关系：

| 场景 | prebuiltMassifIds 默认值 | LLM query_massif 精确解析 | 最终效果 |
|------|:--:|:--:|------|
| "帮我分析虫情" | [1,2,3,...,N] 全项目 | 不需要（语义模糊） | 全农场分析 |
| "地块A虫情" | [1,2,3,...,N] 全项目 | 调 query_massif → 命中 massifId=X | 精确到地块A |
| "地块A虫情"（未命中）| [1,2,3,...,N] 全项目 | 调 query_massif → 未命中 → param_missing | 弹出选择器 |
| 未登录 | null | 不可用 | param_missing（最后防线） |

### 2.3 回退路径

| 场景 | activedProjectId | Farm-Server 响应 | 行为 |
|------|:--:|:--:|------|
| 正常 | 1001 | [1,2,3,...] | 自动填充 massifIds |
| 无项目上下文 | null | — | **触发 param_missing**（回退） |
| Farm-Server 不可达 | 1001 | 网络错误 | **触发 param_missing**（回退） |
| 项目下无地块 | 1001 | [] | **触发 param_missing**（回退） |
| 已有指定地块 | — | — | 跳过解析（massifIds 已预填充） |

### 2.4 已知限制：多地块工具调用的串行瓶颈

`prebuiltMassifIds` 消解了 param_missing——但**不保证多地块工具调用的性能**。

当前 `query_insect_data` / `query_soil_moisture` / `query_farm_weather` 等农情工具接受单个 `massifId`。deep 图中 `toolNode → intention` 是循环边（[agent-graph.ts L60](file:///home/xmm/ai/farm-agent/src/agents/agent-graph.ts#L60)），LLM 需要为每个地块发起一次独立工具调用，每次循环都是完整的 LLM 往返：

```
9 个地块 × 每次 toolNode→intention LLM 往返
  → state.messages 不断膨胀（所有工具结果堆在消息历史里）
  → 可能超 token 限制或延迟过高（30s+）
```

professional 图的 fan-out（当前串行赝品，见 `farm-agent-professional-fanout-plan-v1`）同样存在此瓶颈：fan-out 解决的是 experts 之间的并行，不解决单个 expert 内部的多个地块串行工具调用。

**缓解措施**（本 Plan 不实施，留给后续）：
- 工具批处理：改工具签名为 `massifIds: number[]`，单次调用内部遍历
- 地块数上限：prebuiltMassifIds 截断为前 N 个代表性地块
- 汇总优先：全农场场景走 summary expert（daily_report / weekly_report），只展示聚合数据

> 本 Plan 的定位类比 `thinking-level-runtime-fix`：Route 层正确注入默认值（就像 thinking-level Plan 让路由通往 professional）。下游 DAG 的处理能力由各自 Plan 负责——deep 图的多地块循环是 LangGraph 原生行为，professional 的 fan-out 是 `farm-agent-professional-fanout-plan-v1` 的职责。

### 2.5 与 professional-fanout Plan 的配合

---

## 三、实施 Task + 依赖图

```
第1轮: farm-api 层 (massif.ts 新增 API + farm-project-context.ts 新增解析函数)
    │
    ▼
第2轮: intention.ts + state.ts + route.ts + agent-runner.ts (消费端串联)
    │
    ▼
第3轮: resolve-tool-params.ts 补位 + tsc + eslint
```

### 第1轮：数据源层 — Farm-Server API + 上下文注入

- [x] `src/lib/farm-api/massif.ts`：
  - `getPage()` 签名新增 `projectId?: number`，透传 query 参数（L60）
  - 新增 `getAllByProjectId(projectId: number)`，调 `/farm/massif/options?projectId={projectId}`（L74）

- [x] `src/lib/farm-project-context.ts`：
  - 新增 `resolveProjectMassifIds(): Promise<number[] | null>`（L72-110）
    - activedProjectId null → return null
    - getFarmToken() → createMassifApi() → getAllByProjectId(projectId)
    - response.code ≠ 200 / data 为空 → return null
    - 成功 → agentAudit("PROJECT_MASSIF_RESOLVE") + return massifIds
    - catch → agentAudit + return null

- [x] `src/lib/log/phase.ts`：新增 `ProjectMassifPhase`（L203-206）并入 `AgentAuditPhase`（L220）

### 第2轮：消费端串联 — intention.ts + state + route + agent-runner

- [x] `src/agents/agent-runner.ts`：`StreamAgentInput.prebuiltMassifIds?: number[] | null`（L46）

- [x] `src/agents/state.ts`：`prebuiltMassifIds: Annotation<number[] | null>()`（L134）

- [x] `src/app/api/agent/chat/stream/route.ts`：
  - import `resolveProjectMassifIds`（L13）
  - `streamAgent` 前 try/catch 调用 `resolveProjectMassifIds()`（L264-272）
  - 注入 `prebuiltMassifIds` 到 `StreamAgentInput`（L283）

- [x] `src/agents/nodes/intention.ts`：
  - explicitIntent 分支：prebuiltMassifIds 有值时 `agentAudit("PROJECT_MASSIF_PREFILL")`（L173-177）

### 第3轮：补位 + 验证

- [x] `src/caijuehub/strategies/resolve-tool-params.ts`：
  - 3 个规则 `available()` 新增 `(s.prebuiltMassifIds?.length ?? 0) > 0`（L36/43/50）

- [x] `npx tsc --noEmit` 零错误
- [x] `npx eslint src/` 零 error
- [ ] 端到端验证：
  - 点击"周报分析"卡片 → 不触发 param_missing
  - 自由打字"帮我分析虫情" → 不触发 param_missing（全农场默认值）
  - 自由打字"地块A虫情" → LLM 主动调 query_massif 解析

---

### 3.1 实际实现的数据流（文件级）

```
HTTP POST /api/agent/chat/stream (route.ts L264-278)
  │ ① 调 resolveProjectMassifIds()（farm-project-context.ts L72-110）
  │    ├─ activedProjectId=null → return null
  │    ├─ getFarmToken() → createMassifApi() → getAllByProjectId(projectId)
  │    │   └─ GET /farm/massif/options?projectId={projectId}（massif.ts L74）
  │    ├─ response.code !== 200 → return null
  │    ├─ data.map(m => m.id) → length === 0 → return null
  │    └─ return [1, 2, 3, ..., N]
  │ ② try/catch → 异常时 prebuiltMassifIds 保持 null
  │ ③ 注入 streamAgent({ prebuiltMassifIds, ... })
  │
  ▼ streamAgent → AgentState
  │   └─ prebuiltMassifIds: Annotation<number[] | null>()（state.ts L134）
  │
  ▼ intentionNode（intention.ts L173-177）
  │   └─ prebuiltMassifIds 有值 → agentAudit("PROJECT_MASSIF_PREFILL")
  │
  ▼ deep/professional 图 → LLM 调 query_insect_data(massifId=...)
  │
  ▼ resolveMissingToolParams()（resolve-tool-params.ts L36/43/50）
      └─ available(s): s.prebuiltMassifIds?.length > 0 → true → 不缺参
      └─ 不触发 param_missing
```

**回退链**（任意环节失败 → prebuiltMassifIds=null → resolveToolParams 触发 param_missing）：
- activedProjectId 为 null
- getFarmToken() 返回 null
- Farm-Server options API 网络错误
- 响应 code ≠ 200
- 响应 data 为空数组 []
- resolveProjectMassifIds() 抛出异常

---

## 四、验收标准

- [x] activedProjectId=1001 且项目下有 9 个地块 → route 层自动注入 prebuiltMassifIds（grep 确认 L265/283）
- [ ] 点击"周报分析"卡片 → deep 图推理 → `query_insect_data` 不缺参 → 不触发 param_missing
- [ ] 自由打字"帮我分析虫情" → deep 图推理 → 不缺参 → 不触发 param_missing
- [ ] 自由打字"地块A虫情" → LLM 主动调 `query_massif(name="地块A")` 精确解析
- [x] 点击"地块虫害分析"卡片（massifIds=[1,2]）→ 跳过 projectId 解析 → 行为不变（route.ts L267 条件判断保护）
- [ ] activedProjectId=null → 不自动解析 → 触发 param_missing（回退）
- [x] Farm-Server 不可达 → route 层 try/catch → prebuiltMassifIds=null → 触发 param_missing（回退）（route.ts L268-271）
- [x] 项目下无地块（空数组）→ 触发 param_missing（回退）（farm-project-context.ts L97-99）
- [x] `npx tsc --noEmit` 零错误
- [x] `npx eslint src/` 零 error

---

## 六、已知限制与后续 Plan 配合

### 6.1 多地块工具调用的串行瓶颈

（同 §2.4）

### 6.2 与 professional-fanout Plan 的职责边界

```
系统获取地块数据的优先级：
  1. 用户已选具体地块（massifId/massifIds 已传）              → 直接使用
  2. 系统默认值（route 层 resolveProjectMassifIds）            → 全项目地块
  3. LLM 精确解析（用户提地名 → LLM 调 query_massif 工具）    → 精确到指定地块
  4. param_missing SSE 事件（以上均不可用）                   → 最后防线，弹出选择器
```

**param_missing 不应是"用户没手动选就弹"的第一反应，而是系统穷尽所有自动解析手段后的回退。**

| Plan | 职责 | 边界 |
|------|------|------|
| `thinking-level-runtime-fix` | 修 routeByIntent → professional 路由可达 | 不碰 professionalWorkflow 图拓扑 |
| **本 Plan** | route 层注入 prebuiltMassifIds → 全路径不触发 param_missing | 不碰 deep/professional 图内部逻辑 |
| `professional-fanout` | professionalWorkflow 串行→Send API fan-out | 不碰 resolveThinkingLevel / Router / param_missing |

**执行顺序建议**：本 Plan → professional-fanout。先让 param_missing 不挡路（所有路径都能走进 Agent），再做并行推理。

### 6.3 param_missing 在系统中的最终定位

```
系统获取地块数据的优先级：
  1. 用户已选具体地块（massifId/massifIds 已传）              → 直接使用
  2. 系统默认值（route 层 resolveProjectMassifIds）            → 全项目地块
  3. LLM 精确解析（用户提地名 → LLM 调 query_massif 工具）    → 精确到指定地块
  4. param_missing SSE 事件（以上均不可用）                   → 最后防线，弹出选择器
```

**param_missing 不应是"用户没手动选就弹"的第一反应，而是系统穷尽所有自动解析手段后的回退。**

---

## 七、关联文档

| 文档 | 路径 |
|------|------|
| 前置 Plan（thinkingLevel 裁决） | `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md` |
| 下游 Plan（professional fan-out） | `.qoder/plans/2026-07/06/farm-agent-professional-fanout-plan-v1.md` |
| Farm-Server 地块 API | `src/lib/farm-api/massif.ts` |
| Farm-Project 上下文 | `src/lib/farm-project-context.ts` |
| Dashboard 契约 | `src/api/agent/contracts/dashboard-contract.ts` |
| API 对接文档 | `docs/大田精准耕播智能决策系统/knowledge/02-规范/神经元GUI-API对接文档.md` |
| Handoff | `.qoder/plans/2026-07/06/farm-agent-project-massif-resolution-handoff-v1.md` |
| Review | `.qoder/reviews/farm-agent-project-massif-resolution-review-v1.md` |
