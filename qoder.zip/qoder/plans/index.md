# Plans 总览

> 自动生成: 2026-07-22 11:25:53 | 文档总数: 227 | 下次更新: 每天 2:00 AM


## 2026-07

| 日 | 类型 | 文档 | 主题 |
|---|------|------|------|
| 01 | add-route | [farm-agent-domain-vocabulary-add-route-v2.md](2026-07/01/farm-agent-domain-vocabulary-add-route-v2.md) | farm-agent-domain-vocabulary-add-route-v2 |
| 01 | add-route | [farm-agent-log-audit-unify-add-route-v1.md](2026-07/01/farm-agent-log-audit-unify-add-route-v1.md) | farm-agent-log-audit-unify-add-route-v1 |
| 01 | add-route | [farm-agent-project-context-activation-add-route-v1.md](2026-07/01/farm-agent-project-context-activation-add-route-v1.md) | farm-agent-project-context-activation-add-route-v1 |
| 01 | add-route | [farm-agent-report-closure-integration-add-route-v1.md](2026-07/01/farm-agent-report-closure-integration-add-route-v1.md) | farm-agent-report-closure-integration-add-route-v1 |
| 01 | add-route | [farm-agent-time-standardization-add-route-v1.md](2026-07/01/farm-agent-time-standardization-add-route-v1.md) | farm-agent-time-standardization-add-route-v1 |
| 01 | add-route | [gateway-runtime-fix-service-accounts-contract-add-route-v1.md](2026-07/01/gateway-runtime-fix-service-accounts-contract-add-route-v1.md) | gateway-runtime-fix-service-accounts-contract-add-route-v1 |
| 01 | handoff | [code-review-gateway-report-system-handoff-v1.md](2026-07/01/code-review-gateway-report-system-handoff-v1.md) | farm-agent — Reports 文档体系 + Gateway 边界报告链路 交接手册 |
| 01 | handoff | [farm-agent-domain-vocabulary-handoff-v2.md](2026-07/01/farm-agent-domain-vocabulary-handoff-v2.md) | farm-agent — 8 轮原子事务交接手册 |
| 01 | handoff | [farm-agent-log-audit-unify-handoff-v1.md](2026-07/01/farm-agent-log-audit-unify-handoff-v1.md) | farm-agent-log-audit-unify-handoff-v1 |
| 01 | handoff | [farm-agent-project-context-activation-handoff-v1.md](2026-07/01/farm-agent-project-context-activation-handoff-v1.md) | farm-agent-project-context-activation-handoff-v1 |
| 01 | handoff | [farm-agent-report-closure-integration-handoff-v1.md](2026-07/01/farm-agent-report-closure-integration-handoff-v1.md) | farm-agent-report-closure-integration-handoff-v1 |
| 01 | handoff | [farm-agent-time-standardization-handoff-v1.md](2026-07/01/farm-agent-time-standardization-handoff-v1.md) | farm-agent — 时间规范化治理 交接手册 |
| 01 | handoff | [gateway-runtime-fix-service-accounts-contract-handoff-v1.md](2026-07/01/gateway-runtime-fix-service-accounts-contract-handoff-v1.md) | gateway-runtime-fix-service-accounts-contract-handoff-v1 |
| 01 | handoff | [gateway-runtime-fix-service-accounts-prisma-init-handoff-v1.md](2026-07/01/gateway-runtime-fix-service-accounts-prisma-init-handoff-v1.md) | gateway-runtime-fix-service-accounts-prisma-init-handoff-v1 |
| 01 | plan | [code-review-gateway-report-system-plan-v1.md](2026-07/01/code-review-gateway-report-system-plan-v1.md) | Plan: Report 文档体系搭建 + Gateway 边界报告链路纠正 |
| 01 | plan | [farm-agent-analysis-to-action-plan-v1.md](2026-07/01/farm-agent-analysis-to-action-plan-v1.md) | farm-agent-analysis-to-action-plan-v1 |
| 01 | plan | [farm-agent-domain-vocabulary-plan-v2.md](2026-07/01/farm-agent-domain-vocabulary-plan-v2.md) | farm-agent-domain-vocabulary-plan-v2 |
| 01 | plan | [farm-agent-log-audit-unify-plan-v3.md](2026-07/01/farm-agent-log-audit-unify-plan-v3.md) | farm-agent-log-audit-unify-plan-v3 |
| 01 | plan | [farm-agent-pnpm-migration-plan-v1.md](2026-07/01/farm-agent-pnpm-migration-plan-v1.md) | farm-agent-pnpm-migration-plan-v1 |
| 01 | plan | [farm-agent-project-context-activation-plan-v1.md](2026-07/01/farm-agent-project-context-activation-plan-v1.md) | farm-agent-project-context-activation-plan-v1 |
| 01 | plan | [farm-agent-report-closure-integration-plan-v1.md](2026-07/01/farm-agent-report-closure-integration-plan-v1.md) | farm-agent-report-closure-integration-plan-v1 |
| 01 | plan | [farm-agent-time-standardization-plan-v1.md](2026-07/01/farm-agent-time-standardization-plan-v1.md) | farm-agent-time-standardization-plan-v1 |
| 01 | plan | [gateway-runtime-fix-service-accounts-contract-plan-v1.md](2026-07/01/gateway-runtime-fix-service-accounts-contract-plan-v1.md) | gateway-runtime-fix-service-accounts-contract-plan-v1 |
| 01 | plan | [gateway-runtime-fix-service-accounts-prisma-init-plan-v1.md](2026-07/01/gateway-runtime-fix-service-accounts-prisma-init-plan-v1.md) | gateway-runtime-fix-service-accounts-prisma-init-plan-v1 |
| 02 | add-route | [farm-agent-eslint-fix-add-route-v1.md](2026-07/02/farm-agent-eslint-fix-add-route-v1.md) | farm-agent-eslint-fix-add-route-v1 |
| 02 | add-route | [farm-agent-zod-dto-convergence-add-route-v1.md](2026-07/02/farm-agent-zod-dto-convergence-add-route-v1.md) | farm-agent-zod-dto-convergence-add-route-v1 |
| 02 | handoff | [farm-agent-eslint-fix-handoff-v1.md](2026-07/02/farm-agent-eslint-fix-handoff-v1.md) | farm-agent — ESLint 全量修复（error 清零 + cast 消除 + unused-vars 清理）交接手册 |
| 02 | handoff | [farm-agent-zod-dto-convergence-handoff-v1.md](2026-07/02/farm-agent-zod-dto-convergence-handoff-v1.md) | farm-agent — Zod-DTO 收敛 交接手册 |
| 02 | plan | [farm-agent-eslint-fix-plan-v1.md](2026-07/02/farm-agent-eslint-fix-plan-v1.md) | farm-agent-eslint-fix-plan-v1 |
| 02 | plan | [farm-agent-zod-dto-convergence-plan-v1.md](2026-07/02/farm-agent-zod-dto-convergence-plan-v1.md) | farm-agent-zod-dto-convergence-plan-v1 |
| 03 | plan | [chat-panel-refactor.md](2026-07/03/chat-panel-refactor.md) | chat-panel.tsx 重构：Streaming 逻辑与 UI 分离 |
| 04 | add-route | [farm-agent-add-template-standardization-add-route-v1.md](2026-07/04/farm-agent-add-template-standardization-add-route-v1.md) | farm-agent-add-template-standardization-add-route-v1 |
| 04 | add-route | [farm-agent-thinking-level-runtime-fix-add-route-v1.md](2026-07/04/farm-agent-thinking-level-runtime-fix-add-route-v1.md) | farm-agent-thinking-level-runtime-fix-add-route-v1 |
| 04 | handoff | [farm-agent-thinking-level-runtime-fix-handoff-v1.md](2026-07/04/farm-agent-thinking-level-runtime-fix-handoff-v1.md) | farm-agent-thinking-level-runtime-fix — 5 轮原子事务交接手册 |
| 04 | plan | [farm-agent-add-template-standardization-plan-v1.md](2026-07/04/farm-agent-add-template-standardization-plan-v1.md) | add-template-standardization-plan-v1 |
| 04 | plan | [farm-agent-thinking-level-runtime-fix-plan-v1.md](2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md) | farm-agent-thinking-level-runtime-fix-plan-v1 |
| 04 | plan | [llm-config-centralization-plan-v1.md](2026-07/04/llm-config-centralization-plan-v1.md) | llm-config-centralization-plan-v1 |
| 04 | plan | [sse-interrupt-threadId-boundary-fix-plan-v1.md](2026-07/04/sse-interrupt-threadId-boundary-fix-plan-v1.md) | sse-interrupt-threadId-boundary-fix-plan-v1 |
| 06 | add-route | [farm-agent-professional-fanout-add-route-v1.md](2026-07/06/farm-agent-professional-fanout-add-route-v1.md) | farm-agent-professional-fanout-add-route-v1 |
| 06 | add-route | [farm-agent-project-massif-resolution-add-route-v1.md](2026-07/06/farm-agent-project-massif-resolution-add-route-v1.md) | farm-agent-project-massif-resolution-add-route-v1 |
| 06 | handoff | [farm-agent-professional-fanout-handoff-v1.md](2026-07/06/farm-agent-professional-fanout-handoff-v1.md) | farm-agent — 3 轮原子事务交接手册 |
| 06 | handoff | [farm-agent-project-massif-resolution-handoff-v1.md](2026-07/06/farm-agent-project-massif-resolution-handoff-v1.md) | farm-agent — 3 轮原子事务交接手册 |
| 06 | plan | [farm-agent-professional-fanout-plan-v1.md](2026-07/06/farm-agent-professional-fanout-plan-v1.md) | farm-agent-professional-fanout-plan-v1 |
| 06 | plan | [farm-agent-project-massif-resolution-plan-v1.md](2026-07/06/farm-agent-project-massif-resolution-plan-v1.md) | farm-agent-project-massif-resolution-plan-v1 |
| 07 | add-route | [farm-agent-spatial-reasoning-add-route-v1.md](2026-07/07/farm-agent-spatial-reasoning-add-route-v1.md) | farm-agent-spatial-reasoning-add-route-v1 |
| 07 | handoff | [farm-agent-spatial-reasoning-handoff-v1.md](2026-07/07/farm-agent-spatial-reasoning-handoff-v1.md) | farm-agent-spatial-reasoning — 11 轮原子事务交接手册 |
| 07 | plan | [farm-agent-spatial-reasoning-plan-v1.md](2026-07/07/farm-agent-spatial-reasoning-plan-v1.md) | farm-agent-spatial-reasoning-plan-v1 |
| 07 | plan | [farm-agent-spatial-reasoning-plan-v2.md](2026-07/07/farm-agent-spatial-reasoning-plan-v2.md) | farm-agent-spatial-reasoning-plan-v2 |
| 07 | plan | [farm-agent-spatial-reasoning-plan-v3.md](2026-07/07/farm-agent-spatial-reasoning-plan-v3.md) | farm-agent-spatial-reasoning-plan-v3 |
| 07 | plan | [farm-agent-spatial-reasoning-plan-v4.md](2026-07/07/farm-agent-spatial-reasoning-plan-v4.md) | farm-agent 空间推理 Plan v4 — toolResults 保鲜策略增量补充 |
| 08 | add-route | [add-coder-npm-package-add-route-v1.md](2026-07/08/add-coder-npm-package-add-route-v1.md) | add-coder-add-coder-npm-package-add-route-v1 |
| 08 | handoff | [add-coder-npm-package-handoff-v1.md](2026-07/08/add-coder-npm-package-handoff-v1.md) | add-coder npm 包 — 6 轮原子事务交接手册 |
| 08 | plan | [add-coder-npm-package-plan-v1.md](2026-07/08/add-coder-npm-package-plan-v1.md) | add-coder-add-coder-npm-package-plan-v1 |
| 09 | plan | [farm-agent-caijuehub-transcription-plan-v1.md](2026-07/09/farm-agent-caijuehub-transcription-plan-v1.md) | farm-agent-caijuehub-transcription-plan-v1 |
| 13 | handoff | [api-response-format-unification-handoff-v1.md](2026-07/13/api-response-format-unification-handoff-v1.md) | farm-agent — API 响应格式统一 success/error → code/message 交接手册 |
| 13 | plan | [api-response-format-unification-plan-v1.md](2026-07/13/api-response-format-unification-plan-v1.md) | API 响应格式统一：success/error → code/message (v1) |
| 14 | plan | [farm-agent-mcp-cockpit-ros2-bridge-plan-v1.md](2026-07/14/farm-agent-mcp-cockpit-ros2-bridge-plan-v1.md) | farm-agent MCP 驾仓 + OS Kernel 用户空间 + ROS2 桥接 + Rust HAL — Plan v1 |
| 18 | plan | [farm-agent-adduser-migration-plan-v1.md](2026-07/18/farm-agent-adduser-migration-plan-v1.md) | farm-agent-adduser-migration-plan-v1 |
| 21 | handoff | [checkpointer-table-resilience-handoff-v2.md](2026-07/21/checkpointer-table-resilience-handoff-v2.md) | farm-agent — Checkpointer 表完整性防护 v2 交接手册 |
| 21 | plan | [checkpointer-table-resilience-plan-v2.md](2026-07/21/checkpointer-table-resilience-plan-v2.md) | checkpointer-table-resilience-plan-v2 |
| 22 | plan | [farm-agent-prompt-engine-structured-output-plan-v1.md](2026-07/22/farm-agent-prompt-engine-structured-output-plan-v1.md) | Prompt Engine 结构化输出演进 Plan |

## 2026-06

| 日 | 类型 | 文档 | 主题 |
|---|------|------|------|
| 08 | handoff | [farm-agent-tools-pipeline-handoff-v1.md](2026-06/08/farm-agent-tools-pipeline-handoff-v1.md) | farm-agent — 工具调用管线集成 交接手册 |
| 09 | handoff | [farm-agent-hash-route-sse-fix-handoff-v1.md](2026-06/09/farm-agent-hash-route-sse-fix-handoff-v1.md) | farm-agent — hash route SSE 流式修复 交接手册 |
| 09 | handoff | [farm-agent-review-and-evidence-hardening-handoff-v1.md](2026-06/09/farm-agent-review-and-evidence-hardening-handoff-v1.md) | farm-agent — 审查流程加固 + 边界证据站 交接手册 |
| 09 | plan | [farm-agent-hash-route-sse-fix-plan-v1.md](2026-06/09/farm-agent-hash-route-sse-fix-plan-v1.md) | Plan: hash route SSE 流式修复 |
| 09 | plan | [farm-agent-review-and-evidence-hardening-plan-v1.md](2026-06/09/farm-agent-review-and-evidence-hardening-plan-v1.md) | farm-agent-review-and-evidence-hardening-plan-v1 |
| 10 | add-route | [farm-agent-rag-audit-stacktrace-add-route-old-v1.md](2026-06/10/farm-agent-rag-audit-stacktrace-add-route-old-v1.md) | farm-agent-rag-audit-stacktrace-add-route-v1 |
| 10 | add-route | [farm-agent-rag-audit-stacktrace-add-route-old-v2.md](2026-06/10/farm-agent-rag-audit-stacktrace-add-route-old-v2.md) | farm-agent-rag-audit-stacktrace-add-route-v2 |
| 10 | add-route | [farm-agent-rag-audit-stacktrace-add-route-v1.md](2026-06/10/farm-agent-rag-audit-stacktrace-add-route-v1.md) | farm-agent-rag-audit-stacktrace-add-route-v1 |
| 10 | handoff | [farm-agent-rag-audit-stacktrace-handoff-v1.md](2026-06/10/farm-agent-rag-audit-stacktrace-handoff-v1.md) | farm-agent — 能力专家全量注册 + RAG 链路加固 + API 契约治理 交接手册 |
| 10 | plan | [farm-agent-rag-audit-stacktrace-plan-v1.md](2026-06/10/farm-agent-rag-audit-stacktrace-plan-v1.md) | Plan: 能力专家全量注册 + RAG 链路加固 + API 契约治理 |
| 11 | add-route | [farm-agent-Expert-Grounding-RAG适配-add-route-v1.md](2026-06/11/farm-agent-Expert-Grounding-RAG适配-add-route-v1.md) | farm-agent-Expert-Grounding-RAG适配-add-route-v1 |
| 11 | add-route | [farm-agent-podman数据卷拆离统一-datadir-add-route-v1.md](2026-06/11/farm-agent-podman数据卷拆离统一-datadir-add-route-v1.md) | farm-agent-podman数据卷拆离统一-datadir-add-route-v1 |
| 11 | plan | [farm-agent-podman数据卷拆离统一-datadir-plan-v1.md](2026-06/11/farm-agent-podman数据卷拆离统一-datadir-plan-v1.md) | PLAN：farm-agent Podman 数据卷拆离项目，统一 `$HOME/data/farm-agent` |
| 11 | plan | [farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md](2026-06/11/farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md) | farm-agent Expert Grounding RAG 适配 Plan v1 |
| 12 | add-route | [farm-agent-os-kernel-wiring-add-route-v1.md](2026-06/12/farm-agent-os-kernel-wiring-add-route-v1.md) | farm-agent-os-kernel-wiring-add-route-v1 |
| 12 | handoff | [farm-agent-agrisynapse-integration-handoff-v1.md](2026-06/12/farm-agent-agrisynapse-integration-handoff-v1.md) | farm-agent-agrisynapse-integration-handoff |
| 12 | handoff | [farm-agent-expert-grounding-handoff.md](2026-06/12/farm-agent-expert-grounding-handoff.md) | farm-agent — Expert Grounding RAG 适配 交接手册 |
| 12 | handoff | [farm-agent-os-kernel-wiring-handoff-v1.md](2026-06/12/farm-agent-os-kernel-wiring-handoff-v1.md) | farm-agent — Agent OS Kernel 管线接入 交接手册 |
| 12 | plan | [farm-agent-os-kernel-wiring-plan-v1.md](2026-06/12/farm-agent-os-kernel-wiring-plan-v1.md) | Agent OS Kernel 管线接入 — Plan v1 |
| 15 | add-route | [farm-agent-expert-deep-pipeline-runtime-fix-add-route-v1.md](2026-06/15/farm-agent-expert-deep-pipeline-runtime-fix-add-route-v1.md) | <!-- plan-ref: farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md --> |
| 15 | add-route | [farm-agent-gui-chat-enhancement-add-route-v1.md](2026-06/15/farm-agent-gui-chat-enhancement-add-route-v1.md) | farm-agent-gui-chat-enhancement-add-route-v1 |
| 15 | add-route | [farm-agent-pagination-dry-add-route-v1.md](2026-06/15/farm-agent-pagination-dry-add-route-v1.md) | farm-agent-pagination-dry-add-route-v1 |
| 15 | add-route | [farm-agent-reasoning-structured-dataflow-add-route-v1.md](2026-06/15/farm-agent-reasoning-structured-dataflow-add-route-v1.md) | farm-agent-reasoning-structured-dataflow-add-route-v1 |
| 15 | handoff | [farm-agent-expert-deep-pipeline-runtime-fix-handoff-v1.md](2026-06/15/farm-agent-expert-deep-pipeline-runtime-fix-handoff-v1.md) | farm-agent Expert Deep Pipeline 运行时修复 — 交接手册 |
| 15 | handoff | [farm-agent-pagination-dry-handoff-v1.md](2026-06/15/farm-agent-pagination-dry-handoff-v1.md) | farm-agent — 分页参数 DRY 抽取 + 时间参数补全 交接手册 |
| 15 | handoff | [farm-agent-reasoning-structured-dataflow-handoff-v1.md](2026-06/15/farm-agent-reasoning-structured-dataflow-handoff-v1.md) | farm-agent-reasoning-structured-dataflow-handoff-v1 |
| 15 | plan | [farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md](2026-06/15/farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md) | farm-agent-expert-deep-pipeline-runtime-fix-plan-v1 |
| 15 | plan | [farm-agent-gui-chat-enhancement-plan-v1.md](2026-06/15/farm-agent-gui-chat-enhancement-plan-v1.md) | farm-agent-gui-chat-enhancement-plan-v1 |
| 15 | plan | [farm-agent-pagination-dry-plan-v1.md](2026-06/15/farm-agent-pagination-dry-plan-v1.md) | farm-agent-pagination-dry-plan-v1 |
| 15 | plan | [farm-agent-per-expert-report-template-plan-v1.md](2026-06/15/farm-agent-per-expert-report-template-plan-v1.md) | Plan: per-expert 报告模板体系 |
| 15 | plan | [farm-agent-reasoning-structured-dataflow-plan-v1.md](2026-06/15/farm-agent-reasoning-structured-dataflow-plan-v1.md) | farm-agent-reasoning-structured-dataflow-plan-v1 |
| 15 | plan | [farm-agent-response-tool-summary-plan-v1.md](2026-06/15/farm-agent-response-tool-summary-plan-v1.md) | Plan: response 节点工具执行摘要人话化注入 |
| 16 | add-route | [farm-agent-grounding-customization-add-route-v1.md](2026-06/16/farm-agent-grounding-customization-add-route-v1.md) | farm-agent-grounding-customization-add-route-v1 |
| 16 | add-route | [farm-agent-seed-catalog-add-route-v1.md](2026-06/16/farm-agent-seed-catalog-add-route-v1.md) | farm-agent-seed-catalog-add-route-v1 |
| 16 | handoff | [farm-agent-grounding-customization-handoff-v1.md](2026-06/16/farm-agent-grounding-customization-handoff-v1.md) | farm-agent — 5 轮原子事务交接手册 |
| 16 | plan | [farm-agent-grounding-customization-plan-v1.md](2026-06/16/farm-agent-grounding-customization-plan-v1.md) | farm-agent-grounding-customization-plan-v1 |
| 16 | plan | [farm-agent-grounding-customization-plan-v2.md](2026-06/16/farm-agent-grounding-customization-plan-v2.md) | farm-agent-grounding-customization-plan-v2 |
| 16 | plan | [farm-agent-grounding-customization-plan-v3.md](2026-06/16/farm-agent-grounding-customization-plan-v3.md) | PLAN: farm-agent Grounding 知识分类体系 — 多阶段实施 |
| 16 | plan | [farm-agent-seed-catalog-plan-v1.md](2026-06/16/farm-agent-seed-catalog-plan-v1.md) | farm-agent-seed-catalog-plan-v1 |
| 16 | plan | [farm-agent-seed-crawler-plan-v1.md](2026-06/16/farm-agent-seed-crawler-plan-v1.md) | farm-agent-seed-crawler-plan-v1 |
| 17 | add-route | [farm-agent-deep-kb-dualpath-retrieval-add-route-v1.md](2026-06/17/farm-agent-deep-kb-dualpath-retrieval-add-route-v1.md) | farm-agent-deep-kb-dualpath-retrieval-add-route-v1 |
| 17 | add-route | [farm-agent-intermediate-streaming-ui-fix-add-route-v1.md](2026-06/17/farm-agent-intermediate-streaming-ui-fix-add-route-v1.md) | farm-agent-中间态流式UI修复-add-route-v1 |
| 17 | handoff | [farm-agent-deep-kb-dualpath-retrieval-handoff-v1.md](2026-06/17/farm-agent-deep-kb-dualpath-retrieval-handoff-v1.md) | farm-agent — 2 轮原子事务交接手册 |
| 17 | handoff | [farm-agent-intermediate-streaming-ui-fix-handoff-v1.md](2026-06/17/farm-agent-intermediate-streaming-ui-fix-handoff-v1.md) | farm-agent — 流式中间态 UI 修复 交接手册 |
| 17 | plan | [farm-agent-intermediate-streaming-ui-fix-plan-v1.md](2026-06/17/farm-agent-intermediate-streaming-ui-fix-plan-v1.md) | farm-agent-tool-call-sse-events-v1 |
| 17 | plan | [farm-agent-three-tier-reasoning-graph-plan-v1.md](2026-06/17/farm-agent-three-tier-reasoning-graph-plan-v1.md) | farm-agent-aca-framework-plan-v1 |
| 18 | add-route | [farm-agent-climate-zone-lookup-add-route-v1.md](2026-06/18/farm-agent-climate-zone-lookup-add-route-v1.md) | farm-agent-climate-zone-lookup-add-route-v1 |
| 18 | add-route | [farm-agent-ruifengyun-h5-api-add-route-v1.md](2026-06/18/farm-agent-ruifengyun-h5-api-add-route-v1.md) | farm-agent-ruifengyun-h5-api-add-route-v1 |
| 18 | handoff | [farm-agent-ruifengyun-h5-api-handoff-v1.md](2026-06/18/farm-agent-ruifengyun-h5-api-handoff-v1.md) | farm-agent — 瑞丰耘H5对接 交接手册 |
| 18 | plan | [farm-agent-agrisynapse-integration-plan-v1.md](2026-06/18/farm-agent-agrisynapse-integration-plan-v1.md) | agrisynapse ↔ farm-agent 前端对接 Plan v1 |
| 18 | plan | [farm-agent-climate-zone-lookup-plan-v1.md](2026-06/18/farm-agent-climate-zone-lookup-plan-v1.md) | farm-agent-climate-zone-lookup-plan-v1 |
| 18 | plan | [farm-agent-ruifengyun-h5-api-plan-v1.md](2026-06/18/farm-agent-ruifengyun-h5-api-plan-v1.md) | farm-agent-ruifengyun-h5-api-plan-v1 |
| 22 | add-route | [farm-agent-nongqing-report-add-route-v1.md](2026-06/22/farm-agent-nongqing-report-add-route-v1.md) | farm-agent-nongqing-report-add-route-v1 |
| 22 | add-route | [farm-agent-ruifengyun-h5-api-add-route-v2.md](2026-06/22/farm-agent-ruifengyun-h5-api-add-route-v2.md) | farm-agent-ruifengyun-h5-api-add-route-v2 |
| 22 | handoff | [farm-agent-nongqing-report-api-handoff-v1.md](2026-06/22/farm-agent-nongqing-report-api-handoff-v1.md) | farm-agent — 农情报告 API（总体态势概览 + 日常巡检报告 + 任务/处方 + generate 地块绑定）交接手册 |
| 22 | handoff | [farm-agent-ruifengyun-h5-api-handoff-v2.md](2026-06/22/farm-agent-ruifengyun-h5-api-handoff-v2.md) | farm-agent — 瑞丰耘H5 API v2（服务账户认证 + 生产计划路径重构 + 农情报告 + 完成/取消 + 地块释放）交接手册 |
| 22 | plan | [farm-agent-crop-plan-model-plan-v1.md](2026-06/22/farm-agent-crop-plan-model-plan-v1.md) | farm-agent-crop-plan-model-plan-v1 |
| 22 | plan | [farm-agent-nongqing-report-api-plan-v1.md](2026-06/22/farm-agent-nongqing-report-api-plan-v1.md) | farm-agent-nongqing-report-api-plan-v1 |
| 23 | add-route | [farm-agent-interaction-resume-add-route-v1.md](2026-06/23/farm-agent-interaction-resume-add-route-v1.md) | farm-agent-interaction-resume-add-route-v1 |
| 23 | add-route | [farm-agent-isSummary-toolcall-fix-add-route-v1.md](2026-06/23/farm-agent-isSummary-toolcall-fix-add-route-v1.md) | farm-agent-isSummary-toolcall-fix-add-route-v1 |
| 23 | add-route | [farm-agent-toolresults-contract-add-route-v1.md](2026-06/23/farm-agent-toolresults-contract-add-route-v1.md) | farm-agent-toolresults-contract-add-route-v1 |
| 23 | add-route | [farm-agent-unpdf-migration-add-route-v1.md](2026-06/23/farm-agent-unpdf-migration-add-route-v1.md) | farm-agent-unpdf-migration-add-route-v1 |
| 23 | handoff | [farm-agent-db-backup-infra-handoff-v1.md](2026-06/23/farm-agent-db-backup-infra-handoff-v1.md) | farm-agent — 数据库备份与开发安全加固 交接手册 |
| 23 | handoff | [farm-agent-interaction-resume-fix-handoff-v1.md](2026-06/23/farm-agent-interaction-resume-fix-handoff-v1.md) | farm-agent — 交互点 Resume 标准化修复 交接手册 |
| 23 | handoff | [farm-agent-tools-pipeline-handoff-v2.md](2026-06/23/farm-agent-tools-pipeline-handoff-v2.md) | farm-agent — 工具调用管线 交接手册 |
| 23 | handoff | [farm-agent-unpdf-migration-handoff-v1.md](2026-06/23/farm-agent-unpdf-migration-handoff-v1.md) | farm-agent — unpdf 迁移 PDF 解析 交接手册 |
| 23 | plan | [farm-agent-deep-kb-dualpath-retrieval-plan-v1.md](2026-06/23/farm-agent-deep-kb-dualpath-retrieval-plan-v1.md) | farm-agent-deep-kb-dualpath-retrieval-plan-v1 |
| 23 | plan | [farm-agent-interaction-resume-fix-plan-v1.md](2026-06/23/farm-agent-interaction-resume-fix-plan-v1.md) | farm-agent-interaction-resume-fix-plan-v1 |
| 23 | plan | [farm-agent-isSummary-toolcall-fix-plan-v1.md](2026-06/23/farm-agent-isSummary-toolcall-fix-plan-v1.md) | farm-agent-isSummary-toolcall-fix-plan-v1 |
| 23 | plan | [farm-agent-ruifengyun-h5-api-plan-v2.md](2026-06/23/farm-agent-ruifengyun-h5-api-plan-v2.md) | farm-agent-ruifengyun-h5-api-plan-v2 |
| 23 | plan | [farm-agent-tools-pipeline-plan-v1.md](2026-06/23/farm-agent-tools-pipeline-plan-v1.md) | farm-agent-tools-pipeline-plan-v1 |
| 23 | plan | [farm-agent-unpdf-migration-plan-v1.md](2026-06/23/farm-agent-unpdf-migration-plan-v1.md) | farm-agent-unpdf-migration-plan-v1 |
| 23 | plan | [personnel-management-plan-v1.md](2026-06/23/personnel-management-plan-v1.md) | 人员管理与智能派发体系 v1 |
| 23 | plan | [reasoning-chain-unification-plan-v1.md](2026-06/23/reasoning-chain-unification-plan-v1.md) | 推理链统一与强化实施计划 |
| 23 | plan | [workspace-pmo-plan-v1.md](2026-06/23/workspace-pmo-plan-v1.md) | Workspace PMO 工具集 v1 |
| 24 | add-route | [farm-agent-chat-thread-soft-delete-add-route-v1.md](2026-06/24/farm-agent-chat-thread-soft-delete-add-route-v1.md) | farm-agent-chat-thread-soft-delete-add-route-v1 |
| 24 | add-route | [farm-agent-land-analysis-dict-cache-add-route-v1.md](2026-06/24/farm-agent-land-analysis-dict-cache-add-route-v1.md) | farm-agent-land-analysis-dict-cache-add-route-v1 |
| 24 | add-route | [farm-agent-structured-data-agrisynapse-rehydration-fix-add-route-v1.md](2026-06/24/farm-agent-structured-data-agrisynapse-rehydration-fix-add-route-v1.md) | farm-agent-structured-data-agrisynapse-rehydration-fix-add-route-v1 |
| 24 | handoff | [farm-agent-land-analysis-dict-cache-handoff-v1.md](2026-06/24/farm-agent-land-analysis-dict-cache-handoff-v1.md) | farm-agent — Land Analysis DictCache 字典缓存层 交接手册 |
| 24 | plan | [farm-agent-chat-thread-soft-delete-plan-v1.md](2026-06/24/farm-agent-chat-thread-soft-delete-plan-v1.md) | farm-agent-chat-thread-soft-delete-plan-v1 |
| 24 | plan | [farm-agent-land-analysis-dict-cache-plan-v1.md](2026-06/24/farm-agent-land-analysis-dict-cache-plan-v1.md) | farm-agent-land-analysis-dict-cache-plan-v1 |
| 24 | plan | [farm-agent-structured-data-agrisynapse-rehydration-fix-plan-v1.md](2026-06/24/farm-agent-structured-data-agrisynapse-rehydration-fix-plan-v1.md) | farm-agent-structured-data-agrisynapse-rehydration-fix-plan-v1 |
| 25 | add-route | [add-qoder-integration-add-route-v1.md](2026-06/25/add-qoder-integration-add-route-v1.md) | add-qoder-integration-add-route-v1 |
| 25 | add-route | [audit-log-bypass-governance-add-route-v1.md](2026-06/25/audit-log-bypass-governance-add-route-v1.md) | audit-log-bypass-governance-add-route-v1 |
| 25 | add-route | [farm-agent-domain-vocabulary-add-route-v1.md](2026-06/25/farm-agent-domain-vocabulary-add-route-v1.md) | farm-agent-domain-vocabulary-add-route-v1 |
| 25 | add-route | [farm-agent-ruifengyun-h5-api-v2-add-route-v3.md](2026-06/25/farm-agent-ruifengyun-h5-api-v2-add-route-v3.md) | farm-agent-ruifengyun-h5-api-v2-add-route-v3 |
| 25 | handoff | [add-qoder-integration-handoff-v1.md](2026-06/25/add-qoder-integration-handoff-v1.md) | farm-agent — 3 轮原子事务交接手册 |
| 25 | handoff | [audit-log-bypass-governance-handoff-v1.md](2026-06/25/audit-log-bypass-governance-handoff-v1.md) | farm-agent — AuditLog 绕过治理 交接手册 |
| 25 | handoff | [farm-agent-devlog-table-split-handoff-v1.md](2026-06/25/farm-agent-devlog-table-split-handoff-v1.md) | farm-agent — devlog 表拆分 交接手册 |
| 25 | handoff | [farm-agent-domain-vocabulary-handoff-v1.md](2026-06/25/farm-agent-domain-vocabulary-handoff-v1.md) | farm-agent — 领域词汇注入与工具上下文类型化 交接手册 |
| 25 | handoff | [farm-agent-h5-production-runtime-fixes-handoff-v1.md](2026-06/25/farm-agent-h5-production-runtime-fixes-handoff-v1.md) | farm-agent — 2 轮 Runtime Review 修复交接手册 |
| 25 | handoff | [farm-agent-three-tier-reasoning-graph-handoff-v2.md](2026-06/25/farm-agent-three-tier-reasoning-graph-handoff-v2.md) | farm-agent — ACA 三层推理图 Handoff v2 |
| 25 | plan | [add-qoder-integration-plan-v1.md](2026-06/25/add-qoder-integration-plan-v1.md) | add-qoder-integration-plan-v1 |
| 25 | plan | [add16-audit-log-governance-plan-v1.md](2026-06/25/add16-audit-log-governance-plan-v1.md) | ADD-16 裁决层契约强制门禁 — plan-v1 |
| 25 | plan | [audit-log-bypass-governance-plan-v1.md](2026-06/25/audit-log-bypass-governance-plan-v1.md) | AuditLog 绕过治理 — 禁止 prisma.auditLog.create 直调 — plan-v1 |
| 25 | plan | [farm-agent-api-change-auto-adapt-plan-v1.md](2026-06/25/farm-agent-api-change-auto-adapt-plan-v1.md) | farm-agent-api-change-auto-adapt-plan-v1 |
| 25 | plan | [farm-agent-devlog-table-split-plan-v1.md](2026-06/25/farm-agent-devlog-table-split-plan-v1.md) | farm-agent-devlog-table-split-plan-v1 |
| 25 | plan | [farm-agent-domain-vocabulary-plan-v1.md](2026-06/25/farm-agent-domain-vocabulary-plan-v1.md) | farm-agent-domain-vocabulary-plan-v1 |
| 25 | plan | [farm-agent-massif-api-sync-plan-v1.md](2026-06/25/farm-agent-massif-api-sync-plan-v1.md) | Farm-Server 地块 API 字段 & 字典类型同步 — plan-v1 |
| 25 | plan | [farm-agent-three-tier-reasoning-graph-plan-v2.md](2026-06/25/farm-agent-three-tier-reasoning-graph-plan-v2.md) | farm-agent-aca-framework-plan-v2 |
| 25 | plan | [farm-agent-wecom-doc-notify-plan-v1.md](2026-06/25/farm-agent-wecom-doc-notify-plan-v1.md) | farm-agent-wecom-doc-notify-plan-v1 |
| 26 | add-route | [checkpointer-postgres-migration-add-route-v1.md](2026-06/26/checkpointer-postgres-migration-add-route-v1.md) | checkpointer-postgres-migration-add-route-v1 |
| 26 | add-route | [farm-agent-agrisynapse-api-doc-notify-add-route-v1.md](2026-06/26/farm-agent-agrisynapse-api-doc-notify-add-route-v1.md) | farm-agent-agrisynapse-api-doc-notify-add-route-v1 |
| 26 | add-route | [h5-agent-route-code-quality-add-route-v1.md](2026-06/26/h5-agent-route-code-quality-add-route-v1.md) | h5-agent-route-code-quality-add-route-v1 |
| 26 | handoff | [checkpointer-postgres-migration-handoff.md](2026-06/26/checkpointer-postgres-migration-handoff.md) | farm-agent — Checkpointer PostgreSQL 持久化迁移 交接手册 |
| 26 | handoff | [farm-agent-agrisynapse-api-doc-notify-handoff-v1.md](2026-06/26/farm-agent-agrisynapse-api-doc-notify-handoff-v1.md) | farm-agent-agrisynapse-api-doc-notify-handoff-v1 |
| 26 | handoff | [h5-agent-route-code-quality-handoff-v1.md](2026-06/26/h5-agent-route-code-quality-handoff-v1.md) | h5-agent-route-code-quality — 1 轮 代码质量整改 交接手册 |
| 26 | plan | [checkpointer-postgres-migration-plan.md](2026-06/26/checkpointer-postgres-migration-plan.md) | checkpointer-postgres-migration-plan |
| 26 | plan | [farm-agent-agent-os-state-persistence-plan-v2.md](2026-06/26/farm-agent-agent-os-state-persistence-plan-v2.md) | farm-agent-agent-os-state-persistence-plan-v2 |
| 26 | plan | [farm-agent-agrisynapse-api-doc-notify-plan-v1.md](2026-06/26/farm-agent-agrisynapse-api-doc-notify-plan-v1.md) | farm-agent-agrisynapse-api-doc-notify-plan-v1 |
| 26 | plan | [farm-agent-domain-vocabulary-param-missing-gui-runtime-fix-plan-v1.md](2026-06/26/farm-agent-domain-vocabulary-param-missing-gui-runtime-fix-plan-v1.md) | farm-agent-domain-vocabulary-param-missing-gui-runtime-fix-plan-v1 |
| 26 | plan | [h5-agent-route-code-quality-plan-v1.md](2026-06/26/h5-agent-route-code-quality-plan-v1.md) | h5-agent-route-code-quality-plan-v1 |
| 29 | add-route | [farm-agent-three-tier-reasoning-graph-add-route-v3.md](2026-06/29/farm-agent-three-tier-reasoning-graph-add-route-v3.md) | farm-agent-three-tier-reasoning-graph-add-route-v3 |
| 29 | handoff | [code-review-fixes-handoff-v1.md](2026-06/29/code-review-fixes-handoff-v1.md) | farm-agent-code-review-fixes-handoff-v1 |
| 29 | handoff | [farm-agent-three-tier-reasoning-graph-handoff-v3.md](2026-06/29/farm-agent-three-tier-reasoning-graph-handoff-v3.md) | farm-agent — 4 轮局部闭包交接手册 v3 |
| 29 | plan | [code-review-fixes-plan-v1.md](2026-06/29/code-review-fixes-plan-v1.md) | farm-agent-code-review-fixes-plan-v1 |
| 29 | plan | [farm-agent-three-tier-reasoning-graph-plan-v3.md](2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md) | farm-agent-aca-framework-plan-v3 |
| 30 | add-route | [code-review-18-phase-subtypes-add-route-v1.md](2026-06/30/code-review-18-phase-subtypes-add-route-v1.md) | code-review-18-phase-subtypes-add-route-v1 |
| 30 | add-route | [farm-agent-api-zod-hardening-add-route-v1.md](2026-06/30/farm-agent-api-zod-hardening-add-route-v1.md) | farm-agent-api-zod-hardening-add-route-v1 |
| 30 | add-route | [farm-agent-log-folder-restructure-add-route-v1.md](2026-06/30/farm-agent-log-folder-restructure-add-route-v1.md) | farm-agent-log-folder-restructure-add-route-v1 |
| 30 | handoff | [code-review-18-phase-subtypes-handoff-v1.md](2026-06/30/code-review-18-phase-subtypes-handoff-v1.md) | code-review-18-phase-subtypes-handoff-v1 |
| 30 | handoff | [farm-agent-api-zod-hardening-handoff-v1.md](2026-06/30/farm-agent-api-zod-hardening-handoff-v1.md) | farm-agent — 5 轮原子事务交接手册 |
| 30 | plan | [code-review-18-phase-subtypes-devlog-v1.md](2026-06/30/code-review-18-phase-subtypes-devlog-v1.md) | code-review-18-phase-subtypes-devlog-v1 |
| 30 | plan | [code-review-llm-state-isolation-plan-v1.md](2026-06/30/code-review-llm-state-isolation-plan-v1.md) | Plan: LLM 全局可变状态隔离 |
| 30 | plan | [code-review-log-llm-refactor-plan-v1.md](2026-06/30/code-review-log-llm-refactor-plan-v1.md) | Plan: 日志模块重复代码消除 + 审计通道统一 + agents/index.ts 拆分 |
| 30 | plan | [code-review-log-llm-refactor-plan-v2.md](2026-06/30/code-review-log-llm-refactor-plan-v2.md) | Plan: 日志模块重复代码消除 + 审计通道统一 + agents/index.ts 拆分 |
| 30 | plan | [farm-agent-add-hook-governance-plan-v3.md](2026-06/30/farm-agent-add-hook-governance-plan-v3.md) | farm-agent-add-hook-governance-plan-v3 |
| 30 | plan | [farm-agent-add-hook-intelligence-plan-v1.md](2026-06/30/farm-agent-add-hook-intelligence-plan-v1.md) | farm-agent-add-hook-intelligence-plan-v1 |
| 30 | plan | [farm-agent-api-zod-hardening-plan-v1.md](2026-06/30/farm-agent-api-zod-hardening-plan-v1.md) | farm-agent-api-zod-hardening-plan-v1 |
| 30 | plan | [farm-agent-notify-control-center-plan-v1.md](2026-06/30/farm-agent-notify-control-center-plan-v1.md) | farm-agent-notify-control-center-plan-v1 |

## 2026-05

| 日 | 类型 | 文档 | 主题 |
|---|------|------|------|
| 14 | execution | [co-agent-simplified-execution-v1.md](2026-05/14/co-agent-simplified-execution-v1.md) | 执行计划：farm-agent（7+1 轮原子事务拓扑） |
| 14 | handoff | [co-agent-conversation-handoff-v1.md](2026-05/14/co-agent-conversation-handoff-v1.md) | farm-agent — 7 轮原子事务交接手册 |
| 14 | plan | [co-agent-simplified-plan-v1.md](2026-05/14/co-agent-simplified-plan-v1.md) | PLAN: farm-agent 改进 — 类型收敛 + thinkingLevel + ResponseStrategy + 分析专家模式 + 语义缓存 |
| 14 | plan | [team-coordinator-agent-implementation-plan-v1.md](2026-05/14/team-coordinator-agent-implementation-plan-v1.md) | 团队协同智能体 |
| 14 | plan | [team-coordinator-agent-plan-v1.md](2026-05/14/team-coordinator-agent-plan-v1.md) | 团队协同智能体 |
| 18 | add-route | [streaming-event-bus-add-route-v1.md](2026-05/18/streaming-event-bus-add-route-v1.md) | streaming-event-bus-add-route-v1 |
| 18 | handoff | [streaming-event-bus-handoff-v1.md](2026-05/18/streaming-event-bus-handoff-v1.md) | streaming-event-bus — 1 轮 Runtime 纠正 交接手册 |
| 18 | plan | [architecture-doc-button-hook-fix-plan-v1.md](2026-05/18/architecture-doc-button-hook-fix-plan-v1.md) | 计划：架构文档修正、按钮激活态与模型钩子集成 |
| 18 | plan | [button-hierarchy-fix-plan-v1.md](2026-05/18/button-hierarchy-fix-plan-v1.md) | 计划：按钮层级体系梳理、结构化管线与可审计链路 |
| 18 | plan | [chain-tracer-rag-fix-plan-v1.md](2026-05/18/chain-tracer-rag-fix-plan-v1.md) | 计划：ChainTracer 完整接入与 RAG 检索修复 |
| 18 | plan | [fix-chat-structured-data-plan-v1.md](2026-05/18/fix-chat-structured-data-plan-v1.md) | 修复聊天结构化数据丢失 Bug — 可审计修复方案 |
| 18 | plan | [fix-loading-deadlock-plan-v1.md](2026-05/18/fix-loading-deadlock-plan-v1.md) | 修复页面刷新后"加载中..."卡死问题 |
| 18 | plan | [fix-streaming-structured-data-plan-v1.md](2026-05/18/fix-streaming-structured-data-plan-v1.md) | 流式输出结构化数据 DOM 样式丢失 + 文本重复修复计划 |
| 18 | plan | [streaming-event-bus-plan-v1.md](2026-05/18/streaming-event-bus-plan-v1.md) | 流式输出事件总线改造 — 可审计实施计划 |
| 22 | execution | [farm-agent-podman数据卷拆离统一-datadir-execution-v1.md](2026-05/22/farm-agent-podman数据卷拆离统一-datadir-execution-v1.md) | EXECUTION：farm-agent Podman 数据卷拆离 — 原子任务拆分 |
| 22 | handoff | [farm-agent-layer2-cross-cutting-handoff.md](2026-05/22/farm-agent-layer2-cross-cutting-handoff.md) | farm-agent-layer2-cross-cutting-handoff |
| 22 | handoff | [farm-agent-podman数据卷拆离统一-datadir-handoff-v1.md](2026-05/22/farm-agent-podman数据卷拆离统一-datadir-handoff-v1.md) | HANDOFF：farm-agent Podman 数据卷拆离 — 轮间交接手册 |
| 22 | plan | [agent-tools-plan-v1.md](2026-05/22/agent-tools-plan-v1.md) | Agent Tools 实现计划 |
| 22 | plan | [agri-rag-data-import-v1.md](2026-05/22/agri-rag-data-import-v1.md) | PLAN: 农业 RAG 数据增量导入 |
| 22 | plan | [farm-agent-kb-export-unify-client-plan-v1.md](2026-05/22/farm-agent-kb-export-unify-client-plan-v1.md) | ChromaDB 导入导出客户端统一计划（farm-agent 移植） |
| 22 | plan | [farm-agent-layer2-cross-cutting-plan-v1.md](2026-05/22/farm-agent-layer2-cross-cutting-plan-v1.md) | farm-agent-layer2-cross-cutting-plan-v1 |
| 22 | plan | [farm-agent-rag-sync-fix-plan-v1.md](2026-05/22/farm-agent-rag-sync-fix-plan-v1.md) | RAG 同步修复计划（farm-agent 移植） |
| 22 | plan | [mcp-server-plan-v1.md](2026-05/22/mcp-server-plan-v1.md) | MCP Server 实施规划 |
| 22 | plan | [mcp-test-plan-v1.md](2026-05/22/mcp-test-plan-v1.md) | MCP 服务器测试规划（v2 — 以真实 Bug 为试金石） |
| 26 | plan | [chat-audit-plan-v1.md](2026-05/26/chat-audit-plan-v1.md) | Chat 接口可审计化计划 |
| 26 | plan | [chat-panel-enhancement-plan-v1.md](2026-05/26/chat-panel-enhancement-plan-v1.md) | 模型配置架构文档 |
| 26 | plan | [chat-thread-tab-plan-v1.md](2026-05/26/chat-thread-tab-plan-v1.md) | 聊天列表管理 Tab 计划 |
| 26 | plan | [doc-system-sync-plan-v1.md](2026-05/26/doc-system-sync-plan-v1.md) | 计划：参照 codein2027 规范重组 farm-agent / co-agent 文档体系 |
| 26 | plan | [document-list-pagination-plan-v1.md](2026-05/26/document-list-pagination-plan-v1.md) | PLAN-document-list-pagination-v1：文档列表优化 — ADD 实施计划 |
| 26 | plan | [kb-audit-log-plan-v1.md](2026-05/26/kb-audit-log-plan-v1.md) | 知识库向量化审计日志 + 卡死文档修复方案 |
| 26 | plan | [knowledge-base-fix-plan-v1.md](2026-05/26/knowledge-base-fix-plan-v1.md) | 知识库系统逻辑分析与修复方案 |
| 26 | plan | [knowledge-doc-tag-system-plan-v1.md](2026-05/26/knowledge-doc-tag-system-plan-v1.md) | 知识库文档标签系统 — ADD 范式实施计划 |
| 28 | execution | [farm-agent-多轮对话能力专家链路优化统一状态管理-7轮原子事务拆分-execution-v1.md](2026-05/28/farm-agent-多轮对话能力专家链路优化统一状态管理-7轮原子事务拆分-execution-v1.md) | 执行计划：farm-agent（7+1 轮原子事务拓扑） |
| 28 | handoff | [farm-agent-多轮对话能力专家链路优化统一状态管理-7轮原子事务交接-handoff-v1.md](2026-05/28/farm-agent-多轮对话能力专家链路优化统一状态管理-7轮原子事务交接-handoff-v1.md) | farm-agent — 7 轮原子事务交接手册 |
| 28 | plan | [farm-agent-多轮对话能力专家链路优化统一状态管理-Prompt模板目录重构-plan-v1.md](2026-05/28/farm-agent-多轮对话能力专家链路优化统一状态管理-Prompt模板目录重构-plan-v1.md) | farm-agent Prompt 模板集中管理 Plan v1 |
| 28 | plan | [farm-agent-多轮对话能力专家链路优化统一状态管理-plan-v1.md](2026-05/28/farm-agent-多轮对话能力专家链路优化统一状态管理-plan-v1.md) | PLAN: farm-agent 改进 — 类型收敛 + thinkingLevel + ResponseStrategy + 分析专家模式 + 语义缓存 |

---
*索引由 `scripts/gen-plan-index.sh` 自动生成，勿手动编辑*
