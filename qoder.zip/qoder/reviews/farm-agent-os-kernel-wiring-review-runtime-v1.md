# Agent OS Kernel 管线接入 — 运行时审查 v1

> 关联 Plan: `.qoder/plans/farm-agent-os-kernel-wiring-plan-v1.md`
> 关联 Runtime Review (上游): `.qoder/reviews/farm-agent-expert-grounding-rag-adaptation-review-runtime-v2.md`（7 断裂点来源）
> 审查时间: 2026-06-12

## 一、运行时验证清单

### R1: ToolNode 包装器事件时序
- [R] ToolNode 执行后 emit `action:proposed` 事件含 toolName 和 success 字段
- [R] `globalStateProvider.getSnapshot().execution.toolCallsCount` 在 ToolNode 出口递增
- [R] `execution.lastToolName` / `lastToolStatus` 反映最近一次工具调用

### R2: GlobalState 域更新原子性
- [R] `updateDomain("execution", ...)` 调用后 `meta.version` 递增
- [R] `getSnapshot()` 返回的是只读快照，不可反向写入 AgentState

### R3: retrieval 出口 OS 信号
- [R] retrieval 完成后 emit `evidence:retrieved` 事件含 `count`（本轮新证据数）
- [R] `globalStateProvider.getSnapshot().agent.evidenceCount` 更新为当前轮 evidenceChain 长度
- [R] 检索零命中时 `fallbackFlags.ragEmpty = true` 写入 state

### R4: reasoning 降级路径
- [R] `fallbackFlags.ragEmpty === true` 时，LLM prompt 含 `[系统提示] 本轮RAG检索返回 0 条结果`
- [R] ToolMessages 被提取并注入 reasoning prompt 的工具结果区块
- [R] fallbackFlags 未设置时（正常路径），不影响原始 reasoning 逻辑

### R5: EVENT_CONSUMER_REGISTRY 就绪判定
- [R] `resolveEventConsumerReadiness("retrieval-context-consumer", snapshot)` 在 execution 域就绪后返回 `{ ready: true }`
- [R] `resolveEventConsumerReadiness("reasoning-context-consumer", snapshot)` 在 execution+agent 域就绪后返回 `{ ready: true }`
- [R] 域未初始化时返回 `{ ready: false, reason: "域 \"xxx\" 未初始化" }`

### R6: PolicyUpdateLoop 工具感知
- [R] `evaluate(ttlStats, turnHistory, pathMetrics, toolExecutionStats)` 可接收 execution 域快照
- [R] `toolExecutionStats.toolCallsCount > 0` 时计算 `toolCallSuccessRate`

### R7: 多租户事件隔离
- [R] `eventBus.setThreadId("thread-A")` 后 emit 的事件标记 `__threadId === "thread-A"`
- [R] `eventBus.getHistory({ threadId: "thread-A" })` 过滤后仅返回 thread-A 事件
- [R] 不同 threadId 的 CognitiveEventBus 实例事件相互隔离

### R8: evidenceChain 轮次隔离
- [R] Turn1 retrieval 返回 `evidenceChain: [e1, e2]`，Turn2 retrieval 返回 `evidenceChain: []`
- [R] Turn2 reasoning 不读取到 Turn1 的 e1/e2 证据

---

## 二、编译状态

`npx tsc --noEmit` — **零错误** ✅

---

## 三、已知限制

- 运行时验证需在完整 Agent 管线中执行（需启动 dev server + 发送请求），不在本 Plan 的编译验证范围内
- [R] 清单中的项目可通过单元测试或集成测试覆盖（后续 Plan）
- PolicyUpdateLoop 的 `toolCallSuccessRate` 目前仅计算最近一次工具的成功率（单值），多工具场景的聚合统计留待后续迭代
