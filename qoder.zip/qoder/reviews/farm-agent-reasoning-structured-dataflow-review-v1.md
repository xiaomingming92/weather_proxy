# farm-agent-reasoning-structured-dataflow-review-v1

## Review 元信息

- **Review 对象**:
  - `.qoder/plans/farm-agent-reasoning-structured-dataflow-plan-v1.md`
  - `.qoder/specs/farm-agent-reasoning-structured-dataflow/spec.md`
  - `.qoder/specs/farm-agent-reasoning-structured-dataflow/tasks.md`
  - `.qoder/specs/farm-agent-reasoning-structured-dataflow/checklist.md`
- **Review 范围**: reasoning 节点结构化数据流改造方向、完整性、风险点
- **Review 时间**: 2026-06-15
- **结论级别**: 需修正后执行

---

## 1. 总体结论

方向正确，架构设计合理。核心思路（单 LLM 调用 + 结构化分区 prompt）是当前最优解。存在 3 个 P1 问题需要在进入 Step 1 前回流至 Plan。

---

## 2. 正向评价

1. **方案选型合理**：方案 B（单 LLM 调用 + 分区 prompt）兼顾 token 效率和改造成本，否决多专家并行调用是正确的
2. **向后兼容设计完善**：`expertPackages` 可选 + `@deprecated` 旧路径保留，零破坏性升级
3. **工具结果归属设计正确**：按 `realtimeToolNames` 归集，语义清晰，无歧义
4. **retrieval 节点职责边界清晰**：只负责构建 `expertPackages`（RAG 证据分组），不做工具结果归集（那是 reasoning 节点的职责）
5. **与现有 caijuehub 裁决预算兼容**：topK 配置不受影响，改动面可控

---

## 3. P0/P1 问题清单

**P1 问题列表：**

- **P1-1**：ExpertPromptOutput 与 ReasoningOutput 关系未明确 → 修正建议：ExpertPromptOutput 仅用于 build 阶段，LLM 输出由 reasoningPrompt.parse() 统一解析 → 回流状态：✅ 已回流至 Plan §3.3
- **P1-2**：toolResults 两阶段填充未说明 → 修正建议：retrieval 初始化空数组，reasoning 填充 toolResults → 回流状态：✅ 已回流至 Plan Task 4+5
- **P1-3**：build() 格式化职责归属未明确 → 修正建议：build() 内聚格式化证据和工具结果 → 回流状态：✅ 已回流至 Plan §3.3

**P2 问题列表：**

- P2-1：AgentAuditPhase 扩展未列出具体新增字面量 → ✅ 已回流至 Plan Task 5
- P2-2：汇总专家 build() 扩展参数未说明 → ✅ 已回流至 Plan Task 2

### P1-1：`ExpertPromptOutput` 与 `ReasoningOutput` 的关系未明确

**严重程度**: P1  
**描述**: Plan §3.3 定义每个专家有独立的 `PromptTemplate<ExpertPromptInput, ExpertPromptOutput>`，但 Plan §3.4 又说"LLM 单次调用，parse/validate 保持不变"——即最终仍用 `reasoningPrompt.parse()` 解析整体输出。两者矛盾：是每个专家各自 parse，还是整体 parse？  
**修正建议**: 在 Plan §3.4 明确说明：专家 `ExpertPromptOutput` 仅用于 `build()` 阶段（构建 prompt 区块），不参与 parse。LLM 输出仍由 `reasoningPrompt.parse()` 统一解析，各专家结论从 `conclusion.content` 中按专家分区提取。或者：在 reasoning prompt 的输出格式要求中，明确要求 LLM 按专家分区输出 JSON，整体 parse 后再按专家 key 拆分。

### P1-2：`expertPackages` 的 `toolResults` 在 retrieval 节点阶段为空，但 Plan §4 未明确说明

**严重程度**: P1  
**描述**: Plan §4 Task 4 说 retrieval 节点构建 `expertPackages`，但 `toolResults` 需要 reasoning 节点从 `state.messages` 归集。即 retrieval 节点构建的 package 中 `toolResults` 初始为空数组，reasoning 节点再填充。这个两阶段填充逻辑在 Plan 中没有显式说明，容易引起实现误解。  
**修正建议**: 在 Plan §4 Task 4 明确：retrieval 节点构建 `expertPackages` 时 `toolResults` 初始化为 `[]`；在 Task 5 明确：reasoning 节点负责填充 `toolResults`。

### P1-3：`prompts/experts/` 的 `build()` 输出是否需要携带证据和工具结果文本，还是由 reasoning 节点自行拼接？

**严重程度**: P1  
**描述**: Plan §3.3 说 `build()` 接收 `evidences + toolResults` 并"输出该专家区块的完整 prompt 文本"。但这意味着每个专家 prompt 文件需要知道如何格式化证据列表和工具结果——这层逻辑是否应该内聚在专家 prompt 文件中，还是由 reasoning 节点统一格式化？  
**修正建议**: 建议 `build()` 负责格式化证据和工具结果（内聚在专家 prompt 文件中），因为不同专家可能需要不同的证据展示方式（如 pest_risk 需要按风险等级排序，roi_analysis 需要数值表格）。这样 reasoning 节点只需拼接各区块，无需关心格式。

### P2-1：`AgentAuditPhase` 扩展未在 Plan 中列出具体新增字面量

**严重程度**: P2  
**描述**: Plan Task 5.7 提到新增 `REASONING_EXPERT_PACKAGE_CONSUME` 阶段，但未说明是否还需要 `REASONING_EXPERT_PACKAGE_BUILD`、`REASONING_TOOL_ATTRIBUTION` 等细分阶段。  
**修正建议**: 在 Plan Task 5.7 明确列出所有新增审计阶段字面量。

### P2-2：`daily-report` 和 `weekly-report` 是汇总专家（`isSummary=true`），其 `build()` 逻辑与核心专家不同，Plan 未展开说明

**严重程度**: P2  
**描述**: 汇总专家需要接收所有核心专家的分析结论作为输入，其 `build()` 参数需要额外字段（如 `coreExpertConclusions`）。Plan 仅说"汇总专家，build 逻辑略有不同"，未展开。  
**修正建议**: 在 Plan Task 2.12/2.13 或 Spec 中明确汇总专家 `ExpertPromptInput` 的扩展字段。

---

## 4. 影响评估

| 问题 | 修正前风险 | 修正后 |
|------|-----------|--------|
| P1-1 | 实现时对 parse 路径产生分歧，可能导致每个专家单独 parse（破坏单次调用约束） | 明确整体 parse，消除歧义 |
| P1-2 | retrieval 节点可能错误地尝试填充 toolResults（此时 state.messages 无 tool 消息） | 两阶段职责清晰 |
| P1-3 | reasoning 节点与专家 prompt 文件之间格式化职责不清，重复或遗漏 | 明确内聚策略 |

---

## 5. 维度覆盖审查

### 5.1 数据模型/类型定义

| 审查项 | 结论 |
|--------|--------|
| `ExpertReasoningPackage` 字段完整性 | ✅ 含 expertId/label/promptRef/evidences/toolResults/runtimeInputs，无冗余 |
| `evidences[]` 内部结构 | ⚠️ 应复用现有 `RetrievalEvidence` 类型，避免重复定义 |
| `toolResults[]` 内部结构 | ⚠️ 应复用现有 tool 消息格式，建议 `{toolName: string, content: string}` |
| `ExpertPromptInput` 与 `ExpertReasoningPackage` 关系 | ✅ Input 是 Package 的子集 + query，无冗余字段 |
| `expertPackages` 在 `AgentState` 中的可选性 | ✅ 用 `?` 保证向后兼容，旧路径可回退 |

### 5.2 API 签名/函数接口

| 审查项 | 结论 |
|--------|--------|
| `loadExpertPrompt(expertId: string)` 签名 | ✅ 接受 expertId，返回 `PromptTemplate<ExpertPromptInput, ExpertPromptOutput>` |
| `build(input: ExpertPromptInput)` 输出 | ✅ 返回该专家区块的完整 prompt 文本（`string`） |
| retrieval 节点返回值变化 | ⚠️ 需在现有返回值中追加 `expertPackages` 字段，不能破坏现有 `evidenceChain` 返回 |
| `reasoning.ts` 主函数签名 | ✅ 接受 `AgentState`，返回 `Partial<AgentState>`，无变化 |

### 5.3 错误路径/降级处理

| 审查项 | 结论 |
|--------|--------|
| `expertPackages` 为 `undefined` 时 | ✅ Plan 明确回退到旧的字符串拼接路径（向后兼容） |
| `loadExpertPrompt()` 找不到对应专家 | ⚠️ 应返回默认 prompt 模板或跳过该专家（不崩溃） |
| 单个专家 `build()` 抛异常 | ⚠️ 应捕获并记录审计，不阻断其他专家区块的构建 |
| `toolResults` 归集时 `realtimeToolNames` 无匹配 | ✅ 空数组，无工具调用时该专家无工具数据，可接受 |

### 5.4 兼容性/向后兼容

✅ 已在正向评价中覆盖。`expertPackages` 可选 + `@deprecated` 旧路径保留。

### 5.5 存储/索引成本

| 审查项 | 结论 |
|--------|--------|
| `expertPackages` 在 `AgentState` 中的内存占用 | ✅ 与现有 `evidenceChain` 数据量相当（同一份证据被引用而非复制） |
| ChromaDB 查询次数 | ✅ 无变化（per-expert 检索已在 retrieval 节点完成） |
| prompt token 增加量 | ⚠️ 结构化区块分隔符增加约 100-200 token，在预算范围内 |
| 无新增 LLM 调用 | ✅ 保持单次调用，不增加 API 成本 |

---

## 6. 建议修正优先级

**高优先级（必须在 Step 1 前回流至 Plan）**:
- P1-1：明确 `ExpertPromptOutput` 仅用于 build 阶段，LLM 输出由 `reasoningPrompt.parse()` 统一解析
- P1-2：明确 `expertPackages.toolResults` 的两阶段填充职责（retrieval 初始化空 / reasoning 填充）
- P1-3：明确专家 `build()` 负责格式化证据和工具结果（内聚策略）

**低优先级（Plan 中标记即可）**:
- P2-1：补充审计阶段字面量清单
- P2-2：补充汇总专家 `build()` 扩展参数说明

---

## 7. 最终建议

**执行顺序**：
1. 回流 P1-1/P1-2/P1-3 至 Plan（Plan §3.3、§3.4、§4 Task 4/5）
2. 补充 P2-1/P2-2 至 Plan Task 5.7、Task 2.12
3. DPS 通过后进入 Step 1

**完成判定**：
- 所有 P1 问题在 Plan 中有对应修正文字
- `npx tsc --noEmit` 零错误（Task 1.5、2.14、3.4、4.6、5.8）
- 回归测试通过（Task 6.3、6.4）
