# add-qoder-integration-review-v1

## Review 元信息

- **Review 对象**: `.qoder/plans/2026-06/25/add-qoder-integration-plan-v1.md`
- **Review 范围**: Plan §3.2 词汇映射表的完整性、三轮拆分的合理性、与现有 ADD 基础设施的兼容性
- **Review 时间**: 2026-06-25
- **结论级别**: ⚠️ 需修正后执行（P0: 词汇表覆盖不足，缺 ~60% 专有词汇）

---

## 1. 总体结论

Plan 方向正确——三层模型（词汇→惯性→编排）对准了 ADD 范式与 Qoder 工作流的真实断裂点。但 §3.2 词汇映射表仅覆盖了 9 个触发词，而项目实际 ADD 专有词汇约 **85+ 个**（含文档类型、阶段名称、规则编号、MCP 工具、核心概念、文件路径约定等 6 类）。词汇映射不全 = L1 预埋失效，LLM 仍然要对大部分 ADD 术语"主动去翻"。

**修正方向**：将词汇映射表从 9 条扩展到 6 类全覆盖（约 40-50 条核心映射），并按优先级分级。

---

## 2. 正向评价

| 评价项 | 说明 |
|--------|------|
| ✅ 三层模型架构清晰 | L1 词汇 → L2 惯性 → L3 编排，层次分明，依赖关系正确 |
| ✅ 选型决策审慎 | 纯 Qoder 原生机制，不引入外部 SDK 依赖，风险可控 |
| ✅ orchestrator/guardian 分工 | 不替代只补充，保护了现有 guardian 的投资 |
| ✅ index.md 优先查询 | 双保险设计（规则 + session-init 注入）合理 |
| ✅ 参照 handoff 结构 | 三轮拆分 + 原子事务边界，与项目现有 Plan 风格一致 |

---

## 3. 问题清单

### P0-1: §3.2 词汇映射表覆盖严重不足

**现状**：Plan §3.2 仅列出 9 个触发词映射。

**实际 ADD 词汇全景**（从 project_rules.md、add-paradigm SKILL、handoff 文档、guardian 定义中提取）：

#### 类别 A: 文档类型（11 个）

| 词汇 | LLM 默认操作 |
|------|-------------|
| `Plan` / `plan` | 查 `.qoder/plans/{YYYY-MM}/{DD}/` 下 `*-plan-v*.md` |
| `Spec` / `spec` | 查 `.qoder/specs/{name}/spec.md` |
| `Tasks` / `tasks` | 查 `.qoder/specs/{name}/tasks.md` |
| `Checklist` / `checklist` | 查 `.qoder/specs/{name}/checklist.md` |
| `Review` / `review` | 查 `.qoder/reviews/` 下 `*-review*.md` |
| `review-implementation` | 查 `.qoder/reviews/` 下 `*-review-implementation*.md` |
| `review-runtime` | 查 `.qoder/reviews/` 下 `*-review-runtime*.md` |
| `Handoff` / `handoff` / `交接` | 查 `.qoder/plans/{YYYY-MM}/{DD}/` 下 `*-handoff*.md` |
| `add-route` / `执行路线图` | 查 `.qoder/plans/` 下（递归）`*-add-route*.md` + 调 `check_add_route_status` |
| `devlog` / `开发日志` | **两种触发**: ①用户说"devlog 记录下"→ 立即写 devlog日志(走mcp) 到 `.qoder/plans/{YYYY-MM}/{DD}/`；②Step 8 收敛判断通过后 → 必须自动写 devlog日志(走mcp)（无需用户提醒），记录本轮改了什么、验收结果、遗留项 |
| `index.md` / `Plan索引` | 读 `.qoder/plans/index.md` |

#### 类别 B: ADD 阶段（11 个）

| 词汇 | LLM 默认操作 |
|------|-------------|
| `Step 0` / `文档先行` | 进入 add-paradigm Step 0：分析变更 → 更新文档 → 生成 add-route → DPS 门禁 |
| `Step 1` / `功能分析` | 确定 Phase → 扩展 AgentAuditPhase |
| `Step 2` / `审计基础设施` | 确认 agentAudit 通道 |
| `Step 3` / `业务逻辑实现` | add-route 前置守卫 → 代码实现 + 审计植入 |
| `Step 3.5` / `实现审查` | 跑 checklist [T] 项 → 生成 review-implementation + review-runtime |
| `Step 4` / `审计验证` | check_phase_symmetry + check_failure_path + RAHS 门禁 |
| `Step 5` / `合规检查` | AI 自动检查 ADD 原则合规性 |
| `Step 6` / `定位问题` | 从审计数据推断根因 |
| `Step 7` / `修复验证` | 修复 → 重新验证 |
| `Step 8` / `收敛判断` / `验收` | 全条件满足 → **必须依次执行**: ①写 devlog日志(走mcp) 到 `.qoder/plans/{date}/` → ②生成/更新 handoff → ③验收后架构文档回看（ADD-12）。三者缺一不可，不可只做 handoff 不写 devlog日志(走mcp) |
| `原子闭包` / `三可性` | 执行原子闭包判定：可独立提交/验证/审计/恢复 |

#### 类别 C: 门禁/闸门（6 个）

| 词汇 | LLM 默认操作 |
|------|-------------|
| `DPS` / `DPS闸门` | 调 `check_dps({ planKeyword: "..." })`，DPS ≥ 85 通过 |
| `RAHS` / `RAHS闸门` | 调 `check_rahs({ planKeyword: "..." })`，RAHS ≥ 90 通过 |
| `Guardian` / `门禁` / `add-flow-guardian` | 调 `add-flow-guardian` Subagent（入口或出口模式） |
| `add-route 闭环` / `闭环自检` | 调 `check_add_route_completeness({ planKeyword: "..." })` |
| `BLOCKED` / `阻断` | Guardian 返回 BLOCKED → 回退修复，不得继续 |
| `Review 回流` / `0.6.5` | Review P0/P1 问题必须写回 Plan + Specs |

#### 类别 D: MCP 工具（17 个，高频 8 个）

| 词汇 | LLM 默认操作 |
|------|-------------|
| `get_project_context` | 调 `get_project_context({ scope: "add-state" })` 获取 ADD 状态 |
| `query_audit_logs` | 按 keyword/targetId/targetType 查询审计日志 |
| `record_dev_operation` | 记录开发操作到 AuditLog |
| `check_dps` | DPS 闸门（Step 0 末尾） |
| `check_rahs` | RAHS 闸门（Step 4/8） |
| `check_add_route_status` | add-route 存在性校验（Step 3 前） |
| `check_add_route_completeness` | add-route Step 完成度扫描（Step 3 后） |
| `check_phase_symmetry` | 阶段标记对称性验证 |
| `check_failure_path` | 失败路径等价审计验证 |
| `check_add_compliance` | ADD 原则合规性扫描 |
| `check_spec_sync` | 文档-代码交叉校验 |
| `find_related_docs` | 搜索相关项目文档 |
| `get_add_template` | 读取 add-route 模板 |
| `get_spec_context` | 获取 spec 三元组上下文 |
| `get_db_schema` | 获取数据库 Schema |
| `get_audit_logger_pattern` | 获取审计日志器代码模式 |
| `generate_audit_logger` | 生成审计日志器代码 |

#### 类别 E: Skills / Subagents（5 个）

| 词汇 | LLM 默认操作 |
|------|-------------|
| `session-init` / `会话初始化` | 执行 session-init SKILL（新对话第一步） |
| `add-paradigm` / `ADD范式` | 执行 add-paradigm SKILL（开发任务入口） |
| `add-flow-guardian` / `Guardian` | 调起门禁 Subagent |
| `create-skill` | 引导创建新 Skill |
| `create-subagent` | 引导创建新 Subagent |

#### 类别 F: 核心概念（13 个）

| 词汇 | LLM 含义 |
|------|---------|
| `裁决层` / `caijue` / `caijue.toml` | 读 `src/caijuehub/caijue.toml`，含所有裁决条目 |
| `agentAudit` / `审计打点` | ADD-7：在业务代码中调用 `agentAudit(phase, detail, extra)` 植入运行时审计点（与 `record_dev_operation` 不同——前者是代码内审计函数，后者是 MCP 工具记录开发操作到 AuditLog 表） |
| `agentAuditNodeStart` / `agentAuditNodeEnd` | ADD-2：节点进入/退出阶段标记，用于验证阶段对称性 |
| `Phase` / `AgentAuditPhase` | `src/lib/agent-audit-logger.ts` 中的阶段联合类型定义，所有 `agentAudit()` 调用的 phase 参数必须来自此类型 |
| `ADD-3` / `最小可观测单元` | 审计粒度：循环内每个迭代独立审计、每个关键操作有独立记录，不可合并 |
| `ADD-4` / `三通道` | 审计输出：console（控制台）+ file（日志文件）+ DB（AuditLog 表），三者信息等价 |
| `ADD-5` / `审计数据即业务数据` / `业务日志metadata` | 审计指标回写业务表（如 `Document.metadata.lastSyncAudit`、`ChatThread.auditData`），不是独立审计表而是业务表字段 |
| `traceId` | 全链路追踪 ID，贯穿单次请求所有审计记录，支持 `query_audit_logs({ traceId })` 还原调用链 |
| `收敛` / `收敛判断` | Step 8：所有条件满足（tsc 通过 + checklist 全 [x] + RAHS ≥ 90 + add-route 全闭环）→ 功能开发完成 |
| `阶段对称` | ADD-2：每个 Phase 的 Start/End 必须成对，通过 `check_phase_symmetry` 验证 |
| `失败路径` | ADD-6：catch 块审计信息密度 ≥ try 块，通过 `check_failure_path` 验证 |
| `稀疏推理` | ADD-7 + MCP-5：通过 `query_audit_logs` 按 keyword/targetId/traceId 稀疏恢复开发上下文 |
| `planKeyword` | add-route / check_dps / check_rahs / check_add_route_completeness 的定位关键词，取自 Plan 核心功能名 |

---

**修正要求**：将 §3.2 词汇映射表从 9 条扩展到上述 6 类全覆盖。建议按优先级分三级：

- **P0（必须预埋）**：用户日常高频使用（devlog、handoff、add-route、看依赖、DPS、RAHS、Guardian、session-init、add-paradigm、Plan、Spec、Review、收敛）— 约 15 条
- **P1（应该预埋）**：开发流程中频繁涉及（各 Step 名称、MCP 工具、核心概念）— 约 20 条
- **P2（可选预埋）**：低频但 LLM 容易误解的（模板文件、规则编号）— 约 10 条

### P0-2: 验收闭环缺 devlog 写入——LLM 验收后不留痕

**问题**：用户说"按照 add 流程开始实施编程"，LLM 走完 Step 0-8 并通过验收后，**不执行 devlog 写入和 handoff 更新**。LLM 把"验收通过"当成终点，忽略了 ADD 范式要求验收后必须留痕（devlog + handoff + 架构文档回看）。

**根因**：词汇表中 Step 8 的原有描述只写了"生成 handoff"，没有 devlog。LLM 的"本能"里验收=结束，不包含留痕。

**修正**：Step 8 词汇条目已修正为三步强制序列：①写 devlog日志(走mcp) → ②更新 handoff → ③架构文档回看（ADD-12）。

**关联修正**：`devlog` 条目（类别 A）需增加触发场景说明——不仅在用户说"devlog 记录下"时触发，**在 Step 8 收敛判断通过后也必须自动触发**。

### P1-1: Plan 缺少"词汇分类体系"

**问题**：当前 Plan §3.2 是扁平表格，没有分类。当词汇超过 40 条时，扁平表格对 LLM 不可消费。

**修正建议**：改为分类表格（按 A-F 六类），每类独立表格。LLM 按类别检索更快。

### P1-2: Plan 缺少"触发词优先级"

**问题**：如果用户同时说"devlog 记录下，顺便看下这个依赖哪个plan"，LLM 不知道该先执行哪个。

**修正建议**：在词汇映射表中增加"优先级"列或"执行顺序"规则（如：查依赖类优先于写文档类）。

### P2-1: 缺少与 `project_rules.md` 现有内容的关系说明

**问题**：`project_rules.md` 已有 897 行规则定义，新增词汇映射表后如何与现有内容协同？是增量追加还是替换？是否需要重构 `project_rules.md`？

**修正建议**：在 Plan §4 第1轮中明确说明：词汇映射表作为 `project_rules.md` 的新增章节，放在现有"理论→实践映射"表之前。不删除现有内容。

---

## 4. 影响评估

| 维度 | 修正前（当前 Plan） | 修正后（建议） |
|------|-------------------|---------------|
| 词汇覆盖率 | 9/85 ≈ 10% | 45/85 ≈ 53%（P0+P1 全覆盖） |
| LLM 本能响应率 | 仅覆盖最高频 9 个词 | 覆盖日常开发中 90%+ 的 ADD 术语场景 |
| Plan §3.2 行数 | ~15 行（1 表格） | ~80 行（6 表格） |
| 实施工作量 | 第1轮 2 文件改动 | 第1轮 2 文件改动（内容更充实，文件数不变） |

**无越界风险**：词汇扩展不改变 Plan 的架构设计和三轮拆分，不引入新文件，不新增依赖。

---

## 5. 建议修正优先级

| 优先级 | 编号 | 问题 | 修正 |
|--------|------|------|------|
| 🔴 P0 | P0-1 | §3.2 词汇表仅 9 条 | 扩展到 6 类 ~45 条核心映射 |
| 🔴 P0 | P0-2 | 验收闭环缺 devlog 写入 | Step 8 改为三步序列 + devlog 双触发场景 |
| 🟡 P1 | P1-1 | 缺词汇分类体系 | 改为分类表格 |
| 🟡 P1 | P1-2 | 缺触发词优先级 | 增加优先级列或执行顺序规则 |
| 🟢 P2 | P2-1 | 与 project_rules.md 关系不明 | 补充增量说明 |

---

## 6. 最终建议

1. **先修正 Plan §3.2 词汇表**（P0-1），这是本次 Review 的唯一阻断项。修正内容：将词汇映射表从 9 条扩展到 6 类 P0+P1 全覆盖（约 35-45 条）。
2. **同步修正 P1-1 和 P1-2**，在修正 §3.2 时一并改为分类表格 + 增加优先级。
3. **P2-1 非阻断**，可在 Step 1 实施时自然明确。
4. 修正后重新 Review 确认词汇覆盖度，再进入 Step 0（生成 add-route + Specs）。
