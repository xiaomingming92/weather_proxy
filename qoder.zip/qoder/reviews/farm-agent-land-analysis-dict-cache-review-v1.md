# farm-agent-land-analysis-dict-cache-review-v1

## Review 元信息

- **Review 对象**: `farm-agent-land-analysis-dict-cache-plan-v1.md`
- **对比方案**: 当前硬编码映射 vs DictCache 字典缓存层方案
- **Review 时间**: 2026-06-24
- **Review 类型**: 方案选型 + 架构设计评审
- **前置阅读**: 
  - Plan: `.qoder/plans/2026-06/24/farm-agent-land-analysis-dict-cache-plan-v1.md`
  - dict-data-api: `docs/大田精准耕播智能决策系统/knowledge/02-规范/dict-data-api.md`
  - 地块接口文档: `docs/大田精准耕播智能决策系统/knowledge/02-规范/地块基本信息管理接口文档.v2.md`
  - 当前 route.ts: `src/app/api/h5/production-plan/land-analysis/route.ts`

---

## 1. 总体结论

**方向正确，具备执行基础。** 将枚举映射从硬编码迁移到 DictCache 字典缓存层是正确的架构方向，LLM 后处理覆盖的策略切实可行。存在 1 个 P0 阻断问题（moistureType 的 dictType 未确认）、2 个 P1 问题（token 注入路径、Next.js 生命周期适配），需在实施前解决。

---

## 2. 正向评价

- ✅ **问题分级清晰**：P0/P1/P2 三级划分准确，P0 聚焦用户直接可见的 bug，P1 做架构治理，P2 做文档补齐
- ✅ **方案选型有理有据**：四方案对比表覆盖了新鲜度/可用性/复杂度三个维度，方案 C（in-memory Map + 定时刷新）在权衡中最优
- ✅ **LLM 后处理策略务实**：不试图让 LLM 输出 100% 精确的枚举映射，而是 route.ts 确定性计算后强制覆盖。这是对 LLM 能力的正确认知
- ✅ **OpenAPI 同步解耦合理**：将同步机制标记为独立需求、不阻塞本次修复，避免范围蔓延
- ✅ **Task 1 和 Task 2 可并行**：肥力应急修复（硬编码扩展）和 DictCache 模块开发可同时推进，缩短交付时间

---

## 3. 问题清单

### P0-1：moistureType 对应的 dictType 名称未确认

- **问题**：Plan §3.3 中 `farm_massif_moisture_type` 标注为"待确认确切 dictType 名称"。这是 soilTypeSummary 功能的核心依赖——如果 Farm-Server 中不存在该 dictType，则 DictCache.getLabel() 永远返回 fallback，soilTypeSummary 输出将是 `"未知 100%"`
- **影响**：Task 3（soilTypeSummary 计算）和 Task 4（LLM 后处理覆盖）无法产出正确结果，等同于 P0 问题未修复
- **建议**：
  1. 实施前通过调用 `/system/dict-data/type` 搜索包含 `moisture` / `soil` / `massif` 的 dictType（使用 `/system/dict-data/type` 的列表接口，如果存在）
  2. 如 Farm-Server 没有 moistureType 的字典数据，则在 Plan 中增加 fallback 策略：从 OpenAPI 规范中提取枚举定义，或保留一组经过验证的硬编码映射作为兜底
  3. 在 DictCache 中增加 `registerStatic(dictType, mapping)` 方法，允许代码侧注册静态映射作为无字典数据时的兜底

### P1-1：DictCache 缺乏认证 token 注入路径

- **问题**：Plan §3.2 DictCache 接口设计中，`preload(dictTypes)` 没有参数接收 farmClient 或 token。而 `/system/dict-data/type` 需要 Bearer token 认证（与 Farm-Server 其他接口一致）
- **影响**：DictCache.preload() 无法独立调用 Farm-Server，preload 阶段必然失败
- **建议**：
  1. DictCache 构造函数或 `preload` 方法接受 `getToken: () => Promise<string>` 参数，与现有 `createFarmClient(getToken)` 模式对齐
  2. 或 DictCache 内部通过依赖注入持有 farmClient 实例
  3. 在 Plan §3.2 接口契约中补充 token 参数

### P1-2：Next.js API Route 无传统"启动"生命周期

- **问题**：Plan 多次提到"启动时调用 preload / startRefreshLoop"。Next.js API routes 是 serverless 风格的按需执行单元，没有 `main()` 或 `onStartup` 钩子。模块顶层代码在首次 import 时执行，但并发请求可能导致多次 preload
- **影响**：preload 可能在每个 cold start 都被触发，定时刷新在 Vercel/Node.js 环境下行为不确定（serverless 环境进程可能被回收）
- **建议**：
  1. 使用 lazy-init 模式：首次 `getLabel()` 调用时触发 preload，加 Promise 锁防止并发重复加载
  2. 定时刷新改用模块顶层 `setInterval`（在长期运行的 Node.js 进程下有效），或降级为 TTL-based 惰性刷新（缓存过期后下次查询时自动刷新）
  3. 在 Plan §3.4 中补充 Next.js 环境适配说明

### P2-1：Task 1 硬编码映射与 Task 3 DictCache 存在重复工作

- **问题**：Task 1 扩展硬编码映射 `{'0':'低','1':'中','2':'高','低':'低','中':'中','高':'高'}` 作为应急修复，Task 3 将其替换为 DictCache。两段代码生命周期重叠短，Task 1 的投入在 Task 3 完成后即被丢弃
- **影响**：无功能影响，但有轻微效率损失
- **建议**：如果 Task 1 和 Task 2 能同轮交付，可跳过 Task 1 中的硬编码扩展，直接一步到位接入 DictCache。如确实需要分步交付，当前策略可接受
- **评估**：降级为 P2（应急修复的价值优先于代码整洁度）

### P2-2：dictType 清单硬编码，缺少运行时发现机制

- **问题**：Plan §3.3 的 dictType 清单在代码中硬编码为 `["farm_massif_landform", "farm_massif_fertility_level", "farm_massif_moisture_type"]`。如果 Farm-Server 新增字典类型，消费者代码不会自动感知
- **影响**：新增枚举类型的适配需要代码变更。在当前需求范围内影响可控（字典变更频率极低）
- **建议**：v1 接受硬编码清单；v2 考虑调用 `/system/dict-data/type` 的全量列表接口（如果存在）做自动发现
- **评估**：降级为 P2（当前已知类型覆盖全部需求）

### P2-3：LLM prompt 字段名修正 + 后处理覆盖存在双重保障

- **问题**：Plan 同时要求"LLM prompt 中 soilType → soilTypeSummary"和"route.ts 后处理强制覆盖 soilInfo.fertility 和 soilInfo.soilTypeSummary"。LLM prompt 修正后，LLM 输出的字段名已对齐，后处理覆盖变成冗余操作
- **影响**：无负面影响（belt-and-suspenders 是加分项），但需明确主次关系避免后续维护者困惑
- **建议**：在 Plan §3.5 或代码注释中明确标注"后处理覆盖为权威数据源，LLM prompt 对齐为辅助优化（减少无效推理 token 消耗）"

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 操作 | 风险 |
|------|------|------|
| `src/app/api/h5/production-plan/land-analysis/route.ts` | 修改（肥力计算 + soilTypeSummary + 后处理） | 中（核心业务逻辑变更，需回归测试） |
| `src/lib/farm-api/dict-cache.ts` | **新建** | 低（独立模块，无破坏性） |
| `src/lib/farm-api/massif.ts` | 修改（MassifDTO.fertilityLevel 类型） | 低（类型放宽，向后兼容） |
| `src/agents/prompts/experts/land-analysis.ts` | 修改（字段名对齐） | 低（prompt 变更，LLM 输出可能略有差异但有后处理兜底） |
| `docs/大田精准耕播智能决策系统/knowledge/02-规范/地块基本信息管理接口文档.v2.md` | 修改（新增章节） | 极低（纯文档） |

### 4.2 数据流影响

- **fertility 数据流**：`Farm-Server fertilityLevel(integer) → route.ts 取值(兼容 string/null) → DictCache.getLabel() → 面积加权 → fertilitySummary`。映射层从硬编码移到 DictCache，计算结果不变（修复了 null→"未知"的 bug）
- **soilTypeSummary 数据流**（新增）：`Farm-Server moistureType(string) → route.ts → DictCache.getLabel() → 面积加权 → soilTypeSummary`。此前该字段不存在，新增后 LLM prompt 输入多一个字段，输出被后处理覆盖
- **LLM prompt 输入增加**：`soilTypeSummary` 字段新增传入 userInput，token 消耗增加约 50-100 tokens/请求（可忽略）

### 4.3 回滚风险

- **低风险**：DictCache 为独立新增模块，删除即可回退。route.ts 的肥力计算变更可通过 git revert 回退
- **需注意**：MassifDTO.fertilityLevel 类型变更为 `number | string | null` 放宽后，其他消费者不会编译报错，但需确认运行时行为（原来是 number?，现有代码可能做了 `p.fertilityLevel > 0` 这种数值比较）

---

## 5. 建议修正优先级

| 优先级 | 编号 | 问题 | 动作 |
|:--|:--|:--|:--|
| 🔴 阻断 | P0-1 | moistureType dictType 未确认 | 实施前调用 dict API 确认/搜索；无结果则增加静态映射兜底 |
| 🔴 高 | P1-1 | DictCache token 注入路径缺失 | preload() 增加 getToken 参数，与 farmClient 模式对齐 |
| 🔴 高 | P1-2 | Next.js 生命周期适配 | lazy-init + Promise 锁 + TTL 惰性刷新，替代"启动时"语义 |
| 🟡 中 | P2-1 | Task 1/3 重复工作 | 可接受（应急修复优先）；如能同轮交付则跳过 Task 1 硬编码扩展 |
| 🟢 低 | P2-2 | dictType 清单硬编码 | v1 接受；v2 考虑自动发现 |
| 🟢 低 | P2-3 | LLM 双重保障 | 在代码注释中明确后处理为权威数据源 |

---

## 6. 最终建议

1. **P0-1 先解决再进入 Step 1**——调用 `/system/dict-data/type` 端点确认 moistureType 对应的 dictType 是否存在。如不存在，在 Plan 中增加 `DictCache.registerStatic()` 兜底方案
2. **P1-1/P1-2 在 Specs 阶段细化**——DictCache 接口契约中补充 token 注入和 Next.js lazy-init 的具体实现方式
3. **实施顺序**：Task 2 (DictCache) → Task 1 (肥力修复，可并行) → Task 3 (接入) → Task 4 (prompt) → Task 5 (文档) → Task 6 (验证)
4. **DPS 回流**：P0-1 写入 Plan §3.3 补充 "moistureType 字典获取策略（含兜底）"；P1-1 写入 Plan §3.2 DictCache 接口增加 token 参数；P1-2 写入 Plan §3.4 补充 Next.js lazy-init 说明
