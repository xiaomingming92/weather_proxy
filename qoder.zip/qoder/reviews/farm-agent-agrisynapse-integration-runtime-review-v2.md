# Review: agrisynapse ↔ farm-agent 联调运行时

> **修订记录**
> - 2026-06-08: 初版，方案层 review
> - 2026-06-09: 运行时验证增量——补充 5 项遗漏 + 根因复盘
> - 2026-06-09: 运行时验证增量 #2——RAG 检索崩溃 + 专家链路缺陷 + 审计日志盲区

## Review 元信息

- **Review 对象**: Task 0-7 实施产物（agrisynapse 对接层代码 + farm-agent 跨域配置）
- **对比方案**: 握手机制：一次性初始化 vs 惰性重连（详见第 2 节）
- **Review 时间**: 2026-06-08
- **Review 类型**: 方案 review + 运行时验证（2026-06-09 增量）
- **前置阅读**: `.qoder/plans/farm-agent-agrisynapse-integration-plan-v1.md`、`.qoder/reviews/farm-agent-agrisynapse-integration-plan-v1-review.md`

---

## 0. 本 review 的局限性（事后反省）

本次 review 作为"方案层 review"，在以下维度存在结构性盲区，导致运行时验证阶段暴露 5 项本应提前捕获的问题。

### 0.1 review2 做了什么的

| 维度 | 审查内容 | 状态 |
|------|---------|:---:|
| 握手幂等性 | handshake 每次新建 thread → 引入 action 字段 | ✅ |
| 认证简化 | 砍掉 JWT → hash-only 三层模型 | ✅ |
| 裁决层独立 | auth-gateway.ts / agrisynapse-handshake.ts | ✅ |
| Hash/OPTIONS/Seed | 算法对齐、预检放行 | ✅ |
| 日志基建 | agrisynapse 侧零日志 | ✅ |

### 0.2 review2 没做什么的（根本缺陷）

| # | 未审查项 | 后果 | 应在哪个环节捕获 |
|---|---------|------|-----------------|
| 1 | **Chat 响应格式契约**：agrisynapse 的 `parseSSEStream` 期望 `data:` 行，farm-agent 实际返回 `NextResponse.json({ messages: [...] })` | GUI 永远卡在"等待响应" | plan 的 Task 7 设计阶段，或 review2 的 §4.1 受影响文件逐行对比 |
| 2 | **Next.js 16 兼容性**：`middleware.ts` 已废弃，需用 `proxy.ts`；两者共存直接报错无法启动 | dev server 报错 `Both middleware and proxy detected` | review2 的 §4.1 环境/版本审计 |
| 3 | **Middleware 热更新**：Turbopack 不热加载 proxy 变更，导致改完后实际运行的仍是旧编译产物 | 调试时修改 proxy 无效，误判为"代码有问题" | 运维/部署 checklist |
| 4 | **AuditLog 外键约束**：`userId: "system"` 不在 User 表中，Prisma 写入时报 `Foreign key constraint violated` | AuditLog 表永远为空，审计链路断裂 | review2 的 §4.1 数据模型一致性检查 |
| 5 | **agrisynapse 启动命令 vs env 文件映射**：开发环境到底用 `.env.local` 还是 `.env.dev`，`VITE_FARM_AGENT_BASE_URL` 指向哪个实例，全程未被审查 | curl 打到错误的 farm-agent 实例（远端 IP vs 本地 IP） | review2 的 §4.1 环境变量验证 |
| 6 | **Plan 第4轮专家链路的 undefined 传播**：`expertWhere` 在无激活专家时为 `undefined`，透传到 `knowledge-indexer.ts` 导致 `JSON.stringify(undefined).slice()` 崩溃；审计日志仅记 `error.message` 无 stack trace，`RAG_EMPTY` 误报掩盖了真实 crash | 用户问“天气对玉米生长影响”→ RAG 检索崩溃 → 零证据回答 | review2 的 §4.1 Plan 变更影响链追踪 |

### 0.3 根因："方案 review"与"实现 review"混为一谈

review2 本质上是对 **plan 的设计决策做审核**（握手幂等性、认证简化、裁决层抽象），但被命名为"运行时验证"。真正的运行时检查——`curl` 验证、浏览器 console 检查、端到端数据流追踪——全部缺失。

**教训**：ADD 范式中，review 应分为两阶段：
1. **设计 review**（plan 确认后）：审方案合理性、架构一致性
2. **实现 review**（代码落地后）：跨仓库格式契约逐条验证、end-to-end curl 链路、环境变量审计

---

## 1. 问题复现

Task 0-7 实施完成后，浏览器打开 agrisynapse LLM 页面，`GET /api/agent/{hash}?action=dashboard` 永远 pending。排查过程发现以下阻塞链：

```
浏览器 fetch dashboard
  │
  ├─ OPTIONS 预检 ──► 无响应（route.ts 缺 OPTIONS() 导出）
  │
  ├─ GET dashboard ──► 404（hash 算法三处不匹配 + seed 是业务文案非系统密钥）
  │
  ├─ 修复后 GET dashboard ──► 401（测试 token 无效，JWT 认证链路未验证）
  │
  └─ 假设 token 通过后 ──► handshake 每次新建 thread（不幂等）
                            agrisynapse initialized 锁阻止重连（farm-agent 重启后不可恢复）
```

### 1.1 已当场修复的三项

| # | 问题 | 根因 | 修复 |
|---|------|------|------|
| OPTIONS | 浏览器预检永远 pending | `route.ts` 只有 GET/POST，无 OPTIONS | 新增 `OPTIONS()` → 204 |
| Hash 算法 | hash 校验 404 | 客户端 `seed + "_" + windowMs`、完整 64 位 hex；服务端 `seed + window`、前 12 位 hex | 客户端对齐服务端三要素 |
| Hash Seed | seed 是业务需求文案 | `"汇总当日农场各项数据..."` 是农情日报描述，非系统密钥 | 改为系统级标识字符串 |

### 1.2 仍待解决的阻塞项

**握手不幂等 + 启动顺序绑定**：`handleHandshakePOST` 每次 `createThread` 新建会话；`initSession` 的 `initialized` 锁阻止重连。farm-agent 重启后 agrisynapse 持有失效 threadId/hash，发消息必然失败且无法自动恢复。

**握手成功后 threadId 分配无区分逻辑**：当前 `route.ts` L354 `const thread = await chatPersistence.createThread(...)` 对全部场景一律新建线程，不区分调用意图、不检查已有线程。更根本的问题是：**仪表盘页面加载时不该触发 handshake**——仪表盘是 GUI 入口，用户只是打开页面看面板卡片（农情日报等 9 个技能卡），尚未开始对话。当前因为仪表盘嵌了一个兜底聊天输入框，导致 `onMounted` 时 eager handshake → 建了线程但从未使用 → 产生孤儿线程。正确做法是：仪表盘只鉴权拿 hash，thread 留在用户首次发消息时惰性创建。

以下按「handshake 是否应该发生」和「thread 应如何分配」两个维度分析各场景：

| 场景 | 当前行为（bug） | handshake 应触发？ | thread 应有行为 |
|------|----------------|:---:|---------|
| 用户首次访问仪表盘（只看面板） | eager handshake → **不该建 thread 却建了**，孤儿线程 | 否 | 不创建 thread，仅鉴权 + 渲染仪表盘 |
| 用户从仪表盘输入框发送第一条消息 | 复用仪表盘加载时建的 thread | 是（惰性） | handshake({ action: "new" }) → 无条件新建 |
| 用户刷新页面后继续对话（有历史） | **又新建一个 thread**，旧对话丢失 | 是（惰性，sendMessage 触发） | handshake({ action: "resume" }) → 复用最近 thread |
| 用户点击「新建对话」按钮 | 新建 thread（看似正确，但无法与 resume 区分） | 是（主动） | handshake({ action: "new" }) → 无条件新建 |
| farm-agent 重启后发消息失败 | **又新建一个 thread**，历史不可恢复 | 是（惰性，失败重连） | handshake({ action: "resume" }) → 复用重启前最近 thread |
| resume 查无 thread（首次使用/数据丢失） | 当前无此场景（因为总是 eager 建） | 是（惰性） | 返回 `{ threadId: null }`，GUI 回到仪表盘。不偷偷建线程 |

> **关键约束**：`resume` 的语义是"恢复会话"。查不到就该诚实告知"无会话可恢复"，让 GUI 回到仪表盘。不允许 resume 查无时自动 `createThread()`——那是 `new` 的职责。

根源：`handleHandshakePOST` 内部直接在路由处理函数中硬编码了 `createThread()` 调用（`route.ts` L354-359），没有任何条件分支、没有查询已有线程、没有裁决输入。

**agrisynapse 对接链路零日志**：`agentChatStore`、`src/api/agent/index.ts`、`LlmChatView.vue` 完全静默。farm-agent 侧三层审计（console + 文件 + DB），agrisynapse 侧裸奔，问题定位全靠黑盒。

**JWT 认证链路过度设计**：当前 plan 2.6 设计了三层鉴权（JWT Bearer + userVO + credential-store），但经运行时验证发现：

1. agrisynapse 的 JWT 由 Java 后端签发，farm-agent 的 JWT_SECRET 只认自己签发的 token，跨系统验不过 → 401
2. 即使共享密钥，`Authorization` header 只能放一个 token，无法同时承载"机器身份"和"用户身份"
3. Farm-Server token 出生在浏览器（用户登录 agrisynapse 时获取），经浏览器透传给 farm-agent 会在 DevTools 明文暴露
4. Per-user token 管理带来多点登录混乱——同一用户多个浏览器 tab 持有不同 token 状态

**简化方案**（本次 review 产出）：

```
砍掉：
  ❌ agrisynapse→farm-agent JWT 登录（不需要）
  ❌ SERVICE_TOKEN（不需要）
  ❌ per-user credential-store（改为一个 service token）
  ❌ Farm-Server token 经浏览器透传

保留：
  ✅ hash-path 作为合法调用方证明（SHA-256，10分钟滚动窗口）
  ✅ userVO 经 hash 验证后可信

新增：
  ✅ farm-agent 用自有 service 账户登录 Farm-Server（部署时预配）
  ✅ 一个 service token 服务所有用户，按 massifId 过滤数据
  ✅ lib/credential/ 独立目录，agents/tools/ 禁止 import，LLM 不可达
```

最终认证模型（极简三层）：

| 层 | 证明什么 | 机制 | 放哪 |
|----|---------|------|------|
| 调用方身份 | "你是 agrisynapse" | hash-path（seed + 时间窗口） | URL path |
| 用户身份 | "当前用户是张三" | userVO（hash 验证后可信） | body |
| 数据源凭证 | "有权查 Farm-Server" | farm-agent 自己的 service token（内部闭环） | lib/credential/ |

---

## 2. 方案对比

> 仅对需要设计决策的「握手机制」列出对比。OPTIONS / Hash / Seed 已修复无分歧，日志系统由 agrisynapse 维护者另行准备，JWT 认证已决策砍掉（见 1.2 节简化方案 + 决策 #6）。

### 2.1 方案 A: 一次性握手（现状）

```
agrisynapse onMounted → initSession()
  ├─ initialized=true → 后续调用直接 return
  └─ handshake 返回 threadId

farm-agent handleHandshakePOST
  └─ createThread() → 每次新建
```

- farm-agent 重启 → agrisynapse threadId 失效 → sendMessage 静默失败
- 用户刷新页面 → 再次 handshake → 创建第二个 thread（旧对话丢失）
- 用户无法"新建对话"（与"返回仪表盘"无法区分）

### 2.2 方案 B: 惰性重连 + action 区分意图

```
agrisynapse sendMessage()
  ├─ if (!threadId) → initSession() → handshake({ action: "resume" })
  └─ 请求失败(404/401) → handshake({ action: "resume" }) → 重发

farm-agent handleHandshakePOST
  ├─ action === "new" → createThread()
  └─ action === "resume" (默认) → findFirst(updatedAt desc) → 有则返回 / 无则返回 { threadId: null }
```

handshake 加 `action?: "resume" | "new"` 字段。注意：handshake 不再在仪表盘 `onMounted` 时触发，改为 **惰性触发**——仅在 `sendMessage` 发现 `!threadId` 或请求失败时调用：

| 场景 | 触发时机 | action | farm-agent 行为 |
|------|---------|--------|----------------|
| 用户从仪表盘输入框发送第一条消息 | sendMessage 发现 !threadId | new | 无条件新建 |
| 页面刷新后继续对话 | sendMessage 发现 !threadId（旧 threadId 在内存丢失） | resume | 查到最近线程 → 返回 |
| 点击"新建对话" | 用户主动点击 | new | 无条件新建 |
| farm-agent 重启后发消息失败 | sendMessage 失败(404) → 触发重连 | resume | 查到最近线程 → 返回，重发消息 |
| resume 查无 thread | sendMessage 失败重连后发现无历史线程 | resume | 返回 `{ threadId: null }` → GUI 回仪表盘 |

> **关键区别**："首次访问仪表盘"不在上表中——仪表盘加载不触发 handshake。"从仪表盘发第一条消息"用 `new` 而非 `resume`，因为仪表盘本身不代表有历史会话。`resume` 查无时不建线程——建线程是 `new` 的职责。

### 2.3 方案 B 的裁决层设计：`caijuehub/strategies/agrisynapse-handshake.ts`

方案 B 中 farm-agent 侧的 thread 路由决策不应硬编码在 `route.ts` 中——这违反项目已有的「裁决与执行分离」原则。参照 `caijuehub/strategies/` 下已有模式（`thinking-level.ts`、`sub-intent.ts`、`response.ts`），应抽象为独立的裁决策略文件：

```
┌─ route.ts (执行层) ──────────────────────────┐
│                                               │
│  handleHandshakePOST(body, userId)            │
│    │                                           │
│    ├─ 1. 认证 / user_profile upsert           │
│    ├─ 2. resolveHandshakeThread({             │  ← 调裁决层，不判断
│    │      action: body.action ?? "resume",     │
│    │      userId,                              │
│    │    })                                     │
│    ├─ 3. nextHash = getNextHash()             │
│    └─ 4. return { threadId, nextHash }        │
│                                               │
└───────────────────────────────────────────────┘
                    │
                    ▼
┌─ caijuehub/strategies/agrisynapse-handshake.ts (裁决层) ─┐
│                                               │
│  resolveHandshakeThread(input) → ThreadDecision│
│    │                                           │
│    ├─ action === "new"                        │
│    │   └─ createThread() → 无条件新建         │
│    │                                           │
│    └─ action === "resume" (默认)              │
│        ├─ findFirst(userId, updatedAt desc)   │
│        ├─ 有 → 复用，写审计日志               │
│        │      RESUME_THREAD_REUSED             │
│        └─ 无 → 返回 null，写审计日志          │
│               RESUME_NO_THREAD，GUI 回仪表盘    │
│                                               │
└───────────────────────────────────────────────┘
```

**裁决层 vs 执行层的职责边界**：

| 层 | 文件 | 职责 | 禁止 |
|----|------|------|------|
| 裁决层 | `caijuehub/strategies/agrisynapse-handshake.ts` | 根据 action + userId + DB 查询结果，输出 `{ thread, isNew }` 决策 | 禁止直接读写 HTTP 请求/响应 |
| 执行层 | `route.ts` `handleHandshakePOST` | 调裁决层获取决策 → 组装 HTTP 响应 → 写审计日志 | 禁止内含 if/else 判断 thread 路由 |

**裁决输入/输出类型定义**：

```typescript
// caijuehub/strategies/agrisynapse-handshake.ts

export interface HandshakeThreadInput {
  action: "resume" | "new"
  userId: string
}

export interface HandshakeThreadDecision {
  thread: { id: string } | null  // null = resume 查无，GUI 回仪表盘
  isNew: boolean
  auditAction: "RESUME_THREAD_REUSED" | "RESUME_NO_THREAD" | "NEW_THREAD_CREATED"
}

export async function resolveHandshakeThread(
  input: HandshakeThreadInput
): Promise<HandshakeThreadDecision> {
  if (input.action === "new") {
    const thread = await chatPersistence.createThread(input.userId)
    return { thread, isNew: true, auditAction: "NEW_THREAD_CREATED" }
  }

  // resume: 查找最近活跃线程
  const recent = await prisma.chatThread.findFirst({
    where: { userId: input.userId },
    orderBy: { updatedAt: "desc" },
  })

  if (recent) {
    return { thread: { id: recent.id }, isNew: false, auditAction: "RESUME_THREAD_REUSED" }
  }

  // resume 查无 → 不建线程，返回 null，GUI 回仪表盘
  return { thread: null, isNew: false, auditAction: "RESUME_NO_THREAD" }
}
```

> **设计理由**：`RESUME_THREAD_REUSED`（复用已有）、`RESUME_NO_THREAD`（查无，回仪表盘）、`NEW_THREAD_CREATED`（主动新建）三种 audit action 覆盖全部握手路径。`resume` 查无时不建线程——`resume` 的语义是"恢复"而非"创建"，建线程是 `new` 的专属职责。thread 为 null 时 agrisynapse 应路由到仪表盘页面。

### 2.4 认证网关裁决层：`caijuehub/strategies/auth-gateway.ts`

当前 `proxy.ts` L51 硬编码了 `requireRole(request, ["ROOT", "STAFF", "SERVICE"])`——即"所有 `/api/agent/*` 请求必须有 JWT"。但 agrisynapse 不签发 farm-agent 的 JWT，也不该被要求提供 JWT（hash-path 已证明调用方身份）。更根本的问题是：**proxy.ts 是基础设施，不该内含"哪些调用方用什么认证方式"这种业务规则。**

#### 2.4.1 现状 vs 目标

```
现状（proxy.ts 硬编码认证规则）：

  request → hash 校验 → requireRole(JWT)
                              │
                              ├─ 有 JWT → 验签 → 提取 user → 放行
                              └─ 无 JWT → 401 ❌  agrisynapse 卡死在这

目标（裁决层集中认证决策）：

  request → hash 校验 → resolveAuthGateway(request)
                              │
                              ├─ 有合法 JWT → { mode: "jwt", user }
                              └─ 无 JWT     → { mode: "hash-only" }
                              
                            ↓ 放行（ctx 注入 request）
```

#### 2.4.2 裁决层设计

```
┌─ proxy.ts (执行层) ────────────────────────────────────┐
│                                                        │
│  hash 校验通过                                          │
│    │                                                    │
│    └─ authCtx = resolveAuthGateway(request)  ← 调裁决层│
│         │                                               │
│         ├─ mode === "jwt"       → 审计日志记 userId     │
│         └─ mode === "hash-only" → 审计日志记 "external" │
│                                                        │
│    → 放行至 route.ts                                    │
│                                                        │
└────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─ caijuehub/strategies/auth-gateway.ts (裁决层) ───────┐
│                                                        │
│  resolveAuthGateway(request) → AuthGatewayDecision     │
│    │                                                    │
│    ├─ extractTokenFromRequest(request)                 │
│    │   ├─ 有 token → verifyToken(token)                │
│    │   │   ├─ 有效 → { mode: "jwt", user: payload }    │
│    │   │   └─ 无效 → 401                               │
│    │   └─ 无 token                                     │
│    │       └─ { mode: "hash-only" }                    │
│    │            ↑ 外部 GUI (agrisynapse 等)，           │
│    │              用户身份从 body 取                    │
│                                                        │
└────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─ route.ts (执行层) ────────────────────────────────────┐
│                                                        │
│  authCtx = request.ctx.authGateway                     │
│                                                        │
│  handleHandshakePOST:                                  │
│    mode === "jwt"       → userId = authUser.userId     │
│    mode === "hash-only" → userId = body.userVO.id      │
│                                                        │
│  handleChatPOST:                                       │
│    mode === "jwt"       → userId = authUser.userId     │
│    mode === "hash-only" → userId = body.userId         │
│                                                        │
└────────────────────────────────────────────────────────┘
```

**裁决层 vs 执行层的职责边界**：

| 层 | 文件 | 职责 | 禁止 |
|----|------|------|------|
| 裁决层 | `caijuehub/strategies/auth-gateway.ts` | 根据请求中是否存在 JWT，裁决认证模式（jwt / hash-only） | 禁止读 body、禁止判断用户角色 |
| 执行层 (proxy) | `proxy.ts` | hash 校验 → 调裁决层 → 写审计日志 → 放行 | 禁止内含 `requireRole` 等认证判断 |
| 执行层 (route) | `route.ts` | 根据裁决层的 mode 选择 userId 来源（JWT payload / body userVO） | 禁止内含"这个请求该不该要 JWT"的判断 |

**裁决输入/输出类型定义**：

```typescript
// caijuehub/strategies/auth-gateway.ts

export type AuthMode = "jwt" | "hash-only"

export interface AuthGatewayDecision {
  mode: AuthMode
  user: JWTPayload | null  // null = hash-only 模式，用户身份从 body 取
}

export function resolveAuthGateway(request: NextRequest): AuthGatewayDecision {
  const token = extractTokenFromRequest(request)

  if (token) {
    const payload = verifyToken(token)
    if (payload) {
      return { mode: "jwt", user: payload }
    }
    // token 存在但无效 → 拒绝（不 fallback 到 hash-only）
    throw new AuthError("无效或过期的令牌")
  }

  // 无 token：外部 GUI，hash 已证明调用方身份
  return { mode: "hash-only", user: null }
}
```

> **设计理由**：proxy.ts 作为基础设施，不应内含"哪些调用方用什么认证方式"这种业务规则。今天 agrisynapse 用 hash-only，明天 WeChat 小程序可能用 session token——每次新增调用方都改 proxy.ts 是不可接受的。裁决层集中管理认证模式决策，proxy.ts 只做"调裁决层 → 放行"。`token 存在但无效 → 401`（不 fallback）：如果有人传了 JWT，说明他声称自己是 JWT 模式，验不过就该拒绝，不会悄悄降级成 hash-only。

---

## 3. 决策结论

1. **握手机制**：采用方案 B。去掉 agrisynapse `initialized` 锁，handshake 加 `action` 字段，farm-agent 按 action 决定新建或复用。
2. **裁决层独立**：thread 路由决策（新建/复用）不得硬编码在 `route.ts` 中。新建 `caijuehub/strategies/agrisynapse-handshake.ts`，遵循项目已有「裁决与执行分离」模式（参照 `thinking-level.ts`、`sub-intent.ts`、`response.ts`）。裁决层输出 `{ thread, isNew, auditAction }`，执行层只负责调裁决层 + 组装 HTTP 响应。
3. **两种语义严格分离**：`new` = 无条件建线程（仪表盘输入框首发消息、点击新建对话按钮）；`resume` = 查最近线程，有则复用，无则返回 null → GUI 回仪表盘。resume 永远不建线程。
4. **OPTIONS / Hash / Seed**：已修复，编译验证通过。
5. **日志系统**：agrisynapse 维护者另行准备，不阻塞本次联调。
6. **JWT 认证简化**：砍掉 agrisynapse→farm-agent JWT 登录。hash-path 已证明调用方身份（seed + SHA-256 + 10分钟滚动窗口），userVO 经 hash 验证后即信任。farm-agent 不再需要验证 agrisynapse 的 JWT，也不再签发 SERVICE_TOKEN。Farm-Server 凭证由 farm-agent 自有 service 账户内部闭环管理，agrisynapse 不持有、不传递。详见 1.2 节「简化方案」。
7. **认证网关裁决层**：proxy.ts 不再内含认证模式判断。新建 `caijuehub/strategies/auth-gateway.ts`，集中裁决 jwt / hash-only 两种认证模式。proxy.ts 只做 hash 校验 → 调裁决层 → 放行。route.ts 根据裁决结果选择 userId 来源。详见 2.4 节。

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 影响 |
|------|------|
| farm-agent `src/caijuehub/strategies/agrisynapse-handshake.ts` | **新建**：裁决层，`resolveHandshakeThread()` 集中裁决 thread 路由 |
| farm-agent `src/caijuehub/strategies/auth-gateway.ts` | **新建**：裁决层，`resolveAuthGateway()` 裁决 jwt / hash-only 认证模式 |
| farm-agent `src/app/api/agent/[hash]/route.ts` | `HandshakeRequestBody` 加 `action` 字段；`handleHandshakePOST` 调裁决层替代硬编码 `createThread`；`handleChatPOST` userId 来源改为从裁决层模式判定 |
| farm-agent `src/proxy.ts` | 移除 `requireRole` 调用；hash 校验后改调 `resolveAuthGateway()` 裁决层 |
| farm-agent `src/lib/credential/` | **新建独立目录**：farm-agent 自有 service 账户登录 Farm-Server 的 token 管理。`agents/tools/` 禁止 import，LLM 不可达 |
| agrisynapse `src/store/modules/agentChat.ts` | 去掉 `initialized` 锁；`initSession` 传 `action`；新增 `startNewChat()`；`sendMessage` 惰性重连；移除 Farm-Server token 透传逻辑 |
| agrisynapse `src/api/agent/index.ts` | `handshake()` 签名加 `action` 参数；移除 Authorization header 注入 |
| agrisynapse `src/api/agent/types.ts` | `HandshakeRequest` 加 `action` 字段；移除 `farmServerToken` 字段 |

### 4.2 数据流影响

- 握手响应：`{ threadId: string | null, nextHash }`。threadId 为 null 时 agrisynapse 路由到仪表盘页面
- `sendMessage` 新增失败重连路径：捕获 404/401 → `initSession()` → 重发
- 多线程：用户可通过 `startNewChat()` 创建新线程，旧线程保留在 DB

### 4.3 回滚风险

- handshake `action` 默认 `"resume"`，不传 action 的旧客户端行为 = 方案 B 的 resume 路径（查最近线程），向后兼容
- `initialized` 锁去掉后，`initSession` 可重复调用，需确保 dashboard 数据不重复填充（Store 已有幂等处理）

---

## 5. 运行时验证增量发现（2026-06-09）

### 5.1 发现 #1: Chat 响应格式契约断裂（最严重）

agrisynapse 客户端与 farm-agent 服务端对 chat 请求的响应格式存在根本性分歧。

| 位置 | 期望/实际 | 格式 |
|------|----------|------|
| agrisynapse `parseSSEStream` (L190-220) | 期望 | `data: {"type":"token","content":"..."}\n` |
| agrisynapse `_dispatchEvent` (L243-270) | 期望 | 事件类型: `token`, `rag_search`, `evidence_found`, `tool_call`, `tool_result` |
| farm-agent `route.ts` `handleChatPOST` (L577-588) | **实际** | `NextResponse.json({ success, data: { messages, verdict, ... } })` |

**根因（git 追溯）**：

```
commit 17e1d0f (2026-06-06, "feat: 工具管线 v1 业务层")
  - 新增 src/app/api/agent/[hash]/route.ts
  - handleChatPOST 引用了 runAgent() ← 错误，chat 场景应用 streamAgent()

agents/index.ts 中两个函数自项目创建时（51b6ed5）就同时存在：
  runAgent()      → agent.invoke() 同步执行，等全部管线跑完再返回结果
                    适用场景：批处理、脚本调用、不需要实时反馈的后台任务
  streamAgent()   → agent.stream() 流式执行，逐 node 产出 chunk + 通过
                    CognitiveEventBus 发射 token/evidence/verdict 等事件
                    适用场景：chat 对话、SSE 推送、需要逐字展示的 UI
```

`17e1d0f` 作者从旧端点 `/api/agent/chat/stream/route.ts` 复制工具管线相关代码时，面对两个导出函数随手选了名字更短的 `runAgent`，没有意识到 chat 场景必须用流式版本。

旧端点一直用 `streamAgent` + `CognitiveEventBus` + `NodeStreamController` 做真正的 SSE 流式输出。新端点因选错函数，导致返回 `NextResponse.json({ messages: [...] })` 而非 `text/event-stream`。

**后果链**：
1. agrisynapse POST chat → farm-agent 跑完整 Agent 管线（~54s）→ 返回 JSON
2. `parseSSEStream` 读 body，JSON 不含 `data:` 行 → 永远不 yield 事件
3. `_consumeSSE` 的 `for await` 循环等到 stream done 才退出
4. 期间 `msg.isStreaming = true`，GUI 永远转圈

**修复方向**：`handleChatPOST` 改为使用 `streamAgent()` 替代 `runAgent()`，参照 `/api/agent/chat/stream/route.ts` 的 `CognitiveEventBus` + `NodeStreamController` 模式，返回 `Content-Type: text/event-stream`。

#### review2 为何遗漏

§4.1 列出了受影响文件，但只检查"文件是否存在"，没有做跨仓库格式契约验证。`parseSSEStream` 期望的 event 类型和 `route.ts` 返回的 JSON 字段从未被逐行对比。

---

### 5.2 发现 #2: Next.js 16 middleware.ts 已废弃

```
⚠ The "middleware" file convention is deprecated. Please use "proxy" instead.
❌ Both middleware and proxy detected. Use "./src/proxy.ts" only.
```

dev server 直接报错无法启动。须删除 `src/middleware.ts`，仅保留 `src/proxy.ts`（Next.js 16 的 proxy 约定：导出 `proxy` 函数 + `config`）。

---

### 5.3 发现 #3: Proxy 变更不热更新

```
src/proxy.ts                 Jun 8 18:11  ← 修改后
.next/server/middleware.js   Jun 8 15:31  ← Turbopack 未重新编译
```

修改 proxy 后 curl 不变 → 误判为"代码有问题"。必须 `fuser -k 3000/tcp && npm run dev`。

---

### 5.4 发现 #4: AuditLog 外键约束违反

```
prisma:error
Invalid `prisma.auditLog.create()` invocation:
Foreign key constraint violated on the constraint: `AuditLog_userId_fkey`
```

`agent-gateway-audit.ts` L39 写入 `userId: "system"`，但 `AuditLog.userId → User.id` 是外键，User 表无 id="system" 的记录。

**修复**：创建 `system` 用户 + `agent-gateway-audit.ts` 懒加载查真实 cuid。

---

### 5.5 发现 #5: agrisynapse env 文件与启动命令映射混乱

| 文件 | `BASE_URL` | 启动命令 |
|------|-----------|---------|
| `.env.local` | `{LOCAL_LAN_IP}:3000` | `pnpm dev` ✅ |
| `.env.dev` | `{REMOTE_SERVER_IP}:3000` | `pnpm dev-server` ❌ |

实际 curl 的 Referer 是 `localhost:8091`（本地），目标却是远程 IP（远端超时）。说明用错了启动命令。远端服务器未部署最新代码（无 proxy.ts），请求 10s 超时。

---

### 5.6 发现 #6: RAG 检索崩溃 + 专家链路缺陷 + 审计日志盲区（2026-06-09 增量）

用户提问“最近天气对玉米生长有什么影响？”时，RAG 检索环节因代码 crash 返回空数组，LLM 在无证据的情况下凭空生成回答。

#### 5.6.1 崩溃链路

```
用户提问 → intention 解析 intent=analysis, subIntents=["pest_risk"]
         → resolveSubIntentPlan 验证 pest_risk ∈ ANALYSIS_EXPERTS ✓
         → 但 activeExpertIds=[] ← 专家未被激活（见 §5.6.2）
         → retrieval: expertWhere = mergeExpertEvidenceFilters([]) = undefined
         → searchKnowledgeDocuments(query, 5, undefined, undefined)
         → knowledge-indexer.ts: where = undefined
         → JSON.stringify(undefined) === undefined（JS 值，非字符串）
         → undefined.slice(0, 60) → TypeError
         → catch 块吞掉异常，返回 []
         → RAG_SEARCH_FAIL 记录（但缺 stack trace）
         → RAG_EMPTY 误报“知识库无相关文档”（实际是代码 crash）
         → LLM 零证据凭空回答
```

**修复**（已完成）：`knowledge-indexer.ts` 第 209-210 行 `const where = rawWhere ?? {}`，保证 `where` 始终为对象；ChromaDB 查询改为条件 spread，空对象时不传 `where`。

#### 5.6.2 根因 #1: Plan 第4轮专家链路的 undefined 传播

Plan 第4轮（管线消费闭包）在 `retrieval.ts` 新增了 `expertWhere` 参数透传：

```typescript
// retrieval.ts — Plan 第4轮新增
const expertWhere = mergeExpertEvidenceFilters(activeExperts) // [] → undefined
searchKnowledgeDocuments(searchQuery, 5, undefined, expertWhere)
```

`mergeExpertEvidenceFilters` 在无激活专家时返回 `undefined`。Plan 设计时未考虑“无专家激活”这一正常路径——用户问题不匹配任何注册专家是**预期场景**，不是异常。

`knowledge-indexer.ts` 原有 debug 日志（`JSON.stringify(where).slice()`）本身有防御性缺陷，但之前从未被触发——因为之前调用时第3个参数总会传一个 `sourceType` 字符串，不会让 `where` 变成 `undefined`。**Plan 第4轮的改动是触发条件，`knowledge-indexer.ts` 的日志防御性不足是潜在隐患，两者叠加导致了这次故障。**

### 5.6.3 根因 #2: Plan 未规划专家注册扩展任务

`integration-plan-v1` 的 §一现状分析精确清点了工具层（23 个，含 3 个天气工具），但**完全未审计专家层**。Task 0-9 覆盖了 API 客户端、Store、仪表盘、SSE 流式、跨域认证、裁决层、凭证隔离——**无一个 Task 涉及 `ANALYSIS_EXPERTS` 扩展**。

当前专家注册表仅 3 个专家：

| ID | 领域 | 覆盖范围 |
|----|------|----------|
| `crop_compare` | 种植 | 作物对比、品种推荐 |
| `roi_analysis` | 经济 | 投入产出、成本核算 |
| `pest_risk` | 管收 | 病虫害风险 |

Plan 文件（多轮对话 plan-v1 第 734-737 行）已标注待扩展但**未纳入任何实施 plan**：

```typescript
// 后续按需扩展：
// soil_assessment: { ... }
// weather_impact: { ... }    ← "天气对玉米生长"类问题缺少对应专家
// policy_check: { ... }
```

farm-agent 的**工具层**已注册天气相关工具（`query_weather_realtime`、`query_weather_forecast`、`query_farm_weather`），但**专家层**缺失 `weather_impact`。工具解决"能不能拿到数据"，专家解决"拿到数据后怎么分析"——两者解耦但需配对使用。**Plan 只规划了工具→数据的通路，未规划数据→分析的闭环。**

架构已设计好扩展闭环：`{{EXPERT_DOMAIN_LIST}}` 由 `Object.keys(ANALYSIS_EXPERTS)` 动态生成，在 `registry.ts` 加一条记录即可被 intention prompt 自动感知，无需改 prompt 或路由代码。**实现成本极低（加一条记录），但 Plan 未将其作为 Task 或风险项登记。**

#### 5.6.4 根因 #3: 审计日志三重盲区

| 盲区 | 现象 | 后果 |
|------|------|------|
| `RAG_SEARCH_FAIL` 缺 stack trace | 只记了 `error.message`，无 `error.stack` | 运维无法定位崩溃位置（哪个文件、哪一行、调用链） |
| `RAG_EMPTY` 误报 | `searchKnowledgeDocuments` 崩溃返回 `[]`，retrieval 节点无法区分“真的空”和“crash 返回空” | 日志建议“请先同步知识库”——误导运维方向 |
| `retrieval` 节点标记成功 (✔) | `catch` 块吞掉异常后正常结束，审计记录 `✔ retrieval (45ms)` | 从审计日志看整条链路“一切正常”，实际上检索完全失败 |

**对标 Spring Boot**：`log.error("msg", e)` 默认带完整异常链 + stack trace，`HandlerExceptionResolver` 在全局兜底层自动记录。farm-agent 的 `agentAudit("RAG_SEARCH_FAIL", ...)` 只记 `error.message` 相当于 Spring Boot 里写 `log.error("查询失败: {}", e.getMessage())`——丢了最有价值的诊断信息。

**修复方向（平衡点分级）**：

| 级别 | 内容 | 性质 |
|------|------|------|
| **平衡点** | `RAG_SEARCH_FAIL` 补 `error.stack` 前3帧——一行日志定位崩溃位置，代码本身就是最好的上下文 | 必须做 |
| 平衡点之上 | retrieval 节点记 `activeExpertIds` + `expertWhere` 决策快照——加速上游根因定位。**业务层数据，走业务审计通道，不混入 L2** | 增强项，按需 |
| 超出平衡点 | `searchKnowledgeDocuments` 返回值区分正常空 vs 异常空 + `retrieval.ts` 据此记 `RAG_EMPTY` 或 `NODE_ERROR` | catch 块状态传递改造，应独立成 plan |

#### review2 为何遗漏

§0.2 第6项：Plan 变更影响链追踪缺失。review2 审查了 Plan 的设计决策（握手幂等性、认证简化），但未追踪 Plan 第4轮对已有代码（`knowledge-indexer.ts`）的**副作用**——新增参数透传路径上的 `undefined` 传播未被审查。

---

## 6. review 流程改进项

| 检查项 | 具体操作 | 触发时机 |
|--------|---------|---------|
| 跨仓库格式契约 | 列出所有 API 请求/响应类型，逐对验证发送方参数和接收方返回值 | 实现 review |
| 框架版本兼容性 | `cat package.json \| jq .dependencies.next`，查 breaking changes | 实现 review |
| 中间件变更生效 | 对比 `src/proxy.ts` 和 `.next/server/middleware.js` 的 mtime | 每次修改 proxy 后 |
| 数据模型约束 | 对 Prisma `create()` 的外键字段，验证被引用表中有对应记录 | 实现 review |
| 环境变量加载链 | 列出 `npm run` 命令 → `--mode` → `.env.*` → 每个 `VITE_*` 的值 | 环境变更时 |
| E2E curl 验证 | 用有效 hash 对每个端点 curl，检查 HTTP 状态码 + 响应格式 | 每次实现 review |
| 多 API 场景匹配 | 模块导出多个功能相似函数时（如 `runAgent` vs `streamAgent`），验证调用方选的是场景匹配的那个，不是随手复制 | 实现 review |
| Plan 变更影响链 | Plan 每轮新增参数透传时，追踪完整调用链上每个函数对 `undefined`/`null` 的防御性 | 设计 review + 实现 review |
| 审计日志可诊断性 | 验证 `catch` 块的审计事件包含 stack trace；区分“正常空结果”和“异常导致空结果” | 实现 review |

---

## 7. 决策结论（附录：已运行时修复项）

8. **Chat 格式兼容**：`sendChatStream` 增加 JSON→SSE 适配层，等待 farm-agent 正式支持 `text/event-stream`。
9. **Next.js 16 适配**：删除 `src/middleware.ts`，仅保留 `src/proxy.ts`。
10. **AuditLog 外键**：创建 `system` 用户，`agent-gateway-audit.ts` 改用真实 cuid。
11. **环境变量审计**：`.env.local` 指向 `{LOCAL_LAN_IP}:3000`，本地开发用 `pnpm dev`。

---

## 8. 后续跟进

本次 review 暴露的问题催生了两个 ADD 周期——从根因层面修复审查流程而非逐个修补：

```
review2 §5 运行时发现
│
├── §5.1 Chat 响应格式契约断裂（最严重）
│   └── 🔨 hash-route-sse-fix-plan ──→ handleChatPOST: runAgent → streamAgent
│
├── §5.2 Next.js 16 middleware.ts 废弃
│   └── ✅ 已在本 review 周期内修复（删除 middleware.ts，保留 proxy.ts）
│
├── §5.3 Middleware 热更新不生效
│   └── ✅ 环境问题，非代码缺陷（Turbopack 限制，切 webpack 规避）
│
├── §5.4 AuditLog 外键约束
│   └── ✅ review-and-evidence-hardening-plan ──→ userId 改用 ai-assistant / getSystemUserId()
│
├── §5.5 agrisynapse env 文件映射
│   └── ✅ 已在本 review 周期内修正（.env.local → .env.dev）
│
└── §5.6 RAG 检索崩溃 + 专家链路缺陷 + 审计盲区（2026-06-09 增量）
    ├── ✅ 代码修复：knowledge-indexer.ts where 防 undefined（已提交）
    ├── 🔨 rag-audit-stacktrace-plan ──→ 专家注册 + stack trace 平衡点 + 决策快照
    ├── 📋 rag-empty-distinction-plan ──→ RAG_EMPTY 状态传递改造（超出平衡点）
    └── 📋 专家扩展：weather_impact 已纳入 rag-audit-stacktrace-plan（根因消除）

审查基建加固（预防复发）
├── ✅ review-and-evidence-hardening-plan
│   ├── ADD-10 加强：checklist [T] 多 API 场景匹配 / 外键完整性 / env 加载链
│   └── ADD-11 边界证据站：appendRuntimeFinding() → 合约断裂自动落盘
│
├── 🔨 hash-route-sse-fix-plan
│   └── handleChatPOST SSE 流式化 → Content-Type: text/event-stream
│
├── 🔨 rag-audit-stacktrace-plan
│   ├── Task 1: weather_impact 专家注册（根因消除）
│   ├── Task 2: RAG_SEARCH_FAIL 补 stack trace 前3帧（平衡点）
│   └── Task 3: retrieval 决策快照（增强项，业务审计通道）
│
└── 📋 rag-empty-distinction-plan
    └── searchKnowledgeDocuments 状态传递改造 → RAG_EMPTY / NODE_ERROR 精确区分
```

### 审查基建（已完成 ✅）

→ **[farm-agent-review-and-evidence-hardening-plan-v1](../plans/farm-agent-review-and-evidence-hardening-plan-v1.md)**

该 plan 从两根柱子入手：
- **ADD-10 加强**：checklist [T] 项补多 API 场景匹配、外键完整性、env 加载链三组验证方法；review-implementation 模板加逐项对照步骤
- **ADD-11 边界证据站**：`appendRuntimeFinding()` 驻扎 proxy/route 最外层，跨系统合约断裂时自动落盘证据（法国人站台），不碰 L1/L2/业务 metadata

### §5.1 SSE 契约修复（🔨）

→ **[farm-agent-hash-route-sse-fix-plan-v1](../plans/farm-agent-hash-route-sse-fix-plan-v1.md)**

修复 `handleChatPOST` 中 `runAgent()` → `streamAgent()` 的错误，使 hash route 返回 `Content-Type: text/event-stream` 而非 `NextResponse.json()`。

### §5.6 RAG 检索崩溃 + 审计加固（🔨 2026-06-09 增量）

**已修复（代码层）**：`knowledge-indexer.ts` 的 `where` 参数 `undefined` 防御。

#### §5.6-a RAG 可靠性加固（🔨 审计 + 根因 + 专家注册）

→ **[farm-agent-rag-audit-stacktrace-plan-v1](../plans/farm-agent-rag-audit-stacktrace-plan-v1.md)**

崩溃链路回溯：无匹配专家 → `expertWhere=undefined` → 透传 → `JSON.stringify(undefined).slice()` crash。三个修复点覆盖链路三个环节：

1. **根因消除**：注册 `weather_impact` 专家——消除“无专家激活”这条触发路径，从源头避免 `expertWhere=undefined`
2. **平衡点（必须做）**：`RAG_SEARCH_FAIL` 补 `error.stack` 前3帧——stack trace 是诊断信息的平衡点，代码本身就是最好的上下文，一行日志即可从崩溃点追到上游传参链路
3. **增强项（按需）**：retrieval 节点记 `activeExpertIds` + `expertWhere` 决策快照——加速定位上游根因。**业务层决策数据，走业务审计通道，不混入 L2**

#### §5.6-b RAG_EMPTY 误报修复（📋 超出平衡点，独立 plan）

→ **[farm-agent-rag-empty-distinction-plan-v1](../plans/farm-agent-rag-empty-distinction-plan-v1.md)**

`searchKnowledgeDocuments` 返回值区分正常空 vs 异常空 + `retrieval.ts` 据此记 `RAG_EMPTY` 或 `NODE_ERROR`——与日志详细度无关，是 catch 块吞异常后的**状态传递改造**（改函数签名 + 调用方适配），工作量超出审计加固的平衡点。
