# farm-agent-nongqing-report-api-runtime-review-v1

> 运行时验证纠偏文档。触发方式：用户报告（生产服务器上 maturityDate 到期计划未自动完成 + 取消/删除计划路径缺失）。

## Review 元信息

- **关联 Plan**: [farm-agent-nongqing-report-api-plan-v1.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/22/farm-agent-nongqing-report-api-plan-v1.md)
- **关联实现 review**: 无
- **Review 时间**: 2026-06-25
- **触发方式**: 用户指令 — ssh rfai 检查 cron + PATCH 端点逻辑

---

## 问题优先级总览

| # | 严重度 | 标题 | Plan 回流位置 | 状态 |
|---|:---:|------|-------------|:---:|
| 1 | P0 | auto-complete cron 脚本写了但从未装到生产 crontab | §ADD-7 审计策略表（crontab 行） | ✅ 已修复 (2026-06-25) |
| 2 | P1 | PATCH plans/[id] 不支持 `cancelled` 状态 — 无法取消计划 | §3 端点设计 | ✅ 已修复 (2026-06-25) |
| 3 | P2 | Plan 审计表标记 crontab "✅ 已实施" 但实际未装 | §元信息 ADD-7 审计策略表 | ✅ 已修复 (2026-06-25) |

---

## 1. 发现列表

### F1 [P0] auto-complete cron 脚本写了但从未装到生产 crontab

**症状**：

生产服务器 (114.115.216.200) 上 crontab 只有数据库备份：
```
0 2 * * *   db-backup.sh
10 12 * * *  db-backup.sh
```

缺少计划自动完成调度：
```
30 2 * * *   auto-complete-plans.ts   ← 不存在！
```

**根因**：

[auto-complete-plans.ts](file:///home/xmm/ai/farm-agent/scripts/auto-complete-plans.ts) 脚本已写好（扫描 active 计划 + maturityDate 已过 → 标记 completed + 联动完成 pending 任务 + 释放地块），但 cron 行只写在脚本注释里：

```typescript
// crontab: 每天凌晨 02:30
//   30 2 * * * cd $HOME/farm-agent && tsx scripts/auto-complete-plans.ts >> ...
```

从未加入 [crontab.prod.txt](file:///home/xmm/ai/farm-agent/scripts/crontab.prod.txt)，也未通过 `crontab -e` 手动安装。[ensure-cron.sh](file:///home/xmm/ai/farm-agent/scripts/ensure-cron.sh) 只同步 `crontab.txt`（开发环境用），`crontab.prod.txt` 无自动安装机制。

**后果链**：

```
Plan 生成 → maturityDate 写入 ProductionPlan 表
  → 日期到达 → cron 不触发 → 计划永远是 active
  → 地块永远被绑定 → 新计划无法复用相同地块
  → 前端用户看不到计划自动完成
```

**与 Plan 审计表的矛盾**：

Plan 的 ADD-7 审计表 [第 36 行](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/22/farm-agent-nongqing-report-api-plan-v1.md#L36) 写：

> `crontab | INFRA | COMPONENT_UPDATED | 无计划自动完成调度 | 新增 30 2 * * * 定时执行 auto-complete-plans.ts | ✅ 已实施（2026-06-24）`

但 crontab.prod.txt 里根本没有这一行。

**修复方向**：

1. 在 [crontab.prod.txt](file:///home/xmm/ai/farm-agent/scripts/crontab.prod.txt) 追加：
   ```
   30 2 * * * cd $HOME/ai/farm-agent && npx tsx scripts/auto-complete-plans.ts >> $HOME/data/farm-agent-backups/cron-auto-complete.log 2>&1
   ```
2. 生产环境执行 `crontab scripts/crontab.prod.txt` 安装
3. SSH 到生产验证：`crontab -l | grep auto-complete`

---

### F2 [P1] PATCH plans/[id] 不支持 `cancelled` 状态 — 无法取消计划

**症状**：

用户无法主动取消一个不再需要的计划。API 只支持 `completed` 和 `active` 两种状态。

**根因**：

[PATCH plans/[id]](file:///home/xmm/ai/farm-agent/src/app/api/h5/production-plan/plans/[id]/route.ts#L45-L47) 的状态校验：

```typescript
if (status !== "completed" && status !== "active") {
  return NextResponse.json({ code: 400, message: "status 仅支持 completed 或 active" })
}
```

`ProductionPlan.status` 字段在 Prisma schema 中可能是 `active | completed` 枚举，没有 `cancelled` 值。这也意味着 DB migration 需要先加 `cancelled` 到枚举。

**后果**：

- 用户创建了计划但后来不需要了 → 无法取消 → 只能等 maturityDate 到期自动完成（但 F1 说明自动完成也不工作）
- 地块持续被绑定 → 无法创建新计划
- 唯一能绕过的是 PATCH 为 `completed`（但语义不对——计划并非真的完成）

**修复方向**：

1. Prisma schema `ProductionPlan.status` 枚举加 `cancelled`
2. PATCH 端点加 `cancelled` 分支：标记 cancelled + 联动取消所有 pending 任务 + 释放地块
3. 同名计划检查（generate 端点）跳过 cancelled 状态的计划
4. 地块冲突检查（generate 端点）跳过 cancelled 状态的计划

---

### F3 [P2] Plan 审计表标记 "✅ 已实施" 但实际 crontab 未装

**症状**：同 F1。Plan 文档的 ADD-7 审计表声称 crontab 变更已实施，但生产环境实际未装。

这是 ADD-12（双源头漂移）的典型案例：文档标记完成 ≠ 实际部署完成。

**修复方向**：

F1 修复后，将 Plan 审计表 crontab 行状态改为 `✅ 已装生产 (2026-06-25 runtime review 修复)`。

---

## 2. 影响面评估

| 影响范围 | 严重度 | 说明 |
|---------|:---:|------|
| 生产环境计划生命周期 | P0 | 到期计划永不自动完成，地块永久绑定 |
| 前端用户体验 | P0 | 无 "取消计划" 功能，只能等（但等也等不到） |
| Plan 文档可信度 | P2 | 审计表标记 "已实施" 但实际未装 — 文档漂移 |

---

## 3. 修复优先级

```
P0 立即修复:
  1. crontab.prod.txt 加 auto-complete 行 + 生产安装

P1 新 Plan（独立交付）:
  2. ProductionPlan 加 cancelled 状态 + PATCH 端点支持
  3. generate 端点跳过 cancelled 计划的冲突检查
```
