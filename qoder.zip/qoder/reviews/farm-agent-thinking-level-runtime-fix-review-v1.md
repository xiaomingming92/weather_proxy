# farm-agent-thinking-level-runtime-fix-plan-v1 Review

> Plan review。对 `farm-agent-thinking-level-runtime-fix-plan-v1.md` 的方案正确性、实施可行性与完整性做逐项审查。

## Review 元信息

- **Review 对象**: `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md`
- **触发来源**: `.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-runtime.md` 发现 #1
- **Review 范围**: Plan §一至§六 全部内容 + 目标代码基线（`thinking-level.ts`, `intention.ts`, `intention-async.ts`, `registry.ts`）
- **Review 时间**: 2026-07-04
- **Review 类型**: 方案正确性 + 实施可行性
- **代码基线**: 
  - `src/caijuehub/strategies/thinking-level.ts`（30 行，当前仅 fast/deep）
  - `src/agents/nodes/intention.ts`（349 行，4 处 `resolveThinkingLevel` 调用）
  - `src/agents/nodes/intention-async.ts`（189 行，3 处 `resolveThinkingLevel` 调用）
  - `src/agents/experts/registry.ts`（128 行，`ANALYSIS_EXPERTS`, `ExpertDomain`, `isSummary`）
- **结论级别**: **🔴 阻塞，修正后执行**

---

## 1. 正向评价

### 1.1 方案方向正确

`resolveThinkingLevel` 增加 `subIntents` 参数并基于跨域裁决的思路，是对 runtime-review 发现 #1 的精准修复。`getDomains()` 辅助函数将 `expertId → ExpertDomain` 映射 + 排除 `isSummary` 汇总专家的设计，语义清晰，与 ACA v3 Plan 的 ExpertDomain 体系一致。

### 1.2 原子事务边界清晰

两轮拆分（第1轮 A 规则确定性地解决 ≥3 域 → professional；第2轮 C 增强覆盖 =2 域）职责不重叠，第1轮零 LLM 成本，风险可控。

### 1.3 与上下游 Plan 的定位明确

§1.1a 明确了 professional 图当前是"串行赝品"、本 Plan 只修路由不修图拓扑，与 ACA v3 Plan 轮次 4 的 Send API fan-out 分工清晰。§1.1b 的 tasks.md 全量验收表也真实反映了 v3 的实现现状。

---

## 2. 问题清单

### 🔴 P0: §三代码与 §四验收标准矛盾（阻塞实施）

**问题描述**：

Plan §二标题写的是 `≥ 3 → professional`，但 §三 Task 1 代码示例（L267）写的是：

```typescript
if (domains.size >= 2) return "professional"
```

而 §四验收标准明确写道：

> `resolveThinkingLevel` 跨域 2 专家（pest_risk + variety_recommend）→ `"deep"`（C 覆盖区域）

**三方互相矛盾**：§二说 ≥3、代码写 ≥2、验收标准说跨域 2 应返回 deep。

**影响**：实施者无法确定应该用 `>= 2` 还是 `>= 3`。如果用 `>= 2`，（管+种）双域交叉也会触发 professional，但 professional 图是串行赝品（与 deep 图行为无区别），等于把本该在 deep 图跑的场景路由到一个未就绪的图里。如果用 `>= 3`，则当前仅 3 个活跃域（种/管/跨域）的情况下，只有"全活跃域全覆盖"才触发 professional——触发面极窄，与 runtime-review 发现 #1 的初衷（"水稻选种看看"→ 2 个子意图应触发 professional）不符。

**证据**：

| Plan 位置 | 内容 |
|-----------|------|
| §元信息 L15 | `第1轮：resolveThinkingLevel A 规则（跨域 ≥3 → professional）` |
| §二标题 L168 | `跨 ExpertDomain 的 subIntents（排除 isSummary 汇总专家）≥ 3 → professional` |
| §三代码 L267 | `if (domains.size >= 2) return "professional"` |
| §四验收 L289 | `跨域 2 专家（pest_risk + variety_recommend）→ "deep"（C 覆盖区域）` |

**修正建议**：

统一为 `>= 2`（对齐 runtime-review 原始意图 + 代码实现），并同步修正 §二标题、§元信息和 §四验收标准。理由：
1. runtime-review 发现 #1 的触发场景正是"水稻选种看看"→ crop_compare + variety_recommend（同"种"域，domains.size=1）——如果改为 ≥3，这个场景仍然不触发 professional，等于没修
2. 农业场景中 2 域交叉已有实质性冲突（Plan §2.1 论据表格已充分论证）
3. professional 图虽为串行赝品，但至少会走 `intentionAsyncNode` → Router 链路，验证 Router 模块的端到端可达性——这正是 runtime-review 的核心诉求

---

### 🔴 P0: intention.ts L271 会覆写 L223 的裁决结果（阻塞实施，即使上述矛盾解决后修复仍无效）

**问题描述**：

`intention.ts` 中共有 **4 处** `resolveThinkingLevel` 调用（不是 Plan 声称的 2 处）：

| 行号 | 位置 | 当前参数 | Plan 要求改动 |
|:--:|------|------|:--:|
| L147 | `explicitIntent` 快捷路径 | `(explicitIntent, explicitExpertId)` | 未提及 |
| **L223** | try 块 parse 成功后 | `(result.intent, explicitExpertId)` | **传 `result.subIntents`** |
| L267 | catch 块 fallback | `(parsed.intent, explicitExpertId)` | 未提及（合理，此时无 subIntents） |
| **L271** | try/catch 之后 | `(parsed.intent, explicitExpertId)` | **未提及 ❌** |

关键问题在 **L271**。代码执行流：

```
L223: resolveThinkingLevel(result.intent, explicitExpertId, result.subIntents)
      → 返回 "professional" ✅  (跨域 ≥2)

L271: resolveThinkingLevel(parsed.intent, explicitExpertId)
      → 返回 "deep" ❌          (没传 subIntents!)

L284: if (thinkingLevel === "professional" && ...) → FALSE
      expertPlan 永远不会被构建！
```

L271 使用 L271 的返回值**覆盖**了 L223 的 professional 裁决。即使 Plan 按 §三修改了 L223 传入 `subIntents`，**L271 不传 `subIntents` 会把 thinkingLevel 拉回 `"deep"`**，导致 L284 的 `expertPlan` 构建永不触发，professional 图仍走不到。

**同样的问题存在于 `intention-async.ts`**：

| 行号 | 位置 | 问题 |
|:--:|------|------|
| L82 | Embedding 命中（early return） | 未传 `subIntents`（`buildSubIntentsFromRouter` 已在 L81 产出） |
| L137 | try 块 LLM 成功后 | 未传 `result.subIntents` |
| **L160** | try/catch 之后 | 未传 `subIntents`，覆写 L137 的裁决 |

**修正建议**：

1. `intention.ts` L271 改为 `resolveThinkingLevel(parsed.intent, explicitExpertId, subIntents)`
2. `intention-async.ts` L82 改为 `resolveThinkingLevel("analysis", explicitExpertId, subIntents)`
3. `intention-async.ts` L137 改为 `resolveThinkingLevel(result.intent, explicitExpertId, result.subIntents)`
4. `intention-async.ts` L160 改为 `resolveThinkingLevel(parsed.intent, explicitExpertId, subIntents)`
5. Plan §三 Task 2-3 调用方更新表格应扩展为 **7 处**（含上述遗漏 + `explicitIntent` 路径明确标注"无需传"）

---

### 🟡 P1: intention-async.ts Embedding 命中路径（L82）未传 subIntents

**问题描述**：

`intention-async.ts` L80-103 的 Embedding 命中（tier=1）路径是 professional 图的最常见入口。L81 已经通过 `buildSubIntentsFromRouter(routerResult)` 产出了 `subIntents`，但 L82 调用 `resolveThinkingLevel` 时未传入：

```typescript
const subIntents = buildSubIntentsFromRouter(routerResult)  // L81
const thinkingLevel = resolveThinkingLevel("analysis", explicitExpertId)  // L82 ← 没传 subIntents
```

这导致 Router 的 Embedding 命中路径永远不会触发 professional 路由（`resolveThinkingLevel("analysis", null)` 永远返回 `"deep"`）。

**影响**：Router 模块（domain-vocabulary-v2 的核心交付物）的 Tier 1 路径仍然不可达。只有 LLM fallback（Tier 2）路径有机会触发 professional——前提是 P0 覆写 bug 已修复。

**修正建议**：L82 改为 `resolveThinkingLevel("analysis", explicitExpertId, subIntents)`，并同步更新 Plan §三 Task 3 表格（L281 行）。

---

### 🟡 P1: explicitIntent 快捷路径（intention.ts L147）是否需要传 subIntents 未讨论

**问题描述**：

`intention.ts` L146-173 的 `explicitIntent` 快捷路径（GUI 通过 Dashboard 契约传入明确意图）直接返回，不经过 LLM 意图解析。此路径调用 `resolveThinkingLevel(explicitIntent, explicitExpertId)` 未传 subIntents。

Plan 对此路径只字未提。当前行为是：GUI 点击技能卡片（如"品种推荐"）→ `explicitExpertId="variety_recommend"` → `resolveThinkingLevel` 返回 `"deep"`。行为正确且不应改变。但 Plan 应明确标注此路径"无需传 subIntents"及原因（GUI 直连专家本身就是单专家 deep 管线）。

**修正建议**：Plan §三 Task 2 表格中补充 L147 行，标注"无需传 subIntents——GUI 直连专家走 deep 管线"。

---

### 🟡 P1: 缺少对 `getDomains` 纯函数的单测覆盖要求

**问题描述**：

Plan §四验收标准仅包含 `tsc + eslint + vitest` 三检，但未定义 `getDomains` 函数的具体测试用例。该函数是本次修改的核心新增逻辑，涉及：
- expertId → ExpertDomain 映射
- isSummary 专家过滤
- 无效 expertId 的防御性处理

**修正建议**：§四验收标准增加以下单测场景：
- [ ] `getDomains([crop_compare, variety_recommend])` → `Set{"种"}`（同域去重）
- [ ] `getDomains([pest_risk, variety_recommend, roi_analysis])` → `Set{"管","种","跨域"}`（跨域）
- [ ] `getDomains([pest_risk, weather_impact, daily_report])` → `Set{"管"}`（排除 isSummary）
- [ ] `getDomains([{ domain: "nonexistent" }])` → `Set{}`（无效 expertId 不掉级）

---

### 🟢 P2: `subIntents[].domain` 字段语义歧义

**问题描述**：

`SubIntent` 类型的 JSDoc 明确写 `domain` 是 "子意图域标识，等于 ANALYSIS_EXPERTS 注册表的 key"，即它是 **expertId**（如 `"crop_compare"`），不是 **ExpertDomain**（如 `"种"`）。Plan §三 `resolveThinkingLevel` 签名中用 `subIntents?: Array<{ domain: string }>` 作为参数类型，而内部 `getDomains` 函数通过 `ANALYSIS_EXPERTS[si.domain]?.domain` 做了一层 expertId → ExpertDomain 的映射。

这在语义上是正确的，但参数命名 `domain`（实际是 expertId）与函数内部变量 `domains`（实际是 `Set<ExpertDomain>`）容易造成混淆。Plan §1.2 领域分类表中也混用了两种语义（表头写"领域"但内容是 expertId）。

**修正建议**：在 `resolveThinkingLevel` 的 JSDoc 中加一行注释说明 `subIntents[].domain` 实际为 expertId，`getDomains` 负责映射为 ExpertDomain。非阻塞。

---

### 🟢 P2: `llmSuggestedLevel` 参数在第1轮为预留死参数

**问题描述**：

Plan 在第1轮引入了 `llmSuggestedLevel?: string` 参数，但所有调用方在第1轮都不会传它（值为 `undefined`）。`resolveThinkingLevel` 内部的 `if (llmSuggestedLevel === "professional")` 分支在第1轮永远不会触发。

这不是 bug——预留参数是合理的向前兼容设计。但 Plan 未明确标注"此参数在第1轮恒为 undefined，仅为第2轮预留"。实施者可能困惑是否需要在第1轮构造 LLM prompt 产出。

**修正建议**：§三 Task 1 代码块中加注释 `// llmSuggestedLevel: 第2轮启用，第1轮恒为 undefined`。

---

### 🟢 P2: `resolveSubIntentPlan` 过滤后的 subIntents 不一致

**问题描述**：

`intention.ts` 中 `resolveSubIntentPlan(subIntents, ...)` 会过滤掉未注册的 expertId，但传给 `resolveThinkingLevel` 的是原始的 `result.subIntents`（含可能被过滤掉的无效项）。这不是 bug——`getDomains` 内部也会通过 `ANALYSIS_EXPERTS[si.domain]?.domain` 做同样的过滤（`.filter((d): d is ExpertDomain => !!d)`），行为一致。

但逻辑上存在一次重复的无效过滤（先 `resolveSubIntentPlan` 过滤一次，再 `getDomains` 过滤一次）。非阻塞，只是代码味道。

---

## 3. 调用方全量矩阵

Plan §三 Task 2-3 的调用方更新表格不完整。以下是代码基线中的全量调用点及修正后应使用的参数：

### intention.ts（4 处调用）

| 行号 | 场景 | 当前 | 修正后 | 说明 |
|:--:|------|------|------|------|
| L147 | `explicitIntent` 快捷路径 | `(explicitIntent, explicitExpertId)` | 不变 | GUI 直连专家走 deep，无需 subIntents |
| L223 | try 块 parse 成功 | `(result.intent, explicitExpertId)` | `(result.intent, explicitExpertId, result.subIntents)` | Plan 已覆盖 |
| L267 | catch 块 fallback | `(parsed.intent, explicitExpertId)` | 不变 | 无有效 subIntents |
| **L271** | try/catch 之后 | `(parsed.intent, explicitExpertId)` | `(parsed.intent, explicitExpertId, subIntents)` | **Plan 遗漏** |

### intention-async.ts（3 处调用 + 1 处潜在入口）

| 行号 | 场景 | 当前 | 修正后 | 说明 |
|:--:|------|------|------|------|
| **L82** | Embedding 命中（tier=1） | `("analysis", explicitExpertId)` | `("analysis", explicitExpertId, subIntents)` | **Plan 遗漏**——subIntents 已在 L81 产出 |
| L137 | try 块 LLM 成功 | `(result.intent, explicitExpertId)` | `(result.intent, explicitExpertId, result.subIntents)` | Plan 已覆盖 |
| **L160** | try/catch 之后 | `(parsed.intent, explicitExpertId)` | `(parsed.intent, explicitExpertId, subIntents)` | **Plan 遗漏**——覆写 L137 |

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 操作 | 影响范围 |
|------|:--:|------|
| `src/caijuehub/strategies/thinking-level.ts` | 修改 | 新增 `getDomains` + 扩展 `resolveThinkingLevel` 签名 |
| `src/agents/nodes/intention.ts` | 修改 | L223 + L271 传 `subIntents` |
| `src/agents/nodes/intention-async.ts` | 修改 | L82 + L137 + L160 传 `subIntents` |

### 4.2 回滚风险

- **低**：仅修改 3 个文件，`resolveThinkingLevel` 新增参数为可选（`subIntents?`），不传时行为与当前完全一致
- **deep 图保护**：`explicitExpertId` 路径不传 `subIntents`，行为不变；`chat` intent 优先返回 `"fast"`，不进入跨域裁决

---

## 5. 最终建议

### 5.1 修正顺序（推荐）

```
1. 解决 §二/§三/§四 矛盾 → 统一为 domains.size >= 2
2. 修正 intention.ts L271 + intention-async.ts L160+L82 覆写问题
3. 补充 getDomains 单测场景
4. 更新 Plan §三 Task 2-3 表格为全量 7 处（含 explicitIntent 标注）
5. 标注 llmSuggestedLevel 为第2轮预留
```

### 5.2 修正后验收标准（完整版）

- [ ] `resolveThinkingLevel` 同域 2 专家（crop_compare + variety_recommend）→ `"deep"`
- [ ] `resolveThinkingLevel` 跨域 2 专家（pest_risk + variety_recommend）→ `"professional"`
- [ ] `resolveThinkingLevel` 跨域 3 专家（pest_risk + variety_recommend + roi_analysis）→ `"professional"`
- [ ] `resolveThinkingLevel` 含汇总专家（pest + weather + daily_report）→ 排除 daily_report 后 `Set{"管"}` size=1 → `"deep"`
- [ ] `resolveThinkingLevel` 单 expert → `"deep"`
- [ ] `resolveThinkingLevel` chat → `"fast"`
- [ ] `resolveThinkingLevel` explicitExpertId 存在 → `"deep"`
- [ ] 不传 `subIntents` → 行为与当前一致（向后兼容）
- [ ] `intention.ts` L271 传 `subIntents`，不再覆写 L223 的裁决
- [ ] `intention-async.ts` L82 传 `subIntents`（Embedding 命中路径）
- [ ] `intention-async.ts` L160 传 `subIntents`，不再覆写 L137 的裁决
- [ ] `getDomains` 纯函数单测通过（同域去重 / 排除 isSummary / 无效 expertId 防御）
- [ ] `npx tsc --noEmit` 零错误
- [ ] `npx eslint src/` 零 error
- [ ] 现有 deep 图不受影响

---

## 6. 回流确认

- [ ] P0 问题（代码/验收矛盾 + 覆写 bug）已回流至 Plan
- [ ] P1 问题（调用方矩阵不完整 + 单测缺失）已回流至 Plan
- [ ] Plan §三 Task 2-3 表格已更新为全量 7 处
- [ ] Plan §四验收标准已对齐修正后的实现
