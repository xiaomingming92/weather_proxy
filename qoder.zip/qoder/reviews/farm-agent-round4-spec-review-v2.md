# evidenceFilter 类型设计 Review v2：业务语义抽象 vs. 向量引擎原语

## Review 元信息

- **Review 对象**: `AnalysisExpert.evidenceFilter` 的类型设计
- **对比方案**:
  - **方案 A（old）**: 业务语义抽象类型 — `{ keywords?: string[]; sourceTypes?: EvidenceSource[] }`
  - **方案 B（new）**: ChromaDB `where` 语法原语 — `Record<string, unknown>` → `{ cateId: { $in: [...] } }`
- **Review 时间**: 2026-05-26
- **Review 类型**: 架构决策深度对比
- **前置阅读**: `farm-agent-round4-spec-review.md` (初版 Review), `co-agent-conversation-handoff.md` (第4轮 handoff)

---

## 1. 问题复现：为什么需要这次对比

第3轮实现了 `ExpertEvidenceFilter` 业务语义类型。第4轮要让它被管线节点消费时，发现它无法直接用于 ChromaDB 向量检索。

根因不在"值域不匹配"，而在**两个方案处于不同的抽象层次**。方案 A 在业务语义层，方案 B 在存储引擎层。第4轮的 question 是：管线节点应该工作在哪个层次？

---

## 2. 方案 A：业务语义抽象类型

### 2.1 定义

```typescript
// 方案 A
type EvidenceSource =
  | "植保情报" | "市场行情" | "经济数据" | "农技信息"
  | "种植技术" | "品种选育" | "土壤评估"
  | ... // 共 11 种

interface ExpertEvidenceFilter {
  keywords?: string[]           // 关键词列表，增强查询字符串
  sourceTypes?: EvidenceSource[] // 来源类型白名单
}

// 专家使用
evidenceFilter: {
  keywords: ["水稻纹枯病", "稻瘟病"],
  sourceTypes: ["植保情报", "农技信息"],
}
```

### 2.2 数据流

```
EvidenceFilter (business semantics)
        │
        ▼
┌─────────────────────────────┐
│  translation layer (必要)    │
│  sourceTypes → WHERE 子句    │
│   keywords  → query 拼接     │
└─────────────────────────────┘
        │
        ▼
    ChromaDB WHERE (engine primitive)
```

### 2.3 方案 A 的优点

| 优点 | 说明 |
|------|------|
| **业务可读** | `sourceTypes: ["植保情报"]` 比 `{ cateId: { $in: ["plant_protection"] } }` 直观 |
| **类型安全** | TypeScript 对 `EvidenceSource` 11 个值做编译时穷举检查 |
| **与 ChromaDB 解耦** | 换 Milvus/Weaviate 时只需改翻译层 |

### 2.4 方案 A 的核心问题

#### 2.4.1 翻译层是必要条件，不是可选项

方案 A 必然需要一个翻译层把业务语义转成 ChromaDB 的 `where` 子句。这个翻译层面临三个不可回避的问题：

**问题 1：1:N 映射导致语义膨胀**。一个 `EvidenceSource` 值"植保情报"可能映射到多个 ChromaDB `cateId`（`plant_protection` + `agri_tech` 的子集）。翻译层需要维护一个高耦合的枚举映射表，每次新增分类都要改两处（Prisma KnowledgeCate + 翻译层映射）。

**问题 2：keywords 的查询语义不确定**。`keywords: ["水稻纹枯病"]` 的含义是什么？是拼接到用户的自然语言 query 字符串中？（"query + 水稻纹枯病"）还是作为 ChromaDB metadata 的 text filter？方案 A 没有定义这一点，留给实现者自由发挥，不同专家的 keywords 可能产生不同的查询语义。

**问题 3：类型安全是假象**。`EvidenceSource` 有 11 个值，TypeScript 确实能做编译时检查。但 ChromaDB 实际按 `cateId` 过滤，而不是按"植保情报"这个中文标签。如果翻译层没有正确映射，类型检查通过但运行时 0 结果，编译器不会报错。

#### 2.4.2 扩展性受限于枚举

```
新增分类？ → 加 EvidenceSource 枚举值 → 改翻译层 → 加 KnowledgeCate 行
专家新增过滤维度？ → 改 ExpertEvidenceFilter 接口 → 改翻译层
换向量引擎？ → 改翻译层（这是唯一的正面）
```

每次业务扩展都需要改动类型定义 + 翻译层 + 数据库。三个变更点的耦合降低了扩展速度，而分类体系的变更是高频事件。

---

## 3. 方案 B：ChromaDB where 语法原语

### 3.1 定义

```typescript
// 方案 B
type AnalysisExpertEvidenceFilter = Record<string, unknown>

// 专家使用（ChromaDB where 子句原语）
evidenceFilter: {
  cateId: { $in: ["plant_protection", "agri_tech"] },
}

// 管线节点消费
const where = mergeExpertEvidenceFilters(activeExperts)
// → { cateId: { $in: ["plant_protection", "agri_tech", ...] } }
searchKnowledgeDocuments(query, k, undefined, where)
```

### 3.2 数据流

```
ChromaDB WHERE (engine primitive)
        │
        ▼
    searchKnowledgeDocuments(query, k, undefined, where)
        │
        ▼
    chromaClient.query({ query_embeddings, n_results, where, ... })
```

**无翻译层**。专家直接持有 ChromaDB 能消费的原语。

### 3.3 方案 B 的"缺点"及反驳

| 常被提到的"缺点" | 反驳 |
|-----------------|------|
| `cateId: { $in: [...] }` 不直观，没有业务语义 | `$in` 是 ChromaDB 官方语法，开发者学习一次终身通用。`cateId` 值本身来自 `KnowledgeCate` 受控词表，可以在注册表注释中标注中文映射："plant_protection → 植保情报" |
| 与 ChromaDB 强耦合 | ChromaDB 是向量检索引擎，`where` 是它的原生能力。在任何向量引擎（Milvus/Weaviate/Pinecone）都有等价的 filter 语法（`expr: "cate_id in [...]"` / `filter: { property: "cateId", operator: "Equal", value: ... }`）。**语法不同，但抽象层次相同——都是引擎原语** |
| 换引擎时要改所有专家的 evidenceFilter | 换引擎时整个 knowledge-indexer 层要重写（`add`/`query`/`delete`），改动量远大于 evidenceFilter 的值替换。且 evidenceFilter 改的是值（`$in` → `expr`），不是类型 |

### 3.4 方案 B 的真实优点

| 优点 | 说明 |
|------|------|
| **零翻译层** | 管线节点拿到 `where` 后直接透传，不需要任何中间转换 |
| **与 ChromaDB 协议一致** | `where` 的语义由 ChromaDB 定义（`$in`/`$eq`/`$gt`/`$and`/`$or`），不是自创的 DTO |
| **扩展零成本** | 新增 `KnowledgeCate` 分类 → 更新专家 `evidenceFilter` 的 `$in` 数组 → 完成。不需要改任何类型定义和翻译逻辑 |
| **可测试性强** | 可以直接把 `evidenceFilter` 值传给 `chromaClient.query()` 测试，不需要 mock 翻译层 |
| **过滤器可组合** | 多专家的 `$in` 数组取并集去重是纯粹的集合操作，不涉及业务语义映射 |

---

## 4. 关键差异对比表

| 维度 | 方案 A（业务语义抽象） | 方案 B（引擎原语） |
|------|----------------------|-------------------|
| **抽象层次** | 业务语义层（需翻译） | 引擎原语层（零翻译） |
| **类型定义** | `{ keywords?, sourceTypes: EvidenceSource[] }` | `Record<string, unknown>` |
| **类型安全** | 编译时检查（11 值枚举） | 运行时由 ChromaDB 校验 |
| **数据流节点数** | 3（专家 → 翻译层 → ChromaDB） | 2（专家 → ChromaDB） |
| **新增分类成本** | 枚举值 + 翻译层映射 + KnowledgeCate 行 | KnowledgeCate 行 + evidenceFilter $in 数组 |
| **多专家合并逻辑** | keywords 语义不确定 + sourceTypes 需要翻译后才能合并 | 纯集合操作：`$in` 取并集去重 |
| **向量引擎迁移** | 改翻译层（少量代码） | 改 evidenceFilter 值（语法不同）+ knowledge-indexer 层（大量代码） |
| **可测试性** | 需 mock 翻译层 | 直接透传，零 mock |
| **降级路径** | 翻译层失败 → 两处错误处理 | 无翻译层 → ChromaDB 过滤失败自然触发降级 |

---

## 5. 决定性的论据：降级逻辑的实现差异

降级逻辑在第4轮是必需的（ChromaDB 文档可能尚未关联 `knowledgeCateId`）。对比两方案如何实现降级：

### 方案 A 的降级逻辑

```typescript
// 1. 翻译层把 business filter → ChromaDB where
const chromaWhere = translateFilter(expertFilter)
// 2. 用 where 检索
let results = await search(query, k, chromaWhere)
// 3. 0 结果？
if (results.length === 0) {
  // 4. 降级：无过滤检索
  results = await search(query, k, undefined)
  audit("RAG_EXPERT_FILTER_EMPTY", {
    appliedFilter: JSON.stringify(expertFilter),   // ← 业务语义
    appliedWhere: JSON.stringify(chromaWhere),     // ← 引擎原语
    // 审计中必须记录两套数据，否则排查时不知道"翻译后的 where 是什么"
  })
}
// 5. 审计结论要同时解释两套语义，增加排查负担
```

### 方案 B 的降级逻辑

```typescript
// 1. 直接合并 evidenceFilter（无翻译）
const where = mergeExpertEvidenceFilters(activeExperts)
// 2. 用 where 检索
let results = await search(query, k, where)
// 3. 0 结果？
if (results.length === 0 && where !== undefined) {
  // 4. 降级：无过滤检索
  results = await search(query, k, undefined)
  audit("RAG_EXPERT_FILTER_EMPTY", {
    appliedWhere: JSON.stringify(where),  // ← 唯一表述，排查时一目了然
  })
}
```

方案 B 的降级路径少了一层翻译，审计日志中 `appliedWhere` 直接就是 ChromaDB 收到的查询原语，排查问题时不需要反推中间层的转换逻辑。

---

## 6. 方案 B 的类型安全替代方案

`Record<string, unknown>` 确实丢失了编译时类型检查。但方案 A 的 `EvidenceSource` 枚举是**虚假的类型安全**——编译通过 ≠ 运行时命中。

替代：在 registry.ts 注释标注映射关系，保持可追溯性：

```typescript
pest_risk: {
  evidenceFilter: {
    // ChromaDB where 原语，cateId 映射:
    //   plant_protection → "植保情报" (KnowledgeCate)
    //   agri_tech         → "农技信息" (KnowledgeCate)
    cateId: { $in: ["plant_protection", "agri_tech"] },
  },
  // ...
}
```

这比方案 A 的枚举映射表更容易维护：**当值与 KnowledgeCate 受控词表的 label 不一致时，注释就能揭示映射关系**，不需要在翻译层代码中追踪另一套枚举到 ID 的对应。

---

## 7. 为什么方案 B 是正确选择

### 7.1 根本原因：ChromaDB 是这个上下文中的"可靠抽象"

方案 A 的假设是：ChromaDB 的 `where` 语法不够好，需要在上面包一层。但事实是：

1. ChromaDB `where` 语法本身就是为**元数据过滤**设计的，语义清晰、文档齐全
2. `{ cateId: { $in: ["plant_protection"] } }` 的语义一目了然：过滤 `cateId` 字段值为 `["plant_protection"]` 内任意值的文档
3. 任何会用 ChromaDB 的开发者都能读懂这个表达式，不需要学习你的翻译层 DSL

### 7.2 次要原因：减少代码就是减少 bug 面

方案 A 需要额外的翻译层代码（至少 1 个文件 + 1 个映射表）。每多一个中间层，就多一个 bug 可能发生的地方。

方案 B 零新增文件，只在现有类型上改一行（`ExpertEvidenceFilter` → `Record<string, unknown>`），改动面是方案 A 的 1/3。

### 7.3 边界原因：PostgreSQL 已是单一真相源

`KnowledgeCate` 在 PostgreSQL 中管理，`Document` 引用它（`knowledgeCateId`），索引时投影到 ChromaDB metadata。换向量引擎时：

- `knowledge-indexer.ts` 的 `add()`/`query()` 调用要改写（这是必然的）
- `evidenceFilter` 的语法要改写（`$in` → Milvus 的 `expr` 语法）
- 但不影响 KnowledgeCate 本身、不影响 Document 的引用关系

方案 A 的翻译层在换引擎时确实"只改一处"，但这一处的改动量和方案 B 改 evidenceFilter 值的改动量相当。方案 A 没有显著降低迁移成本。

---

## 8. 结论

**方案 B（ChromaDB where 语法原语）优于方案 A（业务语义抽象类型）**。

三个决定性理由：

1. **零翻译层**：管线节点拿到 `where` 直接透传，降级逻辑简单可靠，审计日志可追溯
2. **扩展零成本**：新增分类只改 KnowledgeCate 表 + evidenceFilter 值，不动类型系统
3. **语义不存在歧义**：`{ cateId: { $in: [...] } }` 的语义由 ChromaDB 官方文档定义，不依赖自创的翻译层 DSL

方案 A 的"业务可读性"和"类型安全"优势在本次上下文（向量引擎元数据过滤）中权重很低：
- 业务可读性 → 用 registry 注释标注 cateId → label 映射即可
- 类型安全 → `EvidenceSource` 枚举是编译通过 ≠ 运行时命中的假安全

---

## 附录：第3轮为何实现了方案 A

第3轮的 spec（co-agent-simplified-v1.md）定义 evidenceFilter 为 `Record<string, unknown>`（父 Plan L676）。但第3轮实现时，`KnowledgeCate` 表尚未创建，`Document` 也没有 `knowledgeCateId` 字段。开发者在没有受控词表的情况下，自然地创建了一个业务语义枚举来表达"按什么维度过滤"的意图。

这不是错误——第3轮的职责是建立分析专家注册表和 AnalysisContext CRUD，不是让 evidenceFilter 可工作。第4轮创建受控词表后，evidenceFilter 的抽象层次自然应该从业务语义收敛到引擎原语。这是迭代开发的正常演进。

---

## 9. [2026-05-26 追加] 规模化场景：3→N 个专家时的类型演进路径

> **前置问题**：当专家从 3 个扩展到几十个时，`Record<string, unknown>` 的无约束性会成为风险源。本节在 A/B 两方案之外探索中间态。

### 9.1 问题空间：三个轴

| 轴 | 一端 | 另一端 |
|---|------|--------|
| **类型安全** | 编译时穷举检查（方案 A） | 运行时校验（方案 B） |
| **可读性** | 中文业务语义（方案 A） | 引擎语法原语（方案 B） |
| **扩展性** | 改枚举+改映射（方案 A） | 只改值不改类型（方案 B） |

方案 A 和 B 占据两个极端。几十个专家的场景需要一个中间态——既不回到翻译层的泥潭，也不放任 `Record<string, unknown>` 到处散落。

### 9.2 方案 C：ChromaDB Where 受限类型（Typed Primitive）

#### 9.2.1 核心思想

不用完整 `Record<string, unknown>`，而是把 ChromaDB `where` 语法的 **实际使用子集** 提炼为 TypeScript 类型：

```typescript
// 方案 C — ChromaDB where 受限类型

type ChromaValue = string | number | boolean

type ChromaOperator =
  | { $eq: ChromaValue }
  | { $ne: ChromaValue }
  | { $in: ChromaValue[] }
  | { $nin: ChromaValue[] }
  | { $gt: ChromaValue }
  | { $gte: ChromaValue }
  | { $lt: ChromaValue }
  | { $lte: ChromaValue }

type ChromaWhereField = { [field: string]: ChromaOperator }

type ChromaWhereClause =
  | ChromaWhereField                          // 字段条件: { cateId: { $in: [...] } }
  | { $and: ChromaWhereExpression[] }         // 组合 AND
  | { $or: ChromaWhereExpression[] }          // 组合 OR

type ChromaWhereExpression = ChromaWhereClause

interface AnalysisExpert {
  // ...
  evidenceFilter?: ChromaWhereExpression     // ← 受限类型，不是 Record<string, unknown>
}
```

#### 9.2.2 使用方式（和方案 B 完全一样）

```typescript
pest_risk: {
  evidenceFilter: {
    cateId: { $in: ["plant_protection", "agri_tech"] },
  },
},

soil_assessment: {
  evidenceFilter: {
    $and: [
      { cateId: { $in: ["planting_technique", "soil_assess"] } },
      { tags: { $in: ["土壤", "肥力"] } },
    ],
  },
},
```

#### 9.2.3 关键优势：IDE 自动补全

这是方案 C 在"几十个专家"场景下的核心价值：

```typescript
// 方案 B — 写的时候完全靠记忆或查文档（无 IDE 提示）
evidenceFilter: {
  cateId: { $in: ["..."] },   // $in 拼对了没？字段名 cateId 还是 category？
}

// 方案 C — IDE 会告诉你所有合法选项
evidenceFilter: {
  c  // → IDE 提示: cateId / tags / fileName / sourceType ...
     // → 选 cateId 后:
     // → IDE 提示: $eq / $ne / $in / $nin / $gt / $gte / $lt / $lte
        // → 选 $in 后:
        // → IDE 要求填入 string[]
}
```

当有几十个专家在维护时，**新人加入团队后不需要先学一遍 ChromaDB where 文法**——类型本身就是文档。

#### 9.2.4 与方案 A/B 对比

| 维度 | 方案 A (枚举) | 方案 B (`Record`) | **方案 C (受限类型)** |
|------|-------------|------------------|---------------------|
| **类型安全** | ✅ 编译时穷举 | ❌ 完全无约束 | ⚠️ shape 约束 + value 自由 |
| **翻译层** | ❌ 必须有 | ✅ 零 | ✅ 零 |
| **可组合性** | ❌ 需要改接口 | ✅ 天然支持 `$and`/`$or` | ✅ 天然支持 |
| **新增字段成本** | 改枚举+改翻译 | 只改值 | 只改值 |
| **IDE 支持** | 枚举自动补全 | 无补全 | **结构体自动补全** |

#### 9.2.5 向量引擎平滑迁移考量（ChromaDB → Milvus）

方案 C 的 `ChromaWhereExpression` 类型名称虽然带"Chroma"，但**它不是 ChromaDB 耦合类型——它是一套向量引擎过滤 AST**。换引擎时不需要推翻这套类型，只需扩展。

##### 操作符映射表

ChromaDB、Milvus、Weaviate、Pinecone 的过滤操作符语义同构，语法不同：

| 过滤语义 | ChromaDB | Milvus | Weaviate | Pinecone |
|---------|----------|--------|----------|----------|
| 等值匹配 | `{ $eq: v }` | `expr: "field == v"` | `{ operator: Equal, value: v }` | `{ $eq: v }` |
| 包含匹配 | `{ $in: [...] }` | `expr: "field in [...]"` | `{ operator: ContainsAny, ... }` | `{ $in: [...] }` |
| 逻辑与 | `{ $and: [...] }` | `expr: "(...) and (...)"` | `{ operator: And, operands: [...] }` | `{ $and: [...] }` |
| 逻辑或 | `{ $or: [...] }` | `expr: "(...) or (...)"` | `{ operator: Or, operands: [...] }` | `{ $or: [...] }` |

关键洞察：**语义同构，语法不同**。方案 C 的类型定义表达的是过滤 AST 的**结构**（字段条件 + $and/$or 嵌套），而不是 ChromaDB 特有的语法。

##### 迁移时的变更范围

```
迁移 ChromaDB → Milvus 时：

✅ 不变的：
  - analysisExpert.evidenceFilter 的值（cateId $in 数组）
  - mergeExpertEvidenceFilters() 合并逻辑（纯集合操作）
  - retrieval.ts 中的管线调用路径
  - 15+ 个 expert 的 evidenceFilter 声明

⚠️ 只需改一处：
  - 在 ChromaWhereExpression 类型定义文件中新增 MilvusExpr 类型

⚠️ 必然要改（与 evidenceFilter 类型无关）：
  - knowledge-indexer.ts 的 add()/query() 调用（换 SDK）
  - searchKnowledgeDocuments 的 where 参数格式
```

##### 迁移时的类型演进

```typescript
// ─── 迁移前（当前）────────────────────────────────
type EngineFilter = ChromaWhereExpression

interface AnalysisExpert {
  evidenceFilter?: EngineFilter
}

// ─── 迁移时（切换到 Milvus）───────────────────────
type MilvusExpr = string  // Milvus 用表达式字符串: "cateId in [...]"

type EngineFilter = ChromaWhereExpression | MilvusExpr

// mergeExpertEvidenceFilters 需要加引擎判断分支：
function mergeExpertEvidenceFilters(
  activeExperts: Array<{ expertId: string }>,
): EngineFilter | undefined {
  // 根据当前引擎类型分发到 ChromaDB 或 Milvus 的合并逻辑
}

// ─── 迁移完成后（ChromaDB 下线）────────────────────
type EngineFilter = MilvusExpr
// 删除 ChromaWhereExpression 类型定义即可。
// 15+ 个 expert 的 evidenceFilter 值写法不变，
// 只需通过运行时函数将 ChromaWhere AST 转为 Milvus expr 字符串。
```

##### 为什么不预先做成 `EngineFilter` 联合类型

当前只有一个引擎（ChromaDB），预先做 `ChromaWhereExpression | MilvusExpr` 联合类型是**虚假的抽象**——没有第二个引擎实例，无法验证 Milvus 分支的正确性。等到真正要换引擎时，Milvus SDK、表达式语法、索引方式都是已知的具体约束，届时再做联合类型扩展是水到渠成的。

当前只需保证：`ChromaWhereExpression` 是一个**独立的、可被替换的**类型定义文件，不被业务代码直接 import 到不可替换的位置。

### 9.3 方案 D：过滤模板注册表（Template Registry）

#### 9.3.1 核心思想

观察到：**几十个专家的 evidenceFilter 大多是少数几种模式的参数化实例**。先定义模板，再引用：

```typescript
// 方案 D — 先定义模板，再引用

type FilterTemplateId =
  | "by_category"           // 按 KnowledgeCate 分类过滤
  | "by_category_and_tag"   // 分类 + 标签组合
  | "by_time_range"         // 按时间范围
  | by_source_type          // 按来源类型

interface FilterTemplateParams {
  by_category: { categories: string[] }
  by_category_and_tag: { categories: string[]; tags: string[] }
  by_time_range: { after?: string; before?: string }
  by_source_type: { sources: string[] }
}

interface AnalysisExpert {
  evidenceFilter?:
    | { template: FilterTemplateId; params: object }   // 引用模板
    | ChromaWhereExpression                            // 或直接写原语（兜底）
}
```

#### 9.3.2 使用方式

```typescript
// 简单场景 — 引用模板（大多数专家）
crop_compare: {
  evidenceFilter: {
    template: "by_category",
    params: { categories: ["planting_technique"] },
  },
},

pest_risk: {
  evidenceFilter: {
    template: "by_category",
    params: { categories: ["plant_protection", "agri_tech"] },
  },
},

// 复杂场景 — 直接写原语（极少数专家）
custom_analyzer: {
  evidenceFilter: {
    $and: [
      { cateId: { $in: ["planting_technique"] } },
      { tags: { $in: ["水稻", "病害"] } },
      { createdAt: { $gte: "2026-01-01" } },
    ],
  },
},
```

#### 9.3.3 运行时解析（与方案 A 翻译层的本质区别）

```typescript
function resolveEvidenceFilter(
  filter?: { template: string; params: object } | ChromaWhereExpression
): ChromaWhereExpression | undefined {
  if (!filter) return undefined
  if ("template" in filter) {
    return renderFilterTemplate(filter.template, filter.params)
  }
  return filter as ChromaWhereExpression
}

function renderFilterTemplate(id: string, params: object): ChromaWhereExpression {
  switch (id) {
    case "by_category":
      return { cateId: { $in: (params as any).categories } }
    case "by_category_and_tag":
      return {
        $and: [
          { cateId: { $in: (params as any).categories } },
          { tags: { $in: (params as any).tags } },
        ],
      }
  }
}
```

> **关键区分**：这个 `renderFilterTemplate` **不是方案 A 的翻译层**。它不做语义映射（"植保情报" → `plant_protection`），只是做 **语法展开**（template + params → where AST）。两者本质不同：
>
> - 方案 A 翻译层：**语义转换**，需要维护业务词汇到引擎字段的映射表
> - 方案 D 渲染函数：**语法展开**，纯机械的模板参数替换，不含业务知识

#### 9.3.4 适用场景

| 场景 | 推荐方案 |
|------|---------|
| 3-10 个专家，过滤简单 | 方案 B（`Record<string, unknown>`）足够 |
| **10-50 个专家，过滤模式重复度高** | **方案 D（模板注册表）最佳** |
| 50+ 个专家，过滤逻辑高度定制化 | 方案 C（受限类型）或 C+D 组合 |
| 需要前端 UI 可视化配置过滤条件 | **方案 D 最佳**（模板 = 可渲染的表单 schema） |

### 9.4 方案 E：C + D 组合（推荐用于几十个专家规模）

#### 9.4.1 架构

```typescript
// === Layer 1: 类型定义（方案 C）===

type ChromaOp = { $eq?: Val } & { $in?: Val[] } & { $and?: Where[] } & { $or?: Where[] }
type Where = { [field: string]: ChromaOp } | { $and: Where[] } | { $or: Where[] }

// === Layer 2: 模板注册表（方案 D，可选，简化常见场景）===

const FILTER_TEMPLATES = {
  by_category(categories: string[]): Where {
    return { cateId: { $in: categories } }
  },
  by_category_and_tag(categories: string[], tags: string[]): Where {
    return { $and: [{ cateId: { $in: categories } }, { tags: { $in: tags }}] }
  },
} as const

// === Layer 3: 专家声明（三种风格共存）===
```

#### 9.4.2 三种声明风格

```typescript
// 风格 1: 模板函数（最简洁，覆盖 80% 场景）
crop_compare: {
  evidenceFilter: FILTER_TEMPLATES.by_category(["planting_technique"]),
},

// 风格 2: 直接写原语（需要组合条件时）
pest_risk: {
  evidenceFilter: {
    $and: [
      { cateId: { $in: ["plant_protection", "agri_tech"] } },
      { tags: { $in: ["病害", "防治"] } },
    ],
  },
},

// 风格 3: 工厂函数（最灵活，可编程生成）
function makeRegionalFilter(regionCates: string[], extraTags: string[]): Where {
  return {
    $and: [
      { cateId: { $in: regionCates } },
      ...(extraTags.length > 0 ? [{ tags: { $in: extraTags } }] : []),
    ],
  }
}

regional_expert: {
  evidenceFilter: makeRegionalFilter(
    ["market_intel", "economic_data"],
    ["邗江区", "扬州"],
  ),
},
```

### 9.5 五方案完整决策矩阵

| 维度 | A: 业务枚举 | B: `Record` | **C: 受限类型** | **D: 模板注册表** | **E: C+D 组合** |
|------|-----------|------------|----------------|------------------|---------------|
| **类型安全** | ⭐⭐⭐⭐⭐ | ⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ |
| **零翻译层** | ❌ | ✅ | ✅ | ✅ | ✅ |
| **3 专家** | 过度工程 | 刚好 | ✅ **第4轮采用** | 过度工程 | 过度工程 |
| **~20 专家** | 维护噩梦 | 开始失控 | **✅ 推荐** | **✅ 推荐** | 可以 |
| **50+ 专家** | 不可用 | 危险 | ✅ 够用 | 可能不够 | **✅ 最佳** |
| **IDE 补全** | 枚举级 | 无 | **结构体级** | 模板名级 | **双层级** |
| **前端可配置** | 需额外开发 | 困难 | 困难 | **天然支持** | **天然支持** |
| **审计日志可读性** | 高 | 中 | 中高 | 高（含模板名） | **高** |
| **实现成本** | 高（翻译层） | 零 | 低（类型定义） | 中（模板引擎） | 中低 |
| **裁决层增益** | 无 | 无 | 无 | **无**（模板是 retrieval 层语法糖，不参与裁决） | 无 |

### 9.6 分阶段演进建议

```
第4轮（3 个专家）→ **升级为方案 C**（加 ChromaWhereExpression 类型定义）
     │  理由：第4轮 evidenceFilter 首次被管线消费（retrieval.ts），
     │  此时给 where 子句加 shape 约束，成本和收益匹配。
     │  20 行类型定义，零运行时开销。
     │
     ▼
第5-7轮（扩展到 ~15-30 个专家）→ 方案 C 持续使用，不做变更
     │  理由：ChromaWhereExpression 足够覆盖 $in/$and/$or 组合，
     │  IDE 补全保障新人不会写错操作符。
     │
     ▼
远期考虑（50+ 专家 + 前端可配置过滤条件时）
  → 可选引入方案 D 模板层（FILTER_TEMPLATES.by_category(...)）
    理由：模板名 → 表单 schema → 非开发人员可视化配置过滤条件。
    在此之前模板层无实际裁决增益，不建议提前引入。
```

> **注**：2026-06-03 决策调整。原建议"第4轮保持方案 B，第5-6轮升级方案 C"，经 Review 讨论后改为"第4轮直接实施方案 C"——理由是实现成本极低（~20 行类型定义 + 改一行接口声明），且第4轮首次消费 evidenceFilter 是加类型约束的自然时机。

### 9.7 第4轮行动项

**实施方案 C**：在当前轮次将 `evidenceFilter` 从 `Record<string, unknown>` 升级为 `ChromaWhereExpression` 受限类型。

改动范围（3 个文件，零运行时开销）：

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/agents/experts/filter-types.ts` | **新建** | `ChromaWhereExpression` 类型定义（~20 行） |
| `src/agents/experts/registry.ts` | 修改 | `evidenceFilter` 类型标注改为 `ChromaWhereExpression` |
| `src/agents/nodes/retrieval.ts` | 修改 | `mergeExpertEvidenceFilters` 返回类型对齐 |

验证：`npx tsc --noEmit` 零类型错误，三个 expert 的现有 evidenceFilter 值自动通过类型检查。

> **非第4轮行动项**：9.2.5 节的向量引擎迁移考量属于远期设计文档，不驱动当前轮次的任何代码变更。方案 D 模板层在无前端可配置需求时增益为零，不建议提前引入。
```

后续轮次看到这条注释时，知道有一条已经论证过的升级路径可以走，而不需要重新做方案选型。
