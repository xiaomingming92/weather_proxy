# farm-agent — ACA 三层推理图 v1→v2→v3 三版 Plan 合并 Review

## Review 元信息

- **Review 对象**: 
  - [v1 Plan](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/17/farm-agent-three-tier-reasoning-graph-plan-v1.md)（2026-06-17）
  - [v2 Plan](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-plan-v2.md)（2026-06-25）
  - [v3 Plan](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md)（2026-06-29）
- **Review 范围**: 三版 Plan 的架构设计一致性、实施路线演化、文档完备性、风险覆盖度
- **Review 时间**: 2026-06-29
- **Review 类型**: 架构决策 + 方案选型 + 实施可行性
- **前置阅读**: 
  - v2 Handoff: `.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-handoff-v2.md`
  - 代码基线: `src/agents/index.ts`, `src/agents/state.ts`, `src/types/evidence.ts`, `src/agents/nodes/reasoning.ts`, `src/agents/edges/conditional.ts`
- **结论级别**: **可接受，修正后执行**

---

## 1. 问题复现

### 1.1 为什么需要这次评审？

三版 Plan 跨越 12 天（06/17→06/29），v3 刚完成撰写。评审目标：

1. **验证架构一致性**：ACA 三阶段（Argumentation + Constraint + Adjudication）是否在三版中保持一致
2. **评估 v2→v3 变化是否退化**：v3 声称"保留 v2 优势"，需验证是否真的保留了而非倒退
3. **判定文档是否具备执行基础**：Spec/Tasks/Checklist 缺失是否阻塞实施
4. **识别风险遗漏**：v3 新增的风险矩阵是否覆盖了所有已知风险

### 1.2 三版 Plan 演化轨迹

```
v1 (06/17):  方向确立
  ├── ✅ ACA 架构定义（三阶段、三图路由）
  ├── ✅ 方案选型（独立子图 vs if-else，选 B）
  ├── ❌ 4 个粗粒度 Phase（缺少原子事务边界）
  ├── ❌ 无 Web 调研（冲突检测算法未参考行业实践）
  └── ❌ 约束松弛策略未定义

v2 (06/25):  细化为原子事务
  ├── ✅ 4 轮原子事务（轮次 1-4）
  ├── ✅ Web 调研：LangGraph interrupt/Send API + MAPF mutex propagation + Lagrangian relaxation
  ├── ✅ 约束松弛三级策略定义
  ├── ✅ 新增 Phase 0：H5 Resume 链路修复（前置依赖）
  ├── ❌ 缺少原子闭包三可性判定
  ├── ❌ 轮次缺少职责边界和 Handoff 交接面
  └── ❌ Spec/Tasks/Checklist 全部未生成

v3 (06/29):  补齐治理 + 风险覆盖
  ├── ✅ 原子闭包三可性判定（§5.0）
  ├── ✅ 代码基线刷新（StreamState + PostgresSaver 兼容性确认）
  ├── ✅ KB 冲突集中处理策略（Web 调研驱动，方案 B）
  ├── ✅ 风险矩阵（5 项 + §7.1 专项分析）
  ├── ✅ 每轮职责边界 + Handoff 交接面
  ├── ✅ 保留 v2 4 轮结构 + 生产者/消费者分离
  └── ❌ Spec/Tasks/Checklist 仍未生成
```

---

## 2. 正向评价

### 2.1 架构设计成熟且一致

ACA 三阶段（Argumentation → Constraint → Adjudication）在三版中保持不变，方向正确：

- **Argumentation**：每位专家独立论证，产出结构化 ExpertClaim（非自由文本），这比 MADAM-RAG 的纯 LLM debate 更严格
- **Constraint**：确定性冲突检测（前提互斥/资源冲突/时序矛盾/执行标准不一致），零 LLM 调用，对齐 NeurIPS 2025 的"投票优于辩论"结论
- **Adjudication**：不可解硬冲突由人类裁决，不是自动降级——农业场景的黄金标准

三版选型（方案 B：独立子图 + 入口路由）自始至终一致，未被推翻。

### 2.2 v2→v3 的改进方向正确

| v2 问题 | v3 改进 | 评价 |
|---------|--------|------|
| 无原子闭包判定 | §5.0 三可性判定 | 强制执行 ADD Step 0.7，防止轮次拆分偏离业务价值 |
| 轮次边界模糊 | 每轮"职责边界 + Handoff 交接面" | 下游 AI 恢复上下文有明确入口 |
| KB 冲突在 fan-out 内 interrupt | 集中式 kbConflictAggregator | 规避 LangGraph 已知 Bug，对齐 MADAM-RAG |
| 未考虑介入变更 | §四 代码基线刷新 | 确认 StreamState + PostgresSaver 兼容 |
| 无风险矩阵 | §七 5 项 + §7.1 专项分析 | 首次覆盖 LangGraph 并行 Bug、竞态、JSON 稳定性 |

### 2.3 行业对齐度强

| 维度 | 行业最佳实践 | v3 设计 | 对齐？ |
|------|------------|---------|:--:|
| Agent 数量 | 3-4 个 | 3 专家 | ✅ |
| KB 冲突 | fan-in 后集中 Aggregator | kbConflictAggregator | ✅ |
| 冲突检测 | 确定性规则优于 LLM 辩论 | conflictResolver 零 LLM | ✅ |
| 辩论轮次 | 2-4 轮 | coordinationDialogue 最多 2 轮 | ✅ |
| 人类裁决 | 结构化选项 | interactionPoint + interrupt | ✅ |

---

## 3. 问题清单

### P0: Spec/Tasks/Checklist 三元组缺失（阻塞实施）

**问题描述**：三版 Plan 的关联文档表中，Spec/Tasks/Checklist 全部标注为"待生成"。v2 已延迟 12 天，v3 若无 Spec 立即进入实施，将重蹈 v2 的"Plan 是方向图，缺施工图"困境。

**影响**：
- 冲突检测算法的 MAPF mutex propagation 到农业场景的映射关系，只在 v2 L766 有 3 行引用，没有 WHEN-THEN 级 Scenario
- 约束松弛策略的 `penalty` 计算方式未定义
- coordinationDialogue 的 prompt 模板未定义
- kbConflictAggregator 恢复后"重新触发受影响 expert 的 reasoning"的流程未定义

**修正建议**：进入 Step 1 之前，必须生成 `specs/farm-agent-three-tier-reasoning-graph/spec.md`，最低覆盖以下 4 个 Requirement：
1. conflictResolver 四类检测的 WHEN-THEN Scenario（每条对应一个农业场景）
2. coordinationDialogue 约束松弛的 penalty 计算 + prompt 模板
3. kbConflictAggregator 的 KB 冲突标记 → interrupt → resume → 重新推理 全流程
4. structuredOutputNode 的 JSON schema 约束（确保 ExpertClaim 字段完整性）

### P1: v3 缺少 add-route（阻塞 ADD Step 3）

**问题描述**：v3 Plan 关联文档表中 add-route 标注为"待生成"。按 ADD 范式 Step 3.0 前置守卫，无 add-route 禁止进入代码实现。

**修正建议**：在 Review 回流后、Step 1 前，调用 `get_add_template({ template: "add-route-template-heavyweight" })` 生成 v3 add-route。

### P1: v2 Handoff 未更新（恢复上下文断裂）

**问题描述**：v2 Handoff（`.qoder/plans/2026-06/25/farm-agent-three-tier-reasoning-graph-handoff-v2.md`）只覆盖了 Phase 0（H5 Resume）的交付，未包含轮次 1-4 的任何信息。v3 是 v2 的延续，但下游 AI 读 v2 Handoff 时不知道 v3 的存在。

**修正建议**：v3 Plan §八 关联文档表补充 v3 Handoff 路径，v3 Handoff 生成后在 §1 标注"上游 Plan 从 v2 演进至 v3"。

### P2: v3 §7.1 的 kbConflictAggregator resume 后"重新触发 reasoning"语义不明确

**问题描述**：v3 Plan §7.1 写道"用户裁决 → Command(resume) → 重新触发受影响 expert 的 reasoning → 重新 structuredOutput"。但未说明"重新触发"是重新调用 LLM（从头推理）还是从 reasoning 节点重新执行整个 fan-out。如果重新执行 fan-out，其他两个 expert 也会被重新推理——这会导致不必要的 token 消耗和不一致的 ExpertClaim 版本。

**修正建议**：在 Spec 中明确定义 resume 后的执行范围——是仅重新执行受影响 expert 的 reasoning + structuredOutput（局部更新 ExpertClaim[]），还是全量 fan-out 重跑。

### P2: v2 约束松弛策略的 "最多 2 轮" 行业依据偏弱

**问题描述**：v2 Plan L817 定义 coordinationDialogue 最多 2 轮。行业文献显示 2-4 轮为最优（Du et al. 2023 推荐 4 轮，Xu et al. 2023 推荐 2 轮）。2 轮作为默认值合理，但未说明阈值依据（是基于 token 成本还是基于"问题漂移"风险）。

**修正建议**：在 Spec 中补充：2 轮的上限基于 Becker et al. (2025) 的"问题漂移"发现——超过 3 轮后约 0.8% 的 case 出现性能下降；农业场景保守取 2 轮。

---

## 4. 影响评估

### 4.1 受影响文件（v3 实施范围）

| 文件 | 操作 | v3 中的轮次 |
|------|:--:|:--:|
| `src/types/evidence.ts` | 修改 | 轮次 1 |
| `src/agents/prompts/types.ts` | 修改 | 轮次 1 |
| `src/agents/state.ts` | 修改 | 轮次 2 |
| `src/agents/nodes/structured-output.ts` | **新建** | 轮次 2 |
| `src/agents/nodes/kb-conflict-aggregator.ts` | **新建** | 轮次 3 |
| `src/agents/nodes/conflict-resolver.ts` | **新建** | 轮次 3 |
| `src/agents/nodes/aggregation.ts` | **新建** | 轮次 3 |
| `src/agents/nodes/coordination-dialogue.ts` | **新建** | 轮次 3 |
| `src/agents/nodes/interaction-point-detection.ts` | 修改 | 轮次 3 |
| `src/agents/nodes/intention.ts` | 修改 | 轮次 4 |
| `src/agents/edges/conditional.ts` | 修改 | 轮次 4 |
| `src/agents/index.ts` | 修改 | 轮次 4 |

### 4.2 数据流影响

- **新数据流**：ExpertClaim[] 在 structuredOutput → kbConflictAggregator → conflictResolver → coordinationDialogue → aggregation 之间传递，构成 professional 图的核心数据契约
- **State 扩展**：新增 6 个字段（massifIds / expertPlan / expertClaims / conflictReports / coordinationResult / aggregatedReport），不影响现有 deep/fast 图
- **interrupt 点分布**：professional 图有两个 interrupt 点——kbConflictAggregator（KB 冲突，fan-in 后）和 interactionPointDetection（硬冲突残留，串行节点）。两者均为串行节点，无并行 Bug 风险

### 4.3 回滚风险

- **低风险**：轮次 1-3 仅新增文件 + 修改现有节点（intention.ts / interaction-point-detection.ts / conditional.ts），不删除任何现有逻辑
- **轮次 4 风险**：index.ts 的 workflow → deepGraph 提取 + professionalGraph 编译，如果 Send API fan-out 编译失败，可通过 git checkout 回滚单文件
- **deep 图保护**：轮次 2 的验收标准明确要求"deep 图回归零"，且现有单 workflow 编译在提取为 deepGraph 后拓扑不变

---

## 5. 最终建议

### 5.1 执行顺序（推荐）

```
1. Review 回流  ← 当前步骤
   ├── P0/P1 问题写回 v3 Plan §八 补充说明
   └── 关联文档表更新为 v3 路径

2. 生成 Spec（P0 阻塞项）
   └── specs/farm-agent-three-tier-reasoning-graph/spec.md
       最低 4 个 Requirement（见 P0 修正建议）

3. 生成 Tasks + Checklist
   └── 从 v3 Plan §五 4 轮任务表提取

4. 生成 add-route（P1 阻塞项）
   └── 重型模板，4 轮映射到 ADD Step 0-8

5. 执行 DPS 闸门
   └── check_dps({ planKeyword: "farm-agent-three-tier-reasoning-graph" })
   └── DPS ≥ 85 方可进入 Step 1

6. 进入实施：轮次 1 → 2 → 3 → 4
```

### 5.2 完成判定标准

- [ ] Spec 已生成，含 4 个最低 Requirement
- [ ] Tasks + Checklist 已生成，与 v3 Plan §五 一致
- [ ] add-route 已生成（重型模板），Task 映射表与 tasks.md 一致
- [ ] DPS ≥ 85
- [ ] P0/P1 Review 问题已回流至 v3 Plan
