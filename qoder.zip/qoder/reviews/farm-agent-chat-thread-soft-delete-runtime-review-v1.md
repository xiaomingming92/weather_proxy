# farm-agent-chat-thread-soft-delete-runtime-review-v1

> 运行时验证纠偏文档。通过用户反馈 + 运行时日志发现 ChatThread 删除为硬删除，对话不可恢复。

## Review 元信息

- **关联方案 review**: 无（原始 `chat-thread-tab-plan-v1.md` 未经过 Plan Review）
- **关联实现 review**: 无
- **关联 checklist**: `.qoder/specs/chat-thread-spec/checklist.md`
- **Review 时间**: 2026-06-24
- **触发方式**: 用户报告 + 运行时日志

---

## 1. 发现列表

### 发现 #1: ChatThread 删除为物理删除，对话不可恢复

**现象**：

```
curl 'http://114.115.216.200:3000/api/agent/3e34b82e13ef?action=thread&id=thread_132b2f77-06df-409e-924c-42a47a190e4f'
→ {"success":false,"error":"对话不存在"}
```

rfai 运行时日志（2026-06-24T12:01:04Z）：
```
[CHAT-PERSIST] [2026-06-24T12:01:04.269Z] [THREAD_LOAD] 加载线程 | {"threadId":"thread_132b2f77-06df-409e-924c-42a47a190e4f"}
[CHAT-PERSIST] [2026-06-24T12:01:04.271Z] [THREAD_LOAD] 线程不存在 | {"threadId":"thread_132b2f77-06df-409e-924c-42a47a190e4f"}
```

同一请求在 `20:03:29`、`20:04:38` 重复出现，确认线程永久丢失。

**根因（git 追溯）**：

```
commit 51b6ed5 (2026-05-23, "create")
  - src/services/chat-persistence.ts (新建)
  - deleteThread() 方法直接调用 prisma.chatThread.delete() — 物理删除
  - ChatThread 模型无 deletedAt 字段
```

关键代码 (`chat-persistence.ts:246-258`)：
```typescript
async deleteThread(threadId: string) {
    chatPersistAudit("THREAD_DELETE", "删除线程", { threadId })
    try {
      await prisma.chatThread.delete({ where: { id: threadId } })  // ← 硬删除
      chatPersistAudit("THREAD_DELETE", "线程删除成功", { threadId })
    } catch (error) { ... }
  }
```

Prisma Schema (`main.prisma:199-212`)：
```prisma
model ChatThread {
  id          String   @id @default(cuid())
  title       String   @default("新对话")
  projectId   String?
  userId      String
  source      String   @default("agrisynapse")
  intent      String?
  metadata    Json?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  // ❌ 无 deletedAt 字段
  messages    ChatMessage[]
  chainTraces ChainTraceRecord[]
}
```

**后果链**：

1. 用户在 agrisynapse 前端点击删除对话 Tab
2. 前端调用 `DELETE /api/agent/chat/threads?threadId=...`
3. `chatPersistence.deleteThread()` 执行 `prisma.chatThread.delete()` 物理删除整行
4. 关联的 `ChatMessage` 和 `ChainTraceRecord` 因 `onDelete: Cascade` 也被级联删除
5. 用户期望的"软删除后可从回收站恢复"不可实现——数据永久丢失

**修复方向**：

1. `ChatThread` 模型新增 `deletedAt DateTime?` 字段
2. `deleteThread()` 改为 `prisma.chatThread.update({ data: { deletedAt: new Date() } })`
3. `getThread()` 和 `getThreadsByUser()` 查询增加 `deletedAt: null` 过滤
4. 创建 Prisma migration
5. 更新 `《聊天实例管理技术文档》.md` 补充软删除说明

#### 为何前置 review 遗漏

- `chat-thread-tab-plan-v1.md`（2026-05-26）在设计 `deleteThread` 时只关注前端交互（"删除后自动切换到相邻会话"），未考虑持久化层面的删除语义
- 原始 `chat-thread-spec` 的检查清单未覆盖"删除后数据可恢复"的验收项
- 缺少运行时的负面测试：创建一个线程 → 删除 → 尝试恢复

---

### 发现 #2: pm2 进程频繁重启（300+ 次）

**现象**：

```
│ 1  │ farm-agent         │ fork     │ 300… │ online    │ 0%       │ 75.9mb   │
```

**根因**：暂未定位，需进一步排查。可能与 `cron` 定时任务或内存泄漏有关。

**修复方向**：待后续独立 runtime-review 或 Plan 跟进，非本次范围。

---

## 2. review 流程改进项

| 检查项 | 具体操作 | 触发时机 |
|--------|---------|---------|
| 删除操作语义检查 | 对所有 DELETE API 端点，checklist 增加"删除为软删除（设置 deletedAt 而非物理删除）"验收项 | Step 5 checklist 生成 |
| 数据恢复路径验证 | checklist 增加"删除后通过 API 查询确认数据可恢复"端到端验证 | Step 8 收敛判断 |
| Schema 字段完整性 | Plan Review 阶段检查新增 model 是否包含 deletedAt / status 等生命周期字段 | Plan Review |

---

## 3. 已运行时修复项

无。待 Plan → 代码实现 → 部署后修复。

---

## 4. 回流确认

- [ ] 流程改进项已写入对应模板（`review-implementation-template.md` / `checklist-template.md`）
- [ ] 修复项已记录审计日志（`record_dev_operation`）
- [ ] Plan 已包含本 Review 的所有发现作为修复依据
