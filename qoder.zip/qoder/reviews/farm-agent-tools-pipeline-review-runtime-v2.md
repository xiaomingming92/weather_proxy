# farm-agent 工具管线 — 运行时审查 v2

> 关联 Plan: `.qoder/plans/farm-agent-tools-pipeline-plan-v1.md`
> 关联 Handoff: `.qoder/plans/farm-agent-tools-pipeline-handoff-v2.md`
> 审查时间: 2026-06-23
> 审查范围: ToolNode → Response 节点间数据契约 & LLM prompt 中工具结果摘要准确性
> 前置 Review: `.qoder/reviews/farm-agent-tools-pipeline-review-runtime-v1.md`（F1-F6 已记录）

---

## 一、发现列表

### F7 [P0] ToolNode 序列化格式与 Response 解析路径不匹配 → LLM 永远收到"0条记录"

**症状**: 用户请求"分析一周农场数据趋势"，工具 `query_farm_weather` / `query_soil_moisture` / `query_insect_data` 均正常执行并返回实际数据（前端 SSE `tool_result` 事件正确展示数据表），但 LLM 最终回复文本中声称：

> - **农场气象站数据**（地块26，2026-06-16至2026-06-23）：返回0条记录
> - **土壤墒情数据**（地块26，2026-06-16至2026-06-23）：返回0条记录
> - **虫情监测数据**（地块26，2026-06-16至2026-06-23）：返回0条记录

**复现路径**:

```
用户问题 → intention → toolNode (3工具执行, 各返回20条) → intention → reasoning 
→ interactionPointDetection → verdict → response (buildToolExecutionSummary → prompt)
→ LLM 回复文本声称全部 0 条
```

**根因映射 — 三条数据通道的格式分裂**:

```
通道 A: 工具函数返回值
  farm-data-tools.ts → unwrapPageResponse(apiResp) → { total, list }
                    → return { success: true, total, list, columns }
  ▲ 格式: { success, total, list, columns }   ← 平铺格式

通道 B: ToolNode 序列化 (src/agents/index.ts:69)
  const resultStr = typeof result === "string" ? result : JSON.stringify(result)
  → ToolMessage.content = '{"success":true,"total":20,"list":[...],"columns":[...]}'
  ▲ 格式: JSON string of 平铺格式   ← 与通道A一致

通道 C: Response prompt 解析 (src/agents/nodes/response.ts:314-317)
  const parsed = JSON.parse(tm.content)
  const data = parsed?.data           // undefined ← 期望 { data: ... } 嵌套
  const innerData = data?.data        // undefined
  const list = innerData?.list ?? []  // [] ← 永远为空！
  ▲ 期望格式: { data: { data: { list } } }   ← 与通道B分裂！
```

**数据流对比**:

| 节点 | 数据路径 | 结果 |
|------|---------|------|
| SSE `tool_result` | 原始 `result` 对象直传 | ✅ 前端数据表正常渲染 |
| `buildToolExecutionSummary` | `tm.content → JSON.parse → .data.data.list` | ❌ `list` 永远 `[]` |
| LLM prompt | `- ${displayName}: 查询成功，返回 ${recordCount} 条记录` | ❌ 永远是 "返回 0 条记录" |
| LLM 最终回复 | 基于 prompt 中的 0 条信息 | ❌ 生成"返回0条记录"的假结论 |

**Plan 文档证据链** — 两个 Plan 文档均未定义该契约:

| 文档 | 相关章节 | 缺失内容 |
|------|---------|---------|
| plan-v1.md | §3.5 Agent 代码模块架构 | 列出文件结构，**未定义 ToolNode → Response 数据格式契约** |
| plan-v1.md | §4 Task 7（管线集成 toolNode） | 描述"添加 ToolNode + 条件路由边"，**未约定 tool 结果传递给 response 的格式** |
| handoff-v2.md | §2.1.5 对话 SSE 协议 | 定义 agrisynapse ↔ farm-agent 的 SSE 事件格式，**未涉及内部节点间数据格式** |
| handoff-v2.md | §3 改动清单 | 24 条改动中无一条涉及 tool 结果格式约定 |

**影响**:

1. **LLM 输出数据量与真实数据量完全脱钩**: 无论工具返回 20 条还是 200 条，LLM 的 prompt 摘要中 `recordCount` 永远是 0
2. **summary 类专家（daily_report / weekly_report）功能性失效**: 这些专家唯一的数据来源是工具调用结果 + 工具执行摘要，摘要说 0 条 → LLM 只能生成"暂无数据"的结论
3. **证据置信度侵蚀**: LLM 在回复中标注"置信度约 80%"但事实上数据完全正确可用，用户收到的是一个**系统性低估自身可靠性的回复**
4. **前端/后端数据不一致**: 用户看到前端表格有数据，LLM 却说没有，严重破坏用户信任

**归类**: **架构契约缺失** — Plan 未定义 ToolNode 输出格式与 Response 节点输入格式之间的接口合约。两个节点由两个不同的开发者/时段实现，各自假设了不同的数据包裹层数，在没有统一契约的情况下天然产生阻抗失配。

---

### F8 [P1] `unwrapPageResponse` 引入的格式拍扁与上层解析路径未同步

**症状**: `farm-data-tools.ts:81-88` 的 `unwrapPageResponse` 将 Farm-Server API 的 `{ data: { total, list } }` 拍扁为 `{ total, list }`，工具函数进一步包装为 `{ success, total, list, columns }`。但 `response.ts:315-317` 的解析代码仍然尝试从 `parsed.data.data.list` 提取数据——这个路径只有在 `unwrapPageResponse` 不存在且工具直接透传 API 原始响应时才能命中。

**根因链**:

```
Farm-Server API 响应:  { data: { total, list } }
        │
        ▼ unwrapPageResponse（farm-data-tools.ts:81-88）
拍扁后:                 { total, list }
        │
        ▼ 工具 return 包装（farm-data-tools.ts:117）
工具返回值:              { success: true, total, list, columns }
        │
        ▼ ToolNode JSON.stringify（index.ts:69）
ToolMessage.content:    '{"success":true,"total":20,"list":[...],"columns":[...]}'
        │
        ▼ JSON.parse（response.ts:314）
解析后:                  { success: true, total: 20, list: [...], columns: [...] }
        │
        ▼ parsed.data（response.ts:315）
                        undefined  ← 格式分裂点！
```

`unwrapPageResponse` 本意是**简化**工具内的数据处理，但它"吃掉"了 API 响应的一层 `.data` 嵌套。这本身是合理的内聚设计——工具函数不应关心 API 响应格式细节。但 response.ts 的 `buildToolExecutionSummary` **硬编码了 API 原始响应格式假设**（`parsed.data.data.list`），两类假设之间没有任何文档或类型系统来强制一致性。

**归类**: 中间层拍扁操作未向上层声明格式变更 — `unwrapPageResponse` 是一个格式转换点，但其转换结果未被上层消费者（response.ts）感知。

---

### F9 [P2] 数据提取路径与工具返回结构的耦合方式脆弱

**症状**: `buildToolExecutionSummary` 中对 `list` 的提取路径是硬编码的三级嵌套 `parsed.data.data.list`，没有任何 fallback 或结构探测逻辑。

**风险**:

| 场景 | 当前行为 | 后果 |
|------|---------|------|
| 工具直接返回 `{ list: [...] }` | `list = []` | LLM 收到假 0 条 |
| 工具返回 `{ data: { list: [...] } }` | `list = innerData.list` ✅ 唯一命中路径 | — |
| 工具返回 `{ data: { data: { list: [...] } } }` | `list = innerData.list` ✅ | — |
| 工具返回 `{ data: { data: { records: [...] } } }` | `list = innerData.records` ✅ | — |
| 工具返回 `{ success, list }`（当前实际格式） | `list = []` ❌ | F7 |

**对比 `unwrapPageResponse`** (`farm-data-tools.ts:81-88`):
```typescript
// 已经做了降级兼容
list: (inner?.list ?? inner?.records ?? [])  // 兼容 list / records 两种字段名
```

而 `buildToolExecutionSummary` 仅在 `innerData` 层面上做了 `list ?? records` 降级，没有在 `parsed` 层面做同样的降级。两处代码的兼容性不对称。

**归类**: 解析逻辑脆弱性 — 单一提取路径，无结构自检/降级机制。

---

## 二、架构根因总结

### 缺失的契约层

```
┌─────────────────────────────────────────────────────────┐
│  当前架构（契约空白）                                      │
│                                                         │
│  ToolNode (index.ts)          Response (response.ts)     │
│  ┌──────────────────┐        ┌──────────────────────┐   │
│  │ result → JSON     │  ???   │ JSON.parse → .data.  │   │
│  │ .stringify()      │───────→│ data.list            │   │
│  │                   │  无契约 │                      │   │
│  └──────────────────┘        └──────────────────────┘   │
│                                                         │
│  Plan 文档 §3.5 / §4 Task 7: 无数据格式定义              │
│  Handoff 文档 §2.1.5: 仅定义 SSE 协议，不涉及内部节点间   │
└─────────────────────────────────────────────────────────┘
```

### 应追加的契约层

```
┌─────────────────────────────────────────────────────────┐
│  修复后架构（契约明确）                                     │
│                                                         │
│  ToolNode (index.ts)          Response (response.ts)     │
│  ┌──────────────────┐        ┌──────────────────────┐   │
│  │ result → JSON     │  合约   │ JSON.parse → 按合约    │   │
│  │ .stringify()      │───────→│ 结构提取 list         │   │
│  │                   │        │                      │   │
│  │ 合约定义:          │        │ 解析逻辑:              │   │
│  │ { success, total, │        │ - 探测 parsed.data?    │   │
│  │   list, columns } │        │ - 降级 parsed.list     │   │
│  └──────────────────┘        └──────────────────────┘   │
│                                                         │
│  Plan §3.5 追加: Tool 结果序列化格式规范                   │
│  Plan §4 Task 7 追加: ToolNode→Response 数据合约          │
└─────────────────────────────────────────────────────────┘
```

---

## 三、修复方案

### 修复策略：不修补数据路径，定义数据契约

**反对直接在 `buildToolExecutionSummary` 中加 fallback** — 这属于"猜格式"而非"定契约"，没有消除根因，未来其他消费者（如 reasoning.ts 的 `toolResultsBlock`）会遇到同样问题。

### 推荐方案：在 LangGraph State 中增加结构化 Tool 结果字段

```typescript
// src/agents/state.ts — 新增字段
toolResults: Array<{
  toolName: string
  success: boolean
  recordCount: number
  list: unknown[]
  columns?: ToolColumn[]
  error?: string
}>
```

- **Producer**: ToolNode 执行工具后，在 return 中同时写入 `messages`（保留给 LLM 上下文）和 `toolResults`（给下游节点消费）
- **Consumer**: Response 节点的 `buildToolExecutionSummary` 从 `state.toolResults` 直接读取结构化数据，不再解析 ToolMessage 的 JSON string

**优势**:
1. **消除解析歧义**: 不再依赖 JSON string 的反序列化路径假设
2. **类型安全**: TypeScript 类型系统强制契约一致性
3. **性能**: 跳过所有工具结果（可能数 MB 的 JSON）的 Stringify → Parse → 字段探测，直接访问结构化数据
4. **复用性**: reasoning 节点的 `toolResultsBlock` 也可直接消费，消除其与 response 的解析重复

### 替代方案（保守）：在 `buildToolExecutionSummary` 中增加结构探测 + 降级

如果不在 State 中增加字段，则至少需要：

```typescript
const list = extractList(parsed)  // 统一提取函数

function extractList(obj: Record<string, unknown>): unknown[] {
  // 探测顺序：parsed.data.data.list → parsed.data.list → parsed.list → parsed.records
  const data = obj?.data as Record<string, unknown> | undefined
  const innerData = data?.data as Record<string, unknown> | undefined
  return (innerData?.list ?? innerData?.records 
       ?? data?.list ?? data?.records 
       ?? obj?.list ?? obj?.records 
       ?? []) as unknown[]
}
```

此方案可快速止血（5 行改动），但 F7 的架构根因（契约缺失）未解决。

### 修复范围

| 项 | 内容 | 优先级 |
|----|------|--------|
| Plan 回流 | plan-v1.md §3.5 追加 "Tool 结果序列化格式规范" 章节 | P0 |
| Plan 回流 | plan-v1.md §4 Task 7 追加 "ToolNode→Response 数据合约" 子任务 | P0 |
| 代码修复 | `buildToolExecutionSummary` 增加结构探测 + 降级逻辑（止血） | P0 |
| 架构改进 | State 新增 `toolResults` 字段，消除跨节点 JSON 解析 | P1 |
| 验证 | 回归测试 daily_report / weekly_report 专家在真实 Farm-Server 数据下的回复准确性 | P1 |

---

## 四、编译状态

待实施后验证。

---

## 五、回流确认

- [x] 需回流至 Plan: plan-v1.md §3.5 追加 "Tool 结果序列化格式规范"
- [x] 需回流至 Plan: plan-v1.md §4 Task 7 追加 "ToolNode→Response 数据合约"
- [x] 需回流至 Plan: ADD-7 审计策略表追加 `response.ts` 的 F7 修复项
- [x] 需回流至 Handoff: handoff-v2.md §3 追加 `response.ts` 工具结果解析修复项
- [x] 需更新 Runtime Review v1 的 §五 F5 修复记录（新增 §六 后记说明 F5→F7 关系）

---

## 六、与 Runtime Review v1 的关系

| v1 发现 | 内容 | 与 F7 关系 |
|---------|------|-----------|
| F5 | `buildToolExecutionSummary` 提取 `tool_calls` 时只用 `aim.tool_calls`，未查 `additional_kwargs` | F5 修复了**参数提取路径**（massifId / dataTime），但 F7 揭示**数据提取路径**（list / recordCount）独立失效 — 即使 F5 修复后 recordCount 仍为 0 |
| F1 | 工具日志未接入 ADD 审计体系 | 无关 |
| F6 | 报告模板缺少 per-expert 逻辑 | 无关 |

F5 和 F7 共同指向 `buildToolExecutionSummary` 函数的设计缺陷：**它试图从序列化后的非结构化 JSON 中反向推导结构化信息**，而这个"反向推导"的假设从未在 Plan 中明确定义。
