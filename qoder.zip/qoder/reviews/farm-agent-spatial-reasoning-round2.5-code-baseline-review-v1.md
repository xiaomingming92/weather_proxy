# farm-agent 空间推理 轮次 2.5 代码基线 Review

## Review 元信息

- **Review 对象**: 轮次 2.5 toolResults 保鲜基础设施 代码基线审计
- **基线 Plan**: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-plan-v3.md` 轮次 2.5
- **增量 Plan**: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-plan-v4.md`
- **Review 时间**: 2026-07-22
- **Review 类型**: 代码基线审计 + 实现质量合规检查
- **前置阅读**:
  - Plan v3: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-plan-v3.md` §轮次 2.5
  - Plan v4: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-plan-v4.md`
  - Review v2: `.qoder/reviews/farm-agent-spatial-reasoning-review-v2.md`

---

## 1. 问题复现

Plan v3 轮次 2.5 定义了 6 个 Task（2.5.1-2.5.6），实现 toolResults 保鲜基础设施。用户要求审计代码基线是否"偷懒"——即实现是否完整覆盖了 Plan 要求，是否存在 stub、空壳、逻辑反转等质量缺陷。

本次审计覆盖的文件：

| Plan Task | 文件 | 审计结果 |
|-----------|------|:--------:|
| 2.5.1 JieqiTable Prisma model | `prisma/main.prisma` + migration | ✅ 合格 |
| 2.5.2 seed-jieqi 种子脚本 | `scripts/fetch-jieqi-from-pmo.ts`（方案变更） | ✅ 合格 |
| 2.5.3 getCurrentJieqi 运行时查询 | `src/lib/jieqi.ts` | ✅ 合格 |
| 2.5.4 toolResultFreshness 策略 | `src/caijuehub/strategies/toolResultFreshness.ts` | ⚠️ 已修复 |
| 2.5.5 toolResultsHydration 节点重构 | `src/agents/nodes/tool-results-hydration.ts` | ⚠️ 已修复 |
| 2.5.6 deep 图拓扑更新 | `src/agents/agent-graph.ts` | ✅ 合格 |

---

## 2. 审计发现与修复

### F1: toolResultFreshness 两处核心逻辑为 stub（P0 → 已修复）

**文件**: `src/caijuehub/strategies/toolResultFreshness.ts`

**问题 A — LAND_ANALYSIS_DEPENDENTS 兜底检查为空壳**：

```typescript
// 修复前（第 125-131 行）
shouldRefreshLandAnalysis = false  // 硬编码，24 节气刷新机制瘫痪
```

Plan v4 §2.2 明确要求"查 land_analysis snapshot.jieqi vs 当前节气"。原实现将核心检查直接写死为 `false`，等于废掉了整个 24 节气刷新机制的兜底保护。

**修复**：新增 `isLandAnalysisSnapshotFresh()` 函数，查询 JieqiTable 获取当前节气日期 → 查 ToolResultSnapshot 表检查 `query_massif` 工具在本节气周期内是否有快照。

```typescript
// 修复后
if ((LAND_ANALYSIS_DEPENDENTS as readonly string[]).includes(expertId) && projectId !== undefined) {
  const fresh = await isLandAnalysisSnapshotFresh(projectId, currentDate)
  shouldRefreshLandAnalysis = !fresh
}
```

**问题 B — jieqi 策略分支未实现节气检查**：

```typescript
// 修复前（第 160-171 行）
case "jieqi":
  // 简化处理：always query snapshot
  return { shouldQuerySnapshot: true, queryDates: [currentDate], ... }
```

Plan 要求"先检查 jieqi 是否已切换，再决定是否查询"。原实现直接返回 `shouldQuerySnapshot: true`，没有调用 `isJieqiChanged()`。

**修复**：`jieqi` 分支现在先调 `isLandAnalysisSnapshotFresh()`，节气已切换时返回 `{ shouldQuerySnapshot: false }`（走 Farm-Server），未变时返回 `{ shouldQuerySnapshot: true }`（读快照）。

### F2: hydration 节点 isResume 判断逻辑反转（P0 → 已修复）

**文件**: `src/agents/nodes/tool-results-hydration.ts` 第 55 行

```typescript
// 修复前（逻辑完全反转）
const isResume = currentToolResults.length === 0  // 空 = resume？错

// 修复后
const isResume = currentToolResults.length > 0  // 有值 = checkpointer 恢复了数据 = resume
```

**影响**：原逻辑导致新请求被误判为 resume → 策略层返回空 actions → 保鲜机制完全不生效。

### F3: 策略层 vs 节点层职责边界不清（P1 → 已修复）

**文件**: `toolResultFreshness.ts` + `tool-results-hydration.ts`

**问题**：原 `FreshnessDecision` 接口使用 `shouldQuerySnapshot` / `shouldPersist` / `queryDates` / `persistDate` 四个布尔+参数组合，节点层用 `if (decision.shouldQuerySnapshot)` / `if (decision.shouldPersist)` 做条件分支——这是策略逻辑泄漏到节点层。

**修复**：

```typescript
// 新增 FreshnessAction 类型，策略层返回执行计划
export type FreshnessAction =
  | { type: "hydrate"; dates: string[] }
  | { type: "persist"; date: string }

export interface FreshnessDecision {
  actions: FreshnessAction[]  // 纯执行计划，节点层按序执行
  shouldRefreshLandAnalysis: boolean
  reason: string
}
```

节点层变为纯执行器：`for (const action of decision.actions)` → `switch (action.type)` → 调 IO 层。

### F4: caijue.toml 未登记两个新策略（P1 → 已修复）

**文件**: `src/caijuehub/caijue.toml`

**问题**：`toolResultFreshness` 和 `awareness` 两个新增策略文件未在裁决中心登记。

**修复**：新增 `resolve-tool-result-freshness` 和 `resolve-awareness` 两条 `[[caijue]]` 条目，含 governance 追溯、inputs/outputs 声明、consumers 标注。

### F5: awareness.ts land_analysis TTL 硬编码为 -1（P0 → 已修复）

**文件**: `src/caijuehub/strategies/awareness.ts` 第 42 行

**问题**：`land_analysis: -1`（永不刷新）是旧认知，v4 已明确 24 节气刷新机制。

**修复**：
- 从 `EXPERT_TTL_MS` 中移除 `land_analysis` 条目
- `resolveAwareness` 改为 `async`，新增 `land_analysis` 特殊分支，调 `isJieqiChanged(spatial.jieqi, projectId)` 判断是否刷新
- `SpatialStateSnapshot` 新增 `jieqi: string | null` 字段
- `AgentState` 新增 `jieqi` 字段
- `spatialPreprocessing` 节点调 `getCurrentJieqi(projectId)` 注入节气
- `syncSpatial()` 新增可选 `jieqi` 参数
- `agent-graph.ts` 调用处传入 `state.jieqi`

### F6: toolResultFreshness.ts 日期解析时区偏移（P2 → 已修复）

**文件**: `src/caijuehub/strategies/toolResultFreshness.ts` 第 122 行

```typescript
// 修复前（UTC 时区偏移风险）
const year = new Date(currentDate).getFullYear()

// 修复后（直接字符串截取）
const year = Number(currentDate.slice(0, 4))
```

### F7: tool-results-hydration.ts 未使用导入（P2 → 待清理）

**文件**: `src/agents/nodes/tool-results-hydration.ts` 第 31 行

```typescript
// import type { FreshnessAction } from "@/caijuehub/strategies/toolResultFreshness"
```

被注释的 import 应删除。节点层不直接引用 `FreshnessAction` 类型（通过 `decision.actions` 消费即可）。

---

## 3. 架构评估

### 3.1 三层职责分离 ✅

```
策略层: caijuehub/strategies/toolResultFreshness.ts
  → 决策逻辑：FreshnessAction[] 执行计划
  → 24 节气刷新 + LAND_ANALYSIS_DEPENDENTS 兜底

IO 层: src/lib/tool-result-cache.ts
  → 纯读写：hydrateToolResults() / persistToolResults()
  → 无业务决策

节点层: src/agents/nodes/tool-results-hydration.ts
  → 纯执行器：for (action of decision.actions)
  → 不做任何条件分支判断
```

修复后职责边界清晰，符合 caijuehub 架构设计原则。

### 3.2 GlobalState 节气数据流 ✅

```
spatialPreprocessing → getCurrentJieqi(projectId) → state.jieqi
    ↓
summaryRetrieval → syncSpatial(..., state.jieqi) → GlobalState.spatial.jieqi
    ↓
resolveAwareness(spatial, expertId) → spatial.jieqi → isJieqiChanged()
```

节气数据从空间预处理节点注入 AgentState → 投影到 GlobalState.spatial → awareness 裁决消费。链路完整。

### 3.3 CognitiveEventBus 标准化评估

| 维度 | 评级 | 说明 |
|------|:----:|------|
| 核心 pub/sub 协议 | A | subscribe/emit/unsubscribe 完整 |
| 类型安全 | B- | `__threadId` 用 `as Record` 强转 |
| 可扩展性 | C+ | 事件类型硬编码在 union 中，无注册表 |
| `StateDomainKey` | **缺失** | 漏了 `"spatial"`（第八域） |

**遗留**：`StateDomainKey` 需补 `"spatial"`，否则 event-consumer-strategies 的 `dependsOn` 无法引用第八域。

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 操作 | 变更摘要 |
|------|------|---------|
| `src/caijuehub/strategies/toolResultFreshness.ts` | 修改 | FreshnessAction 类型 + 兜底检查 + jieqi 分支 |
| `src/agents/nodes/tool-results-hydration.ts` | 修改 | isResume 修正 + actions 消费 |
| `src/caijuehub/strategies/awareness.ts` | 修改 | 24 节气刷新改造 + async |
| `src/agents/global-state.ts` | 修改 | jieqi 字段 + syncSpatial 参数 |
| `src/agents/state.ts` | 修改 | jieqi Annotation |
| `src/agents/nodes/spatial-preprocessing.ts` | 修改 | getCurrentJieqi 注入 |
| `src/agents/agent-graph.ts` | 修改 | syncSpatial 传 jieqi |
| `src/caijuehub/caijue.toml` | 修改 | 两个新策略登记 |

### 4.2 数据流影响

新增数据链路：`spatialPreprocessing` → `state.jieqi` → `GlobalState.spatial.jieqi` → `resolveAwareness()`。
所有返回路径（成功/降级/异常）均注入 `jieqi` 字段。

### 4.3 回滚风险

低风险。所有修改均为增量添加或逻辑修正，不涉及数据迁移。`jieqi` 字段默认 `null`，向后兼容。

---

## 5. 遗留项清单

| # | 严重度 | 问题 | 文件 | 建议 |
|---|:------:|------|------|------|
| L1 | P1 | `StateDomainKey` 缺 `"spatial"` | `cognitive-event-bus.ts` L55-62 | 补上第八域 |
| L2 | P2 | 注释掉的未使用 import | `tool-results-hydration.ts` L31 | 删除 |
| L3 | P2 | `__threadId` 类型不安全 | `cognitive-event-bus.ts` L115 | 引入 EventEnvelope 包装 |
| L4 | P3 | 事件类型无注册表 | `cognitive-event-bus.ts` | 后续可用 EventRegistry mapped type |
| L5 | P3 | `resolveAwareness` 消费方未适配 | `reasoning.ts` / `summaryReasoning.ts` | 调用处需改为 `await`（async 改造） |
| L6 | P1 | `isJieqiChanged` 未使用 | `toolResultFreshness.ts` L20 | import 了但未使用（原 `isJieqiChanged` 被 `isLandAnalysisSnapshotFresh` 替代），应删除 |

---

## 6. 结论

轮次 2.5 代码基线审计发现 **3 个 P0 + 2 个 P1 + 2 个 P2**，均已在本轮修复。

核心修复：
1. toolResultFreshness 策略层从 stub 变为完整实现（兜底检查 + jieqi 分支）
2. 策略层/节点层职责边界清晰化（FreshnessAction 执行计划）
3. awareness 裁决从"永不刷新"升级为 24 节气刷新机制
4. isResume 逻辑反转 bug 修正

修复后架构符合 Plan v3/v4 的设计要求，三层职责分离（策略/IO/节点）到位。遗留项 L1-L6 可在后续轮次中收敛。
