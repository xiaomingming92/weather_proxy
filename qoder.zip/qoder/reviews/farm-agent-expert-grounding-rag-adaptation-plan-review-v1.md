# farm-agent Expert Grounding RAG 适配 Plan Review v1

## Review 元信息

- **Review 对象**: `.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md`
- **对比方案**: 无（单方案审查）
- **Review 时间**: 2026-06-11
- **Review 类型**: 架构决策 + 合规检查
- **前置阅读**: 
  - `.qoder/plans/farm-agent-rag-audit-stacktrace-plan-v1.md`（上游 Plan，RAG 降级路径基座）
  - `src/agents/experts/registry.ts`（ANALYSIS_EXPERTS 定义）
  - `src/services/knowledge-indexer.ts`（ChromaDB 客户端）
  - `src/agents/nodes/retrieval.ts`（检索节点）

---

## 1. 问题复现

第 8 轮架构合流后，`activateExpert()` 在概念层声明了 Expert Grounding 意图，但底层 RAG 基础设施仍使用 ChromaDB `where` 子句做运行时过滤（全局检索 + cateId 过滤）。需要将 Grounding 从概念层下沉到 ChromaDB 索引层，为每个专家建立独立的 collection。

**核心矛盾**：
1. 11 个 Expert 共享一个 `farm_agent` collection，通过 `where: { cateId: { $in: [...] } }` 过滤——精度和效率存在折损
2. 上游 `rag-audit-stacktrace` Plan 已交付 `evidence.expertIds` 字段和 `cateIdToExpertIds` 映射，为 per-collection 迁移提供了基座
3. 当前 `getChromaCollection()` 是单例模式，只连一个 collection——架构上不支撑多 collection

---

## 2. 方案对比

### 2.1 Plan 当前方案：per-collection 分片 + 渐进迁移

- 为 3 个 Expert（crop_compare / roi_analysis / pest_risk）各建独立 collection
- 从全量 `farm_agent` collection 按 cateId 迁移文档
- `grounding.ready()` 判断走新路径还是降级路径
- 未迁移 Expert 继续走 `where` 子句降级

**优点**：
- 不阻塞原则：迁移期间旧路径持续生效
- 降级路径保留为永久 fallback
- 证据链可溯源到具体 collection

**风险**：
- 只覆盖 3/11 Expert（27%），剩余 8 个无迁移 roadmap
- `agri_tech` 被 6 个 Expert 共享——per-collection 意味着同一文档 6 份副本，存储冗余约 16MB+
- `getChromaCollection()` 单例需改造，影响面大
- `searchKnowledgeDocuments()` 签名扩展不明确（`collectionName` 与 `where` 互斥还是叠加？）

### 2.2 替代考量（未在 Plan 中探讨）

**方案 B：ChromaDB 多 collection + 视图/别名**（Plan 未提及）
- 共享 cateId 的文档存入一个"共享 collection"，各 Expert collection 通过逻辑引用指向
- 优点：避免文档重复存储
- 缺点：ChromaDB 原生不支持跨 collection 视图，需应用层实现路由

**方案 C：保持单 collection + 增强索引**（Plan 未提及）
- 利用 ChromaDB metadata 索引 + `where` 子句做精准过滤
- 优点：零架构改动，无数据迁移
- 缺点：未解决精度折损（全局检索仍是瓶颈）

**方案 D：两阶段检索**（Plan 未提及）
- Phase 1：全局粗检索 → Phase 2：Expert collection 精排
- 优点：兼顾召回率和精度
- 缺点：双倍 API 调用，延迟翻倍

---

## 3. 决策结论

**Plan 方向正确，但存在 4 个 ADD 范式合规缺陷和 3 个架构设计缺口，不可直接进入 Step 3。**

### 3.1 ADD 范式合规阻断项（P0）

| # | 缺陷 | 证据 | 修复 |
|---|------|------|------|
| 1 | 缺失 add-route | `check_add_route_status({ planKeyword: "Expert-Grounding" })` → `never_generated` | 回退 Step 0.5，生成 `Expert-Grounding-RAG适配-add-route-v1.md` |
| 2 | 缺失 specs 三元组 | Plan §7 关联文档中无 `.qoder/specs/` 引用 | 补建 `spec.md + tasks.md + checklist.md` |
| 3 | 缺失 Handoff | `glob(**/*handoff*)` → 0 结果 | 生成 `farm-agent-expert-grounding-handoff.md` |

### 3.2 架构设计缺口（P1）

| # | 缺陷 | 影响 | 修复 |
|---|------|------|------|
| 4 | Expert 迁移范围仅 3/11，无 roadmap | 8 个 Expert 留下未规划的债务 | Plan 中新增 §8 完整迁移路线图（Phase 1: 3 个 → Phase 2: 其余 → Phase 3: 汇总 Expert） |
| 5 | `agri_tech` 被 6 个 Expert 共享，per-collection 冗余 | 约 16MB+ 额外存储 | Plan 中明确策略：复制（首期）+ 后续评估引用方案 |
| 6 | `getChromaCollection()` 单例改造方案未定义 | Phase 3 检索路径切换无技术方案 | Plan 中补充 `ChromaCollectionManager` 多 collection 管理设计 |
| 7 | `searchKnowledgeDocuments()` 新签名未定义 | 检索节点无法对接 | Plan Phase 3.1 中给出新签名示例 |
| 8 | **裁决层 `RetrieveBudget` 缺失 per-expert topK 分配** | per-collection 检索下每人搜几条未定义，retrieval 节点无法获取 per-expert topK | `sub-intent.ts` 中 `RetrieveBudget` 接口新增 `perExpertTopK: Record<expertId, number>`，`resolveRetrieveBudget()` 按 Expert 属性分配（核心 5 / 汇总 10） |

### 3.3 中等问题（P2）

- 汇总 Expert（daily_report / weekly_report）在 per-collection 模型下的 collection 策略未说明
- Embedding 重索引成本未评估（API 调用次数 + 时间窗口）
- Phase 编号（1-5）与 ADD Step（0-8）编号冲突，建议改为 "Task 组 A-E"

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 影响 | 改动风险 |
|------|------|:--:|
| `src/services/knowledge-indexer.ts` | `getChromaCollection()` 从单例改为多 collection 管理 | 🔴 高 |
| `src/agents/nodes/retrieval.ts` | 检索路径从 `where` 子句切换为 `collectionName` | 🔴 高 |
| `src/agents/experts/registry.ts` | `AnalysisExpert` 接口新增 `grounding` 字段 | 🟡 中 |
| `src/agents/experts/filter-types.ts` | 新增 `GroundingStatus` 类型 | 🟢 低 |
| `src/agents/types/index.ts` | `Evidence` 新增可选 `grounding` 字段 | 🟢 低 |
| `src/caijuehub/strategies/sub-intent.ts` | `RetrieveBudget` 新增 `perExpertTopK` | 🟡 中 |
| `scripts/init-chroma-collection.ts` | 新增多 collection 创建/同步脚本 | 🟡 中 |
| ChromaDB 集群 | 3 个新 collection + 文档迁移 | 🔴 高 |

### 4.2 数据流影响

```
当前:
  retrieval → searchKnowledgeDocuments(query, k, undefined, expertWhere)
           → ChromaDB 单 collection + where 过滤

迁移后:
  裁决层 → resolveRetrieveBudget(experts) → perExpertTopK: { pest_risk: 5, crop_compare: 5, ... }
         ↓
  retrieval → grounding.ready()
           ├─ ready=true  → searchKnowledgeDocuments(query, perExpertTopK[expertId], { collectionName })
           └─ ready=false → searchKnowledgeDocuments(query, perExpertTopK[expertId], { where }) 降级
         ↓
  evidenceChain: 每条 evidence 直接标注 expertIds: [expertId]（不再通过 cateId 反向映射）
```

**关键风险点**：
- 迁移期间新旧路径共存，`evidence.source` 格式不一致（`chroma_doc_xxx` vs `expert:pest_risk/chroma_doc_xxx`）
- `reasoning` 节点按 `evidence.expertIds` 分组，需向后兼容两种 source 格式

### 4.3 回滚风险

- ChromaDB collection 创建后**不可逆删除**（Plan §5 保留全局 collection，正确 ✅）
- `searchKnowledgeDocuments()` 签名变更后，所有调用方需同步更新
- 文档迁移用复制而非移动——回滚只需切换检索路径回 `where` 子句即可

---

## 5. 最终建议

**推荐执行顺序**：
1. 补齐 ADD 文档基础设施（add-route + specs 三元组 + Handoff）——P0
2. 裁决层 `RetrieveBudget` 接口变更 + `resolveRetrieveBudget()` per-expert topK 分配——P1
3. 明确 Expert 迁移 roadmap（Phase 1: 3 个 → Phase 2: 其余 8 个）——P1
4. 定义 `getChromaCollection()` 多 collection 改造方案——P1
5. 评估 embedding 成本 + 确定 `agri_tech` 共享策略——P2
6. 以上全部补齐后重新调用 `check_add_route_status` + `check_add_route_completeness` 验证，通过后方可进入 Step 3
