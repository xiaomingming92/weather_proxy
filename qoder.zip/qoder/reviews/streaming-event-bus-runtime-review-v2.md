# Review: 流式事件总线 GUI 端点遗漏 + 下游事件类型同步 — 运行时验证 v2

> **修订记录**
> - 2026-06-25: v1 — AuditLog 写入策略诊断
> - 2026-06-26: v2 — GUI 端点 stream-bus 注册遗漏 + 下游 Plan 新增事件类型未回流

## Review 元信息

- **Review 对象**: `streaming-event-bus-plan-v1` 实施产物 + 下游 `farm-agent-domain-vocabulary-plan-v1` 新增事件
- **Review 时间**: 2026-06-26
- **Review 类型**: 运行时 review（领域词汇注入功能交付后的下游同步检查）
- **触发条件**: `farm-agent-domain-vocabulary-plan-v1` 验收完成，审查下游消费者同步状态
- **前置阅读**:
  - Plan: `.qoder/plans/2026-05/18/streaming-event-bus-plan-v1.md`
  - Plan: `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-plan-v1.md`
  - Review v1: `.qoder/reviews/streaming-event-bus-runtime-review-v1.md`

---

## 1. 发现列表

> F1/F2 已在 v1 解决，序号延续。

### F3 [HIGH] GUI 端点从未注册 stream-bus，新事件不可达

| 维度 | 内容 |
|:--|:--|
| **现象** | `farm-agent-domain-vocabulary-plan-v1` 新增的 `ParamMissingEvent` 通过 `emitStreamEvent()` 发出后，GUI（`/api/agent/stream` + `/api/agent/resume`）无法接收。H5 端点和 Hash 端点正常接收。 |
| **根因** | `streaming-event-bus-plan-v1` 原始 ADD-7 审计表 L21 标注 `src/app/api/agent/chat/stream/route.ts` 已注册 stream-bus，但该路由已迁移为 `/api/agent/stream`（当前文件），**新路由未包含 `registerStreamBus`**。Hash 和 H5 端点在后续 Plan 中补齐了注册，GUI 端点被遗漏。 |
| **影响** | `param_missing` 事件在 GUI 端不可达；未来任何新增 `StreamEvent` 类型同样不可达 |
| **代码定位** | `src/app/api/agent/stream/route.ts` L27-50 — `for await (const chunk of agentStream)` 仅处理 `__interrupt__` 和 `messages`，无 `registerStreamBus`；`src/app/api/agent/resume/route.ts` 同样缺失 |

#### 三端点对比

| 端点 | stream-bus 注册 | param_missing 可达 |
|------|:--:|:--:|
| Hash (`/api/agent/[hash]`) | ✅ L589 | ✅ |
| H5 (`/api/h5/agent`) | ✅ | ✅ |
| GUI (`/api/agent/stream`) | ❌ | ❌ |
| GUI resume (`/api/agent/resume`) | ❌ | ❌ |

### F4 [MEDIUM] 下游 Plan 新增 StreamEvent 类型未回流至源 Plan

| 维度 | 内容 |
|:--|:--|
| **现象** | `farm-agent-domain-vocabulary-plan-v1` 在 `stream-bus.ts` 中新增 `ParamMissingEvent` 类型和 `STREAM_BUS_EMIT_PARAM_MISSING` phase，但源 Plan `streaming-event-bus-plan-v1.md` 的 `StreamEvent` 联合类型列表（L152-200）和 AuditPhase 枚举（L34-47）未同步更新 |
| **根因** | ADD-12 双源头漂移：下游 Plan 修改了上游 Plan 创建的基础设施，但未回流到源文档 |
| **影响** | 后续 AI Session 读 `streaming-event-bus-plan-v1.md` 时，事件类型列表不完整 |

---

## 2. 关联 Plan 拓扑

```
streaming-event-bus-plan-v1.md (源)
  │
  ├── 创建 stream-bus.ts + StreamEvent 类型
  │
  ├→ farm-agent-ruifengyun-h5-api-plan-v2.md (消费者)
  │     H5 端 registerStreamBus ✅
  │
  ├→ farm-agent-domain-vocabulary-plan-v1.md (扩展者)
  │     新增 ParamMissingEvent ★ 未回流至源 Plan
  │
  └→ GUI 端点 (遗漏消费者)
       /api/agent/stream + /api/agent/resume
       registerStreamBus ❌
```

---

## 3. 修复方案

### 3.1 F3 修复：GUI 端点补齐 stream-bus 注册

**涉及文件**：
- `src/app/api/agent/stream/route.ts` — 新增 `registerStreamBus` + `GlobalStateProvider` + `CognitiveEventBus`（对齐 Hash 端点 L583-596 模式）
- `src/app/api/agent/resume/route.ts` — 同上

**对应 Plan**：建议生成 Runtime 纠正 Plan `farm-agent-domain-vocabulary-param-missing-gui-runtime-fix-plan-v1.md`，父 Plan 为 `farm-agent-domain-vocabulary-plan-v1`

### 3.2 F4 修复：源 Plan 增量更新

**涉及文件**：
- `.qoder/plans/2026-05/18/streaming-event-bus-plan-v1.md` — §2.2 新增 `param_missing` 事件类型 + §2 AuditPhase 增 `STREAM_BUS_EMIT_PARAM_MISSING` + ADD-7 审计表新增 `stream-bus.ts` 的 MODIFY 行

---

## 4. 教训

### 4.1 基础层 Plan 的消费者审计应覆盖全部端点

`streaming-event-bus-plan-v1` 创建了 stream-bus 基础设施，但审计表只覆盖了 `chat/stream/route.ts` 这一个消费者。生产环境有 3 个消费者（Hash / H5 / GUI），路由迁移后更有可能丢失注册。

**修正**：基础设施层 Plan 的审计策略应显式列出所有消费者端点及其注册状态。

### 4.2 下游 Plan 新增类型应回流至上游 Plan

ADD-12 不仅适用于"代码 → 文档"方向，也适用于"下游 Plan → 上游 Plan"方向。修改共享基础设施时，必须追溯到创建该基础设施的源 Plan 并同步更新。

---

## 5. 回流确认

- [x] F3/F4 发现已记录至本 review
- [ ] F3 修复：Runtime 纠正 Plan 待生成
- [ ] F4 修复：`streaming-event-bus-plan-v1.md` 增量更新待执行
- [ ] 流程改进项待写入 `checklist-template.md`（消费者审计覆盖检查）
