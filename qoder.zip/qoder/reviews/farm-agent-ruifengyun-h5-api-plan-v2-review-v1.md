# farm-agent-ruifengyun-h5-api-plan-v2-review-v1

## Review 元信息

- **Review 对象**: `farm-agent-ruifengyun-h5-api-plan-v2.md`
- **对比方案**: 当前 v1 实现 vs v2 改造方案
- **Review 时间**: 2026-06-22
- **Review 类型**: 架构改造评审
- **前置阅读**: 
  - Plan v2: `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v2.md`
  - Plan v1: `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v1.md`
  - Spec v2: `.qoder/specs/farm-agent-ruifengyun-h5-api-v2/spec.md`
  - API 对接文档: `docs/大田精准耕播智能决策系统/knowledge/02-规范/瑞丰耘H5小程序API对接文档.md`

---

## 1. 总体结论

**方向正确，具备执行基础。** 三项改造（服务账户认证、路径业务化、计划生成端点）均对应用户明确的架构需求，变更范围可控，风险点可识别。存在 2 个 P1 问题需在实施前确认，2 个 P2 建议改进。

---

## 2. 正向评价

- ✅ **认证方案选择合理**：API Key 方案与当前架构的 caijuehub 裁决模式天然兼容，双通道设计保留旧 sessionId 兼容，降低过渡风险
- ✅ **路径重构最小化**：仅迁移 3 个端点目录，不涉及代码逻辑变更，后续通过 Next.js App Router 的目录路由自动生效
- ✅ **聊天端点改造清晰**：body.userId 直通 ChatThread，绕过 h5-handshake-thread 裁决层，链路更短
- ✅ **分阶段策略务实**：阶段1 假数据优先打通认证+路径链路，降低小程序后台等待成本
- ✅ **文档先行到位**：API 对接文档 v2.0 已同步更新，SSE 协议文档详细

---

## 3. 问题清单

### P1-1：ServiceAccount 种子数据生成机制不明确

- **问题**：Plan §3.1 描述 "API Key 生成：svc_ + randomUUID，存储时 SHA-256 哈希"，但未说明 API Key 如何分发给小程序后台。是管理员手动创建，还是提供管理接口？
- **影响**：如果无分发机制，小程序后台无法获得 Key，链路无法验证
- **建议**：在 Task 1 中增加 "提供命令行脚本或管理 API 创建 ServiceAccount 记录，输出明文 API Key（仅创建时可见）"

### P1-2：服务账户的 Farm-Server token 来源未定义

- **问题**：Plan §3.3 说"服务账户的 token 由管理员手动配置（长期有效）"，但未说明 token 从哪里来——是用哪个 Farm-Server 用户的 token？
- **影响**：token 缺失导致 Farm-Server API 调用失败（地块查询、气象数据等全部不可用）
- **建议**：在 Plan §3.3 中明确：复用现有 Farm-Server 管理员账户 token，或独立创建服务账户并申请 token。实施前确认 Farm-Server 对 userId=0 的权限策略

### P2-1：旧路径 404 无重定向

- **问题**：Plan 设计旧路径 `/api/h5/land-analysis` 直接返回 404，无 301 重定向
- **影响**：如果已有第三方缓存或书签指向旧路径，用户会直接看到 404
- **建议**：保留旧路径并返回 301 重定向到新路径（Next.js redirect 配置），避免硬断裂
- **评估**：由于小程序后台从未对接过旧路径（前端直连已废弃），无兼容负担 → 降级为 P2

### P2-2：generate 端点假数据结构与 demo 不完全对齐

- **问题**：demo 页面 `https://80retros.com/wrnc/06/plan/new` 的计划生成步骤具有 7 个生育期阶段 + 4 类物资 + 风险提示，当前假数据仅示例了 1 个阶段 + 1 类物资
- **影响**：小程序前端按 demo 结构渲染时，假数据可能因字段缺失导致 UI 异常
- **建议**：假数据至少覆盖完整的 growthSchedule（7 阶段）、materials（种子/基肥/分蘖肥/农药）、risks（4 条），与 demo 页面结构 1:1 对齐

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 操作 | 风险 |
|------|------|------|
| `prisma/schema.prisma` | 新增 ServiceAccount 模型 | 低（新增表，不影响现有） |
| `h5-auth-gateway.ts` | 签名变更（加 apiKey 参数） | 中（所有调用方需更新） |
| `3 个 production-plan route.ts` | 目录迁移 + 认证切换 | 中（路径变更，旧路径失效） |
| `agent/route.ts` | 移除 handshake 分支 | 低（功能删除） |
| `handshake/route.ts` | 删除 | 低（废弃端点） |

### 4.2 数据流影响

- 认证链路：`X-Session-Id → H5Session.userId → FarmServerCredential` 变为 `X-Api-Key → ServiceAccount → FarmServerCredential(userId=0,source="service")`。后者 token 由管理员维护，不经过 per-user refresh 循环
- 线程链路：`h5-handshake-thread 裁决 → ChatThread` 变为 `body.userId 直通 ChatThread`。线程仍按 `(userId, source="h5")` 隔离，数据结构不变

### 4.3 回滚风险

- **低风险**：Prisma migrate 可回滚（新建表无破坏性），路径迁移可反向操作
- **需注意**：API Key 分发后如需轮换，需同时更新小程序后台和数据库

---

## 5. 建议修正优先级

| 优先级 | 编号 | 问题 | 动作 |
|:--|:--|:--|:--|
| 🔴 高 | P1-1 | API Key 分发机制 | 实施前补充脚本/管理接口 |
| 🔴 高 | P1-2 | Farm-Server token 来源 | 实施前确认并可获取 |
| 🟡 中 | P2-1 | 旧路径 404 | 降级为 P2（无兼容负担），可忽略 |
| 🟡 中 | P2-2 | 假数据结构完整性 | 实施时确保与 demo 页面结构对齐 |

---

## 6. 最终建议

1. **P1-1/P1-2 确认后即可进入 Step 1 编码**——两个问题都是"实施前需确认"而非"方案需重设计"
2. 实施顺序建议：Task 1(ServiceAccount) → P1-1 脚本 → P1-2 token 确认 → Task 2(auth-gateway) → 其余 Task
3. DPS 回流：P1-1 写入 Plan §3.1 补充 "API Key 分发机制"，P1-2 写入 Plan §3.3 明确 "Farm-Server token 来源"
