# farm-agent-unpdf-migration-runtime-review-v1

> 运行时验证纠偏文档。触发方式：用户报告 + SSE 日志。

## Review 元信息

- **关联方案 review**: 无（Plan 未经过 ADD 方案 review）
- **关联实现 review**: 无（Plan 未经过 ADD 实现 review）
- **关联 Plan**: `.qoder/plans/farm-agent-unpdf-migration-plan-v1.md`
- **Review 时间**: 2026-06-23
- **触发方式**: 用户报告（`curl .../progress` → SSE `ERROR: Invalid PDF structure`）+ 日志分析

---

## 问题优先级总览（P0/P1/P2 回流校验）

| # | 严重度 | 标题 | Plan 回流位置 | 状态 |
|---|:---:|------|-------------|:---:|
| 1 | P0 | OCR 文本被当 PDF 二次解析 | §3.2 OCR→索引桥接协议 + Task 12/13 | ✅ 已回流 |
| 2 | P0 | Plan 未经过 ADD review | §元信息 关联文档 + §六 | ✅ 已回流 |
| 3 | P1 | Plan 文档漂移（worker_threads→fork/spawn） | §3.2 架构图 + §四 Task 9/10/12/13 + §五 验收标准 + §7.3 | ✅ 已回流 |
| 4 | P2 | ChromaDB 单 chunk 写入失败无重试 | — | 已知不处理（后续版本改进） |

**P0/P1 回流确认**：
- P0#1: OCR 文本被当 PDF 二次解析 → 已回流至 Plan §二 方案选型 + §三 架构设计
- P0#2: Plan 未经过 ADD review → 已回流至 Plan 元信息关联文档 + §六
- P1#3: Plan 文档漂移 → 已回流至 Plan 全文 child_process.spawn 规范

---

## 1. 发现列表

### 发现 #1：OCR 文本被当 PDF 二次解析——Plan 架构未定义 OCR→索引的桥接协议

**现象**：

SSE 流正常输出 OCR 进度 `(1/3页)` → `(2/3页)` → `OCR完成, 正在向量化...`，随后抛出 `"Invalid PDF structure."`：

```
data: {"status":"OCR_PROCESSING","message":"OCR识别中 (2/3页)","progress":42}
data: {"status":"INDEXING","message":"OCR完成, 正在向量化...","progress":60}
data: {"status":"PARSING","message":"正在解析文档内容...","progress":10}
data: {"status":"ERROR","message":"Invalid PDF structure."}
```

**根因**：

`route.ts:103` OCR 完成回调中：
```typescript
await indexKnowledgeDocumentWithProgress(id, Buffer.from(ocrText), doc.name, ...)
```

`ocrText` 是纯文本字符串（OCR 识别结果），`Buffer.from(ocrText)` 只是把字符串编码为 UTF-8 字节。但 `indexKnowledgeDocumentWithProgress` 内部第 120 行无条件执行：
```typescript
const parsed = await parseDocumentFromBuffer(buffer, fileName)  // ← 当 PDF 解析
```
unpdf 收到的是一坨 UTF-8 文本字节，无法匹配 PDF 文件头，抛出 `Invalid PDF structure`。

**后果链**：

1. OCR 子进程成功跑完 3 页，纯文本已正确返回
2. 纯文本被包成 `Buffer` 传入 `indexKnowledgeDocumentWithProgress`
3. `parseDocumentFromBuffer` 当 PDF 解析，unpdf 报错
4. 用户看到 OCR 进度条走到 42%，然后跳回 PARSING 阶段又崩溃
5. 扫描件 PDF 的端到端索引路径不可用

**修复方向**：

方案 A（侵入性小）：`indexKnowledgeDocumentWithProgress` 新增 `rawText?: string` 参数。OCR 场景传 `rawText: ocrText`，跳过 `parseDocumentFromBuffer`，直接用文本做 smartChunk + embedding。

方案 B（更干净）：OCR 完成回调不调 `indexKnowledgeDocumentWithProgress`，直接在 route.ts 中 inline chunk → embed → ChromaDB。但需复制分块/embed 逻辑。

**推荐方案 A**：改动最小，签名向后兼容，调用方只需加一个参数。

#### 为何前置 review 遗漏

1. **Plan 未经过任何 ADD review**（scheme/implementation/runtime 三层全跳过），缺少"审查 OCR 文本和索引函数之间的数据流"这一环节
2. **Plan §3.2 架构图是粗粒度线框图**：画了"Worker done → chunk → embed"，但 `chunk → embed` 这个箭头内部调了 `parseDocumentFromBuffer`，Plan 没有标注这个调用
3. **`indexKnowledgeDocumentWithProgress` 的输入假设是"文件 Buffer"**，但 OCR 场景下这个 Buffer 不是"文件内容"而是"识别结果"。函数签名没有区分这两种语义

---

### 发现 #2：Plan 未经验证就进入实施——Phase 3 架构存在设计级缺口

**现象**：

全程缺失 ADD review 文件。无方案 review（Step 0 前）、无实现 review（Step 4 后）、无运行时 review。

**根因**：

Plan §二~三 定义了"Worker Thread OCR → chunk → embed → ChromaDB"的粗粒度流程，但没有定义 OCR 输出文本如何进入 `indexKnowledgeDocumentWithProgress`。这导致实现时做了隐式假设：OCR 文本可以当 Buffer 传入索引函数。

**后果链**：

1. 没有任何 review 指出 Plan §3.2 的数据流缺口
2. 实现时填入 `Buffer.from(ocrText)` 是唯一"看起来能编译"的选择
3. 运行时才发现 `parseDocumentFromBuffer` 不认纯文本

#### 为何前置 review 遗漏

**没有做前置 review**。Plan 从生成到实现之间没有任何质量门禁。

---

### 发现 #3：Plan 文档漂移——实际实现与 Plan 多处不一致

**现象**：

Plan §二 选型结论标注 `@napi-rs/canvas` "❌ 待安装"，但实际项目已安装并使用。
Plan §二 选型表格推荐 `unpdf ^1.6.2`，实际 `package.json` 中版本未核实。
Plan §3.2 架构图使用 `worker_threads`，实际实现使用 `child_process.fork`。
Plan §3.2 Task 9 描述 `worker_threads.parentPort`，实际 ocr-worker.ts 使用 `process.send`。
Plan §3.2 Task 12 说 `indexKnowledgeDocumentWithProgress` 不修改，但实际需要改（发现 #1）。

**根因**：

ADD-12 原则（代码后回看架构文档）未执行。每次修完 bug（env→stdin→临时文件→fork→spawn）后，Plan 没有同步更新。

**修复方向**：

在修复发现 #1 后，更新 Plan 将所有"worker_threads"改为"child_process.fork"，补充 OCR→索引的桥接协议，标注 `indexKnowledgeDocumentWithProgress` 的 `rawText` 参数。

---

### 发现 #4：错误路径与降级处理覆盖度审查

**现象**：DPS Review 维度缺失「错误路径/降级处理」覆盖。

**根因**：本 review 未系统性地逐错误路径审查降级机制完整性。

**逐路径审查**：

| 错误路径 | 降级机制 | 状态 |
|---------|---------|:---:|
| OCR 子进程异常退出 (code 1) | `onError` → SSE 推送 `ERROR: OCR失败: ...` | ✅ |
| OCR 子进程被取消 | `cancelJob` → `child.kill()` → 清理临时文件 → SSE 推送 `cancelled` | ✅ |
| `parseDocumentFromBuffer` 返回空内容 | `indexContent` 内 `throw Error("文档内容为空，无法向量化")` → SSE `ERROR` | ✅ |
| SmartChunker 分块失败 | 回退 `textSplitter.splitText` 固定长度分块 | ✅ |
| ChromaDB 单 chunk 写入失败 | 循环内无 try-catch，整个索引失败 → SSE `ERROR` | ⚠️ 建议加单块重试 |
| Expert Grounding 双写失败 | catch + `agentAudit` 日志，不阻断主流程 | ✅ |
| PDF buffer 读取失败 (ENOENT) | resolveFilePath 回退 `uploads/knowledge/fileName` → SSE `ERROR` | ✅ |
| 同步取消中间态残留 | `POST /sync/cancel` 清理 ChromaDB chunks + 回退 `PENDING_INDEX` | ✅ |
| **OCR 文本→索引管线断裂** | **无降级**（发现 #1 根因）→ 需要 `indexContent` 直入 | ❌ 待修复 |

**结论**：除 P0#1（OCR 文本→索引）外，当前错误路径覆盖完整。ChromaDB 单块失败为 P2 改进项，不阻塞。

#### 为何前置 review 遗漏

Review 模板中「错误路径/降级处理」是一个独立审查维度，但本 review 没有逐路径列举。根源是 review 聚焦于已发现的问题而非全量覆盖度审查。

---

## 2. review 流程改进项

| 检查项 | 具体操作 | 触发时机 |
|--------|---------|---------|
| Plan 必须在 Step 0 结束后通过 `check_dps`，DPS ≥ 85 | 调用 `check_dps({ planKeyword: "unpdf" })` | Step 0 末尾 |
| Plan 架构图必须包含数据流中每个函数调用 | 审视数据流中每个箭头对应的函数签名，确认输入类型匹配 | Plan review |
| OCR→索引的桥接协议必须在 Plan 中显式定义 | Plan §3 新增"OCR 文本与索引函数的桥接"子章节，定义 `rawText` 参数 | Plan 生成阶段 |
| 代码实现后必须更新 Plan（ADD-12） | 每次修 bug 后同步更新 Plan 中对应的架构/文件中描述 | Step 8 |

> 上述改进项应回流至 `review-implementation-template.md` 或 `checklist-template.md`，确保下次项目自动继承。

---

## 3. 已运行时修复项

无。等待 Plan 更新 + runtime review 确认后再实施修复。

---

## 4. 回流确认

- [x] 流程改进项已写入对应模板
- [ ] 修复项已记录审计日志（`record_dev_operation`）
- [x] Plan §3.2 已补充 OCR 文本→索引桥接协议（`indexContent` 分离）
- [x] Plan 中所有 `worker_threads` 引用已更新为 `child_process.fork/spawn`
- [x] Plan §四 Task 9-13 实现细节已纠正为实际方案（临时文件/spawn/process.send）
- [x] Plan 元信息已补充 runtime review 引用
