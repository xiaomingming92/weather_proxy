# farm-agent-gui-chat-enhancement-review-v1

## Review 元信息
- Review 对象: `farm-agent-gui-chat-enhancement-plan-v1.md` + specs 三元组
- Review 范围: agrisynapse 神经元 GUI + farm-agent 后端 API 修复
- Review 时间: 2026-06-15
- 结论级别: 可接受

## 1. 总体结论

方向正确。四个问题全部定位：历史对话 = LlmSidebar 硬编码 + 缺少 `action=threads` API；标题 = store 不调 PATCH；交互点 = agentChat 不处理 interactionPoint + LlmChatView 缺模板；历史 metadata = handleThreadGET 不返回 metadata。修复精准且范围锁定在 agrisynapse 神经元 + farm-agent API，不碰 farm-agent ChatPanel/ChatContainer。

## 2. 正向评价

- ✅ 准确定位 `handleThreadGET` 不返回 metadata 的根因
- ✅ 交互点数据流完整：response node → SSE → agentChat dispatch → LlmChatView template
- ✅ 不扩界：不碰 farm-agent GUI 组件
- ✅ 线程列表 API 复用 `chatPersistence.getThreadsByUser`

## 3. Review 维度覆盖

| 维度 | 状态 | 说明 |
|------|------|------|
| 错误路径/降级处理 | ✅ | PATCH 失败乐观更新，fetchThreads 失败降级，metadata=null 兼容 |
| 兼容性/向后兼容 | ✅ | 所有新字段 optional，不破坏现有类型 |
| 数据模型/类型定义 | ✅ | StreamingMessage 新增 interactionPoint?，InteractionPoint 复用已有类型 |
| 存储/索引成本 | ✅ | 无新增存储（不改 Prisma） |

## 4. 问题清单

| # | 严重程度 | 描述 | 修正建议 |
|---|---------|------|---------|
| P0 | P0 | `handleThreadGET` 返回的 message `metadata` 可能为 null（老消息无 structured data），前端不处理会导致 undefined 错误 | 前端 `loadThread` 用 `msg.metadata ?? {}` 兜底 |
| P1 | P1 | agrisynapse `getThreads` 需要 userId 参数，hash-only 模式下 userId 从何处获取未明确 | 复用 `getCurrentUserId()` 或从 store state.userId 读取 |
| P1 | P1 | 交互点 options 字段缺失时无兜底 | LlmChatView template 用 `opt.label ?? "选项"` |
| P2 | P2 | LlmSidebar historyThreads 为空数组时显示空白区 | 加 v-if="historyThreads.length > 0"，否则保持现有 3 条硬编码 |

## 5. 影响评估

无破坏性变更。所有新增字段均为 optional。agrisynapse index.vue navSections 从硬编码改为 computed，已保留硬编码 fallback。

## 6. 最终建议

按 Task 1→6 顺序执行，Task 1-3 可并行。
