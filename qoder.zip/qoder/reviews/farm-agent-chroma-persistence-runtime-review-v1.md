# Review: ChromaDB 数据持久化失效 — 运行时验证

> **修订记录**
> - 2026-06-11: 初版，RAG 检索返回 0 触发运行时诊断

## Review 元信息

- **Review 对象**: podman 数据卷拆离 Plan 实施产物 + RAG 审计加固 Plan 实施产物
- **Review 时间**: 2026-06-11
- **Review 类型**: 实现 review（代码落地后的运行时验证）
- **触发条件**: GUI 文档列表 API 返回 0 + RAG 搜索 `collectionCount: 0`
- **前置阅读**:
  - Plan: `.qoder/plans/farm-agent-podman数据卷拆离统一-datadir-plan-v1.md`
  - Handoff: `.qoder/plans/farm-agent-podman数据卷拆离统一-datadir-handoff-v1.md`
  - Plan: `.qoder/plans/farm-agent-rag-audit-stacktrace-plan-v1.md`

---

## 1. 问题复现

### 1.1 症状

| 现象 | 审计日志证据 |
|------|------------|
| RAG 搜索始终返回 0 条结果 | `[RAG_SEARCH] {"resultCount":0,"collectionCount":0,...}` |
| 文档列表 API 返回 0 | `GET /api/knowledge/documents` → `{"success":true,"data":[],"total":0}` |
| 专家过滤降级后仍为 0 | `[RAG_EXPERT_FILTER_EMPTY] {"fallbackResultsCount":0}` |
| 所有查询均触发 `RAG_EMPTY` | `"suggestion":"请先同步知识库或检查 sourceType 过滤条件"` |

### 1.2 崩溃链路

```
用户提问 → intention → retrieval → searchKnowledgeDocuments()
                                      │
                                      ▼
                              ChromaDB query → collectionCount: 0
                                      │
                                      ▼
                              返回空数组 → RAG_EMPTY
                                      │
                                      ▼
                              LLM 零证据凭空回答
```

---

## 2. 根因分析

### 2.1 直接根因：PERSIST_DIRECTORY 与 volume 挂载路径不匹配

| 配置项 | 值 | 容器内实际路径 |
|--------|-----|--------------|
| `volumes` | `${DATA_DIR}/chroma:/chroma/chroma:Z` | 宿主机 → 容器 `/chroma/chroma` |
| `PERSIST_DIRECTORY` | `/data` | ChromaDB 写到 `/data` |

**两条路径不一致**。ChromaDB 把 sqlite3 + 向量文件写入 `/data/`（容器临时层），volume 挂载在 `/chroma/chroma`（空目录，宿主机持久化）。容器重启后 `/data/` 丢失。

### 2.2 受影响文件清单（4 处同型 bug）

| # | 文件 | 行号 | volume 目标 | PERSIST_DIRECTORY | 匹配 |
|---|------|------|------------|-------------------|:---:|
| 1 | `podman-compose.yml` | L52, L57 | `/chroma/chroma` | `/data` | ❌ |
| 2 | `docker-compose.yml` | L52, L57 | `/chroma/chroma` | `/data` | ❌ |
| 3 | `scripts/db-ensure.sh` | L82, L86 | `/chroma/chroma` | `/data` | ❌ |
| 4 | `scripts/start-infrastructure.sh` | L64 | 日志打印 `${DATA_DIR}/chroma` | 实际写入 `/data` | ❌ |

### 2.3 容器运行时证据

```
podman inspect farm-agent-chroma:
  Mount: Source=/home/xmm/data/farm-agent/chroma → Destination=/chroma/chroma
  Env:   PERSIST_DIRECTORY=/data

容器内:
  /data/          → chroma.sqlite3 (188KB, 空集合)  ← 临时层，重启丢失
  /chroma/chroma/ → 空                                ← volume 挂载点，无数据写入
```

### 2.4 传播链：从 co-agent 继承的配置缺陷

```
co-agent 原始配置:
  volume: ./data/chroma:/chroma/chroma    ← ChromaDB 旧版默认路径
  PERSIST_DIRECTORY: 未设置               ← 旧版默认 /chroma/chroma，匹配 ✓

farm-agent 迁移时:
  volume: ${DATA_DIR}/chroma:/chroma/chroma  ← 路径不变
  PERSIST_DIRECTORY: "/data"                 ← ⚠️ 新增了环境变量，改为 /data
  → 不匹配！volume 没跟着改

podman 数据卷拆离 Plan:
  volume: ${DATA_DIR}/chroma:/chroma/chroma  ← 只改了 Source 端（宿主机路径）
  PERSIST_DIRECTORY: "/data"                 ← 未审查 Destination 端
  → 缺陷被原样保留
```

---

## 3. 数据丢失影响分析

### 3.1 数据资产现状

| 位置 | 内容 | 状态 |
|------|------|------|
| `data/exports/chroma-export-2026-05-29T07-06-01-721Z.json` | 16MB，farm_agent 集合，text-embedding-v4 1024维 | ✅ 完好 |
| `/home/xmm/data/farm-agent/chroma/` | 空目录 | ❌ 数据未迁移至此 |
| `/home/xmm/data/farm-agent/postgres/` | PG 数据 | ✅ PG 迁移成功 |
| 容器内 `/data/` | 188KB sqlite3（空集合） | ⚠️ 临时层，重启即失 |
| VPS `/data/` | 8.5MB sqlite3 + 向量文件 | ⚠️ 临时层，重启即失 |

### 3.2 VPS 同样受影响

VPS（rfai）同样配置，但数据暂存于容器临时层（8.5MB）。**VPS 容器一旦重启，RAG 数据将同样丢失**。

### 3.3 迁移 Plan 的遗漏点

Handoff 文档中 `DB_MIGRATE_COPY_CHROMA` 记录为"检查"而非实际复制。根因：

1. 旧 `./data/chroma/` 目录本来就是空的（ChromaDB 旧版也可能写到容器临时层）
2. 迁移 Plan 只关注了 Source 端（宿主机路径从 `./data/` → `${DATA_DIR}/`），未审查 Destination 端（容器内挂载目标是否匹配 PERSIST_DIRECTORY）

---

## 4. review2 的结构性盲区复盘

| # | 未审查项 | 后果 | 应在哪个环节捕获 |
|---|---------|------|-----------------|
| 1 | `PERSIST_DIRECTORY` 与 volume Destination 路径一致性 | ChromaDB 数据完全不持久化 | Plan §1.1 的 compose 文件逐行对比 |
| 2 | 迁移后 ChromaDB `collectionCount` 验证 | 数据丢失未被发现 | Plan §4.1 验证检查（缺少 curl ChromaDB 验证步骤） |
| 3 | db-ensure.sh 的 fallback `podman run` 命令 | 同样包含 `/chroma/chroma` + `/data` 不匹配 | Plan §1.5 变更清单未覆盖 db-ensure.sh 的 chroma 启动命令 |
| 4 | export 文件未作为数据恢复兜底 | 16MB 导出文件闲置，未被关联到恢复流程 | Handoff §3.3 数据回滚方案只提到 `cp -a ./data/chroma/*`，未提 export JSON |
| 5 | VPS 与本地配置一致性审计 | VPS 同样有此 bug | Plan 只关注本地，无 VPS 对照验证 |

---

## 5. 修复方案

### 5.1 必须做（平衡点 — 最小有效修复）

**修复 volume Destination 路径**：`/chroma/chroma` → `/data`，匹配 `PERSIST_DIRECTORY`。

| # | 文件 | 改动 |
|---|------|------|
| 1 | `podman-compose.yml` L52 | `${DATA_DIR}/chroma:/chroma/chroma:Z` → `${DATA_DIR}/chroma:/data:Z` |
| 2 | `docker-compose.yml` L52 | `${DATA_DIR}/chroma:/chroma/chroma` → `${DATA_DIR}/chroma:/data` |
| 3 | `scripts/db-ensure.sh` L82 | `-v "$DATA_DIR/chroma:/chroma/chroma"` → `-v "$DATA_DIR/chroma:/data"` |

**修复后重启容器 + 数据恢复**：
1. 停 chroma 容器
2. 修正 compose 文件
3. 重启容器
4. 用 `chroma-export-2026-05-29T07-06-01-721Z.json` 恢复数据（或重新同步知识库）

### 5.2 增强项（按需）

- 在 `start-infrastructure.sh` 启动后加一步 ChromaDB `count` 验证
- 在 Plan 验证检查清单中增加 `curl localhost:8000/api/v2/tenants/default_tenant/databases/default_database/collections` 验证步骤

### 5.3 独立问题

- VPS 需同步修复（相同配置）
- export JSON 文件应纳入数据恢复方案文档

---

## 6. 教训

### 6.1 配置变更的"对称审查"原则

修改 volume 配置时，必须同时审查 Source（宿主机路径）和 Destination（容器内路径）两端，并与应用程序实际读写路径交叉验证。

```
审查清单:
  [ ] volume Source → 宿主机持久化路径
  [ ] volume Destination → 容器内应用读写路径
  [ ] 应用配置（如 PERSIST_DIRECTORY）→ 容器内路径
  [ ] 三者一致性 ✓
```

### 6.2 基础设施 Plan 的运行时验证必须包含"数据存在性"检查

Plan §4.1 的验证清单只检查了：
- ✅ `podman inspect` 挂载源路径
- ✅ 服务 HTTP 200

缺了最关键的一步：
- ❌ ChromaDB collection 有数据

**修正**：所有涉及数据存储的基础设施变更，验证清单必须包含"数据存在性"断言。

### 6.3 从 co-agent 继承配置时的"环境变量审计"

`PERSIST_DIRECTORY: "/data"` 是 farm-agent 新增的环境变量（co-agent 未设置，使用默认 `/chroma/chroma`）。迁移时只改了 volume Source 端，未审查新增环境变量对 Destination 端的影响。

**修正**：从其他项目继承配置时，diff 对比所有新增/修改的环境变量，逐一审查其对已有配置项的影响。
