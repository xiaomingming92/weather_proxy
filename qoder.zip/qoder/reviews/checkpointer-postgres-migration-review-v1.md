# checkpointer-postgres-migration-review-v1

## Review 元信息

- **Review 对象**: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-plan.md` + `.qoder/specs/checkpointer-postgres-migration/` 三元组
- **对比方案**: 单一方案（`@langchain/langgraph-checkpoint-postgres`），无候选对比
- **Review 时间**: 2026-06-26
- **Review 类型**: 方案评审（ADD-9）+ 合规检查
- **前置阅读**:
  - Plan: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-plan.md`
  - Specs: `.qoder/specs/checkpointer-postgres-migration/` (spec.md + tasks.md + checklist.md)
  - Handoff: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-handoff.md`
  - ADD Route: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-add-route-v1.md`
- **结论级别**: 可接受（含 1 个 P0 修正 + 2 个 P1 补充）

---

## 1. 总体结论

方向正确，方案简洁，风险可控。`@langchain/langgraph-checkpoint-postgres` 是 LangGraph 官方 PostgreSQL 适配器，API 稳定，与已有 `@langchain/langgraph-checkpoint@^1.0.2` 兼容。

发现 1 个 P0 级问题（Plan 对 checkpointer 作用范围描述过窄）和 2 个 P1 级改进点（验收标准缺少多轮对话验证、Top-level await 风险未在 Spec 中显式记录）。P0 已在 Review 过程中修正。

---

## 2. 正向评价

1. **方案选型正确**：`PostgresSaver.fromConnString()` 复用已有 `DATABASE_URL`，零额外配置，且自带 `setup()` 自动建表
2. **MemorySaver fallback 设计合理**：PostgreSQL 不可用时降级为 MemorySaver + 日志告警，保证服务可用性优先
3. **变更范围精准**：仅改 4 个文件（package.json + 新建 checkpointer.ts + 修改 agents/index.ts + 扩展 AgentAuditPhase），不动 interrupt/resume 逻辑，风险边界清晰
4. **Specs/Handoff/Add-route 三元组完整**：文档链路齐全，原子闭包判定正确（单轮 = 1 个原子闭包）

---

## 3. 问题清单

### P0-1: Plan 对 checkpointer 作用范围描述过窄 ✅ 已修正

- **严重程度**: P0
- **描述**: Plan §1.1 原描述将 checkpointer 仅视为 interrupt/resume 的依赖，忽略了它在每次 graph 执行后保存状态的更基础作用。LangGraph checkpointer 在每次 `invoke/stream` 的每个节点执行后都会保存 checkpoint，同一个 `thread_id` 的后续调用从 checkpointer 加载历史状态——这包括消息历史、graph 状态、中间变量等。
- **实际影响**: PM2 重启后丢失的不只是"中断中的 thread"，而是**所有 thread 的全部历史对话状态**。用户可能感到"AI 不记得之前说了什么"，但不会看到显式报错（不像 resume 场景有 `"u is not async iterable"` 错误）。
- **修正**: 已在 Plan §1.1 补充 checkpointer 的完整作用描述，并区分"显式影响"（resume 报错）和"隐式影响"（多轮上下文丢失）。
- **回流位置**: Plan §1.1

### P1-1: 验收标准缺少多轮对话持久化验证

- **严重程度**: P1
- **描述**: Plan §4 验收标准仅聚焦于 interrupt/resume 场景（标准 1），未覆盖更基础的多轮对话持久化验证。应在验收标准中增加：重启前后同一 thread 的多轮对话上下文是否保持。
- **修正建议**: 在 Plan §4 验收标准中新增第 4 条：
  > 4. 发起多轮对话（同一 thread_id 多次 stream） → `pm2 restart farm-agent` → 再次发送消息（同一 thread_id） → AI 仍能引用之前的对话上下文（消息历史未丢失）
- **回流位置**: Plan §4

### P1-2: Spec 未覆盖 Top-level await 风险

- **严重程度**: P1
- **描述**: `createCheckpointer()` 是 async 函数，`src/agents/index.ts` 第 231 行的 `const checkpointer = await createCheckpointer()` 需要顶层 await。虽然项目 `package.json` 的 `"type": "module"` 和 Next.js 的 ESM 配置支持顶层 await，但 Handoff §7 提到此风险，Spec 的 Boundaries 中未显式记录。
- **修正建议**: 在 Spec §Boundaries 中增加一条：
  > 禁止使用非 ESM 模块加载方式（如 `require()`）引入 `src/lib/checkpointer.ts`——该模块依赖顶层 await
- **回流位置**: Spec §Boundaries

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 操作 | 风险等级 |
|------|------|:--:|
| `package.json` | MODIFY（新增依赖） | 低 — 仅新增，不移除 |
| `src/lib/checkpointer.ts` | CREATE | 低 — 独立模块，无耦合 |
| `src/agents/index.ts` | MODIFY（替换 checkpointer 实例化） | 中 — 核心编译入口点 |
| `src/lib/agent-audit-logger.ts` | MODIFY（新增 2 个 Phase 字面量） | 低 — 类型扩展，无逻辑变更 |

### 4.2 数据流影响

- **写入路径**: 每次 graph 节点执行后 → checkpoint 写入 PostgreSQL `langgraph_checkpoints` 表（而非进程内存）
- **读取路径**: 每次 `invoke/stream` 开始时 → 从 PostgreSQL 加载上次 checkpoint（而非进程内存）
- **对调用方**: 零影响——`agent.stream()` 和 `agent.invoke()` 签名不变，LangGraph API 对 checkpointer 透明

### 4.3 回滚风险

- 回滚代码后，PostgreSQL 中已写入的 `langgraph_checkpoints` 表数据不清理也不影响 MemorySaver 运行
- 唯一的风险是：如果 PostgreSQL 连接池耗尽，会触发 MemorySaver fallback，但此时回退到了变更前的同等行为（进程内存），不会更差

---

## 5. 建议修正优先级

| 优先级 | 问题 | 修正动作 |
|:--:|------|---------|
| P0 | Plan §1.1 作用范围过窄 | ✅ 已修正 |
| P1 | 验收标准缺多轮对话验证 | 补充 Plan §4 验收标准第 4 条 |
| P1 | Spec Boundaries 缺顶层 await 约束 | 补充 Spec §Boundaries |

---

## 6. 最终建议

**推荐执行**，P0 已在 Review 中修正。P1 两项在进入 Step 1 代码实现前补入 Plan/Spec 即可。

执行顺序：
1. 回流 P1-1 → Plan §4
2. 回流 P1-2 → Spec §Boundaries
3. DPS 闸门检查
4. Step 1-3 代码实现
