# audit-log-bypass-governance-review-v1

> ADD-9 方案评审：AuditLog 绕过治理 Plan

## Review 元信息

- **Review 对象**: `.qoder/plans/2026-06/25/audit-log-bypass-governance-plan-v1.md`
- **关联 Specs**: `.qoder/specs/audit-log-bypass-governance/` (spec.md + tasks.md + checklist.md)
- **关联 add-route**: `.qoder/plans/2026-06/25/audit-log-bypass-governance-add-route-v1.md`
- **触发来源**: `.qoder/reviews/streaming-event-bus-runtime-review-v1.md`（生产环境 AuditLog 表 30K 行中 90.7% 为逐字符垃圾）
- **Review 时间**: 2026-06-25
- **Review 类型**: 方案评审（架构决策 + 实施可行性）
- **结论级别**: ✅ 可接受 — Plan 方向正确、方案成熟、可进入实施

---

## 1. 总体结论

Plan 方向正确，问题定位精准（7 模块 10 处绕过 → 统一入口收敛），方案选型充分（Token 策略对比了 4 个方案、traceId 策略对比了 2 个方案），实施步骤依赖拓扑清晰。Plan 已包含 ADD-7 审计策略表、验收标准、关联文档全部链路。**可进入 Step 1 实施**，但需确认 MCP Server 的 `readdirRecursive` 修复已生效（DPS 闸门依赖此修复）。

---

## 2. 正向评价

### 2.1 问题根因分析精准

Plan §1.1 从生产数据出发（30,077 行 → 29,622 缺 traceId → 27,288 为 STREAM_BUS_EMIT_TOKEN），数据驱动的诊断链完整，直接指向根因"7 个模块 10 处直调 prisma.auditLog.create"。

### 2.2 方案选型严谨

每个关键决策都有对比分析：

| 决策 | 对比方案数 | 选择 | 理由充分 |
|:--|:--:|:--|:--:|
| Token 写入策略 | 4 | 内存累积+单条落库 | ✅ 原文完整 + 复杂度低 |
| traceId 策略 | 2 | writeAuditLog 自动兜底 | ✅ 改动最小 (1 文件) |
| 裁决层互锁 | 3 层 | caijue.toml + ESLint + CI grep | ✅ 设计/编码/PR 全覆盖 |

### 2.3 裁决层三层互锁完备

Plan §四 Task 5 明确三层互锁机制：caijue.toml 注册（设计时）→ ESLint 阻断（编码时）→ CI grep 扫描（PR 时），与裁决层三层互锁生效机制（记忆 ID: 1b7c54f7）一致。

### 2.4 原子闭包判定合理

add-route 的原子闭包判定以"用户是否感知完整业务功能"为原点，正确将 Task 1-5 判定为 1 个原子闭包（单轮执行）——Token 不再逐字落库 + 全部模块走统一入口 + 编译期阻断绕过，三者构成完整的治理闭环，缺一不可。

### 2.5 跨 Plan 联动正确

Plan 正确引用了 `farm-agent-review-and-evidence-hardening-plan-v1.md`（append-runtime-finding.ts L2 收口），Task 3 排除了已收口的文件，避免重复修改。

### 2.6 错误路径与降级处理完备

| 错误路径 | 处理机制 | Task |
|:--|:--|:--|
| `done` 事件到达但 `response_end` 未触发 | 兜底清理 `tokenBuffer.delete(traceId)`，防止内存泄漏 | Task 2 |
| `error` 事件 / SSE 连接异常断开 | 同上兜底清理，不残留 buffer | Task 2 |
| `writeAuditLog` 调用时 `currentTraceId` 未设置 | 自动生成 `auto_{uuid}` 兜底 traceId，不阻塞写入 | Task 1 |
| ESLint 阻断后开发人员绕过 | CI `grep` 扫描 `prisma.auditLog.create` 二次拦截 | Task 4-5 |
| stream-bus-logger.ts 中 `prisma` 不可用（DB 宕机） | `writeAuditLog` 内部 catch 后降级为 console + file 双通道，不抛异常 | 现有机制 |

> 降级策略：writeAuditLog 写入失败时降级为 console + file（L1 日志），不阻塞业务流程。这继承了现有的 ADD-4 三通道输出机制。

---

## 3. 问题清单

### P1-1 [已修复] 依赖图 Task 3 原标注 6 模块 → 现 5 模块

- **问题**：原 Plan 依赖图标注 Task 3 为"其余 6 个绕过模块"，但 append-runtime-finding.ts 已在 hardening-plan 中收口。
- **修正**：已修正为 5 模块，Task 3 跳过 append-runtime-finding.ts。
- **状态**: ✅ 已回流至 Plan

### P1-2 [已修复] Task 4 ESLint 规则数 2 → 3

- **问题**：原 Plan Task 4 只提到 1 条 ESLint 规则（禁止 prisma.auditLog.*），实际需要 3 条（+ userId 硬编码 + 新审计文件警告）。
- **修正**：已补充为 3 条规则。
- **状态**: ✅ 已回流至 Plan

### P1-3 [已修复] Task 2 缺 buffer 清理

- **问题**：原 Plan Task 2 只描述 response_end flush，未描述 done/error 兜底清理。
- **修正**：已补充 done/error 兜底清理 tokenBuffer。
- **状态**: ✅ 已回流至 Plan

### P1-4 [已修复] Task 3 缺 agent-gateway-audit.ts

- **问题**：原 Plan Task 3 绕过模块清单缺少 agent-gateway-audit.ts（GATEWAY_THREADS_LIST 等 93 条无 traceId）。
- **修正**：已加入 agent-gateway-audit.ts，targetType="AGENT_GATEWAY"。
- **状态**: ✅ 已回流至 Plan

### P2-1 add-route Step 0 缺少 Plan Review 生成步骤

- **问题**：add-route Step 0 的"动作"和"产出"中未包含"生成 Plan Review（ADD-9）"步骤。虽然前置阅读中引用了 runtime review，但 Plan Review 是 Step 0 的强制产出。
- **修正建议**：在 add-route Step 0 的产出中补充 `- [ ] Plan Review（ADD-9）已生成并通过`
- **严重程度**: P2（Plan Review 已在本次 session 生成，不影响执行）

### P2-2 裁决层契约路径需确认

- **问题**：Plan 引用 `docs/大田精准耕播智能决策系统/knowledge/01-架构/《裁决层-AuditLog写入契约》.md`，需确认此文件当前是否存在且内容完整。
- **修正建议**：进入 Step 1 前用 `find_related_docs` 确认。
- **严重程度**: P2（不影响代码实现，但影响 caijue.toml 注册的正确性）

---

## 4. 影响评估

### 4.1 受影响文件（10 个）

| 文件 | 操作 | 风险 |
|:--|:--|:--|
| `agent-audit-logger.ts` | 修改 writeAuditLog 签名 | 低 — 放宽类型，向后兼容 |
| `stream-bus.ts` | 新增 tokenBuffer + flush | 中 — 影响流式核心路径 |
| `stream-bus-logger.ts` | 3 函数改为 writeAuditLog + 新增 batch | 中 — 涉及 DB 写入变更 |
| `farm-server-client.ts` | 改为 writeAuditLog | 低 — 1 行改动 |
| `credential-store.ts` | 改为 writeAuditLog | 低 — 1 行改动 |
| `chat/stream/route.ts` | 改为 writeAuditLog | 低 — 1 行改动 |
| `layer2-callback.ts` | 改为 writeAuditLog | 低 — 1 行改动 |
| `agent-gateway-audit.ts` | 改为 writeAuditLog | 低 — traceId 已修复，仅收口 |
| `eslint.config.mjs` | 新增 3 条规则 | 低 — 配置文件 |
| `caijue.toml` | 新增条目 | 低 — 配置文件 |

### 4.2 回滚风险

- 代码回滚：`git reset --hard HEAD~1` 即可
- 数据回滚：无数据迁移，历史 AuditLog 不受影响
- 风险：stream-bus tokenBuffer 内存泄漏（低 — done/error 双重兜底）

---

## 5. 最终建议

**推荐按以下顺序执行**：

1. ✅ **Plan Review 已生成**（本文档）
2. ⏳ 确认 MCP Server 已重启（`readdirRecursive` 修复生效）
3. ⏳ 调用 `check_dps({ planKeyword: "audit-log-bypass-governance" })` — DPS ≥ 85 即进入 Step 1
4. ⏳ Step 1: 扩展 `AgentAuditPhase` 新增 `STREAM_BUS_EMIT_TOKEN_BATCH`
5. ⏳ Step 2-3: 按 Task 1→2+3 并行→4→5→6 拓扑执行
6. ⏳ Step 8: 收敛判断 + Handoff 生成
