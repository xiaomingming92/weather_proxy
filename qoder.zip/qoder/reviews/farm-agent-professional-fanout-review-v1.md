# farm-agent-professional-fanout-review-v1

## Review 元信息

- **Review 对象**: `farm-agent-professional-fanout-plan-v1.md`
- **Review 时间**: 2026-07-06
- **Review 类型**: 架构设计 + 方案选型 + 合规检查
- **前置阅读**:
  - Plan: `.qoder/plans/2026-07/06/farm-agent-professional-fanout-plan-v1.md`
  - ACA v3 Plan: `.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md`
  - thinking-level-runtime-fix: `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md`

---

## 1. 问题复现

ACA v3 Plan 三个版本一致要求 professional 图使用 LangGraph Send API fan-out，但当前 `agent-graph.ts` 的 `professionalWorkflow` 是全串行 `.addEdge` 链。本 Plan 是 ACA v3 Plan 轮次 4.3 的专项实施 Plan，目标明确：将图拓扑从串行改为 Send API fan-out + fan-in。

---

## 2. 方案评估

### 2.1 方案选型 ✅

方案 A（Send API fan-out）vs B（保持串行）vs C（Promise.all 伪并行）的对比清晰。选 A 的理由充分——这是 ACA v3 设计目标，也是唯一能实现 per-expert 独立管线的方案。方案 C 的局限分析到位（无法利用 LangGraph fan-in reducer、无法实现 interrupt 恢复的局部重跑）。

### 2.2 架构设计 ✅

- 图拓扑图（§3.1）清晰，per-expert 管线：`intention → routeByExpertPlan → Send(perExpertRetrieval) → perExpertReasoning → perExpertStructuredOutput → fan-in → kbConflictAggregator`
- 节点改造明细表（§3.2）区分了新建/改造/不变三类，职责边界明确
- 数据流（§3.4）从 `expertPlan` → `Send[]` → per-expert 管线 → `ExpertClaim[]` reducer concat → fan-in 链路完整
- `reasoningNode` 双模式设计（§8.3）通过 `state.expertId` 存在性区分——零改动 deep 图

### 2.3 State reducer 修正 ✅

§3.3 指出了 `expertClaims` 缺 reducer 的问题，给出了正确的 `Annotated<ExpertClaim[], { reducer: concat }>` 写法。这是 rurime-review 发现的遗留缺陷，在此被准确识别。

### 2.4 错误路径/降级处理 ✅

Plan §七风险矩阵覆盖了 4 种错误场景：Send API 行为不一致、checkpoint 竞态、reasoning 模式切换 bug、structuredOutput parse 失败。降级策略完备——每个风险有明确的缓解措施（最小可行性验证、集成测试、双模式回退、MAX_RETRIES 不变）。§3.1 图拓扑中空 expertPlan → 直通 kbConflictAggregator 也是降级路径。

### 2.5 兼容性/向后兼容 ✅

Plan 明确声明了兼容性约束：
- `reasoningNode` 通过 `state.fanoutExpertId` 区分双模式，不存在时回退现有串行逻辑（§8.3）
- `structuredOutputNode` 通过 `expertPackages.length === 1` 区分（§2 轮次 2 详情）
- `expertClaims` 的 reducer 仅在写入时触发，不影响不写该字段的 deep/fast 图（§3.3）
- deep/fast 图回归测试在验收标准中（§五），isSummary 路径同样受保护

### 2.6 存储/索引成本 ✅

**零新增存储成本**。本 Plan 不创建新数据库表、不新增索引、不引入新持久化层。数据流为：Send API 并行管线（内存 State 副本）→ ExpertClaim[] reducer concat（Annotation 内存汇聚）→ fan-in 串行链。无缓存设计，不新增 Checkpointer 写入路径（checkpoint 竞态风险已在 §七 中标记为低概率 + 集成测试覆盖）。

---

## 3. P0 阻断性问题

### P0-1: 缺少 Spec / Tasks / Checklist

Plan 元信息中三项全部标注为"待生成"，第六节关联文档同样空白。Plan template 要求关联文档节点包含这三项。本 Plan 涉及 3 轮 7 个 Task，没有 tasks.md 实施时必然遗漏。

### P0-2: Send API 语法有待验证

§8.2 给出了 Send API 代码示例，但 §八末尾标注"⚠️ 语法以实际 `@langchain/langgraph` 版本为准"。轮次 1.2 要求"必须先读取 SDK 确认 API"，但 Plan 当前没有实际验证结果。如果 SDK 语法与示例不同，整个图组装方案需要调整。

建议轮次 1.2 改为：先写最小验证脚本（2 expert mock fan-out），验证通过后再走正式实施。

### P0-3: `routeByExpertPlan` 没有定义 fan-in 节点

§3.1 图拓扑中 fan-in 后的节点是 `kbConflictAggregator`，但 `routeByExpertPlan` 函数（§8.2 L354-362）没有显式声明这个 fallthrough——当 `expertPlan` 为空数组时返回字符串 `"kbConflictAggregator"`，但如果 expertPlan 有值但所有 Send 完成后，LangGraph 如何知道下一个节点是 `kbConflictAggregator`？

需要确认：Send API 的 fan-in 是否需要显式声明边（如 `.addEdge("perExpertStructuredOutput", "kbConflictAggregator")`），还是 LangGraph 自动推断。§8.2 L376 确实给了 `.addEdge("perExpertStructuredOutput", "kbConflictAggregator")`，这一点在代码示例中是正确的，但在 §3.1 的架构描述中不够明确。建议在图拓扑图和 §3.4 数据流中明确标注这个边。

---

## 4. P1 重要问题

### P1-1: `AgentState` 需要新增 `expertId` 字段

`reasoningNode` 双模式切换依赖 `state.expertId`，但当前 `AgentState` 中没有这个字段。Send API 可以通过 `new Send("perExpertRetrieval", { expertId: "pest_risk" })` 注入，但 State 定义中必须有对应字段。轮次 1 应该包含 State 扩展——当前只列了 `expertClaims reducer`，没有列 `expertId` 字段。

### P1-2: toolNode 在 fan-out 中的放置位置不够明确

§3.5 讨论了 toolNode，但只说"perExpertReasoning → toolNode → perExpertReasoning"。Send API fan-out 模式中，每个分支的 toolNode 需要独立——如果所有分支共享一个全局 toolNode，工具调用结果会互相污染。需要确认是否需要 per-expert 独立的 toolNode 实例，还是共享实例可以通过 `state.expertId` 隔离。

### P1-3: 轮次 2 的 3 个 Task 依赖关系未标注

`perExpertRetrieval` 产出 `expertPackage`，被 `perExpertReasoning` 消费——两者强依赖。但依赖图（§四）中 Task 2.1/2.2/2.3 画为并行分支，实际至少 2.1 → 2.2 是串行的。Plan 应该在依赖图中标注"2.1 完成后才能开始 2.2"。

---

## 5. P2 改进建议

### P2-1: §3.3 expertClaims reducer 的 `default: () => null` 可能有问题

```typescript
expertClaims: Annotation<ExpertClaim[] | null>({
  reducer: (current, update) => update 
    ? [...(current || []), ...update] 
    : current,
  default: () => null,
})
```

`default: () => null` 意味着初始值是 `null`，但 reducer 每次 concat 时都要 `current || []`。建议 `default: () => []` 更简洁，reducer 直接 `[...current, ...update]`。

### P2-2: 缺少 codegen 说明

Plan 引用了 `Send` API（`import { Send } from "@langchain/langgraph"`），但没有说明当前项目已安装的 LangGraph 版本号，也没有确认 `Send` 是否在 JS SDK 中可用。建议在 §8.2 或 §2.1 中补充版本信息（`@langchain/langgraph v1.3.2`），并引用 `node_modules/@langchain/langgraph/dist/graph/state.d.ts` 的具体行号。

### P2-3: §3.1 图拓扑图的标记不够直观

```
├─[Send]→ perExpertRetrieval(pest_risk) ──→ perExpertReasoning(pest_risk) ──→ perExpertStructuredOutput(pest_risk) ──┐
```

括号内的 `(pest_risk)` 容易让人误解为函数调用。建议改为：
```
├─[Send]→ perExpertRetrieval  [expertId="pest_risk"]
```

---

## 6. 决策结论

| 维度 | 评价 |
|------|------|
| 问题识别 | ✅ 精确——ACA v3 Plan 4.3 缺口，当前串行赝品 |
| 方案选型 | ✅ A/B/C 对比清晰，选 A 理由充分 |
| 架构设计 | ✅ 拓扑图 + 数据流 + 节点改造表完整 |
| 上游依赖 | ✅ 明确引用 ACA v3 + thinking-level-runtime-fix，职责边界清晰 |
| 结构合规 | ❌ 缺 Spec / Tasks / Checklist — P0 |
| Send API 可行性 | ⚠️ 语法待 SDK 验证 — P0 |
| State 扩展 | ⚠️ 缺 `expertId` 字段 — P1 |
| 风险覆盖 | ✅ 4 条，含并发 checkpoint 竞态 |

**结论**：方案方向正确，P0 问题 3 条需在进入实施前解决。建议先做轮次 1.2 最小可行性验证（2 expert mock Send API），确认 SDK 语法可用后再推进后续轮次。

---

## 7. 受影响文件（回流预期）

| 文件 | 需要修改的内容 |
|------|--------------|
| `farm-agent-professional-fanout-plan-v1.md` | 补 Spec/Tasks/Checklist 关联；补 `expertId` State 字段到轮次 1；更正轮次 2 依赖图 |
| `farm-agent-professional-fanout-spec-v1.md` | 新建 Spec（P0-1） |
| `farm-agent-professional-fanout-tasks-v1.md` | 新建 Tasks（P0-1） |
| `farm-agent-professional-fanout-checklist-v1.md` | 新建 Checklist（P0-1） |
