# cognitive-event-bus.ts 代码实现 Review

## Review 元信息

- **Review 对象**: `src/agents/cognitive-event-bus.ts`（185 行）
- **Review 时间**: 2026-07-22
- **Review 类型**: 代码实现质量 + 架构合规检查
- **前置阅读**:
  - 事件消费者注册表: `src/caijuehub/strategies/event-consumer-strategies.ts`
  - 全局状态: `src/agents/global-state.ts`
  - 策略更新循环: `src/agents/policy-update-loop.ts`
  - caijue.toml: `src/caijuehub/caijue.toml` §event-consumer

---

## 1. 问题复现

`CognitiveEventBus` 是认知管线的中枢神经系统——所有节点的意图、推理、反馈、策略变更通过它流转。当前仅有一个实际消费者（`PolicyUpdateLoop`），但架构需要支持后续的空间推理、觉知注入等新消费者接入。本次审查聚焦：实现质量、类型安全、可扩展性、与 Gateway 背压模型的一致性。

---

## 2. 逐项审计

### 2.1 核心 pub/sub 协议 ✅

```
subscribe(eventType, handler) → unsubscribe fn
emit(event) → specific handlers + wildcard handlers
```

标准实现，`Set<CognitiveEventHandler>` 自动去重，unsubscribe 返回闭包清理空 Set。符合 RxJS/EventEmitter 惯例。

### 2.2 事件类型联合 — 14 种内联 ✅ / ⚠️

14 种事件类型全部内联在 `CognitiveEvent` discriminated union 中。当前够用，但每新增一种事件（如 `spatial:computed`、`jieqi:changed`）需修改此文件——所有 import 方编译时都会受影响。

**评级**: C+（可扩展性）

**建议**（非阻断）: 引入 EventRegistry mapped type：

```typescript
interface EventPayloads {
  "thought:started": {}
  "intent:detected": { intent: string; thinkingLevel: ThinkingLevel }
  "spatial:computed": { regionCount: number; zoneCount: number; jieqi: string }
  // ...
}

type CognitiveEvent = {
  [K in keyof EventPayloads]: { type: K; timestamp: number } & EventPayloads[K]
}[keyof EventPayloads]
```

新增事件只需在 `EventPayloads` 中加一行，不影响 `CognitiveEvent` 的导出签名。

### 2.3 `__threadId` 类型安全 ❌ P0

```typescript
// L124: 运行时注入但类型系统不感知
(event as Record<string, unknown>).__threadId = this.threadId

// L161: 读取时也是 as Record 强转
(e as Record<string, unknown>).__threadId === filter.threadId
```

**问题**：
1. 类型系统不保护 `__threadId` 字段，拼写错误（如 `__thread_id`）静默失败
2. `emit()` 会 mutate 传入的 event 对象——如果调用方持有引用，会观察到副作用
3. `getHistory()` 和 `getTimeline()` 两处过滤逻辑完全重复（DRY 违反）

**修复方案**：引入 EventEnvelope 包装，不污染事件本体：

```typescript
interface EventEnvelope {
  event: CognitiveEvent
  __threadId?: string
}

// history 存 envelope，handler 接收 event（解包后传递）
private history: EventEnvelope[] = []

emit(event: CognitiveEvent): void {
  const envelope: EventEnvelope = {
    event,
    __threadId: this.threadId ?? undefined,
  }
  this.history.push(envelope)
  // handler 只看到 event，不感知 envelope
  // ...
}

getHistory(filter?: { threadId?: string }): CognitiveEvent[] {
  let envelopes = [...this.history]
  if (filter?.threadId) {
    envelopes = envelopes.filter(e => e.__threadId === filter.threadId)
  }
  return envelopes.map(e => e.event)
}
```

### 2.4 handler 异常隔离 ✅

```typescript
try {
  handler(event)
} catch {
  // handler 异常不阻塞事件传播
}
```

正确。但 catch 块完全静默，无任何审计日志。如果 handler 内部抛错，调试时无任何线索。

**建议**: catch 中加一行 audit：

```typescript
} catch (e) {
  agentAudit("EVENT_BUS_HANDLER_ERROR",
    `handler 异常（已隔离）: ${event.type}`,
    { error: e instanceof Error ? e.message : String(e) })
}
```

### 2.5 specificHandlers + wildcardHandlers 重复遍历 ⚠️ P2

```typescript
// L128-137: specific handlers
const specificHandlers = this.handlers.get(event.type)
if (specificHandlers) { for (const handler of specificHandlers) { ... } }

// L141-150: wildcard handlers
const wildcardHandlers = this.handlers.get("*")
if (wildcardHandlers) { for (const handler of wildcardHandlers) { ... } }
```

两段代码逻辑完全相同，仅 `get()` 的 key 不同。可提取为内部方法：

```typescript
private dispatchTo(key: string, event: CognitiveEvent): void {
  const handlers = this.handlers.get(key)
  if (!handlers) return
  for (const handler of handlers) {
    try { handler(event) } catch (e) { /* audit */ }
  }
}

// emit 中：
this.dispatchTo(event.type, event)
this.dispatchTo("*", event)
```

### 2.6 `getHistory` vs `getTimeline` 职责重叠 ⚠️ P2

| 方法 | threadId 过滤 | type 过滤 |
|------|:-----------:|:---------:|
| `getHistory(filter?)` | ✅ | ❌ |
| `getTimeline(eventTypes?, filter?)` | ✅ | ✅ |

`getTimeline` 是 `getHistory` 的超集。两个方法的存在增加了认知负担，且内部实现 80% 重复（threadId 过滤逻辑完全一致）。

**建议**: `getHistory` 加 `eventTypes?` 参数，或 `getTimeline` 替代 `getHistory`。

### 2.7 history 无限增长 ❌ P1

```typescript
private history: CognitiveEvent[] = []
```

无上限、无淘汰策略。长时间运行的进程（如 Next.js dev server 或生产环境单进程多 thread），history 会持续增长直到 OOM。

**对标 DDS/QUIC 范式**：

CognitiveEventBus 的并发模型应走 DDS (Data Distribution Service) 或 QUIC stream 路线，而非应用层队列背压。

- 当前 `handlers: Map<eventType, Set<Handler>>` 天然就是 DDS 的 **per-topic DataWriter → DataReader 匹配模型**
- 14 种 `event.type` = 14 个 DDS Topic，每个 Topic 独立分发、独立流控
- handler 异常不阻塞 = QUIC 的 no head-of-line blocking（已有）
- subscribe 多 handler 并发分发 = QUIC multiplexing（已有）

缺失的是 DDS QoS History policy——每个 Topic 应有独立的保留深度，而非全局 history 无限增长：

```typescript
// DDS QoS History: per-topic 保留策略
type HistoryKind = "KEEP_ALL" | "KEEP_LAST"
interface TopicQoS {
  history: { kind: HistoryKind; depth: number }
  reliability: "RELIABLE" | "BEST_EFFORT"
}

// 示例：不同类型事件差异化 QoS
const DEFAULT_TOPIC_QOS: Record<string, TopicQoS> = {
  "system:done":       { history: { kind: "KEEP_LAST", depth: 1 },  reliability: "RELIABLE" },
  "feedback:observed": { history: { kind: "KEEP_LAST", depth: 50 }, reliability: "BEST_EFFORT" },
  "policy:updated":    { history: { kind: "KEEP_ALL",  depth: -1 }, reliability: "RELIABLE" },
}
```

这样 `system:done` 只需 keep_last(1)（只关心最近一次），`policy:updated` 需要 keep_all（策略回滚审计链不能断）。学术界已有将 DDS/RTPS 映射到 QUIC stream 的工作（如 Cyclone DDS over QUIC），当前 `Map<topic, Set<handler>>` 结构可直接承载这一演进，无需重构。

### 2.8 `setThreadId` 的线程安全问题 ⚠️ P2

```typescript
setThreadId(id: string): void {
  this.threadId = id
}
```

`CognitiveEventBus` 是请求级实例（每个 HTTP 请求 `new CognitiveEventBus()`），所以实际上不存在并发问题。但 `setThreadId()` 可以在请求生命周期的任何时刻被调用——如果误调两次，之前的 `__threadId` 标记不会更新（已 push 到 history 的事件保留旧 threadId）。

**建议**: 构造函数注入 threadId，移除 `setThreadId`：

```typescript
constructor(threadId?: string) {
  this.threadId = threadId ?? null
}
```

当前调用方（`stream/route.ts`、`chat/stream/route.ts`）都是 `new` 后立即 `setThreadId`，构造函数注入更清晰。

### 2.9 `subscribeToEvents` 空实现 ⚠️ P1

```typescript
// policy-update-loop.ts L531-536
private subscribeToEvents(): void {
  this.eventBus.subscribe("feedback:observed", (event) => {
    if (event.type === "feedback:observed") {
      // 反馈事件自动触发 evaluate（在实际集成中由 stream/route.ts 控制调用时机）
    }
  })
}
```

唯一的实际消费者 `PolicyUpdateLoop` 的订阅回调体是空的。`feedback:observed` 事件被订阅后什么都没做——注释说"由 stream/route.ts 控制调用时机"，实际是 `route.ts` 直接调 `evaluate()`，订阅只是占位。

**影响**: 不阻断功能（evaluate 确实由 route.ts 直接调用），但 EventBus 的 pub/sub 管道在这个场景下是"假通"——事件发了、订阅了，但订阅回调不做任何事。

**建议**: 要么在回调中触发 evaluate（真正的 pub/sub 驱动），要么删除 subscribe 调用（明确标注为 pull 模式，不订阅）。

---

## 3. 架构对标：DDS/QUIC vs 当前实现

CognitiveEventBus 的并发模型是 **数据分发层**（类似 DDS/RTPS 或 QUIC stream），而非 **应用层队列背压**（如 Gateway L1/L2）。两者的并发模型完全不同：

| 维度 | Gateway L1/L2 队列 | CognitiveEventBus（DDS/QUIC 方向） |
|------|:---:|:---:|
| **并发原语** | 有限状态机（入队/出队/晋升） | 流式分发（per-topic 独立流控） |
| **背压机制** | 队列溢出丢弃最旧 | 接收端 credit-based flow control |
| **去重** | 同源 60s 窗口 | 不需要（认知事件天然不重复） |
| **生命周期** | 进程级（启动期→请求期） | 请求级（per-thread 实例） |
| **传输语义** | fire-and-forget 异步落盘 | reliable delivery + per-topic QoS |

### DDS 概念映射

| DDS/RTPS 概念 | CognitiveEventBus 当前对应 | 状态 |
|---------------|:---:|:---:|
| **Topic** (DataWriter/Reader) | `event.type`（14 种 = 14 个 topic） | ✅ 已有 |
| **DomainParticipant** | `CognitiveEventBus` 实例（per-thread） | ✅ 已有 |
| **QoS History** (KEEP_ALL/KEEP_LAST) | `history: CognitiveEvent[]`（无 depth） | ❌ **P1 缺失** |
| **QoS Reliability** (RELIABLE/BEST_EFFORT) | `try/catch` 隔离 handler 异常 | ✅ 隐式 BEST_EFFORT |
| **QoS Deadline** | 无 | ⚠️ 可后续加 |
| **QoS Durability** (late-joining subscriber) | 无 | ⚠️ 可后续加 |

### QUIC stream 概念映射

| QUIC 概念 | CognitiveEventBus 当前对应 | 状态 |
|-----------|:---:|:---:|
| **Per-stream flow control** | 每个 event.type 独立 handler set | ✅ 已有 |
| **No head-of-line blocking** | handler 异常不阻塞后续 | ✅ 已有 |
| **Credit-based flow control** | 无 | ⚠️ 可后续加 |
| **Multiplexing** | subscribe 多 handler 并发分发 | ✅ 已有 |

### 当前架构已天然支持 DDS/QUIC 演进方向

`handlers: Map<eventType, Set<Handler>>` 结构可直接承载 per-topic QoS，无需重构。核心差距是 **QoS History**——当前全局 `history[]` 无上限、无 per-topic depth，应演进为 per-topic 独立保留策略。

注意：这与 Gateway 的 L1/L2 队列背压是**完全不同的并发模型**。Gateway 解决的是"进程级边界异常证据不要丢"（有限状态机 + 溢出丢弃），CognitiveEventBus 解决的是"认知事件的高效可靠分发"（per-topic 流控 + QoS 策略）。不应将 Gateway 的队列模式套用到 EventBus。

---

## 4. 审计汇总

| # | 严重度 | 问题 | 位置 |
|---|:------:|------|------|
| F1 | **P0** | `__threadId` 类型不安全，emit mutate 入参 | L124, L161 |
| F2 | **P1** | history 无限增长，无上限 | L79 |
| F3 | **P1** | `subscribeToEvents` 回调体为空，pub/sub 假通 | policy-update-loop.ts L532-536 |
| F4 | **P2** | handler 异常完全静默，无审计日志 | L134 |
| F5 | **P2** | specific/wildcard handler 分发逻辑重复 | L128-150 |
| F6 | **P2** | `getHistory` vs `getTimeline` 职责重叠 | L153-183 |
| F7 | **P2** | `setThreadId` 应改为构造函数注入 | L83-85 |
| F8 | **P3** | 事件类型无注册表，新增事件需改 union | L24-58 |

**P0 必修**：1 项（F1 EventEnvelope）
**P1 应修**：2 项（F2 history 上限 + F3 空回调）
**P2/P3**：后续轮次收敛

---

## 5. 结论

CognitiveEventBus 的核心 pub/sub 协议（subscribe/emit/unsubscribe）实现标准，三层解耦架构（EventBus / consumer-strategies / GlobalStateProvider）设计清晰。当前架构已天然具备 DDS/QUIC 数据分发模型的基础要素（per-topic handler 匹配、no head-of-line blocking、multiplexing）。

主要短板在 **类型安全**（`__threadId` 强转）和 **per-topic QoS History**（全局 history 无上限、无 per-topic depth）。后者不是要抄 Gateway 的 L1/L2 队列背压——那是应用层有限状态机，解决"边界异常证据不要丢"；CognitiveEventBus 是数据分发层，应走 DDS QoS History 路线——每个 event type 独立的 KEEP_LAST(depth) / KEEP_ALL 策略，解决"认知事件的可靠分发"。

建议按 F1（EventEnvelope 类型安全）→ F2（per-topic QoS History）→ F3（空回调清理）的优先级收敛。
