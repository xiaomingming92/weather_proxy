# farm-agent-three-tier-reasoning-graph runtime-review

> 运行时验证纠偏文档。部署 `farm-agent-domain-vocabulary-v2`（Router 模块）后，通过 GUI 端到端测试发现的裁决层遗漏。

## Review 元信息

- **关联方案 review**: `.qoder/reviews/farm-agent-three-tier-reasoning-graph-review-v3.md`
- **关联实现 review**: 无（直接来自终端运行时日志）
- **关联 checklist**: `.qoder/specs/farm-agent-domain-vocabulary-v2/checklist.md`（第8轮 `[R]` 项）
- **Review 时间**: 2026-07-03
- **触发方式**: 运行时日志（GUI chat → terminal console 全链路 trace）

---

## 1. 发现列表

### 发现 #1: resolveThinkingLevel 从未返回 "professional"——Router 全线白写

**现象**：

GUI 发送"水稻选种看看"请求，intention 节点由 LLM 解析出 2 个 subIntent（`crop_compare` + `variety_recommend`），但 `thinkingLevel` 被裁决为 `"deep"`，走了 `deepGraph` → `intentionNode`（旧 LLM 路由），而非 `professionalGraph` → `intentionAsyncNode`（新 Router）。

终端日志关键行：
```
[NODE_END] intention parse success | {"thinkingLevel":"deep","subIntents":["crop_compare","variety_recommend"]}
```

Router 的 `intentionAsyncNode`、`initRouter()`、`route()`、`embeddingRoute()` 全程零调用。

**根因（git 追溯）**：

```
commit {hash} (2026-07-03, "feat(router): 2-Tier 语义路由 8轮完成")
  - src/agents/agent-graph.ts: professionalWorkflow 已切换到 intentionAsyncNode ✅
  - src/caijuehub/strategies/thinking-level.ts: resolveThinkingLevel 仅有 fast/deep 两路 ❌
```

`resolveThinkingLevel` 的代码（`src/caijuehub/strategies/thinking-level.ts:22-29`）：

```typescript
export function resolveThinkingLevel(
  intent: string | undefined,
  explicitExpertId?: string | null,
): ThinkingLevel {
  if (explicitExpertId) return "deep"
  return intent === "chat" ? "fast" : "deep"
}
```

**缺少 `"professional"` 分支**。这个函数定义了 `ThinkingLevel = "fast" | "deep" | "professional"` 三家头，但只实现了两家。

**后果链**：

1. `intentionNode` 调用 `resolveThinkingLevel("analysis", null)` → 返回 `"deep"`
2. `routeByIntent` 按 `thinkingLevel === "deep"` 路由到 `deepGraph`（旧图）
3. `deepGraph` 的 intention 节点指向 `intentionNode`（同步 LLM），不调用 Router
4. `professionalGraph` 的 `intentionAsyncNode`、Router 链路、2-Tier 语义路由全部未被触发
5. `domain-vocabulary-v2` 的 6 个 router 文件（types/tier-decider/centroid-init/embedding/index/llm-fallback）变为死代码，仅 tier-decider 纯函数可通过单测验证

**修复方向**：

在 `resolveThinkingLevel` 中增加 `subIntentsCount` 参数，当 2+ subIntents 时返回 `"professional"`：

```typescript
export function resolveThinkingLevel(
  intent: string | undefined,
  explicitExpertId?: string | null,
  subIntentsCount?: number,        // ← 新增
): ThinkingLevel {
  if (explicitExpertId) return "deep"
  if (subIntentsCount && subIntentsCount >= 2) return "professional"  // ← 新增
  return intent === "chat" ? "fast" : "deep"
}
```

同时需更新所有调用方传入 `subIntentsCount`：
- `src/agents/nodes/intention.ts`：4 处调用
- `src/agents/nodes/intention-async.ts`：3 处调用

**修复涉及的三轮 Plan**：

| Plan | 角色 | 受影响 |
|------|------|:--:|
| `farm-agent-three-tier-reasoning-graph-plan-v3.md` | 定义了 `ThinkingLevel` 三级 | 轮次 4.2 `routeByIntent` 扩展——此步骤从未真正完成 |
| `farm-agent-domain-vocabulary-plan-v2.md` | 创建了 Router + 接入 professionalWorkflow | 第 7 轮 wiring 到位但裁决层未联动 |
| 本修复 | 衔接两个 Plan 的断层 | 本次 |

#### 为何前置 review 遗漏

1. **v3 Plan 的轮次 4 实现不完整**：`routeByIntent` 扩展（4.2 任务）依赖 `resolveThinkingLevel` 先返回 `"professional"`，但 `resolveThinkingLevel` 的修改（`ThinkingLevel` 三级扩展）属于轮次 1 的类型定义层面——轮次 1 只改了类型，没改函数体。两个轮次之间的"类型改了但逻辑没跟上"的断层未被 review 捕获。
2. **domain-vocabulary-v2 的 handoff 假设了 professional 图可达**：第 7 轮 wiring 完成后直接验收，未做端到端路由验证——因为 checklist 的 `[R]` 项全部标记为"待运行时验证"，直到 GUI 部署后才暴露。
3. **`ThinkingLevel` 三级扩展缺少 WHEN-THEN Spec**：v3 Spec 未定义"什么条件下返回 professional"——仅有类型声明无行为规格。

### 发现 #2: interactionPointDetection 的 Zod schema 缺 threadId 字段

**现象**：

terminal 日志（HISTORY.md 第 187-188 行）：
```
[NODE_ERROR] ✘ interactionPointDetection 失败
[ZOD_VALIDATE_FAIL] interrupt payload 校验失败: [{"path":["threadId"],"message":"Invalid input"}]
```

**根因**：

`src/caijuehub/strategies/sse-terminal-event.ts:47-51` 虽有边界注入 `threadId`/`traceId` 的代码：
```typescript
const payloadWithMeta = {
  ...rawPayload,
  threadId: rawPayload.threadId || meta.threadId,
  traceId: rawPayload.traceId || meta.traceId || undefined,
}
```

但 `meta.threadId` 可能为 `undefined`（当 graph 内部 `interrupt()` 未传 `threadId` 时），且 `InterruptSSEPayloadSchema` 中 `threadId` 为必填字段（`z.string()`），`undefined` 无法通过校验。

**后果链**：

1. reasoning → interactionPointDetection 产出交互点（机插 vs 直播决策）
2. SSE 终端事件层尝试校验 payload，`threadId` 缺值 → Zod 校验失败
3. 虽然 fallback 到原始 `payloadWithMeta`（line 57），但前端收到的事件格式不标准
4. 该问题的触发条件是 `meta.threadId` 在 graph 内部 `interrupt()` 调用时未被注入——这是 v3 Plan 轮次 3b（interactionPoint 增强）的遗留

**修复方向**：

`InterruptSSEPayloadSchema` 中 `threadId` 改为可选（`.optional()`），或在 `sse-terminal-event.ts` 的边界注入时保证 `meta.threadId` 从上层 API route 传入。当前 `emitTerminalEvent` 调用方需传递 `threadId`。

#### 为何前置 review 遗漏

与发现 #1 同因——`[R]` 运行时验证项延迟到 GUI 部署后才触达，前置 checklist 仅有 `[T]` 编译期检查。

---

## 2. review 流程改进项

| 检查项 | 具体操作 | 触发时机 |
|--------|---------|---------|
| **resolveThinkingLevel 三级路由完整性** | 检查函数体内是否覆盖所有 `ThinkingLevel` 枚举值——类型系统不会报错（因为返回 `"deep"` 是合法子类型），需手动审查 | 每次修改 `thinking-level.ts` 后 |
| **professional 图可达性端到端验证** | 发送含 2+ 子域的用户查询（如"水稻选种看看"），验证日志中出现 `thinkingLevel=professional` 和 Router 调用 | checklist 第 7/8 轮 `[R]` 项从"待运行时"升级为代码阶段可验证（通过单元测试 mock graph） |
| **interrupt payload 必填字段边界注入** | `InterruptSSEPayloadSchema` 的 `threadId` 改为 `.optional()`；`emitTerminalEvent` 调用方统一传递 `threadId` | 每次修改 SSE 终端事件层后 |
| **Spec WHEN-THEN 覆盖度** | `resolveThinkingLevel` 三种返回值各自定义 WHEN-THEN 规格——`professional` 的触发条件必须在 Spec 中显式声明 | Spec 生成/更新时 |

> 上述改进项应回流至 `checklist-template.md` 和 `spec-template.md`，确保后续 Plan 自动继承。

---

## 3. 已运行时修复项

- [ ] 发现 #1：`resolveThinkingLevel` 增加 `subIntentsCount` 参数 + `"professional"` 分支（待修复）
- [ ] 发现 #2：`InterruptSSEPayloadSchema` 中 `threadId` 改为 `.optional()`（待修复）

---

## 4. 回流确认

- [ ] 流程改进项已写入对应模板（`checklist-template.md`）
- [ ] 修复项已记录审计日志（`record_dev_operation`）
- [ ] 发现问题回流至 `farm-agent-three-tier-reasoning-graph-plan-v3.md` 风险矩阵
