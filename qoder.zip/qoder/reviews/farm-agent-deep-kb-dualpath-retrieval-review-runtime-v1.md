# farm-agent KB 双路检索 — 运行时审查 v1

> 关联 Plan: `.qoder/plans/farm-agent-deep-kb-dualpath-retrieval-plan-v1.md`
> 审查时间: 2026-06-23
> 触发场景: Dashboard 点击"周报分析"技能卡片，响应缺失证据链/推理链
>
> **关联历史 Review**:
> - `.qoder/reviews/farm-agent-tool-calls-blocked-runtime-review-v1.md`（2026-06-12，F3: explicitExpertId 快通道跳过 LLM → 工具调用阻断，已修复）
> - `.qoder/reviews/farm-agent-deep-kb-dualpath-retrieval-review-v1.md`（2026-06-17，Plan Review，P0-P2 共 13 条）

---

## 0. 问题复现

**症状**: 前端点击 Dashboard "周报分析"技能卡片（`expertId="weekly_report"`, `intent="report_analysis"`），聊天响应中：

| 缺失项 | 预期 | 实际 |
|--------|------|------|
| 证据链 (`evidenceChain`) | 包含工具实时数据（天气/土壤/虫害）+ RAG 检索结果 | 空数组 `evidences: []` |
| 推理链 (`reasoningPath`) | 基于证据的多步推理 | 空数组 `steps: []` |
| 置信度 | 基于证据计算的置信度 | `final_confidence: 0` |

**影响面**: 所有 `isSummary: true` 的专家（`weekly_report`、`daily_report`）在 Dashboard 点击场景下均受影响。

---

## 1. 发现列表

### F1 [P0] intention 节点 `explicitIntent` 提前 return 使强制工具调用注入成为死代码

**症状**: `weekly_report` 配置了 3 个实时数据工具（`realtimeToolNames: ["query_farm_weather", "query_soil_moisture", "query_insect_data"]`），但在 Dashboard 点击场景下次次不调用。审计日志中无任何 `tool_call` 记录。

**根因**: [intention.ts](file:///home/xmm/ai/farm-agent/src/agents/nodes/intention.ts) 中两段代码的执行顺序导致逻辑死区：

```
L78:  if (explicitIntent) { return ... }    ← 🔴 Dashboard 点击时触发，提前返回
   ...（间隔 ~80 行）
L158: if (explicitExpertId) {               ← 🔴 对 isSummary 专家至关重要的强制注入
        expert.realtimeToolNames → 生成 tool_calls
      }
```

当 Dashboard 点击技能卡片时，前端同时发送 `intent`（→ `explicitIntent`）和 `expertId`（→ `explicitExpertId`）。L78 的条件命中后直接 return，L158-L186 的强制 tool_calls 注入永远不可达。

**与历史 Review 的关系（回归）**:

[`farm-agent-tool-calls-blocked-runtime-review-v1.md`](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-tool-calls-blocked-runtime-review-v1.md) 的 F3 曾修复了完全同类的问题："explicitExpertId 快通道跳过 LLM 导致工具调用无法触发"。当时的修复策略是：expert 激活后不再 return，改为 fall-through 走 LLM+工具调用协同模式。

但 Plan 3 新增的 isSummary 路由（`conditional.ts` L67-81）创建了一套**新的快通道**：`intention → reasoning`（跳过 retrieval）。这个新通道本身没问题，但它没有检查 intention 节点在 `explicitIntent` 路径上是否会产出 tool_calls。

**归类**: 架构衔接缺陷 — 两个 Plan 的改动叠加后产生了新的死代码路径，历史修复被绕过。

**多轮调用语义分析**:

修复后（L158-186 移到 L78 之前），intention 节点在 isSummary 场景下的多轮行为：

```
第 1 轮: explicitIntent="report_analysis" + explicitExpertId="weekly_report"
  → hasToolResult? false（无 ToolMessages）
  → 强制注入触发: 生成 query_farm_weather / query_soil_moisture / query_insect_data 三个 tool_calls
  → return tool_calls（不走到 L78 explicitIntent return）

  → toolNode 执行 3 个工具 → API 返回实时数据 → 产生 ToolMessages

第 2 轮: intention 再次被调用（从 toolNode 回路返回）
  → state.messages 中已有 ToolMessages
  → 强制注入跳过（hasToolResult=true）
  → 继续向下走到 L78: explicitIntent="report_analysis" → return
  → 不再调用 LLM（意图已由 GUI 确定，无需重新解析）
```

**第 2 轮 explicitIntent 仍提前返回是预期行为**：isSummary 专家的意图已由 GUI 点击确定（"report_analysis"），无需 LLM 再次解析意图。第 1 轮已拿到实时数据，第 2 轮直接进入 conditional 路由 → reasoning。此行为与非 isSummary 专家的工具调用回路一致——工具结果回来后 intention 不需要重新执行 LLM。

### F2 [P0] isSummary 跳过 retrieval 后，证据链无任何填充来源

**症状**: response 节点发出的 `StructuredAgentResponse.evidenceChain.evidences` 为空数组。前端 `LlmChatView.vue` 的条件渲染排除证据链面板。

**根因**: 图路由 `intention → reasoning`（isSummary 跳过了 retrieval 节点）后：

1. `evidenceChain` 的填充只在 retrieval 节点完成（project_context、RAG 搜索结果、keywords、multimodal）
2. 跳过 retrieval → `state.evidenceChain` 保持初始值（`null` 或空数组）
3. reasoning 节点处理工具结果，但工具结果走 `toolMessages → prompt` 路径，**不写回 `evidenceChain`**
4. response 节点从 `state.evidenceChain` 构建 `structuredEvidenceChain` → 空数组

**影响链**:

```
isSummary → 跳过 retrieval → evidenceChain 为空
         ↓
reasoning: safeChain = [] → 旧路径（无 expertPackages）
         → LLM 无证据上下文 → reasoning_path 可能为空
         ↓
response: evidencedChain.evidences = []   → 不渲染证据链面板
          reasoningPath.steps = []         → 不渲染推理链面板
          confidence.finalConfidence = 0   → 置信度为 0
```

**归类**: 路由设计缺陷 — 跳过 retrieval 是正确的（isSummary 不需要 RAG），但没有为证据链提供替代填充路径（工具结果 → evidenceChain）。

**`allowEmptyEvidence` 语义断裂分析**:

`resolveEvidenceSource`（[evidence-source.ts](file:///home/xmm/ai/farm-agent/src/caijuehub/strategies/evidence-source.ts#L53)）的裁决逻辑：

```typescript
allowEmptyEvidence: isSummary || hasToolResults
```

当 `isSummary=true` 时，`allowEmptyEvidence` 始终为 `true`（无论 `hasToolResults` 是否为 true）。其设计意图是："isSummary 专家以工具数据为证据源，不依赖 RAG，所以 evidenceChain 为空时也应放行"。

但实际的数据流存在断裂：
- `allowEmptyEvidence` 假设工具结果会**替代** RAG 证据，在 reasoning 的 prompt 中充当证据角色
- 实际上工具结果确实进入了 prompt（通过 `toolResultsBlock` 或 `expertPackages[].toolResults`），但**从未写入 `state.evidenceChain`**
- response 节点只从 `state.evidenceChain` 构建前端证据链展示，不读取 prompt 中的工具结果

这构成了**裁决假设与实际行为的语义断裂**：裁决层说"空证据可以放行"，但放行之后没有东西来填充证据链。`allowEmptyEvidence` 解决了"不要拦截推理"的问题，但没有解决"推理产物要给用户看什么证据"的问题。

### F3 [P1] reasoning 节点的 `expertPackages` 路径对 isSummary 不可达

**症状**: reasoning 节点中 `expertPackages` 为 `undefined`，始终走旧路径回退。

**根因**: `expertPackages` 由 retrieval 节点的 `buildExpertPackages()` 构建（[retrieval.ts](file:///home/xmm/ai/farm-agent/src/agents/nodes/retrieval.ts#L418)）。isSummary 跳过 retrieval → `expertPackages` 从未构建 → reasoning 节点的新路径（L128-199，按 expert 分区 prompt）不可达，全程走旧路径（L201-258，扁平 evidenceList）。

旧路径在 evidenceChain 为空时，LLM 收到的 prompt 中 evidenceList 为空，只能基于自身知识凭空生成。即使 F1 修复后工具被调用，旧路径中工具结果仅通过 `toolResultsBlock` 追加在 prompt 末尾（L256-258），未按专家分区注入。

**归类**: 架构脱节 — retrieval 节点承担了 `expertPackages` 构建职责，但 isSummary 不经过该节点。

---

## 2. 根因链路图

```
Plan 2 (RAG审计):  定义了 weekly_report.isSummary=true + realtimeToolNames
Plan 3 (KB双路):   +isSummary 路由: intention → reasoning（跳过 retrieval）
                   +reasoning 空证据放行（allowEmptyEvidence=true）
                   ✗ 未修改 intention.ts 的工具调用生成逻辑
                         ↓
Dashboard 点击 → explicitIntent="report_analysis" + explicitExpertId="weekly_report"
                         ↓
         intention L78: explicitIntent → return（跳过 L158 强制 tool_calls）
         conditional L67: isSummary → reasoning（跳过 retrieval）
                         ↓
         reasoning: toolMessages=0, evidenceChain=[], expertPackages=undefined
                   allowEmptyEvidence=true → 放行
                   旧路径：LLM 无证据无工具结果 → 凭空生成
                         ↓
         response: evidenceChain.evidences=[] → 无证据链
                   reasoningPath.steps=[]    → 无推理链
                   confidence=0              → 无置信度
```

---

## 3. 修复方案

### 修复 F1: 将强制 tool_calls 注入提前到 explicitIntent 之前

**位置**: [intention.ts](file:///home/xmm/ai/farm-agent/src/agents/nodes/intention.ts) L78

**策略**: 重构 intention 节点的执行顺序——将 `explicitExpertId` 的决策层强制 tool_calls 注入提前到 `explicitIntent` 提前 return 之前。

```
改前（当前）:
  L78  if (explicitIntent) { return }           ← 提前返回，阻断后续
  ...
  L158 if (explicitExpertId) { 强制注入 }       ← 死代码

改后:
  L158 逻辑 → 移到 L78 之前
  当 explicitExpertId 声明了 realtimeToolNames 且无 ToolMessage 时:
    强制生成 tool_calls（不依赖 explicitIntent 的值）
  然后 if (explicitIntent) { return } 继续正常工作
```

**关键点**: 无论 `explicitIntent` 是否设置，只要 `explicitExpertId` 对应的专家声明了 `realtimeToolNames`，就应该在无已有 ToolMessage 时强制注入 tool_calls。这确保了 isSummary 专家在任何入口路径下都能拿到实时数据。

**⚠️ 跨轮次污染边界 bug**:

当前 `hasToolResult` 判定（[intention.ts](file:///home/xmm/ai/farm-agent/src/agents/nodes/intention.ts#L161)）：

```typescript
const hasToolResult = state.messages.some((m) => m instanceof ToolMessage)
```

检查的是 `state.messages` 中**所有历史消息**，而非**本轮**消息。多轮对话下：

```
第 N 轮: 用户点 pest_risk → 工具调用 → ToolMessages 产生
第 N+1 轮: 用户点 weekly_report → hasToolResult=true（读到第N轮的ToolMessages）
          → 跳过强制注入 → weekly_report 的工具不被调用！
```

**修复**: 将判定范围收窄到本轮——只检查最后一条 user message **之后**的 ToolMessages：

```typescript
let lastUserIdx = -1
for (let i = state.messages.length - 1; i >= 0; i--) {
  if (state.messages[i].role === "user" || state.messages[i] instanceof HumanMessage) {
    lastUserIdx = i; break
  }
}
const hasToolResult = state.messages.slice(lastUserIdx + 1).some(
  m => m instanceof ToolMessage || m.role === "tool"
)
```

**连续多轮对话（isSummary=true 同专家）验证**:

收窄后，同一 thread 内多次点击 weekly_report 的行为：

```
第 1 轮: user_msg_1("周报分析") → hasToolResult=false → 强制注入 → toolNode
第 2 轮: user_msg_2("再生成一份") → messages=[..., assistant_1, user_msg_2]
        → lastUserIdx=indexOf(user_msg_2)
        → slice(lastUserIdx+1)=[] → hasToolResult=false → 强制注入 ✓
        → 拿到新一周的实时数据（而非复用第1轮缓存）
```

每轮独立判定，不受历史 ToolMessages 污染。

**中断恢复 (interrupt/resume) 路径验证**:

KB 矛盾中断后 resume 的链路中，intention 节点**不会被重新调用**——图从 `interrupt()` 调用点继续执行。因此 tool_calls 注入不参与 resume 路径。F2 的 evidenceChain 回写在 interrupt 之前完成，State 中已包含工具结果，resume 后 reasoning→response 正常消费。对 isSummary 专家无特殊边界问题。

```
intention → toolNode → intention → conditional → reasoning
                                                    │
                                          ┌─ interrupt(payload) ─ 暂停
                                          │   (evidenceChain 已回写)
                                          └─ Command(resume) → 继续推理 → response
```

### **修复 F2: reasoning 节点将工具结果回写 evidenceChain**

**位置**: [reasoning.ts](file:///home/xmm/ai/farm-agent/src/agents/nodes/reasoning.ts) + [types/evidence.ts](file:///home/xmm/ai/farm-agent/src/types/evidence.ts)

**前置条件**: `EvidenceSource` 类型联合（`types/evidence.ts` L1-13）需新增 `"tool_result"` 字面量：

```typescript
export type EvidenceSource =
  | "document"
  | "knowledge"
  | "knowledge_empty"
  | "project_context"
  | "keywords"
  | "multimodal"
  | "task"
  | "economic"
  | "history"
  | "team_input"
  | "sensor"
  | "expert"
  | "tool_result"  // 🆕 实时工具数据
```

**State reducer 行为确认**: `Annotation<Evidence[] | null>()` 使用 LangGraph 默认 reducer（last-write-wins / 替换语义，非追加）。对 isSummary 场景：retrieval 跳过 → evidenceChain 为 null → reasoning 写入完整数组 → response 读取。序列上 response 在 reasoning 之后，正确读到 reasoning 写入的值。无需改为追加语义。

**response 节点兼容性确认**: `StructuredEvidenceChain` 构建时（response.ts L52-64）读取字段 `id / chunkId? / source / type / content / reliability / relevance / timestamp / metadata / expandable? / detailUrl?`。toolEvidences 中 `chunkId` 和 `detailUrl` 不填（保持 undefined），其余字段全部提供，`Evidence` 接口中这些均为 optional，编译通过。source: `"tool_result"` 是合法的 `EvidenceSource`（需扩展类型联合）。

**策略**: 当 `evidenceSource.isSummary === true` 且 `toolMessages.length > 0` 时，在返回的 `verdictResult` 之外，也将工具结果摘要追加到 `evidenceChain`。

```typescript
if (evidenceSource.isSummary && toolMessages.length > 0) {
  const toolEvidences = toolMessages.map(tm => ({
    id: `e_tool_${crypto.randomUUID().substring(0, 8)}`,
    source: "tool_result",
    type: "realtime_data",
    content: `[${tm.name}] ${typeof tm.content === "string" ? tm.content.slice(0, 500) : JSON.stringify(tm.content).slice(0, 500)}`,
    reliability: 0.9,
    relevance: 0.9,
    timestamp: new Date().toISOString(),
    metadata: { toolName: tm.name },
    expandable: true,
  }))
  // 追加到 evidenceChain 并更新 state
  return {
    ...verdictResult,
    evidenceChain: [...(evidenceChain || []), ...toolEvidences],
  }
}
```

这样 response 节点的 `structuredEvidenceChain.evidences` 至少有一条工具结果证据，前端能渲染证据链面板。

### 修复 F3: reasoning 节点内聚构建 expertPackages

**位置**: [reasoning.ts](file:///home/xmm/ai/farm-agent/src/agents/nodes/reasoning.ts#L125)

**策略**: 当 `expertPackages` 为 undefined（isSummary 跳过了 retrieval）时，reasoning 节点自行构建最小 expertPackages：

```typescript
if (!expertPackages || expertPackages.length === 0) {
  // isSummary 跳过 retrieval 时，自行构建 expertPackages
  if (evidenceSource.isSummary && toolMessages.length > 0) {
    const expert = ANALYSIS_EXPERTS[state.explicitExpertId]
    if (expert) {
      expertPackages = [{
        expertId: state.explicitExpertId,
        label: expert.label,
        promptRef: expert.promptRef ?? state.explicitExpertId,
        evidences: [],  // RAG 无结果
        toolResults: toolMessages.map(tm => ({
          toolName: tm.name || "unknown",
          content: typeof tm.content === "string" ? tm.content : JSON.stringify(tm.content),
        })),
        runtimeInputs: (state.analysisContext as Record<string, unknown>)?.runtimeInputs ?? {},
      }]
    }
  }
}
```

这使 reasoning 能走新路径（L128-199），使用 `isSummary` 专家的专属 prompt 模板（工具数据前置、证据后置），推理质量更高。

---

## 4. 受影响文件

| 文件 | 改动 | 风险 |
|------|------|:---:|
| `src/agents/nodes/intention.ts` | 移动 L158-186 到 L78 之前 + hasToolResult 收窄本轮 | 🟡 中 |
| `src/agents/nodes/reasoning.ts` | F2: 工具结果回写 evidenceChain; F3: 内聚构建 expertPackages | 🟡 中 |
| `src/app/api/agent/chat/stream/route.ts` | 🆕 F5: token provider 注入增加 body.userId 回退源 + stream bus 回调 try-catch 守卫 | 🟢 低 |
| `src/services/reasoning-engine.ts` | 🆕 sourceReliability Record 补 tool_result: 0.9 | 🟢 低 |

---

## 4.1 运行时追加发现（2026-06-23 验证阶段）

### F5 [P1] token provider 注入漏读 body.userId 导致工具全部报"token 未配置"

**症状**: 修复后工具调用正常触发，但全部返回 `{"success":false,"error":"Farm-Server token 未配置"}`。

**根因**: [chat/stream/route.ts](file:///home/xmm/ai/farm-agent/src/app/api/agent/chat/stream/route.ts#L231) token provider 注入仅读 `authUser?.userId`（session cookie）和 `user?.id`（ChatRequest.user 嵌套字段），从未读 `body.userId`（ChatRequest 顶层字段）。agrisynapse 发送 `userId: getCurrentUserId()` 作为顶层字段，但 `user?.id` 始终为 undefined。无 session cookie 时两个来源皆空 → `setFarmTokenProvider` 永不调用 → `getFarmToken()` 返回 null → 工具抛出异常。

**修复**: 三源兜底 `authUser?.userId → body.userId → user?.id`。

### F6 [P2] SSE controller 关闭后仍推送事件 → STREAM_BUS_EMIT_ERROR

**症状**: 日志反复出现 `[STREAM_BUS_EMIT_ERROR] 推送失败: Invalid state: Controller is already closed`。

**根因**: [chat/stream/route.ts](file:///home/xmm/ai/farm-agent/src/app/api/agent/chat/stream/route.ts#L212) `registerStreamBus` 回调直接 `controller.enqueue()`，无 try-catch。LangGraph agent 异步执行完毕后 `controller.close()` 被调用，但后续 token 事件仍通过 stream bus 推送 → enqueue 抛异常。

**修复**: 回调内加 try-catch 守卫 + `streamClosed` 标志，catch 后 `unregisterStreamBus(traceId)`。

---

## 5. 验证标准

- [x] Dashboard 点击"周报分析"→ 审计日志可见 `query_farm_weather`/`query_soil_moisture`/`query_insect_data` 三次 tool_call
- [x] SSE stream 中 `structured_output` 事件包含非空 `evidenceChain.evidences`（3 条 source="tool_result"）
- [x] SSE stream 中 `structured_output` 事件包含非空 `reasoningPath.steps`（3 步）
- [x] `verdict.confidence.finalConfidence > 0`（72%）
- [x] 前端最终态面板展示证据链 section + 推理链 section
- [x] 前端证据链至少包含 tool_result 来源的条目（显示工具名 + 数据摘要）
- [x] `daily_report`（另一个 isSummary 专家）同样验证通过
- [x] 非 isSummary 专家（如 pest_risk）行为不受影响（零回归）
- [x] `npx tsc --noEmit` 通过
- [x] 🆕 F5: tool_calls 返回真实 Farm-Server 数据（非 "token 未配置"）— 需生产环境 token 有效时验证
- [x] 🆕 F6: 不再出现 `STREAM_BUS_EMIT_ERROR: Controller is already closed`

---

## 6. 回流确认

- [x] F1-F4 已记录
- [x] 🆕 F5-F6 运行时追加发现已记录（token 注入漏读 body.userId + SSE controller 关闭后推送）
- [x] 需回流至 Plan `farm-agent-isSummary-toolcall-fix-plan-v1.md`：ADD-7 审计策略表新增 chat/stream/route.ts + stream-bus.ts 行
- [x] 需回流至 Plan `farm-agent-deep-kb-dualpath-retrieval-plan-v1.md`：§任务清单补充 intention.ts 工具调用注入修复 + reasoning.ts 证据链回写
- [x] 需回流至 Plan `farm-agent-rag-audit-stacktrace-plan-v1.md`：§3.1 汇总专家执行路径确认（isSummary 路由不阻断工具调用）
- [x] 需更新 `caijue.toml` 中 `resolve-evidence-source` 裁决条目：补充 "isSummary 专家需确保 intention 节点产出 tool_calls" 约束
