# farm-agent Grounding Customization — Plan Review v3

> **审查时间**: 2026-06-16
> 
> **关联 Plan**: [farm-agent-grounding-customization-plan-v3.md](../plans/farm-agent-grounding-customization-plan-v3.md)
> 
> **前版 Review**: v1/v2 已作废，由本 Review 替代

---

## 0. 审查范围

本 Review 对 Plan v3 进行四维结构化评审，覆盖方向判定、覆盖完整性、可行性、风险。

Plan 目标：构建多阶段知识分类体系——以 GB/T 13745 三级学科为原子知识单元，通过独立裁决层（Discipline Resolver）实现多源文档自动分类，重写 kb-sync 路由链，并提供可 CRUD 的管理界面。

---

## 1. 方向判定

### 1.1 问题定位——认可

Plan 对三大知识来源的差异分析准确：

| 来源 | 特征 | 裁决策略 |
|------|------|---------|
| 学术/技术文献 | 自带 GB/T 13745 代码 | 正则提取 + 内容关键词 |
| 邗江区农技站报告 | 文件名含期号+作物+技术三维标签 | 模式匹配 |
| 农技云 App 文章 | 省级栏目标签 | 标签映射 |

### 1.2 三层分类模型——认可

```
Layer 1: ExpertDomain（耕/种/管/收/巡检/跨域） — Registry 已有
Layer 2: 二级学科 cateId（210.30/210.60） — 自动推导
Layer 3: 三级学科 disciplineCode（210.6040） ★ — 用户 CRUD
```

与已有 `ANALYSIS_EXPERTS` registry + ChromaDB per-expert collection 架构自然对齐。GB/T 13745 是推荐性国家标准，但高校科研论文、课题申报、成果统计硬性要求使用，知识库接入专业文献时天然携带此分类码。

### 1.3 多阶段实施策略——认可

采用 Step 1-5 + 5 轮 Handoff 的结构，每轮独立闭包，符合 ADD 范式原子事务拆分原则。SmartChunker（Step 3）独立排期不阻塞主线，规避了 Python→TS 移植的风险。

---

## 2. 覆盖完整性

### 2.1 数据模型/类型定义

| 项 | 覆盖 | 备注 |
|----|------|------|
| DocumentGrounding 接口（disciplineCodes + expertIds） | ✅ | 复用 metadata JSON，零 Schema 变更 |
| ExpertId 联合类型 | ✅ | 与 ANALYSIS_EXPERTS 一致 |
| GB/T 13745 数据结构 | ✅ | `{ code, name, parentCode, parentName }` |
| API 请求/响应类型 | ⚠️ | Plan 描述了 API 路径和 body，未给出完整 TS 类型（应由 Specs 补充） |
| disciplineCode → expertId 映射表结构 | ✅ | JSON 文件，非 DB 表 |
| derivedDomains 推导计算 | ✅ | 只读，不存库 |

### 2.2 API 签名/函数接口

| 端点 | 覆盖 | 备注 |
|------|------|------|
| `upload/route.ts` (+ grounding) | ✅ | FormData 兼容，grounding 可选 |
| `PUT /documents/:id/grounding` | ✅ | 含 expertId 合法性校验 |
| `POST /grounding/batch` | ✅ | add/replace/remove |
| `GET /grounding/stats` | ✅ | per-discipline + per-expert |
| `GET /grounding/disciplines` | ✅ | 全量学科列表 |
| `PUT /grounding/mapping` | ✅ | Step 5 |
| `discipline-resolver.ts` 函数签名 | ⚠️ | 三个子裁决器分别返回 `{ codes, confidence }` 结构，Plan 未明确函数签名（应由 Specs 补充） |
| `smart-chunker.ts` 函数签名 | ⚠️ | Python→TS 移植，Plan 未给出 TypeScript 接口（应由 Specs 补充） |

### 2.3 错误路径/降级处理

| 场景 | 覆盖 | 备注 |
|------|------|------|
| grounding.expertIds 含非法值 | ✅ | HTTP 400 + 具体错误信息 |
| 上传 grounding 格式非法 JSON | ✅ | 400 Bad Request |
| Resolver 全部子裁决器返回空 | ✅ | PENDING_CLASSIFY → 前端高亮 |
| ChromaDB 写入 expert collection 失败 | ✅ | 日志记录 + 继续其他 collection |
| 存量文档无 grounding | ✅ | 关键词 fallback |
| 存量 cateId → disciplineCode 迁移 | ✅ | 三阶段（共存→批量转换→清理） |
| 并发编辑 grounding | ❌ | P2 — 未考虑 last-write-wins |
| SmartChunker 超大文档处理 | ✅ | 安全切分三级回退 |
| Resolver LLM 灰色区域仲裁延迟 | ✅ | Phase 2 延期，先收集数据 |

### 2.4 数据迁移策略

| 项 | 覆盖 | 备注 |
|----|------|------|
| Schema 变更 | ✅ | 零变更，复用 metadata JSON |
| 存量文档 cateId → disciplineCode | ✅ | 三阶段迁移策略明确 |
| Expert Collection 幂等写入 | ✅ | 先查后写 + 断点续传 |
| 旧 CATEID_TO_EXPERT_COLLECTION 兼容 | ✅ | 保留为 fallback |
| Expert Collection 重复向量 | ✅ | 断点续传入库防重复 |

### 2.5 存储/索引成本

| 项 | 覆盖 | 备注 |
|----|------|------|
| metadata 字段大小 | ✅ | grounding JSON < 1KB |
| Expert Collection 向量存储 | ⚠️ | 已存在（当前 2964 条副本），但 Plan 未增加额外存储成本（替换而非新增双写） |
| ChromaDB 写入性能 | ⚠️ | P2 — kb-sync 改为批量写入可能改善当前逐条写入的性能 |

---

## 3. 可行性评估

### 3.1 技术可行性——高

- 所有改动均在现有模块内扩展，不引入新依赖
- API 路由复用 Next.js App Router
- 前端复用 ElTablePlus + Form 组件
- expertId → collectionName 直接读 Registry 静态对象
- 借鉴司农 hybrid-rag (南农+南理工) 的成熟算法

### 3.2 实施风险

| 风险 | 严重度 | 缓解措施 |
|------|--------|---------|
| GB/T 13745 数据获取（人工录入） | 中 | Step 1 前置门禁，未就绪禁止下游 |
| SmartChunker Python→TS 移植（439 行） | 中 | 独立排期（Step 3 不阻塞 Step 2/4） |
| LLM 灰色区域仲裁延迟 | 低 | Phase 2 延期，先纯规则 |
| 现有双写替换引入回归 | 中 | 旧映射保留为 fallback |
| 前端页面范围失控 | 低 | 分两期交付 |
| per-collection 缓存改动影响现有缓存 | 低 | 改动量小（~30 行），单文件 |

---

## 4. 决策结论

### 4.1 通过项

- ✅ 方向正确：GB/T 13745 三级学科作为原子知识单元 + 多源裁决器链
- ✅ 架构简洁：零 Schema 变更 + Registry 静态映射 + JSON 配置文件
- ✅ 多阶段交付：Step 1-5 + Handoff 5 轮原子事务，每轮独立闭包
- ✅ 风险可控：SmartChunker 独立排期，LLM 仲裁 Phase 2，双写旧映射 fallback
- ✅ 上一轮 Review P0 项全部吸收：前置门禁 G1/G2、错误路径、幂等策略、迁移策略

### 4.2 需关注（P1 — Review 回流时补充，不阻塞实施）

| # | 问题 | 建议 |
|---|------|------|
| 1 | API 请求/响应完整 TypeScript 类型未在 Plan 中定义 | 在 Specs 中补充 |
| 2 | Resolver / SmartChunker 函数签名未明确 | 在 Specs 中定义完整接口 |
| 3 | ChromaDB 批量写入性能 | 后续版本优化 |
| 4 | 并发编辑 grounding | 后续版本加乐观锁 |

---

## 5. 影响评估

### 5.1 受影响文件

| 文件 | 改动类型 | 风险 |
|------|---------|------|
| `src/data/gbt13745-agriculture.json` | 新建 | 低 |
| `src/services/discipline-resolver.ts` | 新建 | 中 |
| `data/discipline-to-expert-mapping.json` | 新建 | 低 |
| `scripts/kb-sync-expert-collections.ts` | 重写 | 中 |
| `src/services/knowledge-indexer.ts` | 修改（双写替换） | 中 |
| `src/app/api/knowledge/upload/route.ts` | 修改 | 低 |
| `src/services/semantic-cache.ts` | 修改 | 低 |
| `src/services/smart-chunker.ts` | 新建 | 中 |
| `src/app/api/knowledge/documents/[id]/grounding/route.ts` | 新建 | 低 |
| `src/app/api/knowledge/grounding/batch/route.ts` | 新建 | 低 |
| `src/app/api/knowledge/grounding/stats/route.ts` | 新建 | 低 |
| `src/app/api/knowledge/grounding/disciplines/route.ts` | 新建 | 低 |
| `src/app/api/knowledge/grounding/mapping/route.ts` | 新建 | 低 |
| agrisynapse `customization/index.vue` | 重写 | 中 |

### 5.2 数据流影响

- 上传流：不变，追加 grounding 字段
- 索引流：`CATEID_TO_EXPERT_COLLECTION` 替换为 `disciplineCode → expertId → collectionName`
- 检索流：不变（ChromaDB per-expert collection 已存在，仅填充方式改变）
- 缓存流：全局一刀切 → per-collection 精细化

### 5.3 回滚风险

- **低风险**：API 新增、metadata.grounding 字段 optional、旧映射保留 fallback
- **中风险**：kb-sync 重写 + 双写替换，回滚需恢复旧脚本和 CATEID_TO_EXPERT_COLLECTION 映射

---

## 6. 下一步

1. P1 项回流至 Specs（API 类型、函数签名）
2. 生成 Specs 三元组（spec.md + tasks.md + checklist.md）
3. 按 Handoff 第1轮启动实施
4. 打 DPS 门禁（target ≥ 85）
