# farm-agent-climate-zone-lookup-review-v1

## Review 元信息

- **Review 对象**: `.qoder/plans/farm-agent-climate-zone-lookup-plan-v1.md`
- **对比方案**: 方案 C（简化查表法 ~10km JSON）为唯一选定方案
- **Review 时间**: 2026-06-18
- **Review 类型**: 架构决策 + 方案选型 + 合规检查
- **前置阅读**: Plan 本身（无其他依赖文档）

---

## 1. 总体结论

方向正确，方案选型合理，具备执行基础。存在 3 个需修正的问题（0 P0 + 2 P1 + 1 P2），修正后可直接进入实施。

---

## 2. 正向评价

1. **方案选型扎实**：4 方案对比表格清晰，C 方案（~10km JSON 查表）在精度/成本/部署复杂度之间达到最佳平衡
2. **坐标系语义正确**：明确气候带查表用 WGS-84 不走 GCJ-02，与天气 API 的 GCJ-02 需求正确解耦
3. **模块边界清晰**：Schema / impl / index 三层结构遵循项目现有约定
4. **坐标解析复用设计好**：方案 A（提取到 coordinate-utils.ts）优于方案 B（直接 re-import），DRY 原则正确
5. **验收标准具体可测**：抽样验证点明确（北京→Dwa、广州→Cfa、拉萨→Cwb、乌鲁木齐→Bwk）

---

## 3. 问题清单

### P1-1: 网格数据生成依赖外部 Python/GDAL 工具链，可能阻塞 Phase 2

**问题描述**：Plan §五 Phase 2 要求执行 `generate-climate-grid.ts` 生成 ~2-3MB 的网格 JSON。但 §8.3 列出的数据源（kgcpy PyPI / GloH2O GeoTIFF）都是 Python/GDAL 工具链，与 Node.js 项目无直接集成路径。`generate-climate-grid.ts` 如果只是调用 shell 执行 Python 脚本，需要在 Plan 中明确这个依赖。

**修正建议**：在 Plan §8.3 补充数据生成的具体命令（如 `python3 -m kgcpy export --region china --resolution 0.1`），并在 Phase 2 验收标准中增加"Python 3 + kgcpy 可用"作为前置条件。

### P1-2: 坐标工具提取改动 weather-tools import 路径，存在回归风险

**问题描述**：Plan §8.1 建议方案 A——将 `parseTiandituPath`/`calcCentroid`/`detectLocationType` 提取到 `coordinate-utils.ts`，同时更新 weather-tools 的 import 路径。这会影响 weather-tools.ts 的已有引用，需确认无其他文件也 import 了这些函数。

**修正建议**：在 Plan §4 Phase 3 Task 3.2 中增加一步"grep 全项目确认无其他文件直接 import weather-tools 中的这三个函数"，并在验收标准中增加"weather-tools 回归测试通过"。

### P2-1: 审计日志建议补充 DB 持久化

**问题描述**：Plan §3.2 Task 3.2 提到"审计日志：记录查表过程"，但未明确使用 `writeAuditLog`（DB 持久化，与 weather-tools 保持一致）还是仅 `agentAudit`（console + file）。weather-tools 同时使用了两者。

**修正建议**：在 Plan §3.2 Task 3.2 的审计日志要求中明确"同时调用 agentAudit + writeAuditLog，保持与 weather-tools 审计模式一致"。

### P0/P1 问题汇总

| 编号 | 严重程度 | 问题 | 回流状态 |
|------|:------:|------|:------:|
| P1-1 | P1 | 网格数据生成依赖外部 Python/GDAL 工具链 | ✅ 已回流 |
| P1-2 | P1 | 坐标工具提取改动 weather-tools import 路径，回归风险 | ✅ 已回流 |
| P2-1 | P2 | 审计日志建议补充 DB 持久化（writeAuditLog） | ✅ 已回流 |

---

## 3.1 API 签名审查

### 工具签名

```typescript
// query_climate_zone 工具签名（推断）
export const queryClimateZoneTool = tool(
  async ({ location }: { location: string }) => {
    // 返回: { success: boolean, code?: string, name?: string, category?: string, properties?: ClimateZoneProperties, wgs84?: { lng: number, lat: number }, error?: string }
  },
  {
    name: "query_climate_zone",
    description: "查询指定位置的柯本-盖格气候带类型及中国农业属性。支持城市名称/单点坐标/多边形路径。",
    schema: ClimateZoneSchema,
  }
)
```

| 检查项 | 状态 | 说明 |
|--------|:--:|------|
| location 参数类型 | ✅ | `z.string()`，与 weather-tools 一致 |
| 返回值结构 | ✅ | `{ success, code, name, category, properties, wgs84 }` 清晰 |
| 错误处理签名 | ✅ | `{ success: false, error: string }` 模式与 weather-tools 一致 |
| 审计植入点 | ✅ | 函数入口 + 坐标解析 + 返回前各一处 |

### 坐标工具提取签名（不影响 API 契约）

```typescript
// coordinate-utils.ts 导出函数（从 weather-tools 提取，签名不变）
export function parseTiandituPath(path: string): [number, number][]
export function calcCentroid(points: [number, number][]): { lng: number; lat: number }
export function detectLocationType(location: string): LocationType
export function wgs84ToGcj02(wgsLng: number, wgsLat: number): { lng: number; lat: number }
export function resolveWeatherLocation(rawLocation: string): { location: string; type: LocationType; wgs84?: {...}; gcj02?: {...} }

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 影响 | 风险等级 |
|------|------|---------|
| `src/agents/tools/impl/weather-tools.ts` | import 路径重构（如提取坐标工具） | 中 |
| `src/agents/tools/impl/climate-zone-tools.ts` | 新建 | 低 |
| `src/agents/tools/schemas/climate-zone-tools.ts` | 新建 | 低 |
| `src/agents/tools/index.ts` | 新增一行 import + 注册 | 低 |
| `src/data/climate-zones/` | 新建目录 + 数据文件 | 低 |

### 4.2 数据流影响

纯加法，无破坏现有数据流。

### 4.3 回滚风险

极低。新工具独立模块，删除即可回滚。唯一注意点：如执行坐标工具提取，需保留 weather-tools 中原函数定义直至确认无外部引用。

---

## 5. 建议修正优先级

| 优先级 | 编号 | 问题 | 处理 | 回流状态 |
|--------|------|------|------|:--:|
| 🔴 高 | — | 无 | — | — |
| 🟡 中 | P1-1 | 网格数据生成依赖外部工具链 | 补充数据源调用命令 + Python 前置条件 | ✅ 已回流 Plan §8.3 + §五 Phase 2 |
| 🟡 中 | P1-2 | 坐标工具提取回归风险 | 增加 grep 确认 + 回归测试 | ✅ 已回流 Plan §四 Task 3.2 + §五 Phase 5 |
| 🟢 低 | P2-1 | 审计日志缺 DB 持久化 | 明确 writeAuditLog 调用 | ✅ 已回流 Plan §四 Task 3.2 |

---

## 6. 最终建议

**推荐执行顺序**：
1. 回流 P1-1/P1-2/P2-1 至 Plan §7
2. 生成 Specs 三元组（spec/tasks/checklist），将 Review 修正点纳入 Requirements
3. 生成 add-route
4. DPS 门禁 ≥ 85
5. 进入 Step 1 实施

**完成判定标准**：Plan §7 回流记录中 P1-1/P1-2/P2-1 均已关闭。
