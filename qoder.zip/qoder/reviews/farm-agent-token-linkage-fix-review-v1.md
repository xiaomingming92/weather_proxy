# Review: 跨服务 Token 透传链路修复与工具结果业务日志双写

**日期**: 2026-06-12
**类型**: Runtime Review（联调修复）
**关联 Plan**: workspace-pmo-plan-v1.md

---

## 问题诊断

### P0: Farm-Server 工具调用返回 "token 未配置"

**根因链**:

```
agrisynapse login → setToken(仅存 accessToken+refreshToken, 缺失 expiresTime)
  → handshake 请求体 { type, userVO, action } 无 token 字段
    → farm-agent handleHandshakePOST 收不到 token → credential store 空
      → ensureValidToken 永远返回 null
        → 工具调用 getFarmToken() → null → "Farm-Server token 未配置"
```

## 修复清单（6 文件）

### farm-agent 侧 (3 文件)

| 文件 | 改动 | 原因 |
|------|------|------|
| `src/app/api/agent/[hash]/route.ts` | 放宽 token 保存条件：`accessToken+refreshToken` 即可（不强制 expiresTime），缺失时默认 1 小时 | 兼容 agrisynapse 旧 session 无 expiresTime |
| `src/agents/index.ts` | 工具结果新增 `writeAuditLog("TOOL_RESULT","TOOL",...)` DB 业务日志写入 | 对齐 agentAuditRequest/Response 的双写模式 |
| `src/lib/agent-audit-logger.ts` | `writeAuditLog` 从 private → export | 跨模块写入 AuditLog 表 |

### agrisynapse 侧 (3 文件)

| 文件 | 改动 | 原因 |
|------|------|------|
| `src/utils/auth.ts` | `setToken()` 新增 `FARM_TOKEN_EXPIRES` 缓存 + `getFarmTokenExpiresTime()` | handshake 需要传递过期时间 |
| `src/api/agent/types.ts` | `HandshakeRequest` 新增 `accessToken?/refreshToken?/expiresTime?` 字段 | 握手请求体支持 token 透传 |
| `src/api/agent/index.ts` | `handshake()` 从缓存读取 token 并发送；旧 session 无 expiresTime 时用 `Date.now()+3600000` 兜底 | 实际透传 token 到 farm-agent |

## 验证结果

```
✅ query_farm_weather:  success:true, total:50644 条气象数据
✅ query_soil_moisture: success:true (该地块无数据)
✅ query_insect_data:   success:true (该地块无数据)
```

## 遗留问题

工具调用成功后 LLM 推理节点报告 `无证据, 跳过推理`，原因是工具返回数据未注入 evidenceChain。LLM 使用了兜底通识策略 (`strategyId: "deep:fallback"`) 生成回复。需后续修复工具结果 → 证据链的桥接逻辑。

## Devlog 记录

6 条 `record_dev_operation` 已全部落库确认。

---

**结论**: Token 透传链路已修复并验证通过。工具已能正常调用 Farm-Server 返回真实数据。HANDOFF → 修复证据链路桥接。
