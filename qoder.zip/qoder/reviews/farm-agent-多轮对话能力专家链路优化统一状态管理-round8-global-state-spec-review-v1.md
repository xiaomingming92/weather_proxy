# farm-agent-多轮对话能力专家链路优化统一状态管理-round8-global-state-spec-review-v1

## Review 元信息

- **Review 对象**: `.qoder/specs/farm-agent-global-state/`（spec.md + tasks.md + checklist.md）
- **对比方案**: Spec vs Handoff（第8轮章节） vs 架构文档 vs 第1-7轮实际代码交付
- **Review 时间**: 2026-06-04
- **Review 类型**: spec-review（执行前方案评审）
- **前置阅读**:
  - `.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-7轮原子事务交接-handoff-v1.md` §第8轮
  - `.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-plan-v1.md` §0.8
  - `.qoder/specs/farm-agent-global-state/spec.md`
  - `.qoder/specs/farm-agent-global-state/tasks.md`
  - `.qoder/specs/farm-agent-global-state/checklist.md`
  - `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md`
  - `docs/哲学理论/4.嵌入式路径演化策略.md`
  - 第1-7轮全部代码交付

---

## 1. 总体结论

**结论级别：可通过，方案收敛完成**

四交付物方向正确，嵌入式路径演化策略对齐项目哲学基础。发散过程中的两个错误方向已被识别并否定，最终方案落回到已有管线的嵌入式增强。

---

## 2. 正向评价

1. **符合嵌入式路径演化方法论**：subIntents 不新增节点、不新增路由、不破坏管线结构，在既有 `intention → retrieval → reasoning → response` 路径上施加最小结构偏移

2. **与前 7 轮闭包兼容**：`subIntents` 为空时行为完全不变；GlobalStateProvider/CognitiveEventBus/PolicyUpdateLoop 全部可选参数，不传则零开销

3. **方案迭代充分**：发散过程中的 Competition scaffold 和 activeExperts 触发条件经多轮讨论被否定，方案从外部机制收拢到嵌入式演化，符合"不破坏系统存活条件"的核心原则

4. **意图语义定义补全**：当前 intention prompt 将 7 个标签裸扔给 LLM，缺少语义说明。本轮的 prompt 重构同时解决了这个问题（见 §5）

5. **交互点机制赋能**：不是新建决策机制，而是让已有的 interactionPointDetection 借助 GlobalSystemState 获得更完整的当前轮上下文（GlobalSystemState 提供的全局状态快照替代了节点从 AgentState 中拼凑的局部信息），交互点本身的职责不变——仅在当前轮推理结论中存在 ambiguity 时停住管线询问用户

6. **能力专家体系首次闭环**：第 4 轮定义了 ANALYSIS_EXPERTS 注册表和 activateExpert() 函数但未调用。第 8 轮通过 subIntents[].domain → activateExpert() 完成语义路由到专家激活的桥接，实现三路注入（evidenceFilter → retrieval / promptTemplate → reasoning / outputSections → response），是 Semantic Router 架构在农业垂直领域的完整落地

---

## 3. 方案发散与收敛过程

### 3.1 发散起点

第8轮 handoff 的原始目标：Global State Model + Cognitive Event Bus + Policy Loop。前三个交付物无争议，第四个交付物经历了完整的发散-否定-收敛过程。

### 3.2 否定方向一：Competition（多专家竞争执行）

**假设**：activeExperts > 1 时触发多路径推理，每条路径对应一个 expert 的 LLM 调用，评分后选冠军。

**否定原因**：
- `activeExpertIds` 在当前管线中几乎总是 `length === 1`（intent → strategy 一对一匹配）
- `activeExperts > 1` 的触发条件在当前系统中几乎永远不会成立
- 触发条件"方案 A（跨轮累积触发）"和"方案 B（意图多义触发）"经评审均不自然，本质上是为不存在的场景强行设计触发条件

### 3.3 收敛方向：Embedded Path Evolution（嵌入式路径演化）

**核心思路**：让 intentionNode 产出子意图列表（`subIntents[{ domain, subQuery }]`），管线仍然是线性单次执行，但内容覆盖所有子域。

**与"嵌入式路径演化策略"理论的对齐**：

| 理论约束 | 本轮实现 |
|---------|---------|
| 不替换系统 | subIntents 是 CurrentTask 的可选字段，不新增节点和路由 |
| 顺着既有路径 | intention → retrieval → reasoning → response 路径不变 |
| 小步变化、可回滚 | subIntents 为空时 === 当前行为，零影响 |
| 改写系统继续前进的规则 | retrieval 自动扩大搜索范围，reasoning 一个 prompt 回答多个子问题 |

---

## 4. 决策结论

第8轮最终交付物（4 项）：

| # | 交付物 | 文件 | 说明 |
|---|--------|------|------|
| 1 | **GlobalSystemState** | `src/agents/global-state.ts` (新建) | 七域快照 + GlobalStateProvider + sync/diff |
| 2 | **Cognitive Event Bus** | `src/agents/cognitive-event-bus.ts` (新建) | 11 种认知事件 + pub/sub + timeline |
| 3 | **Policy Update Loop** | `src/agents/policy-update-loop.ts` (新建) | 4 个纯决策函数 + evaluate/apply/rollback |
| 4 | **Embedded Path Evolution** | 零新文件，散落在已有节点 | subIntents 类型 + intention/retrieval/reasoning/response 节点增强 |

修改文件：

| 文件 | 改动 |
|------|------|
| `src/agents/state.ts` | `agentStateToCognitiveSnapshot()` + `CurrentTask` 新增 `subIntents?` |
| `src/agents/index.ts` | 管线注入 CognitiveEventBus + GlobalStateProvider |
| `src/agents/nodes/intention.ts` | prompt 重构：意图语义定义 + subIntents 产出 |
| `src/agents/nodes/retrieval.ts` | subIntents 触发时检索全部子域并集 |
| `src/agents/nodes/reasoning.ts` | subIntents 触发时 prompt 携带多子问题 |
| `src/agents/nodes/response.ts` | subIntents 触发时按子域分段输出 |
| `src/agents/prompts/intention.ts` | 意图语义定义（见 §5）+ subIntents 输出格式 |
| `src/services/analysis-context.ts` | `AnalysisTurnRecord` 新增 `previousSubIntents?` 字段 |
| `src/app/api/agent/chat/stream/route.ts` | 初始化 GlobalStateProvider + CognitiveEventBus + 触发 PolicyUpdateLoop |

---

## 5. 意图范畴划分

当前 intention prompt 将 7 个标签订阅给 LLM，LLM 靠常识推断含义。本轮 prompt 重构中补充以下语义定义：

### 5.1 七意图语义定义

| 意图 | 含义 | thinkingLevel | 典型问法 |
|------|------|:---:|---------|
| `chat` | 日常闲聊、寒暄问候、不涉及农业专业分析的对话 | fast | "你好"、"今天天气不错" |
| `question` | 事实性问答，有明确答案（如定义、数值、流程步骤），不需要深度推理或多因素权衡 | deep | "水稻育秧分哪几个步骤？"、"今年稻飞虱的防治阈值是多少？" |
| `analysis` | 多因素分析、农情研判、需要证据链支撑的综合判断 | deep | "这篇地今年稻瘟病风险如何？"、"分析下当前土壤墒情" |
| `planning` | 制定计划、任务排期、资源分配方案 | deep | "帮我制定下周的植保作业计划"、"安排三个人去三号地块" |
| `decision` | 多个方案之间的最优选择，需要权衡利弊 | deep | "方案A和方案B哪个更好？"、"杀虫剂和生物防治选哪个？" |
| `creation` | 新建实体（任务/项目/文档/配置），不是修改已有的 | deep | "创建一个选种方案"、"新建一个水稻实验项目" |
| `modification` | 修改、更新、调整已有实体的属性或状态 | deep | "把任务A的截止日期改成下周五"、"更新地块的种植作物" |

### 5.2 跨域判定规则

当用户问题包含两个或以上意图域的要素时（如"这片地种玉米还是大豆，虫害风险分别多大"同时涉及 decision + analysis），产出 `subIntents`：

```json
{
  "intent": "analysis",
  "subIntents": [
    { "domain": "crop_compare", "subQuery": "玉米 vs 大豆品种对比" },
    { "domain": "pest_risk", "subQuery": "虫害风险评估" }
  ]
}
```

**主意图**（`intent` 字段）取占比最大的域。**子意图**（`subIntents`）为其他域的拆解。subIntents 为可选字段，单域问题不产出。

### 5.3 子意图 → 能力专家桥接机制

意图（intent）和专家（expert）是正交的两个维度——意图定义认知操作类型，专家提供该领域的分析视角。第 8 轮通过 `subIntents[].domain` 字段建立桥接：

```
intentionNode 产出:
  subIntents: [
    { domain: "crop_compare", subQuery: "玉米 vs 大豆品种对比" },
    { domain: "pest_risk",   subQuery: "虫害风险评估" }
  ]

  ↓ subIntents[].domain → activateExpert(analysisCtx, domain)

ANALYSIS_EXPERTS 注册表:
  crop_compare → { label: "作物对比分析", domain: "种植",
                    evidenceFilter: { cateId: "planting_technique" },
                    promptTemplate: "你是作物对比分析专家...",
                    outputSections: ["conclusion", "evidence", "reasoning", "confidence", "risk", "interaction"] }

  pest_risk   → { label: "病虫害风险评估", domain: "管收",
                    evidenceFilter: { cateId: ["plant_protection", "agri_tech"] },
                    promptTemplate: "你是农业植保专家...",
                    outputSections: ["conclusion", "evidence", "reasoning", "confidence", "risk", "action_steps"] }

  ↓ 三路注入到管线

  retrieval    ← mergeExpertEvidenceFilters()  → ChromaDB 按 cateId 精准过滤
  reasoning    ← buildAnalysisExpertContext()  → prompt 注入专家 label + domain + promptTemplate
  response     ← withActiveExpertSections()    → 合并 expert.outputSections，决定前端渲染面板
```

### 5.4 Expert Grounding — 专家知识锚定

医疗 Agent 的产品形态揭示了另一层缺失：心血管诊断专家不是用户提问后去全量医学资料里搜"心血管相关"，而是在用户进入专家界面前就已经——预装好了心电图解读规范、血压分级标准、冠脉造影指征。用户只带着**本次变量**（年龄 56、血压 145/95、胸闷 3 天）进来，LLM 在已闭合的知识域内做推理。

这给出了专家能力的完整两层模型：

```
第一层：专家知识域（激活时闭合）
  ANALYSIS_EXPERTS[pest_risk] 声明:
    knowledgeDomain: "植保知识域"
    cateId: ["plant_protection", "agri_tech"]
    → 激活时确认知识域在 ChromaDB 中已就绪（索引完整、同步最新）
    → 知识域 = 推理的"已知条件"，闭合后不变

第二层：用户变量注入（运行时匹配）
  用户提问 → 提取本次变量: 作物=水稻、生长期=抽穗期、地点=邗江、天气=高温高湿
  → retrieval 在已闭合的知识域内匹配变量，不是发现知识域
  → reasoning 在闭合的专家视角内推断变量组合下的结论
```

**与当前实现的对比**：

| | 当前 farm-agent | 行业标准（Expert Grounding） |
|---|---|---|
| 知识域何时确定 | retrieval 运行时用 evidenceFilter 筛 | 专家激活时 declaration 已闭合 |
| 用户提问角色 | 决定搜什么 + 搜哪里 | 只注入变量，不找知识域 |
| ChromaDB 查询 | "在 plant_protection 类别下搜 query" | "在已就绪的植保知识域内匹配变量" |
| 语义含义 | 搜索发现（knowledge discovery） | 变量推理（variable reasoning） |
| fallback 行为 | 过滤无结果 → 降级为全量搜索 | 变量不匹配 → 告诉用户"该条件下无相关数据" |

**第 8 轮的改进方向**：当前 `evidenceFilter` 注入已经实现了检索时的 cateId 过滤，但缺少了 Expert Grounding 的标准机制——激活时确认知识域已就绪（索引完整、同步最新）。这一步不在第 8 轮代码中完成（依赖知识库管理基础设施），但 `activateExpert()` 调用点应该声明这个意图——激活的不是一个"过滤条件"，而是一个"已锚定的 Grounding Domain"。后续轮次可在 registry 中新增 `groundingDomainReady(): Promise<boolean>` 回调。

**设计原则**：
- subIntents 的 `domain` 取值空间 = ANALYSIS_EXPERTS 的 key 集合（crop_compare / roi_analysis / pest_risk）。未来新增专家只需在 registry 中注册，intention prompt 的跨域判定规则自动覆盖
- 显式专家选择（前端入口点击）优先于语义路由——用户选了 expert 不覆盖，未选时由 intentionNode 产出
- activateExpert() 在第 4 轮已定义但未调用，第 8 轮首次在 intention 节点中调用，完成语义路由到管线注入的最后一步

### 5.5 外部审查：工程风险评估

本轮方案经外部 AI（Grok + SOLO Agent + 第二位 Agent）独立审查，识别出以下工程风险。审查结论已反馈至 spec 补充防御性约束。

#### 5.5.1 Grok：三个架构级风险

**风险一：Global State Model — 审计性 vs 性能瓶颈**

6 节点管线每次节点结束调用 `syncFromAgentState()`，如果每次同步进行 JSON 序列化/深拷贝，会产生 CPU 开销。spec 已补充 §1.2.1 性能约束：`syncFromAgentState()` 必须是字段投影映射，禁止序列化操作；`diff()` 惰性计算，不在管线热路径上。

**风险二：Cognitive Event Bus — 跨模块认知一致性**

`PolicyUpdateLoop` 订阅 `intent:detected` 事件时读取 `GlobalStateProvider.getSnapshot()`，但此时 `agent` 子域可能尚未同步（syncFromAgentState 在节点结束后才执行），导致读取不完整状态。spec 已补充 §2.2.1 Handler 依赖声明契约：handler 注册时声明 `dependsOn`，event bus emit 前检查子域就绪状态。

**风险三：Policy Loop — 自主演化失控**

纯函数不保证输出安全——级联放大可能导致 promptHint 权重等参数恶性循环。spec 已补充 §3.3.1 五条安全约束：

| 约束 | 内容 |
|------|------|
| 变化幅度上限 | cache_ttl ±30%、promptHint ±10% 权重、expert 只增不减、evidenceFilter 只宽不紧 |
| 冷却期 | 同一 domain 两次调整最少间隔 5 轮 |
| 置信度硬门槛 | confidence >= 70 才允许 apply，低门槛只存档 |
| 自动回滚 | apply 后 5 轮指标未改善则自动 rollback |
| 理由可读性 | decisionReason 必须四段式（阈值→当前值→方向→预期效果） |

#### 5.5.2 SOLO Agent：跨轮指代消解 + 激活抖动

SOLO Agent 确认了嵌入式路径演化是正面解法（非妥协），Competition 是伪需求。同时识别出两个运行态风险：

- **跨轮指代消解**：Turn 2 的"那虫害风险呢"依赖 Turn 1 的上下文正确传递。spec 已补充 intention prompt 注入上一轮上下文摘要机制。
- **激活抖动**：Turn 1 激活 crop_compare + roi_analysis，Turn 2 全卸载只剩 pest_risk。不是 bug，但需要在 intention prompt 中正确判断"追问已有域" vs "新域"。spec 已通过 `previousSubIntents` 结构化字段解决。

#### 5.5.3 第二位 Agent：subIntents 三层分析 + 历史锚点

第二位 Agent 识别出两个问题的耦合关系——**intentionNode 每轮独立判断，但多轮对话中拆解决策应该有连续性**——并提出三层分析：

**场景 A — Rich context loss at sub-domain boundary**：Turn 1 分域输出时，pest_risk 子段可能只带"虫害风险较低"一句，裁剪了"这块地在 XX 区域、当前墒情 YY"的被多域共享的背景数据。spec 已补充 response 跨域共享背景保留约束（§4.3）。

**场景 B — 单域跳跃**：风险低，是 LLM 长上下文能力问题，非 subIntents 问题。

**场景 C — 重复拆解**：intentionNode 看不到 Turn 1 的 `{ subIntents: [crop_compare, pest_risk] }` 这个结构化字段，每轮从零判断。这是 subIntents 边界问题的根因。

**subIntents 边界三层分析**：

| 层次 | 问题 | 判定 |
|------|------|------|
| 第一层：拆还是不拆 | ANALYSIS_EXPERTS 注册表的 key 集合与用户语义边界不在同一粒度。用户直觉里"收益"是"对比"的一部分，但 roi_analysis 是独立 expert | 意图 prompt 必须告知 LLM 可用的 expert domain 列表，做 Expert Grounding 前置语义锚定（spec §4.2.2） |
| 第二层：子问题依赖 | "基于虫害风险来决策种什么"中 pest_risk 是 crop_compare 的输入。当前管线单次串行不支持子问题拓扑排序 | 依赖型 subIntents 不在 R8 范围，fallback 为单域处理，保留给 L4（spec Non-Requirements） |
| 第三层：零样本分类无 ground truth | 该拆不拆 / 不该拆乱拆 / 拆错域，三种错误全依赖 LLM | 属于 Expert Grounding 范畴，第 9 轮通过 grounding.ready() 锚定知识域减少拆错域风险 |

**解决方案**：在 AnalysisContext turnHistory 中存储结构化 `previousSubIntents[{ domain, subQuery, resolved }]`，让下一轮 intentionNode 显式看到上一轮的拆解决策。自然语言摘要 + 结构化字段双通道传递，互相验证。spec 已采纳（§4.2.1）。

### 5.6 外部审查总结

三个外部 AI 独立审查覆盖了从架构性能到运行态风险的完整链条，所有风险均已反馈到 spec 补充防御性约束。审查过程验证了方案设计的可辩护性——不同 AI 从不同角度推导，最终结论一致：Competition 是伪需求，Embedded Path Evolution 是正面解法，核心风险在跨轮上下文传递和 subIntents 拆解质量，PolicyUpdateLoop 需要硬性安全边界。

### 5.7 能力专家扩展机制

**原则**：`ANALYSIS_EXPERTS` 注册表是新增专家的唯一切入点。注册完成后，三路注入（evidenceFilter → retrieval / promptTemplate → reasoning / outputSections → response）全部自动生效，不需要修改管线节点代码。

以新增 `soil_analysis`（土壤分析专家）为例，完整扩展链路：

```
                    ┌── 唯一切入点 ──┐
                    │               │
           ANALYSIS_EXPERTS Registry
           { soil_analysis: {
               id, label, domain,
               evidenceFilter: { cateId: {$in: ["soil_science"]} },
               promptTemplate: "你是土壤分析专家...",
               outputSections: ["结论", "养分", "改良方案"]
           }}
                    │
      ┌─────────────┼─────────────┬──────────────┐
      ▼             ▼             ▼              ▼
intention       retrieval     reasoning       response
(需感知域名)     (自动)         (自动)          (自动)
```

| 适配点 | 类型 | 操作 |
|--------|:---:|------|
| `ANALYSIS_EXPERTS` 注册表 | **手动** | 新增 1 个条目（~20 行），是唯一必改的文件 |
| intention prompt 域名列表 | **自动**（R8 后） | 从 `Object.keys(ANALYSIS_EXPERTS)` 动态生成，LLM 自动感知新域名 |
| retrieval（evidenceFilter 注入） | **自动** | `mergeExpertEvidenceFilters()` 读注册表，新 cateId 自动合并到 ChromaDB where 子句 |
| reasoning（promptTemplate 注入） | **自动** | `buildAnalysisExpertContext()` 读注册表，新 prompt 自动注入 LLM |
| response（outputSections 合并） | **自动** | `withActiveExpertSections()` 读注册表，前端自动渲染新面板 |
| ChromaDB 知识数据 | **手动**（R8）/ 手动（R9 建 collection） | 确保 `cateId: "soil_science"` 的文档在知识库中存在 |
| PolicyUpdateLoop | **自动** | `evaluateExpertActivation()` 从 turnHistory 读取 activeExpertIds，新 expert 的激活频率自动纳入统计 |
| 前端渲染 | **自动** | `outputSections` 决定面板，前端不需要感知"多了个专家" |

**关键设计**：intention prompt 的域名列表必须从注册表动态生成，不得硬编码。这是 spec §4.2.2 的核心约束——intention prompt 告知 LLM 可用 expert domain 列表，LLM 在拆解 subIntents 时知道 `"soil_analysis"` 是一个合法域并能将其映射到恰当的语义范围。

---

## 6. 第8轮完成后 OS 架构图

```
┌──────────────────────────────────────────────────────────────────┐
│                     Farm-Agent OS Kernel                          │
│                   (第8轮架构合流后完整视图)                          │
├──────────────────────────────────────────────────────────────────┤
│                                                                    │
│  ┌────────────────────── 应用层 ──────────────────────────────┐  │
│  │  POST /api/agent/chat/stream  →  SSE Stream →  Frontend     │  │
│  │  ChatThread CRUD  │  Semantic Cache  │  Model Config        │  │
│  └────────────────────────────────────────────────────────────┘  │
│                              │                                     │
│  ┌────────────────────── 策略控制层 ★第8轮新增★ ──────────────┐  │
│  │                                                              │  │
│  │  ┌───────────────────┐  ┌───────────────────┐               │  │
│  │  │ PolicyUpdateLoop  │  │ GlobalStateProvider│               │  │
│  │  │                   │  │                   │               │  │
│  │  │ evaluate()        │  │ chat    ┆ agent   │               │  │
│  │  │  ├─ cacheTtl      │  │ memory  ┆ exec    │               │  │
│  │  │  ├─ promptHint    │  │ policy  ┆ audit   │               │  │
│  │  │  ├─ expertActive  │  │ feedback┆ meta    │               │  │
│  │  │  └─ evidenceFilter│  │                   │               │  │
│  │  │                   │  │ getSnapshot()     │               │  │
│  │  │ apply()/rollback()│  │ updateDomain()    │               │  │
│  │  │                   │  │ diff()            │               │  │
│  │  └───────┬───────────┘  └────────┬──────────┘               │  │
│  │          │ 策略更新反馈            │ 全局状态快照               │  │
│  └──────────┼──────────────────────┼──────────────────────────┘  │
│             │                      │                              │
│  ┌──────────┴────────── 认知事件层 ★第8轮新增★ ──────────────┐  │
│  │                                                              │  │
│  │  ┌─────────────────────────────────────────────────────┐    │  │
│  │  │              CognitiveEventBus                        │    │  │
│  │  │                                                      │    │  │
│  │  │  thought:started → intent:detected → route:decided   │    │  │
│  │  │  → evidence:retrieved → reasoning:path_generated     │    │  │
│  │  │  → subIntent:detected/resolved                       │    │  │
│  │  │  → strategy:resolved → action:proposed                │    │  │
│  │  │  → feedback:observed → policy:updated                 │    │  │
│  │  │  → system:done / system:error                         │    │  │
│  │  │                                                      │    │  │
│  │  │  subscribe() / emit() / getHistory() / getTimeline()  │    │  │
│  │  └──────────────────────┬───────────────────────────────┘    │  │
│  └─────────────────────────┼───────────────────────────────────┘  │
│                            │                                      │
  │  ┌────────────── 能力专家注册层 (第4轮 + 第8轮首次调用) ──────────┐  │
  │  │                                                              │  │
  │  │  ┌─────────────────────────────────────────────────────┐    │  │
  │  │  │           ANALYSIS_EXPERTS Registry                   │    │  │
  │  │  │                                                      │    │  │
  │  │  │  crop_compare ┆ roi_analysis ┆ pest_risk             │    │  │
  │  │  │  label/domain/description/inputSchema                 │    │  │
  │  │  │                                                      │    │  │
  │  │  │  ┌── Expert Grounding（激活时闭合，用户只注入变量）──┐│    │  │
  │  │  │  │ crop_compare → 种植技术资料               │     │    │  │
  │  │  │  │ roi_analysis → 市场/经济数据              │     │    │  │
  │  │  │  │ pest_risk    → 植保/农技资料              │     │    │  │
  │  │  │  └───────────────────────────────────────────┘     │    │  │
  │  │  │                                                      │    │  │
  │  │  │  ┌────────────────── 三路注入 ──────────────────┐   │    │  │
  │  │  │  │                                              │   │    │  │
  │  │  │  │  evidenceFilter  → retrieval  → ChromaDB    │   │    │  │
  │  │  │  │  promptTemplate  → reasoning  → LLM prompt  │   │    │  │
  │  │  │  │  outputSections  → response   → 前端面板     │   │    │  │
  │  │  │  └──────────────────────────────────────────────┘   │    │  │
  │  │  │                                                      │    │  │
  │  │  │  ★第8轮★ activateExpert() 首次被 intentionNode 调用  │    │  │
  │  │  │  subIntents[].domain → ANALYSIS_EXPERTS[domain]      │    │  │
  │  │  └─────────────────────────────────────────────────────┘    │  │
  │  └──────────────────────────────────────────────────────────────┘  │
  │                            │                                      │
  │  ┌──────────────── 认知管线层 (第1-7轮 + 第8轮增强) ──────────┐  │
  │  │                                                              │  │
  │  │   ┌────────┐   ┌────────┐   ┌──────────┐   ┌──────────┐    │  │
  │  │   │intention│──▶│retrieval│──▶│reasoning │──▶│ response │    │  │
  │  │   │        │   │        │   │          │   │          │    │  │
  │  │   │ 7意图  │   │ 多域   │   │ 多子问题 │   │ 按域分段 │    │  │
  │  │   │ 语义定义│   │ 检索并集│   │ 统一推理 │   │ 结构化输出│    │  │
  │  │   │ ★新增★ │   │ ★新增★ │   │ ★新增★  │   │ ★新增★  │    │  │
  │  │   │        │   │        │   │          │   │          │    │  │
  │  │   │ 调用   │   │ ↑注入  │   │ ↑注入   │   │ ↑注入    │    │  │
  │  │   │activate│   │ evi-   │   │ prompt  │   │ output   │    │  │
  │  │   │Expert()│   │ dence  │   │ Template│   │ Sections │    │  │
  │  │   │ ★★★   │   │ Filter │   │         │   │          │    │  │
  │  │   └────────┘   └────────┘   └──────────┘   └──────────┘    │  │
  │  │        │                                         │           │  │
  │  │   ┌────┴────┐                              ┌────┴────┐      │  │
  │  │   │interaction│                             │ verdict │      │  │
  │  │   │PointDetect│                             │  Node   │      │  │
  │  │   │ (不变)    │                             │ (不变)  │      │  │
  │  │   └──────────┘                             └─────────┘      │  │
  │  └──────────────────────────────────────────────────────────────┘  │
│                            │                                      │
│  ┌────────────────────── 数据与审计层 ────────────────────────┐  │
│  │                                                              │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌───────────────┐     │  │
│  │  │ Stream Bus   │  │ AuditCallback│  │ ChainTracer   │     │  │
│  │  │ (SSE 推送)   │  │ (L2 审计)    │  │ (链路追踪)    │     │  │
│  │  │ ★不变★       │  │ ★不变★       │  │ ★不变★        │     │  │
│  │  └──────────────┘  └──────┬───────┘  └───────────────┘     │  │
│  │                           │                                  │  │
│  │                    ┌──────▼───────┐                          │  │
│  │                    │  AuditLog 表 │  ← 永久审计记录          │  │
│  │                    └──────────────┘                          │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌───────────────┐     │  │
│  │  │ AnalysisCtx  │  │ SemanticCache│  │ CacheTTLStats │     │  │
│  │  │ (turnHistory)│  │ (RAG 缓存)   │  │ (自适应 TTL)  │     │  │
│  │  │ ★不变★       │  │ ★不变★       │  │ ★不变★        │     │  │
│  │  └──────────────┘  └──────────────┘  └───────────────┘     │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                    │
└──────────────────────────────────────────────────────────────────┘

层间关系：
  CognitiveEventBus ←→ GlobalStateProvider   同步状态快照
  CognitiveEventBus ←→ PolicyUpdateLoop      订阅反馈事件，触发策略调整
  PolicyUpdateLoop  ←→ GlobalStateProvider   读取 policy 子域，写入更新
  认知管线层        ←→ CognitiveEventBus      每个节点边界 emit 事件
  策略控制层        ←→ 数据层                 回写 ChatThread.metadata
```

---

## 7. 决策流程图

### 7.1 完整请求生命周期决策流

```
                          POST /api/agent/chat/stream
                                     │
                                     ▼
                          ┌─────────────────────┐
                          │ 初始化                │
                          │ GlobalStateProvider   │
                          │ CognitiveEventBus     │
                          │ PolicyUpdateLoop      │  ★第8轮新增★
                          └──────────┬──────────┘
                                     │
                                     ▼
                          ┌─────────────────────┐
                          │ Load ChatThread      │
                          │ Load AnalysisContext  │
                          │ (含 turnHistory)      │
                          └──────────┬──────────┘
                                     │
                                     ▼
                          ┌─────────────────────┐
                          │ Start ChainTrace     │
                          │ Register StreamBus   │
                          │ emit thought:started │  ★第8轮新增★
                          └──────────┬──────────┘
                                     │
                                     ▼
  ┌─────────────────────────────────────────────────────────────┐
  │                  ★ Embedded Path Evolution ★                 │
  │                                                              │
  │  ┌──────────────┐                                            │
  │  │ intention    │  这是唯一的分叉点                            │
  │  │              │                                            │
  │  │ 输入: 用户问题                                            │
  │  │ 输出: {                                                   │
  │  │   intent: "analysis",                                    │
  │  │   thinkingLevel: "deep",                                 │
  │  │   subIntents?: [          ← 多域问题时非空                 │
  │  │     { domain: "crop_compare", subQuery: "..." },         │
  │  │     { domain: "pest_risk",   subQuery: "..." }           │
  │  │   ]                                                      │
  │  │ }                                                        │
  │  │                                                          │
  │  │ → emit intent:detected                                   │
  │  │ → emit subIntent:detected (if subIntents)                │
  │  │                                                          │
  │  │ subIntents 非空?                                          │
  │  │   → activateExpert(ctx, domain)  ★第8轮首次调用★         │
  │  │   → ANALYSIS_EXPERTS[domain]                             │
  │  │     { evidenceFilter, promptTemplate, outputSections }   │
  │  │                                                          │
  │  │ ↓ 三路注入下游节点                                        │
  │  │   retrieval   ← evidenceFilter (ChromaDB 精准过滤)        │
  │  │   reasoning   ← promptTemplate (LLM 专家视角注入)         │
  │  │   response    ← outputSections (前端面板决定)              │
  │  └──────┬───────────────────────┬───────────────────────────┘
  │         │                       │
  │    thinkingLevel=fast      thinkingLevel=deep
  │         │                       │
  │         ▼                       ▼
  │  ┌──────────┐          ┌──────────────┐
  │  │ response │          │ retrieval    │
  │  │ (快速回答)│          │              │
  │  └──────────┘          │ subIntents ? │
  │                        │  多域检索并集  │
  │                        │  : 单域检索   │
  │                        │              │
  │                        │ ↑ evidence   │
  │                        │   Filter     │  ← 专家精准过滤
  │                        │              │
  │                        │ → emit       │
  │                        │   evidence:  │
  │                        │   retrieved  │
  │                        └──────┬───────┘
  │                               │
  │                               ▼
  │                        ┌──────────────┐
  │                        │ reasoning    │
  │                        │              │
  │                        │ subIntents ? │
  │                        │  多子问题推理 │
  │                        │  : 单问题推理 │
  │                        │              │
  │                        │ ↑ prompt     │
  │                        │   Template   │  ← 专家视角注入
  │                        │              │
  │                        │ → emit       │
  │                        │   reasoning: │
  │                        │   path_gen   │
  │                        └──────┬───────┘
  │                               │
  │                               ▼
  │                        ┌──────────────────┐
  │                        │ interactionPoint │
  │                        │ Detection        │
  │                        │                  │
  │                        │ 有 ambiguity ?   │
  │                        │  产出交互点      │
  │                        │  : 继续          │
  │                        └────┬─────────────┘
  │                             │
  │                    ┌────────┴────────┐
  │                    │                 │
  │              有交互点            无交互点
  │                    │                 │
  │                    ▼                 │
  │            ┌──────────────┐          │
  │            │ response     │          │
  │            │ (呈现交互点)  │          │
  │            │ 等待用户决策  │          │
  │            └──────┬───────┘          │
  │                   │                  │
  │         ┌─────────▼─────────┐        │
  │         │ 用户做出选择       │        │
  │         │ → 下一轮带着选择   │        │
  │         │   重走管线         │        │
  │         │   subIntents 可能  │        │
  │         │   缩小到单个       │        │
  │         └───────────────────┘        │
  │                                      │
  │                                      ▼
  │                              ┌──────────────┐
  │                              │ verdict      │
  │                              │              │
  │                              │ 裁决:        │
  │                              │ conclusion   │
  │                              │ confidence   │
  │                              │ reasoning    │
  │                              │ _path        │
  │                              └──────┬───────┘
  │                                     │
  │                                     ▼
  │                              ┌──────────────┐
  │                              │ response     │
  │                              │              │
  │                              │ subIntents ? │
  │                              │  按域分段输出 │
  │                              │  : 常规输出  │
  │                              │              │
  │                              │ ↑ output     │
  │                              │   Sections   │  ← 专家面板决定
  │                              │              │
  │                              │ → emit       │
  │                              │   strategy:  │
  │                              │   resolved   │
  │                              │   action:    │
  │                              │   proposed   │
  │                              │   subIntent: │
  │                              │   resolved   │
  │                              └──────────────┘
  └──────────────────────────────────────────────────────────────┘
                                     │
                                     ▼
                          ┌─────────────────────┐
                          │ 流结束后决策收尾       │
                          │                     │
                          │ 1. Save ChatThread   │
                          │ 2. Append turnRecord │
                          │    (含 activeExpertIds│
                          │     专家跟踪记录)      │
                          │ 3. Write to cache    │
                          │ 4. Adapt TTL         │
                          │ 5. syncFromAgentState│  ★第8轮★
                          │ 6. syncFromAnalysis  │  ★第8轮★
                          │    Context           │
                          │ 7. emit system:done  │  ★第8轮★
                          └──────────┬──────────┘
                                     │
                                     ▼
                          ┌─────────────────────┐
                          │ PolicyUpdateLoop     │
                          │ .evaluate() (异步)    │  ★第8轮★
                          │                     │
                          │ 评估 4 个维度:       │
                          │  cacheTtl           │
                          │  promptHint         │
                          │  expertActivation   │
                          │  evidenceFilter     │
                          │                     │
                          │ 有更新?             │
                          │  → apply()          │
                          │  → emit policy:     │
                          │    updated          │
                          │  : 无更新 (normal)  │
                          └─────────────────────┘
```

### 7.2 策略反馈闭环

```
  ┌─────────────────────────────────────────────────────────────┐
  │                    Policy Feedback Loop                      │
  │                                                              │
  │   ┌──────────────┐                                           │
  │   │ 用户请求      │                                           │
  │   └──────┬───────┘                                           │
  │          │                                                   │
  │          ▼                                                   │
  │   ┌──────────────┐     ┌──────────────┐                     │
  │   │ 认知管线执行   │────▶│ Cognitive    │                     │
  │   │              │     │ EventBus     │                     │
  │   │ 产出:        │     │              │                     │
  │   │ - confidence │     │ feedback:    │                     │
  │   │ - evidenceC  │     │ observed     │                     │
  │   │ - turnResult │     │              │                     │
  │   └──────────────┘     └──────┬───────┘                     │
  │                               │                              │
  │                               ▼                              │
  │                        ┌──────────────┐                      │
  │                        │ PolicyUpdate  │                      │
  │                        │ Loop          │                      │
  │                        │               │                      │
  │                        │ 收集 N 轮信号  │                      │
  │                        │ 后触发 evaluate│                      │
  │                        │ ()             │                      │
  │                        └──────┬────────┘                      │
  │                               │                              │
  │                ┌──────────────┼──────────────┐               │
  │                ▼              ▼              ▼               │
  │          ┌──────────┐  ┌──────────┐  ┌──────────┐           │
  │          │cacheTtl   │  │promptHint│  │evidence  │           │
  │          │评估       │  │评估       │  │Filter    │           │
  │          │           │  │           │  │评估      │           │
  │          │ 3次过期   │  │ β<-3 连续 │  │ 证据覆盖 │           │
  │          │ 同结论 →  │  │ 5轮置信度 │  │ 不足 →   │           │
  │          │ TTL↑20%   │  │ 下滑 →    │  │ 放宽     │           │
  │          │           │  │ prompt追  │  │ topK     │           │
  │          │           │  │ 加提示    │  │          │           │
  │          └────┬─────┘  └────┬─────┘  └────┬─────┘           │
  │               └──────────────┼──────────────┘               │
  │                              │                              │
  │                              ▼                              │
  │                       ┌──────────────┐                      │
  │                       │ PolicyUpdate  │                      │
  │                       │ Record        │                      │
  │                       │               │                      │
  │                       │ decisionReason│  ← 人类可读          │
  │                       │ rollbackData  │  ← 可回滚            │
  │                       │               │                      │
  │                       │ apply()       │  → 写入 policy 子域  │
  │                       └──────┬────────┘                      │
  │                              │                              │
  │                              ▼                              │
  │              ┌───────────────────────────┐                   │
  │              │ 下一轮请求                   │                   │
  │              │ GlobalSystemState.policy    │                   │
  │              │ .promptHint 已更新          │                   │
  │              │ .cacheTtl 已调整            │                   │
  │              │ .expertActivation 已变更    │                   │
  │              └───────────────────────────┘                   │
  └─────────────────────────────────────────────────────────────┘
```

---

## 8. 行业级别评估

### 8.1 评估维度与对标

| 维度 | 业界标准 (2026) | farm-agent (第7轮) | farm-agent (第8轮后) | 评级变化 |
|------|:---:|:---:|:---:|:---:|
| **可观测性** | LangSmith tracing + 日志聚合 | L1 console+file + L2 AuditLog + ChainTracer | + GlobalStateProvider diff + CognitiveEventBus timeline | B → **A** |
| **审计追溯** | LLM call 级别 trace | traceId 全链路 + AuditCallback 覆盖 6 节点 | + 认知事件链 + PolicyUpdateRecord 可回滚 | A → **A+** |
| **状态管理** | 节点级 LangGraph State | Annotation.Root 12 字段（局部状态） | + GlobalSystemState 七域统一 + 域间 sync/diff | C → **A** |
| **策略自适应** | 硬编码 prompt / 手工调整 | 3 个独立反馈环（TTL / turnHistory / pathMetrics）各自运行 | + 统一 PolicyUpdateLoop 聚合成单一决策 | C → **B+** |
| **多域问题处理** | 依赖用户拆分问题 / 多轮追问 | 单意图一对一匹配，跨域问题被截断 | + subIntents 嵌入路径，单次请求覆盖多域 | D → **B** |
| **决策可解释性** | LLM 输出 confidence 字段 | Verdict.conclusion + confidence + reasoning_path | + policy decisionReason + StateDiff 归因 | B → **A-** |
| **架构扩展性** | 插件化 / 中间件模式 | 6 节点 LangGraph 管线（固定拓扑） | + 可选参数注入（不改变拓扑）| B → **B+** |
| **工程成熟度** | CI/CD + 测试覆盖 + 文档 | tsc 零错误 + 审计日志 + 架构文档 | + Review 强制关卡 + 认知事件可测试 | B+ → **A-** |

### 8.2 与行业主流方案的横向对比

| | LangChain/LangGraph 标准 Agent | Coze/Dify 低代码 Agent | farm-agent (第8轮后) |
|---|---|---|---|
| **决策管线** | 线性 StateGraph + tool calling | 可视化编排 + 内置节点库 | 线性 StateGraph + 嵌入式路径演化 |
| **多域处理** | 需手动 fork/join 子图 | 不支持单次请求多域覆盖 | subIntents 嵌入式多域覆盖（不改变拓扑） |
| **策略反馈** | 无内置（需自建 eval pipeline） | 无（配置驱动，无运行时自适应） | PolicyUpdateLoop 四个纯决策函数 + 可回滚 |
| **状态模型** | 节点局部状态，无全局快照 | 黑盒，开发者不可见 | GlobalSystemState 七域快照 + diff |
| **审计能力** | traceId + callback（需自建） | 平台日志（不可编程） | L1+L2 三层 + 认知事件链 + ADD-7 开发审计 |
| **演化方式** | 改代码 / 改 prompt / 改 graph | 改配置 / 改编排 | 嵌入式路径演化（不改拓扑，改节点内部行为） |
| **适合场景** | 通用 Agent 开发 | 快速搭建 / 非技术人员 | 农业领域深度决策 + 需要策略自演化的场景 |
| **核心优势** | 生态丰富、灵活 | 低门槛、快迭代 | 可审计、可追溯、策略自适应、架构约束完整 |
| **核心劣势** | 需大量自建基础设施 | 黑盒、不可深度定制 | 领域特化，非通用框架 |

### 8.3 行业定位评估

**farm-agent 第8轮后的行业定位**：农业垂直领域的 **Agent OS 级决策管线**，在以下维度达到或超越业界主流水平：

| 能力 | 等级 | 说明 |
|------|:---:|------|
| **单次请求多域覆盖** | ★★★★☆ | 业界 Agents 普遍不支持（需多轮拆分），本方案通过 subIntents 实现单次覆盖，但不做并行调用（上限明确） |
| **策略闭环演进** | ★★★★★ | 业界少有完整实现。Coze/Dify 无此能力，LangGraph 需自建。本方案 4 个纯决策函数 + apply/rollback 是可复用的参考实现 |
| **审计完整性** | ★★★★★ | ADD 范式的三层审计（L1 dev + L2 runtime + L3 debug）+ CognitiveEventBus 事件链 + ADD-7 开发审计，覆盖度超越绝大多数 Agent 项目 |
| **状态治理** | ★★★★☆ | GlobalSystemState 七域模型 + diff 归因，在 LangGraph 生态中属于首创，但不可变快照模式对高频更新场景有性能上限 |
| **架构约束** | ★★★★☆ | 嵌入式路径演化方法论 + Spec/Review 强制关卡 + 原子事务闭包，保证了"在约束中演化"，但这是双刃剑——约束也是上限 |

### 8.4 第8轮后的阶段定性

```
┌──────────────────────────────────────────────────────────────┐
│                    Farm-Agent 演化阶段                         │
│                                                              │
│  第1-3轮  ─────▶  第4-5轮  ─────▶  第6-7轮  ─────▶  第8轮   │
│  管线成型      专家注册      演化闭环      架构合流            │
│  +类型收敛     +管线消费     +TTL自动适应   +统一状态内核       │
│  +响应裁决     +报告服务     +语义缓存      +认知事件中枢       │
│                              +路径质量评    +策略统一闭环       │
│                              估             +嵌入式路径演化    │
│                                                              │
│  状态: L1     状态: L2      状态: L3       状态: **L4**       │
│  能回答       能用专家视角   能自我调整     能统一管理          │
│  能裁决       能多轮追踪     能记住反馈     能跨域回答          │
│                                             策略可回滚          │
└──────────────────────────────────────────────────────────────┘
```

**L4 定性**：Farm-Agent 在第8轮后不再是"一个能跑管线的 Agent"，而是具备 **OS 内核级的状态治理能力**——全局状态可见、认知事件可追溯、策略决策可回滚、路径演化可约束。这在 LangGraph 生态内属于前沿水平，在农业垂直领域属于**行业领先**。

| # | 严重程度 | 问题 |
|---|:---:|------|
| R1 | **高** | spec 当前 Phase 4 仍为 Competition（已被否定），需更新为 Embedded Path Evolution |
| R2 | 中 | intention 节点的 prompt 重构影响范围比预期大——不仅是加 subIntents，还需补 7 个意图的语义定义。spec 中未体现 |
| R3 | 低 | `competition-execution.ts` 文件已不存在（scope 变更），需从 tasks/checklist 中移除所有相关条目 |
| R4 | **高** | PolicyUpdateLoop 缺乏安全约束：纯函数可能级联放大导致参数失控，需补充幅度上限+冷却期+置信度门槛+自动回滚（Grok 发现） |
| R5 | 中 | CognitiveEventBus 跨模块认知一致性：handler 可能在子域未同步时读取 GlobalStateProvider 导致不完整状态（Grok 发现） |
| R6 | 中 | GlobalStateProvider syncFromAgentState 可能存在序列化开销被滥用，需禁止序列化操作（Grok 发现） |
| R7 | 中 | subIntents 拆解决策不跨轮传递：intentionNode 每轮独立判断，缺失结构化 previousSubIntents 字段（第二位 Agent 发现） |
| R8 | 低 | response 分域输出时跨域共享背景可能被裁剪，需要约束保留规则（第二位 Agent 发现） |

### R1-R3（已修正）

见下方 §7 修正决议。

### R4 [高] PolicyUpdateLoop 安全约束缺失（Grok）

**发现**：纯函数不保证输出安全——级联放大可能导致 promptHint 权重等参数恶性循环。如：置信度下降 → 调高 promptHint 权重 → LLM 输出过于保守 → 置信度再下降 → 恶性循环。

**修正**：spec §3.3.1 新增五条安全约束：变化幅度上限、冷却期（5轮间隔）、置信度硬门槛（≥70 才 apply）、自动回滚（apply 后 5 轮指标未改善则回滚）、决策理由四段式可读性。

### R5 [中] CognitiveEventBus 跨模块认知一致性（Grok）

**发现**：PolicyUpdateLoop 订阅 intent:detected 事件时读取 GlobalStateProvider.getSnapshot()，但 agent 子域可能尚未同步（syncFromAgentState 在节点结束后执行）。

**修正**：spec §2.2.1 新增 Handler 依赖声明契约：handler 注册时声明 dependsOn，event bus emit 前检查子域就绪状态。

### R6 [中] GlobalStateProvider 性能约束（Grok）

**发现**：6 节点管线每次节点结束调用 syncFromAgentState()，如使用 JSON 序列化/深拷贝会产生不必要开销。

**修正**：spec §1.2.1 新增性能约束：syncFromAgentState() 必须是字段投影映射，禁止序列化操作；diff() 惰性计算。

### R7 [中] subIntents 拆解决策不跨轮传递（第二位 Agent）

**发现**：intentionNode 每轮独立判断，看不到 Turn 1 的 `{ subIntents: [crop_compare, pest_risk] }` 结构化字段，"拆还是不拆"的决策没有历史锚点。这是跨轮风险和边界问题的共同根因。

**修正**：spec §4.2.1 新增 AnalysisTurnRecord.previousSubIntents 结构化字段（domain + subQuery + resolved），自然语言摘要 + 结构化字段双通道传递。

### R8 [低] response 分域输出背景裁剪（第二位 Agent）

**发现**：Turn 1 分域输出时，pest_risk 子段可能只带"虫害风险较低"，裁剪了"这块地 XX 区域、墒情 YY"的被多域共享背景。Turn 2 追问时 intentionNode 拿到残缺上下文。

**修正**：spec §4.3 response 约束：分域输出时每个子域 section 必须携带被多个域共享的背景数据，不得因分段而裁剪。

---

## 7. 修正决议

| 修正项 | 决议 | 状态 |
|--------|------|:---:|
| R1: spec Phase 4 重写 | 将 Requirement 4 从 Competition 改为 Embedded Path Evolution | ✅ 已完成 |
| R2: intention prompt 语义定义 | 在 spec 中补充意图范畴划分，在 tasks 中新增 intention prompt 重构子任务 | ✅ 已完成 |
| R3: tasks/checklist 同步 | Phase 4 全部条目重写 | ✅ 已完成 |
| R4: PolicyUpdateLoop 安全约束 | spec §3.3.1 新增五条硬约束（幅度上限、冷却期、置信度门槛、自动回滚、理由可读性） | ✅ 已完成 |
| R5: CognitiveEventBus 依赖契约 | spec §2.2.1 新增 Handler 依赖声明契约 | ✅ 已完成 |
| R6: GlobalStateProvider 性能约束 | spec §1.2.1 新增性能约束（禁止序列化、惰性 diff） | ✅ 已完成 |
| R7: previousSubIntents 结构化传递 | spec §4.2.1 新增 AnalysisTurnRecord.previousSubIntents 字段 | ✅ 已完成 |
| R8: response 跨域背景保留 | spec §4.3 新增 response 分域输出共享背景保留约束 | ✅ 已完成 |
| 架构文档同步 | 在 Step 0（文档先行）中更新决策管线架构说明书 §4.1 + §十 | ✅ 已完成（2026-06-04 审计日志确认） |

---

## 8. 影响评估

### 8.1 受影响文件

| 文件 | 操作 | 影响 |
|------|:---:|------|
| `src/agents/global-state.ts` | 新建 | 正向 |
| `src/agents/cognitive-event-bus.ts` | 新建 | 正向 |
| `src/agents/policy-update-loop.ts` | 新建 | 正向 |
| `src/agents/state.ts` | 修改 | `CurrentTask` 接口扩展（新增可选字段），向后兼容 |
| `src/agents/index.ts` | 修改 | `streamAgent`/`runAgent` 入参扩展（可选参数），向后兼容 |
| `src/agents/nodes/intention.ts` | 修改 | prompt 重构 + subIntents 产出 |
| `src/agents/nodes/retrieval.ts` | 修改 | subIntents 触发时多域检索 |
| `src/agents/nodes/reasoning.ts` | 修改 | subIntents 触发时多子问题 prompt |
| `src/agents/nodes/response.ts` | 修改 | subIntents 触发时分段输出 |
| `src/agents/prompts/intention.ts` | 修改 | 意图语义定义 + subIntents 输出格式 |
| `src/app/api/agent/chat/stream/route.ts` | 修改 | 初始化 GlobalStateProvider + EventBus + PolicyUpdateLoop |
| `src/services/analysis-context.ts` | 修改 | `AnalysisTurnRecord` 新增 `previousSubIntents?` 字段（类型扩展，向后兼容） |

### 8.2 不受影响的文件（兼容性保证）

- `src/agents/nodes/verdict.ts` — 零改动
- `src/agents/nodes/interaction-point-detection.ts` — 零改动
- `src/agents/stream-bus.ts` — 零改动
- `src/agents/response-strategy.ts` — 零改动
- `src/agents/edges/conditional.ts` — 零改动
- `src/services/path-metrics.ts` — 零改动
- `src/services/cache-ttl-stats.ts` — 零改动
- `src/services/semantic-cache.ts` — 零改动
- `src/lib/layer2-callback.ts` — 零改动
- `prisma/schema.prisma` — 零改动
- 前端所有组件 — 零改动

### 8.3 回滚风险

**低**。GlobalStateProvider/CognitiveEventBus/PolicyUpdateLoop 全部为可选参数。subIntents 为空时管线行为完全不变。如有问题，回滚到第 7 轮基线的唯一代价是删除 3 个新文件 + 撤销 9 个文件的 optional 字段变更。

### 8.4 第 9 轮自然入口：Expert Grounding RAG 适配

第 8 轮完成后，`activateExpert()` 在概念层声明了 Expert Grounding 的意图——激活的是一个"已锚定的 Grounding Domain"，不是运行时检索过滤条件。但底层 RAG 基础设施未做改造，当前使用 `evidenceFilter`（ChromaDB where 子句）在检索时模拟 Grounding 行为——管线正常运行不阻塞，精度和效率存在折损。

**当前方案的降级路径**：

```
activateExpert(pest_risk)
  → evidenceFilter: { cateId: { $in: ["plant_protection", "agri_tech"] } }
  → retrieval: 全局 ChromaDB 搜索 + where 过滤
  → 结果: 能搜到正确类别，但每次重新计算，无 Grounding 锚定保证
```

**第 9 轮改造目标**：

| 项目 | 当前 | 第 9 轮目标 |
|------|------|-----------|
| 知识域隔离 | ChromaDB where 子句（运行时过滤） | 每个 expert 独立 collection 或 partition |
| Grounding 确认 | 无 | `groundingDomainReady()` 回调确认索引完整性和同步时效 |
| 检索方式 | 全局搜索 + cateId 过滤 | 在 pre-anchored collection 内向量匹配 |
| 证据链溯源 | `evidenceChain[i].source = "chroma_doc_xxx"` | `evidenceChain[i].source = "expert:pest_risk/chroma_doc_xxx"` 含 Grounding 来源 |
| 知识就绪声明 | 无 | Expert Registry 申明 domain → collection 映射 |

**不阻塞原则**：第 9 轮改造期间，第 8 轮的 evidenceFilter 降级方案持续生效。collection 分片完成后逐 expert 迁移，新 expert 走新路径，未改造的 expert 走旧路径，允许渐进式过渡。

**关联 Plan**：见 `.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-Expert-Grounding-RAG适配-plan-v1.md`。
