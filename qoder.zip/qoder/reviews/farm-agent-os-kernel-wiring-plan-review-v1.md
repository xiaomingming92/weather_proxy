# Agent OS Kernel 管线接入 — Plan Review v1

## Review 元信息

- **Review 对象**: `.qoder/plans/farm-agent-os-kernel-wiring-plan-v1.md`
- **Review 时间**: 2026-06-11
- **Review 类型**: 方案评审（Plan Review / ADD-9）
- **前置阅读**:
  - Runtime Review: `.qoder/reviews/farm-agent-expert-grounding-rag-adaptation-review-runtime-v2.md`（识别 7 断裂点）
  - 上游 Spec: `.qoder/specs/farm-agent-global-state/`

---

## 1. 问题复现

### 1.1 为什么需要这次评审

Runtime Review v2 识别出 Agent OS Kernel（GlobalStateProvider / CognitiveEventBus / PolicyUpdateLoop）与管线节点之间存在 **7 个断裂点**（A-G），其中 P0 级 1 个、P1 级 4 个：

| 断裂点 | 严重度 | 核心现象 |
|--------|:--:|------|
| A: ToolNode ↔ OS Kernel | P0 | ToolNode 裸注册（`new ToolNode(agentTools)`），不 emit `action:proposed`，不更新 `execution` 域 |
| B: RAG ↔ OS Kernel | P1 | retrieval 不 emit `evidence:retrieved`，`agent.evidenceCount` 仅在流结束后更新 |
| C: Tool+RAG 合流 | P1 | reasoning 不消费 `state.messages` 中工具结果 |
| D: 概念文档 | P1 | Agent OS Kernel 无独立架构说明书 |
| E: BSP 约束 | 架构 | ToolNode 内部逐工具不可见（LangGraph BSP 模型固有约束，非可修复缺陷） |
| F: 多租户隔离 | P2 | per-request 碰巧隔离，无 `tenantId` 字段 |
| G: evidenceChain 跨轮残留 | P1 | 同 thread 跨轮次 evidenceChain 不清空，零命中时旧证据冒充新报告 |

Plan 需要回答的核心问题是：**9 个 Task 能否完整修复这 7 个断裂点？方案选型是否正确？实施顺序是否最优？**

### 1.2 评审方法

逐条验证 Plan 中每个 technical claim 与源代码的一致性。关键验证点：
- 方案选型是否与 LangGraph 框架约束匹配
- 文件变更清单是否覆盖所有断裂点
- 签名变更是否正确（类型安全 + 向后兼容）
- 实施顺序是否满足依赖关系
- 验收标准是否可操作

---

## 2. 逐项技术验证

### 2.1 方案选型：RunnableConfig 注入（Plan §2.1）

**Plan 声称**：方案 A（RunnableConfig 注入）是 LangGraph 标准 config 传递机制，优于方案 B（wrapNodeWithAudit 签名扩展）和方案 C（AgentState 携带）。

**代码验证**：

| 验证点 | 当前代码 | 结论 |
|--------|---------|:--:|
| `globalStateProvider`/`eventBus` 当前传递方式 | `route.ts` L242-254 作为 `input` 字段传入，`streamAgent` L180-181 提取后仅在 stream wrapper（L200-217）中使用 | Plan 正确：当前未注入 config.configurable |
| `agent.stream()` 的 config 参数 | `index.ts` L194 已使用 `{ ...(config as any), callbacks: [...] }` spread | Plan 正确：扩展 configurable 兼容 spread 模式 |
| LangGraph addNode 回调签名 | `index.ts` L26-42：`async (state: typeof AgentState.State) => { ... }` — **无 config 参数** | Plan 正确：需为每个 addNode 回调添加 `config?` 参数 |

**裁定**：✅ 方案 A 可行。`config.configurable` 是 LangGraph 的标准扩展点，与 `thread_id` 同通道。Plan 要求的签名变更（末尾追加可选 `config?` 参数）是 TS 兼容的最小改动。

**注意**：需要修改的 addNode 回调数量是 **6 个**（intention / retrieval / reasoning / interactionPointDetection / verdict / response），而非 Plan 声称的 5 个。Plan 遗漏了 `interactionPointDetection` 和 `verdict` 的 addNode 回调。

### 2.2 方案选型：ToolNode 包装策略（Plan §2.2）

**Plan 声称**：用自定义包装函数替代 `new ToolNode()`，通过 `toolNodeInst.invoke(state, config)` 调用原 ToolNode，在返回前叠加 OS 信号。

**代码验证**：

| 验证点 | 当前代码 | 结论 |
|--------|---------|:--:|
| ToolNode 注册方式 | `index.ts` L44：`.addNode("toolNode", new ToolNode(agentTools))` — 裸注册 | ✅ 正确 |
| `ToolNode.invoke()` 签名 | 继承 `Runnable.invoke(input, config?)` | ✅ 可行 |
| 包装函数返回值 | 需返回 `{ messages: ToolMessage[], ...OS信号 }` | ✅ LangGraph addNode 接受 `RunnableLike` |

**裁定**：✅ 包装函数方案优于继承。不依赖 ToolNode 内部实现，对 LangGraph 版本升级有更好兼容性。

### 2.3 AgentState fallbackFlags 字段（Plan §3.2 / §3.3 / §2.4）

**代码验证**：

| 验证点 | 当前代码 | 结论 |
|--------|---------|:--:|
| AgentState 是否有 `fallbackFlags` | `state.ts` L96-116 — **无此字段** | ✅ 需新增 |
| Annotation 类型 | `Annotation<...>()` 无自定义 reducer | ✅ 默认 replace reducer 对 flags 语义正确 |
| Plan §3.2 与 §3.3 矛盾 | §3.2 列 `state.ts` 为"修改"，§3.3 列在"不修改"但立即用注释更正 | ⚠️ 文档不一致，建议从 §3.3 移除 `state.ts` |

**裁定**：✅ 字段新增正确。建议修正 §3.3 中的文档不一致。

### 2.4 evidenceChain 轮次隔离（Plan Task 3）

**Plan 声称**：retrieval 节点返回 `{ evidenceChain: newResults }`，LangGraph 默认 Annotation reducer（replace 语义）自然完成轮次隔离，不需显式清空。

**代码验证**：

| 验证点 | 当前代码 | 结论 |
|--------|---------|:--:|
| evidenceChain Annotation | `state.ts` L101：`Annotation<Evidence[] \| null>()` — 无自定义 reducer，默认 replace | ✅ Plan 正确 |
| retrievalNode 证据追加方式 | `retrieval.ts` L69：`const evidenceChain = [...(state.evidenceChain \|\| [])]` — 复制后追加 | ✅ 新引用替换旧引用 |
| skip-retrieval 路径风险 | fast-response 路径跳过 retrieval → evidenceChain 不更新 → 上一轮证据残留 | ⚠️ Plan 未覆盖此边缘情况 |

**裁定**：✅ 正常路径正确。⚠️ **风险**：fast-response 路径（intention → response）跳过 retrieval，此时 `fallbackFlags` 无法通过 retrieval 出口写入。但 fallbackFlags 是在 reasoning 入口由 wrapNodeWithAudit 写入的（根据 `getSnapshot().agent.evidenceCount === 0`），如果 reasoning 也被跳过则不写入——这与"无检索→无推理"的语义一致，不是缺陷。

### 2.5 reasoning 合流（Plan Task 4）

**Plan 声称**：reasoning.ts 当前全文件零处 `state.messages` 引用，需新增完整输入源。

**代码验证**：

| 验证点 | 当前代码 | 结论 |
|--------|---------|:--:|
| `state.messages` 引用 | `reasoning.ts` 全文 grep：**零处引用** | ✅ Plan 正确 |
| reasoning 当前输入源 | `state.evidenceChain` (L94-103) + `state.analysisContext` (L131-133) | ✅ 仅两处 |
| ToolMessage 结构 | LangGraph ToolNode 产出 `ToolMessage[]`，包含 `name`(工具名) + `content`(结果) | ✅ 可提取 |

**裁定**：✅ 正确。新增工具结果输入源是必要的。

### 2.6 EVENT_CONSUMER_REGISTRY 补全（Plan Task 5）

**代码验证**：

| 验证点 | 当前代码 | 结论 |
|--------|---------|:--:|
| 当前注册表条目数 | `event-consumer-strategies.ts` L43-51：**1 个**（policy-update-loop-consumer） | ✅ Plan 正确 |
| ConsumerStrategy 类型 | `wait` / `pull` / `skip` / `fallback` 四种策略均已定义（L21-25） | ✅ 基础设施就绪 |

**裁定**：✅ 正确。新增 3 个消费者（retrieval-context / reasoning-context / tool-audit），总注册 4 个。

### 2.7 PolicyUpdateLoop 工具感知（Plan Task 6）

**代码验证**：

| 验证点 | 当前代码 | 结论 |
|--------|---------|:--:|
| evaluate() 签名 | `policy-update-loop.ts` L301-304：`(ttlStats, turnHistory, pathMetrics)` | ✅ 无 toolExecutionStats |
| 四个决策函数的参数 | 均不包含工具调用统计 | ✅ Plan 正确 |

**裁定**：✅ 正确。新增 `toolExecutionStats` 参数。

### 2.8 多租户隔离（Plan Task 7）

**代码验证**：

| 验证点 | 当前代码 | 结论 |
|--------|---------|:--:|
| GlobalSystemState.meta 字段 | `global-state.ts` L62-66：`createdAt / updatedAt / version` — **无 tenantId** | ✅ Plan 正确 |
| CognitiveEventBus.getHistory() | `cognitive-event-bus.ts` L129-131：**无 filter 参数** | ✅ Plan 正确 |

**裁定**：✅ 正确。

### 2.9 wrapNodeWithAudit 签名变更范围

**Plan 声称**：需修改 8 处签名（5 处 addNode 回调 + 1 处 wrapNodeWithAudit + 2 处节点函数）。

**代码验证**：

| 实际需修改 | Plan 声称 | 差异 |
|-----------|---------|:--:|
| addNode 回调 | 5 处 | **实际 6 处**（遗漏 `interactionPointDetection`） |
| wrapNodeWithAudit | 1 处 | ✅ 正确 |
| 节点函数（retrieval/reasoning） | 2 处 | ✅ 正确 |
| **总计** | 8 处 | **实际 9 处** |

**裁定**：⚠️ 签名变更数量低估 1 处。`interactionPointDetection` 的 addNode 回调（L35-37）也需加 `config?` 参数，因为 LangGraph 框架要求所有 addNode 回调签名统一。

---

## 3. 实施顺序与依赖图验证

### 3.1 Plan 的依赖图

```
Task 1: ToolNode 包装器 (A)     Task 2: GlobalState 扩展
         │                                    │
         ├────────────────┬───────────────────┘
         ▼                ▼
Task 3: retrieval OS接入+证据隔离(B/G)   Task 4: reasoning 合流+降级(C/G)
         │                    │
         └────────┬───────────┘
                  ▼
Task 5: EVENT_CONSUMER_REGISTRY 补全
```

**验证结论**：

| 依赖关系 | Plan 断言 | 实际 |
|---------|:--:|:--:|
| Task 3 依赖 Task 1 | 是 | ✅ 正确：retrieval 需 ToolNode 包装器中的 config 传递链路就绪 |
| Task 3 依赖 Task 2 | 是 | ✅ 正确：retrieval 需 ExecutionStateSnapshot 扩展字段 |
| Task 4 依赖 Task 1 | 否 | ⚠️ **实际依赖**：reasoning 消费 ToolMessage 不直接依赖 Task 1 的包装器，但 config 传递链路是共享的 |
| Task 4 依赖 Task 2 | 是 | ✅ 正确：reasoning 需 getSnapshot().execution 含扩展字段 |
| Task 5 依赖 Task 3+4 | 是 | ✅ 正确：消费者注册需事件类型定义和使用模式均就绪 |

**裁定**：依赖图基本正确。Task 4 对 Task 1 的依赖关系建议标注为"弱依赖"（共享 config 传递链路，不依赖 ToolNode 包装器逻辑）。

### 3.2 验收标准一致性

| 标准 | 定义位置 | 完工任务 | 一致？ |
|------|---------|---------|:--:|
| V1-V3 | Task 1+2 | Task 1 完工时 | ✅ |
| V4 | Task 4 | Task 4 完工时 | ✅ |
| V5+V9 | Task 3 | Task 3 完工时 | ✅ |
| V6 | Task 6 | Task 6 完工时 | ✅ |
| V7 | Task 5 | Task 5 完工时 | ⚠️ Plan 说 `>=4`，但实际新增 3 个 = 总 4 个 |
| V8 | Task 9 | Task 9 完工时 | ✅ |
| V9 | Task 3（§2.4 新增） | Task 3 完工时 | ⚠️ Plan 验收标准 §五 只列到 V8，遗漏 V9 |

**裁定**：⚠️ Plan §五 验收标准遗漏 V9（evidenceChain 轮次隔离验证项），需补齐。

---

## 4. 风险评估

### 4.1 高风险

| 风险 | 来源 | 缓解 |
|------|------|------|
| **config 传递链路断裂** | 9 处签名变更需全部一致，遗漏任意一处导致运行时 `config is undefined` | Task 1 实施后立即 `npx tsc --noEmit` 验证，类型系统兜底 |
| **LangGraph BSP 封闭性** | ToolNode 包装器与 ToolNode 原生 invoke 之间的交互可能触发 LangGraph 内部状态校验 | 用 `toolNodeInst.invoke(state, config)` 而非直接操作 ToolNode 内部——这是 LangGraph 公开 API |

### 4.2 中风险

| 风险 | 来源 | 缓解 |
|------|------|------|
| **fallbackFlags 写入时机竞态** | wrapNodeWithAudit 在 reasoning 入口写入，但 reasoning 可能在 intention 路由后的下一个 super-step 立即执行 | LangGraph BSP 模型天然保证：retrieval super-step 完成后才执行 reasoning super-step |
| **EVENT_CONSUMER_REGISTRY 消费者未激活** | 注册表声明了消费者，但无代码触发 `resolveEventConsumerReadiness()` | Task 5 需同步实现消费者触发逻辑，不仅是声明注册表 |

### 4.3 低风险

| 风险 | 来源 | 缓解 |
|------|------|------|
| **fast-response 路径 evidenceChain 残留** | 跳过 retrieval 时 evidenceChain 不更新 | 语义上正确：fast-response 不需要检索证据。turnHistory 采集在 route.ts 流结束后执行，不依赖 evidenceChain |

---

## 5. 决策结论

### 5.1 方案可行性：✅ 通过

Plan 总体方案正确，9 个 Task 完整覆盖 7 个断裂点。方案选型（RunnableConfig 注入 + ToolNode 包装函数）是 LangGraph 框架下的最优解。

### 5.2 必须修正的问题（P0）

| # | 问题 | 位置 | 修正 |
|---|------|------|------|
| 1 | addNode 回调签名变更数量低估 | Plan §2.1 表格中"5 处"改为"6 处" | 实际需修改 9 处签名（6 addNode 回调 + 1 wrapNodeWithAudit + 2 节点函数） |
| 2 | 验收标准遗漏 V9 | Plan §五 | 补上 `Task 3: evidenceChain 轮次隔离: Turn2 检索零命中后 reasoning 不读到 Turn1 证据` |
| 3 | §3.3 中 state.ts 列在"不修改" | Plan §3.3 | 移除 `state.ts` 行（已在 §3.2 列为修改） |

### 5.3 建议优化（P1）

| # | 建议 | 理由 |
|---|------|------|
| 4 | Task 4 标注对 Task 1 的弱依赖 | reasoning 合流不直接依赖 ToolNode 包装器，但共享 config 传递链路 |
| 5 | Task 5 补充消费者触发逻辑说明 | 注册表声明 + 实际触发是两步，Plan 仅覆盖前者 |
| 6 | `route.ts` 中 `threadId` 注入 `config.configurable` | Task 7 提到但未在实施步骤中展开，建议在 Task 1 中统一处理 |

### 5.4 总体评级

| 维度 | 评分 | 说明 |
|------|:--:|------|
| 方案选型正确性 | ✅ | RunnableConfig 注入 + ToolNode 包装均是最优解 |
| 覆盖完整性 | ✅ | 9 Task 覆盖 7 断裂点，无遗漏 |
| 技术准确性 | ⚠️ | 签名数量 1 处低估，验收标准 1 项遗漏，文档 1 处不一致 |
| 实施顺序合理性 | ✅ | 依赖图正确，粒度适中 |

**结论：修正 3 个 P0 问题后可进入实施阶段。**

---

## 6. 影响评估

### 6.1 受影响文件

| 文件 | 操作 | 变更量 |
|------|------|:--:|
| `src/agents/index.ts` | MODIFY | ~40 行：ToolNode 包装器 + addNode 回调签名 + wrapNodeWithAudit 扩展 + config 传递 |
| `src/agents/global-state.ts` | MODIFY | ~10 行：ExecutionStateSnapshot 扩展 + meta.tenantId |
| `src/agents/state.ts` | MODIFY | ~5 行：新增 fallbackFlags 字段 |
| `src/agents/nodes/retrieval.ts` | MODIFY | ~15 行：config 取 OS 对象 + emit + updateDomain |
| `src/agents/nodes/reasoning.ts` | MODIFY | ~30 行：消费 state.messages 工具结果 + fallbackFlags 降级 |
| `src/caijuehub/strategies/event-consumer-strategies.ts` | MODIFY | ~20 行：3 个新消费者声明 |
| `src/agents/policy-update-loop.ts` | MODIFY | ~10 行：evaluate() 新增 toolExecutionStats |
| `src/agents/cognitive-event-bus.ts` | MODIFY | ~10 行：getHistory filter |
| `docs/.../Agent-OS-Kernel-架构说明书.md` | CREATE | ~200 行：全新文档 |

### 6.2 不修改的文件确认

- `intention.ts` / `verdict.ts` / `response.ts` — 行为不变 ✅
- `edges/conditional.ts` — 路由不变 ✅
- `prompts/*.ts` — Prompt 模板不变 ✅（reasoning prompt 新增段落由代码拼接，不修改模板文件）
- `stream-bus.ts` / `response-strategy.ts` — 不变 ✅

### 6.3 回滚风险

| 场景 | 回滚方式 | 难度 |
|------|---------|:--:|
| ToolNode 包装器异常 | 恢复 `new ToolNode(agentTools)` 一行 | 低 |
| config 传递链路问题 | 恢复所有签名到无 config 版本 | 中（需回退 9 处签名） |
| fallbackFlags 降级误触发 | 修改 reasoning 节点降级阈值 | 低 |

---

## 7. 关联文档

| 文档 | 路径 |
|------|------|
| 被评审 Plan | `.qoder/plans/farm-agent-os-kernel-wiring-plan-v1.md` |
| Runtime Review v2 | `.qoder/reviews/farm-agent-expert-grounding-rag-adaptation-review-runtime-v2.md` |
| 上游 Spec | `.qoder/specs/farm-agent-global-state/` |
