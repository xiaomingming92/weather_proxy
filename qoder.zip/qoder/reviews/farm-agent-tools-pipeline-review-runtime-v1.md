# farm-agent 工具管线 — 运行时审查 v1

> 关联 Plan: `.qoder/plans/farm-agent-tools-pipeline-plan-v1.md`
> 审查时间: 2026-06-15
> 审查范围: `src/agents/tools/impl/*.ts`（8 个工具文件）的审计日志实现

---

## 一、发现列表

### F1 [P0] 工具日志未接入 ADD 标准审计体系，L1/L2 双写缺失

**症状**: `farm-data-tools.ts` 和 `weather-tools.ts` 使用自造 `console.log` 函数（`farmDataAudit` / `weatherToolAudit`），其余 6 个工具文件零日志。

**根因**: Plan §3.5 与 ADD-7 审计策略表承诺为每个工具创建独立的 L1（dev-logger）/ L2（audit）文件（如 `weather-dev-logger.ts` / `weather-audit.ts`），但实施时简化为工具文件内的 ad-hoc `console.log` wrapper，从未接入 `agentAudit()` + `writeAuditLog()`。

**与 ADD 规范的差距**:

| 维度 | ADD 标准 | 当前实现 |
|------|---------|---------|
| L1 运行时可见 | `agentAudit(phase, detail, extra)` — phase 使用 `AgentAuditPhase` 枚举 | `farmDataAudit("SOIL_MOISTURE_PAGE", ...)` — 自造字符串 |
| L2 结构化落库 | `writeAuditLog(action, targetType, targetId, extra, reason)` — Prisma AuditLog 表 | ❌ 无 |
| Phase 语义 | `OS_KERNEL_TOOL_EMIT` / `OS_KERNEL_TOOL_STATE`（预定义业务阶段） | `SOIL_MOISTURE_PAGE` / `FARM_ERROR`（技术 HTTP 阶段） |

**影响**: 所有工具调用不可被 `query_audit_logs` MCP 跨会话追溯，运行时审查无法回溯工具执行历史。

**归类**: 实施裁剪过度 — Plan 声明的 L1/L2 分层架构在落地时被降级为 console.log。

### F2 [P1] 业务日志与技术日志混在同一函数，无分层

**症状**: 同一 `farmDataAudit()` 函数既打印业务事件（"用户查询了地块#3的土壤数据"）又打印技术事件（"Farm-Server HTTP 500"），无区分。

**根因**: 自造 `farmDataAudit(phase, detail)` 将 phase 作为自由字符串传递，没有语义约束。调用方无法区分：
- **业务层**: "工具 `query_soil_moisture` 被调用，参数 massifId=3" — 需要 L1+L2 双写
- **技术层**: "Farm-Server HTTP 请求耗时 230ms" — 仅需 L1 console

**ADD 标准做法**:

```
业务层: agentAudit("OS_KERNEL_TOOL_EMIT", ...) + writeAuditLog("TOOL_INVOKED", ...)
技术层: agentAudit("OS_KERNEL_TOOL_STATE", ...)  // 仅 L1，不落库
```

**归类**: 架构分层缺失 — 工具层未遵循 OS Kernel 的事件分层约定。

### F3 [P1] 6 个工具文件零日志覆盖

| 文件 | 日志状态 |
|------|---------|
| `project-tools.ts` | ❌ 无 |
| `task-tools.ts` | ❌ 无 |
| `time-tools.ts` | ❌ 无 |
| `user-tools.ts` | ❌ 无 |
| `search-documents.ts` | ❌ 无 |
| `index-documents.ts` | ❌ 无 |

**影响**: 这些工具的调用完全不可见，无法区分"未调用"与"调用失败"。

### F4 [P2] Plan ADD-7 审计策略表承诺未兑现

Plan §ADD-7 审计策略表列出以下待实施项，实际均未创建：

| Plan 承诺 | 状态 |
|----------|------|
| `src/lib/weather-dev-logger.ts`（L1） | ❌ 未创建 |
| `src/lib/weather-audit.ts`（L2） | ❌ 未创建 |
| `src/lib/time-tool-dev-logger.ts`（L1） | ❌ 未创建 |
| `src/lib/time-tool-audit.ts`（L2） | ❌ 未创建 |
| `src/lib/farm-server-client-dev-logger.ts`（L1） | ❌ 未创建 |
| `src/lib/farm-server-client-audit.ts`（L2） | ❌ 未创建 |

### F5 [P0] Response Fallback 场景不包含工具执行信息，LLM 输出原始 API 字段

**症状**: 用户请求"分析一周农场数据趋势"，工具正常调用但全部返回空数据。最终回复出现 `"根据您提供的数据（code: 200, msg: \"\"）"` 这种原始 API 片段，用户完全无法理解。

**复现**: traceId=`b926d049-50f5-488f-bef4-1bd4434ca0e2`, 2026-06-15T03:01:53Z

**根因**: `src/agents/nodes/response.ts` 中 `buildStreamingTextPrompt` 在构建 LLM prompt 时完全不包含工具执行信息。Fallback 场景下 LLM 只收到 `用户问题 + 意图类型: unknown`，对已执行的 3 个工具调用一无所知，只能编造原始 JSON 片段。

对比 `reasoning.ts` 已有 `toolResultsBlock` 注入逻辑，但该逻辑仅在 reasoning 执行时生效，fallback 跳过 reasoning 后工具上下文全部丢失。

**影响**: 用户收到的回复是技术腐数据（`code`/`msg`/`total`/`list`），而非人话如 "已查询气象/墒情/虫情数据，地块38近一周暂无记录"。

**归类**: 响应管道信息断层 — 工具结果未流入 response 节点的 prompt 构建。

### F6 [P1] 报告生成无 per-expert 模板，所有专家共用同一骨架，且缺失 LLM 对话回复

**症状**: `buildReportMarkdown` 对所有专家（weekly_report、pest_risk、growth_report 等 12 个）输出相同结构：裁决结论 → 激活专家列表 → 推理路径 → 证据链 → 交互点 → 运行时输入。周报和虫害报告长得一模一样。

此外 `displayContent`（用户在聊天框看到的 LLM 回复正文）完全没有写入报告。报告只有 verdict 的结构化结论、reasoning 步骤引用、evidence 片段，缺少最重要的"人话正文"。

**根因**:
1. `report-generator.ts:43-129 buildReportMarkdown` 是单一硬编码模板，不感知 `analysisContext.activeExperts`
2. 专家 registry 有 `reportFormats` / `defaultReportFormat` 字段，但只用于格式选择（md/pdf），不参与内容结构
3. `StructuredAgentResponse.displayContent.summary` 从未被 `buildReportMarkdown` 引用

**影响**: 导出的报告是"骨架 dump"而非"可交付文档"。用户需要在报告外独立阅读聊天记录才能获取完整决策建议。

**归类**: 报告管线结构缺失 — registry 缺少 `reportTemplate` 字段，generator 缺少模板分发逻辑。

---

## 二、修复方案

### 修复策略：集中式而非 per-tool 文件

Plan 原设计为每个工具类创建独立 L1/L2 文件（8 个工具 → 16 个文件），但从实际代码结构看，`agentAudit()` 和 `writeAuditLog()` 已在 `src/lib/agent-audit-logger.ts` 统一提供，工具文件直接 import 调用即可，无需 per-tool wrapper。

**修正方向**: 放弃 per-tool L1/L2 文件，改为工具层直接使用 `agentAudit()` + `writeAuditLog()`。

### 业务层模板（每个工具入口/出口）

```typescript
// 入口 — L1+L2
agentAudit("OS_KERNEL_TOOL_EMIT", "query_soil_moisture 被调用", {
  massifId: params.massifId,
  dataTime: params.dataTime,
})
writeAuditLog("TOOL_INVOKED", "FARM_DATA_TOOL", "query_soil_moisture",
  { massifId: params.massifId, dataTime: params.dataTime },
  "土壤墒情数据查询"
)

// 出口 — L1+L2
agentAudit("OS_KERNEL_TOOL_EMIT", "query_soil_moisture 完成", {
  success: true,
  resultType: typeof data,
})
writeAuditLog("TOOL_COMPLETED", "FARM_DATA_TOOL", "query_soil_moisture",
  { success: true },
  "工具执行完成"
)
```

### 技术层模板（HTTP 调用 / 错误）

```typescript
// 仅 L1，不落库
agentAudit("OS_KERNEL_TOOL_STATE", "Farm-Server POST /moisture-data/page", {
  statusCode: 200,
  durationMs,
})
```

### 修复范围

| 文件 | F1(L1+L2) | F2(分层) | F3(补充) |
|------|:---:|:---:|:---:|
| `farm-data-tools.ts` | 替换 farmDataAudit → agentAudit+writeAuditLog | 拆分业务/技术 | — |
| `weather-tools.ts` | 替换 weatherToolAudit → agentAudit+writeAuditLog | 拆分业务/技术 | — |
| `project-tools.ts` | 新增 agentAudit+writeAuditLog | — | ✅ |
| `task-tools.ts` | 新增 agentAudit+writeAuditLog | — | ✅ |
| `time-tools.ts` | 新增 agentAudit+writeAuditLog | — | ✅ |
| `user-tools.ts` | 新增 agentAudit+writeAuditLog | — | ✅ |
| `search-documents.ts` | 新增 agentAudit+writeAuditLog | — | ✅ |
| `index-documents.ts` | 新增 agentAudit+writeAuditLog | — | ✅ |

---

## 三、编译状态

待实施后验证。

---

## 四、回流确认

- [x] F1-F6 已记录
- [ ] 需回流至 Plan: 修正 ADD-7 审计策略表（放弃 per-tool L1/L2 文件，改为集中式）
- [ ] 需回流至 Plan: 验收标准 §五 更新 ADD-4/ADD-5 检查项
- [ ] 需回流至 Plan: F5 response 节点工具摘要注入（`response.ts` buildStreamingTextPrompt）
- [ ] 需回流至 Plan: F6 per-expert 报告模板体系（`report-generator.ts` + `registry.ts` reportTemplate）

---

## 五、F5 修复记录（2026-06-15）

**根因**: `buildToolExecutionSummary` 提取参数时只检查 `aim.tool_calls`，LangChain 序列化后 `tool_calls` 落在 `additional_kwargs` 中，导致 `massifId` / `dataTime` 提取为空，LLM prompt 始终收不到真实地块和日期，输出"地块编号和日期未明确提供"。

**参照**: `src/agents/index.ts` 的 `toolNode` 已使用 `m.tool_calls || m.additional_kwargs?.tool_calls` 兜底模式，`response.ts` 未同步。

**修复**: `response.ts:237` 改为 `aim.tool_calls || aim.additional_kwargs?.tool_calls`；`response.ts:120` 类型 cast 补上 `additional_kwargs`

---

## 六、后记：F5 与 Runtime Review v2 F7 的关系（2026-06-23 补充）

F5 修复了 `buildToolExecutionSummary` 的**参数提取路径**（`tool_calls` / `additional_kwargs`），但未涉及**数据记录提取路径**（`parsed.data.data.list`）。F5 修复后 LLM prompt 能收到正确的 `massifId` / `dataTime`，但 `recordCount` 仍为 0——因为 `list` 提取路径 `parsed.data.data.list` 与 ToolNode 序列化的平铺格式 `{ success, total, list }` 不匹配。

F5 和 F7 共同指向同一个设计缺陷：`buildToolExecutionSummary` 试图从序列化后的非结构化 JSON 中反向推导结构化信息，而所有反向推导假设均未被 Plan 文档明确定义。F7 的修复方案（State 新增 `toolResults` 结构化字段）从根本上消除了这个问题，F5 的 `tool_calls` 参数提取绕路问题也随之自然解决。
