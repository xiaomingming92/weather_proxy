# farm-agent-seed-catalog-review-v1

## Review 元信息

- **Review 对象**: `.qoder/plans/farm-agent-seed-catalog-plan-v1.md` + Specs 三元组
- **对比方案**: 无对照方案（全新功能）
- **Review 时间**: 2026-06-16
- **Review 类型**: 方案选型 + 架构设计
- **前置阅读**: Plan + Spec + Tasks + add-route

---

## 1. 总体结论

方向正确，架构设计合理。方案选型（本地持久化 + 搜索 API 辅助采集）兼顾了数据可靠性和维护效率。Plan 覆盖了后端 API、Agent 工具、前端管理三个维度，边界清晰。原子闭包拆分为 2 轮合理——第1轮交付 Agent 侧价值，第2轮交付管理侧价值，每轮可独立验证。

存在 2 个 P1 问题需修正、2 个 P2 建议，修正后可进入实施。

---

## 2. 正向评价

1. **数据模型设计好**：价格独立成表保留历史，渠道枚举覆盖了主要采购场景，价格按 effectiveDate 取最新的设计避免了覆盖丢失
2. **边界清晰**：明确本次不实现搜索采集、不实现批量导入，避免了范围膨胀
3. **原子闭包合理**：2 轮拆分同时满足"产品需求可感知"和"LLM 注意力集中"两层约束
4. **模块分布正确**：farm-agent 负责数据和工具，agrisynapse 负责管理 UI，符合现有分层惯例
5. **复用现有模式**：API CRUD 模式对齐了已有的 massif/equipment 等模块，前端模式一致

---

## 3. 问题清单

| 编号 | 严重程度 | 问题描述 | 修正建议 |
|------|---------|---------|---------|
| P1-1 | P1 | Spec 缺少 SeedCatalog 与 SeedPrice 的查询关联契约——前端如何展示"品种 + 多个渠道价格"的嵌套结构？Agent 工具返回结构是否与前端一致？ | Spec §Requirements "Agent 种子查询工具" 补充返回格式：`{ varieties: [{ ..., prices: [{ channel, price, ... }] }] }`，prices 按 channel 去重取最新 effectiveDate |
| P1-2 | P1 | Plan §3.2 缺少 API 路由的具体路径约定——Next.js App Router 中 `/api/seed-catalog/page`、`/api/seed-catalog/create` 需要几个 route handler 文件？ | Plan §3.2 补充路由目录树：`route.ts`(GET/POST)、`[id]/route.ts`(GET/PUT/DELETE)、`price/route.ts`(POST) |
| P2-1 | P2 | Tasks Task 4.2 描述较粗，未说明"新增价格"的交互流程 | 实现时弹性决定 |
| P2-2 | P2 | 搜索 API 预留接口未在 Plan §5 验收标准中显式标记 | Plan §5 新增验收项：预留搜索采集 API 端点已定义 |

---

## 4. 影响评估

| 问题 | 影响维度 | 影响说明 |
|------|---------|---------|
| P1-1 | 前后端契约 | 前端实现时可能自己猜测返回格式，导致与 Agent 工具不一致 |
| P1-2 | 路由冲突 | 如果路由结构不对，后期重构成本高 |
| P2-1 | 前端实现弹性 | 影响小，实现时可自行决定交互细节 |
| P2-2 | 范围遗漏 | 影响小，下一轮迭代再做不影响本轮交付 |

---

## 5. 建议修正优先级

- **高优先级**：P1-1（Spec 补充返回格式）、P1-2（Plan 明确路由结构）
- **中优先级**：P2-1（丰富 Task 描述）、P2-2（补充验收项）
- **低优先级**：无

---

## 6. 最终建议

修正 2 个 P1 问题后即可进入 Step 1 实施。建议执行顺序：
1. 先修正 Plan §3.2（补充路由结构）
2. 再修正 Spec §Requirements（补充返回格式契约）
3. 可同步处理 P2 建议
4. 修正完成后 Run DPS，确认 ≥ 85
5. 进入 Step 1 开始第1轮实施
