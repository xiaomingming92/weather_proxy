# farm-agent-ruifengyun-h5-api-v2-runtime-review-v1

> 运行时验证纠偏文档。触发方式：用户报告（成本核算结果过亿元）+ 代码审查。

## Review 元信息

- **关联 Plan**: [farm-agent-ruifengyun-h5-api-plan-v2.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/23/farm-agent-ruifengyun-h5-api-plan-v2.md)
- **关联 Plan v1**: [farm-agent-ruifengyun-h5-api-plan-v1.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/18/farm-agent-ruifengyun-h5-api-plan-v1.md)
- **关联实现 review**: 无（Plan 实施后未经实现 review）
- **Review 时间**: 2026-06-25
- **触发方式**: 用户报告 ssh rfai 上 cost-accounting 请求在 18:19 左右返回结果过亿元

---

## 问题优先级总览（P0/P1/P2 回流校验）

| # | 严重度 | 标题 | Plan 回流位置 | 状态 |
|---|:---:|------|-------------|:---:|
| 1 | P0 | 全链路缺少单位标准化契约——面积/重量/金额无统一规范 | §三 架构设计 + §3.4.6 | ⬜ 待回流 |
| 2 | P0 | LLM 全权做算术，无服务端数值校验 | §三 架构设计 + §五 验收标准 | ⬜ 待回流 |
| 3 | P0 | Zod Schema 只校验类型不校验精度——浮点精度泄露 | §3.4.6 DTO 与 Zod 校验层 | ⬜ 待回流 |
| 4 | P1 | 品种推荐 prompt 示例值锚定偏差蔓延至成本核算 | §三 架构设计（variety-recommend） | ⬜ 待回流 |
| 5 | P1 | prompt 参考区间仅作建议无强制约束 | §三 架构设计（cost-accounting） | ⬜ 待回流 |
| 6 | P2 | 字段命名 header 注释与实际代码不一致 | §3.1 代码注释 | ⬜ 待回流 |

---

## 1. 发现列表

### F1 [P0] 全链路缺少单位标准化契约——面积/重量/金额无统一规范

**症状**：

生产计划 API 链（地块分析 → 品种推荐 → 成本核算 → 计划生成）涉及三类物理量，但代码、prompt、DB schema 中均无显式的单位标准化约束：

| 物理量 | 问题 | 示例 |
|--------|------|------|
| 面积 | 只有「亩」，暂无不一致 | `plantingArea`、`totalArea` 均用亩 |
| 重量 | **kg vs 斤 未强制** | `yieldPerMu` prompt 标注 kg/亩，但中国农业惯用 斤/亩；上游可能传入 斤 → 2x 偏差 |
| 金额 | **元 vs 分 未校验** | DB `grainPrice` 注释「元/kg」值为 1.6，但若误存为分（160）→ 100x 偏差 |
| 精度 | **无四舍五入规范** | LLM 输出浮点数如 `120000.333333`，前后端未做精度控制 |

**根因**：

整个生产计划 API 链缺少一份**单位标准化契约**文件。各单位在各层独立定义：

- DB 层：[grainPrice](file:///home/xmm/ai/farm-agent/prisma/main.prisma#L344) 注释 `// 粮价（元/kg）` — 仅靠注释，无 CHECK 约束
- prompt 层：[cost-accounting.ts](file:///home/xmm/ai/farm-agent/src/agents/prompts/experts/cost-accounting.ts#L31) 描述 `yieldPerMu（kg/亩）、pricePerKg（元/kg，粮价）` — LLM 可忽略
- 代码层：无 `toFixed(2)`、无 `Math.round`、无单位转换逻辑
- Schema 层：[schemas.ts](file:///home/xmm/ai/farm-agent/src/app/api/h5/types/schemas.ts#L76-L84) `z.number()` — 无 `z.number().multipleOf(0.01)`

**与过亿元问题的因果链**：

```
单位不固定 → 上游传入 pricePerKg=160（实际是「分/kg」但标注「元/kg」）
  → route.ts 不做单位校验直接喂 LLM
  → LLM 按「元/kg」计算：500亩 × 600kg × 160 = 48,000,000（4800万）
  → 叠加 LLM 算术误差（多打零）→ 过亿
```

**修复规范**：

已落地为单一真相源 [unit-contract.ts](file:///home/xmm/ai/farm-agent/src/agents/prompts/unit-contract.ts)，注册于 [caijue.toml](file:///home/xmm/ai/farm-agent/src/caijuehub/caijue.toml) `id="resolve-unit-contract" type="contract"`。全链路强制执行以下单位标准化契约：

```
┌─────────────────────────────────────────────────────┐
│         生产计划 API 单位标准化契约                   │
├──────────┬──────────┬───────────────────────────────┤
│ 物理量   │ 标准单位  │ 约束                          │
├──────────┼──────────┼───────────────────────────────┤
│ 面积     │ 中国亩(亩)│ 唯一单位，1 中国亩 ≈ 666.67 m²，API 响应中简称「亩」    │
│ 重量     │ kg       │ 上游传入需自行确认，非 kg 拒收  │
│ 金额     │ 元       │ 所有货币值四舍五入到小数点后2位  │
│ 单价     │ 元/kg    │ 种子单价、粮价统一此单位        │
│ 亩产     │ kg/亩    │ 入口处校验范围 200-2000 kg/亩  │
│ 亩均成本  │ 元/亩    │ 入口处校验范围 50-5000 元/亩   │
│ 精度     │ 2 位小数  │ 金额类字段 toFixed(2)          │
└──────────┴──────────┴───────────────────────────────┘
```

**修复方向**：

1. 在 `types/dto.ts` 中为金额字段添加 JSDoc 单位注释：`/** 元，保留2位小数 */`
2. 在 `types/schemas.ts` 中为金额添加精度约束：`z.number().multipleOf(0.01)` 或至少 `z.number().finite()`
3. 在 cost-accounting route.ts 入口处添加重量/金额单位合理性校验（见 F2-F3）
4. 服务端计算的所有金额结果统一 `Math.round(value * 100) / 100`（toFixed(2) 等价）
5. LLM prompt 中将单位描述从「说明」升级为「硬约束」

---

### F2 [P0] LLM 全权做算术，无服务端数值校验——成本核算结果可任意放大

**症状**：

用户反馈 `/api/h5/production-plan/cost-accounting` 返回的 `expectedRevenue`/`totalCost`/`expectedProfit` 过亿元，远超合理范围。以水稻 500 亩、亩产 600kg、粮价 1.6 元/kg 计算，正常种植收入应为 \(500 \times 600 \times 1.6 = 480,000\) 元（48 万），非亿元级。

**根因**：

[route.ts](file:///home/xmm/ai/farm-agent/src/app/api/h5/production-plan/cost-accounting/route.ts#L86-L94) 将 `plantingArea`、`yieldPerMu`、`pricePerKg` 等原始数字直接作为 LLM 输入，LLM 在 JSON 输出中计算 `expectedRevenue = plantingArea × yieldPerMu × pricePerKg`。代码层只做 `JSON.parse` + `costAccountingSchema.safeParse`，无任何算术验证：

```typescript
// 第 86-94 行：发数字给 LLM，LLM 全权计算
const userInput = JSON.stringify({ cropType, varietyName, plantingArea, yieldPerMu, pricePerKg, seedCostPerMu }, null, 2)
const response = await h5Llm.invoke(messages)

// 第 100-108 行：只解析，不验证数值合理性
const parsed = JSON.parse(stripped)
const validated = costAccountingSchema.safeParse(parsed)
if (validated.success) {
  result = validated.data as CostAccountingData  // ← 亿元直接透传
}
```

[prompt](file:///home/xmm/ai/farm-agent/src/agents/prompts/experts/cost-accounting.ts#L19-L21) 中明确写了：
```
1. 种植收入 = plantingArea × yieldPerMu × pricePerKg
```

这个乘法**应由服务端计算**（`plantingArea × yieldPerMu × pricePerKg` = 确定值），而不是交给 LLM 在 JSON 中输出。

**后果链**：

```
前端传入 plantingArea/yieldPerMu/pricePerKg
  → LLM 做算术（不可靠）
  → 输出 JSON expectedRevenue（可能是正确值的 10-100 倍）
  → Zod 校验通过（z.number() 无上限）
  → 直接返回给前端
  → 生产计划生成使用虚高成本估算
```

**与 Plan v1 设计意图的矛盾**：

Plan v1 [§3.1 决策依据](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/18/farm-agent-ruifengyun-h5-api-plan-v1.md#L249) 明确说"成本核算=公式计算+成本明细生成"，但实际实现中连公式计算都交给了 LLM。

**修复方向**：

服务端计算确定性的乘法（`expectedRevenue`、种子成本 = `seedCostPerMu × plantingArea`），仅将**成本项推算**（肥料/农药/人工/机械单价）交给 LLM。修改 [route.ts](file:///home/xmm/ai/farm-agent/src/app/api/h5/production-plan/cost-accounting/route.ts)：

```typescript
// 服务端计算确定值（不依赖 LLM），金额四舍五入到 2 位小数
const expectedRevenue = Math.round(plantingArea * yieldPerMu * pricePerKg * 100) / 100
const revenueFormula = `${plantingArea}亩 × ${yieldPerMu}kg/亩 × ${pricePerKg}元/kg`

// 只把成本项推算交给 LLM
const userInput = JSON.stringify({
  cropType, varietyName, plantingArea, projectId,
  seedCostPerMu,
  expectedRevenue,  // 已确定，告诉 LLM 不需重算
})
```

同步修改 prompt，让 LLM 只输出 `costItems` 和推算依据，`expectedRevenue`/`totalCost`/`expectedProfit` 由服务端组装。

---

### F3 [P0] Zod Schema 只校验类型不校验精度——浮点精度泄露 + 无整数性约束

**症状**：

金额字段无精度控制，LLM 输出 `expectedRevenue: 120000.333333` 或 `roi: 1.73456789012345`，前端直接展示或入库时携带浮点噪声。

**根因**：

[schemas.ts](file:///home/xmm/ai/farm-agent/src/app/api/h5/types/schemas.ts#L76-L84) 的 `costAccountingSchema` 仅定义了类型约束，无精度与整数性约束：

```typescript
export const costAccountingSchema = z.object({
  expectedRevenue: z.number(),   // ← 可以是浮点数，无精度控制
  totalCost: z.number(),          // ← 同上
  expectedProfit: z.number(),     // ← 同上
  roi: z.number(),                // ← 可能输出 1.73456789012345
  roiRatio: z.string(),
  costItems: z.array(costItemSchema),
  revenueFormula: z.string(),
})
```

**设计原则**：

不对数值做业务上限校验（高价值作物如中药材亩收入可达数万元，硬上限会误杀合法场景）。正确策略是：
- **算法兜底**：服务端计算确定值，LLM 不碰算术（F2）
- **精度兜底**：金额统一 `Math.round(v * 100) / 100`，Zod 加 `multipleOf(0.01)`
- **单位兜底**：全链路遵守单位标准化契约（F1）

只要算法对、精度对、单位对，结果自然可信——无需假设"多大算大"。

**修复方向**：

```typescript
// 金额字段：整数（元），精度到 2 位小数（分）
const yuanAmount = z.number().finite().refine(
  v => Math.round(v * 100) === v * 100,
  { message: "金额最多2位小数" }
)
// 或简化为：z.number().multipleOf(0.01)

export const costAccountingSchema = z.object({
  expectedRevenue: yuanAmount,
  totalCost: yuanAmount,
  expectedProfit: yuanAmount,
  roi: z.number().finite(),
  roiRatio: z.string(),
  costItems: z.array(costItemSchema.extend({
    amount: yuanAmount,
  })),
  revenueFormula: z.string(),
})
```

同时 costItem 的 `amount` 也需精度约束——LLM 推算的单项成本同样可能带浮点噪声。

---

### F4 [P1] 品种推荐 prompt 示例值锚定偏差——可能经前端传递蔓延至成本核算

**症状**：品种推荐 LLM 可能输出虚高的 `revenuePerMu`/`costPerMu`，前端若从此反推 `pricePerKg` 传入成本核算，会造成连锁放大。

**根因**：

[variety-recommend.ts prompt](file:///home/xmm/ai/farm-agent/src/agents/prompts/experts/variety-recommend.ts#L61-L63) 的输出示例值：

```json
"costPerMu": 3500,
"revenuePerMu": 8400,
"profitPerMu": 4900,
```

但数据库 [grainPrice](file:///home/xmm/ai/farm-agent/prisma/main.prisma#L344) 仅为 `1.6 元/kg`。按 `yieldExpectation=750` 计算，实际亩均收入应为 \(750 \times 1.6 = 1200\) 元/亩。示例中的 8400 是实际值的 **7 倍**（隐含 grainPrice = 8400÷750 = 11.2 元/kg）。

LLM 易受 prompt 示例锚定效应影响，输出偏高的经济指标。若前端从 `revenuePerMu / yieldExpectation` 反推 `pricePerKg`，则传入成本核算的粮价会被放大。

**实际影响**：取决于前端小程序如何构造 cost-accounting 请求参数（无前端源码可确认）。若前端直接使用 DB grainPrice 而非 LLM 输出的 revenuePerMu 反推，则此问题不传导。

**修复方向**：
1. 修正 variety-recommend prompt 示例值，使其与 DB 实际 grainPrice 一致（`revenuePerMu: 1200`）
2. 成本核算 prompt 中移除对 LLM 做确定乘法的依赖（见 F1）

---

### F5 [P1] prompt 参考区间仅作建议无强制约束——LLM 可自由输出超出区间 10-100 倍成本

**症状**：成本项推算可能严重偏离农业实际。

**根因**：

[cost-accounting.ts prompt](file:///home/xmm/ai/farm-agent/src/agents/prompts/experts/cost-accounting.ts#L26) 写了参考区间：

```
参考区间：水稻肥料 150-200元/亩、农药 80-120元/亩、人工 200-300元/亩、机械 100-150元/亩
```

但这些只是"参考"，LLM 无强制约束必须在此范围内。LLM 可能输出 18000 元/亩的肥料或 30000 元/亩的人工。

**修复方向**：
1. 配合 F1 修复：将参考区间转为 prompt 中的**硬约束**："每项亩均成本必须在参考区间内，若无法确定取区间中值"
2. 配合 F2 修复：服务端添加每项亩均成本的合理性校验

---

### F6 [P2] 字段命名 header 注释与实际代码不一致

**症状**：[route.ts](file:///home/xmm/ai/farm-agent/src/app/api/h5/production-plan/cost-accounting/route.ts#L7) header 注释写 `grainPrice, seedPrice`，实际代码使用 `pricePerKg, seedCostPerMu`。

```typescript
// 第 7 行 header 注释:
// 输入: { plantingArea, cropType, varietyName, yieldPerMu, grainPrice, seedPrice, projectId, costCategories? }

// 第 39 行实际代码:
const { ..., pricePerKg, seedCostPerMu, ... } = body
```

这造成 API 文档（[对接文档](file:///home/xmm/ai/farm-agent/docs/大田精准耕播智能决策系统/knowledge/02-规范/瑞丰耘H5小程序API对接文档.md#L429-L430) 使用 `pricePerKg`/`seedCostPerMu`）与代码注释不一致，增加维护和理解成本。

**修复方向**：统一 header 注释与代码变量名。

---

## 2. 影响面评估

| 影响范围 | 严重度 | 说明 |
|---------|:---:|------|
| cost-accounting 端点 | P0 | 核心算术依赖 LLM，任何一次 LLM 幻觉都可能导致亿元级错误 |
| plan-generate 端点 | P0 | 使用 costEstimate（来自 cost-accounting），虚高数据直接入库 `ProductionPlan.coreMetrics` |
| H5 前端用户 | P0 | 看到的成本/收益/利润数据严重失真 |
| variety-recommend 端点 | P1 | prompt 示例值可能锚定 LLM 输出偏高的经济指标 |
| 品种推荐→成本核算数据链路 | P1 | 若前端从 LLM 输出反推 pricePerKg，存在连锁放大风险 |

---

## 3. 修复优先级建议

```
P0 立即修复:
  1. 制定并落地单位标准化契约（F1）——面积=中国亩、重量=kg、金额=元、精度=2位小数
  2. 服务端计算 expectedRevenue（F2 核心修复）+ Math.round(v*100)/100
  3. Zod schema 金额字段加精度约束 multipleOf(0.01)（F3）

P1 本次 Plan 回流:
  4. 修正 variety-recommend prompt 示例值（F4）
  5. prompt 参考区间改为硬约束（F5）

P2 随下次改动修复:
  6. header 注释统一字段命名（F6）
```

---

## 4. 验证方法

- [ ] 单位契约验证：所有金额字段输出为 `Math.round(v*100)/100`（2 位小数），无浮点精度泄露
- [ ] 用已知种植面积和单价构造 cost-accounting 请求，验证 `expectedRevenue = area × yield × price` 精确等于服务端计算值（不依赖 LLM 输出）
- [ ] 高价值作物场景不误杀：如 plantingArea=10, pricePerKg=200, yieldPerMu=500 → expectedRevenue=1,000,000 元（100万，高于水稻但正确）
- [ ] yieldPerMu 传入 斤/亩 值时入口校验告警（prompt 约定 kg/亩）
- [ ] variety-recommend 输出中 `revenuePerMu` 不显著偏离 `yieldExpectation × DB grainPrice`
- [ ] `tsc --noEmit` 编译通过
- [ ] 金额类 Zod schema 含 `multipleOf(0.01)` 或等价精度约束
- [ ] `costItem.amount` 同样受精度约束
