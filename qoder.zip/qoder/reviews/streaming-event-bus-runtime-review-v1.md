# Review: 流式事件总线 AuditLog 写入策略 — 运行时验证

> **修订记录**
> - 2026-06-25: 初版，生产环境 AuditLog 表 30K 行中 STREAM_BUS_EMIT_TOKEN 占 90.7% 触发诊断

## Review 元信息

- **Review 对象**: `streaming-event-bus-plan-v1` 实施产物的 AuditLog 写入策略
- **Review 时间**: 2026-06-25
- **Review 类型**: 运行时 review（代码落地后的生产环境观察）
- **触发条件**: 生产环境 AuditLog 表查询发现 STREAM_BUS_EMIT_TOKEN 每字符一条记录
- **前置阅读**:
  - Plan: `.qoder/plans/2026-05/18/streaming-event-bus-plan-v1.md`
  - 源码: `src/agents/stream-bus.ts`, `src/lib/stream-bus-logger.ts`

---

## 1. 生产环境数据快照

```text
rfai 生产库 AuditLog 表 (2026-06-24):

  27288 STREAM_BUS_EMIT_TOKEN     ← 90.7%
   1230 STREAM_BUS_EMIT_ERROR     ← 4.1%
    391 FS_CLIENT_SUCCESS
    196 STREAM_BUS_EMIT
    107 STREAM_BUS_EMIT_STRUCTURED
     93 GATEWAY_THREADS_LIST
     ...
  -----
  30077 TOTAL 行  |  表体积 7 MB

traceId IS NULL 的行:
  27288 STREAM_BUS_EMIT_TOKEN     ← F2: 全部缺失
   1230 STREAM_BUS_EMIT_ERROR
    391 FS_CLIENT_SUCCESS
    196 STREAM_BUS_EMIT           ← F2: 全部缺失
    107 STREAM_BUS_EMIT_STRUCTURED ← F2: 全部缺失
     93 GATEWAY_THREADS_LIST      ← F2: 全部缺失 (已单独修复)
     ...
```

---

## 2. 问题清单

### F1 [CRITICAL] STREAM_BUS_EMIT_TOKEN 逐字符落库，占表 90.7%

| 维度 | 内容 |
|:--|:--|
| **现象** | 每次 LLM 流式回复，每个字符（token）写入 1 条 AuditLog 行。500 字符回复 = 500 条 DB INSERT |
| **根因** | `streaming-event-bus-plan-v1` 审计策略定义为"三通道输出(console+file+DB)"（Plan §ADD-7 审计策略表 L12），未区分事件频率。`emitStreamEvent()` 对全部 12 种 StreamEvent 无条件调用 `streamBusAudit()` → `prisma.auditLog.create()` |
| **影响** | 27,288 行垃圾数据占表 90.7%；每次聊天产生数百次 DB 写入，随使用量线性增长；表膨胀加速，查询变慢 |
| **代码定位** | `src/agents/stream-bus.ts` L136: `streamBusAudit(phase, detail, buildAuditExtra(event))` 对 token 类型无过滤；`src/lib/stream-bus-logger.ts` L56-69: 每调用必写 DB |

#### 崩溃链路

```
LLM.stream() → 逐 token emitStreamEvent("token", {content})
  → streamBusAudit("STREAM_BUS_EMIT_TOKEN", ...)
    → prisma.auditLog.create({ action: "STREAM_BUS_EMIT_TOKEN", ... })
      × N 次（N = 回复字符数）
```

### F2 [HIGH] 全部 STREAM_BUS_* 记录缺失 traceId

| 维度 | 内容 |
|:--|:--|
| **现象** | 生产库中所有 action 以 `STREAM_BUS_` 开头的 AuditLog 行，`traceId` 字段均为 NULL。无法按请求串联审计链路 |
| **根因** | `streamBusAudit()` 直接调用 `prisma.auditLog.create()`，未经过 `agentAudit()` → `setAuditContext()` 路径，从未设置 traceId。`agent-audit-logger.ts` 的 `setAuditContext(userId, traceId)` 机制只对 `agentAudit()` 调用栈生效 |
| **影响** | 无法从 AuditLog 追溯"某次聊天产生了哪些流式事件"；问题排查时 token/evidence/error 事件无法关联到具体请求 |
| **代码定位** | `src/lib/stream-bus-logger.ts` L56-69: `prisma.auditLog.create({ data: { userId, action, ... } })` — 缺少 `traceId` 字段 |

#### 对比：正常审计链路

```
agentAudit("H5_PLAN_GENERATE", ...)
  → setAuditContext(userId, traceId) 已预先调用
  → auditLog.create({ ..., traceId }) ✅ 自动填充

streamBusAudit("STREAM_BUS_EMIT_TOKEN", ...)
  → 直接 auditLog.create({ ... })     ❌ traceId 从未设置
```

---

## 3. Plan 设计回顾

Plan `streaming-event-bus-plan-v1.md` 的审计策略（L12）：

| 文件 | afterState | 缺陷 |
|:--|:--|:--|
| `stream-bus-logger.ts` | "三通道输出(console+file+DB)，10个AuditPhase" | ❌ 未区分事件频率，10 个 Phase 中 `TOKEN` 和 `EVIDENCE` 是循环内高频事件 |
| `stream-bus.ts` | "模块级事件注册表，9种StreamEvent" | ❌ `emitStreamEvent()` 对全部事件统一调用 `streamBusAudit()`，无频率感知 |

Plan 自身在 L81-82 已认知 `STREAM_BUS_EMIT_TOKEN (×N)` 会产生 N 条记录，但未评估存储代价。

---

## 4. 修复方案

### 4.1 F1 修复：内存累积 + response_end 单次落库

**策略**：token 事件在内存中累积，`response_end` 时 flush 为 **1 条** DB 记录（原文完整输出）。

| 事件 | 落库策略 | 文件日志 |
|:--|:--|:--|
| `token` | ❌ 不写 DB，仅内存累积 | ✅ 照写（调试用） |
| `response_end` | ✅ flush buffer → 写 1 条 DB（含 tokenCount + durationMs + 完整原文） | ✅ 照写 |
| 其他事件（RAG/工具/错误） | ✅ 照常写 DB | ✅ 照写 |

**效果预估**：一次聊天从 N 条 DB 行 → 1 条，表增长速度降低 2 个数量级。

**涉及文件**：
- `src/agents/stream-bus.ts`：加 `tokenBuffer` Map + `response_end` flush 逻辑
- `src/lib/stream-bus-logger.ts`：加 `streamBusAuditBatch()` 批量落库函数 + `STREAM_BUS_EMIT_TOKEN_BATCH` Phase

### 4.2 F2 修复：stream-bus-logger 注入 traceId

**策略**：`streamBusAudit()` 自动生成 `sb_{uuid}` 前缀 traceId，与 `agent-gateway-audit.ts` 修复模式一致。

**涉及文件**：
- `src/lib/stream-bus-logger.ts`：`auditLog.create()` 数据中加 `traceId: \`sb_${randomUUID()}\``

### 4.3 增强项（非必须）

- 定期归档：crontab 每半年 `DELETE FROM "AuditLog" WHERE "createdAt" < NOW() - INTERVAL '6 months'` 或导出到冷存储

---

## 5. 教训

### 5.1 "三通道输出"设计需区分事件频率

Plan 审计策略写"三通道输出(console+file+DB)"时，隐含假设所有事件频率相当。实际 `TOKEN` 事件频率是 `RAG_RESULT` 的 1000 倍以上。

**修正**：审计策略必须标注每类事件的设计频率（次/请求），高频事件需特殊处理。

### 5.2 独立审计模块不能绕过统一审计上下文

`stream-bus-logger.ts` 和 `agent-gateway-audit.ts` 都绕过了 `agent-audit-logger.ts` 的 `setAuditContext()` → `agentAudit()` 机制，导致 traceId 缺失。

**修正**：所有审计入口必须在落库前设置 traceId（要么调用 `setAuditContext`，要么自行生成并注入）。

### 5.3 Plan 中标注 `(×N)` 的地方应有存储评估

Plan L81 写了 `STREAM_BUS_EMIT_TOKEN (×N)` 但未评估 N 的量级和存储影响。类似标注应附带"每请求预估条数"和"日活预估总条数"。
