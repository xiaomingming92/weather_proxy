# farm-agent-intermediate-streaming-ui-fix-review-v1

## Review 元信息

- **Review 对象**: `farm-agent-intermediate-streaming-ui-fix-plan-v1.md` + `spec.md` + `tasks.md` + `checklist.md`
- **Review 时间**: 2026-06-16
- **Review 类型**: 方案评审（ADD-9 方向验证）
- **前置阅读**: 
  - Plan: `.qoder/plans/farm-agent-intermediate-streaming-ui-fix-plan-v1.md`
  - add-route: `.qoder/plans/farm-agent-intermediate-streaming-ui-fix-add-route-v1.md`
  - Specs: `.qoder/specs/farm-agent-intermediate-streaming-ui-fix/`

---

## 1. 问题复现

用户点击"分析一周农场数据趋势"后，流式中间态（0~24s）只显示证据条（RAG badge + 5 个通用知识文档），两个缺口：
- **缺口 A**：3 个实时工具在后台执行但前端无反馈（tool_call/tool_result SSE 事件缺失）
- **缺口 B**：证据条 source="knowledge"（`weekly_report` isSummary expert 无 grounding，回退到通用 Collection）

---

## 2. 方案对比

### 2.1 方案 A：NodeStreamController 新增 toolCall/toolResult + retrieval 跳过 isSummary
- 改动：4 个文件，5 个 Task
- 复杂度：低（~50 行代码）
- 风险：无破坏性变更

### 2.2 方案 B：前端不新增 SSE 类型，复用 structured_update
- 改动：仅前端
- 复杂度：低
- 风险：混淆中间态/最终态语义，structured_update 用于证据链等结构化数据，工具调用是中间态进度

### 2.3 方案 C：删除 weekly_report 的 isSummary 标记 + 添加 grounding
- 改动：registry.ts + Expert Grounding Collection 初始化
- 复杂度：高（涉及 Expert Grounding 全链路）
- 风险：修改 expert 定义可能影响多轮对话设计

---

## 3. 决策结论

**采纳方案 A**：改动最小，与前端已有的 `tool_call`/`tool_result` 事件处理器契约一致，isSummary 跳过 RAG 是正确的路由纠正（summary expert 的证据应来自子 expert 报告合并，不是通用知识库搜索）。

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 操作 | 风险 |
|------|------|------|
| `src/agents/stream-bus.ts` | 扩展 union type + audit | 低 |
| `src/agents/node-stream-controller.ts` | 新增 2 个方法 | 低 |
| `src/agents/nodes/retrieval.ts` | 早期 return（isSummary 跳过） | 低（不影响非 isSummary expert） |
| agrisynapse `LlmChatView.vue` | 新增 source 区分样式 | 低 |

### 4.2 数据流影响

```
修复前: toolNode → (无 SSE) → 前端
修复后: toolNode → toolCall SSE → toolResult SSE → 前端 toolCalls[]

修复前: weekly_report → searchKnowledgeDocuments(默认Collection) → source="knowledge"
修复后: weekly_report → return [] (跳过) → 无污染证据条
```

### 4.3 回滚风险

极低。所有修改是增量式的（新增接口、新增方法、新增早期 return），不影响现有代码路径。

---

## 5. 建议修正优先级

| 优先级 | 问题 |
|--------|------|
| P0 | 无 |
| P1 | Plan 未显式声明 Step 0.6.5 回流路径（Review 本身在 Plan 前置） |
| P2 | DPS 中 Specs Requirements 数偏低（2 vs 预期 12），但 2 个 Requirement 已覆盖 Plan 核心变更 |

---

## 6. 运行时审查追加项（2026-06-16 实施中）

### 6.1 工具调用持久化缺失（已修复）

- **问题**: `ChatMessage` 模型无 `toolCalls` 字段，SSE 事件仅存在前端内存中。刷新页面后 `loadThread` 硬编码 `toolCalls: undefined`，DOM 丢失工具调用信息
- **修复**: route.ts SSE 闭包收集 `toolCallsLog[]` → metadata.toolCalls 落库 → agentChat.ts 恢复
- **文件**: `route.ts` (tc-b1) + `agentChat.ts` (tc-b2)
- **状态**: ✅ 已修复

### 6.2 前端工具渲染辅助函数缺失（已修复）

- **问题**: LlmChatView.vue 模板引用了 7 个辅助函数（toolDisplayName 等），但 script 中从未实现
- **修复**: 实现全部 7 个函数 + 工具结果展开/折叠逻辑
- **状态**: ✅ 已修复

### 6.3 工具结果无数据时 dump 原始 JSON（待修复）

- **问题**: `getToolResultRows` 返回 `[]` 时，else 分支用 `formatToolResult()` dump 完整 JSON 字符串，终端用户看到 `{"success":true,"data":...}` —— 不可接受
- **根因**: else 分支设计为调试兜底，未考虑用户体验
- **建议**: 改为 "暂无数据" 友好提示（Task a6）
- **状态**: ⬜ Task a6

### 6.4 原生 `<table>` 应替换为 `<el-table>`（待修复）

- **问题**: 工具结果表格 + 证据链工具数据表格使用原生 `<table>`，项目已引入 Element Plus `el-table` 自带 empty-text、列宽自适应、风格统一
- **建议**: 全部替换为 `<el-table>`（Task a6）
- **状态**: ⬜ Task a6

### 6.5 isSummary expert 的 isRagEmpty 误判（待修复）

- **问题**: reasoning.ts L186-188 当 `isRagEmpty` 时注入 "本轮RAG检索返回 0 条结果" 降级提示，但 isSummary expert 依赖工具数据而非 RAG，提示误导
- **建议**: isSummary expert 在工具数据可用时跳过 isRagEmpty 降级（Task a4）
- **状态**: ⬜ Task a4

---

## 7. 最终建议

**已交付闭包 1**: tool_call SSE 事件 + retrieval.ts isSummary 跳过 + toolCalls 持久化 + 前端渲染辅助函数。

**待交付闭包 2**: Task a4（reasoning.ts isRagEmpty 误判）+ Task a6（el-table + 无数据友好提示）+ Task a5（截图验收）。
