# farm-agent-round5-semantic-cache-spec-review-v1

## Review 元信息

- **Review 对象**:
  - `.qoder/specs/co-agent-semantic-cache/spec.md`
  - `.qoder/specs/co-agent-semantic-cache/tasks.md`
  - `.qoder/specs/co-agent-semantic-cache/checklist.md`
  - `.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-plan-v1.md` (Step 5)
  - `.qoder/plans/farm-agent-多轮对话能力专家链路优化统一状态管理-7轮原子事务交接-handoff-v1.md` (第5轮)
- **Review 范围**: 第5轮语义缓存 spec 三件套的完整性、一致性，以及与父 Plan 的合约对齐
- **Review 时间**: 2026-06-03
- **结论级别**: **需修正后执行** — 缓存键结构需要在 spec 中修正，缓存插入时序需要澄清，但整体方向正确

---

## 1. 总体结论

第5轮 spec 三件套覆盖了语义缓存的核心功能：LRU + TTL + Generation-based 三层淘汰、cacheKey 构建、simulated streaming 输出、knowledge-indexer 集成。整体方向正确，与上游第4轮的继承关系清晰。

存在 **2 个关键问题** 和 **2 个次要问题** 需要在本轮代码执行前修正：

1. **缓存键结构**：spec 中的四元组（含 kbGeneration 在 key 里）与 Plan 的三元组（kbGeneration 在 entry 字段里）不一致，需要统一
2. **缓存插入时序**：spec 假设在 Agent 管线启动前就能拿到 `intent` 来构建 cache key，但 intent 是 intention 节点的产出，存在鸡生蛋问题
3. **spec 缺失覆盖**：`invalidate(pattern)`、`getStats()`、`normalizeQuery()` helper 在 tasks 中有但 spec 中没有对应的 Requirement
4. **spec 内部矛盾**：`MODIFIED Requirements` 中 stream/route.ts 的 `buildCacheKey` 签名仍是旧版三元组

---

## 2. 正向评价

| 评价 | 说明 |
|------|------|
| **三层淘汰设计正确** | Generation → TTL → LRU 的分层淘汰顺序与 Plan 一致，kbGeneration 惰性淘汰机制清晰 |
| **模拟流式设计合理** | cache_hit 事件 + chunkSize=3 分片 + 自适应延迟 + structured_output 补齐，与正常 SSE 流体验可比 |
| **CACHE_TTL 按意图分档** | 7 种意图 + default 的 TTL 配置与 Plan 完全一致，无遗漏 |
| **缓存不阻塞管线** | fire-and-forget + try-catch 包裹 set()，符合 Plan 的降级策略 |
| **四元组 key 优于三元组** | spec 在 Plan 三元组基础上新增 `activeExperts` 和 `kbGeneration`，避免了跨专家缓存串答案的问题。这是架构改进 |
| **原子边界清晰** | tasks.md 明确禁止提前引入第6轮 EvolutionLoop 的 TTL 自适应逻辑，边界守卫到位 |
| **文件清单正确** | 3 个文件（1 新建 + 2 修改）与 handoff 一致，stream/route.ts 的增量编辑提醒到位 |

---

## 3. 问题清单

### 3.1 Critical: 缓存键结构与 Plan 不一致

| 来源 | 缓存键组成 | `buildCacheKey` 签名 |
|------|-----------|---------------------|
| **Plan Step 5.2** | 三元组: `queryHash + intentHash + contextHash` (projectId+threadId) | `buildCacheKey(query, intent, projectId?, threadId?)` |
| **spec.md** | 四元组: `normalizedQuery + intent + activeExperts + kbGeneration` | `buildCacheKey(normalizedQuery, intent, activeExperts, kbGeneration)` |
| **handoff / tasks.md** | 四元组 (与 spec 一致) | 同上 |

**分析**：handoff 第 855 行明确写了"缓存 key 至少包含：normalizedQuery + intent + sorted(activeExperts) + kbGeneration"。这实际上是对 Plan 的改进——Plan 的三元组缺少 `activeExperts`（导致不同专家激活状态可能命中相同缓存，串答案）和 `kbGeneration`（依赖 entry 字段比对而非 key 本身）。

**但 `kbGeneration` 放在 key 里还是 entry 字段里，语义不同**：

- **Plan 设计**（entry 字段）：`kbGeneration` 在 CacheEntry 中作为出生版本号记录。`get()` 时比对 `entry.kbGeneration < currentKbGeneration` → 惰性淘汰。优点是分层清晰（Generation 判定是淘汰逻辑，不是 key 匹配逻辑）。
- **spec 设计**（key 成员）：`kbGeneration` 直接嵌在 compositeKey 里。bump 后旧 key 查不到。语义等价但失去了"三层淘汰"的清晰分层——Generat ion 过期变成了 key miss，与 TTL 过期（entry 仍存在但时间超限）混为一谈。

**建议修正**：
- 缓存键改为**三元组**：`normalizedQuery + intent + sorted(activeExperts)`，`kbGeneration` 从 key 中移除
- `kbGeneration` 保留为 `CacheEntry` 字段（出生版本号），`get()` 中作为 Layer 1 淘汰判定
- `buildCacheKey` 签名改为 `buildCacheKey(normalizedQuery, intent, activeExperts: string[])`
- 三层淘汰的职责边界重新澄清：Layer 1 Generation（entry 字段比对）、Layer 2 TTL（entry 字段比对）、Layer 3 LRU（容量淘汰）

修正后 spec 和 Plan 的差异点只是：spec 用 `activeExperts` 替代 Plan 的 `projectId+threadId` 作为上下文维度。这是合理简化——第5轮不需要区分不同 thread 的缓存（缓存是进程内存 Map），`activeExperts` 对缓存正确性的影响更大。

### 3.2 Important: 缓存查询时序 — 鸡生蛋问题

Plan 和 spec 都假设在 Agent 管线启动前就能拿到 `intent` 来构建 cache key：

```
POST /api/agent/chat/stream
    ├─ 2. 构建语义缓存键  ← 需要 intent
    ├─ 3. 查询缓存
    ├─ 4. 注入 analysisContext
    ├─ 5. 执行 Agent 管线  ← intent 在这里才产生
```

但 `intent` 是 `intention` 节点的产出——需要先跑管线才能拿到 cache key，这是鸡生蛋问题。

**两条可能路径**：

| 方案 | 描述 | 优点 | 缺点 |
|------|------|------|------|
| **A: 预判意图** | 管线启动前做轻量 intent 预判（不完整 intention 节点） | 缓存命中时完全跳过管线 | 额外 LLM 调用，违背了"缓存就是为了省 LLM 调用"的初衷 |
| **B: 管线内插入** | 缓存查询插在 `intention` 之后、`routeByIntent` 分流之前。fast 通道不查缓存（已经是直通 response），deep 通道在进 retrieval 前查缓存 | 零额外 LLM 调用，插入点语义清晰 | 缓存命中时 intention 节点已运行（但 intention 消耗小，可接受） |

**推荐方案 B**。变更点：
- `stream/route.ts`：不在管线启动前查缓存，改为在 `streamAgent` 的 deep 通道（retrieval 之前）插入缓存查询
- `routeByIntent` fast 通道：跳过缓存（fast=chat 意图直通 response，不涉及 RAG）
- `routeByIntent` deep 通道：`routeByIntent` 返回 `"retrieval"` 之前先查缓存，命中则跳转到 response
- 或者在 `retrieval` 节点的**入口**（LangGraph 节点内）做缓存查询——如果命中，retrieval 节点直接返回缓存结果并标记跳过后续节点

**spec 需新增 Requirement**：明确定义缓存插入点在管线中的位置，以及 fast/deep 通道的缓存行为差异。

### 3.3 Minor: spec.md 缺失覆盖的 Requirements

对比 tasks.md Task 1 和 Plan Step 5.2，spec 中以下功能没有独立的 Requirement：

| 缺失项 | 来源 | 说明 |
|--------|------|------|
| `invalidate(pattern: RegExp): number` | tasks Task 1, Plan 5.2 | 正则批量淘汰，用于管理操作（如按 threadId 清缓存） |
| `getStats(): { size, maxSize, hitRate? }` | tasks Task 1, Plan 5.2 | 缓存统计，用于监控和后续 TTL 自适应 |
| `normalizeQuery()` helper | spec 提到了"去标点+去空格+小写化"但无独立 Requirement | 缓存 key 构建的前置步骤，语义需要明确定义 |
| `CacheEntry` 完整字段定义 | Plan 5.2 | `hitCount`、`sourceTraceId`、`intent` 等字段的完整接口未在 spec 中列出 |

**建议**：在 spec 的 `ADDED Requirements` 中追加：
- `Requirement: 缓存淘汰管理` — `invalidate(pattern)` 和 `getStats()` 的 WHEN/THEN
- `Requirement: 查询文本标准化` — `normalizeQuery(text): string` 的定义（去标点+去空格+小写化）
- `Requirement: CacheEntry 数据结构` — 完整字段定义

### 3.4 Minor: spec 内部签名矛盾

spec `MODIFIED Requirements` 中 stream/route.ts 的集成描述仍然使用了旧版三元组签名：

> ```
> 1. 构建 cacheKey = buildCacheKey(userMessage, intent, projectId, threadId)
> ```

与 spec 自己的 `ADDED Requirements` 中四元组定义矛盾。应统一为：

```
1. 构建 cacheKey = buildCacheKey(normalizedQuery, intent, activeExpertIds, kbGeneration)
```

---

## 4. 影响评估

| 问题 | 修正前影响 | 修正后 |
|------|-----------|--------|
| 缓存键 kbGeneration 位置 | 分层淘汰语义模糊，Generation bump 后 key miss 与 TTL 过期混为一谈 | Layer 1 淘汰（entry 字段比对）、Layer 2 TTL（entry 字段比对）分层清晰 |
| 缓存插入时序 | 代码无法工作——管线启动时 intent 未知 | 插入点改为 intention 之后 / retrieval 之前，可工作 |
| spec 缺失 Requirements | 实现者可能遗漏 `invalidate`/`getStats`/`normalizeQuery` | spec 完整覆盖，tasks 与 spec 一一对应 |
| spec 内部签名矛盾 | 读者困惑到底用哪个签名 | 统一为四元组（减 kbGeneration 后为三元组） |

**协议破坏面**：无。第5轮是新建模块，不破坏上游合约。

---

## 5. 建议修正优先级

| 优先级 | 问题 | 修正方式 |
|--------|------|---------|
| **高** | 3.1 缓存键 kbGeneration 位置 | spec 修正：缓存键改为 `normalizedQuery + intent + sorted(activeExperts)`；`kbGeneration` 改为 entry 字段；`get()` 中 Layer 1 淘汰判定 |
| **高** | 3.2 缓存插入时序 | spec 新增 Requirement：明确定义缓存插入点为 `intention` 之后 / deep 通道 retrieval 之前，fast 通道跳过缓存 |
| **中** | 3.3 spec 缺失 Requirements | spec 追加 `invalidate`/`getStats`/`normalizeQuery` 的 Requirement，并补全 `CacheEntry` 字段定义 |
| **低** | 3.4 spec 内部签名矛盾 | spec `MODIFIED Requirements` 中签名对齐 |

---

## 6. 最终建议

1. **修正 spec.md**：按上述优先级修正 3.1 和 3.2（高优先级），同时顺手修 3.3 和 3.4
2. **tasks.md / checklist.md 无需修改**：tasks 中的四元组描述改为三元组即可（去掉 kbGeneration），checklist 验证项仍然适用
3. **handoff 第5轮章节**：缓存键描述从"四元组"改为"三元组 + kbGeneration 作为 entry 出生版本号"
4. **修正后即可开始编码**：整体架构方向正确，无方向性错误

---

## 附录：修正后的 spec 关键定义参考

### 缓存键

```typescript
interface CacheKey {
  normalizedQuery: string      // normalizeQuery(userMessage) 的 SHA256 前 16 位
  intentHash: string           // intent 的 hash 前 8 位
  activeExpertsHash: string    // sorted(activeExpertIds).join(",") 的 hash 前 8 位
  compositeKey: string         // `${normalizedQuery}:${intentHash}:${activeExpertsHash}`
}
```

### CacheEntry（含出生版本号）

```typescript
interface CacheEntry {
  responseContent: string
  displayContent: DisplayContent
  createdAt: Date
  ttl: number
  hitCount: number
  sourceTraceId: string
  kbGeneration: number          // 出生版本号 — get() 时与全局 getKbGeneration() 比对
  intent: string
}
```

### 三层淘汰（get 中的判定顺序）

```
get(key):
  1. entry = store.get(compositeKey) → null? MISS
  2. entry.kbGeneration < getKbGeneration()? → delete → MISS  (Layer 1: Generation)
  3. Date.now() - entry.createdAt > ttl*1000? → delete → MISS  (Layer 2: TTL)
  4. entry.hitCount++ → HIT
```

### 缓存插入点

```
intention 节点完成后:
  fast (thinkingLevel=fast) → 不查缓存 → 直通 response
  deep (thinkingLevel=deep) → 查缓存 → HIT? 跳转到 response : 进入 retrieval
```

或者等效地，在 `retrieval` 节点入口处查缓存，命中则直接返回缓存内容并标记 `skipToResponse`。
