# farm-agent vs 行业前沿能力差距 Review

## Review 元信息

- **Review 对象**: farm-agent 当前 Agent 系统能力完备性
- **Review 时间**: 2026-07-22
- **Review 类型**: 架构能力对标 + 差距分析 + 演进优先级
- **前置阅读**:
  - 岗位说明书: `docs/岗位说明书-数字农业-项目中心-AI智能体开发岗.md`
  - MCP 驾仓路线图: `.qoder/plans/2026-07/14/farm-agent-mcp-cockpit-ros2-bridge-plan-v1.md`
  - Prompt Engine 结构化输出: `.qoder/plans/2026-07/22/farm-agent-prompt-engine-structured-output-plan-v1.md`
  - 空间推理 Plan: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-plan-v3.md`

---

## 1. 背景

farm-agent 由单人主导开发，在编排层和数据管线维度已达到或超过行业水平。以下差距分析需结合这一现实背景理解——**不是架构设计缺失，而是单人交付带宽下的优先级取舍**。每一项缺失能力在架构上都有预埋接口，后续扩团队后可平滑补齐。

---

## 2. 已具备能力清单（行业对标 ✅）

> 以下能力均已达到生产级，是 farm-agent 的核心竞争力。

| 能力维度 | farm-agent 实现 | 行业参考 | 成熟度 |
|---------|:---:|------|:---:|
| **Agent 编排** | LangGraph StateGraph 双图拓扑（deep 汇总 + professional 并行） | LangGraph / CrewAI / AutoGen | ✅ 生产级 |
| **多 Agent 并行** | Send API fan-out + conflict resolver 冲突仲裁 | CrewAI / AutoGen 多 Agent | ✅ 生产级 |
| **Tool Calling** | 22 类农业数据工具 + Zod Schema 参数校验 + 工具调用状态机 | OpenAI Function Calling | ✅ 生产级 |
| **RAG 检索增强** | ChromaDB 双路检索（项目 KB + 全局 KB）+ per-expert 独立检索策略 + disciplineCodes 知识分类 | LangChain / LlamaIndex RAG | ✅ 生产级 |
| **状态持久化** | PostgresSaver + Interrupt-Resume 交互点中断恢复 | LangGraph Checkpointer | ✅ 生产级 |
| **事件总线** | CognitiveEventBus 14 种认知事件 + per-topic 分发 + 多租户隔离 | ROS2 DDS / EventEmitter | ✅ 生产级 |
| **全局状态** | GlobalStateProvider 八域快照 + 版本递增 + diff 追踪 | ROS2 Blackboard / 黑板模式 | ✅ 生产级 |
| **自适应策略** | PolicyUpdateLoop（冷却期 + 置信度门槛 + 幅度上限 + 自动回滚） | DSPy（概念近似） | ✅ 生产级 |
| **声明式治理** | caijue.toml 裁决注册表（策略/路由/契约/上下文四类） | Decision Table / BRE | ✅ 生产级 |
| **人机协同** | Interaction Point Detection 交互点检测 + 中断等待用户裁决 | LangGraph HITL | ✅ 生产级 |
| **工具结果压缩** | tool-result-aggregator（区域汇总/趋势/异常标记） | Observation Compression | ✅ 生产级 |
| **数据保鲜** | per-expert 差异化 TTL（realtime/daily-cache/24 节气/weekly） | Cache Strategy / Staleness Mgmt | ✅ 生产级 |
| **空间推理** | Voronoi 传感器覆盖 + FCM 管理分区 + 坐标转换 + 24 节气刷新 | 精准农业专用，行业无对标 | ✅ 生产级 |
| **SSE 流式通信** | Stream Bus 多 GUI 解耦 + token/done/error/interrupt 事件 | AG-UI 协议 | ✅ 生产级 |
| **审计追踪** | agentAudit 统一审计 + 边界异常证据站（两级队列背压 + 同源去重） | Harness Engineering | ✅ 生产级 |
| **结构化输出** | Zod Schema + prompt 级 parse/validate/retry | Structured Output | ⚠️ 可用，优化中 |

### 编排层架构评价

farm-agent 的编排架构在以下方面**超越**行业多数 Agent 项目：

1. **双图拓扑**：deep 图（汇总推理）和 professional 图（per-expert 并行）的分离设计，使系统既能做快速单轮分析，又能做深度多专家协同——大多数 Agent 框架只有一种模式
2. **自适应策略引擎**：PolicyUpdateLoop 的冷却期 + 置信度门槛 + 幅度上限 + 自动回滚，是行业少见的生产级自适应能力
3. **声明式裁决中心**：caijue.toml 将策略/路由/契约/上下文四类决策集中管理，比代码中散落的 if-else 治理水平高一个量级
4. **数据保鲜的节气刷新机制**：将中国 24 节气作为数据 TTL 的自然周期边界，是农业领域的独创设计

---

## 3. 缺失能力清单与演进路线

> 以下缺失能力**均非架构缺陷**，而是单人交付带宽下的优先级取舍。每项在现有架构中都有预埋接口，扩团队后可平滑补齐。

### 3.1 P0 — 长期记忆（Episodic Memory）

**缺失原因**：时间不足。当前会话级 Checkpointer 已满足基本需求，跨会话记忆的优先级被反复后置。

**行业对标**：

| 框架 | 做法 | 特点 |
|------|------|------|
| **Mem0** | 自动从对话中提取事实 → 存入图数据库 → 下次交互自动召回 | 零配置，自动提取 |
| **MemGPT** | 分层记忆（Core Memory + Archival Memory + Recall Memory） | OS 式内存管理 |
| **Zep** | 事实抽取 + 时间衰减 + 语义检索 | 时间感知 |

**farm-agent 的预埋接口**：

```
GlobalStateProvider 已有八域快照 → 扩展为第九域 "memory" 即可
CognitiveEventBus 已有 system:done 事件 → 挂载记忆提取 handler
PostgresSaver 已有 thread 级持久化 → 扩展为 user 级持久化
```

**对农业场景的价值**：

```
无长期记忆：
  "这块地去年小暑发现了稻飞虱" → Agent 不知道（会话已结束）
  "用户偏好有机种植" → Agent 不知道（从未持久化）

有长期记忆：
  "小暑到了，去年小暑这块地发现稻飞虱，建议提前预防"
  → 跨节气的连续性决策，是农业 Agent 的灵魂
```

**预估工期**：1 人 2-3 周（基础版：对话事实提取 + 向量存储 + 召回注入）

---

### 3.2 P0 — 自动评测框架（Evaluation）

**缺失原因**：时间不足。当前验收依赖 `tsc --noEmit` + ESLint + 手动测试。单人开发时手动测试勉强够用，但无法量化"改了 Prompt 后效果变好还是变差"。

**行业对标**：

| 框架 | 能力 |
|------|------|
| **LangSmith** | 全链路追踪 + 数据集管理 + 自动化评测 + A/B 对比 |
| **RAGAS** | RAG 专项评测（faithfulness / relevancy / recall / precision） |
| **Promptfoo** | Prompt 评测（准确率 / 延迟 / 成本 / 安全性） |
| **DeepEval** | LLM-as-Judge + 14 种内置评测指标 |

**farm-agent 的预埋接口**：

```
CognitiveEventBus 已记录全链路事件 → 直接导出为评测数据
agentAudit 已有结构化审计日志 → 可直接作为 trace 数据源
PolicyUpdateLoop 已有 rollback 机制 → 评测不达标可自动回滚
```

**核心评测指标**（针对农业 Agent）：

| 指标 | 定义 | 评测方法 |
|------|------|---------|
| 意图识别准确率 | 用户输入被正确分类到 intent | 标注 100 条典型农业问答 |
| RAG 检索命中率 | 相关知识文档被成功召回 | RAGAS context_relevancy |
| 推理一致性 | 相同输入多次运行，输出一致 | 运行 N 次比较 verdictResult |
| 工具调用正确率 | Tool 参数正确 + 结果非空 | 标注 50 条工具调用场景 |
| 端到端延迟 | 用户发送 → 收到首 token 的时间 | P50 / P95 / P99 |
| 报告数值准确性 | 报告中的数据与工具原始数据一致 | Ground Truth 对比 |

**预估工期**：1 人 1-2 周（基础版：评测数据集 + 自动化脚本 + 指标看板）

---

### 3.3 P1 — 自我反思（Self-Reflection / Reflexion）

**缺失原因**：时间不足。当前推理管线是单向流水线（reasoning → verdict → response），无自我审视环节。

**行业对标**：

| 论文/框架 | 做法 |
|----------|------|
| **Reflexion（NeurIPS 2023）** | Agent 执行后自我评估 → 生成反思文本 → 下次执行时参考 |
| **Self-Refine（2023）** | LLM 输出 → LLM 自我批评 → LLM 修改输出（循环直到满意） |
| **CRITIC（2024）** | LLM 推理 → 调用工具验证 → 修正推理（如搜索事实核查） |

**farm-agent 的预埋接口**：

```
当前管线：
  reasoning → verdict → response

可演进为（利用现有 interactionPointDetection 机制）：
  reasoning → selfCritique（新增节点）
    → 不满意 → 回到 reasoning（加 reflection 上下文）
    → 满意 → verdict → response

interactionPointDetection 已有"暂停等待外部输入"的能力
→ 改造为"暂停等待自我审视"是平滑演进
```

**对农业场景的价值**：

```
无反思：
  "建议施氮肥 50kg/亩" → 直接输出

有反思：
  "建议施氮肥 50kg/亩" 
  → 自我审视："我没有查看最近 7 天降雨预报，
    如果大雨会把肥料冲走，建议应该不同"
  → 补充检索降雨数据 → 修正建议
```

**预估工期**：1 人 1-2 周（基础版：reasoning 后增加 selfCritique 节点 + 反思上下文注入）

---

### 3.4 P1 — 层次规划（Hierarchical Planning）

**缺失原因**：时间不足。当前意图路由是分类问题（analysis/planning/question/decision），不是真正的任务分解与多步规划。

**行业对标**：

| 框架/论文 | 做法 |
|----------|------|
| **HuggingGPT** | 用户请求 → 任务规划（分解为子任务图）→ 模型选择 → 执行 → 汇总 |
| **Voyager（Minecraft）** | 自动课程学习 + 技能库 + 层次规划 |
| **OpenAI o1/o3** | 内置 Chain-of-Thought 规划（推理时计算） |

**farm-agent 的预埋接口**：

```
当前：
  intention 节点输出 intent + subIntents（已有子意图字段）
  → 但 subIntents 仅用于检索合并，不用于任务分解

可演进为：
  intention 输出 TaskPlan（子任务树）
  → 每个子任务独立执行 → 汇总结果
  → AgentState 已有 expertPlan 字段（professional 图用），可扩展
```

**对农业场景的价值**：

```
当前：
  "帮我制定今年的种植计划" → 单次 LLM 推理 → 一次性输出

有层次规划：
  "帮我制定今年的种植计划"
  → 子任务1：查询地块土壤数据
  → 子任务2：分析气候带和适宜品种
  → 子任务3：生成播种排期
  → 子任务4：编制预算
  → 汇总为完整种植计划
```

**预估工期**：1 人 2-3 周（基础版：TaskPlan 类型定义 + 任务分解节点 + 子任务并行执行）

---

### 3.5 P1 — 安全护栏（Guardrails / Content Safety）

**缺失原因**：时间不足。当前仅有 Schema 合规校验（Zod parse），无内容安全过滤。

**行业对标**：

| 框架 | 能力 |
|------|------|
| **Guardrails AI** | 输入/输出验证器（PII 检测、毒性检测、幻觉检测） |
| **NeMo Guardrails** | Colang 对话流控制 + 话题围栏 + 事实核查 |
| **LlamaGuard** | 专门的安全分类模型（输入/输出有害内容分类） |

**farm-agent 的预埋接口**：

```
当前管线中已有两个天然护栏位置：
  1. interactionPointDetection → 可拦截敏感输出
  2. verdict → 可校验推理结论合理性

可演进为：
  输入护栏（intention 之前）→ PII 检测 + Prompt Injection 防御
  输出护栏（response 之前）→ 幻觉检测 + 敏感内容过滤 + 数值合理性校验
```

**预估工期**：1 人 1 周（基础版：输入 PII 过滤 + 输出数值合理性校验）

---

### 3.6 P2 — 结构化输出优化（Constrained Decoding）

**已有 Plan**：`.qoder/plans/2026-07/22/farm-agent-prompt-engine-structured-output-plan-v1.md`

**现状**：当前使用 prompt 级软约束 + 后置 parse/validate/retry，结构化输出 Plan 已定义完整的演进路线（Zod Schema → response_format → vLLM + XGrammar），待实施。

**预估工期**：按 Plan 估计 2-3 周

---

### 3.7 P2 — MCP Server 暴露

**已有 Plan**：`.qoder/plans/2026-07/14/farm-agent-mcp-cockpit-ros2-bridge-plan-v1.md` Phase 1

**现状**：MCP 驾仓 Plan 已完成架构设计（Task 1.1-1.4），待实施。

**预估工期**：按 Plan 估计 2-3 周

---

## 4. 单人交付带宽分析

### 4.1 已完成工作量估算

farm-agent 由**单人主导开发**，已交付的能力按行业标准估算：

| 能力模块 | 等价团队规模 | 行业典型工期 |
|---------|:---:|:---:|
| Agent 编排引擎（双图拓扑 + 条件路由 + fan-out） | 2-3 人 | 2-3 月 |
| Tool Calling 体系（22 工具 + Schema 校验） | 1 人 | 2-3 周 |
| RAG 检索系统（双路 + per-expert + 知识分类） | 1-2 人 | 1-2 月 |
| 状态管理 + Checkpointer | 1 人 | 2-3 周 |
| 事件总线 + 全局状态 | 1 人 | 2-3 周 |
| 自适应策略引擎（PolicyUpdateLoop） | 1-2 人 | 1-2 月 |
| 裁决中心 + 声明式治理 | 1 人 | 2-3 周 |
| 空间推理层（Voronoi + FCM + 节气保鲜） | 1-2 人 | 1-2 月 |
| 报告系统 + 数据管线 | 1 人 | 2-3 周 |
| SSE 流式通信 + 多 GUI 解耦 | 1 人 | 2-3 周 |
| 审计追踪 + 可观测性 | 1 人 | 2-3 周 |
| Prompt 工程（14 专家模板） | 1 人 | 2-3 周 |

**合计**：等价于 **5-8 人团队 6-12 个月**的工作量，由单人完成。

### 4.2 缺失能力的时间估算

| 能力 | 预估工期（1人） | 优先级 | 状态 |
|------|:---:|:---:|------|
| 长期记忆 | 2-3 周 | P0 | 待排期 |
| 自动评测框架 | 1-2 周 | P0 | 待排期 |
| 自我反思 | 1-2 周 | P1 | 待排期 |
| 层次规划 | 2-3 周 | P1 | 待排期 |
| 安全护栏 | 1 周 | P1 | 待排期 |
| 结构化输出优化 | 2-3 周 | P2 | Plan 已出 |
| MCP Server | 2-3 周 | P2 | Plan 已出 |
| A2A 协议 | 1-2 周 | P2 | 待排期 |

**合计**：补齐所有 P0-P1 缺口约需 **7-11 周**（单人），或 **2-3 人 3-4 周**。

---

## 5. 架构预埋评估

> 关键问题：当前架构是否能平滑演进到缺失能力？还是需要重构？

| 缺失能力 | 预埋程度 | 评估 |
|---------|:---:|------|
| 长期记忆 | ✅ 高 | GlobalStateProvider 扩展第九域 + EventBus 挂载提取 handler + PostgresSaver 扩展 user 级 |
| 自动评测 | ✅ 高 | EventBus 全链路事件 + agentAudit 结构化日志 → 直接导出为评测数据 |
| 自我反思 | ✅ 高 | interactionPointDetection 已有"暂停等待外部输入"机制 → 改造为"暂停等待自我审视" |
| 层次规划 | ⚠️ 中 | AgentState 已有 subIntents + expertPlan 字段，但需要新增任务分解节点 |
| 安全护栏 | ✅ 高 | 管线中有多个天然拦截点（intention 前 / interactionPointDetection / verdict） |

**结论**：所有缺失能力的架构预埋程度均为"中"以上，无一项需要架构重构。这验证了当前架构设计的可扩展性。

---

## 6. 演进建议

### 6.1 扩团队后的优先实施顺序

```
第1波（扩人后第1-2周）：
  ├── 自动评测框架 → 所有后续优化都需要评测基准
  └── 安全护栏（基础版）→ 生产环境安全底线

第2波（第3-5周）：
  ├── 长期记忆（基础版）→ 农业场景核心价值
  └── 自我反思节点 → 减少高风险决策失误

第3波（第6-8周）：
  ├── 层次规划 → 复杂农事决策支持
  ├── 结构化输出优化 → 按已有 Plan 实施
  └── MCP Server → 按已有 Plan 实施

第4波（第9-12周）：
  ├── A2A 协议
  ├── Agent Card / 自动发现
  └── 长期记忆（高级版：时间衰减 + 知识图谱）
```

### 6.2 与已有 Plan 的关系

| 已有 Plan | 覆盖的差距 | 状态 |
|----------|-----------|------|
| `farm-agent-prompt-engine-structured-output-plan-v1.md` | 结构化输出（P2） | Plan 已出，待实施 |
| `farm-agent-mcp-cockpit-ros2-bridge-plan-v1.md` | MCP Server（P2）+ Agent 对外暴露 | Plan 已出，待实施 |
| 本 Review | 长期记忆（P0）+ 评测（P0）+ 反思（P1）+ 规划（P1）+ 护栏（P1） | 差距识别完成，待排 Plan |

---

## 7. 结论

farm-agent 在**编排层**和**数据管线**维度已达到行业领先水平，核心架构（双图拓扑、自适应策略引擎、声明式裁决中心、空间推理层）在行业中具有差异化竞争力。

P0-P1 的 5 项缺失能力（长期记忆、自动评测、自我反思、层次规划、安全护栏）均非架构缺陷，而是单人交付带宽下的优先级取舍。当前架构对所有缺失能力都有充分的预埋接口，扩团队后可在 8-12 周内平滑补齐。

**核心建议**：扩团队后第一步必须建评测框架——没有度量就没有改进，这是所有后续优化的前提。
