# farm-agent 工具调用链路阻断 — 运行时审查

> runtime review: intention prompt 抑制 function calling + explicitExpertId 参数丢失

## Review 元信息

- **创建时间**: 2026-06-12
- **触发场景**: 前端点击"周报分析"技能卡片，聊天过程无工具调用，RAG 检索返回 0 条
- **关联代码**:
  - [prompts/intention.ts](file:///home/xmm/ai/farm-agent/src/agents/prompts/intention.ts)
  - [route.ts](file:///home/xmm/ai/farm-agent/src/app/api/agent/[hash]/route.ts)
  - [intention.ts](file:///home/xmm/ai/farm-agent/src/agents/nodes/intention.ts)
  - [conditional.ts](file:///home/xmm/ai/farm-agent/src/agents/edges/conditional.ts)

---

## 1. 发现列表

### F1 [P0] intention prompt 中"只返回 JSON"指令抑制 LLM function calling

**症状**: LLM 已通过 `getLLMWithTools()` 绑定 23 个工具（farm-data-tools、weather-tools、time-tools 等），但始终不输出 `tool_calls`，意图解析直接返回结构化 JSON。

**根因**: [prompts/intention.ts](file:///home/xmm/ai/farm-agent/src/agents/prompts/intention.ts#L77) 的 `commonEnding` 中强制声明：

```typescript
只返回 JSON，不要其他内容。
```

此指令让 LLM 认为输出 `tool_calls` 违反了"不要其他内容"的约束，即使工具已绑定且代码链路（intention → hasToolCalls → toolNode → intention loopback）完整可用。

**影响**: 整个工具调用链路（intention → toolNode → 回路返回 intention）形同虚设。聊天过程中 LLM 从未调用 farm-data、weather、time 等外部数据工具。

**归类**: Prompt Engineering 缺陷 — prompt 约束与 runtime capability 冲突。

### F2 [P0] route.ts 未将前端 expertId 映射到 explicitExpertId

**症状**: 前端发送 `expertId: "weekly_report"`，但 agent state 中 `explicitExpertId` 为 null，导致 [intention.ts](file:///home/xmm/ai/farm-agent/src/agents/nodes/intention.ts#L97-L131) 的直连专家路径被跳过。

**根因**: [route.ts](file:///home/xmm/ai/farm-agent/src/app/api/agent/[hash]/route.ts#L355) 只提取了 `intent` 字段，未提取 `expertId`：

```typescript
const intent = (body as unknown as Record<string, unknown>).intent as string | undefined
// ❌ expertId 被忽略
```

且 [streamAgent 调用](file:///home/xmm/ai/farm-agent/src/app/api/agent/[hash]/route.ts#L452-L461) 只传 `explicitIntent`，无 `explicitExpertId`。

**影响**: 技能卡片点击沦为空壳 — expert 不激活 → 管线退化为通用 RAG 检索 → 无匹配文档 → 兜底回复。

**归类**: 参数映射缺失 — 前端传了，后端丢了。

### F3 [P0] explicitExpertId 快通道跳过 LLM 导致工具调用无法触发

**症状**: F1/F2 修复后，`explicitExpertId` 正确传入且 expert 被激活，但 LLM 从未被调用，工具调用仍为 0 次（日志 `source:"explicit_expert"` 证实走了快通道）。

**根因**: [intention.ts](file:///home/xmm/ai/farm-agent/src/agents/nodes/intention.ts#L97-L131) 的 `explicitExpertId` 分支在 expert 激活后直接 `return`，完全绕过了 `getLLMWithTools().invoke()` 调用。LLM 根本没有机会输出 `tool_calls`。

**影响**: Expert Grounding RAG（per-expert collection 知识检索）可正常工作，但实时数据工具（farm-data/weather/time）完全无法触发。周报分析只能依赖知识库文档，无法获取本周实际的传感器/气象数据。

**归类**: 架构设计缺陷 — GUI 直连专家路径与 LLM 工具调用路径互斥，而非协同。

---

## 2. 修复方案

### 修复 F1: 移除 tool_calls 抑制指令

`prompts/intention.ts` 中 `commonEnding` 的修改：
- 删除 `只返回 JSON，不要其他内容。`
- 新增工具使用引导：当用户问题涉及实时数据（天气、土壤、虫害、地块等）时，允许先调用工具获取数据，再将数据融入意图 JSON

### 修复 F2: 补传 explicitExpertId

`route.ts` 中 `handleChatPOST`：
- 从 `body` 提取 `expertId`
- 在 `streamAgent` 调用中增加 `explicitExpertId` 字段

### 修复 F3: 重构 explicitExpertId 路径为 LLM+工具调用协同模式

`intention.ts` 中 `explicitExpertId` 分支 + `prompts/intention.ts`：
- expert 激活后不再 return，改为 fall-through 到 LLM 路径
- `preActivatedContext` 在 tool_calls 返回和 normal 返回中均携带
- 注入 expert 上下文到 prompt（label、description、inputSchema），引导 LLM 自主调用工具
- 更新 `IntentionInput` 类型增加 `explicitExpertId` 字段
- `week_range` 默认当前周、`farm_area` 标注【由 GUI 预选，无需调用工具】
- `ExpertInputSchemaItem` 类型新增 `defaultDescription` 字段

---

## 3. 已运行时修复项

- [x] F1: 移除 intention prompt 中 "只返回 JSON" 指令，新增工具使用引导
- [x] F2: route.ts 补传 explicitExpertId 到 agent state
- [x] F3: explicitExpertId 快通道改为 LLM 协同模式（激活 expert 后 fall-through 走 LLM+工具）
- [x] F3 补充: prompt 中 week_range 标注默认当前周，farm_area 标注 GUI 预选
- [x] F3 补充: ExpertInputSchemaItem 类型新增 defaultDescription，weekly_report registry 同步更新
- [ ] 待后续验证：地块（massif）确认机制 — 前端 GUI 需预选地块后再触发技能卡片

---

## 4. 回流确认

- [x] 修复项已记录审计日志（`record_dev_operation`）
- [ ] 需后续验证：LLM 模型 `qwen-vl-plus` 通过 DashScope compatible API 的 function_calling 能力是否正常工作
- [ ] 需后续验证：tool_calls 回路（intention → toolNode → intention）在真实场景下可正确执行
