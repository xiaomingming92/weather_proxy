# farm-agent-project-context-activation-review-v1

## Review 元信息
- **Review 对象**: `farm-agent-project-context-activation-plan-v1.md`
- **Review 时间**: 2026-07-01
- **Review 类型**: 方案选型

## 结论

**方向正确，可执行。** 改动范围小（4 文件），向后兼容。

| # | 问题 | 严重度 | 修复 |
|---|------|--------|------|
| P1-1 | `getFarmProjectId()` 语义从返回 `currentProjectId` 变为返回 `activedProjectId`，需确认所有调用方适配 | P1 | 盘点 `getFarmProjectId()` 调用方（预计 <5 处），确保兼容 |
| P2-1 | handshake 中 `projectId` 数组无 Zod 校验 | P2 | 补充 `z.array(z.number())` + `z.number().optional()` |

## 覆盖维度

| 维度 | 状态 |
|------|:--:|
| 数据模型 | ✅ |
| 错误路径 | ✅（无新错误路径） |
| 迁移策略 | ✅（向后兼容） |
| 兼容性 | ✅（`setFarmProjectId` 同时设置 activedProjectId） |
| 存储成本 | ✅（无 DB 变更） |
