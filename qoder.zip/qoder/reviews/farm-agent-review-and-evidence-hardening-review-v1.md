# farm-agent 审查流程加固 + 边界证据站 — 实现审查

## Review 元信息

- **Review 对象**: 模板层修改（checklist + review-implementation）+ 代码层修改（append-runtime-finding + check-runtime-review + proxy/route）
- **关联方案 review**: .qoder/reviews/farm-agent-review-and-evidence-hardening-review-v1.md（待填写）
- **Review 时间**: 2026-06-09
- **Review 类型**: 实现 review（ADD-10 意图与实现的语义鸿沟）
- **前置阅读**: .qoder/plans/farm-agent-review-and-evidence-hardening-plan-v1.md

---

## 1. 跨仓库格式契约

本轮无新增跨系统 API，不涉及跨仓库格式契约变更。

- [x] 新增函数 `appendRuntimeFinding()` 签名与 plan 一致（`(error: unknown, context: EvidenceContext) => Promise<void>`）
- [x] proxy/route 最外层 try/catch 中调用 `appendRuntimeFinding`，不改变现有 API 响应格式

---

## 2. 框架版本兼容性

- [x] `cat package.json | jq .dependencies.next` ≈ `16.x`，prox
<omitted />y.ts 为 Next.js 16 推荐方式，无 breaking change
- [x] 编译产物检查：npx tsc --noEmit 通过

---

## 3. 数据模型约束

- [x] `appendRuntimeFinding.ts` 写入 AuditLog 使用 `getSystemUserId()` 懒加载真实 cuid，非硬编码字符串
- [x] AuditLog 外键 `userId → User.id`：system 用户已在 DB 中存在
- [x] 无新增 Prisma schema 变更

---

## 4. 环境变量加载链

- [x] `package.json` dev 命令：`cross-env NODE_ENV=development npm run predev && npm run db:ensure && next dev --webpack -p 3000`
- [x] predev 脚本使用 `tsx` 运行，不依赖环境变量
- [x] review-runtime.md 路径硬编码为 `.qoder/reviews/farm-agent-review-runtime.md`，不受环境变量影响

---

## 5. 多 API 场景匹配

- [x] `appendRuntimeFinding` 是 fire-and-forget 工具函数，不涉及多 API 选择
- [x] proxy/route 的 try/catch 只新增大外层包装，内部 handler 逻辑不变

---

## 6. E2E 逐端点 curl

- [ ] [R] 用有效 hash 对 dashboard 端点 curl，检查正常返回
- [ ] [R] 用无效 hash 触发 404 → 确认 RUNTIME_ERROR 写入 AuditLog
- [ ] [R] 确认 review-runtime.md 追加（或创建）

---

## 7. 关联 Checklist

对照 `.qoder/specs/review-and-evidence-hardening/checklist.md`：

- [x] [T] append-runtime-finding.ts 存在且导出 appendRuntimeFinding()
- [x] [T] check-runtime-review.ts 存在且可被 tsx 执行
- [x] [T] package.json 含 predev script 且 dev 链入
- [x] [T] proxy.ts 外层有 try/catch → appendRuntimeFinding 调用
- [x] [T] route.ts 外层有 try/catch → appendRuntimeFinding 调用
- [x] [T] L1/L2/业务 metadata 代码无改动
- [x] [T] appendRuntimeFinding 是 fire-and-forget，自身异常不传播
- [x] [T] appendRuntimeFinding 不 import agent 节点层模块
- [x] [T] check-runtime-review.ts 不阻断启动（exit code 0）
- [R] E2E curl 验证 — 待运行时
- [R] session-init 扫描 review-runtime.md — 待运行时
