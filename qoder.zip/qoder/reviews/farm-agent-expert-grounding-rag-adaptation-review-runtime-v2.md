# Expert Grounding RAG 适配 — 运行时审查 v2

> **审查时间**: 2026-06-11
> 
> **v2 增量**: RAG、Tool、LangChain 节点、LangGraph 流、Global OS Kernel 四层关系审查
> 
> **v1 基线**: ChromaDB collection 迁移 + evidence grounding 验证清单 + B1-B4 缺陷修复

> **关联 Plan**: [agent-os-kernel-wiring-plan-v1.md](../plans/farm-agent-os-kernel-wiring-plan-v1.md) — 基于本 review 的 6 断裂点管线接入方案

---

## 0. v1 的局限性

v1 聚焦于 Expert Grounding 的 ChromaDB 层（collection 分片、证据溯源），未覆盖上游的执行层与内核层的交互。具体来说：

| 未覆盖 | 原因 |
|--------|------|
| ToolNode 执行后的 OS 信号 | ToolNode 是 LangGraph 原生对象，不在 v1 审查范围内 |
| RAG 检索结果与 Tool 结果的合流 | retrieval 节点只消费 ChromaDB，工具结果留在 `AgentState.messages` |
| GlobalStateProvider 对工具/RAG 的感知 | `execution.toolCallsCount` 字段存在但从未更新 |
| CognitiveEventBus 工具/RAG 事件 | `action:proposed` 类型定义了 `tool_call` 但从未 emit |
| PolicyUpdateLoop 对工具调用模式的感知 | evaluate() 的 4 个维度全看节点产出，无工具执行数据 |

v2 补充以上全部缺失项。

---

## 1. 四层系统全景

```
┌─────────────────────────────────────────────────────────────────┐
│                         LangGraph Flow                           │
│                                                                  │
│   __start__ → intention ─┬─→ toolNode ──→ intention（回环）      │
│                          ├─→ retrieval → reasoning               │
│                          └─→ response（fast）                    │
│                                     │                            │
│                     interactionPointDetection                    │
│                           ╱              ╲                       │
│                     verdict              response                │
│                         │                                        │
│                         ▼                                        │
│                      response → __end__                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐     │
│   │  RAG 层       │  │  Tool 层（23 tools，全部专家共用）│  │  LangChain 节点   │     │
│   │              │  │                          │  │                  │     │
│   │ retrieval    │  │ 23 tools                 │  │ intention        │     │
│   │   ↓          │  │  ├─ search   │  │ retrieval        │     │
│   │ ChromaDB     │  │  ├─ time     │  │ reasoning        │     │
│   │   ↓          │  │  ├─ weather  │  │ verdict          │     │
│   │ knowledge-   │  │  ├─ farm     │  │ response         │     │
│   │ indexer.ts   │  │  └─ task     │  │ interactionPoint │     │
│   └──────┬───────┘  └──────┬───────┘  └────────┬─────────┘     │
│          │                 │                    │               │
├──────────┼─────────────────┼────────────────────┼───────────────┤
│          │                 │                    │               │
│   ┌──────┴─────────────────┴────────────────────┴───────────┐  │
│   │                    OS Kernel（第8轮）                      │  │
│   │                                                          │  │
│   │  GlobalStateProvider    CognitiveEventBus   PolicyUpdate  │  │
│   │  ├─chat/agent/memory    ├─11 种事件类型      Loop          │  │
│   │  ├─execution ★          ├─pub/sub           ├─cacheTtl    │  │
│   │  ├─policy/audit         ├─timeline          ├─promptHint  │  │
│   │  └─feedback             └─consumer registry ├─expert      │  │
│   │                                              └─evidence   │  │
│   └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│   ★ = 字段存在但从未被 RAG/Tool 层更新                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. 断裂点逐一分析

### 2.1 断裂点 A: ToolNode ↔ OS Kernel 信号缺失

**当前代码** (`src/agents/index.ts` L44)：
```typescript
.addNode("toolNode", new ToolNode(agentTools))
```

ToolNode 是 LangGraph 原生对象。6 个节点的注册方式是 `wrapNodeWithAudit("intention", state, intentionNode)`（L26-42），但 toolNode 是裸的——无 audit 包装、无 eventBus emit、无 GlobalStateProvider 更新。

**设计预设但未实现**：

| 预设 | 位置 | 状态 |
|------|------|:--:|
| `action:proposed` 事件类型含 `actionType: "tool_call"` | `cognitive-event-bus.ts` L35 | 类型存在，从未 emit |
| `ExecutionStateSnapshot.toolCallsCount` | `global-state.ts` L34 | 字段存在，始终为 0 |
| `EVENT_CONSUMER_REGISTRY` 支持 `pull`/`wait`/`skip`/`fallback` | `event-consumer-strategies.ts` L21-25 | 注册表只有 1 个消费者（policy-update-loop on `system:done`） |
| `CognitiveEventBus.subscribe()` 支持按事件类型订阅 | `cognitive-event-bus.ts` L75-93 | 管道可用，无订阅者 |

**实际流**：
```
intention 检测 tool_calls → routeByIntent("toolNode")
  → ToolNode 执行 [tool1, tool2, ...]
  → ToolMessage[] 写入 AgentState.messages
  → toolNode → intention（回环）
  → 无 emit、无 state 更新、无 audit
```

**预期流**（与 Linux OS 同构）：
```
intention 检测 tool_calls → routeByIntent("toolNode")
  → ToolNode 执行 tool_i
  → emit({ type: "action:proposed", actionType: "tool_call",
           detail: JSON.stringify({ name, success, rowCount, durationMs }) })
  → globalStateProvider.updateDomain("execution", prev => ({
      ...prev,
      toolCallsCount: prev.toolCallsCount + 1,
      lastToolName: name,
      lastToolStatus: success ? "success" : "failed",
      lastToolDurationMs: durationMs,
    }))
  → toolNode → intention（回环）
  → 下游节点可通过 getSnapshot().execution 感知工具执行结果
  → PolicyUpdateLoop 可通过 eventBus.getHistory() 获取工具调用模式
```

---

### 2.2 断裂点 B: RAG 检索结果与 OS Kernel 信号分离

**retrieval 节点** (`src/agents/nodes/retrieval.ts`)：
- 直接调用 `searchKnowledgeDocuments()` → ChromaDB
- 结果写入 `state.evidenceChain`
- 调用 `agentAudit()` 写审计日志
- **不 emit** `evidence:retrieved` 事件
- **不更新** `GlobalStateProvider.agent.evidenceCount`

**设计预设**：
- `evidence:retrieved` 事件类型已定义 (`cognitive-event-bus.ts` L26)
- `AgentCognitiveSnapshot.evidenceCount` 字段存在 (`global-state.ts` L18)

**但 GlobalStateProvider.syncFromAgentState()** (`global-state.ts` L213-225) 只在流结束后被调用一次（`index.ts` L214）。这意味着 retrieval 执行完后，OS 内核的 `agent.evidenceCount` 仍然是上一轮的值，直到整个流结束才更新。

---

### 2.3 断裂点 C: Tool 结果与 RAG 结果在 reasoning 节点处合流断裂

**reasoning 节点** 的输入来源：
1. `state.evidenceChain` — RAG 检索结果（retrieval 节点写入）
2. `state.messages` — 含 ToolMessage（ToolNode 写入）

当前 reasoning 的 prompt 构建 (`src/agents/nodes/reasoning.ts`) 只消费 `evidenceChain`，不消费 `messages` 中的工具结果。工具调用产出的数据（土墒、虫情、气象站）完全不进入推理上下文。

**合流缺失的后果**：
- LLM 调用 `query_soil_moisture` 获取了土墒数据，但 reasoning 不知道
- 工具结果只能等下一次 intention → toolNode 回环时被 LLM 看到（以 chat messages 形式参与下一轮意图判断），而非参与当前轮的深度推理
- PolicyUpdateLoop 看不到工具调用频率、成功率，无法据此调整策略

### 2.4 新发现：evidenceChain 跨轮次残留导致旧证据冒充新报告

**发现时间**: 2026-06-12，通过审计日志回溯 growth_report 生成过程  
**影响范围**: 同 thread 内跨轮次 RAG 检索

#### 2.4.1 现象

同一 thread (`thread_c28fbcba`) 内两个连续轮次：

| 轮次 | 意图 | RAG 检索 | evidenceChain | reasoning 产出 |
|------|------|---------|--------------|---------------|
| Turn 1 | daily_report | 12 条命中 | [12 条农情证据] | 农情日报 ✅ |
| Turn 2 | growth_report | **0 条命中** | [**仍保留 12 条 Turn1 证据**] | "生长报告" ← 用旧证据编的 |

Turn 2 的 ChromaDB collection 为空（growth_report 无对应知识库），检索零命中。但 `state.evidenceChain` 未在轮次边界清空，reasoning 节点拿着 Turn 1 的 12 条农情证据 + growth_report prompt，强行推理出"生长报告"。

**这不是跨 thread 污染**（两个轮次同属 `thread_c28fbcba`），而是同 thread 内 **evidenceChain 生命周期管理缺失**——证据被当成持久记忆使用。

#### 2.4.2 行业三条分层线

行业标准严格区分三个独立生命周期层：

| 层 | 生命周期 | 典型实现 | farm-agent 现状 |
|------|---------|---------|:--:|
| 对话记忆 | 跨轮累积 | 摘要压缩 / 滑动窗口 / ConversationBufferMemory | `AnalysisContext.turnHistory` | ✅ |
| 当前轮证据 | 单轮有效 | 每轮检索前清空，新结果覆盖 | `evidenceChain` 不清空 | ❌ |
| 知识索引 | 持久化 | ChromaDB / Pinecone | ChromaDB collection | ✅ |

LangChain 的 `ConversationalRetrievalChain` 是经典范例：每轮检索独立产出 `sourceDocuments`，跨轮记忆走 `chat_history` 单独注入 prompt，**两条管线互不污染**。farm-agent 当前把证据当了记忆用。

#### 2.4.3 OS 内核视角的修复方向

不在 AgentState 层手动 `evidenceChain = []`（绕过 GlobalStateProvider，违背 OS 设计哲学）。正确路径是通过 `wrapNodeWithAudit` 在节点边界注入 OS 内核感知。

**为什么是 wrapNodeWithAudit，不是 stream consumer**

当前 `syncFromAgentState()` 挂在 stream consumer 末尾（`index.ts` L213-214），整个流结束后才执行一次，太晚了。但挂在 stream consumer 的 chunk 迭代中间也不行——LangGraph 的 `.stream()` 是**产出即消费**：chunk `{ retrieval: {...} }` 到达 consumer 时，LangGraph 内部已经推进到 intention 路由甚至 reasoning 了。stream consumer 是在事件循环的微任务队列中消费 chunk，无法在 retrieval 和 reasoning 两个 super-step 之间插入代码。

能做到的是 `wrapNodeWithAudit`（`index.ts` L69-103）：它**运行在 LangGraph 节点内部**，是节点函数调用的包装器。BSP 模型下，节点 N 的 wrapper return 之后，LangGraph 才会推进到 super-step N+1。这意味着：

```
LangGraph super-step N:
  → wrapNodeWithAudit("retrieval", state, retrievalNode)
    → retrievalNode(state) → 返回 { evidenceChain: [...] }
    → ★ 此时调用 globalStateProvider.updateDomain("agent", prev => ({
        ...prev, evidenceCount: newCount
      }))                          ← 在 wrapper return 前，实时写入 OS 内核
    → return result to LangGraph

LangGraph 内部 state 合并 + 路由 → super-step N+1:
  → intention (路由)
  → wrapNodeWithAudit("reasoning", state, reasoningNode)
    → ★ sn := globalStateProvider.getSnapshot()     ← 实时读取
    → if sn.agent.evidenceCount === 0:
        state.fallbackFlags.ragEmpty = true           ← OS 内核注入降级信号
    → reasoningNode(state) → prompt 带降级标记
```

时间线上，`globalStateProvider.updateDomain()` 在 retrieval 的 wrapper return 前执行，`globalStateProvider.getSnapshot()` 在 reasoning 的 wrapper 开始时执行——两个调用在不同 super-step，LangGraph BSP 模型天然保证前者先于后者，不存在竞态条件。

**前提依赖**：`wrapNodeWithAudit` 当前签名 `(nodeName, state, nodeFn)` 没有 `globalStateProvider` 引用。需要注入——方案 A（RunnableConfig.configurable）在 Plan §2.1 已选定，`wrapNodeWithAudit` 签名改为 `(nodeName, state, nodeFn, config?)`，从 `config.configurable.globalStateProvider` 取引用。

核心改动：

1. **AgentState 新增 `fallbackFlags` 字段**：`{ ragEmpty: boolean, toolResultsEmpty: boolean, ... }`，由 wrapNodeWithAudit（reasoning 入口处）写入，reasoning 节点函数读取
2. **wrapNodeWithAudit 扩展为节点边界钩子**：retrieval 出口处更新 `globalStateProvider.agent.evidenceCount`；reasoning 入口处读取并注入 `fallbackFlags`
3. **零命中时注入降级信号**而非空跑：`fallbackFlags.ragEmpty = true`，reasoning prompt 注入 `[系统提示] 本轮RAG检索返回 0 条结果，基于模型知识回答，置信度较低。`
4. **跨轮记忆走 turnHistory 摘要**：上轮对话结论通过摘要注入 prompt，不带原始证据 chunk

当前 `GlobalStateProvider.syncFromAgentState()` 只在流结束后调用一次（`global-state.ts` L213-225），在 retrieval→reasoning 之间 OS 内核完全看不到证据状态变化。

#### 2.4.4 与 Plan 的衔接

该缺陷在 [agent-os-kernel-wiring-plan-v1.md](../plans/farm-agent-os-kernel-wiring-plan-v1.md) 中未覆盖，建议作为 Task 3（retrieval OS 感知）的自然延伸——retrieval 接入 OS Kernel 时同步修复 evidenceChain 轮次隔离。

---

## 3. EVENT_CONSUMER_REGISTRY 缺口

当前注册表 (`event-consumer-strategies.ts` L43-51) 只有 1 个消费者：

```typescript
export const EVENT_CONSUMER_REGISTRY: EventConsumerConfig[] = [
  {
    id: "policy-update-loop-consumer",
    subscribe: ["system:done"],           // 只在流结束后触发
    dependsOn: ["agent", "memory", "policy", "chat", "feedback"],
    strategy: "pull",                      // 由 route.ts 主动调 evaluate()
    description: "PolicyUpdateLoop ...",
  },
]
```

**缺失的消费者**：

| 消费者 | 应订阅 | 策略 | 理由 |
|--------|--------|:--:|------|
| `retrieval-context-consumer` | `action:proposed` (tool_call) | `wait` | retrieval 节点执行前检查 execution 域，如有工具产出则合并到搜索上下文 |
| `reasoning-context-consumer` | `evidence:retrieved` + `action:proposed` | `wait` | reasoning 节点执行前检查，合并 RAG 证据和工具结果。注意：pull 语义为"管线末端由外部主动调 evaluate()"，reasoning 是中间节点，用 wait 阻塞直到 dependsOn 域就绪更符合语义。 |
| `tool-audit-consumer` | `action:proposed` (tool_call) | `wait` | 工具执行后写入 AuditLog DB |

---

## 4. 四层之间的小闭环现状

### 4.1 RAG → LangGraph 流

| 路径 | 状态 |
|------|:--:|
| retrieval 节点 → `state.evidenceChain` → reasoning 节点消费 | ✅ 正常 |
| retrieval 节点 → `agentAudit("RETRIEVAL_DECISION")` → AuditLog | ✅ 正常 |
| retrieval 节点 → `emit("evidence:retrieved")` → CognitiveEventBus | ❌ 缺失 |
| retrieval 节点 → `globalStateProvider.updateDomain("agent")` | ❌ 仅在流结束后 |
| retrieval 节点 → `state.currentTask?.subIntents` → `resolveSubIntentPlan()` → caijuehub | ✅ 正常 |

### 4.2 Tool → LangGraph 流

| 路径 | 状态 |
|------|:--:|
| intention 检测 `tool_calls` → `routeByIntent("toolNode")` | ✅ 正常 |
| ToolNode 执行 → `state.messages` 写入 ToolMessage | ✅ 正常（LangGraph 原生） |
| ToolNode → intention 回环 → LLM 看到工具结果 | ✅ 正常（下一轮） |
| ToolNode → `emit("action:proposed")` | ❌ 缺失 |
| ToolNode → `globalStateProvider.updateDomain("execution")` | ❌ 缺失 |
| 工具结果 → reasoning 节点 prompt 注入 | ❌ 缺失（同轮不可见） |

### 4.3 OS Kernel → 下游消费

| 路径 | 状态 |
|------|:--:|
| `globalStateProvider.syncFromAgentState()` 在流结束后 | ✅ 正常 |
| `globalStateProvider.syncFromAnalysisContext()` 在流结束后 | ✅ 正常 |
| `PolicyUpdateLoop.evaluate()` 在流结束后 fire-and-forget | ✅ 正常 |
| 节点执行中实时读取 `getSnapshot()` | ❌ 无节点使用 |
| 节点订阅 `eventBus.subscribe()` | ❌ 无节点订阅 |

---

## 5. 与 Linux 内核同构的偏差

farm-agent OS 内核按 Linux 同构设计，但三处未对齐：

| Linux | farm-agent 设计 | 实际 | 偏差 |
|-------|----------------|------|------|
| `task_struct` → `/proc` | `GlobalSystemState.execution` | 字段存在，未更新 | ToolNode 不写 execution 域 |
| `do_signal()` → `SIGCHLD` | `action:proposed(tool_call)` | 事件类型存在，未 emit | ToolNode 不 emit |
| `waitpid()` → 父进程感知 | 节点 `subscribe(action:proposed)` | subscribe API 可用，无订阅者 | 无节点订阅工具事件 |
| `scheduler stats` → `cgroup` | `PolicyUpdateLoop.evaluate(cacheTtl, ..., toolStats)` | evaluate() 存在，无 toolStats 参数 | 工具调用模式不可见 |

---

## 6. Agent OS Kernel 概念隐没（文档缺口）

### 6.1 现象

GlobalStateProvider、CognitiveEventBus、PolicyUpdateLoop 三个组件已在代码中落地，但架构文档中从未将它们统一命名为 **Agent OS Kernel**。当前这些概念只在对话上下文和 memory 中流转，不对文档读者暴露。

| 组件 | 代码位置 | 文档覆盖 |
|------|---------|:--:|
| `GlobalStateProvider` | `src/agents/global-state.ts` | `specs/farm-agent-global-state/`（仅 checklist） |
| `CognitiveEventBus` | `src/agents/cognitive-event-bus.ts` | 同上 |
| `PolicyUpdateLoop` | `src/agents/policy-update-loop.ts` | 同上 |
| **Agent OS Kernel 概念** | 无专有文件 | ❌ 零处定义 |

### 6.2 为什么这是个问题

1. **OS 隐喻只在代码和对话中可见，不在文档中**。阅读 `global-state.ts` 的注释看不到 `/proc` 同构类比，阅读 `cognitive-event-bus.ts` 看不到 `netlink/udev` 类比。新读者可能理解功能，但不知道"为什么这样设计"。
2. **三个组件被误解为独立工具**。没有 OS Kernel 概念的串联，GlobalStateProvider 看起来像"全局变量池"、CognitiveEventBus 像"pub/sub 库"、PolicyUpdateLoop 像"定时任务"。但它们的 OS 本质是：统一的系统调用接口（`/proc`）+ 异步事件通知机制（`netlink`）+ 自适应调度策略（`cgroups/scheduler`）。
3. **子系统边界不清、注册无规范**。一个完整的 OS 至少包含文件系统（ChromaDB 持久化）、进程管理（LangGraph 节点调度）、内存管理（AgentState + MemorySaver）、设备驱动（工具 API 客户端）。这些在代码中都有，但从未被组织到统一的 OS 框架下，导致新添"设备驱动"时不知道该注册到哪个 domain、该 emit 什么事件。

### 6.3 缺失的文档

| 应有文档 | 当前状态 |
|---------|:--:|
| Agent OS Kernel 架构总览（子系统关系图 + Linux 同构映射表） | ❌ 不存在 |
| OS 子系统清单与实现状态（已实现 / 待实现） | ❌ 不存在 |
| 新子系统注册规范（声明 domain、consumer strategy、subscribe 事件类型） | ❌ 不存在 |
| `EVENT_CONSUMER_REGISTRY` 扩展指南（何时用 pull/wait/skip/fallback，各策略的含义与约束） | ❌ 不存在 |
| OS 内核与 LangGraph 管线的职责边界定义（OS 是静默框架层、管线是执行层，互不持有对方引用） | ❌ 不存在 |

### 6.4 推荐

新增 `docs/大田精准耕播智能决策系统/knowledge/01-架构/Agent-OS-Kernel-架构说明书.md`，至少覆盖：

- Linux 同构映射表（GlobalStateProvider.getSnapshot() ↔ /proc, CognitiveEventBus ↔ netlink, PolicyUpdateLoop ↔ scheduler tuning, 工具 ↔ user-space process）
- OS 子系统清单与状态
- 文档引用：将现有 `specs/farm-agent-global-state/` 作为 OS Kernel 的子文档索引，而非孤立 spec

---

## 7. LangGraph BSP 模型与 OS Kernel 实时性约束

### 7.1 问题

LangGraph 的 Pregel 引擎基于 BSP（Bulk Synchronous Parallel）模型。ToolNode 内部用 `Promise.all()` 等待所有工具完成，然后作为单个 super-step 产出。OS Kernel 无法在 ToolNode super-step 内部观察单个工具的完成——这是 BSP 模型的设计约束，不是版本问题（LangGraph 1.3.2 的 `ToolCallStream` 只服务于外部协议层）。

### 7.2 影响评估


| 场景 | 受 BSP 影响？ | 说明 |
|------|:--:|------|
| reasoning 同轮消费工具结果 | 否 | 图拓扑 `toolNode → intention → (retrieval →) reasoning` 天然保证 ToolMessage 已在 `state.messages` 中。不涉及 BSP 打破。当前 reasoning 未消费工具结果是因为没读 messages（断裂点 C），不是拓扑问题。|
| PolicyUpdateLoop 跨轮次学习 | 否 | 跨请求模式识别，不依赖同轮实时性 |
| 逐工具实时流式观察 | **是** | 需 BSP 打破，不在 farm-agent 控制范围内 |

### 7.3 结论

BSP 约束锁的是**节点内部不可见**（即 ToolNode 内单个工具完成时无法被 OS Kernel 观察）。但跨节点观察不受影响——图拓扑的 `toolNode → intention → retrieval → reasoning` 链路天然保证后续节点执行时工具结果已全部就绪。

OS Kernel 在 BSP 约束下能发挥约 70% 的设计价值。PolicyUpdateLoop 的跨轮次模式识别（工具成功率、缓存命中率、专家激活模式）才是 OS Kernel 的真正主场——不依赖 BSP 打破。

---

## 8. 多租户隔离缺失

### 8.1 当前状态

`route.ts` L213-214 在 POST handler 内创建 `GlobalStateProvider` 和 `CognitiveEventBus`：每次 HTTP 请求一个独立实例，不同用户不会互相污染。**隔离存在，但是"碰巧对的"，不是设计出来的。**

### 8.2 结构性问题

| 缺失 | 后果 |
|------|------|
| `GlobalSystemState` 无 `tenantId` 字段 | 如果将来一个请求处理多个 thread，状态会串 |
| `CognitiveEventBus` 无 threadId 过滤 | `getHistory()` 只能看全局事件，无法按会话过滤 |

### 8.3 推荐

- `GlobalSystemState.meta` 新增 `tenantId?: string`
- `CognitiveEventBus.getHistory()` 支持 `filter: { threadId }`

---

## 9. 修复方向（不在本次审查范围，留给 Plan）

1. **ToolNode 包装**：替换为自定义包装器，在工具执行前后 emit `action:proposed` + `updateDomain("execution")`
2. **ExecutionStateSnapshot 扩展**：新增 `lastToolName` / `lastToolStatus` / `lastToolDurationMs`
3. **retrieval/reasoning 节点 OS 感知**：执行前检查 `getSnapshot().execution`，合并到 prompt 上下文。当前 `wrapNodeWithAudit` 签名 `(nodeName, state, nodeFn)` 不传递 OS 内核对象，节点获取 `globalStateProvider` 引用有三种可行通道，需 Plan 阶段选定：
   - **A: RunnableConfig 注入**：通过 `agent.stream(input, { configurable: { globalStateProvider } })` 传入，节点从 `RunnableConfig` 取。与 LangGraph 的 `thread_id` 同机制，不污染 state，不改变节点签名。推荐。
   - **B: wrapNodeWithAudit 签名扩展**：改为 `(nodeName, state, nodeFn, os)`，显式注入。所有自定义节点签名需变，ToolNode 不归 wrapNodeWithAudit 管，需单独处理。
   - **C: AgentState 携带（禁用）**：`AgentState._osProvider` 字段。checkpointer 会将其序列化写入快照，导致反序列化失败和快照膨胀。不可选。
4. **EVENT_CONSUMER_REGISTRY 扩展**：新增 retrieval-context / reasoning-context / tool-audit 三个消费者
5. **PolicyUpdateLoop 工具感知**：`evaluate()` 新增 `toolExecutionStats` 参数
6. **wrapNodeWithAudit wiring**：在每个节点边界调用 `eventBus.emit()` + `globalStateProvider.updateDomain()`
7. **多租户 namespace**：`GlobalSystemState.meta.tenantId` + `getHistory({ filter })`
8. **evidenceChain 轮次隔离**（§2.4 新发现）：retrieval 节点接入 OS Kernel 时同步修复，通过 wrapNodeWithAudit 节点边界钩子（retrieval 出口写入 evidenceCount、reasoning 入口注入 fallbackFlags）实现零命中降级信号
9. **AgentState 新增 `fallbackFlags` 字段**：OS 内核写入的降级标志，reasoning 读取后走降级 prompt 模板

---

## 10. 受影响文件

| 文件 | 当前状态 | 涉及断裂点 |
|------|---------|:--:|
| `src/agents/index.ts` L44 | `new ToolNode(agentTools)` 裸注册 | A |
| `src/agents/global-state.ts` L32-35 | `ExecutionStateSnapshot` 字段不足 | A |
| `src/agents/cognitive-event-bus.ts` L35 | `action:proposed` 类型存在但未 emit | A |
| `src/caijuehub/strategies/event-consumer-strategies.ts` L43-51 | 注册表只有 1 个消费者 | A, C |
| `src/agents/nodes/retrieval.ts` | 不 emit evidence 事件，不更新 GlobalState | B |
| `src/agents/nodes/reasoning.ts` | 不消费 state.messages 中工具结果 | C |
| `src/agents/nodes/reasoning.ts` | 不感知 fallbackFlags（零命中降级信号） | G |
| `src/agents/policy-update-loop.ts` L301-304 | evaluate() 无工具执行数据入参 | C |
| `src/agents/global-state.ts` L213-225 | syncFromAgentState 仅流结束后调用，无轮次级订阅 | G |
| `docs/大田精准耕播智能决策系统/knowledge/01-架构/` | 无 Agent OS Kernel 架构说明书 | D |
| `src/app/api/agent/chat/stream/route.ts` L213-214 | GlobalStateProvider/EventBus per-request 非设计隔离 | F |
| `src/agents/index.ts` L69-103 | wrapNodeWithAudit 无 eventBus emit / 无 state updateDomain | E |

---

## 11. 验证清单

以下检查项需 dev server 运行，通过 AuditLog 和 eventBus history 交叉验证：

- [R] V1: `action:proposed` 事件在 tool_call 时 emit
  - 预期: `eventBus.getTimeline(["action:proposed"]).filter(e => e.actionType === "tool_call")` 非空
- [R] V2: `ExecutionStateSnapshot.toolCallsCount` > 0
  - 预期: `globalStateProvider.getSnapshot().execution.toolCallsCount` 与工具调用次数一致
- [R] V3: `ExecutionStateSnapshot.lastToolName` 记录最后执行的工具名
  - 预期: 与 AuditLog 中的工具名一致
- [R] V4: reasoning 节点 prompt 含工具结果摘要
  - 预期: AuditLog `REASONING_PROMPT` 的 extra 中含 `toolResultsCount > 0`
- [R] V5: `evidence:retrieved` 事件在检索后 emit
  - 预期: `eventBus.getTimeline(["evidence:retrieved"])` 非空
- [R] V6: PolicyUpdateLoop 能看到工具调用统计
  - 预期: `PolicyUpdateRecord.decisionReason` 含 `toolCallSuccessRate` 或类似字段
- [R] V7: `EVENT_CONSUMER_REGISTRY` 注册 ≥3 个消费者
  - 预期: `registry.length > 1`
- [R] V8: `npx tsc --noEmit` 零新增类型错误

---

## 12. 执行顺序

```
V1 (tool emit) → V2 (state update) → V3 (lastToolName)
                                       ↓
                                  V5 (evidence emit)
                                       ↓
                                  V4 (reasoning 合流)
                                       ↓
                                  V6 (PolicyLoop 感知)
                                       ↓
                                  V7 (consumer registry)
                                       ↓
                                  V8 (tsc)
```
