# farm-agent 第4轮 Spec / Handoff Review

## Review 元信息

- **Review 对象**:
  - `.qoder/specs/co-agent-pipeline-integration/spec.md`
  - `.qoder/specs/co-agent-pipeline-integration/tasks.md`
  - `.qoder/specs/co-agent-pipeline-integration/checklist.md`
  - `.qoder/documents/co-agent-conversation-handoff.md` 的 `<第4轮>` 章节
  - `.qoder/documents/co-agent-simplified-v1.md` Step 4.5-4.8（父 Plan 参考）
  - `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统技术架构说明书》.md` — 八节（当前仅含 8.1-8.3，8.4 尚未创建）
  - `docs/大田精准耕播智能决策系统/knowledge/01-架构/《大田精准耕播智能决策系统决策管线架构说明书》.md` — 二/三节（状态字段 + 管线拓扑）
  - `docs/大田精准耕播智能决策系统/knowledge/01-架构/《RAG知识库系统技术文档》.md` — ChromaDB SOURCE_TYPE 值域
- **Review 范围**: 第4轮领域消费闭包：管线消费 + 报告服务 + 架构文档对齐
- **Review 时间**: 2026-05-26
- **结论级别**: ~~方向正确，但存在 3 个致命阻塞性问题，不建议在修正前进入代码执行~~ → **[2026-05-26 收敛后更新]** 三个致命问题已全部解决，spec/tasks/checklist 已对齐，可进入代码执行。

---

## 1. 总体结论

第4轮 spec、tasks、checklist 和 handoff 的整体方向正确——让 activeExperts 被 retrieval / reasoning / response 实际消费，并提供多格式报告生成与下载。

~~但是，本轮存在三个致命阻塞性问题。~~ **[2026-05-26 收敛后更新]** 经过讨论，三个致命问题已全部解决：

| 问题 | 初判 | 收敛结论 |
|------|------|---------|
| 架构文档 8.4 节缺失 | 致命 | ✅ 确认需在 Step 0 创建（history: 第1-3轮均在代码前创建对应章节） |
| `ChatMessage.structuredResponse` 不存在 | 致命 | ✅ 全部改为 `ChatMessage.metadata: Json?` |
| `EvidenceFilter.sourceTypes` ChromaDB 不匹配 | ~~致命~~ | ✅ 建 `KnowledgeCate` 表 → `cateId` 索引桥接 → `evidenceFilter` 使用 ChromaDB `where` 语法。本问题在 Review 讨论过程中发现更深层根因：父 Plan 需要的是 ChromaDB `where` 子句原语（`Record<string,unknown>`），而第3轮实现的是业务语义类型（`ExpertEvidenceFilter { keywords, sourceTypes: EvidenceSource[] }`），两者维度完全不同 |

---

## 2. Review 讨论过程

### 2.1 ~~初版结论~~ → 讨论纠正

**[初版 Review 指出两个致命问题，但分析有误]**

~~ChromaDB `sourceType` 只有两类值（`PROJECT_DOC` / `KNOWLEDGE_UPDATE`），而 `EvidenceSource` 有 11 种业务语义值。但 ChromaDB 的 `metadatas` 是 PostgreSQL 数据的索引投影，不是独立数据源。真正的问题是：postgreSQL 已有 `Document.tags` 和 `Document.metadata`，但索引时没有桥接到 ChromaDB，导致专家过滤无法命中任何文档。**

~~推荐方案 A：用 `evidenceFilter.keywords` 增强查询字符串。用户指出这等于只有"查不到不报错"的兜底，专家过滤是空洞的。~~

**[讨论收敛]**

问题不是"不该改"，而是"按职责改什么"。讨论逐层推进：

1. 用户指出：ChromaDB 确实有文档标签的定义，`Document.tags` 和 `Document.metadata` 已经存在
2. 用户指出：`tags` 和分类维度不能互相替代（一个文档有多个 tags、只有一个分类）
3. 用户指出：分类应该是**树形结构**，不是扁平的 `sourceType` 枚举
4. 用户指出：`cate` 比 `sourceLabel` 更准确（表达的是农业知识分类，不是"来源标签"）
5. 用户指出：应该建 `KnowledgeCate` 表作为 PRISMA 管理的受控词表，自引用树 → 项目已有 `Task.TaskHierarchy` 可对齐
6. 用户指出：`evidenceFilter` 存 ChromaDB `where` 子句原语（`{ cateId: { $in: [...] } }`），不是业务语义类型

**最终方案**：

```
KnowledgeCate 表（Prisma）
├── 自引用树（parentId + @relation("KnowledgeCateHierarchy")）
├── 纯新增，不碰已有表/字段
└── 叶子节点 ID 被专家 evidenceFilter 引用
         ↓
knowledge-indexer.ts（索引桥接）
├── 索引前读 Document.knowledgeCateId + Document.tags
└── 写入 ChromaDB metadata: { cateId, tags }
         ↓
retrieval.ts（管线消费）
├── 合并 activeExperts 的 evidenceFilter（$in 取并集）
├── 透传 where 给 searchKnowledgeDocuments → ChromaDB
└── 0 结果时降级无过滤（RAG_EXPERT_FILTER_EMPTY 审计）
```

### 2.2 "不改 Prisma Schema"的含义纠正

~~初版 Review 将此理解为"不能改 Prisma Schema"。~~ → **[2026-05-26 纠正]** 用户明确：不改已有表/字段，但可以新增独立模型。`KnowledgeCate` 是纯新增，完全在约束内。

### 2.3 evidenceFilter 类型收敛

~~初版 Review 对比了 `ExpertEvidenceFilter.sourceTypes: EvidenceSource[]` 和 ChromaDB `sourceType: string`。~~ → 根因不在 ChromaDB 值域大小，而在第3轮实现的类型不是父 Plan 要求的 ChromaDB `where` 原语。父 Plan L676 定义 `evidenceFilter?: Record<string, unknown>`，第3轮错误地细化成了 `ExpertEvidenceFilter { keywords, sourceTypes }`。

---

## 3. 正向评价（维持不变）

### 3.1 第4轮原子边界清晰

**[2026-05-26 更新]** 新增 `KnowledgeCate` 模型和索引桥接仍在第4轮原子边界内：不改已有 Prisma 表/字段、不改 Prisma 已有字段、不改前端组件、不改 stream-bus。文件清单从 ~~2新+4改~~ 扩展到 **2新+7改**（新增 schema/registry/knowledge-indexer），但职责边界未变。

### 3.2 管线消费的三节点设计正确

```text
retrieval:  activeExperts 非空 → 合并 evidenceFilter → 透传 ChromaDB where → 过滤检索
            activeExperts 为空 → 行为不变

reasoning:  activeExperts 非空 → 追加专家维度块
            activeExperts 为空 → 行为不变

response:   activeExperts 非空 → 构造 StrategyActiveExpert[]
            activeExperts 为空 → ResponseStrategy 自行裁决
```

"空→行为不变"的向后兼容设计确保了无分析上下文时的常规对话不受影响。

### 3.3 PostgreSQL 单一真相源 + ChromaDB 索引投影

**[2026-05-26 补充评价]** 架构决策正确：KnowledgeCate 在 PostgreSQL 管理（受控词表），Document 引用它（`knowledgeCateId`），索引时投影到 ChromaDB metadata。迁移到 Milvus 时从 PostgreSQL 重新全量索引即可，不依赖 ChromaDB 数据导出。

### 3.4 报告 API 设计合理

（不变）

### 3.5 依赖选择务实

（不变）

---

## 4. 问题清单（全部已解决）

### 4.1 ~~EvidenceFilter.sourceTypes 与 ChromaDB sourceType 不匹配~~ → ✅ 已解决

**[收敛方案]** 新建 `KnowledgeCate` 表 → `evidenceFilter` 使用 ChromaDB `{ cateId: { $in: [...] } }` where 语法 → `knowledge-indexer.ts` 索引桥接。详见第2节。

### 4.2 ~~ChatMessage.structuredResponse 字段不存在~~ → ✅ 已解决

全部改为 `ChatMessage.metadata: Json?`。spec/tasks/checklist 已更新。

### 4.3 ~~架构文档 8.4 节不存在~~ → ✅ 已解决

确认需在 Step 0（文档先行）创建。checklist 已将此纳入验证标准。

### 4.4 ~~Handoff 恢复指南不完整~~ → 待代码执行时补全

第4轮 handoff 恢复指南仍需补全（对齐第2轮模板）。建议在代码执行完成后由第4轮 AI 补齐：[ADDED] 逐文件 targetId 查询映射、一键汇总 keyword、恢复顺序建议。

### 4.5 ~~管线节点缺少 ANALYSIS_EXPERTS 导入~~ → 已列入 tasks

tasks.md Task 3-5 均明确写出 `import { ANALYSIS_EXPERTS } from "@/agents/experts/registry"`。

### 4.6 ~~reportFormats 不一致~~ → 保留当前值

registry.ts 中三个专家 `reportFormats: ["md", "xlsx"]`，与父 Plan 存在差异。`inferDefaultFormat` 按硬编码映射实现（roi→xlsx, 其他→md），不依赖 `reportFormats[0]`。

### 4.7 ~~降级语义~~ → 已修正

降级从"查不到就跳过"改为 **"ChromaDB 文档尚未关联 knowledgeCateId 时的兼容保护"**。一旦有文档被标记分类，过滤立即生效。

---

## 5. 越界检查（更新后）

**[2026-05-26 更新]** 新增的 `KnowledgeCate` 模型和 `knowledge-indexer.ts` 索引桥接仍在原子边界内：不改已有表/字段，不改 stream-bus，不改前端。

没有看到第4轮提前实现：semantic cache（第5轮）、path metrics（第6轮）、审计管线（第7轮）、Global State Model（第8轮）。

---

## 6. 最终建议

第4轮 spec/tasks/checklist 已通过讨论收敛，**可以进入代码执行**。执行前需完成：

1. **Step 0 文档先行**：创建架构文档 8.4 节 + 决策管线说明书拓扑图更新
2. 按 Task 0 → Task 8 顺序执行（spec 已更新为划旧留新格式，可追溯全部变更历史）
3. 代码执行完成后：补全 handoff 恢复指南

执行顺序（已修正）：

```text
Step 0: 创建架构文档 8.4 节（文档先行）
  ↓
Task 0: prisma schema 新增 KnowledgeCate + migrate dev + seed
  ↓
Task 1: registry.ts evidenceFilter 修正（引用 KnowledgeCate cateId）
  ↓
Task 2: knowledge-indexer.ts 索引桥接 + searchKnowledgeDocuments where 扩展
  ↓
Task 3: retrieval.ts 合并 evidenceFilter + 降级
  ↓
Task 4-5: reasoning.ts / response.ts 管线消费（可并行，依赖 Task 1）
  ↓
Task 6-7: report-generator.ts + report/route.ts（可并行）
  ↓
Task 8: npm install（可并行）
  ↓
Step 0.6: 架构文档回看确认一致性
```

完成的判定标准（已修正）：

```text
架构文档 8.4 节已创建 + 八节标题更新为"第1-4轮"
决策管线说明书已更新：管线拓扑含专家消费标注 + 报告 API 拓扑小节
analysisContext 成功从 stream/route.ts 经 streamAgent 传递到各管线节点
retrieval 在 activeExperts 非空时使用 cateId 过滤 ChromaDB（非伪造的 source 字段）
reasoning 在 activeExperts 非空时追加专家维度块
response 在 activeExperts 非空时构造 StrategyActiveExpert[]
报告 API 从 ChatMessage.metadata 正确提取 StructuredAgentResponse（非 ChatMessage.structuredResponse）
activeExperts 为空时三个管线节点行为不变
ADD-7 审计 action 完整落库（9 个文件）
Handoff 恢复指南补全对齐第2轮模板
```
