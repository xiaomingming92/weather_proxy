# farm-agent-add-hook-governance-review-v3

## Review 元信息

- **Review 对象**: [farm-agent-add-hook-governance-plan-v3.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/30/farm-agent-add-hook-governance-plan-v3.md)
- **Review 范围**: 11 Qoder Hook 事件 → ADD 全生命周期映射的架构设计
- **Review 时间**: 2026-06-30
- **Review 类型**: 架构决策 + API 合规检查
- **前置阅读**: [Qoder Hook 文档](https://docs.qoder.com/zh/cli/hooks) / [Qoder CN Hook 文档](https://help.aliyun.com/en/lingma/qodercli-cn/user-guide/hook) / [ADD 治理词汇表](file:///home/xmm/ai/farm-agent/.qoder/vocabulary/add-governance-vocabulary.md)

---

## 1. 总体结论

**方向正确，但存在 3 个 API 误解 + 2 个过度设计 + 1 个优先级倒挂。需修正后执行。**

11 事件全覆盖的设计方向正确——ADD 流程确实能和 Qoder Hook 事件层一一对应。但具体到每个事件的 Action 设计，有 3 处与 Hook API 实际行为不一致，会导致运行时行为不符合预期。

---

## 2. 正向评价

- ✅ **UserPromptSubmit 三层路由设计**：精准触发词 → 上下文注入 / 开发关键词 → exit 2 / 活跃流程 → 注入状态，逻辑清晰且与 vocabulary 单一真值源对齐
- ✅ **共享库设计**：`vocabulary.sh` + `state-detect.sh` 避免 11 个脚本各自重复解析逻辑
- ✅ **vocabulary 机器可读化**：在 vocabulary.md 新增纯文本触发词清单供 hook grep，保持 vocabulary 仍是单一真值源

---

## 3. 问题清单

### P0-1: Stop 事件用错了 exit code 语义

**Plan 写的是**：Stop 检测到 ADD 未闭环 → stdout 注入提示 → exit 0
**API 实际行为**：Stop 的 **exit 2 = 阻止 Agent 停止**，stderr 作为消息注入对话让 Agent 继续工作。exit 0 = Agent 正常停止。

**影响**：如果验收未闭环（devlog 缺、handoff 未更新），`exit 0` 会让 Agent 停下来不做事——正相反，应该 `exit 2` 迫使 Agent 完成闭环。

**修正**：
```
Stop 检测到 ADD 未闭环 → stderr "验收未闭环: 缺 devlog/handoff" → exit 2（Agent 继续工作）
Stop 检测到 ADD 已闭环 → exit 0（Agent 可以停了）
```

### P0-2: PostToolUse 不能"提示执行 MCP 工具"

**Plan 写的是**：PostToolUse → stdout 提示 "请执行 record_dev_operation"
**API 实际行为**：PostToolUse 在工具**已执行完毕后**触发，不能阻断。stdout 作为 `additionalContext` 注入对话，但 Agent 不一定立即响应。

**影响**：审计落库提醒可能被忽略（Agent 已经继续做别的事了）。

**修正**：PostToolUse 的提醒改为 `additionalContext`（注入对话但不强制），配合 Stop 的 exit 2 形成双重保障——Stop 时检查审计是否完整，不完整则不让停。

### P0-3: SessionStart 遗漏 "clear" 和 "new" source

**Plan 写的是**：只处理 startup / resume / compact
**API 实际值**：startup / resume / clear / compact / new 共 5 种

**影响**：`/clear` 或新建会话时不注入上下文，Agent 丢失 ADD 状态。

**修正**：SessionStart 对所有 source 统一执行活跃流程检测，不区分 source。

### P1-1: 11 事件全部实施 → 用户决策：保持全量，测试部分（已闭环）

**用户决策**：11 个独立脚本成本相近，全部一次交付。5 个高频事件全测，5 个低频事件 mock 验证。Plan §四 已更新。

### P2-1: PreToolUse 的 Plan 检查粒度（已回流）

**原问题**：`src/agents/` 或 `src/lib/` → 太粗
**修正**：收窄为 `src/agents/**` + `src/lib/agent-audit-logger.ts` + `src/types/**` + `prisma/schema.prisma`。其他 lib/ 和 app/ 放行。Plan §3.2 事件3 已更新。

### P2-2: additionalContext JSON 结构化注入（已回流）

**原问题**：全部使用 stdout 纯文本，未利用 Hook API 的 `hookSpecificOutput.additionalContext` 字段
**修正**：SessionStart 使用 JSON 格式注入 Plan 路径 + 当前 Step + 恢复审计查询命令。Plan §3.2 事件1 已更新。

---

## 4. 影响评估

| 修正项 | 影响文件 | 修复难度 |
|--------|---------|:--:|
| P0-1: Stop exit code | `stop-check.sh` | 低（改 1 行） |
| P0-2: PostToolUse 语义 | `post-tool-use.sh` + Plan §3.2 | 中（需配合 Stop 双重保障） |
| P0-3: SessionStart source | `session-start.sh` | 低（删除 source 判断） |
| P1-1: 优先级重排 | Plan §四 | 低（重新编号 Task） |
| P2-1: PreToolUse 路径收窄 | `pre-tool-use.sh` | 低（改 grep 正则） |

---

## 5. 建议修正优先级

```
高优先级:
  1. Stop → exit 2 语义修正
  2. SessionStart → 覆盖全部 source
  3. 优先级重排：先交付轮次1（UserPromptSubmit + SessionStart + Stop）

中优先级:
  4. PostToolUse → additionalContext + Stop 双重保障
  5. PreToolUse → 路径收窄

低优先级:
  6. additionalContext JSON 结构化注入
```

---

## 6. 最终建议

**可接受，修正 P0 后执行。** 建议先交付轮次 1（3 个核心事件），用实际对话验证后再补轮次 2。

执行顺序：
1. 回流 P0-1~P0-3 至 Plan
2. 重排 Task 为两轮
3. 实施轮次 1（UserPromptSubmit + SessionStart + Stop）
4. 实战验证
5. 实施轮次 2
