# farm-agent-add-hook-governance-review-v2

## Review 元信息

- **Review 对象**: [farm-agent-add-hook-governance-plan-v3.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/30/farm-agent-add-hook-governance-plan-v3.md)（实施后审查）
- **对比基线**: [review-v3（v1）](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-add-hook-governance-review-v3.md) — 6 个问题（P0-1/2/3, P1-1, P2-1/2）
- **Review 时间**: 2026-06-30
- **Review 类型**: 实施后代码质量审查 + 边界条件验证
- **审查范围**: `.qoder/hooks/` 下 11 个脚本 + 3 个共享库 + `settings.json` + `vocabulary.md`

---

## 1. v1 Review 问题闭环验证

| v1 问题 | 状态 | 证据 |
|---------|:----:|------|
| P0-1: Stop exit code 语义 | ✅ 已修正 | [stop-check.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/stop-check.sh#L23) Q2 `exit 2`，[L65](file:///home/xmm/ai/farm-agent/.qoder/hooks/stop-check.sh#L65) 未闭环 `exit 2` |
| P0-2: PostToolUse 不阻断 | ✅ 已修正 | [post-tool-use.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/post-tool-use.sh#L19) 仅 stdout 提醒，`exit 0`，Stop 双重保障已实现 |
| P0-3: SessionStart 全 source | ✅ 已修正 | [session-start.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/session-start.sh) 无 source 过滤，统一处理 |
| P1-1: 11 事件全量交付 | ✅ 已交付 | settings.json 11 事件全部配置，10 个脚本全部就位 |
| P2-1: PreToolUse 路径收窄 | ✅ 已修正 | [pre-tool-use.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/pre-tool-use.sh#L9) 精确到 `src/agents/` + `agent-audit-logger.ts` + `src/types/` + `prisma/schema.prisma` |
| P2-2: JSON 结构化注入 | ✅ 已修正 | [context-inject.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/lib/context-inject.sh#L6-L17) `build_session_start_json` 输出结构化 JSON |

**结论：v1 全部 6 个问题已闭环。** 实施质量高于 Plan 设计——实际交付了 Plan 未包含的 `review-checklist.sh`（112 行，验收 Review 质量检查）。

---

## 2. 正向评价

### 2.1 超预期交付

| 项目 | Plan 设计 | 实际交付 |
|------|----------|---------|
| 脚本数量 | 10 个 | 11 个（+`review-checklist.sh`） |
| 验收检查 | Stop 仅检查 devlog/handoff/add-route | +checklist 质量复查（6 类问题检测） |
| 触发词路由 | 仅 P0 精准触发词 | +Layer 2 开发关键词检测 + Layer 3 活跃 ADD 状态注入 |
| 验收幂等 | 无设计 | `prompt-submit.sh` L15-34: 已验收 → Review 模式（不重复覆盖） |
| 审计表同步 | 无设计 | `review-checklist.sh` L90-103: checklist cuid vs handoff 审计表交叉验证 |

### 2.2 架构设计亮点

- **四象限 Stop 分流** ([stop-check.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/stop-check.sh#L17-L71)): Q1~Q4 语义清晰，`exit 0` vs `exit 2` 使用正确
- **Dev Flag 追踪** ([state-detect.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/lib/state-detect.sh#L10-L62)): 用 `/tmp` 标记文件跨 hook 事件传递"本次是否有代码改动"，解决 hook 间无状态共享问题
- **词汇表驱动路由** ([vocabulary.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/lib/vocabulary.sh)): 触发词→操作映射从单一 markdown 表格解析，改词汇表即可改路由
- **验收幂等保护**: 二次"验收"不覆盖已有结论，自动进入 Review 模式

### 2.3 防御性设计

- `pre-tool-use.sh` 路径白名单：非核心路径（`src/app/`, `src/lib/` 中非审计文件）直接放行，避免过度阻断
- `prompt-submit.sh` 三层路由降级：精准触发词 → 开发关键词 → 状态注入，优先级递减
- `stop-check.sh` 的 `stop_hook_active` 幂等保护（L4-L5）：上一轮已用 `exit 2` 阻止过的，本轮不再阻止，避免无限循环

---

## 3. 问题清单（实施后审查）

### P1-1: `pre-compact.sh` 分隔符不一致（代码 Bug）✅ 已修复

**位置**: [pre-compact.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/pre-compact.sh#L10)
**问题**: 使用 `IFS='|'` 解析 `detect_active_add` 输出，但 `detect_active_add` 实际使用 `::` 作为分隔符（[state-detect.sh#L46](file:///home/xmm/ai/farm-agent/.qoder/hooks/lib/state-detect.sh#L46)）。导致解析结果全部为空。

```bash
# 错误（pre-compact.sh L10）
IFS='|' read -r plan step rounds handoff <<< "$state"

# 正确
IFS='::' read -r plan step rounds handoff add_route <<< "$state"
```

**影响**: PreCompact 事件不注入有效 ADD 状态，上下文压缩后丢失 Plan 信息。
**修复**: 2026-06-30 已修正，同步补齐 `add_route` 字段匹配 5 字段输出。

---

### P1-2: `detect_active_add` 7 天窗口 + 策略优先级缺陷

**位置**: [state-detect.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/lib/state-detect.sh#L14-L47)
**问题 1**: `-mtime -7` 硬编码 7 天窗口。超过 7 天未活跃的 Plan 会被静默丢失——
- SessionStart 不注入上下文 → Agent 不知道有未完成 Plan
- PreToolUse 不检查 → 可直接修改核心代码无 Plan
- Stop 不触发 Q4 验收检查 → 未闭环代码可正常 Stop

**问题 2**: 搜索策略有逻辑冲突。先找当天目录（L17），再全局搜索（L18），但两次都用 `-mtime -7`。如果当天目录的 handoff mtime 超过 7 天（项目放了一周假），会进入 L18 fallback；但如果刚好有另一个 7 天内的 handoff 在其他目录，会错误匹配到不相关的 Plan。

**修正建议**:
1. 将 `-mtime -7` 改为 `-mtime -30`（放宽到 30 天）或基于 handoff §状态 字段（`进行中` vs `已验收`）判断
2. 搜索策略应先精确匹配当天目录，再 fallback 全局；fallback 时优先匹配与 prompt 关键词相关的 handoff

**修复难度**: 中（需改检测逻辑 + 增加状态字段判断）。

---

### P2-1: `notification.sh` 全局 ls 性能 + 无过滤

**位置**: [notification.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/notification.sh#L19)
**问题**: `ls "$reviews_dir"/*.md` 在当前已有 60+ review 文件的 reviews 目录下执行。每次 Notification result 事件触发都要遍历全部文件。且不区分是否与当前活跃 Plan 相关。
**修正建议**: 只检查与当前活跃 `detect_active_add` Plan 相关的 review 文件。
**修复难度**: 低。

---

### P3-1: `vocabulary.sh` markdown 表格解析脆弱

**位置**: [vocabulary.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/lib/vocabulary.sh#L8-L18)
**问题**: `sed -n '/^## 类别 A: 文档类型/,/^## 类别 [G-Z]/p'` 硬编码了章节标题。如果 vocabulary.md 的章节标题格式变动（如 "类别 A: 文档类型" → "类别 A：文档类型" 全角冒号），解析静默失败——`load_triggers` 返回空，`prompt-submit.sh` 三层路由全部失效。

**当前 vocabulary.md 实际格式**: 文件中 §类别 A~F 使用了**两套格式**——前半部分用 `## 类别 A: 文档类型（11 个）` 表格格式，后半部分用 `## 类别 A: 文档类型` + 独立表格格式。`sed` 命令匹配前半部分，但后半部分的 `## 类别 G-Z` 不存在，可能导致 sed 匹配到文件末尾，获取到额外的非表格行。

**修正建议**: 
1. 改用更鲁棒的解析方式（如提取所有 `| P0 | trigger | action |` 行）
2. 或改为在 vocabulary.md 末尾维护一个 `## 附录: hook 触发词清单` 专用区域，格式严格
**修复难度**: 中。

---

### P3-2: 缺乏 hook 脚本单元测试

**问题**: Plan §Task 4 设计了集成测试（5 全测 + 5 mock），但 `.qoder/hooks/` 目录下无测试文件，`.qoder/tests/` 也无对应测试。当前只能靠运行时验证，回归风险高。

**具体风险场景**:
- `stop-check.sh` Q4 分流逻辑修改后，可能误判 Q2/Q3
- `vocabulary.sh` markdown 解析修改后，`prompt-submit.sh` 可能全部放行
- `pre-tool-use.sh` 路径白名单修改后，可能阻断不该阻断的文件

**修正建议**: 在 `.qoder/hooks/` 下增加 `tests/` 目录，为 5 个高频 hook 写 stdin 模拟测试：
```bash
# 示例: test-stop-check.sh
echo '{"stop_hook_active": false}' | \
  .qoder/hooks/stop-check.sh
# 验证: exit code 和 stderr 输出
```

**修复难度**: 中（需逐个编写 mock stdin + 验证逻辑）。

---

### P3-3: `subagent-guard.sh` 门禁类型硬编码

**位置**: [subagent-guard.sh](file:///home/xmm/ai/farm-agent/.qoder/hooks/subagent-guard.sh#L8)
**问题**: 只匹配 `guardian|orchestrator`，如果未来新增 `add-flow-guardian-v2` 或其他门禁 Subagent 名称不包含这两个关键词，日志将静默丢失。
**修正建议**: 改为匹配 `add-flow|guardian|orchestrator` 或使用更宽的匹配。
**修复难度**: 低。

---

## 4. 边界条件分析

| 场景 | 当前行为 | 是否合理 | 建议 |
|------|---------|:------:|------|
| vocabulary.md 不存在 | `load_triggers` 返回 1，`prompt-submit.sh` 全部放行 | ⚠️ | 应 exit 2 阻止所有写操作（无词汇表 = 不可治理） |
| handoff 文件被手动删除 | `detect_active_add` 返回空，ADD 状态丢失 | ⚠️ | 应有 git 检查或从 add-route 恢复的 fallback |
| settings.json JSON 非法 | Qoder 加载 hook 配置失败，全部 hook 静默不执行 | ⚠️ | Plan 应有验收项：`jq . .qoder/settings.json > /dev/null` |
| 同时存在多个活跃 handoff | `detect_active_add` 只取第一个 `find | head -1` | ⚠️ | 可能匹配到错误的 Plan |
| `/tmp/qoder_dev_*` 标记文件残留 | `has_dev_action` 误判为"本次有代码改动" | ⚠️ | 建议在 SessionStart 时清理旧的 dev flag |
| `prompt-submit.sh` 无 prompt 字段 | 静默 exit 0（L5） | ✅ | 正确——非用户输入不触发路由 |
| 中文触发词（全角/半角） | `grep -qiE` 大小写不敏感，但全半角敏感 | ✅ | 已在 vocabulary 中用 `\|` 覆盖两种写法 |

---

## 5. 影响评估

| 问题编号 | 严重度 | 影响范围 | 触发条件 | 修复难度 |
|:--------:|:----:|---------|---------|:------:|
| P1-1 | 🔴 高 | PreCompact 上下文注入失效 | 每次 compact | 低 |
| P1-2 | 🟡 中 | 7 天后 ADD 状态静默丢失 | 项目停 7 天以上 | 中 |
| P2-1 | 🟢 低 | Notification 性能 | 每次 result 通知 | 低 |
| P3-1 | 🟡 中 | 全部触发词路由失效 | vocabulary.md 格式变化 | 中 |
| P3-2 | 🟡 中 | 回归风险 | hook 脚本修改后 | 中 |
| P3-3 | 🟢 低 | 新门禁 Subagent 日志丢失 | 新增门禁类型 | 低 |

---

## 6. 建议修正优先级

```
高优先级（影响核心功能）:
  1. P1-1: 修复 pre-compact.sh 分隔符 bug
  2. P3-2: 为高频 hook 补充单元测试

中优先级（健壮性提升）:
  3. P1-2: 放宽 detect_active_add 时间窗口 + 状态字段判断
  4. P3-1: 增强 vocabulary.sh 解析鲁棒性

低优先级（优化）:
  5. P2-1: notification.sh 按 Plan 过滤 review 文件
  6. P3-3: subagent-guard.sh 放宽门禁类型匹配
```

---

## 7. 总体结论

**实施质量显著高于 Plan 设计。** 11 个 hook 全部可用，v1 Review 的 6 个问题全部闭环，还超预期交付了 `review-checklist.sh` 验收质量复查和验收幂等保护。四象限 Stop 分流 + Dev Flag 追踪 + 词汇表驱动路由构成了一套**生产级的 ADD 治理基础设施**。

当前唯一的 **功能性 Bug 是 P1-1**（pre-compact.sh 分隔符错误），会导致 compact 时丢失 ADD 上下文。其余问题为健壮性改进。

**建议**: 修复 P1-1 后即可投入日常使用。P1-2（7 天窗口）可在下次项目休假前修复。P3-2（单元测试）建议在下次修改 hook 脚本前补齐。

---

## 8. 关联文档

| 文档 | 路径 |
|------|------|
| Plan (v3) | [farm-agent-add-hook-governance-plan-v3.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/30/farm-agent-add-hook-governance-plan-v3.md) |
| v1 Review | [farm-agent-add-hook-governance-review-v3.md](file:///home/xmm/ai/farm-agent/.qoder/reviews/farm-agent-add-hook-governance-review-v3.md) |
| Hooks 目录 | `.qoder/hooks/` (11 脚本 + 3 lib) |
| Settings | [.qoder/settings.json](file:///home/xmm/ai/farm-agent/.qoder/settings.json) |
| 词汇表 | [add-governance-vocabulary.md](file:///home/xmm/ai/farm-agent/.qoder/vocabulary/add-governance-vocabulary.md) |
