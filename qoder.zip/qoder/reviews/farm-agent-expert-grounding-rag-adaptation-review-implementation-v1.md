# Expert Grounding RAG 适配 — 实现审查 v1

> **审查时间**: 2026-06-11
> **审查范围**: Plan v1（0.6.5 回流修正后）Task Group A-D 全部代码实现
> **add-route**: farm-agent-Expert-Grounding-RAG适配-add-route-v1.md

---

## 0. 审查方法

逐文件对照 Plan §4 实施步骤 + spec.md §Requirements + checklist.md 编译期检查项，验证代码实现与意图的一致性。

---

## 1. 文件级审查

### 1.1 `scripts/migrate-expert-collections.ts` (Task A3, CREATE)

| 审查点 | 预期 | 实际 | 判定 |
|--------|------|------|------|
| 支持 `--expert` 指定单 Expert 迁移 | ✅ | 已实现 | ✅ |
| 支持 `--dry-run` 模式 | ✅ | 已实现 | ✅ |
| 支持 `--source-collection`  | ✅ | 已实现 | ✅ |
| 按 cateId 从源 collection 复制文档 | ✅ | 已实现 | ✅ |
| 保留原 collection 不删除 | ✅ | 已实现 | ✅ |

### 1.2 `src/agents/experts/registry.ts` (Task B1, MODIFY)

| 审查点 | 预期 | 实际 | 判定 |
|--------|------|------|------|
| `AnalysisExpert.grounding` 字段 | ✅ | 已添加 | ✅ |
| 3 个 Phase 1 Expert 配置 collectionName | ✅ | crop_compare/roi_analysis/pest_risk | ✅ |
| 6 个 Phase 2 Expert 配置 collectionName | ✅ | weather_impact 等 6 个 | ✅ |
| `grounding.ready()` 懒加载 | ✅ | `createGroundingReady()` 工厂 | ✅ |

### 1.3 `src/agents/experts/filter-types.ts` (Task B2, MODIFY)

| 审查点 | 预期 | 实际 | 判定 |
|--------|------|------|------|
| `GroundingStatus` 接口定义 | ✅ | ready/documentCount/lastSyncedAt/indexHealth | ✅ |

### 1.4 `src/caijuehub/strategies/sub-intent.ts` (Task B3, MODIFY)

| 审查点 | 预期 | 实际 | 判定 |
|--------|------|------|------|
| `RetrieveBudget.perExpertTopK` | ✅ | `Record<string, number>` | ✅ |
| 核心 Expert topK=5 | ✅ | `isSummary: false → 5` | ✅ |
| 汇总 Expert topK=10 | ✅ | `isSummary: true → 10` | ✅ |
| `NULL_PLAN.retrievalBudget.perExpertTopK` | ✅ | `{}` | ✅ |

### 1.5 `src/services/knowledge-indexer.ts` (Task C1/C2, MODIFY)

| 审查点 | 预期 | 实际 | 判定 |
|--------|------|------|------|
| `getChromaCollection(collectionName?)` 多 collection | ✅ | `Map<string, ChromaCollection>` 缓存 | ✅ |
| 不传 collectionName 默认 `farm_agent` | ✅ | 向后兼容 | ✅ |
| `SearchOptions` 接口 | ✅ | `collectionName?` / `filter?` | ✅ |
| collectionName 与 filter 互斥路由 | ✅ | collectionName 优先 | ✅ |
| 旧调用方行为不变 | ✅ | 第三参数兼容旧式 `Record` | ✅ |

### 1.6 `src/agents/nodes/retrieval.ts` (Task C3/D2, MODIFY)

| 审查点 | 预期 | 实际 | 判定 |
|--------|------|------|------|
| per-expert `Promise.all` 并行检索 | ✅ | 已实现 | ✅ |
| grounding 路由: ready → collection, 否则 → evidenceFilter | ✅ | 互斥分支 | ✅ |
| expertIds 直标 `[expertId]` | ✅ | 不再通过 cateId 反向映射 | ✅ |
| chunkId 去重 + expertIds 归并 | ✅ | `EXPERT_DEDUP` 审计 | ✅ |
| `buildCateIdToExpertIds()` 移除 | ✅ | 已删除 | ✅ |
| 6 个新审计 Phase | ✅ | READY/DEGRADED/COLLECTION_SEARCH/SEARCH_EMPTY/SEARCH_RESULT/DEDUP | ✅ |
| expertIds fallback 到 subIntentPlan | ✅ | commit 9a8a2bf | ✅ |

### 1.7 `src/types/evidence.ts` (Task D1, MODIFY)

| 审查点 | 预期 | 实际 | 判定 |
|--------|------|------|------|
| `Evidence.grounding` 可选字段 | ✅ | collectionName/groundingStatus/retrievedVia | ✅ |
| `EvidenceSource` 新增 `"expert"` | ✅ | reliability 0.85 | ✅ |

### 1.8 `src/lib/agent-audit-logger.ts` (Step 1, MODIFY)

| 审查点 | 预期 | 实际 | 判定 |
|--------|------|------|------|
| 6 个新 AgentAuditPhase 字面量 | ✅ | 全部已添加 | ✅ |

---

## 2. Spec 需求对照

| Spec Requirement | 实现位置 | 判定 |
|:--|:--|:--:|
| WHEN Grounded Expert → THEN collection 检索 | retrieval.ts grounding 路由 | ✅ |
| WHEN 未 Grounded Expert → THEN evidenceFilter 降级 | retrieval.ts fallback 分支 | ✅ |
| WHEN 多个 Expert 命中同一 chunk → THEN 去重归并 | retrieval.ts chunkId dedup | ✅ |
| WHEN 检索完成 → THEN evidence 含 grounding 元数据 | retrieval.ts grounding 字段写入 | ✅ |

---

## 3. 类型安全检查

- `npx tsc --noEmit` ✅ 零新增类型错误
- `RetrieveBudget.perExpertTopK` 消费端可选链 `?.` 防 undefined ✅
- `NULL_PLAN` 包含 `perExpertTopK: {}` ✅
- `grounding.ready()` 返回 `Promise<GroundingStatus>` 类型对齐 ✅

---

## 4. 架构一致性

| 原则 | 判定 |
|------|:--:|
| 裁决层统一分配 perExpertTopK | ✅ |
| grounding 路由在 retrieval 节点内闭环 | ✅ |
| 降级路径保留为永久 fallback | ✅ |
| 全局 `farm_agent` collection 不删除 | ✅ |
| 证据归属从间接（cateId 映射）升级为直接（expertIds 直标） | ✅ |

---

## 5. 结论

**14/14 审查点全部通过** ✅。代码实现与 Plan v1 架构设计、spec.md 需求场景、checklist.md 编译期检查项完全一致，无语义鸿沟。

**遗留**: 运行时验证（检查项 `[R]`）由 `review-runtime.md` 覆盖。
