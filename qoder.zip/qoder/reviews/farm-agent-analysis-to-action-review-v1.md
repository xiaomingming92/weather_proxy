# farm-agent-analysis-to-action-review-v1

## Review 元信息

- **Review 对象**: [farm-agent-analysis-to-action-plan-v1.md](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-07/01/farm-agent-analysis-to-action-plan-v1.md)
- **Review 时间**: 2026-07-01
- **Review 类型**: 架构决策 + 方案选型
- **前置阅读**:
  - `farm-agent-domain-vocabulary-plan-v2.md`（触发词 v2 + 3-Tier 路由）
  - `farm-agent-project-context-activation-plan-v1.md`（项目上下文激活）
  - `personnel-management-plan-v1.md`（人员管理与智能派发）
  - `farm-agent-nongqing-report-api-plan-v1.md`（农情报告 API）
  - `src/app/api/h5/nongqing/daily-report/route.ts`（日报现有实现）
  - `src/agents/experts/registry.ts`（专家注册表）
  - `prisma/nongqing.prisma`（农情域 Schema）

---

## 1. 问题复现

为什么需要这次评审？

本 Plan 试图解决 farm-agent 最核心的结构性断裂：**分析管线与执行管线完全分离**。14 个专家只能"说"不能"做"——产出文本报告但无法写入业务数据。这是一个跨模块的架构变更，涉及专家接口扩展、Agent 工具新增、图拓扑后处理、LLM 分析激活、Schema 变更五个维度，方向错误代价极高，必须在编码前验证。

---

## 2. 方案对比

### 2.1 专家输出→动作桥接方式

Plan 选用了方案 B（outputActions 配置声明 + reasoning 后处理），对比：

| 维度 | A: prompt 内调工具 | **B: outputActions + 后处理** ✅ | C: 独立 action 节点 |
|------|-------------------|-------------------------------|-------------------|
| 侵入性 | 中（改 prompt） | **低（改配置 + 后处理）** | 高（改图拓扑） |
| 关注点分离 | ❌ 分析推理与工具调用耦合 | ✅ 专家声明能力，框架执行 | ✅ 完全独立 |
| 可测试性 | ❌ 依赖 LLM 正确输出 tool_call | ✅ 后处理逻辑可单测 | ✅ 可单测 |
| 扩展性 | ❌ 每个专家 prompt 都要改 | ✅ 配置声明即可 | ✅ 配置声明即可 |
| 风险 | 低 | **中** | 高（影响所有专家） |

**决策**：B 方案合理。在现有图拓扑上最小侵入，且后处理逻辑可独立测试。

**但有一个隐患**：方案 C 虽然当前风险高，但长期看是更干净的架构。Plan 应明确标注 B→C 的演进路径，避免后处理逻辑膨胀后被迫重构。

### 2.2 日报 LLM 分析激活方式

Plan 选用了方案 C（抽取 LLM 分析函数，不走完整 Agent 图），对比：

| 维度 | A: route.ts 内调 LLM | B: 走 Agent 管线 | **C: 抽取分析函数** ✅ |
|------|---------------------|-----------------|---------------------|
| 架构复杂度 | 低 | 高（循环调用风险） | **中** |
| 复用专家能力 | ❌ | ✅ | 🔶 复用 prompt 模板，不走图 |
| 工具调用 | ❌ 需手动实现 | ✅ 自动走工具链 | ⚠️ 需手动聚合数据 |

**决策**：C 方案务实。但需要明确"复用 prompt 模板"的具体机制——当前专家 prompt 在 `src/agents/prompts/experts/` 下，是面向 Agent 图上下文设计的（包含 evidenceChain、activeExperts 等变量），直接抽取给独立函数用需要适配。

---

## 3. 决策结论

**总体方向正确，5 个问题需要在进入 Spec 前解决。**

### P0 问题（阻塞 Spec）

#### 3.1 reasoning 输出→处方参数的映射机制未定义

Plan 中 `mapReasoningToPrescription()` 是一个黑盒。核心难点：

- LLM 输出的 `conclusion` 是自由文本（"建议立即喷施吡虫啉防治蚜虫"），但 `AlertPrescription.name` 需要结构化字符串（"蚜虫预警防治"）
- `action_steps` section 的格式未标准化——不同专家的 action_steps 结构可能不同
- `triggerReason` 需要从 evidence 中提取，但 evidence 是多条证据的数组

**建议**：Spec 中必须定义 `ExpertOutputAction.paramMapping` 的完整映射规则，或者改为让 LLM 在 reasoning 阶段直接输出结构化的 action payload（在专家 prompt 中增加 action_output 格式约束）。后者更可靠但增加 prompt 复杂度。

#### 3.2 区块 1 与区块 4 的处方创建逻辑重复

- 区块 1 新建 `nongqing-action.ts` 服务层封装 `createPrescription()`
- 区块 4 的 `daily-report/route.ts` L184-212 已有处方创建逻辑（直接调 `prisma.alertPrescription.create`）

两条路径写同一张表，审计策略不同（Agent 工具走 Layer 2 AuditLog，日报走 agentAudit）。

**建议**：区块 4 的处方创建逻辑应重构为调用区块 1 的 `nongqing-action.ts` 服务层，统一审计通道。Plan 应明确标注这个重构。

#### 3.3 日报分析函数的工具调用问题

`daily-report-analyzer.ts` 需要聚合 24h 四情数据（weather/soil/insect），Plan 说"复用已有工具"。但这些工具（`query_farm_weather` 等）是 LangChain Tool 定义，绑定在 Agent 图的工具链中。独立函数无法直接调用 LangChain Tool。

**建议**：两条路——
1. 抽取工具的核心查询逻辑为纯函数（`fetchFarmWeather(projectId)`），Tool 和 analyzer 都调用纯函数
2. analyzer 内直接用 `farm-server-client.ts` 查询，不走 Tool 层

Plan 应明确选择哪条路。

### P1 问题（Spec 中解决）

#### 3.4 outputActions 的触发时机与用户确认

当前设计：reasoning 完成后自动创建处方（status=pending）。用户可能在对话中说"帮我看看虫害情况"，并不期望自动创建处方。

**问题**：自动创建的边界在哪？
- 所有 pest_risk 分析都自动创建处方？还是仅当置信度 > 阈值时？
- 用户是否需要一个确认步骤（"检测到虫害风险，是否创建防治处方？"）

**建议**：`confidenceThreshold` 是必要的门控，但还应考虑交互点机制——当专家配置了 outputActions 且置信度在"建议确认"区间时，触发交互点让用户确认，而非静默创建。

#### 3.5 B→C 演进路径缺失

Plan 选了方案 B（后处理），但没提方案 C（独立 action 节点）的演进路径。如果 outputActions 的专家从 3 个扩展到 10 个，后处理逻辑会膨胀。

**建议**：Plan 中增加一段"演进策略"：当 outputActions 专家数 > 5 时，评估迁移到方案 C（独立 action 节点）。

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 操作 | 风险 |
|------|------|------|
| `src/agents/experts/registry.ts` | 修改接口 | 中——所有专家 config 需兼容新字段（optional 缓解） |
| `src/agents/tools/index.ts` | 注册新工具 | 低 |
| `src/agents/agent-graph.ts` 或 `reasoning.ts` | 新增后处理 | **高**——核心图逻辑变更 |
| `src/app/api/h5/nongqing/daily-report/route.ts` | 替换硬编码为 LLM | 中——日报 API 行为变化 |
| `prisma/nongqing.prisma` | 新增字段 | 低——nullable 不影响现有 |
| `src/services/nongqing-action.ts` | 新建 | 低 |
| `src/services/daily-report-analyzer.ts` | 新建 | 中——LLM 输出质量不确定 |

### 4.2 数据流影响

```
变更前:
  reasoning → verdict → response（纯文本）

变更后:
  reasoning → outputAction 检测 → [工具调用写入 DB] → verdict → response（文本 + 结构化动作结果）
```

verdict 节点需要感知 outputAction 的执行结果（成功/失败），以便在 response 中呈现。这要求 verdict 的输入增加 `actionResults` 字段。

**Plan 未提及 verdict 节点的适配。**

### 4.3 回滚风险

| 区块 | 回滚难度 | 说明 |
|------|---------|------|
| 区块 1（工具层） | 低 | 删除新文件 + 取消注册 |
| 区块 2（接口扩展） | 低 | outputActions 是 optional，移除不影响现有 |
| 区块 3（后处理） | 中 | 图逻辑变更，需回归测试所有专家 |
| 区块 4（日报 LLM） | **中** | 日报从硬编码变为 LLM，行为不可预测，需保留 fallback |
| 区块 5（Schema） | 低 | nullable 字段，删除 migration 即可 |

**建议**：区块 4 应保留硬编码 fallback——当 LLM 分析超时或失败时，降级为返回 `status: "normal"` 的 demo 数据，确保日报 API 不中断。

---

## 5. 补充建议

### 5.1 缺少幂等性保障

处方创建的去重逻辑（`findFirst` by projectId + sourceReportDate + name）依赖 `name` 精确匹配。如果 LLM 两次分析产出略有不同的 name（"蚜虫防治" vs "蚜虫预警防治"），去重失效。

**建议**：去重键应使用更稳定的标识（如 projectId + triggerType + sourceReportDate），而非 name。

### 5.2 缺少成本估算

区块 4 引入日报 LLM 分析，每次日报多一次 LLM 调用。Plan 风险矩阵中写了"成本可控"，但应量化：
- 日报调用频率：1-2 次/天/项目
- 单次 LLM 调用成本：~$0.005（gpt-4o-mini）或 ~$0.03（gpt-4o）
- 100 个项目月成本：$15-$90

### 5.3 区块执行顺序调整建议

Plan 当前顺序：1→2→3→4→5

建议调整为：1→4→2→3→5

理由：
- 区块 4（日报 LLM 激活）不依赖区块 2（outputActions），可先独立交付
- 区块 4 激活后，日报处方链路立即生效，快速验证 `nongqing-action.ts` 服务层
- 区块 2+3 是更复杂的图拓扑变更，放在服务层验证稳定后再做

---

## 6. Review 结论

| 维度 | 评分 | 说明 |
|------|------|------|
| 方向正确性 | ✅ 通过 | 分析→生成的闭包是系统演化的正确方向 |
| 方案选型 | ✅ 通过 | B 方案最小侵入，C 方案抽取分析函数务实 |
| 完整性 | 🔶 需补齐 | 3.1 映射机制、3.2 逻辑重复、3.3 工具调用 需明确 |
| 风险评估 | ✅ 充分 | 风险矩阵覆盖主要场景 |
| 依赖管理 | ✅ 清晰 | 前置 Plan 和依赖关系图完整 |
| 回滚策略 | 🔶 需补齐 | 区块 4 需保留 fallback |

**结论**：方向通过，解决 3 个 P0 问题后可进入 Spec。

---

## 7. 回流状态（2026-07-02）

| # | 问题 | 优先级 | 回流状态 | 回流位置 |
|---|------|--------|---------|---------|
| 3.1 | reasoning→处方映射机制 | P0 | ✅ 已回流 | §3.2 + 区块 2 ExpertOutputAction 重写 + 映射机制说明 |
| 3.2 | 区块 1/4 处方创建逻辑重复 | P0 | ✅ 已回流 | 区块 4 处方自动创建（重构）+ 去重键修正 |
| 3.3 | 日报分析函数工具调用 | P0 | ✅ 已回流 | 区块 4 daily-report-analyzer.ts 改用 farm-server-client + 超时降级 |
| 3.4 | 自动创建边界 | P1 | ✅ 已回流 | 区块 3 自动创建边界与用户确认（三级策略） |
| 3.5 | B→C 演进路径 | P1 | ✅ 已回流 | §2.1 B→C 演进策略 |
| 额外 | 执行顺序调整 | — | ✅ 已回流 | §四 执行顺序 1→4→2→3→5 |
| 额外 | verdict 节点适配 | — | ✅ 已回流 | 区块 3 关键约束 + §3.2 |
| 额外 | 去重键修正 | — | ✅ 已回流 | 区块 4 去重键修正 |
