# PLAN: code-review-suggestions 修复 v1

## 元信息

- **Plan 名称**: code-review-fix
- **版本**: v1
- **创建日期**: 2026-06-29
- **触发源**: `code-review-suggestions.md`（15 项代码审查建议）
- **ADD 范式**: 9 阶段（Step 0-8）

## 变更概述

修复 `code-review-suggestions.md` 中列出的 15 项代码质量问题，按优先级分为三类：

| 优先级 | 数量 | 说明 |
|--------|------|------|
| 🔴 P0 | 5 | 安全风险 / 死代码 / 数据暴露 |
| 🟡 P1 | 6 | 代码质量 / 可维护性 |
| 🟢 P2 | 4 | 优化建议 |

## 变更范围

### P0 — 立即修复

| # | 问题 | 文件 | 修复方式 |
|---|------|------|---------|
| 1 | 重复 LLM 模块 | 删除 `src/lib/llm.ts` | 删除死代码 |
| 6 | JWT 硬编码默认密钥 | `src/lib/auth.ts` | 生产环境强制要求配置 | .env.production
| 11 | Chroma 端口未绑定 localhost | `docker-compose.yml` | 绑定 `127.0.0.1` |
| 13 | 双 lock 文件 | 删除 `package-lock.json` | 统一使用 pnpm |
| 15 | Prisma 多文件路径不一致 | `prisma/schema.prisma` | 修正注释 |

### P1 — 本次修复

| # | 问题 | 文件 | 修复方式 |
|---|------|------|---------|
| 2 | LLM 单例竞态条件 | `src/lib/llm/index.ts` | 请求级 LLM 实例 |
| 5 | 审计日志静默吞错 | `src/lib/agent-audit-logger.ts` | 增加失败计数 |
| 7 | activeTracers 内存泄漏 | `src/agents/index.ts` | TTL 过期清理 |
| 8 | 缺少请求体校验 | `src/app/api/agent/chat/route.ts` | Zod schema |
| 12 | Docker 资源限制被注释 | `docker-compose.yml` | 启用 resource limits |
| 14 | Model config 动态 require() | `src/lib/llm/index.ts` | 静态 import |

### P2 — 后续优化

| # | 问题 | 说明 |
|---|------|------|
| 3 | 大量 `as any` | 需要逐步用类型守卫替代，本次不处理 |
| 4 | QWeather JWT 占位符 | 待 co-agent 迁移时处理 |
| 9 | 脚本目录过于庞大 | 归档一次性脚本，本次不处理 |
| 10 | 大文件职责混杂 | 需拆分 `src/agents/index.ts`，本次不处理 |

## 原子闭包三可性判定

| 维度 | 判定 |
|------|------|
| 可独立提交 | ✅ 15 项修复各自独立，可分批提交 |
| 可独立验证 | ✅ 每项修复有明确验证方式（tsc / lint / 手动检查） |
| 可独立审计 | ✅ 每项修复涉及文件明确，Git diff 可追溯 |
| 可独立恢复 | ✅ 每项修复可通过 `git revert` 独立回滚 |

## Phase 规划

| Step | Phase | 说明 |
|------|-------|------|
| Step 0 | — | 文档先行 |
| Step 1 | `code_review_fix_analysis` | 功能分析 |
| Step 2 | `code_review_fix_audit_infra` | 审计基础设施 |
| Step 3 | `code_review_fix_impl` | 业务逻辑实现 |
| Step 4 | `code_review_fix_audit_verify` | 审计验证 |
| Step 8 | `code_review_fix_converge` | 收敛判断 |