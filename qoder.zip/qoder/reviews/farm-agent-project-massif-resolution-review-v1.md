# farm-agent-project-massif-resolution-review-v1

## Review 元信息

- **Review 对象**: Plan `.qoder/plans/2026-07/06/farm-agent-project-massif-resolution-plan-v1.md` + Specs `.qoder/specs/farm-agent-project-massif-resolution/`
- **Review 时间**: 2026-07-06
- **Review 类型**: 方案选型 + 合规检查
- **前置阅读**: `farm-agent-thinking-level-runtime-fix-plan-v1`（前置依赖）

---

## 1. 问题复现

`farm-agent-thinking-level-runtime-fix-plan-v1` 为 SkillCard 引入了 `massifIds` 字段，但"全农场"模式下（massifIds = undefined），LLM 调 `query_insect_data` 等工具时缺 massifId → 永远触发 `param_missing`。这与"全农场"语义矛盾——用户点"周报分析"本意是分析整个项目的数据，不应弹出地块选择器。

根因：`activedProjectId` 已在 handshake 时注入，但没有代码做 `projectId → massifIds[]` 自动解析。

---

## 2. 方案对比

### 2.1 方案 A：route 层无条件自动解析（本 Plan 采用，Review 后扩大范围）

在 `chat/stream/route.ts` 中，调用 `streamAgent` 前**无条件**调 `resolveProjectMassifIds()`——不等意图节点判断路径，而是作为系统级默认值提前注入。成功则 `prebuiltMassifIds` 有值，失败/null 则保持 null（回退到 param_missing）。

**范围**：覆盖全路径——卡片点击（explicitIntent）+ 自由打字（LLM 意图解析）。

**param_missing 定位**：最后防线，不是第一反应。优先级链：用户已选地块 > 系统默认值（本 Plan）> LLM query_massif 精确解析 > param_missing 选择器。

**优点**：
- 改动集中在 route 入口层 + farm-api 层，不侵入 Agent 内部逻辑
- `resolveToolParams` 只需在 `available()` 中加一个条件，改动最小
- `param_missing` 回退路径完整保留（4 种场景）
- 覆盖全路径：卡片点击 + 自然对话均受益
- 与 LLM 的 `query_massif` 工具互补：系统默认全农场 + LLM 可精确解析地名

**缺点**：
- 每次 chat 请求都调一次 Farm-Server API（但此 API 返回地块列表，数据量小，延迟可接受）
- 自然对话路径下 prebuiltMassifIds 是全项目默认值，如果用户后续调 `query_massif` 精确到某地块，两种数据源并存——需依赖 resolveToolParams 正确选择（本 Plan 的 available() 扩展已覆盖）

### 2.2 方案 B：intentionNode 内自动解析（被淘汰）

在 `intention.ts` 的 LLM 路径中，每次意图解析完后调 `resolveProjectMassifIds` 填充。

**淘汰理由**：
- 每次 LLM 调用都额外调 Farm-Server API，增加延迟
- LLM 路径的 subIntents 是 LLM 自由产出的，与"全农场"语义无绑定关系
- 与 Plan 的"先覆盖卡片路径"目标不一致

### 2.3 方案 C：LLM 工具调用时自动补全（被淘汰）

在 `resolveToolParams` 检测缺参时主动调 Farm-Server 补全。

**淘汰理由**：
- 破坏裁决层职责单一性（它只负责"判有没有参数"，不应负责"去拿参数"）
- 异步调用在裁决层引入延迟
- 不提前解析，工具调用时才做 → 工具可能在多个 expert 间共享，解析结果不好传递

### 2.4 方案 B+C 淘汰后，扩大至自然对话的决策

初始 Plan 仅覆盖 explicitIntent 路径。Review 讨论中发现：
- 农业软件行业共识：模糊语义（不提具体地块）= 默认"我的项目/农场"
- 用户不可能知道内部 massifId——"地块A虫情"的解析应靠 LLM 调 `query_massif` 工具，而非让用户在 param_missing 里选
- param_missing 定位错误：应该是最后防线，而非"没手动选就弹"

因此 Route 层解析从条件触发改为无条件触发，覆盖全部路径。

---

## 3. 决策结论

✅ **接受方案 A**。

Plan 的 3 轮原子事务拆分合理：
- 第1轮（farm-api + context）：纯数据源层，无副作用
- 第2轮（state + route + intention）：消费端串联，依赖第1轮产出的类型和函数
- 第3轮（resolve-tool-params + 验证）：裁决层补位，改动 3 行

所有轮次文件边界独立，互不跨轮修改。每个轮次可独立 `tsc + eslint` 验证。

---

## 4. 影响评估

### 4.1 受影响文件（7 个）

| 文件 | 改动量 | 风险 |
|------|:--:|:--:|
| `src/lib/farm-api/massif.ts` | +15 行 | 低（新增函数，不影响已有调用） |
| `src/lib/farm-project-context.ts` | +25 行 | 低（新增函数，已有 API 不变） |
| `src/agents/state.ts` | +3 行 | 低（新增 Annotation） |
| `src/agents/agent-runner.ts` | +3 行 | 低（新增可选字段） |
| `src/app/api/agent/chat/stream/route.ts` | +15 行 | 中（新增 await 调用，需处理 try/catch） |
| `src/agents/nodes/intention.ts` | +8 行 | 低（explicitIntent 分支内新增条件检查） |
| `src/caijuehub/strategies/resolve-tool-params.ts` | +3 行 | 低（仅扩展 available() 条件） |

### 4.2 API 签名/函数接口影响

| 新增函数 | 签名 | 返回类型 |
|------|------|------|
| `massif.ts: getAllByProjectId` | `(projectId: number) => Promise<FarmApiResponse<MassifDTO[]>>` | `{ code: number, data: MassifDTO[] }` |
| `farm-project-context.ts: resolveProjectMassifIds` | `() => Promise<number[] \| null>` | `number[]` 或 `null` |
| `state.ts: prebuiltMassifIds` | `Annotation<number[] \| null>()` | LangGraph Annotation |

- 无破坏性 API 变更（全为新增）
- `resolveToolParams.available()` 签名不变（仅内部条件扩展）

### 4.3 存储/索引成本

**零新增存储成本**。本次变更不创建新数据库表、不新增索引、不引入新持久化层。数据流为：Farm-Server API → 内存（prebuiltMassifIds）→ Agent State → 工具调用透传。无缓存设计（P2 建议未来可选）。

### 4.4 数据流影响

```
Handshake → activedProjectId=1001
  → route.ts: resolveProjectMassifIds() → GET /farm/massif/options?projectId=1001
    → state.prebuiltMassifIds = [1,2,3,...,N]
      → intention.ts: 跳过解析
        → deep/professional 图: 工具调用不缺参 → 不触发 param_missing
```

不改变 Handshake 协议、SkillCard 结构、deep/professional 图内部逻辑。

### 4.5 回滚风险

**低风险**。`resolveProjectMassifIds` 返回 null 时回退到 param_missing——与修复前行为完全一致。新增的 `prebuiltMassifIds` 字段是可选的，不影响现有数据流。

### 4.6 建议修正优先级

**P0**：无。

**P1**：`route.ts` 中 `resolveProjectMassifIds` 调用需加 try/catch 包裹，避免 Farm-Server 异常导致整个 chat 请求失败——Plan 已有明确回退路径（§2.2），Spec 中有对应 Scenario。

**P2**：
- `farm-project-context.ts` 的 token 获取需确认 `getFarmToken()` 在 route 上下文中可用。当前 `farm-data-tools.ts` 已使用相同模式，无风险。
- 未来可考虑缓存 `resolveProjectMassifIds` 结果（同一 session 内项目地块列表不变），降低重复 Farm-Server 调用。

---

## 5. 最终建议

Plan + Specs 方向正确，3 轮原子事务拆分合理，回退路径完备。建议：

1. P1：确保 `route.ts` 中 `resolveProjectMassifIds` 调用在 try/catch 内，失败时 `prebuiltMassifIds` 保持 null（当前 Plan §2.2 回退表已覆盖此场景）
2. 通过 DPS 闸门后进入 Step 1 实施
