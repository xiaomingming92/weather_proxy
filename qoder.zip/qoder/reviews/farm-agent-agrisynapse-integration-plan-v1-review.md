# Review: farm-agent-agrisynapse-integration-plan-v1

> 审核时间: 2026-06-08
> 审核人: User (人工审核)
> Plan 文件: `.qoder/plans/farm-agent-agrisynapse-integration-plan-v1.md`

## 审核意见

### ❌ 缺失 1: Farm-Server Token 刷新机制未体现

Plan 2.6 节描述了双层认证拓扑，但仅覆盖了稳态流程（token 有效时）。**未描述 Farm-Server token 过期后的自动刷新链路**，而 farm-agent 已完整实现该逻辑：

```
ensureValidToken(userId, "agrisynapse")
  │
  ├─ getValidToken(userId)  ← credential-store 查询 + 过期检查
  │   └─ token 有效 → 返回 accessToken ✓
  │
  ├─ token 过期 → tryRefreshToken(userId)
  │   └─ POST Farm-Server /system/auth/refresh-token?refreshToken=...
  │       ├─ 成功 → updateRefreshedToken() 更新 DB → 返回新 accessToken ✓
  │       └─ 失败 → deleteToken() + 返回 null
  │
  └─ refresh 失败 (source="agrisynapse")
      └─ 返回 null → farm-token-context.getFarmToken() → null
          → Farm-Server 工具调用时收到 null → 需降级处理
```

**建议**: 在 2.6 节补充 Token 生命周期子节，描述过期→刷新→最终失效的完整链路。

### ❌ 缺失 2: Farm-Server Token 最终失效时 agrisynapse 的感知路径

当 refresh 也失败（TokenExpiredError），farm-agent token provider 返回 null。但 plan 未定义：
- farm-agent 如何通知 agrisynapse "Farm-Server 凭据已失效"？
- 是通过 SSE 事件（如 `error` 事件）？HTTP 状态码？还是静默降级？
- agrisynapse 收到通知后的 UI 行为（弹窗提示？跳转农场接入设置页？）

**建议**: 明确定义 Farm-Server token 失效的通信协议和前端处理策略。

### ⚠️ 缺失 3: 2.3 对接流程图中 handshake 参数与实际代码不一致

第 71 行仍然写 `{ type: "handshake", accessToken, refreshToken, userVO }`，与 2.6 节修正后的结论矛盾（handshake 不传 Farm-Server 凭据）。

**建议**: 修正 2.3 流程图中的 handshake 请求体为 `{ type: "handshake", userVO }`。

### ⚠️ 建议补充: credential-store 加密存储说明

2.6 节拓扑图中标注了 `cred-store (AES-256-GCM)`，但未说明加密密钥来源（`CREDENTIAL_ENCRYPTION_KEY` 环境变量）和 token 存储位置（`FarmServerCredential` 表，per-user 加密入库）。这对理解 L2 安全边界有关键意义。

### ⚠️ 缺失 4: 2.7 节未区分 Token 刷新路径与业务请求路径

2.7 节流程图把 token 刷新和业务数据查询画成一条路径，但实际是两条分离的链路：
- **Token 刷新**：`token-manager.ts` 直接用 `fetch()` 调 Farm-Server `/refresh-token`，不走 `farm-server-client`
- **业务查询**：Agent tools → `farm-server-client.ts` → `farm-token-context` → Farm-Server

分离原因：`farm-token-context` 依赖 `ensureValidToken` 提供有效 token，若刷新也走 `farm-server-client` 会形成循环依赖。

**建议**：2.7 节补充说明两条路径的分离关系和设计理由。

## 审核结论

- [] 补充 Token 刷新生命周期（缺失 1）
- [] 补充 Farm-Server token 失效的感知与处理路径（缺失 2）
- [] 修正 2.3 流程图 handshake 参数（缺失 3）
- [] 可选：补充 credential-store 加密细节
- [] 2.7 节区分 Token 刷新路径与业务请求路径（缺失 4）

**审核状态: 待审核**
