# farm-agent-多轮对话能力专家链路优化统一状态管理 — Runtime 纠正 Review

## Review 元信息

- **Review 对象**: `.qoder/plans/2026-05/28/farm-agent-多轮对话能力专家链路优化统一状态管理-plan-v1.md`
- **Review 类型**: Runtime 纠正（ADD-12 双源漂移检测——Plan 与底层机制认知不一致）
- **Review 时间**: 2026-06-26
- **触发来源**: [checkpointer-postgres-migration-plan](file:///home/xmm/ai/farm-agent/.qoder/plans/2026-06/26/checkpointer-postgres-migration-plan.md) 执行过程中发现认知缺口
- **前置阅读**:
  - 本 Plan: `farm-agent-多轮对话能力专家链路优化统一状态管理-plan-v1.md`（2310 行）
  - checkpointer Plan: `.qoder/plans/2026-06/26/checkpointer-postgres-migration-plan.md`
  - checkpointer Spec: `.qoder/specs/checkpointer-postgres-migration/spec.md`
- **结论级别**: 需修正后回流（6 个 P0/P1 缺口）

---

## 1. 问题复现

### 触发链

1. 执行 `checkpointer-postgres-migration` Plan 时，确认 LangGraph checkpointer 的全局作用：**每次 graph 节点执行后自动保存 `AgentState`，同一 `thread_id` 的后续调用从 checkpointer 加载历史状态**。这不仅服务于 interrupt/resume，更是所有多轮对话持久化的基础。
2. 回查本 Plan（"多轮对话能力专家链路优化统一状态管理"，2310 行），发现该 Plan **全文未提及 `checkpointer`、`MemorySaver`、`checkpoint`、`LangGraph 状态持久化`**。
3. 进一步发现：本 Plan 定义了一套独立的跨轮记忆机制（`AnalysisContext` → `ChatThread.metadata`），与 LangGraph checkpointer 的 `AgentState` 持久化形成**双重状态管理层**，两者关系完全未界定。

### 核心矛盾

```
LangGraph checkpointer（已有）          Plan 的 AnalysisContext（本Plan新增）
─────────────────────────────          ─────────────────────────────
自动保存 AgentState                    手动 saveAnalysisContext()
  ├── messages（消息历史）               ├── activeExperts
  ├── evidenceChain                     ├── runtimeInputs
  ├── verdictResult                     ├── turnHistory
  └── conversationContext               └── totalTurns
       ↓                                      ↓
PostgreSQL langgraph_checkpoints        ChatThread.metadata (Prisma Json)
```

两个层面对应同一个 `thread_id`，存的是部分重叠的状态，但完全不知道对方的存在。

---

## 2. 正向评价（Plan 中与 checkpointer 一致的判断）

1. **第 8 轮"Global State Model"的方向正确**：统一 chat/agent/memory/tool/policy/audit/feedback state 是必要的架构演进
2. **`AnalysisContext.threadId` 的设计正确**：以 thread 为粒度管理跨轮状态
3. **持久化到 DB 的判断正确**：`ChatThread.metadata`（Prisma Json）确实能跨进程存活——Plan 意识到了"不能只靠内存"，只是没意识到 LangGraph 已有 checkpointer 在做同样的事

---

## 3. 问题清单

### P0-1: §0.1 缺陷 #4「无对话记忆」诊断错误

- **当前文字**（第 46 行）: `4. 无对话记忆：每轮对话独立，无法识别追问、无法累积用户选择的分析维度`
- **问题**: 这个诊断混淆了"功能缺失"和"基础设施问题"。LangGraph checkpointer **已经提供了对话记忆**——同一 `thread_id` 的多次 `invoke/stream` 会自动从 checkpointer 加载 `AgentState`（包括 `messages`）。真正的问题不是"无对话记忆"，而是当前 `MemorySaver` 在进程重启后丢失状态。
- **影响**: 下游 AI 读到此缺陷描述，会误以为需要从头实现对话记忆功能，而非修复底层 checkpointer 持久化
- **修正方向**: 改为 "checkpointer 未持久化：MemorySaver（进程内存）在 PM2 重启后丢失所有 thread 状态"，并引用 `checkpointer-postgres-migration-plan.md`

### P0-2: §4.3 AnalysisContext 与 checkpointer 双重状态管理未界定

- **当前文字**（第 741-782 行）: 定义 `AnalysisContext` 数据结构 + `saveAnalysisContext/getAnalysisContext` 持久化到 `ChatThread.metadata`
- **问题**: 
  - `AnalysisContext` 存的 `activeExperts`、`runtimeInputs` 与 LangGraph checkpointer 自动保存的 `AgentState` 对应同一个 thread
  - `activeExperts` 被 retrieval 节点消费（过滤 evidence），`runtimeInputs` 被 reasoning 节点消费（prompt 注入）→ 这两个字段应该在 AgentState 中由 checkpointer 统一管理
  - `turnHistory`、`totalTurns` 是执行后诊断数据，不被 graph 节点消费 → 可留在 ChatThread.metadata
- **影响**: 两套状态管理并行运行，graph 消费字段在 checkpointer 之外 → 时序不一致 → 状态分裂
- **最终结论**（2026-06-26 讨论确认）:

  **模式 B' — 混合分层：以"是否被 graph 节点消费"为判定标准**

  ```
  AgentState + checkpointer (执行态)     AnalysisContext + ChatThread.metadata (观测态)
  ────────────────────────────────       ─────────────────────────────────────────
  messages          （已有，reasoning消费）   turnHistory       （诊断记录，无节点消费）
  evidenceChain     （已有，reasoning消费）   totalTurns        （统计，无节点消费）
  verdictResult     （已有，response消费）
  activeExperts     （★应迁入，retrieval消费）
  runtimeInputs     （★应迁入，reasoning消费）
  ```

  **两者通过 `thread_id` 关联，但不需要互相查询。**

  **Agent OS 恢复策略**（类比 Linux 从磁盘重建而非休眠恢复）：
  - checkpointer（PostgreSQL）→ graph 状态无损恢复
  - ChatThread.metadata → 分析上下文无损恢复
  - GlobalStateProvider → 每次请求从零重建（运行时投影）
  - dispatch_journal → 未完成的调度令可恢复（先写盘再执行副作用）
  - scheduled_tasks（DB 轮询，不用 setTimeout）→ 错过的定时任务可补发

### P0-3: §0.8 第 8 轮「Global State Model」未提及 checkpointer 作为底层持久化引擎

- **当前文字**（第 150-168 行）: 描述 Global State Model 统一 6 类 state，建立 single source of truth
- **问题**: 未提及这个统一状态模型的**底层持久化机制**应该是什么。checkpointer（迁移到 PostgreSQL 后）正是天然的候选——它已经在每个节点执行后自动保存 `AgentState`，如果 Global State Model 的其他 state（memory/tool/policy/audit/feedback）也纳入 `AgentState` 或其扩展，checkpointer 自动承担持久化职责
- **影响**: 第 8 轮实施时可能再造一套持久化方案，与 checkpointer 形成第三层状态管理
- **修正方向**: 明确声明 Global State Model 应基于 LangGraph checkpointer（PostgreSQL）作为统一持久化层，`AgentState` 作为 unified state 的载体

### P1-1: §0.7 第 3 轮「AnalysisContext 持久化」与 checkpointer 关系未声明

- **当前文字**（第 141 行）: `第3轮 | 领域上下文闭包 | ExpertRegistry + AnalysisContext 持久化`
- **问题**: "持久化"的语义在本轮是指通过 Prisma 写 `ChatThread.metadata`，但没有声明这层持久化与 LangGraph checkpointer 的自动持久化的关系
- **修正方向**: 补充说明"本轮的 AnalysisContext 持久化与 LangGraph checkpointer 的 AgentState 持久化是互补关系，前者存分析维度和运行时变量，后者存消息历史和 graph 状态；两者通过 thread_id 关联"

### P1-2: 验收标准（§8）缺少 checkpointer 持久化验证

- **当前状态**: §8.1-8.7 的 40+ 条验收标准无一条涉及 checkpointer 状态持久化
- **问题**: 多轮对话的核心基础设施——checkpointer——的持久化可靠性没有任何验收标准
- **修正方向**: 新增验收项：`pm2 restart farm-agent` 后同一 thread_id 的多轮对话上下文保持；`AgentState.messages` 和 `AnalysisContext.turnHistory` 的轮数一致

### P1-3: 缺少"副作用操作恢复"和"状态双重管理"风险

- **当前状态**: Plan 的风险分析分散在各 Step 的验收小节中，无集中风险清单
- **问题**: 
  1. `AgentState`（checkpointer 管理）和 `AnalysisContext`（手动管理）的双重状态管理——特别是 `activeExperts`/`runtimeInputs` 被 graph 节点消费但不在 AgentState 中——构成状态分裂风险
  2. 跨 Agent 调度令发送、定时任务触发等有副作用的操作，仅靠 checkpointer 恢复 graph 状态不够——对方 Agent 已经行动了，需要 journal 记录意图才能恢复
  3. Plan 未涉及 Agent OS 重启后的恢复策略
- **最终结论**（2026-06-26 讨论确认）:

  风险 1 缓解：`activeExperts`/`runtimeInputs` 迁入 AgentState → 由 checkpointer 统一管理

  风险 2 缓解：引入 dispatch_journal 表（先写盘再执行副作用）+ scheduled_tasks 表（DB 轮询，不用 setTimeout）

  风险 3 补充：Agent OS 恢复策略应明确——Agent OS 是 Linux 不是 Windows，不"休眠恢复"，"重启后从磁盘重建"；checkpointer 负责 graph 状态恢复，dispatch_journal 负责副作用恢复

---

## 4. 影响评估

### 4.1 对 checkpointer-postgres-migration 的影响

checkpointer 迁移到 PostgreSQL 后，Agent OS 的状态恢复能力大幅提升：

- **graph 状态（messages 等）**：checkpointer → PostgreSQL，重启无损 ✅
- **分析上下文（turnHistory 等）**：ChatThread.metadata → Prisma，重启无损 ✅
- **活跃专家/运行时输入**：应迁入 AgentState，由 checkpointer 统一管理
- **调度令副作用**：需新增 dispatch_journal 表（先写盘再执行）
- **定时任务**：需从 setTimeout 迁移至 DB 轮询

**短期（checkpointer 迁移 + AnalysisContext 不变）**: 两条线独立运行，graph 状态可靠持久化，分析上下文通过 ChatThread.metadata 持久化——不冲突
**中期（activeExperts/runtimeInputs 迁入 AgentState）**: graph 消费字段由 checkpointer 统一管理，时序一致
**长期（第 8 轮 Global State Model）**: checkpointer 成为 graph 状态的 canonical store，Global State Model 是跨 store 的统一访问层

### 4.2 受影响章节

| Plan 位置 | 当前内容 | 纠正类型 |
|-----------|---------|:--:|
| §0.1 缺陷 #4（第 46 行） | "无对话记忆" | 诊断修正 |
| §0.7 第 3 轮（第 141 行） | "AnalysisContext 持久化" | 补充声明 |
| §0.8 第 8 轮（第 150-168 行） | "Global State Model" | 架构补充（明确 checkpointer + dispatch_journal + scheduled_tasks） |
| §4.3（第 741-782 行） | AnalysisContext 定义 | 关系声明（模式 B'：消费者入 AgentState，观测者留 metadata） |
| §8 验收标准 | 40+ 条 | 新增 checkpointer 持久化 + 副作用恢复验证项 |
| 风险/恢复相关 | 缺失 | 新增 Agent OS 恢复策略 + 状态双重管理 + 副作用恢复风险 |

---

## 5. 建议修正优先级

| 优先级 | 编号 | 修正动作 |
|:--:|------|---------|
| P0 | P0-1 | §0.1 缺陷#4：修正"无对话记忆"为"checkpointer 未持久化"，引用 checkpointer-postgres-migration-plan |
| P0 | P0-2 | §4.3：声明 AnalysisContext 与 checkpointer AgentState 的关系 |
| P0 | P0-3 | §0.8：Global State Model 明确 checkpointer 为底层持久化引擎 |
| P1 | P1-1 | §0.7 第 3 轮：声明 AnalysisContext 持久化与 checkpointer 持久化的互补关系 |
| P1 | P1-2 | §8 验收标准：新增 checkpointer 持久化验证项 |
| P1 | P1-3 | 新增风险条目：状态双重管理风险 |

---

## 6. 最终建议

**推荐回流**。6 个缺口中，P0-2 和 P1-3 经讨论确认了具体方案：

- **模式 B'**：以"是否被 graph 节点消费"为判定标准，`activeExperts`/`runtimeInputs` 应迁入 AgentState 由 checkpointer 统一管理
- **Agent OS 恢复**：checkpointer 负责 graph 状态恢复，dispatch_journal 负责副作用恢复，scheduled_tasks（DB 轮询）负责定时任务恢复——类比 Linux 从磁盘重建

回流步骤：
1. ✅ 用户确认本 Review 结论
2. 按优先级逐项回流至 Plan（增量更新：保留原文 → 插入纠正段落 → 更新修订时间）
3. 回流后调用 `check_dps` 验证文档质量
4. 记录 ADD-7 审计
