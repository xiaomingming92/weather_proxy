# Context Assembly 声明式化 Plan Review

## Review 元信息

- **Review 对象**: `farm-agent-context-assembly-declarative-plan-v1.md`（attached_files）
- **Review 时间**: 2026-07-22
- **Review 类型**: 合规检查 + 事实核验 + 架构对齐
- **前置阅读**:
  - 路线图: `docs/Agent系统演进架构路线图-v1.md`
  - 源码: `src/agents/agent-runner.ts`（170 行）、`src/agents/state.ts`（212 行）
  - 节点: `reasoning.ts`、`response.ts`、`summary-reasoning.ts`、`intention.ts`、`coordination-dialogue.ts`

---

## 1. P0 阻断性问题

### P0-1: §2.2 硬编码位置表行号严重错乱

Plan §2.2 的硬编码清单将**所有位置都标注为 `agent-runner.ts`**，但实际行号与文件内容完全不符：

| Plan 声称 | 实际代码 | 问题 |
|----------|---------|------|
| `agent-runner.ts L86` — `prebuiltThinkingLevel: ThinkingLevel \| null` | L86 实际是 `prebuiltThinkingLevel?: string \| null`（`StreamAgentInput` 接口） | **类型错误**：Plan 写 `ThinkingLevel \| null`，实际是 `string \| null` |
| `agent-runner.ts L129` — `prebuiltMassifIds: number[] \| null` | L129 实际是 `for await (const chunk of stream)` | **行号错误**：`prebuiltMassifIds` 在 L93（`StreamAgentInput`），在 `state.ts` L135（`Annotation`） |
| `agent-runner.ts L202` — `expertPackages` Annotation | agent-runner.ts 总共只有 **170 行**，不存在 L202 | **文件混淆**：实际是 `state.ts` L149 |
| `agent-runner.ts L220` — `spatialRegions` Annotation | 同上，不存在 L220 | **文件混淆**：实际是 `state.ts` L161 |
| `agent-runner.ts L238` — `expertClaims` Annotation | 同上，不存在 L238 | **文件混淆**：实际是 `state.ts` L179 |
| `agent-runner.ts L301` — `toolResults` Annotation | 同上，不存在 L301 | **文件混淆**：实际是 `state.ts` L151 |

**根因**：Plan 把 `state.ts`（AgentState Annotation 定义）和 `agent-runner.ts`（Agent 入口 + StreamAgentInput）混为一谈，行号全部张冠李戴。

**影响**：如果按 Plan 的行号去改代码，会改到完全错误的位置。整个 §2.2 需要重写。

### P0-2: 真正的硬编码位置未被识别

Plan 假设所有硬编码上下文装配逻辑都在 `agent-runner.ts`，但实际上**硬编码散布在 6 个节点文件中**：

| 文件 | 行号 | 硬编码内容 | Plan 是否识别 |
|------|------|-----------|:---:|
| `reasoning.ts` | L130 | `state.toolResults ?? []` 直接读取 | ❌ |
| `reasoning.ts` | L204 | `state.expertPackages as ExpertReasoningPackage[]` 直接读取 | ❌ |
| `reasoning.ts` | L236 | 从 `state.messages` 按 realtimeToolNames 归集 | ❌ |
| `reasoning.ts` | L525 | `state.toolResults` 构建快速查找表 | ❌ |
| `response.ts` | L128 | `state.messages as Array<...>` 传给 `buildToolExecutionSummary` | ❌ |
| `response.ts` | L132 | `state.toolResults as Array<...>` 类型断言 | ❌ |
| `response.ts` | L146 | `state.managementZones` 直接读取 | ❌ |
| `response.ts` | L147 | `state.toolResults` 直接读取（isSummary 分支） | ❌ |
| `summary-reasoning.ts` | L61-63 | `state.spatialRegions` + `state.managementZones` + `state.toolResults` | ❌ |
| `summary-reasoning.ts` | L96 | `state.evidenceChain?.length` | ❌ |
| `intention.ts` | L105 | `state.messages` 遍历查找最后用户消息 | ❌ |
| `coordination-dialogue.ts` | L64 | `state.expertClaims` 直接读取 | ❌ |
| `spatial-preprocessing.ts` | L59-60 | `state.spatialRegions` + `state.toolResults` | ❌ |

**影响**：Plan 的改造范围只覆盖了 `agent-runner.ts` 的 Annotation 定义层，**完全遗漏了节点消费层的硬编码**。真正的 Context Assembly 改造需要重构这 6 个节点的 `state.*` 直接访问。

---

## 2. P1 重要问题

### P1-1: §2.2 `prebuiltThinkingLevel` 类型不一致

Plan §2.2 声称类型为 `ThinkingLevel | null`，但 `agent-runner.ts` L87 实际定义为 `string | null`：

```typescript
// agent-runner.ts L87（实际代码）
prebuiltThinkingLevel?: string | null

// state.ts L125（Annotation 定义）
prebuiltThinkingLevel: Annotation<ThinkingLevel | null>(),
```

两层类型不一致（`string` vs `ThinkingLevel`），Plan 未识别这个问题。Context Assembly 改造时应统一为 `ThinkingLevel | null`。

### P1-2: §3.3 依赖图与 §4.1 依赖关系表自相矛盾

§3.3 依赖图明确标注：

```
farm-agent-context-assembly-declarative-plan-v1
  │  无上游依赖
```

但 §4.1 依赖关系表又说：

```
本 Plan 的 Context Layer Provider 需要调用：
- tool-result-aggregator 的 aggregateToolResults()（由 spatial-reasoning-plan 轮次1 产出）
```

这两个描述矛盾。正确的依赖关系是：

```
farm-agent-spatial-reasoning-plan-v3（轮次1: tool-result-aggregator）
        │
        ▼
farm-agent-context-assembly-declarative-plan-v1（消费 aggregateToolResults）
```

建议修改 §3.3 依赖图为：

```
farm-agent-spatial-reasoning-plan-v3
        │  产出 aggregateToolResults（轮次1）
        ▼
farm-agent-context-assembly-declarative-plan-v1
        │
        ▼
farm-agent-prompt-engine-structured-output-plan-v1
```

### P1-3: 配置位置未明确——caijue.toml 还是新文件？

Plan §1.5 说：

> 通过声明式配置（如 caijue.toml 或独立的 context-assembly.toml）控制

但后续所有 Task 都引用 `resolveContextConfig()`，没有明确配置来源。需要决策：

| 方案 | 优势 | 劣势 |
|------|------|------|
| **复用 caijue.toml** | 统一治理入口，与现有 Policy Registry / Event Subscription 并列 | caijue.toml 已有 525 行，继续膨胀 |
| **新建 context-assembly.toml** | 职责单一，配置文件大小可控 | 多一个配置文件，治理入口分散 |

**建议**：复用 `caijue.toml`，新增 `[context-assembly]` 段。理由：
1. caijue.toml 的 `[[caijue]]` 表已有 `type = "context"` 裁决类型，Context Assembly 配置是自然延伸
2. `resolveContextConfig()` 可以从 `src/caijuehub/` 导出，与现有 `resolveToolResultFreshness()` 等策略函数同构
3. 岗位说明书中"技术治理文档"职责已明确包含 caijue.toml，不需要引入新文件

### P1-4: §2.4 数据流图不完整

Plan §2.4 的数据流图遗漏了**节点消费层**——这是当前硬编码最严重的地方：

```
Plan 当前数据流图（不完整）：
  API Route → agent-runner → StateGraph 节点 → LLM Prompt

应补充为：
  API Route → agent-runner → StateGraph 节点
                                    │
                          ┌─────────┼──────────┐
                          │         │          │
                    reasoning.ts  response.ts  summary-reasoning.ts
                    (state.toolResults    (state.messages     (state.spatialRegions
                     state.expertPackages  state.toolResults   state.managementZones
                     state.messages)       state.mgmtZones)    state.toolResults
                          │                │                   state.evidenceChain)
                          └─────────┬──────────┘
                                    │
                              LLM Prompt
```

### P1-5: §1.4 范围界定遗漏节点层改造

Plan §1.4 的范围界定表只覆盖了三类改造：

| Plan 列出 | 实际还需要 |
|----------|-----------|
| StreamAgentInput 预构建字段 | ❌ 节点层 `state.*` 直接访问的重构 |
| AgentState Annotation | ❌ `tool-result-aggregator` 集成到 Context Layer Provider |
| Context Layer Provider 模块 | ❌ `reasoning.ts` / `response.ts` / `summary-reasoning.ts` 等 6 个节点改造 |

**建议**：在 §1.4 表格中新增一行：

| 模块 | 本 Plan 是否涉及 | 说明 |
|------|:---:|------|
| 节点层 state.* 消费重构 | ✅ | 6 个节点的 `state.toolResults` / `state.messages` / `state.expertPackages` 等直接访问改为通过 `ContextAssemblyProvider` 获取 |

---

## 3. P2 建议优化

### P2-1: Task 4.4 节点改造顺序建议

Plan §4.4 说"逐步替换各节点中直接读取 `state.toolResults`、`state.messages` 的硬编码逻辑"，但没有指定顺序。建议按风险从低到高排序：

```
1. coordination-dialogue.ts（L64, 仅读 state.expertClaims，最简单）
2. intention.ts（L105, 仅读 state.messages，逻辑简单）
3. response.ts（L128-147, 读 state.messages + state.toolResults + state.managementZones）
4. reasoning.ts（L130+L204+L236+L525, 最多硬编码点，最复杂）
5. summary-reasoning.ts（L61-63+L96, 空间推理字段，需与 spatial-reasoning plan 对齐）
```

### P2-2: Task 4.3 应与 spatial-reasoning plan 的 tool-result-aggregator 对齐

Plan §4.3 的 `ContextLayerProvider.buildLayer()` 中 `toolSummary` 层需要调用 `aggregateToolResults()`。这个函数已经存在于 `src/agents/prompts/tool-result-aggregator/index.ts`（由 spatial-reasoning plan 产出），但 Plan 未提及复用。

**建议**：在 Task 4.3 中明确标注：

```
ContextLayerProvider.buildLayer("tool_summary", context) 内部调用：
  import { aggregateToolResults } from "@/agents/prompts/tool-result-aggregator"
  → 消费 state.toolResults + state.spatialRegions
  → 产出 AggregationResult（区域汇总/趋势/异常）
```

### P2-3: `resolveContextConfig()` 的裁决层归属

Plan 新增了 `resolveContextConfig()` 函数但未指定所属 caijuehub 策略模块。建议放入新文件 `src/caijuehub/strategies/context-assembly.ts`，与现有策略函数同构：

```
src/caijuehub/strategies/
  ├── thinking-level.ts         → resolveThinkingLevel()
  ├── response.ts               → resolveResponseStrategy()
  ├── toolResultFreshness.ts    → resolveToolResultFreshness()
  ├── awareness.ts              → resolveAwareness()
  └── context-assembly.ts       → resolveContextConfig()  ← 新增
```

---

## 4. 审计汇总

| # | 严重度 | 问题 | 位置 |
|---|:------:|------|------|
| F1 | **P0** | §2.2 硬编码位置表行号全部错乱，agent-runner.ts 仅 170 行，Plan 引用了 L202/L220/L238/L301 | §2.2 全表 |
| F2 | **P0** | 6 个节点文件的 `state.*` 直接访问（真正的硬编码）未被识别 | §2.2, §2.4 |
| F3 | **P1** | `prebuiltThinkingLevel` 类型：Plan 写 `ThinkingLevel`，实际是 `string` | §2.2 |
| F4 | **P1** | §3.3 依赖图标注"无上游依赖"，但 §4.1 承认依赖 spatial-reasoning 的 aggregateToolResults | §3.3, §4.1 |
| F5 | **P1** | 配置位置未决策（caijue.toml vs 新文件） | §1.5, §4.2, §4.3 |
| F6 | **P1** | §1.4 范围界定遗漏节点层 state.* 消费重构 | §1.4 |
| F7 | **P2** | 节点改造顺序未指定 | §4.4 |
| F8 | **P2** | 未提及复用 tool-result-aggregator 的 aggregateToolResults() | §4.3 |
| F9 | **P2** | resolveContextConfig() 的 caijuehub 策略模块归属未明确 | §4.2, §4.3 |

---

## 5. 结论

Plan 的核心设计思路正确——将硬编码上下文装配改为声明式配置+运行时解析，是 Agent 架构走向可扩展的关键一步。但 §2.2 的事实核验严重失准（行号全错 + 真正硬编码位置未识别），导致改造范围被低估。

**建议**：
1. **必须修复 F1-F2（P0）后才能进入实施**：重写 §2.2 硬编码清单，补充 6 个节点文件的真实硬编码位置
2. **修复 F3-F6（P1）后 Plan 可达到实施标准**：统一类型、修正依赖图、决策配置位置、补全范围界定
3. F7-F9（P2）可在实施阶段逐步解决
