# farm-agent-domain-vocabulary-review-v1

## Review 元信息
- Review 对象: `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-plan-v1.md` + `.qoder/specs/farm-agent-domain-vocabulary/`（三元组）
- Review 范围: 领域触发词汇注入 + Tool Context 类型修复 + 裁决层参数动态判断
- Review 时间: 2026-06-26
- 结论级别: 可接受（需补 Specs Requirements 后进入实施）

## 1. 总体结论
方向正确。领域触发词集中管理 + Tool Context category 分区渲染 + caijuehub 裁决层三层设计完整覆盖了"LLM 匹配专家 → 工具参数供应 → 参数缺失兜底"的全链路。Plan 经过 v1→v5 五轮迭代，架构设计充分审核。Specs Requirements 数量需扩展至与 Task 数量匹配。

## 2. 正向评价
- ✅ 方案选型清晰：A/B/C 三方案对比，选 A（集中文件）理由充分
- ✅ §3.5 五层管线设计完整：Tool Context → 裁决 → Zod → SSE，边界清楚
- ✅ Category 语义分类设计正确：`RuntimeInputCategory` 枚举型，用字段不用 key
- ✅ 词汇路径体系对称设计（devlog 回流）：`.qoder/vocabulary/`（IDE 侧 LLM + 治理 AI）↔ `src/agents/vocabulary/`（farm-agent 运行时用户 LLM），两条路径各自独立、互不污染
- ✅ 裁决层职责单一：不供应值、不校验、只做动态判断
- ✅ 文档辅助更新到位：架构说明书 + SSE 协议文档均已增量更新

## 3. 问题清单

| # | 严重程度 | 描述 | 修正建议 |
|---|:--:|------|---------|
| 1 | P1 | Specs Requirements 不足 | P0/P1-回流: Specs 已扩展至 8 个 Requirement |
| 2 | P1 | 数据模型变更无迁移策略 | P0/P1-回流: Plan §3.5.2 已注明无需 DB migration |
| 3 | **P2** | 裁决层规则表覆盖范围未量化 | Specs 中补充具体工具列表 |
| 4 | **P2** | 错误路径：裁决层失败时 fallback 到 Zod 原逻辑 | 裁决层返回 null 时走现有 tool_result error 流程 |
| 5 | **P2** | 兼容性：Record<string, RuntimeInputEntry> 与现有访问兼容 | RuntimeInputEntry 结构（value/label）不变 |
| 6 | **P2** | 存储：domain-triggers.ts 14 专家 ~2KB | 可忽略 |

## 4. 影响评估
- 修正前：Specs 不完整 → 下游 AI 注意力漂移 → 实现可能遗漏 Task
- 修正后：Specs 每个 Requirement 对应一个 Task Group → 实现有据可依

## 5. 建议修正优先级
- 高优先级：扩展 Specs Requirements（P1-1）
- 中优先级：补充数据迁移说明（P1-2）
- 低优先级：量化裁决层覆盖范围（P2-3）

## 6. 最终建议
扩展 Specs 后重新 DPS，预期 ≥ 85 进入实施。
