# farm-agent-ruifengyun-h5-api Plan Review v1

## Review 元信息

- **Review 对象**: `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v1.md`
- **Review 时间**: 2026-06-18
- **Review 类型**: ADD Step 0 方案评审（Plan Review）
- **前置阅读**:
  - Plan 文档: `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v1.md`
  - 需求来源: `docs/大田精准耕播智能决策系统/knowledge/00-需求/对接瑞丰耘AI智能体小程序-v1.md`
- **DPS 快照**: 16/100 🔴 BLOCKED（Plan 粒度 65、Review 覆盖 0、Specs 精确 0、回流完整 0）

---

## 1. 问题复现

瑞丰耘 H5 对接需要在 farm-agent 新增 3 个 REST API 端点，Plan 文档覆盖了专家注册、握手流程、API 端点等维度。但以下关键设计缺失或不一致，导致 **3 个 P0 阻断项** 阻塞实施。

---

## 2. P0 阻断项（必须修复后方可进入 Step 1）

### P0-1: 地块分析输入/输出 schema 与需求文档冲突

| 维度 | Plan §2.3 + §3.2 设计 | 需求文档实际定义 |
|------|----------------------|-----------------|
| 输入 | `region{province,city,district}` + `plots[{name,area,soilType,pH,fertility,prevCrop}]` | `province, city, district`（单区域，无 plots） |
| 输出 | `land_plot_analysis` JSON + "地块明细数组" | `land_plot_analysis` JSON（location + climate + soil + summary，无地块明细） |

**根因分析**: Plan §2.3 自行引入了"多地块综合判定"设计，需求文档第 1-43 行定义的 `land_plot_analysis` schema 是单区域级别的气候+土壤分析。H5 流程第一步是"地块选择"（可能选多个），但需求文档只定义了区域分析，没有多地块加权判定。**Plan 扩展了需求范围但未补充扩展后的 schema 定义，也未确认 H5 端实际传参格式。**

**传播链**: 若按当前 Plan 实施 → Task 8 API 端点的输入/输出 schema 无明确定义 → API 实现无法开工 → 或者实现后与 H5 前端不兼容 → 返工。

**修复方向**:
- **方案 A（推荐）**: 与 H5 前端确认实际传参格式。如果 H5 确实传多地块，在 Plan 中补充"地块明细"的完整 JSON schema，并将需求文档的 schema 作为子集嵌入。
- **方案 B**: 如果 H5 只传单地块（区域），回退 Plan 到单区域分析模式，删除 plots 数组和"地块明细"概念。

### P0-2: 缺少 Agent 内核同步调用模式的技术设计方案

**现象**: Plan §3.3 声明"复用 agent 内核但跳过 streaming"，但全篇没有任何具体实现方案。

**根因分析**: 现有 agent 调用链（`/api/agent/[hash]/route.ts`，826 行）深度耦合了以下流式链路组件，没有一个现成的"同步调用"入口：

| 组件 | 耦合方式 | 同步调用的影响 |
|------|---------|--------------|
| LangGraph streaming 节点图 | `agent.stream()` → `for await (chunk)` | 需要替换为 `agent.invoke()` |
| StreamBus 事件总线 | `registerStreamBus()` / SSE 推送 | 不需要（同步模式跳过） |
| chatPersistence | `chatPersistence.save()` / threadId | 不需要对话线程 |
| reasoning 节点 | 流式消费 expert packages | 需改为同步消费 |
| report 生成 | 依赖 streaming traces 收集 | 需改为同步收集 |

**传播链**: 这是方案的技术核心 → Task 8-10 三个 API 端点依赖此设计方案 → 没有设计方案则无法开始实施 → **3 个 API 全部阻塞**。

**修复方向**: Plan 补充 §3.3.1 小节，至少明确以下选型：
- **路线 A（轻量）**: 在 API Route 中直接调用 `loadExpertPrompt()` + LLM（绕过 LangGraph），复用 prompt/template，但不走 agent 内核。代价：丢失 grounding RAG、工具注入等 agent 能力。
- **路线 B（完整）**: 创建 `invokeExpertSync()` 封装，内部调用 `agent.invoke()` 替代 `agent.stream()`，保留 grounding + 工具注入。代价：需要改造 reasoning 节点以支持同步模式。
- 明确选择并给出 pros/cons。

### P0-3: SessionId 内存 Map 缺少多实例/多进程兼容方案

**现象**: Plan §3.5.2 说"内存 Map，TTL=30min"，但没有考虑生产环境部署形态。

**根因分析**: 项目使用 `pm2 start ecosystem.config.cjs`，可能是 cluster 模式（多进程）。`Map` 是进程内内存，多进程下：
- 握手请求路由到进程 A → sessionId 写入进程 A 的 Map
- 业务 API 请求路由到进程 B → 进程 B 的 Map 无此 sessionId → 校验失败

此外，Map 无过期清理机制会导致内存泄漏。

**传播链**: 当前方案仅适用于单进程开发环境 → 生产部署后 sessionId 随机失效 → H5 用户在 5 步向导中途认证丢失 → 回退到握手 → 用户体验断裂。

**修复方向**:
- **方案 A（轻量，推荐先采用）**: 明确声明当前版本仅支持单进程（`pm2 instances: 1`），补充 Map 定期清理逻辑（`setInterval` 每 5 分钟扫描过期条目）。
- **方案 B（完整）**: sessionId 存入 DB（如 `prisma.h5Session` 表），30min TTL 通过 `expiresAt` 字段 + 定期清理实现。
- 在 Plan 中补充选型决策和 trade-off 分析。

---

## 3. P1 重要问题（建议实施前修复）

### P1-1: roi_analysis 输入与成本核算 API 的字段映射不完整

| cost-accounting API 输入 | roi_analysis inputSchema | 缺失映射 |
|--------------------------|-------------------------|---------|
| `plantingArea` | `area`（种植面积） | ✅ 可映射 |
| `cropType` | `crop`（目标作物） | ✅ 可映射 |
| `varietyName` | — | ❌ 无对应字段 |

品种推荐结果（如"南粳9108"）需传递给成本核算，但 roi_analysis 没有品种字段。Plan 未说明 API 层如何将 varietyName 注入 Expert 调用（作为 prompt 附加参数？还是扩展 roi_analysis 的 inputSchema？）。

**修复方向**: 在 Plan §3.2 cost-accounting API 部分补充品种信息的传递方式。

### P1-2: 审计日志 traceId 上下文生成策略缺失

**现象**: Plan §3.3 说"每个 API 调用 `agentAudit()`"，但现有 `agentAudit()` 依赖于 `setAuditContext(userId, traceId)` 设置上下文。H5 API 无对话线程概念，需要明确 traceId 生成策略。

**传播链**: traceId 缺失 → audit log 无法关联到具体请求 → 审计日志不可查询 → 验收标准"审计日志可查询"不可达成。

**修复方向**: Plan 补充：使用 `sessionId + timestamp + random` 生成 per-request traceId，在 API Route 入口调用 `setAuditContext()`，出口调用 `clearAuditContext()`。

### P1-3: 品种推荐在种子库查询失败时的降级策略

**现象**: variety_recommend 依赖 `query_seed_catalog` 实时工具，但 Plan 未说明种子库返回空/查询失败时的降级行为。

**传播链**: 种子库无数据 → LLM 无证据输入 → 要么输出空推荐（H5 空白页），要么幻觉编造数据。

**修复方向**: Plan 补充降级策略——种子库无数据时，LLM 基于 knowledge base（expert_variety_recommend collection）进行纯知识推理，输出中 `data_confidence: "low"` 并附 `remark: "种子库无匹配数据，以下推荐基于知识库推理"`。

### P1-4: 成本核算 LLM 输出到 5 类成本明细的映射策略

**现象**: 需求文档第 332-676 行的 cost_accounting schema 包含 5 类成本明细（种子/肥料/病虫害/人工/其他），但 roi_analysis 是通用 ROI 分析专家。Plan 未说明如何确保 LLM 输出能映射到如此精细的成本结构。

**传播链**: LLM 自由输出 → API 层解析失败 → 返回不完整 JSON → H5 展示异常。

**修复方向**: Plan 在 §3.2 cost-accounting 部分补充：API 层在 prompt 中注入 H5 成本明细 schema 约束（参考 variety_recommend 加 `query_seed_catalog` 的方式），或在 API 层做 schema 校验 + 缺失字段补 `null`。

---

## 4. P2 优化建议

### P2-1: Grounding collection 初始数据来源未说明

Plan Phase 4 要求初始化 `expert_land_analysis` + `expert_variety_recommend` collection，但未说明初始知识文档来源。两个新专家若无 knowledge base 支撑，Grounding 将退化（`GROUNDING_DEGRADED`）。

**建议**: Phase 4 补充初始知识文档上传计划（手动上传 / 脚本生成基础农业知识文档）。

### P2-2: API 错误响应格式未定义

3 个 REST API 端点的错误响应（sessionId 过期、LLM 调用失败、参数校验失败）没有统一定义。当前 Plan 只定义了成功响应的 JSON schema。

**建议**: 补充统一错误响应格式，如 `{ error: { code, message }, requestId }`。

### P2-3: Plan §6 关联文档引用了不存在的文件

Plan 引用了以下文件但均不存在：
- `.qoder/specs/farm-agent-ruifengyun-h5-api/spec.md`
- `.qoder/specs/farm-agent-ruifengyun-h5-api/tasks.md`
- `.qoder/specs/farm-agent-ruifengyun-h5-api/checklist.md`
- `.qoder/plans/farm-agent-ruifengyun-h5-api-handoff-v1.md`

**建议**: 移除不存在的引用，或标记为"待生成（Step 0.5 产出）"。

---

## 5. 决策结论

| 结论 | 说明 |
|------|------|
| **当前状态** | 🔴 BLOCKED — 3 个 P0 阻断项必须回流至 Plan 后才能进入 Step 1 |
| **修复顺序** | P0-1（与需求对齐）→ P0-2（技术方案补全）→ P0-3（多实例兼容） |
| **修复责任** | P0 由人工确认后通过 SearchReplace 回流至 Plan 文档 |
| **再评审触发** | P0 全部修复后，重新跑 DPS 检查，DPS ≥ 60 后方可流转 |

---

## 6. DPS 量化评分

| 维度 | 分数 | 权重 | 加权 | 说明 |
|------|------|------|------|------|
| Plan 可执行粒度 | 65/100 | 25% | 16.3 | 专家注册详实，但核心技术方案和 schema 定义缺失 |
| Review 覆盖完备度 | 85/100 | 25% | 21.3 | 本次 Review 覆盖数据模型、API 签名、存储 3/5 维度 |
| Specs 精确度 | 0/100 | 25% | 0 | Specs 目录未创建（Plan Review 阶段不强制） |
| Review 回流完整度 | 0/100 | 25% | 0 | 待 P0 回流后更新 |
| **DPS 复合** | — | — | **37.6** 🔴 | P0 回流后预计提升至 ≥60 |

---

## 7. 关联文档

| 文档 | 路径 | 关系 |
|------|------|------|
| Plan | `.qoder/plans/farm-agent-ruifengyun-h5-api-plan-v1.md` | 被评审对象 |
| 需求 | `docs/大田精准耕播智能决策系统/knowledge/00-需求/对接瑞丰耘AI智能体小程序-v1.md` | 需求依据 |
| ADD Route | `.qoder/plans/farm-agent-ruifengyun-h5-api-add-route-v1.md` | 待生成（Step 0.5） |
| Handoff | `.qoder/plans/farm-agent-ruifengyun-h5-api-handoff-v1.md` | 待生成（Step 0.5） |
| Specs | `.qoder/specs/farm-agent-ruifengyun-h5-api/` | 待生成（Step 0.5） |

---

## 8. 教训总结

1. **Plan 的 API 设计必须与需求文档的 JSON schema 逐字段对齐**，扩展需求范围时需在 Plan 中补充扩展后的 schema 定义，不可仅引用"需求文档定义"而自行新增字段。
2. **"复用某现有能力"必须在 Plan 中写明具体的技术对接方式**（如"复用 agent 内核但跳过 streaming"必须展开为至少一段技术路线），否则 Review 无法判断可行性。
3. **涉及会话管理的方案必须评估部署形态**（单进程 vs 多进程），即使是"先简单实现"也需要在 Plan 中声明 trade-off 和后续演进计划。
