# farm-agent KB 双路检索 Plan Review v1

## Review 元信息

- **Review 对象**: `.qoder/plans/farm-agent-deep-kb-dualpath-retrieval-plan-v1.md`
- **对比方案**: Plan 内部 §2.1 方案 A vs B 对比审查 + §2.3 数据模型选型对比
- **Review 时间**: 2026-06-17
- **Review 类型**: 架构决策 + 合规检查 + 代码基座一致性验证
- **前置阅读**:
  - `.qoder/plans/farm-agent-deep-kb-dualpath-retrieval-plan-v1.md`（被评审 Plan）
  - `.qoder/plans/farm-agent-three-tier-reasoning-graph-plan-v1.md`（关联 ACA 框架 Plan）
  - `src/agents/nodes/retrieval.ts`（检索节点，505 行）
  - `src/agents/state.ts`（AgentState 定义）
  - `src/agents/index.ts`（Graph 拓扑）
  - `src/agents/edges/conditional.ts`（条件路由）
  - `src/services/knowledge-indexer.ts`（ChromaDB 索引 + 检索，747 行）
  - `src/app/api/knowledge/upload/route.ts`（上传路由）
  - `src/app/api/agent/stream/route.ts`（流式推理路由）
  - `prisma/schema.prisma`（Document 模型）
  - `agrisynapse/src/views/llm/customization/index.vue`（前端知识配置页）
  - `agrisynapse/src/api/knowledge/grounding.ts`（Grounding API 客户端）

---

## 1. 问题复现

当前 `retrieval.ts` 已完成 Per-Expert Grounding 并行检索（第 9/10 轮改造），每个 Expert 独立检索各自的 collection（expert_pest_risk 等），降级时回退到 `farm_agent` 主 collection + `where` 过滤。但所有检索路径均不使用 `state.projectId` 做项目级过滤，导致：

1. **项目知识混用**：用户选项目 A 提问时，RAG 返回项目 B 的文档片段
2. **KB 冲突无感知**：项目级知识（如"该地块适合玉米"）与全局知识（如"该条件应种大豆"）可能矛盾，当前无检测机制
3. **交互点伪暂停**：`interactionPointDetection` 仅设 `pendingInteraction` 标志后继续执行到 `response`，不是真暂停

Plan 提出在 deep 管线的 `retrieval → reasoning` 之间插入双路检索 + KBClaim 提取 + 冲突检测 + `interrupt()` 暂停，方向正确。但存在以下问题。

---

## 2. 方案对比

### 2.1 Plan §2.1 方案 B 审查：双路检索 + 交叉比对 + interrupt()

**方向正确**——与 ACA 框架的 Argumentation + Adjudication 模式同构，可作为深图验证铺路。

**但存在架构叠层冲突**：

当前 `retrieval.ts` 已实现 Per-Expert 并行检索（`expertIds.map(async ({ expertId }) => ...)`），每个 Expert 独立检索自己的 Grounding collection 或 `farm_agent` 降级。Plan 在此之上再叠加"项目 KB + 全局 KB"双路，形成**三层检索嵌套**：

```
Per-Expert 并行（已有）
  └─ 每个 Expert → 独立 collection 或 farm_agent
双路并行（Plan 新增）
  └─ 项目 KB → farm_agent where:{projectId}
  └─ 全局 KB → farm_agent 不过滤
```

Plan 未说明双路检索与 Per-Expert 检索的组合语义——是替代、叠加、还是正交？retrieval 节点的改造方案 §Task 5 只说"双路并行检索执行"，没有定义与现有 Per-Expert 管线的集成点。

### 2.2 Plan §2.3 数据模型选型审查：单 Collection + metadata 过滤

**选型正确**——交叉比对依赖同一向量空间的余弦距离可比性，单 collection + `where: { projectId }` 是最合理的选择。

但 Plan 的 §关键定义中写到 `projectId` 的语义是"划分检索域"而非"标记归属"，这与 Prisma `Document.projectId String?` 的实际用法（项目目录标识）存在语义偏移。需要明确：projectId 在 ChromaDB metadata 中是用于**隔离检索域**，还是用于**标记文档来源**。两种语义会影响全局检索的行为（是否排除有 projectId 的文档）。

### 2.3 KBClaim 提取方案审查：mini-LLM vs 轻量 fan-in

Plan 提出 `kbClaimExtractor` 节点，用 mini-LLM 从检索 chunk 提取结构化 KBClaim（claim + preconditions + constraints + confidence）。这是**重量级方案**。

项目已有的实践规范（"双路检索交叉比对实践规范"）定义为：

> 双路 KB 交叉比对是 retrieval 层的**轻量 fan-in 模式**：复用多 Expert 汇聚骨架（并行执行 + 结果合并），但冲突检测需独立实现——仅处理 chunk 去重、来源标记（project_kb / global_kb）、置信度微调（同源 +0.1 / 全局独有 -0.05 / 矛盾标记），**不复用 reasoning 层的复杂冲突检测逻辑**。

Plan 的 KBClaim + mini-LLM 方案明显超出这个轻量规范。需要决策：是遵循已有的轻量 fan-in 实践，还是升级为重量级 KBClaim 提取。

---

## 3. 决策结论

**Plan 方向正确，但存在 2 个阻断项（P0）和 6 个严重问题（P1），不可直接进入 Step 3。**

### 3.1 阻断项（P0）

| # | 缺陷 | 证据 | 修复建议 |
|---|------|------|---------|
| 1 | **双路检索与 Per-Expert 检索的组合语义未定义** | `retrieval.ts` L207-287 已实现 Per-Expert 并行检索；Plan §Task 5 仅说"双路并行检索"，未说明与 Per-Expert 层的关系 | Plan §Task 5 补充组合策略：(A) 双路替换 Per-Expert 降级路径（推荐）(B) 双路叠加在 Per-Expert 之上 (C) 双路仅在 Per-Expert 降级时触发 |
| 2 | **projectId 类型不一致** | `AgentState.projectId: Annotation<number \| null>()`（state.ts L120）；`Document.projectId: String?`（schema.prisma L156）；`searchKnowledgeDocuments` 的 `where` 子句接受 `Record<string, unknown>` | Plan 需统一 projectId 类型策略：number → String 转换点在哪里？ChromaDB metadata 中 projectId 存 number 还是 string？建议统一为 string（与 Prisma 一致） |

### 3.2 严重问题（P1）

| # | 缺陷 | 影响 | 修复建议 |
|---|------|------|---------|
| 3 | **KBClaim 提取 vs 轻量 fan-in 规范冲突** | Plan 引入 mini-LLM 提取 KBClaim（额外 LLM 调用 + 延迟），但已有实践规范要求"轻量 fan-in，不复用 reasoning 层冲突检测逻辑" | 决策二选一：(A) 采用轻量 fan-in（chunk 去重 + 来源标记 + 置信度微调），KBClaim 延后到 ACA Graph 验证 (B) 升级规范为"结构化 Claim 提取"，同步更新实践规范 |
| 4 | **interrupt() + MemorySaver 持久化风险** | `index.ts` L187: `const checkpointer = new MemorySaver()`——这是内存级 checkpointer，进程重启后所有中断状态丢失 | Plan 需评估 MemorySaver 是否满足 interrupt() 的暂停-恢复需求（同一进程内可恢复，但跨进程不可恢复）。如果需要持久化中断，需替换为 PostgresSaver 或 SQLiteSaver |
| 5 | **resume 端点与现有 streamAgent() 的集成路径不明** | `stream/route.ts` 当前直接调用 `streamAgent(input, config)` → `agent.stream()`；LangGraph interrupt 恢复需要 `agent.stream(Command({ resume: ... }), { ...config })` 传入同一 thread_id | Plan §Task 7 需明确：resume 端点是独立路由还是 stream/route.ts 内的条件分支？config 中的 `thread_id` 如何传递以保持 State？建议新增独立端点 `/api/agent/resume` |
| 6 | **Task 6 Graph 集成描述与实际需求矛盾** | Plan §Task 6.2 说"interrupt() 自动暂停，不需要 conditional edge"，但 §ADD-7 审计策略表却列出 `src/agents/edges/conditional.ts` 需新增 `routeByKBConflict` | 二选一：(A) interrupt() 自动暂停确实不需要 conditional edge——从审计策略表中移除 conditional.ts 行 (B) 需要 conditional edge 处理 interrupt 未触发的标准路由——补充 routeByKBConflict 的具体语义 |
| 7 | **upload route 的 projectId 提取与现有 FormData 字段冲突** | `upload/route.ts` 当前 FormData 字段有 `file` 和 `grounding`；Plan 要新增 `projectId`。但 Prisma Document.projectId 是 `String?`，而 AgentState.projectId 是 `number` | Plan §Task 1.2 需明确：FormData 中 projectId 的类型、转换逻辑、以及与 Document 表的写入路径 |
| 8 | **存量 ChromaDB chunk 的 projectId 回填策略缺失** | 当前 `knowledge-indexer.ts` L155-167 写入 ChromaDB metadata 时不含 projectId。Plan 只改增量（新上传的），不管存量 | Plan 需补充：是否需要对已索引的 chunk 做 projectId 回填？如果需要，提供回填脚本方案 |

### 3.3 中等问题（P2）

| # | 问题 | 建议 |
|---|------|------|
| 9 | **KBClaim 提取的 LLM 选型和延迟预算未定义** | Plan 提到"mini-LLM"但未指定模型。KBClaim 提取在每个检索 chunk 上调用，假设 topK=5 × 2 路 = 10 次调用，延迟可能达 3-5 秒。需定义延迟预算和模型选择 |
| 10 | **__interrupt__ chunk 的 SSE 前端协议未定义** | Plan §Task 7.1 说"检测 `__interrupt__` chunk"，但未定义前端如何解析。LangGraph 的 interrupt chunk 格式是 `{ __interrupt__: [...] }` 还是其他？前端需要明确的 SSE 事件类型和 payload 结构 |
| 11 | **customization 页面 projectId 来源未明确** | Plan §Task 8.2 说"引入 agentChatStore.projectId"，但 customization 页面是独立的知识管理页面，不在聊天上下文中。需要明确 projectId 从哪个 store/context 获取 |
| 12 | **Plan §3.3 interrupt() options 的"展开对比"选项缺乏实现路径** | `options: [{ id: "review", label: "展开对比" }]`——用户选择"展开对比"后，系统应该做什么？Plan 未定义后续行为 |
| 13 | **kbConflictResolver 的"可自动裁决"规则未覆盖边界** | Plan 提到"项目优先 / 置信度优者胜"，但未定义：项目 KB 和全局 KB 置信度相同时如何处理？项目 KB 为 0 条结果时是否跳过冲突检测？ |

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | Plan 声明 | 实际影响 | 改动风险 |
|------|-----------|---------|:--:|
| `src/agents/nodes/retrieval.ts` | 双路检索改造 | 已有 505 行 Per-Expert 并行逻辑，双路检索需在 Per-Expert 循环**内部**或**之后**嵌入，改动面大 | 🔴 高 |
| `src/agents/nodes/kb-claim-extractor.ts` | 新建 | 新文件，低风险；但调用链关系需明确 | 🟢 低 |
| `src/agents/nodes/kb-conflict-resolver.ts` | 新建 | 新文件 + interrupt() 调用，需验证 LangGraph interrupt 在当前版本的兼容性 | 🟡 中 |
| `src/agents/state.ts` | 新增 3 个字段 | 追加 Annotation 字段，低风险 | 🟢 低 |
| `src/agents/index.ts` | 新增节点 + 修改边 | 当前 `retrieval → reasoning` 是硬编码边（L178），改为 `retrieval → kbConflictResolver → reasoning` 需调整 wrapNodeWithAudit 包装 | 🟡 中 |
| `src/agents/edges/conditional.ts` | 新增 routeByKBConflict | 取决于 P1 #6 的决策——可能不需要 | 🟡 中 |
| `src/services/knowledge-indexer.ts` | metadata 写入 projectId | 需在 3 个索引入口（indexKnowledgeDocumentWithProgress + indexKnowledgeDocument 的两个分支）都加入 projectId，改动面中等 | 🟡 中 |
| `src/app/api/knowledge/upload/route.ts` | FormData 提取 projectId | 改动小，但需与 Prisma 类型对齐 | 🟢 低 |
| `src/app/api/agent/stream/route.ts` | interrupt 支持 + resume 端点 | 改动面中等，需理解 LangGraph interrupt chunk 格式 | 🟡 中 |
| `agrisynapse/src/views/llm/customization/index.vue` | projectId 过滤 | 1117 行的大文件，改动点分散（fetchDocuments + handleUpload + onMounted） | 🟡 中 |
| `agrisynapse/src/api/knowledge/grounding.ts` | API 扩展 projectId | uploadDocument 签名变更，getDocuments 参数扩展 | 🟢 低 |

### 4.2 数据流影响

```
当前:
  retrieval → Per-Expert 并行检索（expert collection / farm_agent 降级）
           → 去重 + expertPackages 构建
           → reasoning

Plan 改造后:
  retrieval → Per-Expert 并行检索（已有）
           → [新增] 项目 KB + 全局 KB 双路检索（语义待定义）
           → [新增] kbClaimExtractor（mini-LLM 提取）
           → [新增] kbConflictResolver（冲突检测 + interrupt()）
           → reasoning
```

**关键风险点**：
- Per-Expert 检索已消耗大量 LLM token 和延迟，叠加双路检索 + KBClaim 提取后，retrieval 节点总延迟可能从 2-3 秒增长到 8-10 秒
- `expertPackages` 在 Per-Expert 检索后构建，双路检索的结果如何注入 expertPackages 未定义
- interrupt() 暂停后，AgentState 中的 `expertPackages` 和 `evidenceChain` 需要完整保留，恢复后 reasoning 节点需能正确消费

### 4.3 回滚风险

- ChromaDB metadata 写入 projectId 是**幂等操作**——不写 projectId 的 chunk 仍可正常检索（`where` 为空时不过滤），回滚安全 ✅
- interrupt() 机制可降级——如果 interrupt 有问题，可以 catch 后直接走标准路径（合并 Claim → reasoning），回滚路径清晰 ✅
- 新增节点可旁路——kbClaimExtractor 和 kbConflictResolver 是中间节点，移除后 retrieval 直连 reasoning 即可回滚 ✅

---

## 5. 最终建议

**Plan 架构方向正确（双路检索 + 冲突检测 + interrupt()），但在进入 Step 3 前需解决以下优先级问题**：

1. **[P0] 定义双路检索与 Per-Expert 检索的组合语义**——这是最核心的架构缺口，不解决则 Task 5 无法实施
2. **[P0] 统一 projectId 类型策略**——明确 number ↔ string 转换点和 ChromaDB metadata 存储类型
3. **[P1] 决策 KBClaim 提取方案**——轻量 fan-in（已有规范）vs 重量级 mini-LLM（Plan 方案），二选一
4. **[P1] 评估 interrupt() + MemorySaver 的持久化可行性**——如果仅需进程内恢复则可行，否则需替换 checkpointer
5. **[P1] 明确 resume 端点集成路径**——独立路由 vs 条件分支，thread_id 传递机制
6. **[P1] 解决 Task 6 的 conditional edge 矛盾**——interrupt() 是否需要 conditional edge
7. **[P2] 补充存量 chunk 的 projectId 回填策略**——至少声明"不回填"的决策理由
8. **[P2] 定义 __interrupt__ 的 SSE 前端协议**——事件类型 + payload 结构

**推荐执行顺序**：先解决 P0 #1-#2 → 再解决 P1 #3-#6 → 最后处理 P2 → 更新 Plan 后重新评审
