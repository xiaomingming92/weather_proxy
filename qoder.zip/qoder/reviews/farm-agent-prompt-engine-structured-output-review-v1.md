# Prompt Engine 结构化输出演进 Plan — Review v1

> **Review Target**: `farm-agent-prompt-engine-structured-output-plan-v1`
> **Review Date**: 2026-07-22
> **Reviewer**: AI Agent

---

## 总体评价

Plan 技术深度优秀，对现状基线、痛点分析和双路径演进策略的梳理非常清晰。但存在 **模板结构不合规**、**Handoff 完全缺失**、**若干数据不准确** 三类问题。建议回流修正后再进入实施。

---

## P0 — 必须修复（阻断实施）

### P0-1: Plan 模板结构不合规

**问题**: Plan 使用自定义 §1-§13 结构，未遵循 `simple-plan-template.md` 要求的 §一~§六 + Handoff 4.1-4.10 结构。

**对比**:

| 模板要求 | Plan 现状 | 状态 |
|---------|---------|------|
| §一、Plan 概述（现状/目标/核心原则） | 分散在 §1 背景 + §3 目标 | 需合并 |
| §二、变更范围（文件表 + 设计决策） | §8 影响文件（部分对齐） | 需重组 |
| §三、Tasks（checkbox 格式） | §7 表格格式（非 checkbox） | 需转格式 |
| §四、Handoff（4.1-4.10 完整子节） | **完全缺失** | 需新建 |
| §五、验收标准 | §10 验收标准 | 基本对齐 |
| §六、关联 | 缺失 | 需补充 |

**修复**: 按模板重构文档结构，将现有内容映射到模板章节中。

### P0-2: Handoff 章节完全缺失

**问题**: 无 §四 Handoff，意味着缺少以下关键信息：

- 4.1 交接前状态
- 4.2 交接后状态（目标）
- 4.3 改动清单
- 4.4 回滚方案
- 4.5 执行前置检查
- 4.6 执行 Task 摘要（依赖图）
- 4.7 关键风险点
- **4.8 恢复上下文审计查询**（四段式：一键恢复 + 逐任务查询 + SQL 验证 + 恢复判定）
- 4.9 后置确认
- 4.10 脱敏要求

Plan §11 依赖关系图可迁移到 4.6，§9 风险可迁移到 4.7，§13 审计查询需按 4.8 四段式重构（当前缺少 SQL 验证段和 `query_audit_logs()` 工具调用格式）。

**修复**: 按 handoff-single-round-template 补全全部子节。

### P0-3: Tasks 格式不符 — 表格 vs Checkbox

**问题**: §7 Tasks 使用表格格式（`| # | 任务 | 文件 | 说明 | 验收 |`），模板要求 checkbox 格式：

```markdown
- [ ] Task 1: {描述}
  - [ ] SubTask 1.1: {子描述}
```

**影响**: checkbox 格式是 ADD 工作流 checklist 追踪的基础，表格格式无法被 checklist 机制识别。

**修复**: 将 §7 短期目标 10 个 Task 转为 checkbox 嵌套结构，每个 SubTask 包含文件路径和验收条件。

---

## P1 — 应当修复（影响准确性）

### P1-1: markdown 剥离重复次数不准确

**Plan 声明** (§2.3): "每个节点独立实现 markdown 剥离...重复 6+ 次"

**实际验证**: `grep` 命中 **9 处**：

| # | 文件 |
|---|------|
| 1 | `src/agents/prompts/intention.ts` |
| 2 | `src/agents/prompts/intention_async.ts` |
| 3 | `src/agents/prompts/reasoning.ts` |
| 4 | `src/agents/prompts/verdict.ts` |
| 5 | `src/agents/prompts/interaction-point-detection.ts` |
| 6 | `src/agents/prompts/response.ts` |
| 7 | `src/agents/nodes/intention.ts` |
| 8 | `src/agents/nodes/intention-async.ts` |
| 9 | `src/agents/router/llm-fallback.ts` |

**遗漏**: `src/agents/router/llm-fallback.ts` 未被纳入影响文件清单（§8 完全未提及此文件）。此文件也做 markdown 剥离，改造时应一并处理。

### P1-2: 节点计数与覆盖不一致

**问题**:
- §2.2 声明 "7 个节点"（含 response），但 §8.5 列出 **8 个节点文件**（额外包含 `coordination-dialogue.ts`）
- `coordination-dialogue.ts` 未在 §2.2 节点清单中出现，但它确实调用 LLM 并做 JSON 解析

**修复**: §2.2 应列出 8 个 LLM 调用节点（含 coordination-dialogue），或明确解释分类逻辑。

### P1-3: `reasoning.zod.ts` 有文件无 Task

**问题**: §8.1 新建文件清单列出 `schemas/reasoning.zod.ts`（ReasoningOutput 的 Zod schema），但 §7 短期目标 Task 表无对应创建任务。

Task 1.2 仅覆盖 `intention.zod.ts`，Task 1.3 仅覆盖 `expert-claim.zod.ts`，`reasoning.zod.ts` 成为"幽灵文件"——在影响清单中声明但无 Task 驱动其创建。

**修复**: 在 Task 表中新增 `1.x: ReasoningOutput 迁移为 Zod schema` 任务。

### P1-4: §10 验收标准混入中期目标项

**问题**: 短期验收标准中包含 `model.toml 中 structuredDecoding 配置项可用`，但 §8.6 明确声明 `src/config/model.toml` 短期不改配置（"中期目标才加 structuredDecoding 字段"）。

**修复**: 将此项从短期验收中移除，或明确标注为"不纳入短期验收"。

---

## P2 — 建议优化

### P2-1: `AuditedLLM.withStructuredOutput()` 的 Ollama 降级策略需细化

**问题**: §4.2 提到 "ChatOllama 的 `withStructuredOutput()` 依赖模型是否支持 JSON mode"，但 `AuditedLLM` 内部持有 `ChatOpenAI | ChatOllama` 联合类型。当 provider=ollama 时：

- `ChatOllama` 的 `withStructuredOutput()` 行为与 `ChatOpenAI` 不同
- 部分 Ollama 模型不支持 JSON mode（如早期的 llama2）
- 降级到 prompt-parse 的触发条件未定义

**建议**: 在 §4.2 或 `structuredInvoke()` 设计中明确 Ollama 后端的降级判定逻辑：
```typescript
if (llm.underlying instanceof ChatOllama) {
  // Ollama: 仅 JSON mode, 无 schema 约束 → 始终走 prompt-parse 降级路径
}
```

### P2-2: `coordination-dialogue.ts` 的 JSON 提取方式特殊

**问题**: §8.5 将 `coordination-dialogue.ts` 的改造描述为 "regex 提取 JSON 改为 schema 约束"，但该文件的 JSON 提取方式与其他节点不同——使用 `text.match(/\[[\s\S]*\]/)` 提取 JSON 数组，而非 markdown 剥离 + `JSON.parse`。

它的输出类型是 `ConflictReport[]`（数组），与 `structuredInvoke()` 设计的单对象 schema 场景略有差异。

**建议**: 确认 `withStructuredOutput()` + `z.array(ConflictReportSchema)` 在 LangChain.js 下的兼容性，或在 `structuredInvoke()` 中显式支持数组 schema。

### P2-3: `response.ts` 死代码处理建议更明确

**问题**: §8.4 对 `response.ts` 的处理建议是 "标记为 `@deprecated` 或删除"，过于模糊。

**验证**: `responsePrompt` 在 `src/agents/prompts/index.ts` 中导出，但全局无 `import { responsePrompt }` 消费方。确认为死代码。

**建议**: 明确选择"删除"路径。理由：
- 无消费方
- response 节点走 `stream()`，永远不经过 prompt template 的 `parse()/validate()`
- 保留死代码增加维护负担

---

## 技术亮点

1. **双路径设计合理**: 云端 `response_format` + 本地 `XGrammar` 的分层策略务实，且保证短期改造代码可复用
2. **降级策略完整**: `structuredInvoke()` 的三级降级（structured_output → prompt_parse → degraded）设计稳健
3. **影响分析细致**: §8 对 23+ 文件的分类（新建/基础设施/Schema/Prompt/节点/不动）非常详尽
4. **`response.ts` 死代码识别**: 正确识别了未使用的 `responsePrompt`

---

## 回流清单

| # | 级别 | 问题 | 回流目标章节 | 状态 |
|---|------|------|------------|------|
| 1 | P0 | 模板结构不合规 | 全文重构 | ✅ 决策: 保持 standard-plan-template，不切 simple |
| 2 | P0 | Handoff 完全缺失 | 新增 §四 | ✅ 决策: Plan 不含 Handoff（后续实施时单独生成） |
| 3 | P0 | Tasks 格式不符 | §三 Tasks | ✅ 已回流: 表格转 checkbox，新增 Task 1.3 reasoning.zod.ts，重编号至 1.11 |
| 4 | P1 | markdown 剥离计数 + 遗漏 llm-fallback.ts | §2.3 + §8 文件清单 | ✅ 已回流: 计数修正为 9 处，补充 llm-fallback.ts |
| 5 | P1 | 节点计数不一致 | §2.2 | ✅ 已回流: 7→8 节点，补充 coordinationDialogue |
| 6 | P1 | reasoning.zod.ts 无 Task | §三 Tasks | ✅ 已回流: 新增 Task 1.3 |
| 7 | P1 | 验收标准混入中期项 | §五 验收标准 | ✅ 决策: 直接移除 structuredDecoding 项 |
| 8 | P2 | Ollama 降级策略细化 | §4.2 | ✅ 已回流: 补充 Ollama 降级策略代码示例 |
| 9 | P2 | 数组 schema 兼容性 | §4.3 | ✅ 已回流: 补充 z.array() 兼容性说明 |
| 10 | P2 | response.ts 明确删除 | §8.4 | ✅ 决策: 标记 @deprecated |
