# farm-agent Expert Deep Pipeline 运行时修复 — Plan Review v1

> **审查时间**: 2026-06-15
> 
> **关联 Plan**: [farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md](../plans/farm-agent-expert-deep-pipeline-runtime-fix-plan-v1.md)

---

## 0. 审查范围

本 Review 对 Plan `farm-agent-expert-deep-pipeline-runtime-fix-plan-v1` 进行四维结构化评审，覆盖方案方向、覆盖完整性、可行性、风险。

Plan 目标：修复专家技能卡片对话中 farm-agent 未走 deep pipeline + agrisynapse GUI 不渲染结构化产物的双重缺陷。

---

## 1. 方向判定

### 1.1 根因定位——认可

Plan 定位两个根因：

| # | 根因 | 认可 |
|---|------|------|
| R1 | `resolveThinkingLevel` 未感知 `explicitExpertId`，技能卡片触发仍判为 fast | ✅ |
| R2 | `intentionNode` tool_calls 返回路径丢失 `currentTask.query`，导致 retrieval 空查询 | ✅ |
| R3 | **Expert Grounding collection 全部为空**：文档仅索引到默认 `farm_agent` collection，expert 专有 collection（`expert_pest_risk` 等）从未接收数据 → `checkCollectionGrounding()` 返回 `indexHealth: "empty"` → `groundingReady = false` → `source = "knowledge"` → GUI 证据条只渲染 knowledge 分支 | 🆕 Runtime 发现 |

定位精准：R1 是裁决层策略缺口，R2 是节点边界数据丢失，R3 是 Expert Grounding 知识域锚定未初始化。三处均为单点断裂。

### 1.2 修复方向——认可

| 修复 | 位置 | 评价 |
|------|------|------|
| 裁决层策略增强 `explicitExpertId` 参数 | `thinking-level.ts` | ✅ 策略集中化，符合裁决层收敛原则 |
| 4 处调用透传 `explicitExpertId` | `intention.ts` | ✅ 全路径覆盖 |
| 2 处 tool_calls return 补充 `currentTask.query` | `intention.ts` | ✅ 修复数据丢失 |
| GUI 三层语义容器分离 + 深度思考折叠 | `LlmChatView.vue` | ✅ DeepSeek 模式，交互合理 |

### 1.3 方案 B 决策——认可

证据链（`msg.evidenceChain`）与证据条（`msg.evidence`）是两个独立概念：证据条是流式实时推送，证据链是管线末端整理后的结构化产出。Plan 将证据条放入深度思考折叠容器、证据链放入最终态面板——职责清晰，认可。

---

## 2. 覆盖完整性

### 2.1 后端覆盖

| 节点 | 是否覆盖 | 说明 |
|------|---------|------|
| thinking-level 策略 | ✅ | explicitExpertId 强制 deep |
| intention 4 处调用 | ✅ | 全透传 |
| intention tool_calls return | ✅ | 两路径均补充 currentTask |
| retrieval | ⚠️ | 上游电流修复后检索自然恢复，但 **Expert Grounding collection 为空导致 source 恒为 knowledge** |
| reasoning | ✅ | 证据非空时不再跳过 |
| verdict | ✅ | 推理非空时正常产出 |
| response | ✅ | 全量 structured_output |

### 2.2 前端覆盖

| GUI 元素 | 是否覆盖 | 说明 |
|---------|---------|------|
| 深度思考折叠容器 | ✅ | RAG spinner + 证据条 + 工具调用 |
| 深度思考 header 自动展开/收起 | ✅ | 流式中展开，流式完收起 |
| 文本气泡 | ✅ | 唯一有 bubble 样式 |
| 最终态面板 | ✅ | 证据链 + 推理 + 裁决 + 交互 + 工具按钮 |
| 证据来源区分 | ✅ | expert / knowledge / tool 三类图标 |

### 2.3 覆盖缺口（Review 阶段新发现）

| 缺口 | 说明 |
|------|------|
| **流式中间态数据不持久化（含 expertIds）** | `structuredResponse`（持久化到 `ChatMessage.metadata`）仅包含最终态字段（evidenceChain/reasoningPath/verdict/interactionPoint），不包含流式中间态字段（evidence/ragResult/ragSearching/toolCalls/**expertIds**）。页面刷新后：① 深度思考折叠容器内证据条和 RAG 状态栏为空白；② **expertIds 丢失导致前端 `hasExpertIds(msg)` 返回 false，最终态面板不展示"导出报告"按钮**。 |
| **loadThread 不恢复流式字段** | `agentChat.ts` 的 `loadThread()` 从 metadata 恢复消息时只取了 verdict/evidenceChain/reasoningPath/interactionPoint 四个字段，未恢复 evidence/ragResult/ragSearching/toolCalls。导致历史回放时中间态数据丢失。 |
| **ragResult.sources key 为 CUID** | retrieval.ts L407 使用 `e.metadata?.documentName \|\| e.source` 构建 source 统计 key。当 ChromaDB 中 `result.metadata?.name` 返回的是 collection ID（CUID）而非文档文件名时，RAG 结果栏显示 `cmpqihxve0017lz3rl81stzft×1` 而非可读文档名。 |
| **`.chat-bubble-final` 内部元素排序与 Plan 不符** | Plan（L165-174）要求最终态面板元素顺序为 `evidence-chain → reasoning → verdict → interaction → action-bar`。实际代码顺序为 `reasoning → evidence-chain → verdict → interaction → (多余 bubble) → action-bar`。 |
| **`.chat-bubble-final` 内部重复的 `.chat-bubble-content`**（LlmChatView.vue L372-375） | Plan 明确 `.chat-bubble-content` 仅在 `.chat-bubble-final` **外部**存在（`v-if="msg.isStreaming \|\| !hasPipelineOutput(msg)"`）。当前代码在最终态面板内部 action-bar 上方多了一个裸露的 `.chat-bubble-content`，重复渲染 `msg.content`。 |
| **`.evidence-chain` 渲染未按 source 区分** | Plan（L167-170）要求证据链在最终态面板中也按 source 三源渲染（expert→🧠+collection badge；knowledge→📄+文档名+进度条；tool→🔧+工具名+原生 table）。当前 `.evidence-chain` 对所有条目统一渲染（chevron + source 文本 + type 文本 + 可靠/关联进度条），无 source 分支逻辑。 |
| **Expert Grounding collection 全部为空 → evidence-bar 只走 knowledge 分支** | 知识库文档全量索引到默认 collection `farm_agent`，但 Expert Grounding 检查独立 collection（如 `expert_pest_risk`）。`checkCollectionGrounding()` → `client.count()` → 0 → `indexHealth: "empty"` → `groundingReady = false` → `_grounded = false` → `source = "knowledge"`。**Runtime 确认**：agent-audit.log 显示 `EXPERT_GROUNDING_DEGRADED: Expert pest_risk grounding 不可用: empty` + `EXPERT_GROUNDING_DEGRADED: 无激活专家，回退全局检索 (expertCount=0)`；stream-bus.log 中全部 5 条 evidence_found 均为 `source="knowledge"`、`relevance=0`。结果：模板 `v-if source === 'expert'`（🧠+collection badge）永远不命中，证据条只渲染 knowledge 分支（📄图标），且 relevance=0 进度条为空。 |
| **中间态 evidence-bar 实际已渲染（knowledge 分支），但用户感知为"未渲染"** | stream-bus.log 证实 evidence_found SSE 事件正常发出，`_dispatchEvent` 正确 push 到 `msg.evidence`。证据条 DOM 存在且走 `v-else-if source === 'knowledge'` 分支（📄+文档名+0%进度条），但因全部 evidence 都是 knowledge 源、无 expert 图标、tool-calls 为空，用户视觉上认为"只有 RAG 结果栏有数据"。需进一步确认浏览器 DOM 中 `.llm-page__evidence-bar` 是否实际存在。 |

### 2.4 未覆盖（原计划）

- 渐进式逐节点渲染（retrieval→reasoning→verdict 的 per-node structured_output 实时展示）：Plan 明确标注为后续优化
- fast 路径闲聊场景：Plan 确认不触发 retrieval，行为不变

### 2.5 API 签名/函数接口

| 函数 | 签名变更 | 兼容性 |
|------|---------|--------|
| `resolveThinkingLevel(intent, explicitExpertId?)` | +1 optional 参数 | ✅ 向后兼容（默认为空时走原逻辑） |
| intentionNode 4 处 `resolveThinkingLevel(..., explicitExpertId)` | 调用方透传新参数 | ✅ 不改变调用约定 |
| intentionNode tool_calls return：`currentTask: { ...state.currentTask, query: queryText }` | 扩展 State 字段 | ✅ 子集扩展，下游按需读取 |
| `evidenceFound(evidence)` | `evidence` 对象增加 `documentName?, collectionName?, toolName?, data?, expertIds?` | ✅ 全部 optional，前端按需解构 |
| `collectStreamingTraces(): StreamingTraces` | 新增方法 | ✅ 仅 response 节点调用，不影响其他节点 |
| `structuredResponse` 增加 `streamingTraces` | metadata 扩展 | ✅ JSON 字段追加，存量消息 `streamingTraces` 为 undefined → 前端 fallback 为空 |
| `loadThread()` 恢复 `evidence`, `ragResult` | 读取 `streamingTraces` 并 merge 到 message | ✅ 存量消息无 `streamingTraces` 时跳过恢复 |
| `indexKnowledgeDocumentWithProgress(expertCateIds?)` | +1 optional 参数 | ✅ 默认不传时行为不变 |

### 2.6 兼容性/向后兼容

| 场景 | 影响 | 兼容策略 |
|------|------|----------|
| 存量 ChatMessage 无 `streamingTraces` | 页面刷新后深度思考容器为空 | `loadThread()` 对 undefined 字段 fallback 为 undefined/[]，不影响已渲染的最终态面板 |
| 存量 ChatMessage 无 `expertIds` | `hasExpertIds(msg)` 返回 false | 不显示导出报告按钮，不报错 |
| SSE `evidence_found` 新增 optional 字段 | 旧版 agrisynapse 不解析新字段 | 前端按 field? 读取，不解析时仅丢失 badge 信息，不影响核心渲染 |
| Expert Grounding collection 同步后 | 存量检索结果 source 从 "knowledge" 变为 "expert" | 前端模板已支持三源分支，切换无声 |
| kb-import `--expert` 未传 | 导入到默认 collection 后不写 expert collection | 等同于未启用 Expert Grounding，降级为 knowledge 源 |
| 纯闲聊无 expertId | `resolveThinkingLevel` 返回 "fast" | 不触发 deep pipeline，行为不变 |

---

## 3. 可行性

### 3.1 后端改动（Task 1-3）

- `thinking-level.ts`: 1 个参数 + 1 行判断，无风险
- `intention.ts`: 4 处透参 + 2 处 return 补充，改动量小、边界清晰
- 所有改动已通过 `npx tsc --noEmit` 验证

### 3.2 前端改动（Task 4）

- DOM 语义化重构：嵌套层级明确（`.chat-deep-thinking` → 4 元素、`.chat-bubble-content`、`.chat-bubble-final` → 5 元素）
- 不影响纯文本渲染路径
- 折叠动画可用 CSS transition 实现，无需 JS 动画库

### 3.3 跨仓库协调

- farm-agent 编译先行 → agrisynapse 编译后行
- 建议统一分支名 `fix/expert-deep-pipeline-runtime`

---

## 4. 风险

| 风险 | 概率 | 影响 | 缓解 |
|------|------|------|------|
| 深度思考折叠动画与聊天滚动冲突 | 低 | 中 | 折叠时维持滚动锚点 |
| 最终态面板元素过多导致布局拥挤 | 低 | 低 | 无 border 约束 + 全宽布局 |
| 首次渲染时证据条/证据链均为空导致面板空白 | 中 | 低 | `hasPipelineOutput()` 条件渲染，空时不显示面板 |
| **Expert Grounding collection 未初始化 → source 恒为 knowledge** | **高** | **高** | 知识库文档索引路径从未写入 expert 专有 collection；需增加 per-expert collection 同步逻辑，或改为基于 metadata filter 的 grounding 方案 |
| evidence-bar 因全部 source=knowledge 且 relevance=0 导致视觉上"像没渲染" | 高 | 中 | 修复 Expert Grounding 后 source 恢复 expert/knowledge 混合，图标和进度条正常展示 |

---

## 5. 审查结论

**PASS** — 方案方向正确，覆盖完整，改动量可控，风险可缓解。

**前置条件（进入 Step 1 前必须满足）**:
- [x] Plan 已完成 P1/P2 Review 问题回流
- [ ] Specs（tasks.md + checklist.md）已生成
- [ ] ADD Route 已生成
- [ ] Handoff 已生成

---

## 6. P0/P1/P2 问题清单

| 编号 | 级别 | 问题 | 处置 |
|------|------|------|------|
| P1-1 | ⚠ | evidence_found source 透传虚增工作量 | ✅ 已删除 |
| P1-2 | ⚠ | 证据链归属不明确 | ✅ 方案B：进最终态面板 |
| P1-3 | ⚠ | 跨仓库依赖声明缺失 | ✅ 已补充 |
| P1-4 | ⚠ | 中间态/最终态分类与实际代码不对齐 | ✅ 已修正标注 |
| P1-5 | ⚠ | Task 状态缺乏审计证据 | ✅ 已补充 |
| P1-6 | ⚠ | **流式中间态数据不持久化：页面刷新后证据条为空 + expertIds 丢失导致"导出报告"按钮不展示** | ⬜ 待处理（见 P1-7 联动） |
| P1-7 | ⚠ | **loadThread 不恢复 evidence/ragResult/ragSearching 等流式中间态字段** | ⬜ 需在 Plan 中补充任务（metadata 扩展 + loadThread 恢复逻辑） |
| P2-1 | ℹ | Runtime Review 引用错误 | ✅ 已修正 |
| P2-2 | ℹ | 关联文档 3/5 不存在 | ✅ 状态标注"待生成" |
| P1-8 | ⚠ | **`.chat-bubble-final` 内部元素排序与 Plan 不符** | ⬜ evidence-chain 应在 reasoning 之前；移除多余 bubble |
| P1-9 | ⚠ | **`.chat-bubble-final` 内部重复 `.chat-bubble-content`（L372-375）** | ⬜ 删除重复的 msg.content 渲染 |
| P1-10 | ⚠ | **`.evidence-chain` 渲染未按 source 三源区分** | ⬜ 证据链需增加 expert/knowledge/tool 分支渲染 |
| P1-11 | ⚠ | **Expert Grounding collection 全部为空：文档只索引入 `farm_agent`，expert 专有 collection（`expert_pest_risk` 等）无数据** | ⬜ `source` 恒为 `"knowledge"` + `relevance=0`，需决定：方案A) per-expert collection 同步；方案B) 改为 metadata filter grounding |
| P1-12 | ⚠ | **中间态 evidence-bar 实际已渲染（knowledge 分支），但因全部 source=knowledge+tool-calls 为空，用户感知为"未渲染"** | ⬜ 修复 P1-11 后自然恢复，但需浏览器 DOM 确认 `.llm-page__evidence-bar` 存在 |
| P2-3 | ℹ | **ragResult.sources key 为 CUID 而非文档名** | ⬜ Runtime 确认 `{"cmpqihxve0017lz3rl81stzft":2, "14期-喷灌技术意见.pdf":1}` CUID 与文档名混排。根因：`e.metadata?.documentName` 部分文档未设置 → fallback 到 CUID |
