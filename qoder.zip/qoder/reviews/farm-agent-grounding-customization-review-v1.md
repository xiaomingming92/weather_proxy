# farm-agent Grounding Customization — Plan Review v1

> **审查时间**: 2026-06-16
> 
> **关联 Plan**: [farm-agent-grounding-customization-plan-v1.md](../plans/farm-agent-grounding-customization-plan-v1.md)

---

## 0. 审查范围

本 Review 对 Plan `farm-agent-grounding-customization-plan-v1` 进行四维结构化评审，覆盖方向判定、覆盖完整性、可行性、风险。

Plan 目标：构建文档→Expert Collection 的显式映射管理系统，替代 `kb-sync-expert-collections.ts` 中纯文件名关键词推断，使 Expert Grounding 在 per-collection 维度上可配置、可追溯。

---

## 1. 方向判定

### 1.1 问题定位——认可

Plan 识别的五个缺陷维度准确：

| # | 缺陷 | 认可 |
|---|------|------|
| D1 | 纯文件名关键词推断 → 不可控、不可见、不可改 | ✅ |
| D2 | weather_impact / roi_analysis 永久为空（无匹配关键词文档） | ✅ |
| D3 | 上传时无法指定文档归属 Expert Collection | ✅ |
| D4 | syncKnowledgeBase 向量化后不自动写 expert collections | ✅ |
| D5 | 无 API 可查询/编辑文档→expert 映射关系 | ✅ |

### 1.2 修复方向——认可

| 修复 | 位置 | 评价 |
|------|------|------|
| 上传接口接收 `grounding` 字段 | `upload/route.ts` | ✅ 最小改动，FormData 追加字段，向后兼容 |
| grounding CRUD API（3 端点） | `documents/[id]/grounding`, `grounding/batch`, `grounding/stats` | ✅ RESTful，粒度合理 |
| syncKnowledgeBase 自动联动 | `knowledge-sync.ts` | ✅ 消除"手动跑脚本"步骤 |
| sync 脚本优先级链 | `kb-sync-expert-collections.ts` | ✅ expertId 映射 > cateId 路由 > 关键词 fallback |
| customization 前端页面 | agrisynapse `index.vue` | ✅ 复用现有文档列表组件 |

### 1.3 expertId vs cateId 分层——认可

Plan 澄清了 expertId（Registry key）与 collectionName（ChromaDB name）的映射关系，用户操作层用 expertId，内部解析层用 registry 映射。这避免了将 ChromaDB collection 名直接暴露给用户。

---

## 2. 覆盖完整性

### 2.1 数据模型/类型定义

| 项 | 覆盖 | 备注 |
|----|------|------|
| `DocumentGrounding` 接口 | ✅ | expertIds(ExpertId[])、domains(CateId[])、priority、manualOverride |
| ExpertId 联合类型 | ✅ | 11 个专家，与 Registry 一致 |
| CateId 联合类型 | ✅ | 6 个 cateId，与 CATEGORY_KEYWORDS 一致 |
| API 请求/响应类型 | ⚠️ | **P1** — Plan 只描述了 API 路径和 body 结构，未给出完整 TypeScript 类型定义 | 
| 新增 `metadata.grounding` 与存量文档兼容性 | ✅ | 字段 optional，存量文档 metadata 无 grounding → undefined → 走 fallback |
| expertId → collectionName 解析函数类型 | ⚠️ | **P2** — Plan 描述了映射逻辑但未给出 `resolveExpertIdToCollection(expertId: ExpertId): string` 的完整签名和错误处理 |

### 2.2 API 签名/函数接口

| 端点 | 覆盖 | 备注 |
|------|------|------|
| `POST /api/knowledge/upload` (+grounding) | ✅ | FormData 兼容，grounding 为可选 JSON 字符串 |
| `PUT /.../documents/:id/grounding` | ✅ | 单文档编辑 |
| `POST /.../grounding/batch` | ✅ | add/replace/remove 三种 mode |
| `GET /.../grounding/stats` | ✅ | per-collection 统计 |
| `syncExpertCollectionsForDoc(docId, grounding)` | ⚠️ | **P1** — Plan 提到但未给出完整的函数签名、返回值、错误处理 |
| `resolveDocGrounding(docMeta)` 复用函数 | ⚠️ | **P1** — 被 Task 2 和 Task 3 共享，函数签名和导出方式未定义 |

### 2.3 错误路径/降级处理

| 场景 | 覆盖 | 备注 |
|------|------|------|
| grounding.expertIds 含不存在的 expertId | ⚠️ | **P1** — Plan 只写了"找不到 expert → 跳过"，未说明是否返回 warning 给前端 |
| grounding.expertIds 指向汇总专家（无 grounding） | ⚠️ | **P1** — Plan 提到解析 summaryOf 子专家，但未说明子专家不存在或也空的降级 |
| 上传时 grounding 格式非法 JSON | ❌ | **P1** — 未覆盖。应定义返回 HTTP 400 + 具体错误信息 |
| ChromaDB 写入 expert collection 失败 | ❌ | **P1** — syncExpertCollectionsForDoc 故障时是静默跳过还是抛出阻塞同步全流程？ |
| syncKnowledgeBase 新索引 0 文档 | ✅ | 无文档 → 不调用 syncExpertCollectionsForDoc，无副作用 |
| 存量已索引文档（无 grounding metadata） | ✅ | grounding 为 undefined → 走关键词 fallback，不影响现有行为 |
| 并发编辑 grounding（两个管理员同时改同一文档） | ❌ | **P2** — 未考虑 last-write-wins 可能丢数据 |

### 2.4 数据迁移策略

| 项 | 覆盖 | 备注 |
|----|------|------|
| Schema 变更 | ✅ | 零 Schema 变更，复用 metadata JSON 字段 |
| 存量文档 | ✅ | 无 grounding → fallback 到关键词推断，行为不变 |
| Expert Collection 去重 | ❌ | **P1** — syncExpertCollectionsForDoc 每次同步会追加向量到 expert collection，重复同步是否会产生重复向量？需要检查或加幂等保证。 |
| 同步后旧 grounding 配置变更 | ⚠️ | **P2** — 如果用户改了 grounding.expertIds 后再同步，旧 collection 中的向量是否应删除？Plan 未覆盖"删除旧归属"逻辑。 |

### 2.5 存储/索引成本

| 项 | 覆盖 | 备注 |
|----|------|------|
| metadata 字段大小 | ✅ | grounding JSON < 1KB/文档，可忽略 |
| Expert Collection 向量存储增长 | ⚠️ | **P2** — 每篇文档被指派给多个 expert 时，会在每个 expert collection 存一份向量副本。极端情况 433 文档 × 7 collections = 3031 份向量（当前已发生）。建议加 warning 阈值提示 |
| ChromaDB 写入 QPS | ⚠️ | **P2** — 大文件向量化 + expert collection 同步串行执行，433 文档的 sync 耗时可能较长。Plan 未给出超时/批次控制策略 |

---

## 3. 可行性评估

### 3.1 技术可行性——高

- 所有改动均在现有模块内扩展，不引入新依赖
- API 路由复用 Next.js App Router 模式
- 前端复用 ElTablePlus + Form 组件
- expertId → collectionName 映射直接读 Registry 静态对象，无需额外查询

### 3.2 实施风险

| 风险 | 严重度 | 缓解 |
|------|--------|------|
| Task 2（sync 自动联动）引入 ChromaDB 写入性能回归 | 中 | 增加批次控制 + 异步队列 |
| expertId 类型与 Registry 不同步（新增专家时漏更新类型） | 低 | ExpertId 类型可从 Registry 自动推导（`keyof typeof ANALYSIS_EXPERTS`） |
| 前端页面复杂度失控（文档列表 + 筛选 + 编辑 + 批量 + 同步） | 中 | 按 Task 拆分，先做 API 再做页面 |

---

## 4. 决策结论

### 4.1 通过项

- 方向正确：expertId 映射 + cateId 路由 + 关键词 fallback 三层优先级链合理
- 架构简洁：零 Schema 变更，复用 metadata JSON + Registry 静态映射
- 闭环完整：上传指派 → 同步自动联动 → 事后编辑 + 覆盖率统计

### 4.2 需修正项（P0 — 阻塞进入 Step 1）

1. **错误路径覆盖不足**：Plan 须补充以下场景的处理策略：
   - grounding.expertIds 含非法值 → 返回 400 + 具体错误信息
   - `syncExpertCollectionsForDoc` ChromaDB 写入失败 → 记录错误日志 + 继续其他 collection
   - grounding 格式非法 → 400 Bad Request
2. **Expert Collection 幂等写入**：须说明重复同步是否产生重复向量。建议方案：同步前先查询 collection 是否已有该 docId，有则 skip。
3. **`syncExpertCollectionsForDoc` 和 `resolveDocGrounding` 的完整函数签名**：作为被 Task 2/3 共享的函数，须在 Plan 中定义完整签名。

### 4.3 建议改进项（P1 — 不阻塞进入 Step 1，Review 回流时补充）

1. API 请求/响应的完整 TypeScript 类型应放入 Specs
2. 同步后"删除旧归属"逻辑应在后续版本中补充
3. Expert Collection 向量副本数应加监控阈值

---

## 5. 影响评估

### 5.1 受影响文件

| 文件 | 改动类型 | 风险 |
|------|---------|------|
| `src/app/api/knowledge/upload/route.ts` | 修改（追加字段） | 低 |
| `src/app/api/knowledge/documents/[id]/grounding/route.ts` | 新增 | 低 |
| `src/app/api/knowledge/grounding/batch/route.ts` | 新增 | 低 |
| `src/app/api/knowledge/grounding/stats/route.ts` | 新增 | 低 |
| `src/services/knowledge-sync.ts` | 修改（追加函数） | 中 |
| `scripts/kb-sync-expert-collections.ts` | 修改（优先级链） | 中 |
| agrisynapse `src/views/llm/customization/index.vue` | 重写 | 中 |

### 5.2 数据流影响

- 上传流：不变，仅追加 grounding 字段
- 同步流：新增 expert collection 写入步骤（syncKnowledgeBase 调用链变长）
- 查询流：无影响（grounding 存储在 metadata，不影响 RAG 检索路径）

### 5.3 回滚风险

- **低风险**：API 新增不影响现有端点；metadata.grounding 字段 optional，存量无此字段
- **中风险**：syncKnowledgeBase 新增 expert collection 联动，若回滚需确认无半截写入

---

## 6. 下一步

1. **P0 项回流至 Plan**（0.6.5 卡位）— 补充错误路径、幂等策略、函数签名
2. 生成 Specs 三元组（spec.md + tasks.md + checklist.md）
3. 打 DPS 门禁（target ≥ 85）
4. 进入 Step 1（生成 add-route）
