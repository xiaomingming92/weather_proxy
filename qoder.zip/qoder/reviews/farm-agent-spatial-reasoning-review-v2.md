# farm-agent-spatial-reasoning-review-v2

## Review 元信息

- **Review 对象**: `farm-agent-spatial-reasoning-plan-v2.md`
- **Review 时间**: 2026-07-13
- **Review 类型**: 架构设计 + 方案选型 + 合规检查
- **前置阅读**:
  - Plan: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-plan-v2.md`
  - 前置 Plan: `.qoder/plans/2026-07/06/farm-agent-project-massif-resolution-plan-v1.md`
  - 前置 Plan: `.qoder/plans/2026-07/06/farm-agent-professional-fanout-plan-v1.md`
  - 前置 Plan: `.qoder/plans/2026-07/04/farm-agent-thinking-level-runtime-fix-plan-v1.md`
  - Handoff: `.qoder/plans/2026-07/07/farm-agent-spatial-reasoning-handoff-v1.md`（Step 8 收敛后生成）

---

## 1. 问题复现

### 1.1 为什么需要这次改造

Plan 的根因分析（§一）精准地指出了前三个 Plan 的共同盲区：**数据可达性 ≠ 数据可用性**。

```
project-massif-resolution → 解决"不缺参"（工具调用 massifId 不为空）
professional-fanout       → 解决"可并行"（Send API fan-out）
thinking-level-runtime-fix → 解决"路由可达"（professional 图可被执行）
                              ↓
                         但仍然没解决"LLM 能看到什么"
```

核心矛盾定位准确（§1.2）：`state.toolResults` 已有完整结构化契约，但 `reasoning.ts` 消费的是 `state.messages` 中的 ToolMessage 字符串 + `slice(0, 200)` 截断。per-expert-reasoning.ts 无截断但全量 JSON 注入导致信息过载。

### 1.2 两种图的问题差异化分析

Plan §2.2 对 deep 图和 professional 图的问题做了精确区分：

| 图 | 截断方式 | LLM 看到什么 | 问题本质 |
|----|---------|-------------|---------|
| deep (reasoning.ts) | `slice(0,200)` 硬截断 | 第一条记录碎片 JSON | 信息不足 |
| professional (per-expert-reasoning.ts) | 无截断，全量 JSON | 200 条完整 JSON blob | 信息过载 |

这个区分很重要——说明问题不是简单的"加空间数据"能解决，需要结构化的聚合层。Plan 正确地识别了这一点。

---

## 2. 方案评估

### 2.1 方案选型 ✅

**两层空间推理模型（§2.0）：Voronoi（几何层）+ FCM（分析分区层）**

这是审阅的核心亮点。Plan 没有简单地把坐标数据塞进 prompt，而是设计了两个互补的计算层：

- **几何层（Voronoi）**：回答"传感器管哪块地"——纯几何问题，Fortune's Algorithm O(n log n)
- **分析分区层（FCM）**：回答"哪些地应该一起管"——数据分析问题，PCA + FCM 聚类

两层各自的输入/输出/用途分离清晰，算法选择有行业文献支撑（§2.0.1, §2.0.2）。

**关于方案选择的判断**：✅ 正确。Voronoi + FCM 组合在精准农业领域有扎实的学术基础（Nature 2025、农业工程学报 2025），不是凭空设计。

### 2.2 架构设计 ✅

**图拓扑设计（§3.0）**：

- deep 图新增 3 个节点（`spatialPreprocessing` → `summaryRetrieval` → `summaryReasoning`），在 `toolNode → intention` 循环完成后进入，保证了 toolResults 完整性
- professional 图不变——职责边界清晰，per-expert 的改造仅限于 prompt 层消费 spatialRegions
- 两种图的分工表（§3.0.3）明确了各自场景、推理模式、空间预处理使用情况

**数据装订链路（§八，5 层模型）**：完整且可审计。

### 2.3 降级策略 ✅

Plan §6.2 给出了完整的降级矩阵：

| 依赖失败 | 降级行为 |
|---------|---------|
| Farm-Server /massif/options API 不可用 | spatialRegions = null → 回退现有逻辑 |
| Farm-Server /equipment/page API 不可用 | 无传感器时每个地块独立成区域 |
| spatialRegions 为空 | 所有改造路径回退，行为与当前一致 |
| spatialContext 为 undefined | factory.ts 行为不变 |

这是嵌入式路径演化的核心原则——新能力在已有路径内增强，失败时静默降级。✅

### 2.4 存储/索引成本 ✅

**零新增持久化成本**。spatialRegions 和 managementZones 仅存在于 state（Annotation），不涉及数据库表、不新增索引、不引入新持久化层。数据生命周期与单次 Agent 调用绑定，无需 GC 策略。

---

## 3. P0 阻断性问题

### P0-1: 缺少 Spec / Tasks / Checklist 三件套

Plan 元信息（§PLAN 元信息）中 ADD-7 审计策略表覆盖了所有文件的 targetType/action/beforeState/afterState，但没有关联 Spec、Tasks、Checklist 文档。根据 ADD 文档工程化规范，Plan 文档生成后应同步生成这三件套。

**影响**：6 轮 17 个文件改动，没有 tasks.md 时实施容易遗漏步骤；没有 checklist 时验收缺乏结构化依据。

**建议**：实施前补充三件套文档（可在 Plan 中注明为后续补充并先发 Review）。

### P0-2: `d3-delaunay` 服务端兼容性未验证

Plan §3.2 推荐使用 `d3-delaunay` npm 包实现 Voronoi 图计算。但 `d3-delaunay` 是基于浏览器的 Delaunay 三角剖分库，依赖 `d3-array` 等 d3 生态——需要确认它能否在 Node.js 环境下运行（无 DOM/Canvas API 依赖）。

**风险**：
- `d3-delaunay` 的 `Delaunay.from()` 接受 `ArrayLike<number>` 扁平数组，本身不依赖 DOM——理论可行
- 但 `voronoi.render()` 等方法需要 Canvas context——如果代码被 import 时触发副作用可能报错
- Plan 推荐方案表中说"依赖较重，需要 turf 全家桶"来否定 `@turf/voronoi`，但实际上 `d3-delaunay` 对 Node.js 的适配也可能有坑

**建议**：第 1 轮开始前，先在 Node.js 环境下写最小验证脚本：`import { Delaunay } from "d3-delaunay"; Delaunay.from([0,0,1,0,0.5,1]).voronoi([0,0,400,400])`，确认不报错。

### P0-3: professional 图不经过 spatialPreprocessing，但拟消费 spatialRegions

Plan §3.0.2 明确说"professional 图不变"，§3.0.3 表中也写了 professional 图"不经过 spatialPreprocessing"。但在 §七改造方案中，`per-expert-reasoning.ts` 要从 `state.spatialRegions` 读取空间上下文并注入 prompt。

**矛盾点**：如果 spatialPreprocessing 只在 deep 图中执行，professional 图的 state 中 `spatialRegions` 始终为 null（初始值）。那么 per-expert-reasoning 注入的空间上下文永远是空的。

**两种解**：
- 方案 A：professional 图也接入 spatialPreprocessing（在 per-expert fan-out 之前）
- 方案 B：professional 图放弃消费 spatialRegions，仅 deep 图汇总专家使用

需要明确选择并更新 Plan，不能保持模糊。

### P0-4: FCM 聚类输入特征矩阵定义缺失

Plan §3.1 和 §九第 1 轮 task 说 `computeManagementZones(toolResults, voronoiRegions)` 做 PCA 降维 + FCM 聚类，但没有定义输入特征矩阵的构造方式：

- **多源数据如何合并为统一特征矩阵？** 虫情（数量、趋势）、土墒（湿度百分比）、气象（温度、降雨量）的量纲完全不同
- **PCA 降维保留多少个主成分？** 解释方差阈值是多少？
- **最优分区数如何确定？** XB 指数？轮廓系数？还是固定 3 类？

这些细节决定 FCM 输出的管理分区是否有实际意义。建议在 spatial/fcm.ts 的 task 中补充特征工程规范。

---

## 4. P1 重要问题

### P1-1: `routeByIntent` 新增 `spatialPreprocessing` 路由条件未定义

Plan §3.0.1 代码示例中：

```typescript
.addConditionalEdges("intention", routeByIntent, [
  "toolNode", "retrieval", "response", "spatialPreprocessing"
])
```

但没有说明 `routeByIntent` 内部何时路由到 `spatialPreprocessing` 而非其他节点。从 Plan 描述看应该是"toolNode → intention 循环中 LLM 确认数据足够后"，但在 intention 节点的路由逻辑中如何判断"数据已足够"？（当前是否有 `state.confirmDataComplete` 标记？）

**建议**：补充路由条件伪代码，明确判断逻辑。

### P1-2: `aggregateToolResults` 假设所有 toolResults 都有 `massifName` 字段

Plan §3.3 伪代码中：

```typescript
const massifName = record.massifName as string
if (!massifName) continue
```

但并非所有工具返回的数据都有 `massifName`——例如 `query_farm_weather` 可能返回站点级气象数据（没有地块维度），`query_farming_operation` 可能返回农事操作记录（按操作日期而非地块）。这些数据的按区域聚合逻辑需要不同的 fallback 策略。

**建议**：为无 massifName 字段的 toolResult 定义降级聚合策略（如按时间窗口聚合、按传感器 ID 聚合），避免静默丢弃数据。

### P1-3: LangGraph Checkpointer 序列化兼容性

`state.spatialRegions` 和 `state.managementZones` 作为新增的 Annotation 字段，会在 LangGraph checkpoint 中被序列化。需要确认：

- `VoronoiRegion.polygon`（坐标数组）和 `ManagementZone` 对象能否被 LangGraph 的 JSON serializer 正确序列化/反序列化
- 如果 Checkpointer 使用 PostgresSaver，嵌套对象是否有字段类型兼容问题

**建议**：在第 1 轮 state 扩展后，写一个序列化往返测试（`JSON.parse(JSON.stringify(region))` 后结构不丢失）。

### P1-4: 第 5 轮 response.ts 的 `isSummary` 分支扩展了原定 scope

Plan §九第 5 轮新增了 `isSummary` 分支逻辑：「消费 `expert.reportTemplate` 章节定义替代 `strategy.sections`」「`buildStreamingTextPrompt` 使用汇总专家专用 prompt 模板」。这些改动涉及 `responseNode` 的 prompt 构建策略，不只是加一个 `regionBreakdown` 字段。

**风险**：response.ts 是用户可见输出的最后装订层，改 prompt 构建逻辑可能影响所有 deep 图汇总专家的输出格式。建议评估是否需要独立的 response 节点（如 `summaryResponse`），而不是在现有 `responseNode` 中加分支。

### P1-5: 第 4 轮 reasoning.ts 改造与现有 deep 图单专家路径的兼容性

Plan 说 reasoning.ts "仅删除 `contentStr.slice(0, 200)` 截断，改用 `state.toolResults` 结构化数据"。但有两点需要确认：

1. **deep 图的单专家路径是否仍然经过 reasoning.ts？** 如果 deep 图新增了 `summaryReasoning` 替代 reasoning.ts，那 reasoning.ts 的改造是否还必要？
2. **`toolResults` 为空时的回退逻辑**是否真的与当前一致？当前用 ToolMessage 字符串，改造后用 toolResults 结构化数据——两者数据源不同，回退到空的语义也可能不同。

---

## 5. P2 改进建议

### P2-1: Voronoi 算法选型对小 n 的过度设计

Plan §3.2 说"n = 传感器数量 (通常 3-10 个)"。对于 n ≤ 10 的规模，Fortune's Algorithm O(n log n) 和暴力 O(n²) 在实际运行时间上几乎没有差异（差异在微秒级）。引入 d3-delaunay 增加了 npm 依赖（含 d3-array、delaunator 等传递依赖），但收益有限。

**建议**：考虑手写简化版 Voronoi（n 很小，仅需 point-in-cell 判断），减少依赖。但如果 d3-delaunay 已被验证可用且体积可接受，也无需纠结——保持当前方案即可。

### P2-2: CGCS2000 → WGS-84 近似标注需要更谨慎

Plan §九第 1 轮任务中注释："Farm-Server 使用天地图 CGCS2000 坐标系（≈ WGS-84，偏差 < 1m），农业场景下可直接当 WGS-84 使用"。

对于 Voronoi 覆盖判断（判断一个地块重心点是否在某个传感器覆盖区域），1m 偏差确实可忽略。但建议在代码注释中保留这个说明，避免后续其他模块（如无人机航线规划需要亚米级精度）复用 spatial lib 时忽略坐标系差异。

### P2-3: Token 预算分析不包含多 tool 聚合

Plan §5.4 Token 预算分析中"空间推理上下文 (4 区域) ~500 tokens"是基于单 toolResult 聚合的估算。实际场景中 deep 图汇总专家会调 3+ 个工具（虫情 + 土墒 + 气象），每个工具产出都需要在空间上下文中体现，token 会线性增长。

**建议**：增加多 tool 并行场景的 token 预算分析（3 个工具 × 4 区域 = 1200 tokens 空间上下文），确认在上下文窗口内仍可接受。

### P2-4: 缺少空间计算的性能基准

Voronoi + FCM 计算（含 Farm-Server API 调用）是同步阻塞在 pipeline 中的，会延长首 token 响应时间（TTFT）。建议在实施后记录以下指标：

| 场景 | Voronoi 计算 | FCM 计算 | Farm-Server API 调用 | 总延时 |
|------|:-----------:|:--------:|:-------------------:|:-----:|
| 3 地块 + 2 传感器 | < 50ms | < 100ms | ~200ms | ~350ms |
| 20 地块 + 10 传感器 | ? | ? | ? | ? |

### P2-5: 缺少对汇总专家 `expertId` 的定义

Plan 多处引用"汇总专家"，但没有定义其 `expertId`（是 `"daily_report"` 还是 `"summary"` 还是其他？）。汇总专家在 `expertRegistry` 中是否需要注册？其 `isSummary` 标记字段从哪里来？

---

## 6. 决策结论

| 维度 | 评价 |
|------|------|
| 问题识别 | ✅ 精准——根因分析从 3 个前置 Plan 的盲区出发，区分了 deep/professional 两种图的不同问题形态 |
| 方案选型 | ✅ Voronoi + FCM 两层互补，学术基础扎实，行业对标清晰 |
| 架构设计 | ✅ 图拓扑 + 数据装订 5 层模型 + 降级矩阵完整 |
| 行业对标 | ✅ 6 点需求 × 对应算法 × 学术来源，论证充分 |
| professional 图 spatialRegions 来源 | ❌ 矛盾——不经过 spatialPreprocessing 但拟消费 spatialRegions — P0 |
| FCM 特征工程 | ❌ 输入矩阵构造方式未定义 — P0 |
| d3-delaunay 服务端兼容 | ⚠️ 未经验证 — P0 |
| 文档配套 | ❌ 缺 Spec / Tasks / Checklist — P0 |
| 路由条件 | ⚠️ intention → spatialPreprocessing 判断逻辑未定义 — P1 |
| 数据字段兼容 | ⚠️ 非 massifName 工具的聚合策略缺失 — P1 |
| 风险覆盖 | ✅ 6.2 降级矩阵 + §八保真度分析 + 回退路径 |

**结论**：方案方向正确，Voronoi + FCM 双层空间推理模型是解决全农场分析信息碎片化的正确方向。**4 条 P0 问题需在进入实施前解决**，其中 P0-3（professional 图 spatialRegions 来源矛盾）是架构级问题，需要明确两条路径：

- 要么 professional 图也接入 spatialPreprocessing
- 要么 professional 图放弃消费 spatialRegions，仅 deep 图使用

---

## 7. 受影响文件（回流预期）

| 文件 | 需要修改的内容 |
|------|--------------|
| `farm-agent-spatial-reasoning-plan-v2.md` | ① 明确 professional 图 spatialRegions 来源（P0-3）；② 补充 FCM 特征矩阵构造规范（P0-4）；③ 补充 d3-delaunay Node.js 兼容性验证结果（P0-2）；④ 定义 intention → spatialPreprocessing 路由条件（P1-1）；⑤ 为非 massifName 工具补充聚合降级策略（P1-2） |
| `farm-agent-spatial-reasoning-spec-v2.md` | 新建 Spec（P0-1） |
| `farm-agent-spatial-reasoning-tasks-v2.md` | 新建 Tasks（P0-1） |
| `farm-agent-spatial-reasoning-checklist-v2.md` | 新建 Checklist（P0-1） |

---

## 8. 回流结果（2026-07-15 执行）

> 以下逐条记录 Review 每项结论的回流状态：已解决 / 待决策 / 未解决 / 不适用。

### P0 阻断性问题 回流状态

| # | 问题 | 状态 | 回流说明 |
|:--:|------|:--:|------|
| P0-1 | 缺少 Spec / Tasks / Checklist 三件套 | ✅ 已解决 | `spec.md`（798行）、`tasks.md`（133行）、`checklist.md`（126行）已存在于 `.qoder/specs/farm-agent-spatial-reasoning/`。checklist 含 10 大类 [T]/[R]/[E]/[H] 验证项，覆盖 Voronoi/FCM/降级/审计全链路 |
| P0-2 | `d3-delaunay` 服务端兼容性未验证 | ⚠️ 待第1轮前验证 | Review 建议的最小验证脚本（`Delaunay.from([0,0,1,0,0.5,1]).voronoi([0,0,400,400])`）尚未执行。**阻塞判定**：第 1 轮实施前必须跑通此脚本，若失败则改用方案 B（手写简化 Voronoi for n≤10） |
| P0-3 | professional 图不经过 spatialPreprocessing 但拟消费 spatialRegions | ✅ 已决策 | **决策**：professional 图暂不消费 spatialRegions，仅 deep 图使用。per-expert-reasoning 改造收缩为仅消费 toolResults 结构化数据，不注入空间上下文。待 deep 图周报/日报效果验证后，再评估 professional 图是否需要 |
| P0-4 | FCM 聚类输入特征矩阵定义缺失 | ✅ 已解决 | spec.md Phase 1 algorithm steps 已含 10 步算法细节。**检索策略同步决策**：不硬编码 cateId，改用 registry 的 `grounding.collectionName` + `summaryExpertIds`（ExpertId 类型安全）做跨 collection 联合检索。Plan §十一 文件清单已新增 `registry.ts`（+ `EXPERT_IDS` / `ExpertId` / `summaryExpertIds`）、`weekly-report.config.ts`、`daily-report.config.ts` 三项改动 |

### P1 重要问题 回流状态

| # | 问题 | 状态 | 回流说明 |
|:--:|------|:--:|------|
| P1-1 | `routeByIntent` 新增 `spatialPreprocessing` 路由条件未定义 | ✅ 已解决 | Plan §3.0.1 已补充路由条件伪代码：`thinkingLevel==="deep" && 无 tool_calls && toolResults.length > 0 → spatialPreprocessing` |
| P1-2 | `aggregateToolResults` 假设所有 toolResults 都有 `massifName` 字段 | ✅ 已解决 | 经 Farm-Server API 文档 + farm-data-tools.ts 代码双重验证：三个数据工具（soil_moisture/insect_data/farm_weather）均使用 `getPage` 端点，响应不返回 massifId/massifName，仅有 equipmentId/equipmentName。Spec Phase 1 FCM 步骤1 改为按 equipmentId 分组 → Voronoi 归因；Phase 4 per-expert 同样改为 equipmentId → spatialRegions 归因。虫情 at/ah 字段需 ÷10 还原实际值（API-1）| 
| P1-3 | LangGraph Checkpointer 序列化兼容性 | ✅ 已解决 | tasks.md Task 1.4 已增加序列化往返测试子任务：`JSON.parse(JSON.stringify(region))` 验证 VoronoiRegion.polygon 和 ManagementZone.membershipMatrix 不丢失 |
| P1-4 | 第 5 轮 response.ts 的 `isSummary` 分支扩展了原定 scope | 🟡 已评估 | Review 建议评估是否需要独立 `summaryResponse` 节点。**决策**：暂不拆分独立 response 节点。理由：① 改动量 ~30 行，可控；② `isSummary` 分支仅影响 prompt 构建策略，不影响 SSE 流式输出协议；③ 如果后续汇总专家的输出格式频繁变化，再提取独立节点。**风险**：response.ts 是最终装订层，修改需额外回归测试 existing deep 图单专家路径 |
| P1-5 | 第 4 轮 reasoning.ts 改造与现有 deep 图单专家路径兼容性 | 🟡 已评估 | 两个确认点：① deep 图新增 summaryReasoning **不替代** reasoning.ts——summaryReasoning 是汇总专家专用，单专家路径仍走现有 reasoning.ts → interactionPointDetection。两者并存于 deep 图中，由 intention 路由分支。② `toolResults` 为空时回退逻辑：改造前用 ToolMessage 字符串，改造后用 toolResults 结构化数据——若两者都为空的语义一致（都表示"无工具数据"），则回退等效 |

### P2 改进建议 回流状态

| # | 建议 | 处置 |
|:--:|------|------|
| P2-1 | Voronoi 对小 n 的过度设计 | 📝 记录，不强制修改。若 P0-2 d3-delaunay 兼容性验证失败，自然回退到手写简化版 |
| P2-2 | CGCS2000 → WGS-84 注释保留 | ✅ 已落实。spec.md §Boundaries 和 coordinate-transform.ts 接口注释中均已保留坐标系说明 |
| P2-3 | Token 预算多 tool 场景 | 📝 记录。当前 §5.4 仅估算了单 tool（~500 tokens）。3 tools × 4 区域 ≈ 1200 tokens，仍在 64K 窗口内安全。建议实施后在 checklist 中增加"3 tools 场景 token < 2000"验证项 |
| P2-4 | 空间计算性能基准 | 📝 记录。建议在第 6 轮手动验证时记录 TTFT 增量 |
| P2-5 | 汇总专家 `expertId` 定义 | 📝 记录。Plan §3.0.1 用了 `explicitExpertId = "daily_report"`，但未在 expertRegistry 中注册。建议在实施时确认 expertId |

### Farm-Server API 验证新发现（2026-07-16 回流新增）

> 实际阅读 Farm-Server API 文档 + farm-data-tools.ts 代码后的发现。

| # | 发现 | 状态 | 回流说明 |
|:--:|------|:--:|------|
| **API-1** | 虫情 `at`/`ah` 字段需 ÷10 归一化 | ✅ 已解决 | API 文档明确注释：温度/湿度值为乘以 10 后的结果。FCM 聚类前不除以 10 会导致量纲偏差 10×，扭曲 PCA 主成分。Spec Phase 1 FCM 步骤 1 已增加单位归一化说明 |
| **API-2** | equipment `status` 是字符串 | ✅ 已解决 | API 文档：`status`: string — "0"=开启。Spec Phase 2 中已写 `status="0"` 字符串比较，与 API 一致，无需额外修改 |
| **API-3** | `getPage` 端点不返回 massifId/massifName | ✅ 已解决 | 三个数据工具实际使用的端点（farm-data-tools.ts L191/L237/L323）均为 `/getPage`，响应仅有 equipmentId/equipmentName。此发现直接导致 P1-2 从"假设缺失"升级为"确认缺失"，聚合策略从 massifName 分组改为 equipmentId → Voronoi 归因 |

### 回流后仍待执行的行动项

| # | 行动项 | 状态 | 说明 |
|:--:|------|:--:|------|
| 1 | **P0-2**（第1轮前）：执行 d3-delaunay Node.js 最小验证脚本 | ⬜ 实施阶段 | 非文档问题，属实施前验证 |
| 2 | **P0-4**：在 spec 或 types.ts 中补充 `ToolResultRecord` 接口定义 | ⬜ 实施阶段 | 代码实现细节，第1轮 types.ts 创建时同步完成 |
| ~~3~~ | ~~P0-3：professional 图 spatialRegions 方案~~ | ✅ 已决策 | professional 图暂不消费，仅 deep 图使用 |
| ~~4~~ | ~~P1-1：routeByIntent 路由条件~~ | ✅ 已回流 | Plan §3.0.1 已补充三条件判断伪代码 |
| ~~5~~ | ~~P1-2：非 massifName 工具降级策略~~ | ✅ 已回流 | Spec Phase 1 FCM + Phase 4 per-expert 改为 equipmentId → Voronoi 归因 |
| ~~6~~ | ~~P1-3：checkpoint 序列化测试~~ | ✅ 已回流 | tasks.md Task 1.4 已增加往返测试子任务 |

---

## 10. 架构讨论回流（2026-07-16 — 觉知注入层 + GlobalState 第八域）

> 实施过程中发现 Plan 在空间数据的消费路径上存在设计真空。以下为讨论后达成的决策。

### P0-新发现: 空间数据只有生产没有消费通道

**现象**：spatialRegions/managementZones 存在 AgentState（thread 级 Checkpointer）中，但 LLM 上下文窗口是滑动窗口——多轮对话后，LLM 完全不知道农场空间结构。且跨 thread 不共享，同用户新对话需重算一次。

**决策 1: 每轮 prompt 固定注入觉知文本（不是让 LLM 记）**

以 weekly_report（汇总专家）为例——同一 digest 每轮注入：

```
Turn 1: [空间: 3区 — 低湿区虫↑/过渡区→/高燥区↓] [用户: 虫情?]
Turn 2: [空间: 3区 — 低湿区虫↑/过渡区→/高燥区↓] [用户: 低湿区怎么办?]
Turn 3: [空间: 3区 — 低湿区虫↑/过渡区→/高燥区↓] [用户: 上个方案呢?]
```
LLM 不需要"联想"——每轮 prompt 头部固定位置注入同一 digest。

**但不同 expert 的 digest 内容不同——按传感器类型过滤 + 按农场复杂度分级：**

| Expert | 传感器过滤 | 觉知内容 | token |
|--------|:---:|------|:---:|
| `pest_risk` | insect only | `虫情测报灯覆盖 9 块地，虫↑湿78%` | ~20 |
| `weather_impact` | weather only | `气象站覆盖 5 块地，本周降雨 45mm` | ~30 |
| `daily_report` / `weekly_report`（summary） | all | 完整三区划分 + 四情联动 | ~150 |
| `crop_compare` / `roi` / `machinery` | all | 微型：`23 块地，3 分区` | ~15 |
| `land_analysis` | all | 标准：分区 + 地块归属 | ~80 |

**digest 自适应分级（T0-T3）——按分区数 + 每区地块数自动选择：**

> 格式设计原则（websearch 验证，Context Engineering 最佳实践）：
> ① 结构化 > 自由文本 —— LLM 解析表格/键值对比解析段落更准确，token 效率更高
> ② 最小高信号 —— 每行一个分区，每列一个维度，不塞无关字段
> ③ 前置固定区 —— digest 注入 system message 区域（持久 DNA），不混入对话历史
> ④ 注意力预算 —— 总行数 ≤ 15 行，LLM "context 超过 800 行开始忽略指令"

| 级别 | 触发条件 | 格式（结构化表格，非自由文本） | token |
|:---:|------|------|:---:|
| T0 | 地块=1，无分区 | `[农场] 地块: 鼎和-地块001` | ~8 |
| T1 | 地块≤10，无分区（Voronoi 传感器分组） | `[农场] 地块:8 传感器:5(气象2/土墒2/虫情1) 分区:3(传感器)` | ~15 |
| T2 | 分区>1，每区≤10块 | 结构化表格（见下方示例） | ~50 |
| T3 | 分区>1，某区>10块 | 表格 + 地块列表折叠为 `[...N块]` | ~60 |

**T2/T3 标准格式（Context Engineering 推荐结构化格式）：**

```
[农场空间] 地块:23 传感器:47(气象11/土墒26/虫情10) 分区:3
──────────────────────────
分区            地块数 虫情 湿度  代表地块
低湿区(虫害高风险)   9   ↑  78%  鼎和-001,335,路南西
过渡区             7   →  55%  农科所-花生,路北东
高燥区             7   ↓  42%  南农大-罡杨,好润-001
──────────────────────────
```

> 对比旧格式（自由文本 ~150 token）：信息密度提升 3×，LLM 注意力集中在行列结构而非解析自然语言。per-expert 过滤时只保留相关传感器类型行（pest_risk 只看虫情列 + 代表地块列）。

**per-expert TTL 表——不同专家不同刷新周期：**

| Expert | TTL | 原因 |
|--------|:---:|------|
| `daily_report` | 1h | 日报需逐时趋势 |
| `weekly_report` | 1d | 周报看日均，小时噪声无意义 |
| `pest_risk`（常规） | 1h | 虫情监测按小时 |
| `pest_risk`（爆发期） | 30min | 定向风险报告需高频跟踪 |
| `weather_impact` | 1h | 气象变化按小时 |
| `crop_compare` / `roi` | 1d | 作物生长、成本都是天级 |
| `land_analysis` | -1 | 土壤/地形不变，永不刷新 |

### P1-新发现: FCM 聚类地块数下限未定义

**现象**：当前代码 `n < 3` 时返回单一"全农场"分区。但 n=3~9 的灰色地带，PCA 仅提取 2-3 个成分，FCM 分 2-3 类区分度极低，Xie-Beni 指数在小样本下不稳定。学术论文的 FCM 管理分区研究样本量均为几十到几百块地。

**决策**：

| 地块数 n | 行为 |
|:---:|------|
| n < 10 | 跳过 FCM——直接用 Voronoi 传感器分组代替管理分区。spatialRegions 的 regionId 即为分区标识，digest 输出"传感器 S1 覆盖区(N块) / 传感器 S2 覆盖区(N块)" |
| n ≥ 10 | FCM 正常计算，产出 ManagementZone[] |

**PolicyUpdateLoop 跟踪建议**（不在本 Plan scope，留给 `global-awareness` Plan）：

> FCM 分区对 LLM 推理质量的实际影响需要运行时反馈验证。建议后续 PolicyUpdateLoop 增加维度：
> - `zone_confidence`：跟踪各 expert 推理中引用管理分区的频率与置信度关联
> - `zone_drift`：跨周/跨月比较分区稳定性，漂移过大触发重算告警
> - `small_farm_fallback`：n<10 的农场累计推理质量评分，验证降级路径是否足够
> - 若连续多周分区未被任何 expert 引用 → 自动降级为 Voronoi 传感器分组

**决策 2: GlobalState 新增第八域 `spatial`（进程级，跨 thread 共享）**

```
GlobalSystemState（八域）
  ├── chat      /  agent  /  memory  /  execution
  ├── policy    /  audit  /  feedback
  └── spatial   ★ 新增第八域
        spatialRegions: VoronoiRegion[] | null
        managementZones: ManagementZone[] | null
        spatialContextDigest: string | null
        computedAt: number        ← TTL 裁决
        sensorIds: string[]       ← diff 对比
```

spatialPreprocessing 节点计算完成后调用 `globalState.syncSpatial()` 写入，其他 thread 的 spatialPreprocessing 先查 GlobalState.spatial：TTL 未过期 + sensorIds 未变 → 直接投影到 AgentState，跳过 Farm-Server API 调用。

**决策 3: 觉知裁决与注入链**

| 组件 | 职责 |
|------|------|
| `resolveAwareness` (caijuehub) | TTL 检查 + per-expert 过滤 + 级别判定 |
| `spatialPreprocessing` 节点 | 调 Farm-Server → Voronoi + FCM → 写入 AgentState + GlobalState.spatial |
| `injectAwareness` (prompts/awareness.ts) | 读 state.spatialContextDigest → 裁剪 → 注入 prompt 头部 |

### 受影响文件（后续 Plan 需补充）

| 文件 | 操作 | 内容 |
|------|------|------|
| `src/agents/global-state.ts` | MODIFY | +`SpatialStateSnapshot` 类型 + spatial 域 default + diff 列表 + `syncSpatial()` |
| `src/agents/state.ts` | MODIFY | +`spatialContextDigest` Annotation |
| `src/agents/prompts/awareness.ts` | CREATE | `buildSpatialDigest()` + `injectAwareness()` |
| `src/caijuehub/strategies/awareness.ts` | CREATE | `resolveAwareness()` 觉知裁决 |
| `src/agents/nodes/spatial-preprocessing.ts` | MODIFY | 计算后调用 `globalState.syncSpatial()` |
| Plan + Spec + caijue.toml | MODIFY | 补充觉知注入层 + 裁决条目 |

### P1-新发现: 项目缺少 Context Engineering 管理系统与熵值量化

**现象**：觉知注入层的格式（结构化表格 vs 自由文本）、注入位置（system message 区 vs 对话区）、信息密度（token/信息量）目前靠人工判断，没有量化指标。当多个 injector（spatial、equipment、task 等）同时注入时，可能超过 LLM 注意力预算（>800 行）。

**决策**：本项目应建立 Context Engineering 管理模块，记录以下指标：

| 指标 | 说明 | 计算方式 |
|------|------|------|
| `contextEntropy` | 上下文信息熵——token 中有效信号占比 | `H = -Σ(p_i × log(p_i))`，p_i = 各注入块 token 占比。熵越高 = 信息越分散 = LLM 越难聚焦 |
| `injectionBudget` | 注入总预算 | 各 injector 声明的 maxTokens 之和 vs 预设上限（如 500 tokens） |
| `signalDensity` | 信号密度 | `(stats/variables/tables 行数) / 总行数`。paragraph 类文本 signalDensity 低 |
| `attentionDrift` | 注意力漂移 | 跟踪 LLM 推理中引用注入信息的频率。若连续 N 轮未引用 spatial digest → 降级或移除该 injector |

**Context Engineering 模块设计**（不在本 Plan scope，列给 `global-awareness` Plan）：

```
src/lib/context-engineering/
  ├── entropy.ts          — contextEntropy 计算
  ├── injector-registry.ts — 所有 injector 注册表（spatial/equipment/task/weather...）
  ├── budget-manager.ts   — injectionBudget 汇总 + 超限告警
  └── metrics.ts          — signalDensity + attentionDrift 采集
```

> 预期效果：当系统有 N 个觉知域时，budget-manager 在超限时自动裁决"哪些 injector 本轮降级/跳过"，保持 LLM 注意力预算在安全线内。

### Context Engineering ↔ PolicyUpdateLoop 预埋接口

上述四个指标不应只是观测数据——应接入 PolicyUpdateLoop，让策略层自动响应：

```typescript
// src/lib/context-engineering/types.ts（预埋接口）

interface ContextEngineeringSnapshot {
  contextEntropy: number          // 0-1，越低越好
  injectionBudget: { used: number; limit: number }
  signalDensity: number           // 0-1，越高越好
  attentionDrift: Record<string, number>  // injectorId → 连续未引用轮数
}

// PolicyUpdateLoop 新增 evaluateContext 决策函数
interface ContextPolicyAction {
  type: "downgrade" | "remove" | "upgrade" | "alert"
  injectorId: string              // 如 "spatial" / "equipment"
  reason: string                  // 如 "attentionDrift > 10 rounds"
  suggestedAction: string         // 如 "降级为 micro 级别"
}

function evaluateContextEngineering(
  snapshot: ContextEngineeringSnapshot
): ContextPolicyAction[] {
  const actions: ContextPolicyAction[] = []

  // 规则1: 熵过高 → 预算不足，降级最低优先级的 injector
  if (snapshot.contextEntropy > 0.7) {
    actions.push({ type: "downgrade", injectorId: "lowest_priority", ... })
  }

  // 规则2: 预算超限 → 紧急降级
  if (snapshot.injectionBudget.used > snapshot.injectionBudget.limit) {
    actions.push({ type: "alert", injectorId: "budget", ... })
  }

  // 规则3: 注意力漂移 → 连续 N 轮未引用 → 移除该 injector
  for (const [injectorId, driftCount] of Object.entries(snapshot.attentionDrift)) {
    if (driftCount > 10) {
      actions.push({ type: "remove", injectorId, reason: `attentionDrift=${driftCount}` })
    }
  }

  return actions
}
```

| 触发条件 | PolicyUpdateLoop 动作 |
|------|------|
| `contextEntropy > 0.7` | 降级最低优先级 injector 到 micro 级别 |
| `injectionBudget used > limit` | 告警 + 自动移除未引用的 injector |
| `attentionDrift[spatial] > 10` | spatial digest 降级为 T1（微型），10 轮后再评估 |
| `signalDensity < 0.3` | 建议 injector 开发者将自由文本改为结构化格式 |

> 接口先预埋在 Review/Plan 中，实现在 `global-awareness` Plan 与 PolicyUpdateLoop 对接时完成。

---

## 9. Spec 逐函数偷懒审查（2026-07-15 执行）

> 逐函数审查 `spec.md` 的 19 个函数/节点/类型定义，按 Phase 标注偷懒等级（🔴 严重 / 🟡 中度 / 🟢 轻微 / ✅ 合格）及缺失内容。

### Phase 1: 空间计算层

| 函数 | 等级 | 缺失内容 |
|------|:--:|------|
| 5 个类型接口 | ✅ | 字段、JSDoc、取值范围、API 来源全部到位 |
| `parseGraphicDrawing` | ✅ | 签名 + 输入/输出格式 + lng,lat→lat,lng 反转逻辑均明确 |
| `computeCentroid` | ✅ | 算术平均公式在 algorithm 步骤中给出 |
| `toCartesian` | ✅ | 公式写死在 pseudocode 中：`x = lng × cos(avgLat) × 111320` |
| `assignPlotToSensor` | ✅ | 射线法 + 边界归属规则（面积大者）明确 |
| `computeVoronoiRegions` | ✅ | 5 步骤 + 完整 pseudocode（100+ 行）+ 6 个 WHEN 边界场景 |
| `cgcs2000ToWgs84` | 🟡 | 默认恒等路径清晰，但**精确模式只写了"七参数 Helmert"六个字**——无公式、无参数来源、无依赖包。若 `enableTransform=true` 永远不用，应直接删除精确模式而非留坑 |
| `cgcs2000ToWgs84Batch` | 🟡 | 同上 |

### Phase 1 FCM 聚类

| 函数 | 等级 | 缺失内容 |
|------|:--:|------|
| `extractDataMatrix` | 🔴 | **ToolResult 结构未定义**——字段名（at/ah/lux/humidity/temperature/soilHumidity1-6/soilTemperature）硬编码在注释里，spec 没有给出 `ToolResult.list` 条目的类型定义。实现者需自己去翻 state.ts 和现有 tool 代码才能开工 |
| `pcaReduce` | 🟡 | 签名给了，Algorithm 步骤 4 有协方差矩阵 + 特征分解的数学描述。但**没有声明 npm 依赖**——手写 SVD/特征分解在 TS 里不现实，必然要引入 `ml-matrix` 或 `numeric`，spec 对此只字未提 |
| `fuzzyCMeans` | ✅ | 签名完整（5 参数 + 默认值），数学公式在步骤 6 给出 |
| `xieBeniIndex` | ✅ | 公式在步骤 7 给出 |
| `optimalClusterCount` | ✅ | 遍历 c=2..min(5,n-1) 逻辑清楚 |
| `computeManagementZones` | ✅ | 10 步骤 + 7 WHEN 场景，整体扎实。⚠️ 但模糊隶属度矩阵初始化无随机种子——每次运行结果可能不同，与 spec "可复现判定" 的要求矛盾 |
| 分区命名规则 | 🟡 | 硬编码了阈值 `>70%="高湿区"` `<40%="低湿区"`，但**虫情 ↑ 和温度异常的判定阈值没有给出**（什么算 "虫情 ↑"？什么算 "温度异常"？） |

### Phase 2: spatialPreprocessing 节点

| 函数 | 等级 | 缺失内容 |
|------|:--:|------|
| `spatialPreprocessingNode` | 🟡 | Pseudocode 以注释形式给出，5 步骤 + 5 WHEN 场景覆盖降级路径。但三个关键细节缺失：**(1) projectId 从 state 的哪个字段取？(2) Farm-Server API 调用的 HTTP client 是哪个——fetch 裸调还是走已有封装？(3) 认证 token 怎么传？** 这些不是"实现细节"，是"能不能跑通"的前提 |
| `SENSOR_TYPES` 映射 | ✅ | 常量定义清楚，type → 内部枚举 + 参与判断 |

### Phase 3: 汇总专家检索 + 推理（⚠️ 重灾区）

| 函数 | 等级 | 缺失内容 |
|------|:--:|------|
| `summaryRetrievalNode` | 🔴 | **只有 4 行注释**——没有函数签名参数，没有 ChromaDB 调用方式（哪个 client？哪个 collection？），没有 filter 结构定义，没有返回值类型。"汇总专家专属 filter（报告模板 + 农事标准 + 四情方法论）"——这 3 个 filter 的具体值是什么？怎么传给 ChromaDB？实现者只能去翻现有 retrieval.ts 代码猜测 |
| `buildSpatialContextSection` | 🔴 | 参数给了 `zones: ManagementZone[]`，返回值 `string`。但 **Markdown 模板一个字没写**——这个 section 直接喂给 LLM 做推理，格式质量直接影响模型输出质量。"包含：分区总数 + label/summary/dominantTrend/massifNames" 等于没说——表格？列表？段落？"推理要求"怎么措辞？"总 token < 2000"——怎么量的？谁负责截断？ |
| `summaryReasoningNode` | 🟡 | 4 步流程有框架，但没有 **LLM 调用细节**：用哪个 model？system prompt 是什么？temperature？`verdictResult` 的结构是什么？JSON 解析失败的回退说"提取第一个完整 JSON 对象"——用什么策略提取？正则？ |

### Phase 4: 现有推理改造 + Graph 接入

| 函数 | 等级 | 缺失内容 |
|------|:--:|------|
| reasoning 去截断 | ✅ | 精确到行号 L108-118，验收方式（grep 确认）。干净 |
| per-expert 数据升级 | 🔴 | **只有一句话："消费 state.toolResults 结构化数据 + spatialRegions"**——没有说怎么消费：替换 toolMessages？追加？合并？`spatialRegions` 按什么逻辑分组？改动范围多大？这是 13 个修改文件之一，spec 只给了半行 |
| Prompt 类型扩展 | ✅ | Re-export + 新增字段明确 |
| deep 图拓扑更新 | ✅ | 3 节点注册 + 条件边 + ASCII 图，清晰 |

### Phase 5: Prompt + Response + EventBus

| 函数 | 等级 | 判定 |
|------|:--:|------|
| `factory.ts build()` 注入 | 🟢 | 注入位置（领域触发词之前）、遍历方式、回退逻辑清楚。格式留白可接受——prompt 模板措辞属实现调优范畴 |
| `response.ts buildRegionSummary` + `isSummary` | 🟢 | 改动范围明确（~30 行），两个分支逻辑清晰 |
| EventBus fanout | ✅ | 事件名 + emit 位置都写死了 |

### 量化统计

| 等级 | 数量 | 占比 | 典型函数 |
|:--:|:--:|:--:|------|
| 🔴 严重 | 4 | 21% | `extractDataMatrix`, `summaryRetrievalNode`, `buildSpatialContextSection`, per-expert 数据升级 |
| 🟡 中度 | 6 | 32% | `cgcs2000ToWgs84`×2, `pcaReduce`, 分区命名规则, `spatialPreprocessingNode`, `summaryReasoningNode` |
| 🟢 轻微 | 2 | 11% | `factory.ts`, `response.ts` |
| ✅ 合格 | 7 | 37% | Voronoi 全套 + FCM 核心 + 去截断 + 类型扩展 + 拓扑/EventBus |

### 结构性问题

最大的结构性问题：**Phase 3（汇总专家链路）是整个 Plan 的"新功能核心"，但 Phase 3 的 3 个函数中有 2 个是 🔴、1 个是 🟡**——在最不该省的地方省了。

### 补全优先级建议

| 优先级 | 函数 | 需补内容 |
|:--:|------|------|
| P0 | `summaryRetrievalNode` | ChromaDB 调用方式 + filter 结构 + 伪代码（至少到 Phase 1 Voronoi 的详细度） |
| P0 | per-expert 数据升级 | 具体改造逻辑：改动点 + 数据流 + 与 spatialRegions 的关系（或明确放弃消费） |
| P0 | `buildSpatialContextSection` | Markdown 模板（这是 LLM prompt 关键组件，不能靠实现者猜） |
| P1 | `extractDataMatrix` | `ToolResultRecord` 接口定义，字段映射表 |
| P1 | `cgcs2000ToWgs84` 精确模式 | 要么删掉精确模式，要么补全公式 + 参数来源 + 依赖包（二选一） |
| P1 | `pcaReduce` | 声明 npm 依赖（`ml-matrix` 或 `numeric`） |
| P1 | `spatialPreprocessingNode` | projectId 来源 + HTTP client 引用 + 认证方式 |
| P1 | `summaryReasoningNode` | LLM 调用规格：model、prompt 模板、temperature、verdictResult 结构 |
| P2 | 分区命名规则 | 虫情 ↑/温度异常的判定阈值 |
| P2 | FCM 随机种子 | 固定种子以保证可复现性 |
