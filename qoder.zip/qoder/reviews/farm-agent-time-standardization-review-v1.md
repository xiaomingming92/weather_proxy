# farm-agent-time-standardization-review-v1

## Review 元信息

- **Review 对象**: `.qoder/plans/2026-07/01/farm-agent-time-standardization-plan-v1.md` + `.qoder/specs/farm-agent-time-standardization/` 三元组
- **对比方案**: 唯一方案（统一时间入口），无候选方案对比
- **Review 时间**: 2026-07-01
- **Review 类型**: 架构决策
- **前置阅读**: `.qoder/plans/2026-07/01/farm-agent-time-standardization-plan-v1.md`

---

## 1. 问题复现

项目已有 `src/lib/time.ts` 定义 `now()` / `reportNow()` 统一时间函数，注释明确要求"仅通过此模块生成时间戳"。但全局 80+ 处绕过该模块裸调 `new Date().toISOString()`，失去统一入口的所有好处：全局时区策略调整需改 55 个文件而非 1 个。

---

## 2. 方案对比

### 2.1 方案 A: 逐文件替换（采用）

`new Date().toISOString()` → `import { now } from "@/lib/time"`，每处显式选择 `now()` 或 `reportNow()`。

- **优点**: 零侵入、完全可控、语义清晰（从代码就能看出是 UTC 还是本地时间）
- **缺点**: 需修改 55 个文件
- **风险**: 低——纯 import 替换，git diff 清晰可审计

### 2.2 方案 B: ESLint 规则强制

配置 `no-restricted-syntax` 禁止 `new Date().toISOString()`。

- **优点**: 自动化持续约束，防止未来新增违规
- **缺点**: 需要额外配置，无法区分 `now()` vs `reportNow()` 语义
- **建议**: 作为方案 A 的补充，本次不实现，后续单独 Plan

## 3. 决策结论

**采用方案 A**。理由：每处替换显式选择 `now()` / `reportNow()` / `nowDate()`，语义不丢失。方案 B 作为后续补充。

**关键修正**（Review 过程发现）：
- Plan 初始遗漏 9 个文件（intention.ts, index-documents.ts, progress/route.ts 等），已补全
- Prisma DateTime `new Date()` 原误判为"合理豁免"，经用户指正后统一走 `nowDate()`

## 4. 影响评估

### 4.1 受影响文件

| 类别 | 文件数 | 修改量 |
|------|--------|--------|
| lib/time.ts | 1 | +4 函数 |
| Logger/lib | 15 | 各 1 行 import 替换 |
| Service | 11 | JSON metadata 时间戳替换 |
| Agent | 5 | step timestamp 替换 |
| API Route | 13 | timestamp + Prisma DateTime 替换 |
| Store | 3 | `now()` 替换 |
| UI 组件 | 4 | `fromUTC()` 接入 |
| **合计** | **52** | **~85 处** |

### 4.2 数据流影响

**无数据流变更**。所有替换保持语义等价：
- `new Date().toISOString()` → `now()` 返回相同 UTC ISO 8601 字符串
- `new Date()` → `nowDate()` 返回相同 Date 对象
- `new Date().toISOString()` → `reportNow()` 返回本地+8 ISO（仅影响人类可读输出）

### 4.3 回滚风险

**零风险**。所有修改为纯 import 替换，git revert 可一键回滚。Report 时间格式变更为预期行为（UTC→北京时间）。

### 4.4 API 签名/函数接口

`src/lib/time.ts` 新增 4 个导出函数，对外接口变化：
- `nowDate(): Date` — 无参数，返回 Date
- `fromUTC(utcString: string): string` — 入参 UTC ISO，返回本地格式化串
- `fromUTCToDate(utcString: string): Date` — 入参 UTC ISO，返回本地 Date
- `toLocalISO(utcString: string): string` — 入参 UTC ISO，返回本地 ISO

所有函数均为纯函数，无副作用，不影响已有 `now()` / `reportNow()` 签名。

### 4.5 错误路径/降级处理

- `fromUTC` 入参为空字符串或无效 ISO 格式时，返回空字符串（不抛异常）
- `fromUTCToDate` 入参无效时返回 `new Date(NaN)`（与原生行为一致）
- 降级策略：所有替换为纯 import 替换，若 `now()` 行为异常（极不可能），可 git revert

### 4.6 兼容性/向后兼容

- `new Date().toISOString()` → `now()`：返回相同 UTC ISO 8601 字符串，**完全向后兼容**
- `new Date()` → `nowDate()`：返回相同 Date 对象，**完全向后兼容**
- `new Date().toISOString()` → `reportNow()`：仅影响 human-readable 输出（Report/通知），**预期行为变更**而非兼容性问题
- `fromUTC()` 接入：**新增功能**，不影响已有代码路径

### 4.7 性能影响

**零性能影响**。`now()` 和 `nowDate()` 本质是封装 `new Date()`，无额外开销。`fromUTC` 仅做字符串解析+偏移计算，O(1)。55 个文件的 import 替换在编译期完成，运行时零差异。

## 5. 问题清单

| # | 严重程度 | 问题描述 | 修正建议 | 状态 |
|---|:---:|------|------|:---:|
| 1 | 🔴 P0 | Plan 初始遗漏 9 个文件（intention.ts, index-documents.ts, progress/route.ts, prescriptions, tasks, production-plan, service-accounts, seed-catalog price, daily-report, 3个 UI 组件） | 已在 Review 中逐一验证并补全到 Plan ADD-7 表格 | ✅ 已修正 |
| 2 | 🔴 P0 | Prisma DateTime `new Date()` 原误判为"合理豁免"，未纳入 `nowDate()` | 已在 Plan §2.2 移除豁免、§3.1 新增 nowDate()、ADD-7 表格补齐 6 处 Prisma DateTime | ✅ 已修正 |
| 3 | 🟡 P1 | 前端 `fromUTC()` 函数需在 Task 1 先实现，否则 Task 8 无法执行 | 已在 Spec Requirements 明确依赖顺序，Tasks 中标注 Task 8 依赖 Task 1 | ✅ 已修正 |
| 4 | 🟡 P1 | DPS 77 (WARN)，Specs Requirements 7/9 不足 | 补充 Service 层独立 Requirement 后重新 DPS | ✅ 已修正 |
| 5 | 🟢 P2 | 后续 ESLint 规则持续约束防止新增违规 | 后续单独 Plan，不影响本次实施 | 已知不处理 |

## 6. 建议修正优先级

| 优先级 | 问题 | 状态 |
|--------|------|------|
| P0 | 确认 55 个文件无遗漏 | ✅ 已 Review 补全 |
| P0 | Prisma DateTime `new Date()` 纳入 `nowDate()` | ✅ 已修正 |
| P1 | 前端 `fromUTC()` 函数需在 Task 1 先实现 | ✅ 已在 Spec + Tasks 中 |
| P2 | 后续 ESLint 规则持续约束 | 后续单独 Plan |

## 6. 最终建议

Plan 文件清单已经两轮 Review 补全，覆盖全部 `new Date()` / `new Date().toISOString()` 裸调用（豁免场景除外）。**方向正确，可进入实施。**
