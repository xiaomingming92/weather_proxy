# farm-agent-log-audit-unify-review-v1

## Review 元信息

- **Review 对象**: `farm-agent-log-audit-unify-plan-v3.md`
- **对比方案**: v1（初始方案）→ v2（细化）→ v3（重构 Gateway + 删除 audit-log）
- **Review 时间**: 2026-07-01
- **Review 类型**: 架构决策 + 方案选型
- **前置阅读**: `code-review-combined-report.md` #6-#9; `audit-log-bypass-governance-plan-v1.md`; `farm-agent-review-and-evidence-hardening-plan-v1.md`

---

## 1. 问题复现

`code-review-combined-report.md` 发现 4 个系统性问题：
1. 8 个 logger 文件内联相同的 `ensureLogDir/writeToFile/formatMessage` - 重复代码
2. Gateway 审计两个文件行为不一致（IS_DEV vs always），且仅覆盖 agent/[hash]，h5 缺失
3. `audit-log.ts` 内存存储死代码与 `writeAuditLog()` DB 方案重复
4. `agents/index.ts` 563 行单体文件职责过大

---

## 2. 方案对比

### 2.1 方案 A（v3）：分层重构

| Atom | 策略 | 评估 |
|------|------|------|
| Atom 1 | 提取 `LogFileWriter` + `LazyLogFileWriter`，注入 userId | ✅ 消除 8 处重复 |
| Atom 2 | 创建 `auditGatewayRequest()` 纯函数，删除两个旧文件，接入 h5 13 条路由 | ✅ 边界清晰（成功路径 vs hardening plan 报错路径） |
| Atom 3 | 删除 `audit-log.ts` 整个文件，`audit/route.ts` 直查 Prisma | ✅ 消除死代码 |
| Atom 4 | agents/index.ts 拆 6 文件 + index.ts re-export | ✅ 保持外部 import 兼容 |

### 2.2 方案 B（v2 废弃方案）

- Atom 2 仅合并两个 agent gateway 文件，不推广到 h5
- Atom 3 改为"内存→DB 迁移"而非直接删除

**选型理由**：v3 解决 v2 的架构盲区——Gateway 审计覆盖率缺口 + audit-log.ts 应该删除而非迁移。

---

## 3. 决策结论

**方向正确，建议执行。** 4 个 Atom 的划分合理，依赖拓扑清晰。

需关注的改进点：

| # | 问题 | 严重度 | 修复建议 |
|---|------|--------|---------|
| P1-1 | `LogFileWriter` 引入后 userId 查询从 DB 层移到 file 层，`getLogUserId()` 缓存失效风险需确认 | P1 | 确认 `getLogUserId()` 的 `let logUserId` 缓存逻辑在 module-level 正常工作 |
| P1-2 | h5 路由接入 gateway 审计后，每个请求多一次 `writeAuditLog` DB 写入，需确认对农情高峰期（>100 req/s）的影响 | P1 | 评估 DB 写入频率，必要时加 buffer 或采样 |
| P2-1 | `audit-log.ts` 删除后 `AuditAction` 类型消失，`audit/route.ts` 的 filter 参数从联合类型变为自由 string | P2 | 保留 `AuditAction` 枚举定义在 `audit/route.ts` 内联，或改用 `writeAuditLog` 的 string action |

---

## 4. 影响评估

### 4.1 受影响文件

| 类别 | 文件数 | 操作 |
|------|--------|------|
| 新增 | 8 | `file-writer.ts`, `gateway-audit.ts`, tracer-store/tracer/tool-node-wrapper/audit-wrapper/graph/agent-runner |
| 修改 | 18+ | 8 logger + audit.ts + agent/[hash] + 7 h5 P0 + audit/route + services/index + agents/index + log/index |
| 删除 | 3 | `agent-gateway-dev-logger.ts`, `agent-gateway-audit.ts`, `audit-log.ts` |

### 4.2 数据流影响

- **File 日志格式**：`plain` → `JSONL`（向后兼容：console 保持人类可读，仅 file 切换）
- **DB 审计**：无 schema 变更，`writeAuditLog()` 保持不变
- **Gateway 审计**：`targetType` 从 `AGENT_GATEWAY` 拆为 `GATEWAY_AGENT` / `GATEWAY_H5`

### 4.3 回滚风险

- 低：Atom 1-4 独立可回滚，不修改 Prisma schema
- 如 h5 接入后日志量过大：还原单个 route 的 import 即可

---

## 5. 覆盖维度检查

| 维度 | 状态 | 说明 |
|------|:--:|------|
| 数据模型/类型定义 | ✅ | `LogFileWriterOptions`, `LogEntry`, `GatewayAuditOptions` 接口已定义 |
| 错误路径/降级处理 | ✅ | `writeAuditLog` 已有失败告警；Gateway 报错走 hardening plan 的 `appendRuntimeFinding` |
| 数据迁移策略 | ✅ | 无 DB schema 变更；File 格式切换为一次性，旧文件保留 |
| 兼容性/向后兼容 | ✅ | agents/index.ts re-export 保持 25+ import 不变；audit/route.ts API 签名不变 |
| 存储/索引成本 | ✅ | JSONL 文件按天轮转 + 7 天保留；DB 无新增索引 |
