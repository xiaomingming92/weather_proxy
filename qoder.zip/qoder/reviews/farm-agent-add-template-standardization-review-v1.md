# farm-agent-add-template-standardization-review-v1

## Review 元信息

- **Review 对象**: `.qoder/plans/2026-07/04/farm-agent-add-template-standardization-plan-v1.md`
- **Review 时间**: 2026-07-04
- **Review 类型**: 方案选型 + 架构设计 + 结构合规
- **前置阅读**:
  - Plan: `.qoder/plans/2026-07/04/farm-agent-add-template-standardization-plan-v1.md`
  - 对照标准: `.qoder/templates/plan-template.md`

---

## 1. 结构合规检查

对照 `.qoder/templates/plan-template.md` 逐项检查：

| 章节 | plan-template 要求 | Plan 实际 | 状态 |
|------|-------------------|-----------|:--:|
| 标题 | `# {需求域名}-{核心内容}-plan-v{版本号}` | `# add-template-standardization-plan-v1` | ✅ |
| Plan/Spec 边界提醒 | 有 | 有 | ✅ |
| PLAN 元信息 | Plan 名称、启动时间、主导 AI | 三项齐全 | ✅ |
| 关联文档 — ADD Route | **必须** | **缺失** | ❌ |
| 关联文档 — Handoff | 必须 | 有 | ✅ |
| 关联文档 — Review | 必须 | 有 | ✅ |
| **ADD-7 审计策略表** | **必须** | **缺失** | ❌ |
| 一、背景与目标 | 1.1 + 1.2 | 有 | ✅ |
| 二、方案选型 | 2.x | 2.1 + 2.2 + 2.3 | ✅ |
| 三、架构设计 | 有 | 有 | ✅ |
| 四、实施步骤 + 依赖图 | ASCII 图 + Step 子节 | 有 ASCII 图，但使用 Task 而非 Step 子节 | ⚠️ |
| 五、验收标准 | checklist | 有 | ✅ |
| 六、关联文档 | ADD Route / Spec / Tasks / Checklist | **只有 Handoff + Review + 实现文件** | ❌ |

---

## 2. P0 阻断性问题

### P0-1: 缺少 ADD-7 审计策略表

plan-template 第 14-18 行明确要求。本 Plan 涉及修改 **16 个模板文件 + 1 个 Shell 脚本 + 至少 3 个消费方文档**（AGENTS.md / vocabulary.sh / add-governance-vocabulary.md），至少 20 个文件的变更，全部没有审计策略记录。

**影响**：Step 3 实施时无法按表逐文件验证审计落库，Step 8 验收时无法交叉校验 `query_audit_logs` 与 git diff。

### P0-2: 缺少 ADD Route 关联

元信息中缺少 `ADD Route` 路径，第六节关联文档中同样缺失。按照 ADD 范式，每个 Plan 必须有关联的 ADD Route 用于工作流导航。

### P0-3: 第六节关联文档缺少 Spec / Tasks / Checklist

plan-template 第六节要求关联 Spec、Tasks、Checklist。当前 Plan 只关联了输出物（Handoff、Review）和实现目标文件（TERMINOLOGY.md、doc-format-guard.sh），缺少 Plan → Spec → Tasks 的标准链路。

### P0-4: Task 2 未穷举 16 个模板

只列出 12 个 + "其余 4 个模板"。需要给出完整的 16 个模板文件路径清单，否则实施时必然遗漏。已知模板列表应包含：

- [ ] plan-template.md
- [ ] simple-plan-template.md
- [ ] spec-template.md
- [ ] tasks-template.md
- [ ] checklist-template.md
- [ ] handoff-template.md
- [ ] handoff-single-round-template.md
- [ ] handoff-multi-round-template.md
- [ ] add-route-template.md
- [ ] add-route-template-heavyweight.md
- [ ] review-template.md
- [ ] review-implementation-template.md
- [ ] review-runtime-template.md
- [ ] 其余 4 个待补充

---

## 3. P1 重要问题

### P1-1: 依赖图错误 — Task 3 不独立于 Task 1

```
当前依赖图（Plan L175-188）:
Task 1: 术语表定稿 ──┐
Task 2: schema.json  │ 可并行    ← 错误
Task 3: 模板修正     │ 可并行    ← 错误
```

Task 2 的 `forbidden_terms` 字段和 Task 3 的"替换禁止词"都依赖 Task 1 的术语表终稿。Task 1 不定稿，Task 2/3 无法开始。正确依赖关系：

```
Task 1: 术语表定稿 ──┬── Task 2: 16 个 schema.json
                    └── Task 3: 16 个模板修正
                              │
                              ▼
                    Task 4: doc-format-guard.sh 重构
                              │
                              ▼
                    Task 5: 消费方同步
                              │
                              ▼
                    Task 6: 回写验证
```

### P1-2: 缺少风险分析 — 旧文档术语断裂

16 个模板术语统一后，`.qoder/plans/` 下 200+ 已有 Plan / Spec / Handoff 中可能引用旧术语（`Phase`、`阶段`、`步骤`、`轮次` 等中文词）。Plan 未讨论：

- 历史文档是否批量替换还是容忍共存？
- 如果共存，守卫是否会对历史文档报 `forbidden_terms`？
- 如果批量替换，由谁执行、如何验证完整性？

### P1-3: 守卫执行流程中文件名推断规则不明确

```
L163: 识别模板类型（从文件名推断：*plan* / *spec* / *handoff* / ...）
```

当文件名同时含多个关键词时（如 `review-implementation-xxx` 含 review + implementation），匹配优先级未定义。且 `*handoff*` 通配会同时命中 handoff-template、handoff-single-round-template、handoff-multi-round-template，三者 schema 不同。需要精确的匹配规则和优先级定义。

---

## 4. P2 改进建议

### P2-1: 方案选型 B "200+ Plan"缺数据来源

L65："plan-template 是使用最频繁的模板（200+ Plan）"。需要注明统计方法（如 `find .qoder/plans -name "*plan*" | wc -l`），否则被 Review 质疑时无法复现。

### P2-2: 验收标准缺乏量化指标

当前验收标准全是二元 `[ ]` 项。建议增加：

- `[ ]` 误阻断率 < 5%（对历史 200+ Plan 抽样 20 个验证）
- `[ ]` 漏检率 = 0（人为构造 5 个缺章节文档，全部被阻断）
- `[ ]` PreToolUse hook 增加 JSON 解析后耗时增量 < 50ms

### P2-3: 3.3 示例自身的章节名不一致

示例中 simple-plan-template 使用 `一、Plan 概述`，而 plan-template 使用 `一、背景与目标`。在标准化 Plan 中引用未标准化的章节名作为示例，削弱论证可信度——建议在示例中注明"此示例展示的是标准化前的状态，标准化后将统一为 X"。

### P2-4: 缺少 Shell 中 JSON 解析的性能评估

`doc-format-guard.sh` 每次 PreToolUse 触发都要解析 JSON，在 Shell 中逐文件读取 16 个 `.schema.json` 可能有性能问题。建议评估实际耗时，或考虑生成预制索引文件减少运行时解析开销。

---

## 5. 决策结论

| 维度 | 评价 |
|------|------|
| 问题识别 | ✅ 术语分裂、层级混乱、守卫缺口问题定位准确，表格对比直观 |
| 方案选型 | ✅ 选型有 A/B/C 对比，理由清晰 |
| 结构合规 | ❌ 缺 ADD Route、ADD-7 审计策略表、Spec/Tasks/Checklist 关联 |
| 依赖图 | ❌ Task 1/2/3 并行关系有误 |
| 风险覆盖 | ❌ 缺风险分析章节 |

**结论**：P0 问题 4 条需在进入 Step 1 前修复。P1 问题 3 条建议在 Step 3 实施前解决。整体方案方向正确，补齐合规项后可以进入实施。

---

## 6. 受影响文件（回流预期）

| 文件 | 需要修改的内容 |
|------|--------------|
| `farm-agent-add-template-standardization-plan-v1.md` | 补 ADD-7 审计策略表 + ADD Route 关联 + Spec/Tasks/Checklist 关联 + 更正依赖图 + 穷举 16 模板 |
| `farm-agent-add-template-standardization-add-route-v1.md` | 新建 ADD Route（P0-2） |
| `farm-agent-add-template-standardization-spec-v1.md` | 新建 Spec（P0-3） |
