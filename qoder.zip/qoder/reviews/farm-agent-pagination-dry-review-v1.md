# farm-agent-pagination-dry-review-v1

## Review 元信息

- **Review 对象**: Plan `farm-agent-pagination-dry-plan-v1.md` + Specs `farm-agent-pagination-dry/`
- **Review 时间**: 2026-06-15
- **Review 类型**: 方案选型
- **前置阅读**: Plan, Spec, Tasks, Checklist
- **结论级别**: ✅ 可接受

---

## 1. 问题复现

5 处 zod schema 重复定义 `pageNo`/`pageSize`，虫情/气象工具缺少 `dataTime` 参数，导致周报/日报专家无法按时间窗口过滤数据。

---

## 2. 方案对比

| 维度 | 方案 A: spread 引用 | 方案 B: z.object().extend() | 方案 C: 不提取 |
|------|---------------------|---------------------------|---------------|
| 改动量 | 低（2 文件） | 中（需改调用链） | 无 |
| 类型安全 | ✅ zod 自动推导 | ✅ | ❌ |
| 可维护性 | ✅ 一处修改全局生效 | ✅ | ❌ 5 处不同步 |

**结论**：方案 A 最优。

---

## 3. 决策结论

- ✅ `BasePageParams` 提取到 `schemas/farm-data-tools.ts`，通过 spread 引用
- ✅ `InsectDataPageSchema` + `FarmWeatherPageSchema` 补 `dataTime`，与 `SoilMoisturePageSchema` 对齐
- ✅ 不引入 detail/get 工具——page 接口已返回全量字段
- ✅ 不修改 default 值、不扩展 AgentAuditPhase

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 变更 |
|------|------|
| `schemas/farm-data-tools.ts` | 新增 BasePageParams，SoilMoisturePageSchema 引用它 |
| `impl/farm-data-tools.ts` | 4 处内联替换 + 2 个 schema 补 dataTime + 2 个工具透传 |

### 4.2 数据流影响

无——工具调用路径不变，LLM 可选的参数更多（dataTime），向后兼容。

### 4.3 回滚风险

低——纯 schema 重构 + 可选参数新增，不影响现有调用。

---

## 5. 问题清单

无 P0/P1 问题。

| # | 严重度 | 描述 | 状态 |
|---|--------|------|------|
| 1 | P2 | 工具 description 未提及 dataTime 参数 | 已知不处理（description 由 LLM 从 schema 推导） |
