# Expert Grounding RAG 适配 — 运行时审查 v1

> **审查时间**: 2026-06-11
> **依赖环境**: ChromaDB 本地 + VPS（rfai）双端可用

---

## [R] 运行时待验证清单

以下检查项需要 ChromaDB 运行环境，无法在编译期完成。标记为 `[R]` 以区别于 `[T]` 编译期检查项。

---

### E1: 本地验证

- [R] E1.1: 运行 `npx tsx scripts/migrate-expert-collections.ts --dry-run` 确认文档迁移计划正确
  - 预期: 输出 3 个 Expert collection 各需迁移的文档数
- [R] E1.2: 运行 `npx tsx scripts/migrate-expert-collections.ts` 执行实际迁移
  - 预期: 3 个 collection 创建完毕，文档数 ≥ 对应 cateId 源码
- [R] E1.3: `grounding.ready()` 对 `pest_risk` 返回 `{ ready: true, indexHealth: "healthy" }`
- [R] E1.4: `grounding.ready()` 对 `crop_compare` 返回 `{ ready: true, indexHealth: "healthy" }`
- [R] E1.5: `grounding.ready()` 对 `roi_analysis` 返回 `{ ready: true, indexHealth: "healthy" }`
- [R] E1.6: `activateExpert(pest_risk)` 后在 `expert_pest_risk` collection 内检索
- [R] E1.7: 未迁移 Expert（如 `weather_impact`）走 evidenceFilter 降级，AuditLog 有 `EXPERT_GROUNDING_DEGRADED` 记录
- [R] E1.8: `resolveRetrieveBudget(["pest_risk", "daily_report"])` → `perExpertTopK.pest_risk === 5` 且 `perExpertTopK.daily_report === 10`
- [R] E1.9: evidence 中 `source === "expert"` 且 `grounding.retrievedVia === "collection_search"`
- [R] E1.10: 降级路径 evidence 中 `grounding.groundingStatus === "degraded"`
- [R] E1.11: chunkId 去重生效——同一 chunk 被多个 Expert 命中时只出现一次
- [R] E1.12: AuditLog 中 `EXPERT_GROUNDING_READY` / `EXPERT_COLLECTION_SEARCH` / `EXPERT_SEARCH_RESULT` 均有记录
- [R] E1.13: AuditLog 中 `EXPERT_DEDUP` 记录出现（多 Expert 命中同一 chunk 场景）

### E2: VPS（rfai）同步验证

- [R] E2.1: VPS 上 3 个 Expert collection 已创建
- [R] E2.2: VPS 上文档迁移完成，documentCount ≥ 预期
- [R] E2.3: VPS 上 `grounding.ready()` 返回 healthy
- [R] E2.4: VPS 上降级路径可用
- [R] E2.5: VPS 端到端 API 调用返回 evidence 含 grounding 字段

### 跨项目联调

- [R] C1: `RetrieveBudget.perExpertTopK` 在 `sub-intent.ts` 定义与 `retrieval.ts` 消费格式一致
- [R] C2: 3 个 Expert collection 名称不与现有 collection 冲突
- [R] C3: reasoning-engine 正确处理 `EvidenceSource = "expert"` (reliability 0.85)

### 回归检查

- [R] R1: 现有 API `/api/agent/stream` 在不传 Expert 参数时行为不变
- [R] R2: 现有 API `/api/agent/stream` 在传单个 Expert 参数时仍返回有效结果
- [R] R3: `npm run build` 生产构建通过

---

## 🐛 运行时缺陷发现（2026-06-11 日志分析）

> 通过 thread_c28fbcba "农情日报" 重复查询的 agent-audit.log 交叉对比发现。

### B1: retrieval.ts L122 `activeExperts` vs `expertIds` 变量误用

- [x] B1.1: `searchPromises = activeExperts.map(...)` 在 analysisContext 无激活专家时始终为空数组
  - **现象**: `Promise.all([])` → 0 次检索 → `RAG_EMPTY` 误报
  - **根因**: L94 `activeExperts` 仅来自 `analysisContext`（creation 意图始终为空），L101-103 `expertIds` 有 `subIntentPlan` fallback 但 L122 未使用
  - **修复**: L122 改用 `expertIds.map(...)`，同步修正 L228 `expertCount` 引用
  - **验证**: 2026-06-11 `03:16` 查询成功（5 results）vs `10:03` 查询失败（0 results, `per_expert_parallel` 模式）
  - **关联 commit**: `fix(retrieval): activeExperts → expertIds 修复 per-expert 空检索`

### B2: retrieval.ts 空 expert 时缺少全局搜索 fallback

- [x] B2.1: `expertIds.length === 0` 时未回退全局 ChromaDB 检索
  - **现象**: 即使 ChromaDB 有 690+ 条文档，仍然返回 0 结果
  - **根因**: `searchPromises = [].map(...)` → `Promise.all([])` → `results.length === 0` → `RAG_EMPTY`，无降级路径
  - **修复**: 新增 `if (expertIds.length === 0)` 分支 → `searchKnowledgeDocuments(searchQuery, 5)` 全局检索
  - **审计**: AuditLog 输出 `EXPERT_GROUNDING_DEGRADED` + `fallbackMode: "global_search"`
  - **关联 commit**: `fix(retrieval): 空 expert 时 fallback 全局 ChromaDB 检索`

### B3: intention 解析器未识别 "农情日报" → daily_report 专家

- [x] B3.1: LLM 意图解析对 creation 意图不产出 subIntents，导致 daily_report 从未激活
  - **现象**: "汇总当日农场各项数据，生成简洁明了的农情日报" → `activeExpertIds: []` → retrieval 无专家定位
  - **根因**: intention prompt 未将 "农情日报" 关键词与 `daily_report` expert 关联
  - **修复**: 新增 `KEYWORD_EXPERT_MAP` 正则映射表：
    - `农情日报|日报|农情简报|每日.*农情` → `daily_report`
    - `周报|每周.*报|农情周报` → `weekly_report`
  - **触发**: LLM 解析后 `activeExpertIds.length === 0` → `resolveKeywordExperts(queryText)` 兜底激活
  - **审计**: AuditLog 输出 `NODE_INFO` + `keywordExpertIds`
  - **关联 commit**: `feat(intention): 关键词→Expert 映射兜底激活`

### B4: intention.ts analysisContext 为 null 时关键词兜底激活被短路丢弃

- [x] B4.1: 新线程首次请求 `state.analysisContext` 为 `null`，`activateExpert()` 需要合法 `AnalysisContext` 对象但被 `?? undefined` + `&& updatedAnalysisContext` 短路跳过
  - **现象**: 关键词兜底匹配到 `weekly_report`，NODE_INFO 日志显示 "keyword fallback activated experts"，但 retrieval 节点拿到的 `analysisContext.activeExperts` 仍为空，回退到 `subIntentPlan.activateExpertIds: ["growth_report"]` → `growth_report` collection 为空 → 0 条 RAG 结果
  - **根因**: L165 `updatedAnalysisContext = state.analysisContext ?? undefined` → `undefined`；L166 `if (...&& updatedAnalysisContext)` 短路（跳过 LLM 激活）；L174 兜底进入，L181 `if (updatedAnalysisContext &&...)` 再次短路（跳过关键词激活）；L231 `...(updatedAnalysisContext ? { analysisContext } : {})` 返回空（context 没传给 retrieval）
  - **修复**: 新增 `ensureAnalysisContext()` 空壳兜底函数，当 `analysisContext` 为 null/undefined 时返回带空 `activeExperts` 的合法 `AnalysisContext`；三路径统一使用：L100 `explicitExpertId` 路径、L178 LLM 激活路径、L191 关键词兜底路径
  - **影响范围**: GUI 直连专家（`explicitExpertId`）路径同样受益——新线程首次点技能卡片也能正确激活专家
  - **审计**: 修复后 `RETRIEVAL_DECISION` 的 `source: "analysisContext"` 而非 `"subIntentPlan"`
  - **关联 commit**: `fix(intention): ensureAnalysisContext 空壳兜底防止专家激活被丢弃`

---

## 执行顺序

```
E1.1 (dry-run) → E1.2 (migrate) → E1.3-5 (grounding check) → E1.6-8 (retrieval)
                                                               ↓
                                                          E1.9-13 (evidence + audit)
                                                               ↓
                                                          E2.1-5 (VPS sync)
                                                               ↓
                                                          C1-3 (cross-project)
                                                               ↓
                                                          R1-3 (regression)
```

## 当前状态

### ChromaDB 依赖项

⚠️ **ChromaDB 不可用（本地/VPS 双端未运行）**，以上 22 个 `[R]` 项均未验证。

可在 ChromaDB 恢复后按执行顺序逐步验证，每通过一项勾选对应 checkbox。

### 日志分析缺陷

✅ **B1-B4 已通过 agent-audit.log 交叉对比发现并修复**（详见 §🐛 运行时缺陷发现）。

四项修复均为代码逻辑缺陷，无需 ChromaDB 即可验证——可在下一次 API 调用时通过 AuditLog 确认：
- `RETRIEVAL_DECISION` 中 `activeExpertIds` 不再为 `(none)`（当 query 命中关键词时）
- `EXPERT_GROUNDING_DEGRADED` 中 `fallbackMode: "global_search"` 在无专家时出现
- `NODE_INFO` 中 `keywordExpertIds` 在关键词命中时出现
- `RETRIEVAL_DECISION` 中 `source: "analysisContext"` 而非 `"subIntentPlan"`（修复 B4 后）
