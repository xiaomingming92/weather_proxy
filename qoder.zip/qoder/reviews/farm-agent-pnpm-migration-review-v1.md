# farm-agent-pnpm-migration-review-v1

## Review 元信息

- **Review 对象**: [farm-agent-pnpm-migration-plan-v1](../plans/2026-07/01/farm-agent-pnpm-migration-plan-v1.md)
- **Review 时间**: 2026-07-02
- **Review 类型**: 方案审查（ADD-9）
- **前置阅读**: `farm-agent-pnpm-migration-plan-v1.md`

---

## 1. 背景

Plan 目标是将 farm-agent 从 npm 切换到 pnpm，解决双锁文件问题（package-lock.json + pnpm-lock.yaml 并存），同步改造 Volta、CI、scripts 和文档。

Plan 整体结构合理，覆盖了迁移的核心方面。但存在以下计数漏报和遗漏文件的问题需要修正。

---

## 2. 评审发现

### P0 — 必须在实施前修复

#### P0-1: `package.json` scripts 中 `npm run` 残留计数漏报（Plan §4.1）

Plan 声称 3 处 `npm run`，实际共 **5 处**：

| 行号 | 脚本 | 实例 |
|------|------|------|
| L7 | `dev` | `npm run predev`, `npm run db:ensure` (2) |
| L9 | `start` | `npm run db:ensure` (1) |
| L24 | `db:reset` | `npm run db:init:safe` (1) |
| L36 | `kb:logs` | `npm run kb:sync`（echo 帮助文本，建议也改）(1) |

**影响**: 实施时可能遗漏，导致 `db:reset` 或 `kb:logs` 在 pnpm 下行为异常。

**建议**: 修正 §4.1 表格，补充 L36 的 echo 字符串。

---

#### P0-2: 文档脚本文案更新范围严重漏报（Plan §七）

Plan 仅列出 3 个文件（db-export / db-import / start-infrastructure），实测需要更新的文件达 **8 个**：

| 遗漏文件 | `npm run` 出现次数 | 类型 |
|----------|---------------------|------|
| `scripts/check-dev-env.ts` | 2 | console.error 帮助文本 |
| `scripts/agent-diagnose.ts` | 2 | console.log 帮助文本 |
| `scripts/sync-farm-api-index.ts` | 1 | JSDoc 注释 |
| `scripts/sync-farm-service-api-docs.ts` | 1 | JSDoc 注释 |
| `scripts/startup-farm-service-login.ts` | 1 | JSDoc 注释 |
| `scripts/ensure-cron.sh` | 1 | 注释 |
| `README.md` | **15** | 安装/开发/数据库/知识库/Agent 命令 |

**影响**: 用户按 README 中的 `npm run xxx` 操作会失败，agent-diagnose 的诊断建议也会给出错误命令。

**建议**: §七 扩展文件列表至 8 个，README.md 作为独立小节处理。

---

#### P0-3: CI `sudo -u ai bash -l -c` 下 pnpm 可用性未验证（Plan §5.3）

CI 使用 `$AI="sudo -u ai bash -l -c"` 模式。Volta 的 shim 通过 shell 初始化脚本注入 PATH，`bash -l -c` 理论上会加载 login shell（从而加载 Volta），但 `sudo -u` 可能改变环境变量行为。

**当前状态**: §5.3 只说"VPS 上确认 pnpm 已通过 Volta 安装"，没有明确验证方法。

**建议**: 在 CI prepare 脚本中增加显式检查：
```bash
$AI "command -v pnpm" || { echo "!!! pnpm 不可用，请执行: npm i -g pnpm@11.9.0"; exit 1; }
```
或退而选择为 `ai` 用户全局安装 `npm i -g pnpm@11.9.0`（不依赖 Volta shim）。

---

#### P0-4: 现有 `pnpm-lock.yaml` 处理策略不明确（Plan §3.2 vs §八 Step 4）

- §3.2 说"如果现有 pnpm-lock.yaml 是手动创建的，建议删除后重新生成"
- §八 Step 4 说"`pnpm install` 重新生成"

两者语义不同：前者明确删除再生成（干净），后者仅 `pnpm install`（可能基于不干净的旧 lockfile 增量更新）。

**建议**: 统一为：
```bash
rm pnpm-lock.yaml          # 强制删除旧 lockfile
pnpm install               # 从 package.json 重新解析生成
```
确保 lockfile 与 package.json 完全一致，避免旧 lockfile 中的脏数据。

---

#### P0-5: `.npmrc` `shamefully-hoist=true` 范围过宽（Plan §六）

`shamefully-hoist=true` 会完全破坏 pnpm 的严格依赖解析——这是在用 pnpm 模拟 npm 的扁平结构，为个别包的问题付出全局代价。

**建议**: 优先去掉 `shamefully-hoist=true`，仅保留 `public-hoist-pattern[]`：
```ini
public-hoist-pattern[]=*prisma*
public-hoist-pattern[]=*@prisma*
```
如果 Next.js 等框架确实需要，再按需追加 pattern，而不是全局 hoist。这样后续收紧配置更容易，而不是被迫全局放宽。

---

### P1 — 应在实施中处理

#### P1-1: 缺少 `.gitignore` 验证步骤

删除 `package-lock.json` 后，若 `.gitignore` 中显式包含 `package-lock.json`，git 不会追踪删除操作。实施步骤中缺少此检查。

**建议**: §八 Step 3 后追加：验证 `.gitignore` 中无 `package-lock.json` 显式条目。

---

#### P1-2: CI 中的 `npx` vs `pnpm exec`（Plan §4.2）

Plan 说"npx prisma 在 pnpm 下等价，无需改动"。但在 CI 的 `sudo -u ai bash -l -c` 上下文中，`npx` 可能解析为 npm 的 npx 而非 pnpm 的。`pnpm exec prisma` 更明确且不依赖 PATH 上的歧义。

**建议**: §五 CI 改造中，`npx prisma` → `pnpm exec prisma`（当前 CI 文件中无显式 npx，但 package.json scripts 中有多处 `npx prisma` 调用）。

---

#### P1-3: 缺少 `db-ensure.prod.sh` 脚本的 `npm` 引用检查

CI deploy 阶段（L132）引用 `bash scripts/db-ensure.prod.sh`。Plan 未提及该脚本，其内部可能包含 `npm run` 或 `npx` 调用。

**建议**: 实施前 grep 检查 `scripts/db-ensure.prod.sh` 是否有 `npm` 调用，纳入迁移范围。

---

#### P1-4: Node 24.x 与 pnpm 11.9.0 兼容性未验证

`volta.toml` pin Node `24.x.x` + pnpm `11.9.0`。Node 24 较新，需确认 pnpm 11.9.0 官方支持。

**建议**: §九 风险评估表追加此项：`Node 24 与 pnpm 11.9.0 不兼容` → `构建前 `pnpm --version` 验证正常运行`。

---

#### P1-5: §八 Step 6 / Step 8 的"处数"标注与实际不符

| Step | Plan 标注 | 实际 |
|------|----------|------|
| Step 6（改 scripts 内联） | 3 处 | 5 处 |
| Step 8（文档脚本文案） | 3 个文件 | 8 个文件 |

**建议**: 修正为实际数量，避免实施时困惑。

---

### P2 — 建议优化

#### P2-1: 缺少团队协作引导

Plan 未说明协同开发者如何统一 pnpm 版本。全局 pnpm 版本不一致会导致 lockfile 格式冲突。

**建议**: §二 追加团队协作说明：
> 强制推荐所有开发者安装 Volta（`curl https://get.volta.sh | bash`），`cd` 进项目自动切换 pnpm 11.9.0，其他项目 pnpm 版本不受影响。不装 Volta 的开发者需自行保证全局 pnpm 版本与 lockfile 一致。

#### P2-2: 建议增加 `--frozen-lockfile` 的 pre-commit hook

迁移完成后，建议在 `.githooks/pre-commit` 中检查 `pnpm-lock.yaml` 是否与 `package.json` 同步，防止本地 `pnpm install` 后忘记提交 lockfile 变更。

#### P2-3: package.json scripts 中 `npx prisma` 可简化为 `prisma`

pnpm 会自动将 `node_modules/.bin` 加入 scripts 的 PATH，`npx prisma generate` 可简写为 `prisma generate`（减少一次 npx 解析开销）。

---

## 3. 决策结论

| 项目 | 结论 |
|------|------|
| P0-1 ~ P0-5 | **必须修复后再实施**，否则 CI/shell 行为会出现预期外异常 |
| P1-1 ~ P1-5 | **实施中同步修复**，降低 CI 翻车风险 |
| P2-1 ~ P2-3 | **建议采纳**，提升团队协作体验和长期可维护性 |

---

## 4. 影响评估

### 4.1 受影响文件

| 文件 | 当前 Plan 是否覆盖 | 评审后补充 |
|------|--------------------|------------|
| `volta.toml` | ✅ | — |
| `package.json` | ✅（计数需修正） | L36 kb:logs echo 文本 |
| `package-lock.json` | ✅ | `.gitignore` 验证 |
| `pnpm-lock.yaml` | ✅（策略需明确） | 删除后重新生成 |
| `.npmrc` | ✅（配置需收紧） | 去掉 shamefully-hoist |
| `.gitlab-ci.yml` | ✅ | pnpm 可用性检查 |
| `scripts/db-export.ts` | ✅ | — |
| `scripts/db-import.ts` | ✅ | — |
| `scripts/start-infrastructure.sh` | ✅ | — |
| `scripts/check-dev-env.ts` | ❌ **遗漏** | 1 处 `npm run` |
| `scripts/agent-diagnose.ts` | ❌ **遗漏** | 2 处 `npm run` |
| `scripts/sync-farm-api-index.ts` | ❌ **遗漏** | 1 处 `npm run` |
| `scripts/sync-farm-service-api-docs.ts` | ❌ **遗漏** | 1 处 `npm run` |
| `scripts/startup-farm-service-login.ts` | ❌ **遗漏** | 1 处 `npm run` |
| `scripts/ensure-cron.sh` | ❌ **遗漏** | 1 处 `npm run` |
| `scripts/db-ensure.prod.sh` | ❌ **遗漏** | 需 grep 确认 |
| `README.md` | ❌ **遗漏** | 15 处 `npm` 命令 |

### 4.2 数据流影响

- `pnpm install` 重建 `node_modules`（结构从扁平变为 symlink）
- `pnpm-lock.yaml` 重新生成（需确认依赖树与 package.json 一致）
- CI 从 `npm ci` 切换到 `pnpm install --frozen-lockfile`

### 4.3 回滚风险

- **低风险**: git 历史保留所有变更，`git revert` 可回退
- **中度风险**: 若 `pnpm install` 后 `node_modules` 结构导致运行时问题（隐式依赖缺失），需逐步追加 `public-hoist-pattern[]`
- **建议**: 本地 `pnpm install && pnpm build && tsc --noEmit` 通过后，再删除 `package-lock.json` 提交，保留一键回滚能力
