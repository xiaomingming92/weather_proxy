# farm-agent-api-zod-hardening-round1-review

## Review 元信息

- **Review 对象**: [farm-agent-api-zod-hardening-plan-v1.md](../plans/2026-06/30/farm-agent-api-zod-hardening-plan-v1.md)
- **Review 时间**: 2026-06-30
- **Review 类型**: 方案选型 + 架构决策
- **前置阅读**: Plan v1、`code-review-combined-report.md` §13/15、`sse-terminal-event.ts`、H5 SSE 协议文档

---

## 1. 问题复现

生产事故（June 29 16:30 CST）：H5 端点中断流 `event: interrupt` 无 `threadId`，调用方拿到交互点数据后不知调哪个 thread 的 `/resume`。本地 curl 已复现中断触发但无 threadId。根因已定位到 `handleInterrupt()` L44 直接 `JSON.stringify()` 裸发，无类型约束。

Plan 将这一问题归类为"缺少 Zod schema 导致运行时漏检"，方向正确。

---

## 2. 方案对比

Plan 选择**唯一方案：Zod schema 集中定义 + 端点内 safeParse**。无备选方案。

### 2.1 方案优点

- Zod 已引入项目（`h5/types/schemas.ts` 已有使用），无新增依赖
- `safeParse` 不抛异常，降级路径可控
- 集中定义 schema 避免各端点重复定义

### 2.2 方案风险

- **Layer 泄漏**：SSE schema 定义在 `src/app/api/types/schemas.ts`，但消费者 `sse-terminal-event.ts` 在 `src/caijuehub/strategies/`。caijuehub 层引用 api/types 违反分层依赖方向（裁决层不应依赖路由层）。
- **重建量预估不充分**：40+ 个路由文件，每个端点需要定义请求体和响应 schema——这不仅是"加一个 safeParse"，而是需要梳理每个端点当前的实际字段语义。P1 的实现工作量可能远超 Plan 预估。

---

## 3. 决策结论

方向正确，但有 3 个 P0 缺口必须补（P0-1 撤回——api/types 定义合同，caijuehub 实现合同，依赖方向正确）：

### ~~P0-1: Schema 文件位置违反分层依赖~~（撤回）

`api/types/schemas.ts` 是合同的**生产者**，`caijuehub` 是实现合同的**消费者**——消费者依赖生产者是正确的依赖方向。原 Review 判断错误，已于 2026-06-30 撤回。

### P0-2: Plan 未穷举受影响端点文件，导致调用方清单缺失

Plan §三 轮次 1 写"2 文件"，实际 `handleInterrupt` + `resolveStreamEnd` 有 4 个调用方分布在多个路由文件中。如果 Plan 先在 §三 对 `src/app/api/` 做全量端点文件扫描和穷举，这些调用点就会自然暴露——不是 P0-2 本身漏了，是 Plan 的端点文件清单不完整导致下游判断出错。

**修正建议**：Plan 加入"受影响端点文件全量清单"（按目录穷举 `h5/agent`、`agent/chat/stream`、`agent/resume` 等路径 + 每个文件中 `handleInterrupt`/`resolveStreamEnd` 调用行号 + 是否需要传 `meta`），作为轮次 1 变更范围。

| 端点文件 | handleInterrupt 调用 | resolveStreamEnd 调用 | 需传 meta? |
|------|------|------|:--:|
| `h5/agent/route.ts` | L244 → 加 meta | L258 → 已有 threadId | ✅ |
| `h5/agent/[threadId]/resume/route.ts` | L80 → 加 meta | L92 → 已有 threadId | ✅ |
| `agent/chat/stream/route.ts` | 待查 | 待查 | 待查 |
| `agent/resume/route.ts` | 待查 | 待查 | 待查 |

### P0-3: SSE 协议文档未列入同步更新计划

`InterruptSSEPayloadSchema` 增加 `threadId` 字段后，H5 前端也需要更新。H5 SSE 协议文档 §7.2 需要新增 `threadId` 字段描述。前端对接方需要知道中断事件现在包含 `threadId`。

**修正建议**：Plan 加入"更新瑞丰耘H5小程序SSE流式聊天协议文档.md §7.2，新增 `threadId` 字段"。

### P0-4: 无 Specs 三元组

Plan 缺少对应的 `specs/farm-agent-api-zod-hardening/` 三元组（`spec.md` + `tasks.md` + `checklist.md`），这是 ADD 规范要求的产出。当前 Plan §4 验收标准用简单 checklist 替代了正式的 `checklist.md`。

---

## 4. 影响评估

### 4.1 受影响文件（修订后）

| 文件 | 改动 | 风险 |
|------|------|------|
| `src/caijuehub/types/sse-schemas.ts` | **新建**：SSE 事件 Zod schema | 低 |
| `src/app/api/types/schemas.ts` | **新建**：API 请求体 Zod schema（不含 SSE） | 低 |
| `src/caijuehub/strategies/sse-terminal-event.ts` | **修改**：`handleInterrupt` 加 meta + safeParse | 中（中断流变更） |
| `h5/agent/route.ts` | **修改**：调用 `handleInterrupt` 时传 `meta` | 中（生产流量） |
| `h5/agent/[threadId]/resume/route.ts` | **修改**：同上 | 中 |
| `agent/chat/stream/route.ts` | **可能**：同上 | 低（待查） |
| `agent/resume/route.ts` | **可能**：同上 | 低（待查） |
| `docs/.../瑞丰耘H5小程序SSE流式聊天协议文档.md` | **修改**：§7.2 中断事件新增 threadId | 低 |

### 4.2 协议破坏面

`event: interrupt` 的 data 从 `{ type, description, options }` 变为 `{ type, description, options, threadId }`——这是**向后兼容变更**（只加字段，不删字段）。前端不升级也能正常工作（忽略多余字段），只是仍然拿不到 threadId。

### 4.3 回滚风险

低——Zod `safeParse` 替代 `JSON.stringify`，失败降级路径是 fallback 到原 payload + audit 告警，不会使 SSE 流中断。

---

## 5. 建议修正优先级

| 优先级 | 问题 | 修正 |
|:--:|------|------|
| **P0** | 端点文件清单不完整 | Plan 加入全量端点文件扫描（调用方 + meta 参数）|
| **P0** | SSE 协议文档未同步 | 加入 docs 更新任务 |
| **P0** | 无 Specs 三元组 | 补 `spec.md` + `tasks.md` + `checklist.md` |
| **P1** | P1 范围过大 | 轮次 2-4 的 20+ 文件改动可降级，先完成 P0 |

---

## 6. 最终建议

**方向正确，可以执行，但 P0-1~P0-4 四个缺口必须在进入 Step 1 代码实现前补到 Plan 里。**

建议执行顺序：
1. 补 Specs 三元组（spec.md + tasks.md + checklist.md）
2. 修正 Plan 中的 schema 文件位置（caijuehub/types/ → api/types/ 依赖方向修正）
3. 补充 handleInterrupt 调用方清单
4. 加入 SSE 协议文档更新任务
5. 将 P0-1~P0-3 的修正回流到 Plan 体中（触发 0.6.5 卡位）
6. 然后开始轮次 1 代码实现
