# zod-dto-convergence Review v1

- **Plan**: `farm-agent-zod-dto-convergence-plan-v1`
- **评审时间**: 2026-07-03
- **评审方式**: 代码现状 grep + schema 逐字段比对

---

## P0 — 必须回流 Plan，阻塞 Task 1

### P0-1: `type` 字段 optional/required 未决策

`NeuronChatRequestSchema` 有 `type: z.literal("chat")` 为**必填**字段，而当前 `agent/stream/route.ts` 和 `agent/chat/route.ts` 导入的 `ChatRequest` **不含 `type`**。

Task 3 计划将 `ChatRequest` re-export 为 `NeuronChatRequest`，切换后 GUI 不传 `type` 会被 `safeParse` 拒绝返回 400。

**决策选项**：
- A: `type` 改为 `.optional()`，兼容所有端
- B: `type` 保持必填，Task 5 中 stream/chat 路由需同步要求 GUI 传 `type: "chat"`
- C: 不统一为一个 schema，保留 `AgentChatStreamSchema`（无 type）和 `NeuronChatRequestSchema`（有 type）独立

### P0-2: `messages[].name` 字段差异遗漏

| Schema | `messages[].name` |
|--------|:--:|
| `agent.dto.ts` ChatRequest | `string?` ✅ |
| `hash/schemas.ts` NeuronChatRequestSchema | `string?` ✅ |
| `farm-agent/schemas.ts` AgentChatStreamSchema | **缺失** ❌ |

Task 1 差异表未列出此字段。`AgentChatStreamSchema` 的 messages 子 schema 需补 `name: z.string().optional()`。

### P0-3: `intent` 字段差异遗漏

| Schema | `intent` |
|--------|:--:|
| `agent.dto.ts` ChatRequest | ❌ 无 |
| `hash/schemas.ts` NeuronChatRequestSchema | ✅ optional |
| `farm-agent/schemas.ts` AgentChatStreamSchema | ✅ optional |

手写 DTO 缺失此字段。对齐时需确认：是 DTO 遗漏（应补）还是有意排除（schema 应删）。

---

## P1 — 数据不准确，需修正

### P1-1: safeParse 计数偏高

Plan 称"有 safeParse = 17"，实际 grep 统计约 **12-13 个** route 有 safeParse 调用（含 response 校验）。无 safeParse 且有 `request.json()` 的实际约 **18 个**。

### P1-2: `h5/types/dto.ts` 也是死文件

Plan Task 2 要求"检查每个 interface 是否有非 schema 消费方"。实际全项目 grep 结果：**零导入** `src/app/api/h5/types/dto.ts`。

与 `h5/types/schemas.ts` 一样是死文件，可直接删除，无需逐 interface 分析。Task 2 步骤可简化。

### P1-3: ChatRequest 三份定义差异表不完整

Plan §1.1 差异表仅列 6 个字段，实际差异至少 9 个（补 `name`、`intent`、`interactionResponse`）。

---

## P2 — 建议优化

### P2-1: 缺少 schema 复用策略

`NeuronChatRequestSchema` 与 `AgentChatStreamSchema` 字段重叠约 80%，Plan 只说"对齐字段"但未讨论抽取公共 base schema：

```typescript
const BaseChatSchema = z.object({ messages, threadId, user, project, modelConfig, ... })
export const NeuronChatRequestSchema = BaseChatSchema.extend({ type: z.literal("chat"), ... })
export const AgentChatStreamSchema = BaseChatSchema.extend({ ... })
```

不抽取则两份独立 schema 未来仍会漂移，与 Plan 目标"Zod 成为唯一真相源"矛盾。

### P2-2: `h5/types/schemas.ts` 描述需精确

Plan §1.1 称其"头部注释声明已迁移，内容冗余"。实际该文件 304 行，内容是完整的 H5 响应 schema（非请求 schema），且全项目零导入。建议描述为"完整死文件，304 行，零导入"。

---

## 评审结论

| 级别 | 数量 | 是否阻塞实施 | 状态 |
|------|:--:|:--:|:--:|
| P0 | 3 | ✅ 阻塞 Task 1 | ✅ 已回流 Plan |
| P1 | 3 | ❌ 不阻塞但需修正 | ✅ 已回流 Plan |
| P2 | 2 | ❌ 建议采纳 | ✅ 已回流 Plan |

**判定**: 全部 8 个发现已回流 Plan §1.1 / Task 1-3 / §七。核心决策：`BaseChatSchema` 抽取 + `ChatRequest` re-export 自 `AgentChatStreamSchema.z.infer`。
