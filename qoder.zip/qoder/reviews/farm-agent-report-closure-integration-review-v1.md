# farm-agent-report-closure-integration-review-v1

## Review 元信息

- **Review 对象**: [farm-agent-report-closure-integration-plan-v1](../plans/2026-07/01/farm-agent-report-closure-integration-plan-v1.md)
- **对比方案**: 方案 A: 新增 Step 9（独立条件性步骤）vs 方案 B: 扩展 Step 8（四步闭环内嵌）
- **Review 时间**: 2026-07-01
- **Review 类型**: 架构决策
- **前置阅读**: 
  - Plan: `.qoder/plans/2026-07/01/farm-agent-report-closure-integration-plan-v1.md`
  - REPORT-WORKFLOW: `.qoder/reports/REPORT-WORKFLOW.md`
  - check-boundary-report: `scripts/check-boundary-report.ts`
  - add-paradigm SKILL: `.qoder/skills/add-paradigm/SKILL.md`

---

## 1. 问题复现

gateway.md 运行时发现的关闭流程存在三个断裂：

1. **handoff 无 Report Closure 模板** — runtime-fix plan 的 handoff 不知道如何关闭 gateway.md 发现
2. **REPORT-WORKFLOW.md 格式与脚本不一致** — doc 写 `**Triage 结果**`，但 `check-boundary-report.ts` L58-60 解析 `- [x]` checklist 行
3. **ADD 工作流未接入 Report 流程** — 运行时修复完成后没有强制步骤要求关闭 gateway.md 发现

---

## 2. 方案对比

### 2.1 方案 A: 新增 Step 9（独立条件性步骤）

- 新建 `report-handoff-template.md` 独立模板
- 新增 ADD Step 9 Report Closure，仅 runtime-fix plan 执行
- 12 个治理文件同步 Step 0-8 → Step 0-9

**优势**:
- 关注点分离：文档收敛（Step 8）与监控关闭（Step 9）解耦
- 条件触发明确：非 runtime plan 自然跳过
- 审计可追溯：独立 step 编号可独立查询

**劣势**:
- 12 个文件需要同步改动，覆盖面广
- ADD 范式版本号从 9→10 阶段，历史文档引用需注意

### 2.2 方案 B: 扩展 Step 8（四步闭环内嵌）

- Step 8 三步闭环改为四步闭环，第四步条件执行
- 不新增 Step 编号

**优势**:
- 改动范围小，仅 add-paradigm SKILL.md + 词汇表
- 不改变 Step 编号体系

**劣势**:
- 文档收敛与监控关闭耦合在同一 Step
- 非 runtime plan 的 Step 8 会有空步骤
- 无法独立审计 report closure 完成状态

### 2.3 选型

**选择方案 A**。理由：
- 关注点分离是 ADD 基本原则，不同维度的收敛不应混在同一 Step
- Step 9 条件性步骤模式可复用于未来其他"条件性收敛"场景
- 12 个文件的同步虽然工作量大，但是一次性架构升级

---

## 3. 决策结论

1. **新增 ADD Step 9（Report Closure）** — runtime-fix plan 条件性步骤
2. **新建 `report-handoff-template.md`** — 独立模板，不污染通用 handoff 模板
3. **同步 12 个治理文件** — 从 Step 0-8/9阶段 更新到 Step 0-9/10阶段
4. **gateway.md 立即应用新流程** — 31 条发现追加 `- [x]`

---

## 4. 影响评估

### 4.1 受影响文件（12 个）

| # | 文件 | 改动类型 | 风险 |
|---|------|---------|:--:|
| 1 | `.qoder/templates/report-handoff-template.md` | 新建 | 低 |
| 2 | `AGENTS.md` | 修改 2 处 | 低 |
| 3 | `.qoder/skills/add-paradigm/SKILL.md` | 修改多处 + 新增 Step 9 章节 | 中 |
| 4 | `.qoder/vocabulary/add-governance-vocabulary.md` | 新增 5 条词汇 + 更新 5 条 | 中 |
| 5-6 | `add-route-template.md` ×2 | 各新增 1 行 | 低 |
| 7 | `.qoder/rules/project_rules.md` | 修改 2 处 + 新增 ADD-15 | 低 |
| 8 | `.qoder/rules/theory-practice-map.toml` | 新增 1 条映射 | 低 |
| 9 | `.qoder/agents/add-flow-guardian.md` | 新增 Step 9 入口/出口 | 中 |
| 10 | `.qoder/agents/add-orchestrator.md` | 新增 Step 9 行 + 提醒 | 中 |
| 11 | `.qoder/reports/REPORT-WORKFLOW.md` | 格式修正 + 流程补充 | 低 |
| 12 | `gateway.md` | 31 条追 `- [x]` + 删除 §2/§4 | 低 |

### 4.2 数据流影响

- 无代码逻辑变更，无数据迁移
- 仅治理文档升级，不影响运行时行为

### 4.3 回滚风险

- 低风险：所有改动限定在 `.qoder/` 和 `AGENTS.md`，不影响 `src/`
- 回滚方式：git revert

---

## 5. P0/P1 问题清单

| # | 严重程度 | 问题 | 修正建议 | 回流位置 |
|---|:------:|------|---------|---------|
| 1 | P0 | gateway.md 31 条发现未 `- [x]` 标记 | Step 9 执行时批量追加 | Plan §三 Task K |
| 2 | P0 | REPORT-WORKFLOW.md 格式与脚本不一致 | `**Triage 结果**` → `- [x] Triage 结果:` | Plan §三 Task J |
| 3 | P1 | add-paradigm SKILL.md 引用 "9 phases Step 0-8" | 改为 "10 phases Step 0-9" | Plan §三 Task D |
| 4 | P1 | add-governance-vocabulary.md 缺 report 词汇 | 新增 gateway.md / Step 9 / boundary-report | Plan §三 Task C |
| 5 | P2 | 历史 plan/review 中 "Step 0-8" 引用 | 不修改（历史文档保持原样） | 已知不处理 |
