# farm-agent-domain-vocabulary-review-v2

> 方案评审（Plan Review），评审对象为 `farm-agent-domain-vocabulary-plan-v2.md`。

## Review 元信息

- **评审对象**: `.qoder/plans/2026-07/01/farm-agent-domain-vocabulary-plan-v2.md`
- **评审时间**: 2026-07-02
- **评审类型**: 方案评审（Plan Review）
- **评审人**: Qoder
- **前置 Plan**: [farm-agent-domain-vocabulary-plan-v1.md](../plans/2026-06/25/farm-agent-domain-vocabulary-plan-v1.md)（✅ 已完成 2026-06-26）

---

## 总体评价

Plan 结构清晰、技术扎实、遵循 ADD 规范。核心架构（3-Tier Cascade）方案选型有充分的行业方案对比和量化数据支撑。6 个 Task 分解合理可执行。以下是按严重程度分类的评审意见。

---

## P0 — 阻塞性问题（实施前必须解决）

### 发现 #1: 缺少 ADD Route 和 Spec（实施前置条件缺失）

**现状**: Plan 中明确标注 ADD Route、Handoff、Spec 均为"待生成"。按 ADD 范式规定，add-route 和 spec 必须在 Step 1（实施）开始前存在。没有 add-route，就没有将 6 个 Task 绑定到 ADD 门禁（DPS/RAHS）的执行路线图。

**影响**: 无法进入 Step 1 实施阶段。缺少 Spec 会导致实现时无精确接口定义可参照。

**修复方向**:
1. 生成 `farm-agent-domain-vocabulary-add-route-v2.md`，在每个 Task 边界标注 DPS/RAHS 闸门检查点
2. 生成 `farm-agent-domain-vocabulary-v2/spec.md`，包含 `RouterResult`、`Candidate`、`Tier1Index` 等精确类型定义和 Tier 1/2/3 的 WHEN-THEN 场景

---

### 发现 #2: `buildContextBlock()` 同步→异步转换未说明

**现状**: Plan 的 Task 5（第 294 行）要求 `buildContextBlock()` 调用 `Router.route()`。但查看实际代码 `src/agents/prompts/intention.ts:31`，`buildContextBlock()` 是**同步函数**，而 `Router.route()` 必须是**异步**的（Tier 2 需要 `await getEmbeddings()`）。

**级联影响**:
```
buildContextBlock() → async
  └─ buildPrompt() → async
       └─ PromptTemplate.build 接口签名 → 改为 Promise<string>
```

**影响**: 如果实施时才发现这个异步转换问题，会打乱 Task 5 的工期预估。`PromptTemplate` 接口变更可能影响其他 prompt 模板。

**修复方向**: 在 Plan 的 §3.3 或 Task 5 中新增说明：
- `buildPrompt()` 将改为 `async`，返回 `Promise<string>`
- `PromptTemplate.build` 接口签名从 `(input: T) => string` 改为 `(input: T) => Promise<string>`
- 评估其他实现 `PromptTemplate` 的 prompt 是否受影响

---

### 发现 #3: 未提及 DPS 闸门检查

**现状**: 按 AGENTS.md 和 ADD 范式规定，`check_dps` 应在 Step 0 末尾调用。Plan 中没有记录 DPS 检查结果，PLAN 元信息中也无 DPS 状态字段。

**影响**: 缺少治理合规记录，无法确认 Plan 的四维质量（可观测性/阶段对称/审计完整性/失败路径覆盖）是否通过。

**修复方向**: 
1. 调用 `check_dps({ planKeyword: "domain-vocabulary-v2" })` 
2. 在 PLAN 元信息中增加 `DPS 状态` 字段，记录检查结果
3. 如有未通过项，在 Plan 中补充对应内容

---

## P1 — 重要缺陷

### 发现 #4: 验收标准中维度数据不一致（第 315 行）

**现状**: 第 273 行正确标注 `text-embedding-v4` = 1024 维，`14 × 1024 × 4B = 57KB`。但第 315 行验收清单仍写着：

```
Tier 2 centroid embedding 启动时计算完成（14 * 384 维，内存 <50KB）
```

这是最初 MiniLM-L6-v2 方案（384 维）的残留数据，v2 已修正为 1024 维。

**影响**: 验收时可能拿 384 维去验证，发现与 1024 维不匹配。

**修复方向**: 将第 315 行改为 `14 * 1024 维，内存 <60KB`。

---

### 发现 #5: 缺少回滚/灰度策略

**现状**: Plan 修改了核心路由路径（意图 → 专家分发），影响全部 14 个专家。如果 3-Tier Router 有 bug，每个用户请求都会受影响。当前没有任何：
- Feature flag 在 v1（纯 LLM）和 v2（3-Tier）之间切换
- 回滚步骤
- 灰度/分阶段上线方案

**影响**: 上线后如 Router 出现分词错误或 Embedding 异常，无法快速回退到 v1 稳定路径，所有用户受影响。

**修复方向**: 
1. 增加 `USE_V2_ROUTER` 环境变量（默认 `false`），`intention.ts` 在 Router 出问题时自动 fallback 到 v1 行为
2. 在风险矩阵中增加此项缓解措施

---

### 发现 #6: Tier 3 LLM fallback 的 prompt 质量风险未澄清

**现状**: Plan 说 Tier 3 LLM 只看到 "top-3 候选专家描述"（非触发词）。但当前 `buildPrompt()` 还注入了 `INTENT_SEMANTICS`（7 种 intent 类型定义）和 `CROSS_DOMAIN_RULES`（跨域判定规则），这两者对 LLM 做意图分类至关重要。

如果 Tier 3 去掉这些，LLM 的意图分类质量可能比 v1 还差——top-3 候选专家描述只告诉 LLM "可能是这些专家"，不告诉它"如何判定 intent 类型"。

**影响**: Tier 3 覆盖 5-10% 的请求，如果这部分意图分类质量下降，整体用户体验可能倒退。

**修复方向**: 在 §3.3 或 Task 5 中明确：
- Tier 3 LLM prompt 是否仍保留 `INTENT_SEMANTICS` 和 `CROSS_DOMAIN_RULES`
- 还是完全被 Router 的 top-3 候选替代
- 如果保留，两者如何组合

---

## P2 — 改进建议

### 发现 #7: Tier 1 中文分词方案可能不够用

**现状**: Plan 使用 `Intl.Segmenter`（Node.js 22+）做中文分词（第 330 行）。`Intl.Segmenter` 做的是**字素切分**（grapheme clustering），不是语义分词。"烂根" 会被切成 `["烂", "根"]`，无法匹配触发词表中的复合词 "烂根"。

v2 触发词包含大量多字口语短语（"烂根"、"打药"、"选种"、"叶子发黄"），`Intl.Segmenter` 的逐字切分会显著降低 Tier 1 命中率。

**影响**: Tier 1 的实际覆盖率可能远低于预期的 60-70%，大量请求被迫走 Tier 2/3，抵消了成本优势。

**建议**: 
- 方案 A: 使用 `nodejieba` 等中文语义分词库
- 方案 B: 用重叠 n-gram（2-4 字滑动窗口）构建 Tier 1 反向索引，补偿 `Intl.Segmenter` 的局限
- 更新风险矩阵，增加"分词精度不足导致 Tier 1 命中率低于预期"风险

---

### 发现 #8: Tier 2 阈值缺少实证依据

**现状**: `top-1 > 0.6` 和 `top-1 - top-2 > 0.15`（第 274 行）没有调优来源或实证数据支撑。Cosine 相似度阈值高度依赖于：
- Embedding 模型（`text-embedding-v4` 对短查询的行为）
- 每个专家的触发词多样性和数量
- 查询长度（"虫害" vs "地里那片玉米叶子发黄有斑点"）

**影响**: 阈值设置不当会导致 Tier 2 误判率高——要么过早升级 Tier 3（增加成本），要么错误返回低置信度结果（影响路由准确性）。

**建议**: 
- 标注阈值为初始值，需要线上流量调优
- 增加 Tier 2 评分日志记录机制（`agentAudit` 或 console），用于离线阈值优化
- 建议初期设置较低的升级阈值（保守策略），观察线上数据后收紧

---

### 发现 #9: ACA professional 图依赖风险被低估

**现状**: 第 331 行正确标记为"高风险"，但缓解措施（"intention 用 subIntents 消费"）只覆盖了 deep 图路径。§3.4 描述的多专家 fan-out（crop_compare + variety_recommend → conflictResolver → aggregation）完全依赖 professional 图的 `aggregationNode` 和 `conflictResolver`，这些尚未实现。

**影响**: v2 Router 产出 top-K 多候选时，deep 图只能处理 subIntents 的独立子问题分解，无法实现 expert fan-out 后交叉验证和冲突裁决。用户看到的是"两个独立答案"而非"一个综合建议"。

**建议**: 
- 在 Plan 中明确标注：v2 Router 初期只做单专家路由，top-K > 1 时走 deep 图 subIntents 降级路径
- 多专家 fan-out 推迟到 professional 图（v3 ACA plan 轮次 4）集成后开启
- 更新 §3.4 的描述，区分"设计目标"和"v2 可达范围"

---

### 发现 #10: 对现有 `PromptTemplate` 接口的影响范围未评估

**现状**: `intention.ts` 中的 prompt 模板实现了 `PromptTemplate<IntentionInput, IntentionOutput>` 接口。如果 `build` 从同步改异步，需要确认系统中是否有其他 prompt 模板也实现了该接口，评估影响范围。

**建议**: Task 5 增加子任务：`grep 'PromptTemplate' src/agents/prompts/` 确认所有实现者，评估异步改造的影响范围。

---

## ✅ 做得好的地方

| 维度 | 评价 |
|------|------|
| **问题定义** | §1.2 三缺陷表格（覆盖率不足/prompt 注入天花板/联合链路无信号）一针见血，每个缺陷都有现象+根因 |
| **方案选型** | §2.1 行业三方案对比有成本($)/延迟(ms)/覆盖率(%)量化数据，选型有理有据 |
| **Embedding 复用** | 不引入新模型，复用 `getEmbeddings()`（`text-embedding-v4`, 1024 维）用于 RAG + 路由双场景，零额外开销 |
| **模块设计** | `src/agents/router/` 6 个文件，职责单一：index（入口）、tier1/2/3（逐层）、index-builder（初始化）、types（类型） |
| **资源估算** | Centroid 内存占用 57KB（14 × 1024 × 4B）计算准确，启动时一次构建，运行时零开销 |
| **范围控制** | "非目标"一节明确排除 v1 的 Storage/Category/裁决层/SSE/collectionHints，防止范围蔓延 |
| **风险矩阵** | 4 个风险，含概率/影响/缓解，格式规范 |
| **命名合规** | 符合 `{项目名}-{功能}-plan-v{N}.md` 命名规范 |

---

## 评审结论

| 级别 | 数量 | 关键项 |
|------|------|--------|
| 🔴 P0 | 3 | 缺 add-route/spec（#1）；sync→async 未说明（#2）；缺 DPS 检查（#3） |
| 🟡 P1 | 3 | 维度笔误 384→1024（#4）；缺回滚开关（#5）；Tier 3 prompt 范围不清（#6） |
| 🟢 P2 | 4 | `Intl.Segmenter` 分词能力（#7）；阈值需调优（#8）；professional 图耦合（#9）；`PromptTemplate` 影响范围（#10） |

**判定**: P0 项已全部解决。核心架构（2-Tier Embedding + LLM Fallback）设计合理，5 个 Task 可执行。✅ 可进入 Step 1 实施。

**回流完成清单**：

| # | 级别 | 结论 | 写回位置 |
|---|:--:|------|---------|
| P0 #1 | 🔴 | ✅ add-route + spec 三件套已生成 | Plan 元信息 |
| P0 #2 | 🔴 | ✅ 新建 `intention_async.ts` + `intention-async.ts` node + `agent-graph.ts` wiring，不改 `intention.ts` | Plan §3.3-3.4 |
| P0 #3 | 🔴 | ✅ DPS 88 分 🟢 PASS | Plan 元信息 |
| P1 #4 | 🟡 | ✅ 384→1024 已修正 | Plan 验收 §5 |
| P1 #5 | 🟡 | ❌ 不成立（professional 图独立，不需兜底） | — |
| P1 #6 | 🟡 | ✅ Tier 2 LLM prompt 保留 INTENT_SEMANTICS + CROSS_DOMAIN_RULES | Plan §2.2, §3.3 |
| P2 #7 | 🟢 | ✅ 砍 Tier 1 后无需分词 | Plan §2.2 |
| P2 #8 | 🟢 | ✅ 阈值标注需线上流量调优 | Plan 风险矩阵 §6 |
| P2 #9 | 🟢 | ✅ professional 图耦合风险已覆盖 | Plan 风险矩阵 §6 |
| P2 #10 | 🟢 | ✅ 不改 `PromptTemplate` 接口 | Plan §3.3 |

---

## 关联文档

| 文档 | 路径 | 状态 |
|------|------|------|
| V2 Plan | `.qoder/plans/2026-07/01/farm-agent-domain-vocabulary-plan-v2.md` | ✅ 已评审 |
| V1 Plan | `.qoder/plans/2026-06/25/farm-agent-domain-vocabulary-plan-v1.md` | ✅ 已完成 |
| V3 ACA Plan | `.qoder/plans/2026-06/29/farm-agent-three-tier-reasoning-graph-plan-v3.md` | 🔄 进行中 |
| ADD Route | `.qoder/plans/2026-07/01/farm-agent-domain-vocabulary-add-route-v2.md` | ✅ 已生成 |
| Spec | `.qoder/specs/farm-agent-domain-vocabulary-v2/spec.md` | ✅ 已生成 |
