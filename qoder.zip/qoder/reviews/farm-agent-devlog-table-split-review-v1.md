# farm-agent-devlog-table-split-review-v1

## Review 元信息

- **Review 对象**: `.qoder/plans/2026-06/25/farm-agent-devlog-table-split-plan-v1.md`
- **Review 范围**: Schema 设计、迁移策略、MCP 工具兼容、session-init 影响
- **Review 时间**: 2026-06-25
- **结论级别**: ✅ 可接受（1 P1 + 1 P2，非阻断）

---

## 1. 总体结论

方向正确——AuditLog 混合承载运行时审计和开发操作是 session-init 上下文污染的根因。拆表方案选型合理：同库分表，不碰 `agentAudit()` 链路，只改 MCP 工具底层。Schema 设计干净，DevOperation 是 AuditLog 的精简版（去 userId / traceId）。

---

## 2. 正向评价

| 评价项 | 说明 |
|--------|------|
| ✅ 拆表不拆库 | 最低侵入，不引入新连接串 |
| ✅ AuditLog 零改动 | agentAudit() / AuditCallback 不受影响 |
| ✅ session-init 接口不变 | MCP 工具内部切换表，上层无感 |
| ✅ 旧数据不迁移 | 量小，自然过渡，避免迁移风险 |
| ✅ Schema 完整 | DevOperation 保留 userId 和 user FK；traceId 换为 planKeyword（devlog 无请求上下文，用 Plan 级分组键） |

---

## 3. 问题清单

### P1-1: session-init 过渡期空结果

**问题**：`record_dev_operation` 切到 DevOperation 后，旧 AuditLog 中的 devlog 记录不会被查到。session-init 在新表为空时返回空结果，导致上下文恢复失败。

**影响**：仅影响切换后第一次 session-init，之后新 devlog 写入即正常。

**修正建议**：在 MCP `query_audit_logs` 中增加 fallback 逻辑——DevOperation 为空时，fallback 查询 AuditLog（where action in devlog 相关 action 类型）。过渡期后（如 7 天）可移除此逻辑。

### P2-1: Plan 未提及 `check_dps` / `check_rahs` 是否受影响

**问题**：Plan 未明确验证 `check_dps` 和 `check_rahs` 是否查询 AuditLog 表。如果这两个工具也依赖 AuditLog 做覆盖率分析，拆表后可能产生偏差。

**验证建议**：实施 Task 3 后，调用 `check_dps` 和 `check_rahs` 确认 DPS/RAHS 评分与拆表前一致。如不一致，说明工具内部也查询了 devlog 相关 action，需同步调整。

---

## 4. 影响评估

| 维度 | 修正前 | 修正后 |
|------|--------|--------|
| session-init 数据源 | AuditLog（混合） | DevOperation + AuditLog fallback |
| record_dev_operation 写入 | AuditLog | DevOperation |
| agentAudit() 写入 | AuditLog | AuditLog（不变） |
| 回滚风险 | 无 | 低（仅 MCP 工具改表名，可快速回滚） |

---

## 5. 建议修正优先级

| 优先级 | 编号 | 问题 | 修正 |
|--------|------|------|------|
| 🟡 P1 | P1-1 | 过渡期 session-init 空结果 | MCP query_audit_logs 加 AuditLog fallback |
| 🟢 P2 | P2-1 | check_dps/check_rahs 未验证 | 实施后验证 DPS/RAHS 一致性 |

---

## 6. 最终建议

1. **可进入实施**，P1-1 和 P2-1 均非阻断。
2. P1-1 在 Task 3 实施时一并处理（MCP query_audit_logs 加一行 fallback SQL）。
3. P2-1 在 Task 5 回测阶段验证。
